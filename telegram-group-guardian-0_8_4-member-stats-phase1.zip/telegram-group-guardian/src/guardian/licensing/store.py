"""Persistence contract for group licenses (implemented by memory_store / postgres_store)."""
from __future__ import annotations

from datetime import datetime
from typing import Protocol

from .models import AuditEvent, GroupLicense, LicenseStatus


class LicenseStore(Protocol):
    """All methods are async and scoped by group_id (no cross-group queries leak data)."""

    async def get(self, group_id: int) -> GroupLicense | None:
        ...

    async def register_pending_if_absent(
        self, group_id: int, title: str | None, now: datetime
    ) -> tuple[GroupLicense, bool]:
        """Atomically create a PENDING license if none exists. Returns (license, created).

        MUST NOT change the status of an existing row (re-adding the bot never
        reactivates, never lifts expired/rejected/banned). May refresh `title` only.
        When created, an audit record `register_pending` is appended in the same atomic step.
        """
        ...

    async def transition(
        self,
        group_id: int,
        *,
        expected_status: LicenseStatus,
        new_license: GroupLicense,
        audit: AuditEvent,
    ) -> bool:
        """Compare-and-set: replace the row only if its current status == expected_status,
        appending `audit` atomically. Returns False (and writes nothing) on mismatch,
        which makes repeated/concurrent calls idempotent.
        """
        ...

    async def audit_for_group(self, group_id: int, limit: int = 50) -> list[AuditEvent]:
        """Most recent license audit records of THIS group only (oldest first)."""
        ...

    async def list_all(self, limit: int = 2000) -> list[GroupLicense]:
        """READ-ONLY listing of the registered groups for the OWNER panel (newest change first, then group_id).
        This is the only cross-group read of licenses: it has no authorization of its own, so only the owner-panel
        service (which checks the primary owner on every call) may use it. At most `limit` rows (1..5000)."""
        ...
