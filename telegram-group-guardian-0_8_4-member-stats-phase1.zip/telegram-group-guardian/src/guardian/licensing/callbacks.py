"""Strict codec + server-side handler for license-action callback data.

Callback data is attacker-controlled: any user can craft any string. Therefore
* parsing is a strict whitelist (fixed prefix, known action codes, one negative integer);
* the ACTOR is always the Telegram user of the callback update (`callback.from_user.id`),
  never something inside the data;
* authorization is re-checked on the server on every call (hiding buttons is not security).
Only argument-less actions are supported here. Duration-bearing actions (temporary/renew)
arrive in Phase 5 together with a confirmation step.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from ..auth import MIN_BIGINT
from ..audit import FORGED_CALLBACK, SecurityAudit, make_event, record_safely
from ..errors import InvalidInput, PermissionDenied
from .admin import (
    ALLOW,
    BAN,
    REJECT,
    STOP,
    UNBAN,
    ACTIVATE_PERMANENT,
    LicenseActionResult,
    LicenseAdminService,
)

PREFIX = "lic"
MAX_CALLBACK_BYTES = 64  # Telegram limit
_CODES = {
    "ap": ACTIVATE_PERMANENT,
    "st": STOP,
    "rj": REJECT,
    "bn": BAN,
    "ub": UNBAN,
    "al": ALLOW,
}
_ACTION_TO_CODE = {v: k for k, v in _CODES.items()}
_RE = re.compile(r"^lic:(ap|st|rj|bn|ub|al):(-[1-9][0-9]{0,18})$", re.ASCII)  # ASCII digits only


@dataclass(frozen=True, slots=True)
class LicenseCallback:
    action: str
    group_id: int


def build_callback(action: str, group_id: int) -> str:
    if action not in _ACTION_TO_CODE:
        raise InvalidInput("unsupported callback action")
    if not isinstance(group_id, int) or isinstance(group_id, bool) or group_id >= 0:
        raise InvalidInput("group_id must be a negative integer")
    data = f"{PREFIX}:{_ACTION_TO_CODE[action]}:{group_id}"
    if len(data.encode("utf-8")) > MAX_CALLBACK_BYTES:
        raise InvalidInput("callback data too long")
    return data


def parse_callback(data: object) -> LicenseCallback:
    if not isinstance(data, str) or len(data.encode("utf-8", "ignore")) > MAX_CALLBACK_BYTES:
        raise InvalidInput("malformed callback")
    match = _RE.fullmatch(data)
    if not match:
        raise InvalidInput("malformed callback")
    group_id = int(match.group(2))
    if group_id < MIN_BIGINT:  # 19 digits can still overflow BIGINT
        raise InvalidInput("malformed callback")
    return LicenseCallback(_CODES[match.group(1)], group_id)


async def handle_license_callback(
    admin: LicenseAdminService,
    audit: SecurityAudit | None,
    actor_id: object,
    data: object,
    *,
    context_chat_id: int | None = None,
) -> LicenseActionResult:
    """Parse + authorize + execute. Raises InvalidInput (malformed) or PermissionDenied (forged)."""
    try:
        cb = parse_callback(data)
    except InvalidInput:
        await record_safely(
            audit,
            make_event(FORGED_CALLBACK, actor=actor_id if isinstance(actor_id, int) and not isinstance(actor_id, bool) else None,
                       detail="malformed license callback"),
        )
        raise
    method = getattr(admin, cb.action)  # action names are whitelisted by the codec
    try:
        return await method(actor_id, cb.group_id, context_chat_id=context_chat_id)
    except PermissionDenied:
        await record_safely(
            audit,
            make_event(FORGED_CALLBACK, actor=actor_id if isinstance(actor_id, int) and not isinstance(actor_id, bool) else None,
                       group_id=cb.group_id, permission="change_license", detail=f"unauthorized {cb.action}"),
        )
        raise
