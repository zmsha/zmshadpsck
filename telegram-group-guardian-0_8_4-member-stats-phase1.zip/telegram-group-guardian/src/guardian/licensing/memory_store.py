"""In-memory reference implementation of LicenseStore.

For unit tests and local experiments ONLY: state is lost on restart, so it must
never be used as the production store.
"""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime

from .models import AuditEvent, GroupLicense, LicenseStatus


class InMemoryLicenseStore:
    def __init__(self) -> None:
        self._rows: dict[int, GroupLicense] = {}
        self.audit_log: list[AuditEvent] = []

    async def get(self, group_id: int) -> GroupLicense | None:
        return self._rows.get(group_id)

    async def register_pending_if_absent(
        self, group_id: int, title: str | None, now: datetime
    ) -> tuple[GroupLicense, bool]:
        existing = self._rows.get(group_id)
        if existing is not None:
            if title and title != existing.title:
                existing = replace(existing, title=title)  # metadata only; status untouched
                self._rows[group_id] = existing
            return existing, False
        created = GroupLicense(group_id=group_id, title=title, status=LicenseStatus.PENDING, updated_at=now)
        self._rows[group_id] = created
        self.audit_log.append(
            AuditEvent(
                group_id=group_id,
                action="register_pending",
                previous_status=None,
                new_status=LicenseStatus.PENDING,
                occurred_at=now,
            )
        )
        return created, True

    async def transition(
        self,
        group_id: int,
        *,
        expected_status: LicenseStatus,
        new_license: GroupLicense,
        audit: AuditEvent,
    ) -> bool:
        current = self._rows.get(group_id)
        if current is None or current.status is not expected_status:
            return False
        if new_license.group_id != group_id or audit.group_id != group_id:
            raise ValueError("group_id mismatch between arguments")
        self._rows[group_id] = new_license
        self.audit_log.append(audit)
        return True

    async def audit_for_group(self, group_id: int, limit: int = 50) -> list[AuditEvent]:
        return [e for e in self.audit_log if e.group_id == group_id][-limit:]

    async def list_all(self, limit: int = 2000) -> list[GroupLicense]:
        limit = max(1, min(int(limit), 5000))
        rows = sorted(self._rows.values(), key=lambda r: (-r.updated_at.timestamp(), r.group_id))
        return rows[:limit]
