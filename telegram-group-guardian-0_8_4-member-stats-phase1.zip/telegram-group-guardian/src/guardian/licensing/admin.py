"""Owner-only license actions (activate, renew, stop, reject, ban, unban, allow).

Every call:
1. authorizes on the SERVER through `PermissionService` (Permission.CHANGE_LICENSE = the
   primary owner only; `context_chat_id` must equal the target group when supplied);
2. validates the transition against the current EFFECTIVE status (a lapsed temporary
   license counts as expired even if the scheduler never ran);
3. applies a compare-and-set through the store, which writes the row and the audit record
   atomically; repeating a request is a no-op (`Outcome.NO_CHANGE`, no duplicate audit).

Duration parsing (Arabic phrases, calendar months) is Phase 5; this service receives an
absolute UTC `expires_at`.
"""
from __future__ import annotations

import enum
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Callable

from ..audit import LICENSE_ACTION_REJECTED, SecurityAudit, make_event, record_safely, sanitize_text
from ..errors import ConcurrentModification, GroupNotRegistered, InvalidInput, InvalidTransition
from ..permissions import Permission, PermissionService
from ..time_utils import ensure_utc, utcnow
from .models import AuditEvent, GroupLicense, LicenseStatus, evaluate
from .store import LicenseStore

MAX_LICENSE_HORIZON = timedelta(days=1830)  # ~5 years; longer needs a permanent activation
MAX_REASON_LEN = 200

ACTIVATE_PERMANENT = "activate_permanent"
ACTIVATE_TEMPORARY = "activate_temporary"
RENEW = "renew"
STOP = "stop"
REJECT = "reject"
BAN = "ban"
UNBAN = "unban"
ALLOW = "allow"

S = LicenseStatus
_ALL = frozenset(LicenseStatus)
_ALLOWED_FROM: dict[str, frozenset[LicenseStatus]] = {
    ACTIVATE_PERMANENT: frozenset({S.PENDING, S.ACTIVE_PERMANENT, S.ACTIVE_TEMPORARY, S.EXPIRED, S.STOPPED}),
    ACTIVATE_TEMPORARY: frozenset({S.PENDING, S.ACTIVE_PERMANENT, S.ACTIVE_TEMPORARY, S.EXPIRED, S.STOPPED}),
    STOP: frozenset({S.STOPPED, S.ACTIVE_PERMANENT, S.ACTIVE_TEMPORARY}),
    REJECT: frozenset({S.REJECTED, S.PENDING, S.EXPIRED, S.STOPPED}),
    BAN: _ALL,
    UNBAN: frozenset({S.BANNED, S.PENDING}),   # PENDING = already lifted -> idempotent no-op
    ALLOW: frozenset({S.REJECTED, S.PENDING}),
}
# Activating from REJECTED/BANNED is deliberately impossible: lift first (unban/allow -> pending).


class Outcome(str, enum.Enum):
    CHANGED = "changed"
    NO_CHANGE = "no_change"


@dataclass(frozen=True, slots=True)
class LicenseActionResult:
    outcome: Outcome
    action: str
    license: GroupLicense


class LicenseAdminService:
    def __init__(
        self,
        store: LicenseStore,
        permissions: PermissionService,
        audit: SecurityAudit | None = None,
        *,
        clock: Callable[[], datetime] = utcnow,
    ):
        self._store = store
        self._permissions = permissions
        self._audit = audit
        self._clock = clock

    # ------------------------------------------------------------------ public actions
    async def activate_permanent(self, actor_id, group_id, *, reason=None, context_chat_id=None) -> LicenseActionResult:
        return await self._run(ACTIVATE_PERMANENT, actor_id, group_id, reason, context_chat_id, None)

    async def activate_temporary(self, actor_id, group_id, expires_at: datetime, *, reason=None,
                                 context_chat_id=None) -> LicenseActionResult:
        """Activate or renew until `expires_at` (UTC). Renewal counts from the caller's computed
        `expires_at` (Phase 5 computes it from 'now', not from the old expiry, by default)."""
        return await self._run(ACTIVATE_TEMPORARY, actor_id, group_id, reason, context_chat_id, expires_at)

    async def stop(self, actor_id, group_id, *, reason=None, context_chat_id=None) -> LicenseActionResult:
        return await self._run(STOP, actor_id, group_id, reason, context_chat_id, None)

    async def reject(self, actor_id, group_id, *, reason=None, context_chat_id=None) -> LicenseActionResult:
        return await self._run(REJECT, actor_id, group_id, reason, context_chat_id, None)

    async def ban(self, actor_id, group_id, *, reason=None, context_chat_id=None) -> LicenseActionResult:
        return await self._run(BAN, actor_id, group_id, reason, context_chat_id, None)

    async def unban(self, actor_id, group_id, *, reason=None, context_chat_id=None) -> LicenseActionResult:
        """banned -> pending (the owner must still activate explicitly afterwards)."""
        return await self._run(UNBAN, actor_id, group_id, reason, context_chat_id, None)

    async def allow(self, actor_id, group_id, *, reason=None, context_chat_id=None) -> LicenseActionResult:
        """rejected -> pending (the owner must still activate explicitly afterwards)."""
        return await self._run(ALLOW, actor_id, group_id, reason, context_chat_id, None)

    # ------------------------------------------------------------------ core
    async def _run(self, kind, actor_id, group_id, reason, context_chat_id, expires_at) -> LicenseActionResult:
        await self._permissions.require(actor_id, group_id, Permission.CHANGE_LICENSE, context_chat_id=context_chat_id)
        now = self._clock()
        note = sanitize_text(reason, MAX_REASON_LEN)
        if kind == ACTIVATE_TEMPORARY:
            expires_at = self._validate_expiry(expires_at, now)

        current = await self._store.get(group_id)
        if current is None:
            raise GroupNotRegistered("group is not registered")
        effective = evaluate(current, now).status or current.status

        if effective not in _ALLOWED_FROM[kind]:
            await self._reject(actor_id, group_id, kind, effective)
            raise InvalidTransition(f"{kind} is not allowed from {effective.value}")

        target = self._target_status(kind)
        if self._is_noop(kind, current, effective, expires_at):
            return LicenseActionResult(Outcome.NO_CHANGE, kind, current)

        action = kind
        if kind == ACTIVATE_TEMPORARY and effective in (S.ACTIVE_TEMPORARY, S.EXPIRED):
            action = RENEW
        new = self._build(kind, current, target, actor_id, now, expires_at, note)
        audit = AuditEvent(
            group_id=group_id,
            action=action,
            previous_status=effective,
            new_status=target,
            occurred_at=now,
            actor_telegram_id=actor_id,
            expires_at=new.expires_at if target in (S.ACTIVE_TEMPORARY,) else None,
            reason=note,
        )
        if await self._store.transition(group_id, expected_status=current.status, new_license=new, audit=audit):
            return LicenseActionResult(Outcome.CHANGED, action, new)

        # Lost a race. If the winner produced exactly what we wanted, we are done (idempotent).
        again = await self._store.get(group_id)
        if again is not None and again.status is target and again.expires_at == new.expires_at:
            return LicenseActionResult(Outcome.NO_CHANGE, kind, again)
        raise ConcurrentModification("license changed concurrently; re-read and retry")

    @staticmethod
    def _target_status(kind: str) -> LicenseStatus:
        return {
            ACTIVATE_PERMANENT: S.ACTIVE_PERMANENT,
            ACTIVATE_TEMPORARY: S.ACTIVE_TEMPORARY,
            STOP: S.STOPPED,
            REJECT: S.REJECTED,
            BAN: S.BANNED,
            UNBAN: S.PENDING,
            ALLOW: S.PENDING,
        }[kind]

    @staticmethod
    def _is_noop(kind, current: GroupLicense, effective: LicenseStatus, expires_at) -> bool:
        if kind == ACTIVATE_TEMPORARY:
            return effective is S.ACTIVE_TEMPORARY and current.expires_at == expires_at
        # same status requested again (active_permanent/stopped/rejected/banned/pending)
        target = LicenseAdminService._target_status(kind)
        return effective is target and current.status is target

    @staticmethod
    def _build(kind, current: GroupLicense, target, actor_id, now, expires_at, note) -> GroupLicense:
        common = dict(group_id=current.group_id, title=current.title, status=target, updated_at=now, note=note)
        if target is S.ACTIVE_PERMANENT:
            return GroupLicense(**common, activated_at=now, activated_by=actor_id, expires_at=None)
        if target is S.ACTIVE_TEMPORARY:
            return GroupLicense(**common, activated_at=now, activated_by=actor_id, expires_at=expires_at)
        if target is S.PENDING:  # unban / allow: back to a clean pending state
            return GroupLicense(**common)
        # stopped / rejected / banned: keep the history fields for display
        return GroupLicense(**common, activated_at=current.activated_at, activated_by=current.activated_by,
                            expires_at=current.expires_at if current.status is S.ACTIVE_TEMPORARY else None)

    @staticmethod
    def _validate_expiry(expires_at, now: datetime) -> datetime:
        if not isinstance(expires_at, datetime):
            raise InvalidInput("expires_at must be a datetime")
        try:
            value = ensure_utc(expires_at)
        except ValueError as exc:
            raise InvalidInput("expires_at must be timezone-aware") from exc
        if value <= now:
            raise InvalidInput("expires_at must be in the future")
        if value - now > MAX_LICENSE_HORIZON:
            raise InvalidInput("expires_at is too far in the future")
        return value

    async def _reject(self, actor_id, group_id, kind, effective) -> None:
        await record_safely(
            self._audit,
            make_event(LICENSE_ACTION_REJECTED, actor=actor_id, group_id=group_id,
                       permission=Permission.CHANGE_LICENSE.value, detail=f"{kind} not allowed from {effective.value}",
                       now=self._clock()),
        )
