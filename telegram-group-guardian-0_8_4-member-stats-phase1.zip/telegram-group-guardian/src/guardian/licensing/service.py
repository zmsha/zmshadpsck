"""License checking service (read path + bot-added registration).

Phase 1 scope: contracts and the safe runtime check. Owner actions (activate,
renew, stop, reject, ban, unban) and the Postgres transitions arrive in later phases.
"""
from __future__ import annotations

import logging
from datetime import datetime

from ..time_utils import utcnow
from .models import AuditEvent, DenyReason, GroupLicense, LicenseDecision, LicenseStatus, evaluate
from .store import LicenseStore

log = logging.getLogger(__name__)


class LicenseService:
    def __init__(self, store: LicenseStore, on_new_group=None):
        self._store = store
        self._on_new_group = on_new_group  # async (group_id) -> None; runs ONLY when this call registered the group (5.7 defaults)

    async def check(self, group_id: int, now: datetime | None = None) -> LicenseDecision:
        """Is protection allowed in `group_id` right now? Fails CLOSED on any problem."""
        decision, _ = await self.status_report(group_id, now)
        return decision

    async def status_report(
        self, group_id: int, now: datetime | None = None
    ) -> tuple[LicenseDecision, GroupLicense | None]:
        """Decision plus the stored license (for display). Fails CLOSED on any problem.

        The decision is computed from stored data AND the current time, so an
        expired temporary license is denied even if the scheduler never ran
        (e.g. the free host was asleep). Persisting the expiry is best-effort and
        can never turn a denial into an approval.
        """
        now = now or utcnow()
        try:
            license_ = await self._store.get(group_id)
        except Exception:  # store down, DB timeout, bug... -> deny
            log.error("license lookup failed; denying protection", extra={"group_id": group_id}, exc_info=True)
            return LicenseDecision(False, None, DenyReason.STORE_UNAVAILABLE), None

        decision = evaluate(license_, now)
        if decision.expired_by_time and license_ is not None:
            await self._record_expiry(license_, now)
        return decision, license_

    async def on_bot_added(self, group_id: int, title: str | None, now: datetime | None = None) -> tuple[GroupLicense, bool]:
        """Register the group as PENDING if unknown. Never reactivates or unbans.

        Raises if the store is unavailable (callers decide how to report it).
        """
        license_, created = await self._store.register_pending_if_absent(group_id, title, now or utcnow())
        if created and self._on_new_group is not None:
            try:
                await self._on_new_group(group_id)
            except Exception:  # seeding defaults must never break registration (the group stays pending either way)
                log.warning("new-group hook failed", extra={"group_id": group_id}, exc_info=True)
        return license_, created

    async def _record_expiry(self, license_: GroupLicense, now: datetime) -> None:
        """Move ACTIVE_TEMPORARY -> EXPIRED once (compare-and-set makes repeats no-ops)."""
        try:
            expired = GroupLicense(
                group_id=license_.group_id,
                title=license_.title,
                status=LicenseStatus.EXPIRED,
                updated_at=now,
                activated_at=license_.activated_at,
                expires_at=license_.expires_at,
                activated_by=license_.activated_by,
                note=license_.note,
            )
            audit = AuditEvent(
                group_id=license_.group_id,
                action="auto_expire",
                previous_status=LicenseStatus.ACTIVE_TEMPORARY,
                new_status=LicenseStatus.EXPIRED,
                occurred_at=now,
                expires_at=license_.expires_at,
                reason="license time elapsed",
            )
            await self._store.transition(
                license_.group_id,
                expected_status=LicenseStatus.ACTIVE_TEMPORARY,
                new_license=expired,
                audit=audit,
            )
        except Exception:  # store errors, CAS races, bugs: never affects the decision
            log.warning("could not persist license expiry", extra={"group_id": license_.group_id}, exc_info=True)
