"""PostgreSQL LicenseStore.

`transition` is a compare-and-set inside ONE transaction: the group row is locked
(`FOR UPDATE`), its status must equal `expected_status`, then the row update and the
append-only audit record are written together (both or neither). Append-only
enforcement of the audit table is done by triggers in migration 0002.
NOT executed against a real PostgreSQL in the build sandbox - see TEST_REPORT.md.
"""
from __future__ import annotations

from datetime import datetime

from ..db.pool import Database
from .models import AuditEvent, GroupLicense, LicenseStatus

_COLUMNS = "group_id, title, license_status, activated_at, expires_at, activated_by, status_note, updated_at"


def _row_to_license(row) -> GroupLicense:
    return GroupLicense(
        group_id=row["group_id"],
        title=row["title"],
        status=LicenseStatus(row["license_status"]),
        activated_at=row["activated_at"],
        expires_at=row["expires_at"],
        activated_by=row["activated_by"],
        note=row["status_note"],
        updated_at=row["updated_at"],
    )


class PostgresLicenseStore:
    def __init__(self, database: Database):
        self._db = database

    async def get(self, group_id: int) -> GroupLicense | None:
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(f"SELECT {_COLUMNS} FROM telegram_groups WHERE group_id = $1", group_id)
        return _row_to_license(row) if row else None

    async def list_all(self, limit: int = 2000) -> list[GroupLicense]:
        limit = max(1, min(int(limit), 5000))
        async with self._db.acquire() as conn:
            rows = await conn.fetch(
                f"SELECT {_COLUMNS} FROM telegram_groups ORDER BY updated_at DESC, group_id LIMIT $1", limit)
        return [_row_to_license(r) for r in rows]

    async def register_pending_if_absent(
        self, group_id: int, title: str | None, now: datetime
    ) -> tuple[GroupLicense, bool]:
        async with self._db.acquire() as conn:
            async with conn.transaction():
                inserted = await conn.fetchrow(
                    "INSERT INTO telegram_groups (group_id, title, license_status, created_at, updated_at) "
                    "VALUES ($1, $2, 'pending', $3, $3) "
                    "ON CONFLICT (group_id) DO NOTHING RETURNING group_id",
                    group_id,
                    title,
                    now,
                )
                created = inserted is not None
                if created:
                    await conn.execute(
                        "INSERT INTO license_audit_log "
                        "(group_id, actor_telegram_id, action, previous_status, new_status, occurred_at) "
                        "VALUES ($1, NULL, 'register_pending', NULL, 'pending', $2)",
                        group_id,
                        now,
                    )
                elif title:
                    # Metadata only; never touches license_status.
                    await conn.execute(
                        "UPDATE telegram_groups SET title = $2 WHERE group_id = $1 AND title IS DISTINCT FROM $2",
                        group_id,
                        title,
                    )
                row = await conn.fetchrow(f"SELECT {_COLUMNS} FROM telegram_groups WHERE group_id = $1", group_id)
        return _row_to_license(row), created

    async def transition(
        self,
        group_id: int,
        *,
        expected_status: LicenseStatus,
        new_license: GroupLicense,
        audit: AuditEvent,
    ) -> bool:
        if new_license.group_id != group_id or audit.group_id != group_id:
            raise ValueError("group_id mismatch between arguments")
        async with self._db.acquire() as conn:
            async with conn.transaction():
                current = await conn.fetchval(
                    "SELECT license_status FROM telegram_groups WHERE group_id = $1 FOR UPDATE", group_id
                )
                if current is None or current != expected_status.value:
                    return False  # lost the race / stale expectation: nothing written
                await conn.execute(
                    "UPDATE telegram_groups SET title = $2, license_status = $3, activated_at = $4, "
                    "expires_at = $5, activated_by = $6, status_note = $7, updated_at = $8 WHERE group_id = $1",
                    group_id,
                    new_license.title,
                    new_license.status.value,
                    new_license.activated_at,
                    new_license.expires_at,
                    new_license.activated_by,
                    new_license.note,
                    new_license.updated_at,
                )
                await conn.execute(
                    "INSERT INTO license_audit_log (group_id, actor_telegram_id, action, previous_status, "
                    "new_status, expires_at, reason, occurred_at) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)",
                    group_id,
                    audit.actor_telegram_id,
                    audit.action,
                    audit.previous_status.value if audit.previous_status else None,
                    audit.new_status.value,
                    audit.expires_at,
                    audit.reason,
                    audit.occurred_at,
                )
        return True

    async def audit_for_group(self, group_id: int, limit: int = 50) -> list[AuditEvent]:
        limit = max(1, min(int(limit), 500))
        async with self._db.acquire() as conn:
            rows = await conn.fetch(
                "SELECT group_id, actor_telegram_id, action, previous_status, new_status, expires_at, reason, "
                "occurred_at FROM license_audit_log WHERE group_id = $1 ORDER BY id DESC LIMIT $2",
                group_id,
                limit,
            )
        return [
            AuditEvent(
                group_id=r["group_id"],
                action=r["action"],
                previous_status=LicenseStatus(r["previous_status"]) if r["previous_status"] else None,
                new_status=LicenseStatus(r["new_status"]),
                occurred_at=r["occurred_at"],
                actor_telegram_id=r["actor_telegram_id"],
                expires_at=r["expires_at"],
                reason=r["reason"],
            )
            for r in reversed(rows)
        ]
