"""License domain model for per-group activation (pure, no I/O).

Authority rules live in `guardian.auth`; persistence contracts in `store.py`.
Statuses are explicit strings (never a single boolean): see LicenseStatus.
"""
from __future__ import annotations

import enum
from dataclasses import dataclass
from datetime import datetime

from ..time_utils import ensure_utc


class LicenseStatus(str, enum.Enum):
    PENDING = "pending"                    # registered, awaiting primary-owner approval
    ACTIVE_PERMANENT = "active_permanent"  # expires_at must be NULL
    ACTIVE_TEMPORARY = "active_temporary"  # expires_at must be set
    EXPIRED = "expired"
    STOPPED = "stopped"
    REJECTED = "rejected"
    BANNED = "banned"


ACTIVE_STATUSES = frozenset({LicenseStatus.ACTIVE_PERMANENT, LicenseStatus.ACTIVE_TEMPORARY})


class DenyReason(str, enum.Enum):
    NONE = "none"
    NOT_REGISTERED = "not_registered"
    PENDING = "pending"
    EXPIRED = "expired"
    STOPPED = "stopped"
    REJECTED = "rejected"
    BANNED = "banned"
    STORE_UNAVAILABLE = "store_unavailable"


_STATUS_TO_REASON = {
    LicenseStatus.PENDING: DenyReason.PENDING,
    LicenseStatus.EXPIRED: DenyReason.EXPIRED,
    LicenseStatus.STOPPED: DenyReason.STOPPED,
    LicenseStatus.REJECTED: DenyReason.REJECTED,
    LicenseStatus.BANNED: DenyReason.BANNED,
}


@dataclass(frozen=True, slots=True)
class GroupLicense:
    group_id: int
    title: str | None
    status: LicenseStatus
    updated_at: datetime
    activated_at: datetime | None = None
    expires_at: datetime | None = None  # NULL means permanent ONLY with ACTIVE_PERMANENT
    activated_by: int | None = None
    note: str | None = None

    def __post_init__(self) -> None:
        # Normalise to UTC (naive datetimes raise ValueError).
        object.__setattr__(self, "updated_at", ensure_utc(self.updated_at))
        if self.activated_at is not None:
            object.__setattr__(self, "activated_at", ensure_utc(self.activated_at))
        if self.expires_at is not None:
            object.__setattr__(self, "expires_at", ensure_utc(self.expires_at))
        if self.status is LicenseStatus.ACTIVE_PERMANENT and self.expires_at is not None:
            raise ValueError("active_permanent requires expires_at to be NULL")
        if self.status is LicenseStatus.ACTIVE_TEMPORARY and self.expires_at is None:
            raise ValueError("active_temporary requires expires_at")


@dataclass(frozen=True, slots=True)
class LicenseDecision:
    allowed: bool
    status: LicenseStatus | None
    reason: DenyReason
    expired_by_time: bool = False  # status in storage is still ACTIVE_TEMPORARY but time has passed


def evaluate(license_: GroupLicense | None, now: datetime) -> LicenseDecision:
    """Decide whether protection may run. Fail closed for anything unknown.

    Boundary: a temporary license is expired when now >= expires_at.
    """
    if license_ is None:
        return LicenseDecision(False, None, DenyReason.NOT_REGISTERED)
    now = ensure_utc(now)
    status = license_.status
    if status is LicenseStatus.ACTIVE_PERMANENT:
        return LicenseDecision(True, status, DenyReason.NONE)
    if status is LicenseStatus.ACTIVE_TEMPORARY:
        assert license_.expires_at is not None  # guaranteed by invariant
        if now >= license_.expires_at:
            return LicenseDecision(False, LicenseStatus.EXPIRED, DenyReason.EXPIRED, expired_by_time=True)
        return LicenseDecision(True, status, DenyReason.NONE)
    return LicenseDecision(False, status, _STATUS_TO_REASON.get(status, DenyReason.NOT_REGISTERED))


def effective_status(license_: GroupLicense, now: datetime) -> LicenseStatus:
    """The status that is true NOW: a stored ACTIVE_TEMPORARY whose time has passed is EXPIRED (the row may still say
    otherwise until something persists the expiry, e.g. after the free host slept)."""
    decision = evaluate(license_, now)
    return LicenseStatus.EXPIRED if decision.expired_by_time else license_.status


@dataclass(frozen=True, slots=True)
class AuditEvent:
    """Append-only audit record contract (no message content, no secrets)."""

    group_id: int
    action: str                      # e.g. register_pending, auto_expire (more in later phases)
    previous_status: LicenseStatus | None
    new_status: LicenseStatus
    occurred_at: datetime            # UTC
    actor_telegram_id: int | None = None  # None = system
    expires_at: datetime | None = None
    reason: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "occurred_at", ensure_utc(self.occurred_at))
        if self.expires_at is not None:
            object.__setattr__(self, "expires_at", ensure_utc(self.expires_at))
