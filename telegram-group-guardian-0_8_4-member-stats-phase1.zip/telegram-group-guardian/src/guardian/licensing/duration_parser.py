"""Arabic/English duration parser for license activation (`تفعيل البوت 3 أيام`).

Pure and side-effect free. The text after the command is turned into an exact `timedelta`;
the caller (Part 5.2 commands, Part 5.4 owner panel) adds it to the execution time.

Owner decisions (31 Oct 2026):
- A **month is 30 days** for activation durations (not a calendar month), so
  `31 Jan + شهر = 2 Mar` (2026) and the result never depends on the month's length.
- Times are stored in UTC and shown in Mecca time (`Asia/Riyadh`, UTC+3, no DST) through
  `time_utils.format_display(value, config.display_timezone)`.

Accepted (after normalising Arabic-Indic/Persian digits, hamza forms, taa marbuta,
tatweel and diacritics; an optional leading `لمدة`/`مدة`/`for` is ignored):
    ساعة | يوم | أسبوع | شهر                        -> 1
    ساعتين | يومين | أسبوعين | شهرين (و`ساعتان`..)    -> 2
    <n> ساعة/ساعات | يوم/أيام | أسبوع/أسابيع | شهر/أشهر/شهور
    <n> hour(s) | day(s) | week(s) | month(s)
    ثلاث..عشر (مؤنث/مذكر) + وحدة، و`<وحدة> واحد`    -> 3..10 / 1

Rejected with `DurationParseError.reason` (never guessed): empty, missing_unit, unknown_unit,
invalid_number, zero, negative, fractional, ambiguous (plural alone, `2 ساعتين`),
too_many_tokens, too_large (> `MAX_DURATION`).
"""
from __future__ import annotations

import enum
import re
import unicodedata
from dataclasses import dataclass
from datetime import datetime, timedelta

from ..errors import InvalidInput
from ..time_utils import ensure_utc

# Must stay equal to `LicenseAdminService`'s horizon (asserted by a test): anything longer
# than ~5 years must be an explicit permanent activation.
MAX_DURATION = timedelta(days=1830)
_MAX_DIGITS = 7  # longer digit strings are "too large" without ever building a huge int


class DurationUnit(str, enum.Enum):
    HOUR = "hour"
    DAY = "day"
    WEEK = "week"
    MONTH = "month"


UNIT_DELTA: dict[DurationUnit, timedelta] = {
    DurationUnit.HOUR: timedelta(hours=1),
    DurationUnit.DAY: timedelta(days=1),
    DurationUnit.WEEK: timedelta(days=7),
    DurationUnit.MONTH: timedelta(days=30),  # owner decision: a month is 30 days
}


class DurationParseError(InvalidInput):
    """Rejected duration text. `reason` is a stable code the command layer maps to i18n."""

    def __init__(self, reason: str):
        super().__init__(f"invalid duration: {reason}")
        self.reason = reason


@dataclass(frozen=True, slots=True)
class ParsedDuration:
    amount: int
    unit: DurationUnit

    @property
    def delta(self) -> timedelta:
        return UNIT_DELTA[self.unit] * self.amount


# ---------------------------------------------------------------- vocabulary (normalised)
_S, _D, _P = "singular", "dual", "plural"
_UNITS: dict[str, tuple[DurationUnit, str]] = {}


def _register(unit: DurationUnit, singular: list[str], dual: list[str], plural: list[str]) -> None:
    for kind, words in ((_S, singular), (_D, dual), (_P, plural)):
        for w in words:
            _UNITS[w] = (unit, kind)


_register(DurationUnit.HOUR, ["ساعه", "hour"], ["ساعتين", "ساعتان"], ["ساعات", "hours"])
_register(DurationUnit.DAY, ["يوم", "day"], ["يومين", "يومان"], ["ايام", "days"])
_register(DurationUnit.WEEK, ["اسبوع", "week"], ["اسبوعين", "اسبوعان"], ["اسابيع", "weeks"])
_register(DurationUnit.MONTH, ["شهر", "month"], ["شهرين", "شهران"], ["اشهر", "شهور", "months"])

_NUMBER_WORDS = {
    "ثلاث": 3, "ثلاثه": 3, "اربع": 4, "اربعه": 4, "خمس": 5, "خمسه": 5, "ست": 6, "سته": 6,
    "سبع": 7, "سبعه": 7, "ثمان": 8, "ثماني": 8, "ثمانيه": 8, "تسع": 9, "تسعه": 9,
    "عشر": 10, "عشره": 10,
}
_ONE_WORDS = frozenset({"واحد", "واحده"})
_ZERO_WORDS = frozenset({"صفر", "zero"})
_FRACTION_WORDS = frozenset({"نصف", "نص", "ربع", "half"})
_PREFIXES = frozenset({"لمده", "مده", "for"})
_NEGATIVE_SIGNS = "-\u2212\u2013\u2014"  # hyphen-minus, minus sign, en dash, em dash

_DIGITS = {ord(c): str(i) for i, c in enumerate("٠١٢٣٤٥٦٧٨٩")}
_DIGITS.update({ord(c): str(i) for i, c in enumerate("۰۱۲۳۴۵۶۷۸۹")})
_LETTER_DIGIT = re.compile(r"(?<=\d)(?=[^\W\d_])|(?<=[^\W\d_])(?=\d)")
_FRACTION = re.compile(r"^\d+[.,٫]\d+$")


def _normalise(text: str) -> str:
    text = unicodedata.normalize("NFKC", text).translate(_DIGITS)
    text = "".join(ch for ch in text if unicodedata.category(ch) != "Mn")  # diacritics
    text = text.replace("\u0640", "")  # tatweel
    for src in "أإآٱ":
        text = text.replace(src, "ا")
    text = text.replace("ى", "ي").replace("ة", "ه").lower()
    text = _LETTER_DIGIT.sub(" ", text)
    return " ".join(text.split())


normalise_text = _normalise  # shared with the command parser (same Arabic folding)


def _parse_number(token: str) -> int:
    """Return a positive int for a numeric token/word or raise `DurationParseError`."""
    if token and token[0] in _NEGATIVE_SIGNS:
        raise DurationParseError("negative")
    if token in _ZERO_WORDS:
        raise DurationParseError("zero")
    if token in _FRACTION_WORDS or _FRACTION.match(token):
        raise DurationParseError("fractional")
    if token in _NUMBER_WORDS:
        return _NUMBER_WORDS[token]
    if not (token.isascii() and token.isdigit()):
        raise DurationParseError("invalid_number")
    if len(token.lstrip("0")) > _MAX_DIGITS:
        raise DurationParseError("too_large")
    value = int(token)
    if value == 0:
        raise DurationParseError("zero")
    return value


def parse_duration(text: str) -> ParsedDuration:
    """Parse the text that follows the activation command. Raises `DurationParseError`."""
    if not isinstance(text, str):
        raise DurationParseError("empty")
    tokens = _normalise(text).split()
    while tokens and tokens[0] in _PREFIXES:
        tokens.pop(0)
    if not tokens:
        raise DurationParseError("empty")
    if len(tokens) > 2:
        raise DurationParseError("too_many_tokens")

    if len(tokens) == 1:
        (tok,) = tokens
        if tok in _UNITS:
            unit, kind = _UNITS[tok]
            if kind == _S:
                return _checked(1, unit)
            if kind == _D:
                return _checked(2, unit)
            raise DurationParseError("ambiguous")  # "ايام" alone: how many days?
        if tok in _FRACTION_WORDS:
            raise DurationParseError("fractional")
        if tok and tok[0] in _NEGATIVE_SIGNS or tok in _ZERO_WORDS or tok in _NUMBER_WORDS or tok.isdigit():
            _parse_number(tok)  # raises negative/zero/too_large; a valid number lacks its unit
            raise DurationParseError("missing_unit")
        raise DurationParseError("unknown_unit")

    first, second = tokens
    if second in _ONE_WORDS:  # "يوم واحد"
        if first in _UNITS:
            unit, kind = _UNITS[first]
            if kind == _S:
                return _checked(1, unit)
            raise DurationParseError("ambiguous")
        raise DurationParseError("unknown_unit")
    amount = _parse_number(first)
    if second not in _UNITS:
        raise DurationParseError("unknown_unit")
    unit, kind = _UNITS[second]
    if kind == _D:
        raise DurationParseError("ambiguous")  # "2 ساعتين"
    return _checked(amount, unit)


def _checked(amount: int, unit: DurationUnit) -> ParsedDuration:
    parsed = ParsedDuration(amount, unit)
    if parsed.delta > MAX_DURATION:
        raise DurationParseError("too_large")
    return parsed


def compute_expiry(now: datetime, parsed: ParsedDuration) -> datetime:
    """Absolute UTC expiry = `now` (the moment the owner acts) + duration.

    The duration always starts at the execution/renewal time (never at an old expiry);
    only the primary owner can renew, so the owner alone decides the start moment.
    `now` must be timezone-aware (naive raises `ValueError`, like `ensure_utc`).
    """
    return ensure_utc(now) + parsed.delta


_AR_NAMES = {
    DurationUnit.HOUR: ("ساعة", "ساعتين", "ساعات"),
    DurationUnit.DAY: ("يوم", "يومين", "أيام"),
    DurationUnit.WEEK: ("أسبوع", "أسبوعين", "أسابيع"),
    DurationUnit.MONTH: ("شهر", "شهرين", "أشهر"),
}


def format_duration(parsed: ParsedDuration, lang: str = "ar") -> str:
    """Human text for confirmations: `3 أيام`, `يومين`, `15 يوم`, `1 hour`, `30 days`."""
    n, unit = parsed.amount, parsed.unit
    if lang == "en":
        return f"{n} {unit.value}" + ("" if n == 1 else "s")
    one, two, many = _AR_NAMES[unit]
    if n == 1:
        return one
    if n == 2:
        return two
    return f"{n} {many}" if 3 <= n <= 10 else f"{n} {one}"
