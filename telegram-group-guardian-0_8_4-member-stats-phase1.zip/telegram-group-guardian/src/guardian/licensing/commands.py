"""Group license commands: `تفعيل البوت [مدة]`, `إيقاف البوت`, `حالة البوت` (+ `/activate`, `/deactivate`).

Framework independent (no aiogram): the message adapter is `bot/license_handler.py`. Decisions:

* **Activate / stop = primary owner only** (`Permission.CHANGE_LICENSE`, i.e. the exact `OWNER_TELEGRAM_ID` of the real
  sender; the command's chat must be the target group). Group owners/admins, delegates and the backup owner can never
  change a license. A refused group admin gets one short "owner only" reply; an ordinary member or an anonymous
  admin gets silence (nothing to learn, nothing to spam). Every denial is written to the security audit by
  `PermissionService`.
* `تفعيل البوت` without a duration = permanent (`expires_at = NULL`); with a duration the expiry is computed from the
  moment the owner runs the command (a repeat on an active group is a renewal that also starts from now).
  Months are 30 days (owner decision); times are shown in `display_timezone` (Mecca time by default).
* **Status (`حالة البوت`) = group admins/delegates (VIEW_GROUP_STATUS) and the owner only.** The public `/status` of
  `bot/routers/basic.py` is unchanged. Status is read-only and works while the license is expired or stopped.
* Redelivered Telegram updates never apply a command twice (`claims`, keyed by chat + message id).
* Anything uncertain (store down, lookup failed, unexpected error) refuses safely with a generic message.
"""
from __future__ import annotations

import enum
import logging
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Callable

from ..errors import (ConcurrentModification, GroupNotRegistered, InvalidInput, InvalidTransition, PermissionDenied)
from ..i18n import license_label, t
from ..idempotency import operation_key
from ..permissions import Permission
from ..time_utils import format_display, utcnow
from .admin import Outcome, RENEW
from .duration_parser import (DurationParseError, DurationUnit, ParsedDuration, compute_expiry, format_duration,
                              normalise_text, parse_duration)
from .models import DenyReason, LicenseStatus

log = logging.getLogger(__name__)
MAX_COMMAND_LEN = 200  # longer texts are conversation, never a command


class LicenseCommand(str, enum.Enum):
    ACTIVATE = "activate"
    STOP = "stop"
    STATUS = "status"


@dataclass(frozen=True, slots=True)
class ParsedLicenseCommand:
    command: LicenseCommand
    arg: str = ""        # text after the command (only ACTIVATE accepts one)
    arabic: bool = False


_ARABIC = {
    normalise_text("تفعيل البوت"): LicenseCommand.ACTIVATE,
    normalise_text("إيقاف البوت"): LicenseCommand.STOP,
    normalise_text("حالة البوت"): LicenseCommand.STATUS,
}
_SLASH = {"activate": LicenseCommand.ACTIVATE, "deactivate": LicenseCommand.STOP}


def parse_license_command(text: object, bot_username: str | None = None) -> ParsedLicenseCommand | None:
    """The license command in a message text, or None. STOP/STATUS with extra words are NOT commands."""
    if not isinstance(text, str):
        return None
    stripped = text.strip()
    if not stripped or len(stripped) > MAX_COMMAND_LEN:
        return None
    if stripped.startswith("/"):
        parts = stripped.split(None, 1)
        name, at, target = parts[0][1:].partition("@")
        cmd = _SLASH.get(name.lower())
        if cmd is None:
            return None
        if at and (not bot_username or target.lower() != bot_username.lower()):
            return None  # addressed to another bot (or we do not know our own name)
        arg = parts[1].strip() if len(parts) > 1 else ""
        if cmd is not LicenseCommand.ACTIVATE and arg:
            return None
        return ParsedLicenseCommand(cmd, arg, arabic=False)
    folded = normalise_text(stripped)
    for phrase, cmd in _ARABIC.items():
        if folded == phrase:
            return ParsedLicenseCommand(cmd, "", arabic=True)
        if folded.startswith(phrase + " "):
            arg = folded[len(phrase) + 1:].strip()
            if cmd is not LicenseCommand.ACTIVATE:
                return None
            return ParsedLicenseCommand(cmd, arg, arabic=True)
    return None


class ResultKind(str, enum.Enum):
    CHANGED = "changed"
    NO_CHANGE = "no_change"
    STATUS = "status"
    OWNER_ONLY = "owner_only"      # an admin was refused (replied)
    IGNORED = "ignored"            # silent: not allowed / duplicate / not applicable
    INVALID = "invalid"            # bad duration text
    REFUSED = "refused"            # wrong state / not registered / retry
    ERROR = "error"                # fail-safe generic failure


@dataclass(frozen=True, slots=True)
class LicenseCommandResult:
    kind: ResultKind
    text: str = ""  # Telegram-HTML reply; empty = send nothing


def _remaining(delta: timedelta, lang: str) -> str:
    days = delta.days
    if days >= 1:
        return format_duration(ParsedDuration(days, DurationUnit.DAY), lang)
    hours = int(delta.total_seconds() // 3600)
    if hours >= 1:
        return format_duration(ParsedDuration(hours, DurationUnit.HOUR), lang)
    return t("lic_cmd_less_than_hour", lang)


class LicenseCommandService:
    def __init__(self, *, license_admin: Any, license_service: Any, permissions: Any, claims: Any,
                 display_timezone: str = "Asia/Riyadh", language: str = "ar",
                 clock: Callable[[], datetime] = utcnow, hub: Any = None):
        self._admin, self._licenses, self._perm, self._claims = license_admin, license_service, permissions, claims
        self._hub = hub  # owner_hub.reports.HubReporter | None: a notice after a change was applied
        self._tz, self._default_lang, self._clock = display_timezone, language, clock

    async def handle(self, parsed: ParsedLicenseCommand, *, chat_id: int, actor_id: object, message_id: int,
                     language: str | None = None) -> LicenseCommandResult:
        """Never raises: any failure becomes a safe result (and nothing is changed)."""
        lang = language or self._default_lang
        try:
            if parsed.command is LicenseCommand.STATUS:
                return await self._status(chat_id, actor_id, lang)
            return await self._change(parsed, chat_id, actor_id, message_id, lang)
        except Exception:
            log.error("license command failed", extra={"group_id": chat_id}, exc_info=True)
            return LicenseCommandResult(ResultKind.ERROR, t("action_failed_safe", lang))

    # ------------------------------------------------------------------ activate / stop
    async def _change(self, parsed, chat_id, actor_id, message_id, lang) -> LicenseCommandResult:
        decision = await self._perm.check(actor_id, chat_id, Permission.CHANGE_LICENSE, context_chat_id=chat_id)
        if not decision.allowed:
            return await self._refuse(actor_id, chat_id, lang)

        duration: ParsedDuration | None = None
        if parsed.command is LicenseCommand.ACTIVATE and parsed.arg:
            try:
                duration = parse_duration(parsed.arg)
            except DurationParseError as exc:
                reason = t(f"lic_dur_err_{exc.reason}", lang)
                return LicenseCommandResult(ResultKind.INVALID, t("lic_cmd_dur_error", lang, reason=reason))

        key = operation_key("lic", parsed.command.value, chat_id, message_id)
        if not await self._claims.claim(key):
            return LicenseCommandResult(ResultKind.IGNORED)  # redelivered update: already handled

        try:
            if parsed.command is LicenseCommand.STOP:
                result = await self._admin.stop(actor_id, chat_id, context_chat_id=chat_id)
            elif duration is None:
                result = await self._admin.activate_permanent(actor_id, chat_id, context_chat_id=chat_id)
            else:
                expires_at = compute_expiry(self._clock(), duration)
                result = await self._admin.activate_temporary(actor_id, chat_id, expires_at, context_chat_id=chat_id)
        except PermissionDenied:
            return await self._refuse(actor_id, chat_id, lang)
        except GroupNotRegistered:
            return LicenseCommandResult(ResultKind.REFUSED, t("lic_cmd_not_registered", lang))
        except InvalidTransition:
            return await self._bad_state(chat_id, lang)
        except ConcurrentModification:
            return LicenseCommandResult(ResultKind.REFUSED, t("lic_cmd_retry", lang))
        except InvalidInput:
            return LicenseCommandResult(ResultKind.INVALID, t("lic_dur_err_too_large", lang))

        lic = result.license
        if result.outcome is not Outcome.NO_CHANGE and self._hub is not None:
            try:                                           # 5.9: best effort, never turns an applied change into an error
                self._hub.license_changed(lic, result.action, "command")
            except Exception as exc:
                log.warning("owner hub notice failed (%s)", type(exc).__name__)
        if result.outcome is Outcome.NO_CHANGE:
            return LicenseCommandResult(ResultKind.NO_CHANGE, t("lic_cmd_no_change", lang, status=license_label(lic.status, lang)))
        if parsed.command is LicenseCommand.STOP:
            return LicenseCommandResult(ResultKind.CHANGED, t("lic_cmd_stopped", lang))
        if duration is None:
            return LicenseCommandResult(ResultKind.CHANGED, t("lic_cmd_activated_perm", lang))
        key_text = "lic_cmd_renewed" if result.action == RENEW else "lic_cmd_activated_temp"
        text = t(key_text, lang, duration=format_duration(duration, lang), when=format_display(lic.expires_at, self._tz))
        return LicenseCommandResult(ResultKind.CHANGED, text)

    async def _refuse(self, actor_id, chat_id, lang) -> LicenseCommandResult:
        """Only someone who may at least look at this group's status learns that the command is owner-only."""
        seen = await self._perm.check(actor_id, chat_id, Permission.VIEW_GROUP_STATUS, context_chat_id=chat_id,
                                      audit_denial=False)
        if seen.allowed:
            return LicenseCommandResult(ResultKind.OWNER_ONLY, t("lic_cmd_owner_only", lang))
        return LicenseCommandResult(ResultKind.IGNORED)

    async def _bad_state(self, chat_id, lang) -> LicenseCommandResult:
        decision, lic = await self._licenses.status_report(chat_id)
        status = (decision.status or (lic.status if lic else None))
        if status in (LicenseStatus.REJECTED, LicenseStatus.BANNED):
            return LicenseCommandResult(ResultKind.REFUSED, t("lic_cmd_lift_first", lang, status=license_label(status, lang)))
        if status is None:
            return LicenseCommandResult(ResultKind.REFUSED, t("lic_cmd_not_registered", lang))
        return LicenseCommandResult(ResultKind.REFUSED, t("lic_cmd_bad_state", lang, status=license_label(status, lang)))

    # ------------------------------------------------------------------ status
    async def _status(self, chat_id, actor_id, lang) -> LicenseCommandResult:
        decision = await self._perm.check(actor_id, chat_id, Permission.VIEW_GROUP_STATUS, context_chat_id=chat_id)
        if not decision.allowed:
            return LicenseCommandResult(ResultKind.IGNORED)
        now = self._clock()
        verdict, lic = await self._licenses.status_report(chat_id, now)
        if verdict.reason is DenyReason.STORE_UNAVAILABLE:
            return LicenseCommandResult(ResultKind.STATUS, t("status_group_store_error", lang))
        if lic is None:
            return LicenseCommandResult(ResultKind.STATUS, t("status_group_unregistered", lang))
        status = verdict.status or lic.status
        lines: list[str] = []
        if verdict.allowed and status is LicenseStatus.ACTIVE_PERMANENT:
            lines.append(t("detail_permanent", lang))
        elif verdict.allowed and lic.expires_at is not None:
            lines.append(t("detail_expires", lang, when=format_display(lic.expires_at, self._tz)))
            lines.append(t("lic_cmd_remaining", lang, remaining=_remaining(lic.expires_at - now, lang)))
        elif lic.expires_at is not None and status is LicenseStatus.EXPIRED:
            lines.append(t("detail_expires", lang, when=format_display(lic.expires_at, self._tz)))
        else:
            lines.append(t("detail_protection_off", lang))
        if lic.activated_at is not None:
            lines.append(t("lic_cmd_activated_at", lang, when=format_display(lic.activated_at, self._tz)))
        protection = t("lic_cmd_protection_on" if verdict.allowed else "lic_cmd_protection_off", lang)
        text = t("lic_cmd_status", lang, status=license_label(status, lang), details="\n".join(lines), protection=protection)
        return LicenseCommandResult(ResultKind.STATUS, text)
