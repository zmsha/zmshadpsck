"""The content guard (part 9.2): what happens when a message / a new member trips the content filter.

Decision table (all rules apply only to a sender the gate says `can_sanction`; the owner, delegates and Telegram admins of the
group are therefore exempt from every rule, and so are the ids listed in the group's `cf_exempt`):

  banned emoji in the message OR in the sender's name/username ..... delete + BAN at once (no ladder, no review)
  a letter of a blocked writing system in the message text ......... delete + BAN at once (names / usernames are NOT scanned)
  clear text violation (explicit word/phrase/pattern, strong insult,
  the group's own word, or Gemini BLOCK with confidence >= 0.75) ... ladder: 1st warning (message deleted), 2nd mute 1 h,
                                                                      3rd mute 24 h, 4th and later BAN
  suspicious text (hint / dating phrase) -> Gemini:
      SAFE (confidence >= 0.6) ..................................... nothing
      BLOCK (>= 0.75) .............................................. ladder, as above
      WARNING / low confidence / Gemini unavailable (no key, quota,
      network, malformed answer) .................................. NEVER assumed safe: delete + mute 24 h + a review for the
                                                                      admins (confirm + ban / reject + unmute)

New members (`screen_member`): banned emoji in name/username -> ban; explicit name -> ban; suspicious name -> Gemini as above;
profile photo (Telegram Bot API + Gemini Vision, only when Gemini is configured): explicit -> ban, doubtful -> 24 h mute + review.
A missing photo or a failed fetch/review NEVER punishes anyone.

Safety rules: one claim per message (a redelivery never acts twice); bot rights are checked first (unknown/missing => no
action, owner told, throttled); `dry_run` audits only; every Telegram failure is classified by the actions adapter and never
raised here; no message text, name or photo is stored (the review row keeps ids and a closed-vocabulary reason only).
"""
from __future__ import annotations

import html
import logging
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Protocol, Sequence

from ..audit import SecurityAudit, make_event, record_safely
from ..groups.store import SettingsStore
from ..i18n import t
from ..idempotency import IdempotencyStore, operation_key
from ..moderation.duration import format_duration
from ..permissions import Permission
from ..protection.settings import ProtectionSettings
from ..protection_gate import ProtectionContext
from ..telegram_rights import BotCapability, ChatInfoProvider, check_bot_capabilities
from ..time_utils import utcnow
from . import gemini
from .classifier import BLOCK, CAT_EXPLICIT, CAT_PATTERN, SUSPECT, ContentClassifier, default_classifier
from .emojis import find_banned_emoji
from .ladder import BAN, LADDER_WINDOW_SECONDS, MUTE, step_for
from .lexicon import Lexicon
from .scripts import find_blocked_script
from .store import CONFIRMED, REJECTED, ContentLedger, ReviewStore

log = logging.getLogger(__name__)

CONTENT_ACTION = "content_filter_action"
CONTENT_DRY_RUN = "content_filter_dry_run"
CONTENT_BLOCKED = "content_filter_blocked_bot_rights"
CONTENT_AI_FAILED = "content_filter_ai_failed"
CONTENT_PHOTO_UNCHECKED = "content_filter_photo_unchecked"
CONTENT_REVIEW_OPENED = "content_review_opened"
CONTENT_REVIEW_DM_FAILED = "content_review_dm_failed"
CONTENT_REVIEW_UNREACHABLE = "content_review_unreachable"
CONTENT_REVIEW_CONFIRMED = "content_review_confirmed"
CONTENT_REVIEW_REJECTED = "content_review_rejected"
CONTENT_REVIEW_ACTION_FAILED = "content_review_action_failed"

REVIEW_MUTE_SECONDS = 86400
_OWNER_NOTICE_EVERY = 600.0
CALLBACK_PREFIX = "cf"
SRC_MESSAGE, SRC_NAME, SRC_PHOTO = "message", "name", "photo"


# ------------------------------------------------------------------------------------------------ callbacks
def encode_callback(group_id: int, review_id: int, choice: str) -> str:
    return f"{CALLBACK_PREFIX}:{group_id}:{review_id}:{choice}"  # at most 3+16+1+10+2 characters (limit 64 bytes)


def parse_callback(data: object) -> tuple[int, int, str] | None:
    """`cf:<group id>:<review id>:c|r` -> (group, id, 'c'|'r'); anything else None. Both numbers are only a LOOKUP key (every
    statement filters by both): the member, the right of the presser and the decision state come from the database / Telegram,
    never from this string, so a forged string can at most hit "review not found"."""
    if not isinstance(data, str) or len(data) > 48:
        return None
    parts = data.split(":")
    if len(parts) != 4 or parts[0] != CALLBACK_PREFIX or parts[3] not in ("c", "r"):
        return None
    group, rid = parts[1], parts[2]
    if not (group.startswith("-") and group[1:].isdigit() and rid.isdigit()):
        return None
    group_id, review_id = int(group), int(rid)
    return (group_id, review_id, parts[3]) if -(2**62) < group_id < 0 and 0 < review_id < 2**62 else None


# ------------------------------------------------------------------------------------------------ views
@dataclass(frozen=True, slots=True)
class ContentView:
    chat_id: int
    user_id: int
    message_id: int
    text: str | None
    first_name: str | None = None
    last_name: str | None = None
    username: str | None = None
    chat_title: str | None = None
    is_edit: bool = False
    service: bool = False

    @property
    def display_name(self) -> str:
        return " ".join(p for p in (self.first_name, self.last_name) if p).strip()


@dataclass(frozen=True, slots=True)
class NewMember:
    user_id: int
    first_name: str | None = None
    last_name: str | None = None
    username: str | None = None
    is_bot: bool = False

    @property
    def display_name(self) -> str:
        return " ".join(p for p in (self.first_name, self.last_name) if p).strip()


class AIReviewer(Protocol):
    @property
    def configured(self) -> bool: ...

    async def review_text(self, text: str) -> gemini.AIResult: ...

    async def review_image(self, image: bytes, mime: str = "image/jpeg") -> gemini.AIResult: ...


class GuardActions(Protocol):
    async def delete_message(self, chat_id: int, message_id: int) -> Any: ...

    async def mute_member(self, chat_id: int, user_id: int, until: datetime | None) -> Any: ...

    async def unmute_member(self, chat_id: int, user_id: int) -> Any: ...

    async def ban_member(self, chat_id: int, user_id: int, until: datetime | None) -> Any: ...

    async def send_message(self, chat_id: int, text: str, buttons: Any = None) -> Any: ...


@dataclass(frozen=True, slots=True)
class Finding:
    kind: str                 # ban | ladder | suspect
    source: str               # message | name | photo
    category: str             # emoji | script | explicit | insult | custom | hint | pattern | ai | photo
    reason: str = ""
    confidence: float = 0.0


def _mention(user_id: int, name: str) -> str:
    label = html.escape((name or "").strip()[:40] or "—", quote=False)
    return f'<a href="tg://user?id={user_id}">{label}</a>'


class ContentGuard:
    def __init__(self, settings_store: SettingsStore, actions: GuardActions, chat_info: ChatInfoProvider,
                 claims: IdempotencyStore, audit: SecurityAudit | None, ledger: ContentLedger, reviews: ReviewStore,
                 *, ai: AIReviewer | None = None, photos: Any = None, permissions: Any = None, notifier: Any = None,
                 owner_ids: Sequence[int] = (), classifier: ContentClassifier | None = None, lexicon: Lexicon | None = None,
                 counters: Any = None, language: str = "ar", clock=utcnow, member_stats: Any = None):
        self._settings_store = settings_store
        self._actions = actions
        self._chat_info = chat_info
        self._claims = claims
        self._audit = audit
        self._ledger = ledger
        self._reviews = reviews
        self._ai = ai
        self._photos = photos          # object with `async fetch_profile_photo(user_id) -> bytes | None` (usually `actions`)
        self._permissions = permissions
        self._notifier = notifier
        self._owner_ids = tuple(i for i in owner_ids if isinstance(i, int) and not isinstance(i, bool) and i > 0)
        self._classifier = classifier or default_classifier()
        self._lexicon = lexicon or self._classifier.lexicon
        self._counters = counters
        self._member_stats = member_stats  # MemberStatsRecorder (optional): the sender's violation / deletion tick, once per message
        self._language = language
        self._clock = clock
        self._owner_notified: dict[int, float] = {}

    # ------------------------------------------------------------------ settings / helpers
    async def _load(self, group_id: int) -> ProtectionSettings:
        try:
            row = await self._settings_store.get(group_id)
        except Exception:
            log.warning("content filter: could not load settings; using defaults", extra={"group_id": group_id})
            return ProtectionSettings()
        return ProtectionSettings.from_raw(row.settings if row is not None else None)

    @staticmethod
    def _active(cfg: ProtectionSettings) -> bool:
        return cfg.adult_enabled or cfg.cf_emoji or cfg.cf_scripts

    def _ai_ready(self, cfg: ProtectionSettings) -> bool:
        return bool(cfg.cf_ai and self._ai is not None and self._ai.configured)

    async def _audit_event(self, kind: str, *, actor: int | None, group_id: int | None, detail: str | None, now: datetime,
                           target: object = None) -> None:
        await record_safely(self._audit, make_event(kind, actor=actor, group_id=group_id, detail=detail, now=now,
                                                    target=target))

    async def _bump(self, group_id: int, now: datetime) -> None:
        if self._counters is None:
            return
        try:
            await self._counters.bump(group_id, "violation", now)
        except Exception:  # statistics only
            log.warning("violation counter failed", extra={"group_id": group_id})

    async def _count_member(self, group_id: int, user_id: int, message_id: int, deleted: bool, now: datetime) -> None:
        if self._member_stats is None:
            return
        try:
            await self._member_stats.message_acted_on(group_id, user_id, message_id, deleted, now)
        except Exception:  # statistics only
            log.warning("member stats tick failed", extra={"group_id": group_id})

    async def _notice(self, group_id: int, text: str) -> None:
        try:
            await self._actions.send_message(group_id, text)
        except Exception:
            log.warning("content filter notice failed", extra={"group_id": group_id})

    async def _owner_notice(self, group_id: int, now: datetime) -> None:
        if self._notifier is None:
            return
        last = self._owner_notified.get(group_id)
        if last is not None and now.timestamp() - last < _OWNER_NOTICE_EVERY:
            return
        self._owner_notified[group_id] = now.timestamp()
        try:
            await self._notifier.notify_owner(t("owner_bot_rights_missing", self._language, group_id=str(group_id)))
        except Exception:
            log.warning("owner notification failed")

    # ------------------------------------------------------------------ local detection
    def _local_finding(self, cfg: ProtectionSettings, view: ContentView) -> Finding | None:
        names = f"{view.display_name} {view.username or ''}".strip()
        lex = self._lexicon
        if cfg.cf_emoji and (find_banned_emoji(view.text, lex.banned_emojis) or find_banned_emoji(names, lex.banned_emojis)):
            return Finding("ban", SRC_MESSAGE, "emoji")
        if cfg.cf_scripts and find_blocked_script(view.text, lex.blocked_scripts, lex.allowed_script_chars):
            return Finding("ban", SRC_MESSAGE, "script")
        if cfg.adult_enabled and view.text:
            verdict = self._classifier.classify(view.text, cfg.adult_custom_words)
            if verdict.level == BLOCK:
                return Finding("ladder", SRC_MESSAGE, verdict.category or CAT_EXPLICIT)
            if verdict.level == SUSPECT:
                return Finding("suspect", SRC_MESSAGE, verdict.category or "hint")
        return None

    # ------------------------------------------------------------------ messages
    async def handle_message(self, ctx: ProtectionContext, view: ContentView, now: datetime | None = None) -> bool:
        """True when the offending message was dealt with (deleted): later handlers must not process it."""
        if view.service or not ctx.can_sanction or ctx.chat_id != view.chat_id or ctx.sender_id != view.user_id:
            return False
        now = now or self._clock()
        try:
            cfg = await self._load(view.chat_id)
            if not self._active(cfg) or view.user_id in cfg.cf_exempt:
                return False
            finding = self._local_finding(cfg, view)
            if finding is None:
                return False
            return await self._apply(cfg, view, finding, now)
        except Exception:
            log.error("content guard failed; no action", extra={"group_id": view.chat_id}, exc_info=True)
            return False

    async def _apply(self, cfg: ProtectionSettings, view: ContentView, finding: Finding, now: datetime) -> bool:
        g, u = view.chat_id, view.user_id
        if cfg.dry_run:
            await self._audit_event(CONTENT_DRY_RUN, actor=u, group_id=g, detail=f"{finding.kind}:{finding.category}", now=now)
            return False
        try:
            first = await self._claims.claim(operation_key("content", g, u, view.message_id), now)
        except Exception:
            log.warning("content claim unavailable; not acting", extra={"group_id": g})
            return False
        if not first:
            return True  # a redelivery of a message already handled
        cap = await check_bot_capabilities(self._chat_info, g, BotCapability.DELETE_MESSAGES, BotCapability.RESTRICT_MEMBERS)
        if cap.lookup_failed:
            await self._audit_event(CONTENT_BLOCKED, actor=u, group_id=g, detail="rights_unknown", now=now)
            return False
        can_delete = BotCapability.DELETE_MESSAGES not in cap.missing
        can_restrict = BotCapability.RESTRICT_MEMBERS not in cap.missing
        if not can_delete and not can_restrict:
            await self._audit_event(CONTENT_BLOCKED, actor=u, group_id=g, detail="rights_missing", now=now)
            await self._owner_notice(g, now)
            return False

        if finding.kind == "suspect":
            judged = await self._judge_text(cfg, view, finding, now)
            if judged is None:
                return False  # Gemini said SAFE
            finding = judged
        deleted = (await self._actions.delete_message(g, view.message_id)).ok if can_delete else False
        key = operation_key("content", g, u, view.message_id)
        if finding.kind == "ban":
            await self._ban(g, u, finding, can_restrict, now, key)
        elif finding.kind == "ladder":
            await self._ladder(cfg, view, finding, can_restrict, now, key)
        else:
            await self._open_review(view.chat_id, view.chat_title, u, view.display_name, finding, view.text, can_restrict, now)
        await self._bump(g, now)
        await self._count_member(g, u, view.message_id, deleted, now)
        return deleted

    async def _judge_text(self, cfg: ProtectionSettings, view: ContentView, finding: Finding, now: datetime) -> Finding | None:
        """Gemini's opinion of a suspicious text. None = safe. A failure is NEVER safe: it becomes a review."""
        if not self._ai_ready(cfg):
            return Finding("suspect", finding.source, finding.category, "ai_unavailable")
        result = await self._ai.review_text(view.text or "")  # type: ignore[union-attr]
        if not result.ok:
            await self._audit_event(CONTENT_AI_FAILED, actor=view.user_id, group_id=view.chat_id, detail=result.failure, now=now)
        outcome = gemini.decide(result)
        if outcome == "safe":
            return None
        v = result.verdict
        reason = v.reason if v else (result.failure or "ai_failed")
        if outcome == "block":
            return Finding("ladder", finding.source, "ai", reason, v.confidence if v else 0.0)
        return Finding("suspect", finding.source, finding.category, reason, v.confidence if v else 0.0)

    # ------------------------------------------------------------------ actions
    async def _ban(self, g: int, u: int, finding: Finding, can_restrict: bool, now: datetime, key: str) -> bool:
        banned = (await self._actions.ban_member(g, u, None)).ok if can_restrict else False
        await self._audit_event(CONTENT_ACTION, actor=u, group_id=g, now=now,
                                detail=f"ban:{finding.source}:{finding.category} ok={banned}")
        if banned:
            await self._record(g, u, finding, "ban", now, key)
            await self._notice(g, t("cf_notice_ban", self._language))
        return banned

    async def _record(self, g: int, u: int, finding: Finding, action: str, now: datetime, key: str | None) -> None:
        try:
            await self._ledger.record(g, u, finding.source, finding.category, action, now, key)
        except Exception:
            log.error("could not record a content violation", extra={"group_id": g}, exc_info=True)

    async def _ladder(self, cfg: ProtectionSettings, view: ContentView, finding: Finding, can_restrict: bool,
                      now: datetime, key: str) -> None:
        g, u = view.chat_id, view.user_id
        try:
            earlier = await self._ledger.count_since(g, u, now - timedelta(seconds=LADDER_WINDOW_SECONDS))
        except Exception:
            log.warning("content ledger unreadable; deleting only", extra={"group_id": g}, exc_info=True)
            await self._audit_event(CONTENT_BLOCKED, actor=u, group_id=g, detail="ledger_unreadable", now=now)
            return
        step = step_for(earlier + 1)
        name = view.display_name
        if step.action == BAN:
            await self._ban(g, u, finding, can_restrict, now, key)
            return
        if step.action == MUTE and can_restrict and step.seconds:
            if not (await self._actions.mute_member(g, u, now + timedelta(seconds=step.seconds))).ok:
                return  # Telegram refused: do not record (a failed call must not escalate the next one)
            await self._record(g, u, finding, "mute", now, key)
            await self._audit_event(CONTENT_ACTION, actor=u, group_id=g, now=now,
                                    detail=f"mute:{step.seconds}:{finding.source}:{finding.category}")
            await self._notice(g, t("cf_notice_mute", self._language, mention=_mention(u, name),
                                    duration=format_duration(step.seconds, self._language)))
            return
        await self._record(g, u, finding, "warn", now, key)  # first offense (or no restrict right): a warning
        await self._audit_event(CONTENT_ACTION, actor=u, group_id=g, now=now,
                                detail=f"warn:{finding.source}:{finding.category}")
        await self._notice(g, t("cf_notice_warn", self._language, mention=_mention(u, name)))

    # ------------------------------------------------------------------ review (WARNING) flow
    async def _open_review(self, g: int, title: str | None, u: int, name: str, finding: Finding, text: str | None,
                           can_restrict: bool, now: datetime) -> None:
        if not can_restrict:
            await self._audit_event(CONTENT_BLOCKED, actor=u, group_id=g, detail="review_needs_restrict", now=now)
            return
        until = now + timedelta(seconds=REVIEW_MUTE_SECONDS)
        if not (await self._actions.mute_member(g, u, until)).ok:
            return
        try:
            review = await self._reviews.create(g, u, finding.source, finding.category, finding.reason[:160],
                                                finding.confidence, now)
        except Exception:
            log.error("could not open a content review", extra={"group_id": g}, exc_info=True)
            await self._audit_event(CONTENT_BLOCKED, actor=u, group_id=g, detail="review_store_failed", now=now)
            return
        await self._audit_event(CONTENT_REVIEW_OPENED, actor=u, group_id=g, now=now, target=review.id,
                                detail=f"{finding.source}:{finding.category}")
        await self._notice(g, t("cf_notice_review", self._language, mention=_mention(u, name)))
        await self._notify_admins(review.id, g, title, u, name, finding, text, now)

    async def _admin_ids(self, g: int) -> list[int]:
        ids: list[int] = list(self._owner_ids)
        try:
            for admin in await self._chat_info.list_admins(g):
                if (not admin.is_bot and not admin.is_anonymous and isinstance(admin.user_id, int) and admin.user_id > 0
                        and admin.user_id not in ids):
                    ids.append(admin.user_id)
        except Exception:
            log.warning("could not list the group's admins for a review", extra={"group_id": g})
        return ids

    async def _notify_admins(self, review_id: int, g: int, title: str | None, u: int, name: str, finding: Finding,
                             text: str | None, now: datetime) -> None:
        excerpt = ""
        if finding.source == SRC_MESSAGE and text:
            excerpt = "\n\n" + t("cf_review_excerpt", self._language, text=html.escape(gemini.scrub(text, 160), quote=False))
        body = t("cf_review_dm", self._language, group=html.escape((title or str(g))[:60], quote=False),
                 member=_mention(u, name), user_id=str(u), source=t(f"cf_src_{finding.source}", self._language),
                 reason=html.escape(finding.reason[:120] or "—", quote=False)) + excerpt
        buttons = [[(t("cf_btn_confirm", self._language), encode_callback(g, review_id, "c")),
                    (t("cf_btn_reject", self._language), encode_callback(g, review_id, "r"))]]
        ok = failed = 0
        for admin_id in await self._admin_ids(g):
            sent = await self._actions.send_message(admin_id, body, buttons)
            if getattr(sent, "ok", False):
                ok += 1
                continue
            failed += 1  # typically `forbidden`: this admin never started the bot
            await self._audit_event(CONTENT_REVIEW_DM_FAILED, actor=admin_id, group_id=g, now=now, target=review_id,
                                    detail=str(getattr(sent, "error", None) or "other"))
        try:
            await self._reviews.set_delivery(g, review_id, ok, failed)
        except Exception:
            log.warning("could not store review delivery counts")
        if ok == 0:
            await self._audit_event(CONTENT_REVIEW_UNREACHABLE, actor=None, group_id=g, now=now, target=review_id,
                                    detail=f"failed={failed}")
            await self._notice(g, t("cf_notice_unreachable", self._language))

    async def decide(self, group_id: int, review_id: int, choice: str, presser_id: int,
                     now: datetime | None = None) -> tuple[str, bool]:
        """A press on a review button: -> (toast text, show_alert). The FIRST valid decision is applied; everything after it
        only reads that it was already decided. `presser_id` must be Telegram's `from_user.id`, never callback data."""
        now = now or self._clock()
        lang = self._language
        review = await self._reviews.get(group_id, review_id)
        if review is None:
            return t("cf_cb_missing", lang), True
        if self._permissions is not None:
            decision = await self._permissions.check(presser_id, review.group_id, Permission.MODERATE)
            if not decision.allowed:
                return t("cf_cb_denied", lang), True
        status = CONFIRMED if choice == "c" else REJECTED
        decided = await self._reviews.decide(group_id, review_id, status, presser_id, now)
        if decided is None:
            return t("cf_cb_done", lang), True  # someone else decided first
        g, u = decided.group_id, decided.user_id
        if status == CONFIRMED:
            ok = (await self._actions.ban_member(g, u, None)).ok
            await self._audit_event(CONTENT_REVIEW_CONFIRMED, actor=presser_id, group_id=g, now=now, target=u,
                                    detail=f"review={review_id} ok={ok}")
            if ok:
                try:
                    await self._ledger.record(g, u, decided.source, decided.category, "ban", now,
                                              operation_key("review", review_id))
                except Exception:
                    log.warning("could not record a confirmed review")
            text = t("cf_cb_confirmed", lang)
        else:
            ok = (await self._actions.unmute_member(g, u)).ok
            await self._audit_event(CONTENT_REVIEW_REJECTED, actor=presser_id, group_id=g, now=now, target=u,
                                    detail=f"review={review_id} ok={ok}")
            text = t("cf_cb_rejected", lang)
        if not ok:
            await self._audit_event(CONTENT_REVIEW_ACTION_FAILED, actor=presser_id, group_id=g, now=now, target=u,
                                    detail=f"review={review_id} choice={choice}")
            return t("cf_cb_action_failed", lang), True
        return text, False

    # ------------------------------------------------------------------ new members
    async def screen_member(self, group_id: int, member: NewMember, title: str | None = None,
                            now: datetime | None = None) -> str | None:
        """Screen one joined member. Returns 'ban' / 'review' when the member was acted on (so verification/welcome skip
        them), else None. Never raises."""
        now = now or self._clock()
        try:
            return await self._screen(group_id, member, title, now)
        except Exception:
            log.error("member screening failed; no action", extra={"group_id": group_id}, exc_info=True)
            return None

    async def _screen(self, g: int, m: NewMember, title: str | None, now: datetime) -> str | None:
        if m.is_bot or not isinstance(m.user_id, int) or m.user_id <= 0:
            return None
        cfg = await self._load(g)
        if not (cfg.cf_emoji or cfg.cf_names or cfg.cf_photos):
            return None
        if m.user_id in cfg.cf_exempt:
            return None
        if self._permissions is not None and await self._permissions.is_exempt_from_automation(m.user_id, g):
            return None
        finding = self._name_finding(cfg, m)
        if finding is None and self._ai_ready(cfg) and cfg.cf_photos and self._photos is not None:
            finding = await self._photo_finding(cfg, g, m, now)
        if finding is None:
            return None
        if cfg.dry_run:
            await self._audit_event(CONTENT_DRY_RUN, actor=m.user_id, group_id=g, detail=f"{finding.kind}:{finding.category}",
                                    now=now)
            return None
        key = operation_key("contentjoin", g, m.user_id, int(now.timestamp()) // 60)
        try:
            first = await self._claims.claim(key, now)
        except Exception:
            return None
        if not first:
            return None
        cap = await check_bot_capabilities(self._chat_info, g, BotCapability.RESTRICT_MEMBERS)
        if cap.lookup_failed or not cap.ok:
            await self._audit_event(CONTENT_BLOCKED, actor=m.user_id, group_id=g, now=now,
                                    detail="rights_unknown" if cap.lookup_failed else "rights_missing")
            if not cap.lookup_failed:
                await self._owner_notice(g, now)
            return None
        if finding.kind == "suspect" and finding.source == SRC_NAME:  # a photo finding was already judged by Gemini Vision
            finding = await self._judge_name(cfg, g, m, finding, now)
            if finding is None:
                return None
        if finding.kind in ("ban", "ladder"):  # a clear case at join is a ban (no warning step for an explicit identity)
            return "ban" if await self._ban(g, m.user_id, finding, True, now, key) else None
        await self._open_review(g, title, m.user_id, m.display_name, finding, None, True, now)
        return "review"

    def _name_finding(self, cfg: ProtectionSettings, m: NewMember) -> Finding | None:
        names = f"{m.display_name} {m.username or ''}".strip()
        if not names:
            return None
        if cfg.cf_emoji and find_banned_emoji(names, self._lexicon.banned_emojis):
            return Finding("ban", SRC_NAME, "emoji")
        if not (cfg.cf_names and cfg.adult_enabled):
            return None
        verdict = self._classifier.classify(f"{m.display_name} {(m.username or '').replace('_', ' ')}", cfg.adult_custom_words)
        if verdict.level == BLOCK and verdict.category in (CAT_EXPLICIT, CAT_PATTERN):
            return Finding("ban", SRC_NAME, verdict.category)
        if verdict.level in (BLOCK, SUSPECT):  # insult / custom word / hint in a NAME: a human or Gemini decides
            return Finding("suspect", SRC_NAME, verdict.category or "hint")
        return None

    async def _judge_name(self, cfg: ProtectionSettings, g: int, m: NewMember, finding: Finding, now: datetime) -> Finding | None:
        if not self._ai_ready(cfg):
            return Finding("suspect", SRC_NAME, finding.category, "ai_unavailable")
        result = await self._ai.review_text(f"{m.display_name} {m.username or ''}")  # type: ignore[union-attr]
        if not result.ok:
            await self._audit_event(CONTENT_AI_FAILED, actor=m.user_id, group_id=g, detail=result.failure, now=now)
        outcome = gemini.decide(result)
        if outcome == "safe":
            return None
        v = result.verdict
        reason = v.reason if v else (result.failure or "ai_failed")
        if outcome == "block":
            return Finding("ban", SRC_NAME, "ai", reason, v.confidence if v else 0.0)
        return Finding("suspect", SRC_NAME, finding.category, reason, v.confidence if v else 0.0)

    async def _photo_finding(self, cfg: ProtectionSettings, g: int, m: NewMember, now: datetime) -> Finding | None:
        """Profile photo -> Gemini Vision. No photo / fetch failure / Gemini failure => no finding (never a penalty)."""
        try:
            image = await self._photos.fetch_profile_photo(m.user_id)
        except Exception:
            image = None
        if not image:
            return None
        result = await self._ai.review_image(image)  # type: ignore[union-attr]
        del image  # never kept
        if not result.ok:
            await self._audit_event(CONTENT_PHOTO_UNCHECKED, actor=m.user_id, group_id=g, detail=result.failure, now=now)
            return None
        outcome = gemini.decide(result)
        v = result.verdict
        if outcome == "block":
            return Finding("ban", SRC_PHOTO, "photo", v.reason, v.confidence)
        if outcome == "warning":
            return Finding("suspect", SRC_PHOTO, "photo", v.reason, v.confidence)
        return None
