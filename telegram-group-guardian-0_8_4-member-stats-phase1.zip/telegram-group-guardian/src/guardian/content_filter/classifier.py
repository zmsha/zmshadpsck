"""Local text classification: CLEAN / SUSPECT / BLOCK. Pure and synchronous (no network, no database).

* BLOCK   - an unmistakable violation (explicit sexual word/phrase/pattern, strong insult, the group's own custom word). Handled
            locally, never sent to Gemini.
* SUSPECT - a suggestive / dating / innuendo signal that only an AI (or a human) can judge. Sent to Gemini; if Gemini fails the
            message is NOT assumed safe (service.py).
* CLEAN   - nothing found.

Matching is by WHOLE WORD after normalisation (diacritics, tatweel, Arabic letter folding, repeated letters, spaced / dotted
letters, look-alike digits). A word in `exceptions` is skipped, but only that word: every other word of the sentence is still
checked, so an innocent word never lets a violating sentence through.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, replace

from ..protection.adult_words import fold, prefold
from .lexicon import Lexicon, default_lexicon

CLEAN, SUSPECT, BLOCK = "clean", "suspect", "block"
CAT_EXPLICIT, CAT_INSULT, CAT_CUSTOM, CAT_HINT, CAT_PATTERN = "explicit", "insult", "custom", "hint", "pattern"

_SPLIT = re.compile(r"[\W_]+", re.UNICODE)
_HAS_ARABIC = re.compile("[\u0600-\u06ff]")
_HAS_LATIN = re.compile("[a-z]")
_LEET = str.maketrans({"0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t", "@": "a", "$": "s", "!": "i"})
_REPEAT = re.compile(r"(.)\1+")
_PREFIXES = ("وبال", "وال", "بال", "فال", "كال", "لل", "ال", "و", "ب", "ف", "ل", "ك")
_SHORT_PREFIXES = ("وبال", "وال", "بال", "فال", "كال", "لل", "ال", "و")  # a <=3-letter listed word is only recognised behind the article / و (so `فكس` "fax" stays clean)
MAX_TEXT = 4000  # longer text is cut (Telegram's limit is 4096); the filter never works on unbounded input
MAX_GLUE = 6


@dataclass(frozen=True, slots=True)
class Verdict:
    level: str = CLEAN
    category: str | None = None
    matched: str | None = None  # the folded listed entry; for tests/debug only, never stored or sent anywhere

    @property
    def clean(self) -> bool:
        return self.level == CLEAN


CLEAN_VERDICT = Verdict()


def _tokens(text: str) -> list[str]:
    return [t for t in _SPLIT.split(text) if t]


def _glued(tokens: list[str]) -> list[str]:
    """Spaced-out letters: runs of short tokens (`س ك س`, `س ك` + `س`) joined, as whole runs and as 2..4 windows."""
    out: list[str] = []
    run: list[str] = []
    for tok in [*tokens, ""]:
        if 0 < len(tok) <= 2 and not tok.isdigit():
            run.append(tok)
            continue
        if len(run) >= 3:
            run = run[:MAX_GLUE * 4]
            out.append("".join(run))
            for size in (2, 3, 4):
                for i in range(len(run) - size + 1):
                    out.append("".join(run[i:i + size]))
        run = []
    return out


def _delook(token: str) -> str | None:
    if not (token.isascii() and any(c in "013457@$!" for c in token) and _HAS_LATIN.search(token)):
        return None
    return _REPEAT.sub(r"\1", token.translate(_LEET))


def _forms(token: str) -> list[str]:
    forms = [token]
    if _HAS_ARABIC.search(token):
        for prefix in _PREFIXES:
            rest = token[len(prefix):]
            if token.startswith(prefix) and len(rest) >= 2:
                forms.append(rest)
    return forms


class ContentClassifier:
    def __init__(self, lexicon: Lexicon | None = None):
        self._base = lexicon or default_lexicon()
        self._lex = self._base

    @property
    def lexicon(self) -> Lexicon:
        """The EFFECTIVE lexicon: the bundled one plus the owner's default-word changes (see `set_overlay`)."""
        return self._lex

    @property
    def base_lexicon(self) -> Lexicon:
        """The bundled lexicon exactly as loaded from `data/` (no owner changes)."""
        return self._base

    def set_overlay(self, added: frozenset[str] = frozenset(), removed: frozenset[str] = frozenset()) -> None:
        """Owner-managed default words (part 9.5). `added` words are explicit (block); `removed` words are dropped from the
        explicit / insult / hint lists. Both are in the folded form. One assignment, so a running classification never sees a
        half-updated lexicon."""
        base = self._base
        if not added and not removed:
            self._lex = base
            return
        self._lex = replace(base, explicit=(base.explicit - removed) | added, insults=base.insults - removed,
                            hints=base.hints - removed)

    def classify(self, text: object, custom: tuple[str, ...] | list[str] = ()) -> Verdict:
        if not isinstance(text, str) or not text.strip():
            return CLEAN_VERDICT
        lex = self._lex
        pre = prefold(text[:MAX_TEXT])
        folded = _REPEAT.sub(r"\1", pre)
        folded = self._without_exception_phrases(folded)
        best = CLEAN_VERDICT
        tokens = _tokens(folded)
        candidates = list(tokens)
        candidates.extend(_glued(tokens))
        for tok in tuple(candidates):
            looked = _delook(tok)
            if looked:
                candidates.append(looked)
        custom_set = frozenset(c for c in custom if isinstance(c, str))
        for tok in candidates:
            if tok in lex.exceptions:
                continue
            for form in _forms(tok):
                if form in lex.exceptions:
                    continue
                if len(form) < len(tok) and len(form) <= 3 and not tok.startswith(_SHORT_PREFIXES):
                    continue
                if form in lex.explicit:
                    return Verdict(BLOCK, CAT_EXPLICIT, form)
                if form in lex.insults:
                    best = Verdict(BLOCK, CAT_INSULT, form) if best.level != BLOCK else best
                elif form in custom_set:
                    return Verdict(BLOCK, CAT_CUSTOM, form)
                elif form in lex.hints and best.level == CLEAN:
                    best = Verdict(SUSPECT, CAT_HINT, form)
        spaced = " " + " ".join(tokens) + " "
        for phrase in lex.phrases_block:
            if f" {phrase} " in spaced:
                return Verdict(BLOCK, CAT_EXPLICIT, phrase)
        if best.level == CLEAN:
            for phrase in lex.phrases_suspect:
                if f" {phrase} " in spaced:
                    best = Verdict(SUSPECT, CAT_HINT, phrase)
                    break
        for level, pattern in lex.patterns:
            hit = pattern.search(pre)
            if hit:
                if level == "block":
                    return Verdict(BLOCK, CAT_PATTERN, pattern.pattern[:40])
                if best.level == CLEAN:
                    best = Verdict(SUSPECT, CAT_PATTERN, pattern.pattern[:40])
        return best

    def _without_exception_phrases(self, folded: str) -> str:
        """Blank innocent multi-word phrases (`الجنس البشري`) so their words are not judged; nothing else is removed."""
        if not self._lex.exception_phrases:
            return folded
        padded = " " + " ".join(_tokens(folded)) + " "
        for phrase in self._lex.exception_phrases:
            padded = padded.replace(f" {phrase} ", " ")
        return padded.strip()


_DEFAULT: ContentClassifier | None = None


def default_classifier() -> ContentClassifier:
    global _DEFAULT
    if _DEFAULT is None:
        _DEFAULT = ContentClassifier()
    return _DEFAULT
