"""Banned emoji detection (message text AND member names). The list is `data/banned_emojis.txt`."""
from __future__ import annotations

from .lexicon import default_lexicon

_STRIP = dict.fromkeys(map(ord, "\ufe0f\ufe0e\u200d"))  # variation selectors / zero-width joiner never hide an emoji


def find_banned_emoji(text: object, banned: frozenset[str] | None = None) -> str | None:
    """The first banned emoji contained in `text` (any position, any surrounding text), or None."""
    if not isinstance(text, str) or not text:
        return None
    banned = default_lexicon().banned_emojis if banned is None else banned
    if not banned:
        return None
    stripped = text.translate(_STRIP)
    for emoji in banned:
        if emoji in stripped:
            return emoji
    return None
