"""The penalty ladder for a CLEAR violation by a member: 1st = warning, 2nd = 1 h mute, 3rd = 24 h mute, 4th and later = ban.
Immediate-ban rules (banned emoji, blocked script, explicit name/photo) do NOT use the ladder, and a suspected (WARNING) case
never counts until an admin confirms it."""
from __future__ import annotations

from dataclasses import dataclass

WARN, MUTE, BAN = "warn", "mute", "ban"
LADDER_WINDOW_SECONDS = 30 * 86400  # offenses older than this no longer count


@dataclass(frozen=True, slots=True)
class Step:
    action: str            # warn | mute | ban
    seconds: int | None    # mute length (None for warn/ban)


STEPS = (Step(WARN, None), Step(MUTE, 3600), Step(MUTE, 86400), Step(BAN, None))


def step_for(offense: int) -> Step:
    """`offense` is 1-based; anything above the table is the last step (ban)."""
    n = offense if isinstance(offense, int) and not isinstance(offense, bool) and offense >= 1 else 1
    return STEPS[min(n, len(STEPS)) - 1]
