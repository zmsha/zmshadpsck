"""Loads the editable lexicon from `data/`. Forgiving by design: a bad line is skipped and reported in `problems`, never fatal
(a typo in a word file must not take protection down). Words are stored in the SAME folded form the classifier compares."""
from __future__ import annotations

import json
import logging
import re
import time
from dataclasses import dataclass, field
from pathlib import Path

from ..protection.adult_words import fold

log = logging.getLogger(__name__)

DATA_DIR = Path(__file__).parent / "data"
MAX_PATTERN_LEN = 250
_PATTERN_BUDGET_SECONDS = 0.05  # a pattern slower than this on a 2000-char probe is refused (catastrophic backtracking guard)
LEVELS = ("block", "suspect")


@dataclass(frozen=True, slots=True)
class Lexicon:
    explicit: frozenset[str] = frozenset()
    insults: frozenset[str] = frozenset()
    hints: frozenset[str] = frozenset()
    exceptions: frozenset[str] = frozenset()
    exception_phrases: tuple[str, ...] = ()
    phrases_block: tuple[str, ...] = ()
    phrases_suspect: tuple[str, ...] = ()
    patterns: tuple[tuple[str, "re.Pattern[str]"], ...] = ()
    banned_emojis: frozenset[str] = frozenset()
    blocked_scripts: frozenset[str] = frozenset()
    allowed_script_chars: frozenset[str] = frozenset()  # symbols of a blocked script that stay allowed (`allow:` line)
    false_positives: dict = field(default_factory=dict)
    problems: tuple[str, ...] = ()


def _lines(path: Path, problems: list[str]) -> list[str]:
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError:
        problems.append(f"{path.name}: unreadable")
        return []
    return [ln.strip() for ln in raw.splitlines() if ln.strip() and not ln.strip().startswith("#")]


def _split_words(lines: list[str]) -> tuple[set[str], set[str]]:
    """-> (single words, multi-word phrases). An underscore inside a line means a space (a phrase)."""
    words: set[str] = set()
    phrases: set[str] = set()
    for line in lines:
        text = fold(line.replace("_", " "))
        text = " ".join(text.split())
        if len(text) < 2:  # a collapsed 1-letter entry (e.g. "xxx" -> "x") would match a harmless token: refuse it
            continue
        (phrases if " " in text else words).add(text)
    return words, phrases


def _probe(pattern: "re.Pattern[str]") -> bool:
    start = time.perf_counter()
    for sample in ("a" * 2000, "ا" * 2000, "a " * 1000, "x_" * 1000):
        pattern.search(sample)
    return time.perf_counter() - start <= _PATTERN_BUDGET_SECONDS


def _patterns(lines: list[str], problems: list[str]) -> list[tuple[str, "re.Pattern[str]"]]:
    out: list[tuple[str, re.Pattern[str]]] = []
    for line in lines:
        level, _, body = line.partition("|")
        if level not in LEVELS or not body or len(body) > MAX_PATTERN_LEN:
            problems.append("patterns.txt: bad line (level|regex)")
            continue
        try:
            compiled = re.compile(body, re.IGNORECASE | re.UNICODE)
        except re.error:
            problems.append("patterns.txt: invalid regex skipped")
            continue
        if not _probe(compiled):
            problems.append("patterns.txt: slow regex skipped")
            continue
        out.append((level, compiled))
    return out


def _emoji_set(lines: list[str]) -> frozenset[str]:
    found: set[str] = set()
    for line in lines:
        for token in line.split():
            cleaned = token.replace("\ufe0f", "").replace("\ufe0e", "")
            if cleaned:
                found.add(cleaned)
    return frozenset(found)


def load(directory: Path | None = None) -> Lexicon:
    base = directory or DATA_DIR
    problems: list[str] = []
    explicit_w, explicit_p = _split_words(_lines(base / "words_explicit.txt", problems))
    insult_w, insult_p = _split_words(_lines(base / "words_insults.txt", problems))
    hint_w, hint_p = _split_words(_lines(base / "words_hints.txt", problems))
    exc_w, exc_p = _split_words(_lines(base / "exceptions.txt", problems))
    block_phrases = set(explicit_p) | set(insult_p)
    suspect_phrases = set(hint_p)
    for line in _lines(base / "phrases.txt", problems):
        level, _, body = line.partition("|")
        text = " ".join(fold(body).split())
        if level not in LEVELS or " " not in text:
            problems.append("phrases.txt: bad line (level|phrase)")
            continue
        (block_phrases if level == "block" else suspect_phrases).add(text)
    script_lines = _lines(base / "blocked_scripts.txt", problems)
    scripts = frozenset(ln.upper() for ln in script_lines if not ln.lower().startswith("allow:"))
    allowed = frozenset(ch for ln in script_lines if ln.lower().startswith("allow:") for ch in ln[6:] if not ch.isspace())
    false_positives: dict = {}
    try:
        data = json.loads((base / "false_positives.json").read_text(encoding="utf-8"))
        false_positives = data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        problems.append("false_positives.json: unreadable")
    lex = Lexicon(
        explicit=frozenset(explicit_w), insults=frozenset(insult_w), hints=frozenset(hint_w),
        exceptions=frozenset(exc_w), exception_phrases=tuple(sorted(exc_p)),
        phrases_block=tuple(sorted(block_phrases)), phrases_suspect=tuple(sorted(suspect_phrases)),
        patterns=tuple(_patterns(_lines(base / "patterns.txt", problems), problems)),
        banned_emojis=_emoji_set(_lines(base / "banned_emojis.txt", problems)),
        blocked_scripts=scripts, allowed_script_chars=allowed, false_positives=false_positives, problems=tuple(problems))
    for problem in problems:
        log.warning("content filter data: %s", problem)
    return lex


_CACHE: Lexicon | None = None


def default_lexicon() -> Lexicon:
    """The bundled lexicon, loaded once per process."""
    global _CACHE
    if _CACHE is None:
        _CACHE = load()
    return _CACHE
