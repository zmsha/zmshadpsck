"""Blocked writing systems in message text (not names, not usernames). Uses Unicode character names (stdlib `unicodedata`).

A single distinctive LETTER of a blocked script is enough. Ignored: links, digits, punctuation, emoji, symbols and the shared
(`Common`) characters; only letters / combining marks are looked at, and the text is NFKC-normalised first so full-width and
stylised forms count as what they imitate."""
from __future__ import annotations

import re
import unicodedata

from .lexicon import default_lexicon

_URL = re.compile(r"(?i)(?:https?://|www\.|t\.me/|tg://)\S+|\b[\w.-]+\.[a-z]{2,}(?:/\S*)?")
_MENTION = re.compile(r"@\w+")


def script_of(ch: str) -> str | None:
    """The script word of a LETTER (e.g. CYRILLIC, GREEK, CJK, HANGUL), or None for anything that is not a letter/mark."""
    if not unicodedata.category(ch).startswith(("L", "M")):
        return None
    name = unicodedata.name(ch, "")
    if name.startswith(("HALFWIDTH ", "FULLWIDTH ")):
        name = name.split(" ", 1)[1]
    return name.split(" ", 1)[0].split("-", 1)[0] or None if name else None


def find_blocked_script(text: object, blocked: frozenset[str] | None = None,
                        allowed_chars: frozenset[str] | None = None) -> str | None:
    if not isinstance(text, str) or not text:
        return None
    lex = default_lexicon()
    blocked = lex.blocked_scripts if blocked is None else blocked
    allowed_chars = lex.allowed_script_chars if allowed_chars is None else allowed_chars
    if not blocked:
        return None
    cleaned = _MENTION.sub(" ", _URL.sub(" ", unicodedata.normalize("NFKC", text)))
    for ch in cleaned:
        if ch.isascii() or ch in allowed_chars:
            continue
        script = script_of(ch)
        if script is not None and script in blocked:
            return script
    return None
