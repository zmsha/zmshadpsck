"""PostgreSQL stores of the content filter (NOT executed against a real PostgreSQL in the build sandbox).
Every statement is parameterised; reviews are decided with one conditional UPDATE so the first valid decision wins."""
from __future__ import annotations

from datetime import datetime

from .gemini import KeyState
from .store import PENDING, Review

_REVIEW_COLS = ("id, group_id, user_id, source, category, reason, confidence, status, created_at, decided_by, decided_at, "
                "notified, failed")


def _review(r) -> Review:
    return Review(id=r["id"], group_id=r["group_id"], user_id=r["user_id"], source=r["source"], category=r["category"],
                  reason=r["reason"], confidence=float(r["confidence"]), status=r["status"], created_at=r["created_at"],
                  decided_by=r["decided_by"], decided_at=r["decided_at"], notified=r["notified"], failed=r["failed"])


class PostgresContentLedger:
    def __init__(self, database) -> None:
        self._db = database

    async def count_since(self, group_id, user_id, since) -> int:
        async with self._db.acquire() as conn:
            value = await conn.fetchval(
                "SELECT count(*) FROM content_violations WHERE group_id = $1 AND user_id = $2 AND created_at > $3",
                group_id, user_id, since)
        return int(value or 0)

    async def record(self, group_id, user_id, source, category, action, now, idempotency_key=None) -> bool:
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "INSERT INTO content_violations (group_id, user_id, source, category, action, created_at, idempotency_key) "
                "VALUES ($1, $2, $3, $4, $5, $6, $7) ON CONFLICT (idempotency_key) DO NOTHING RETURNING id",
                group_id, user_id, source, category, action, now, idempotency_key)
        return row is not None


class PostgresReviewStore:
    def __init__(self, database) -> None:
        self._db = database

    async def create(self, group_id, user_id, source, category, reason, confidence, now) -> Review:
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "INSERT INTO content_reviews (group_id, user_id, source, category, reason, confidence, status, created_at) "
                f"VALUES ($1, $2, $3, $4, $5, $6, '{PENDING}', $7) RETURNING {_REVIEW_COLS}",
                group_id, user_id, source, category, reason, float(confidence), now)
        return _review(row)

    async def get(self, group_id, review_id) -> Review | None:
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                f"SELECT {_REVIEW_COLS} FROM content_reviews WHERE group_id = $1 AND id = $2", group_id, review_id)
        return _review(row) if row is not None else None

    async def decide(self, group_id, review_id, status, decided_by, now) -> Review | None:
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "UPDATE content_reviews SET status = $3, decided_by = $4, decided_at = $5 "
                f"WHERE group_id = $1 AND id = $2 AND status = '{PENDING}' RETURNING {_REVIEW_COLS}",
                group_id, review_id, status, decided_by, now)
        return _review(row) if row is not None else None

    async def set_delivery(self, group_id, review_id, notified, failed) -> None:
        async with self._db.acquire() as conn:
            await conn.execute("UPDATE content_reviews SET notified = $3, failed = $4 WHERE group_id = $1 AND id = $2",
                               group_id, review_id, notified, failed)


class PostgresKeyStateStore:
    def __init__(self, database) -> None:
        self._db = database

    async def load(self) -> dict[int, KeyState]:
        async with self._db.acquire() as conn:
            rows = await conn.fetch("SELECT slot, fingerprint, status, until FROM gemini_key_state")
        return {int(r["slot"]): KeyState(r["status"], r["until"], r["fingerprint"]) for r in rows}

    async def save(self, slot: int, state: KeyState, now: datetime) -> None:
        async with self._db.acquire() as conn:
            await conn.execute(
                "INSERT INTO gemini_key_state (slot, fingerprint, status, until, updated_at) VALUES ($1, $2, $3, $4, $5) "
                "ON CONFLICT (slot) DO UPDATE SET fingerprint = EXCLUDED.fingerprint, status = EXCLUDED.status, "
                "until = EXCLUDED.until, updated_at = EXCLUDED.updated_at",
                slot, state.fingerprint, state.status, state.until, now)


class PostgresDefaultWordStore:
    """The owner's changes to the default word list (`content_default_words`, migration 0012). Every statement is parameterised."""

    def __init__(self, database) -> None:
        self._db = database

    async def load(self) -> dict[str, str]:
        async with self._db.acquire() as conn:
            rows = await conn.fetch("SELECT word, action FROM content_default_words")
        return {r["word"]: r["action"] for r in rows}

    async def set(self, word: str, action: str, actor_id: int, now: datetime) -> None:
        async with self._db.acquire() as conn:
            await conn.execute(
                "INSERT INTO content_default_words (word, action, changed_by, changed_at) VALUES ($1, $2, $3, $4) "
                "ON CONFLICT (word) DO UPDATE SET action = EXCLUDED.action, changed_by = EXCLUDED.changed_by, "
                "changed_at = EXCLUDED.changed_at", word, action, actor_id, now)

    async def delete(self, word: str) -> None:
        async with self._db.acquire() as conn:
            await conn.execute("DELETE FROM content_default_words WHERE word = $1", word)
