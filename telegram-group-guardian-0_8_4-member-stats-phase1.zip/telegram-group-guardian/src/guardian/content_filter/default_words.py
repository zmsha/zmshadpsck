"""The owner's default word list (part 9.5): add / remove / list words of the content filter that apply to EVERY group.

The bundled lists in `data/*.txt` stay as they are; the owner's changes are a small overlay kept in the database
(`content_default_words`) and applied to the classifier (`ContentClassifier.set_overlay`):

* adding a word  -> it becomes an explicit (block) word everywhere; a bundled word the owner had switched off is simply switched back on;
* removing a word -> an owner-added word is deleted; a BUNDLED word is switched off (a `remove` row), so it works for the built-in
  words too;
* all words are stored in the classifier's folded form (`normalize_word`: alef/hamza, ta marbuta, diacritics, repeated letters), so
  `إباحي` and `اباحيي` are the same entry.

Pure logic + a store protocol (in-memory here, PostgreSQL in `postgres_store.py`). Who may call it is decided by the command
service (`owner_panel/default_words_commands.py`)."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Protocol

from ..protection.adult_words import normalize_word
from ..time_utils import utcnow
from .classifier import ContentClassifier

log = logging.getLogger(__name__)

ADD, REMOVE = "add", "remove"
MAX_OWNER_WORDS = 2000          # a runaway script must not grow the overlay without bound


class DefaultWordStore(Protocol):
    async def load(self) -> dict[str, str]: ...
    async def set(self, word: str, action: str, actor_id: int, now: datetime) -> None: ...
    async def delete(self, word: str) -> None: ...


class InMemoryDefaultWordStore:
    def __init__(self) -> None:
        self.rows: dict[str, str] = {}

    async def load(self) -> dict[str, str]:
        return dict(self.rows)

    async def set(self, word, action, actor_id, now) -> None:
        self.rows[word] = action

    async def delete(self, word) -> None:
        self.rows.pop(word, None)


@dataclass(frozen=True, slots=True)
class ChangeResult:
    added: tuple[str, ...] = ()        # newly effective words (a switched-off bundled word that came back counts too)
    removed: tuple[str, ...] = ()      # words that stopped matching
    unchanged: tuple[str, ...] = ()    # already in the wanted state
    invalid: tuple[str, ...] = ()      # raw input that is not a usable single word
    limit_reached: bool = False


@dataclass(frozen=True, slots=True)
class DefaultWordsView:
    bundled_explicit: int
    bundled_insults: int
    bundled_hints: int
    added: tuple[str, ...]             # owner-added words (sorted)
    removed: tuple[str, ...]           # bundled words the owner switched off (sorted)
    bundled_sample: tuple[str, ...]    # all effective bundled explicit words, sorted


class DefaultWordsService:
    def __init__(self, store: DefaultWordStore, classifier: ContentClassifier, *, clock=utcnow):
        self._store, self._classifier, self._clock = store, classifier, clock
        self._rows: dict[str, str] = {}

    # ------------------------------------------------------------------ state
    def _bundled(self) -> frozenset[str]:
        lex = self._classifier.base_lexicon
        return lex.explicit | lex.insults | lex.hints

    def _apply(self) -> None:
        added = frozenset(w for w, a in self._rows.items() if a == ADD)
        removed = frozenset(w for w, a in self._rows.items() if a == REMOVE)
        self._classifier.set_overlay(added, removed)

    async def refresh(self) -> bool:
        """Load the owner's changes from the store and apply them. False (and the previous state kept) when the store fails."""
        try:
            rows = await self._store.load()
        except Exception:
            log.warning("default words: could not load the owner's changes; using the bundled list", exc_info=True)
            return False
        self._rows = {w: a for w, a in rows.items() if isinstance(w, str) and a in (ADD, REMOVE)}
        self._apply()
        return True

    # ------------------------------------------------------------------ changes
    async def add(self, actor_id: int, raw_words) -> ChangeResult:
        added: list[str] = []
        unchanged: list[str] = []
        invalid: list[str] = []
        bundled = self._bundled()
        limit_reached = False
        for raw in raw_words:
            word = normalize_word(raw)
            if word is None:
                invalid.append(str(raw)[:40])
                continue
            state = self._rows.get(word)
            if state == ADD or (state is None and word in bundled):
                unchanged.append(word)
                continue
            if state == REMOVE:                     # a bundled word switched off: switch it back on
                await self._store.delete(word)
                self._rows.pop(word, None)
            else:
                if sum(1 for a in self._rows.values() if a == ADD) >= MAX_OWNER_WORDS:
                    limit_reached = True
                    break
                await self._store.set(word, ADD, actor_id, self._clock())
                self._rows[word] = ADD
            added.append(word)
        self._apply()
        return ChangeResult(tuple(dict.fromkeys(added)), (), tuple(dict.fromkeys(unchanged)), tuple(invalid), limit_reached)

    async def remove(self, actor_id: int, raw_words) -> ChangeResult:
        removed: list[str] = []
        unchanged: list[str] = []
        invalid: list[str] = []
        bundled = self._bundled()
        for raw in raw_words:
            word = normalize_word(raw)
            if word is None:
                invalid.append(str(raw)[:40])
                continue
            state = self._rows.get(word)
            if state == ADD:
                await self._store.delete(word)
                self._rows.pop(word, None)
                if word in bundled:                 # also a bundled word: deleting the owner's row would bring it back
                    await self._store.set(word, REMOVE, actor_id, self._clock())
                    self._rows[word] = REMOVE
                removed.append(word)
            elif state is None and word in bundled:
                await self._store.set(word, REMOVE, actor_id, self._clock())
                self._rows[word] = REMOVE
                removed.append(word)
            else:
                unchanged.append(word)
        self._apply()
        return ChangeResult((), tuple(dict.fromkeys(removed)), tuple(dict.fromkeys(unchanged)), tuple(invalid))

    # ------------------------------------------------------------------ read
    def view(self) -> DefaultWordsView:
        base = self._classifier.base_lexicon
        added = tuple(sorted(w for w, a in self._rows.items() if a == ADD))
        removed = tuple(sorted(w for w, a in self._rows.items() if a == REMOVE))
        gone = frozenset(removed)
        return DefaultWordsView(len(base.explicit), len(base.insults), len(base.hints), added, removed,
                                tuple(sorted(base.explicit - gone)))
