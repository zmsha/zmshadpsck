"""Storage interfaces + in-memory implementations (tests / local) for the content filter. PostgreSQL versions: postgres_store.py."""
from __future__ import annotations

import itertools
from dataclasses import dataclass, replace
from datetime import datetime
from typing import Protocol

PENDING, CONFIRMED, REJECTED = "pending", "confirmed", "rejected"


@dataclass(frozen=True, slots=True)
class Review:
    id: int
    group_id: int
    user_id: int
    source: str            # message | name | photo
    category: str
    reason: str
    confidence: float
    status: str
    created_at: datetime
    decided_by: int | None = None
    decided_at: datetime | None = None
    notified: int = 0
    failed: int = 0


class ContentLedger(Protocol):
    async def count_since(self, group_id: int, user_id: int, since: datetime) -> int: ...

    async def record(self, group_id: int, user_id: int, source: str, category: str, action: str, now: datetime,
                     idempotency_key: str | None = None) -> bool:
        """True when a new row was written (False: the same key was already recorded)."""
        ...


class ReviewStore(Protocol):
    async def create(self, group_id: int, user_id: int, source: str, category: str, reason: str, confidence: float,
                     now: datetime) -> Review: ...

    async def get(self, group_id: int, review_id: int) -> Review | None: ...

    async def decide(self, group_id: int, review_id: int, status: str, decided_by: int, now: datetime) -> Review | None:
        """pending -> `status` exactly once. Returns the updated row, or None when it is not pending any more (or unknown)."""
        ...

    async def set_delivery(self, group_id: int, review_id: int, notified: int, failed: int) -> None: ...


class InMemoryContentLedger:
    def __init__(self) -> None:
        self.rows: list[dict] = []

    async def count_since(self, group_id, user_id, since) -> int:
        return sum(1 for r in self.rows if r["g"] == group_id and r["u"] == user_id and r["at"] > since)

    async def record(self, group_id, user_id, source, category, action, now, idempotency_key=None) -> bool:
        if idempotency_key is not None and any(r["key"] == idempotency_key for r in self.rows):
            return False
        self.rows.append({"g": group_id, "u": user_id, "source": source, "category": category, "action": action,
                          "at": now, "key": idempotency_key})
        return True


class InMemoryReviewStore:
    def __init__(self) -> None:
        self._rows: dict[int, Review] = {}
        self._ids = itertools.count(1)

    async def create(self, group_id, user_id, source, category, reason, confidence, now) -> Review:
        review = Review(next(self._ids), group_id, user_id, source, category, reason, float(confidence), PENDING, now)
        self._rows[review.id] = review
        return review

    async def get(self, group_id, review_id) -> Review | None:
        row = self._rows.get(review_id)
        return row if row is not None and row.group_id == group_id else None

    async def decide(self, group_id, review_id, status, decided_by, now) -> Review | None:
        row = self._rows.get(review_id)
        if row is None or row.group_id != group_id or row.status != PENDING or status not in (CONFIRMED, REJECTED):
            return None
        self._rows[review_id] = row = replace(row, status=status, decided_by=decided_by, decided_at=now)
        return row

    async def set_delivery(self, group_id, review_id, notified, failed) -> None:
        row = self._rows.get(review_id)
        if row is not None and row.group_id == group_id:
            self._rows[review_id] = replace(row, notified=notified, failed=failed)
