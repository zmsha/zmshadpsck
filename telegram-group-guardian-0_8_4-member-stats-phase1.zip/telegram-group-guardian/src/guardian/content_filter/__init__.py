"""Content filter (part 9.2): explicit / suggestive / inappropriate-dating / insult detection, evasion handling, banned emojis,
blocked writing systems, optional Gemini review (key rotation) and the penalty ladder.

Layout (every module is small and independent; only `service.py` talks to the outside world through injected adapters):

* `data/*.txt`, `data/false_positives.json` - the editable lexicon (words, phrases, patterns, exceptions, emojis, scripts).
* `lexicon.py`   - loads + validates the data files (never raises for a bad line: it is skipped and reported).
* `classifier.py`- local text classification -> CLEAN / SUSPECT / BLOCK (+ category).
* `emojis.py`, `scripts.py` - banned emoji / blocked Unicode script detection.
* `gemini.py`    - key pool with rotation + client (text and vision) returning SAFE / WARNING / BLOCK with confidence + reason.
* `ladder.py`    - the penalty ladder (warning -> 1 h mute -> 24 h mute -> ban).
* `service.py`   - the guard: messages, new-member screening, admin review decisions.
"""
