"""UTC-first time helpers. All stored timestamps are timezone-aware UTC."""
from __future__ import annotations

from datetime import datetime, timezone
from zoneinfo import ZoneInfo

UTC = timezone.utc


def utcnow() -> datetime:
    return datetime.now(UTC)


def ensure_utc(value: datetime) -> datetime:
    """Return `value` in UTC. Naive datetimes are rejected (ambiguous)."""
    if value.tzinfo is None or value.utcoffset() is None:
        raise ValueError("naive datetime is not allowed; use timezone-aware UTC")
    return value.astimezone(UTC)


def to_display_tz(value: datetime, tz_name: str) -> datetime:
    return ensure_utc(value).astimezone(ZoneInfo(tz_name))


def format_display(value: datetime, tz_name: str) -> str:
    """Human-readable local time, always with the zone name, e.g. '2026-10-29 03:25 (Asia/Riyadh)'."""
    return f"{to_display_tz(value, tz_name):%Y-%m-%d %H:%M} ({tz_name})"
