"""The reports exporter (part 6.7c): a group's stored reports as CSV or TXT. Pure: no I/O, and NO permission check (the
command has applied `MODERATE` and the licence gate before anything is read; this module only formats).

What a record carries: the number, the closed vocabularies (status/type/priority/outcome), the ids of the reporter, the
reported member, the reported message and the moderators who took/handled it, the times (UTC and local), and the reporter's
short sanitized reason (`clean_reason`, <= 200 characters: the report's own body, shown to moderators by `/report show`).
Never: the update's idempotency key, the trace id, usernames, message text, other groups' rows (a foreign row is skipped).
The file goes only to the requester's private chat (`ExportDelivery`), never to a group.
"""
from __future__ import annotations

from datetime import datetime
from typing import Sequence

from ..reports.models import Report
from ..time_utils import ensure_utc, to_display_tz
from .settings_export import stamp
from .tabular import Built, render_csv, render_txt
from .models import ExportFile

CSV = "csv"
TXT = "txt"
FORMATS = (CSV, TXT)
ROW_CAP = 1000          # newest reports kept when a group has more (the file says so; the command tells the requester)

HEADER = ("id", "created_at", "created_at_local", "status", "type", "priority", "reporter_id", "target_user_id",
          "message_id", "reason", "assigned_to", "outcome", "handled_by", "handled_at", "handled_at_local")


def _local(value: datetime | None, tz_name: str) -> str | None:
    if value is None:
        return None
    try:
        return f"{to_display_tz(value, tz_name):%Y-%m-%d %H:%M}"
    except Exception:
        return None


def _cells(r: Report, tz_name: str) -> list[object]:
    return [
        r.id, stamp(r.created_at), _local(r.created_at, tz_name), r.status.value, r.report_type.value, r.priority.value,
        r.reporter_id, r.target_user_id, r.message_id, r.reason, r.assigned_to,
        None if r.outcome is None else r.outcome.value, r.handled_by,
        None if r.handled_at is None else stamp(r.handled_at), _local(r.handled_at, tz_name),
    ]


def build_reports_export(group_id: int, reports: Sequence[Report], now: datetime, display_timezone: str, fmt: str = CSV, *,
                         status_key: str = "all", truncated: bool = False) -> Built:
    """`reports` = oldest first (the command pages newest first and reverses). `truncated` = the command already left older
    rows out (row cap); the byte budget may cut further. Rows of another group are dropped, never exported."""
    if fmt not in FORMATS:
        raise ValueError("bad export format")
    now = ensure_utc(now)
    mine = [r for r in reports if r.group_id == group_id]
    rows = [_cells(r, display_timezone) for r in mine]
    name = f"reports_{abs(group_id)}_{now:%Y%m%d}"
    if fmt == CSV:
        content, kept = render_csv(HEADER, rows)
    else:
        header = [("export", "reports"), ("group", group_id), ("exported_at", stamp(now)), ("timezone", display_timezone),
                  ("filter", status_key)]
        records = [list(zip(HEADER, cells)) for cells in rows]
        content, kept = render_txt(header, records, truncated_note="note: older reports were left out (size limit)")
    cut = truncated or kept < len(mine)
    return Built(ExportFile(name, fmt, content, rows=kept), kept, cut)
