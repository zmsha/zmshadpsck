"""Export, part 6.7a: the value types of the private delivery path.

`ExportFile` is what a later exporter (6.7b/6.7c) hands to `ExportDelivery`; `DeliveryResult` is what comes back. Both are
closed and content-free where it matters: the result carries a CODE (never the file), so nothing downstream can leak it.
"""
from __future__ import annotations

from dataclasses import dataclass

KINDS = ("txt", "csv", "tsv", "json", "md")   # the extensions `screen_file` accepts, minus `.log` (an export is never a log)
MAX_BYTES = 1_000_000                          # the same ceiling as `owner_hub.redactor.MAX_FILE_BYTES`
MAX_ROWS = 20_000                              # data rows an export may carry (the exporter pages/caps before this)
MAX_NAME = 60
MAX_CAPTION = 400

# delivery codes (closed vocabulary; the audit detail and the later command messages use exactly these)
SENT = "sent"
PRIVATE_NOT_STARTED = "private_not_started"    # the requester never started the bot in private / blocked it
TOO_LARGE = "too_large"
TOO_MANY_ROWS = "too_many_rows"
REJECTED = "rejected"                          # `screen_file` refused it (secret-shaped file, bad name, empty, ...)
DUPLICATE = "duplicate"                        # the same operation key was already delivered
INVALID = "invalid"                            # not a usable requester id / file
FAILED = "failed"                              # Telegram error or timeout
CODES = frozenset({SENT, PRIVATE_NOT_STARTED, TOO_LARGE, TOO_MANY_ROWS, REJECTED, DUPLICATE, INVALID, FAILED})


class PrivateChatUnavailable(Exception):
    """Raised by a transport when the requester's private chat cannot be reached (never started / blocked the bot)."""


class ExportError(ValueError):
    """An `ExportFile` that is not well formed."""


@dataclass(frozen=True, slots=True)
class ExportFile:
    """A finished export: a base name (no path), a kind and the text content. `rows` = data rows (for the cap and audit)."""
    name: str
    kind: str
    content: str
    rows: int = 0

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not self.name.strip() or len(self.name) > MAX_NAME or any(c in self.name for c in "/\\\x00"):
            raise ExportError("bad export name")
        if self.kind not in KINDS:
            raise ExportError("bad export kind")
        if not isinstance(self.content, str):
            raise ExportError("export content must be text")
        if not isinstance(self.rows, int) or isinstance(self.rows, bool) or self.rows < 0:
            raise ExportError("bad row count")

    @property
    def filename(self) -> str:
        return f"{self.name}.{self.kind}"

    def data(self) -> bytes:
        return self.content.encode("utf-8")


@dataclass(frozen=True, slots=True)
class DeliveryResult:
    code: str
    redactions: int = 0     # places masked by the screen (0 = nothing found); a hint for the exporter's own tests

    @property
    def ok(self) -> bool:
        return self.code == SENT
