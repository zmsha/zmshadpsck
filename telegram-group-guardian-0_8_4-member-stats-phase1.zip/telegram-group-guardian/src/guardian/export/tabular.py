"""Shared table rendering of the CSV / TXT exports (part 6.7c). Pure: no I/O, no permissions, no Telegram.

* `safe_cell`: a text cell that a spreadsheet could read as a FORMULA (`= + - @`, tab, CR) gets a leading `'` (CSV injection);
  integers are written as they are and a purely numeric string (an opaque id such as `-1001234`) stays a number.
* `render_csv`: UTF-8 with a BOM (so Excel shows Arabic correctly), `\\r\\n` line ends, every field quoted by `csv` rules.
* `render_txt`: a short header (`label: value`), then one block per record (`label: value` lines). Labels never look like a
  secret name (the delivery screen masks `secret_name: value` pairs).
* The BYTE BUDGET: rows arrive oldest first; when the whole table would not fit, the OLDEST rows are dropped (the newest are
  the useful ones) and the result says it was cut. The budget stays below the delivery ceiling (`models.MAX_BYTES`).
"""
from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass
from typing import Sequence

from .models import MAX_BYTES, ExportFile

BYTE_BUDGET = 900_000          # < MAX_BYTES: headroom for the masking done by the delivery screen
BOM = "﻿"
_FORMULA_START = ("=", "+", "-", "@", "\t", "\r", "\n")
_NUMBER = re.compile(r"^-?[0-9]{1,20}$")

assert BYTE_BUDGET < MAX_BYTES


@dataclass(frozen=True, slots=True)
class Built:
    """An exporter's result: the file, how many records it holds and whether older records were left out."""
    file: ExportFile
    included: int
    truncated: bool


def safe_cell(value: object) -> str | int:
    """One CSV cell. `None`/`bool` -> empty; ints unchanged; text neutralised against formula injection."""
    if value is None or isinstance(value, bool):
        return ""
    if isinstance(value, int):
        return value
    text = str(value)
    if not text or _NUMBER.match(text):
        return text
    return "'" + text if text.startswith(_FORMULA_START) else text


def _csv_line(cells: Sequence[object]) -> str:
    out = io.StringIO()
    csv.writer(out, lineterminator="\r\n", quoting=csv.QUOTE_MINIMAL).writerow([safe_cell(c) for c in cells])
    return out.getvalue()


def _fit(lines: list[str], fixed: int) -> int:
    """How many of the NEWEST `lines` (the list is oldest first) fit in the budget after `fixed` bytes; returns the start index."""
    used, start = fixed, len(lines)
    for index in range(len(lines) - 1, -1, -1):
        used += len(lines[index].encode("utf-8"))
        if used > BYTE_BUDGET:
            break
        start = index
    return start


def render_csv(header: Sequence[str], rows: Sequence[Sequence[object]]) -> tuple[str, int]:
    """-> (content, number of rows kept)."""
    head = BOM + _csv_line(header)
    lines = [_csv_line(r) for r in rows]
    start = _fit(lines, len(head.encode("utf-8")))
    return head + "".join(lines[start:]), len(lines) - start


def txt_value(value: object) -> str:
    """One TXT value: a single line, no control characters; empty -> `-`."""
    if value is None or isinstance(value, bool):
        return "-"
    text = " ".join("".join(ch if ch.isprintable() else " " for ch in str(value)).split())
    return text or "-"


def render_txt(header: Sequence[tuple[str, object]], records: Sequence[Sequence[tuple[str, object]]], *,
               truncated_note: str | None = None) -> tuple[str, int]:
    """`header` = (label, value) lines; each record = (label, value) lines. -> (content, records kept)."""
    top = [f"{label}: {txt_value(value)}" for label, value in header]
    blocks = ["\n".join(f"{label}: {txt_value(value)}" for label, value in rec) + "\n" for rec in records]
    # the header states how many records follow, so it is rendered once the cut is known
    start = _fit(blocks, sum(len(line.encode("utf-8")) + 1 for line in top) + 200)
    kept = len(blocks) - start
    lines = list(top) + [f"records: {kept}"]
    if start > 0 and truncated_note:
        lines.append(truncated_note)
    return "\n".join(lines) + "\n" + "\n" + "\n".join(blocks[start:]), kept
