"""The licence exporter (part 6.7b): a group's licence state and its change history as one JSON file. Pure: no I/O, and NO
permission check (the command applies the owner-only check BEFORE it reads anything; this module only formats).

State: the status that is true NOW (`effective_status`: a stored temporary licence whose time has passed reads `expired`),
the stored status next to it when they differ, `permanent` (true only for `active_permanent`; then `expires_at` is null) and
the expiry as UTC plus local time. History: the licence audit rows, OLDEST first, with the actor id (null = the system), the
status change, the expiry set by that change and its short reason. Never contains secrets, member data or message content.
"""
from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Sequence

from ..licensing.models import AuditEvent, GroupLicense, LicenseStatus, effective_status
from ..time_utils import ensure_utc, to_display_tz
from .models import ExportFile
from .settings_export import stamp

FORMAT = "guardian-license-export"
VERSION = 1
HISTORY_LIMIT = 200          # `AuditQueryService.license_history` clamps to this; a full page may be truncated
MAX_TEXT = 200               # note / reason are short owner notes; cut anyway


def _local(value: datetime | None, tz_name: str) -> str | None:
    return None if value is None else f"{to_display_tz(value, tz_name):%Y-%m-%d %H:%M}"


def _text(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    cleaned = " ".join("".join(ch if ch.isprintable() else " " for ch in value).split())
    return cleaned[:MAX_TEXT] or None


def _license_part(license_: GroupLicense | None, now: datetime, tz_name: str) -> dict[str, Any]:
    if license_ is None:
        return {"registered": False, "status": None}
    shown = effective_status(license_, now)
    part: dict[str, Any] = {
        "registered": True,
        "status": shown.value,
        "permanent": license_.status is LicenseStatus.ACTIVE_PERMANENT,
        "expires_at": None if license_.expires_at is None else stamp(license_.expires_at),
        "expires_at_local": _local(license_.expires_at, tz_name),
        "activated_at": None if license_.activated_at is None else stamp(license_.activated_at),
        "activated_by": license_.activated_by,
        "updated_at": stamp(license_.updated_at),
        "note": _text(license_.note),
    }
    if shown is not license_.status:
        part["stored_status"] = license_.status.value    # the row still says active_temporary until something persists the expiry
    return part


def _history_part(events: Sequence[AuditEvent], tz_name: str) -> list[dict[str, Any]]:
    rows = []
    for ev in events:
        rows.append({
            "at": stamp(ev.occurred_at),
            "at_local": _local(ev.occurred_at, tz_name),
            "action": ev.action,
            "from": None if ev.previous_status is None else ev.previous_status.value,
            "to": ev.new_status.value,
            "by": ev.actor_telegram_id,
            "expires_at": None if ev.expires_at is None else stamp(ev.expires_at),
            "permanent": ev.new_status is LicenseStatus.ACTIVE_PERMANENT,
            "reason": _text(ev.reason),
        })
    return rows


def build_license_export(group_id: int, license_: GroupLicense | None, history: Sequence[AuditEvent], now: datetime,
                         display_timezone: str) -> ExportFile:
    now = ensure_utc(now)
    rows = _history_part(history, display_timezone)
    body = {
        "format": FORMAT,
        "version": VERSION,
        "exported_at": stamp(now),
        "timezone": display_timezone,
        "group_id": group_id,
        "license": _license_part(license_, now, display_timezone),
        "history": rows,
        "history_limit": HISTORY_LIMIT,
        "history_may_be_truncated": len(rows) >= HISTORY_LIMIT,
    }
    text = json.dumps(body, ensure_ascii=False, indent=2) + "\n"
    return ExportFile(f"license_{abs(group_id)}_{now:%Y%m%d}", "json", text, rows=len(rows))
