"""The settings exporter (part 6.7b): a group's EFFECTIVE settings as one JSON file. Pure: no I/O, no permissions.

What it contains: exactly `TEMPLATE_KEYS` (protection, welcome, verification, new-member policy) with the values the bot would
really use (`effective_settings`: defaults for anything missing or invalid), plus `customized` = the keys whose value differs
from the defaults. What it NEVER contains: secrets (none live in group settings; the delivery screen still checks), `dry_run`
(a per-group owner switch, not a configuration; see `owner_templates.EXCLUDED_KEYS`), the approved reports destination (an
owner-only setting outside `TEMPLATE_KEYS`), member ids, licence data, group title.

The file is the input a later restore (6.9) can validate: the same flat key space as settings templates.
"""
from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from ..owner_templates.templates import TEMPLATE_KEYS, effective_settings
from ..time_utils import ensure_utc
from .models import ExportFile

FORMAT = "guardian-settings-export"
VERSION = 1


def stamp(at: datetime) -> str:
    """UTC ISO-8601 with a `Z` suffix (seconds precision)."""
    return ensure_utc(at).strftime("%Y-%m-%dT%H:%M:%SZ")


def build_settings_export(group_id: int, raw_settings: Any, now: datetime) -> ExportFile:
    """`raw_settings` = the group's stored settings JSON (any junk is tolerated: defaults fill in)."""
    effective = effective_settings(raw_settings)
    defaults = effective_settings({})
    ordered = {key: effective[key] for key in TEMPLATE_KEYS}
    body = {
        "format": FORMAT,
        "version": VERSION,
        "exported_at": stamp(now),
        "group_id": group_id,
        "settings": ordered,
        "customized": [key for key in TEMPLATE_KEYS if ordered[key] != defaults[key]],
    }
    text = json.dumps(body, ensure_ascii=False, indent=2) + "\n"
    return ExportFile(f"settings_{abs(group_id)}_{ensure_utc(now):%Y%m%d}", "json", text, rows=len(ordered))
