"""Strict argument parsing of `/export` (parts 6.7b and 6.7c). Pure text logic: no Telegram, no permissions.

    /export settings                      تصدير الاعدادات
    /export license                       تصدير الترخيص
    /export reports [csv|txt] [status]    تصدير البلاغات [csv|txt] [الكل|المفتوحة|...]
    /export audit [csv|txt]               تصدير التدقيق [csv|txt]

The FIRST word is the export; `settings` and `license` take nothing else (they are JSON). `reports` and `audit` take an
optional format word (default `csv`) and `reports` also an optional status word (default `all`, the same words as `/reports`),
in any order, each at most once. Anything else is an error (`CommandError`, localized `mod_err_export_usage`): a mis-read
word must never export the wrong thing. English and Arabic words are interchangeable after `fold_arabic`.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..moderation.arabic import fold_arabic
from ..moderation.command_error import CommandError
from ..reports import args as report_args

SETTINGS = "settings"
LICENSE = "license"
REPORTS = "reports"
AUDIT = "audit"
CSV = "csv"
TXT = "txt"
AVAILABLE = (SETTINGS, LICENSE, REPORTS, AUDIT)
TABULAR = (REPORTS, AUDIT)       # the two that take a format word


def _table(mapping: dict[str, tuple[str, ...]]) -> dict[str, str]:
    return {fold_arabic(word): kind for kind, words in mapping.items() for word in words}


EXPORT_WORDS = _table({
    SETTINGS: ("settings", "setting", "config", "الاعدادات", "اعدادات", "الإعدادات", "إعدادات", "الاعداد"),
    LICENSE: ("license", "licence", "الترخيص", "ترخيص", "الرخصة", "رخصة"),
    REPORTS: ("reports", "report", "البلاغات", "بلاغات"),
    AUDIT: ("audit", "log", "التدقيق", "تدقيق", "السجل", "سجل"),
})


FORMAT_WORDS = _table({
    CSV: ("csv", "جدول"),
    TXT: ("txt", "text", "نص", "نصي"),
})


@dataclass(frozen=True, slots=True)
class ExportRequest:
    what: str                     # settings | license | reports | audit
    fmt: str = "json"             # json (settings, license) | csv | txt
    status_key: str = "all"       # reports only
    statuses: Any = None          # reports only: tuple of ReportStatus, or None = every status


def _status(word: str) -> tuple[str, Any] | None:
    """A `/reports` status word; Arabic also with the article (`المفتوحة` as well as `مفتوحة`)."""
    found = report_args.status_of(word)
    if found is None:
        folded = fold_arabic(word)
        if folded.startswith("ال") and len(folded) > 2:
            found = report_args.status_of(folded[2:])
    return found


def parse_export(args: tuple[str, ...] | list[str]) -> ExportRequest:
    """`<what> [format] [status]` -> the request. Raises `CommandError` `export_usage` for no word, an unknown word, a word the
    export does not take, or a repeated word."""
    words = list(args)
    if not words:
        raise CommandError("export_usage")
    what = EXPORT_WORDS.get(fold_arabic(words[0]))
    if what is None:
        raise CommandError("export_usage")
    extra = words[1:]
    if what not in TABULAR:
        if extra:
            raise CommandError("export_usage")
        return ExportRequest(what)
    fmt: str | None = None
    status: tuple[str, Any] | None = None
    for word in extra:
        folded = fold_arabic(word)
        if folded in FORMAT_WORDS and fmt is None:
            fmt = FORMAT_WORDS[folded]
        elif what == REPORTS and status is None and _status(word) is not None:
            status = _status(word)
        else:
            raise CommandError("export_usage")
    key, statuses = status if status is not None else ("all", None)
    return ExportRequest(what, fmt or CSV, key, statuses)


def alias_args_ok(args: tuple[str, ...] | list[str]) -> bool:
    """Arabic `تصدير ...` is a command only when it is followed by a valid request of the command's own vocabulary (so the
    bare word and ordinary sentences such as "تصدير البضائع الى" stay chat)."""
    words = list(args)
    if not words:
        return False
    try:
        parse_export(words)
    except CommandError:
        return False
    return True
