"""The security-audit exporter (part 6.7c): a group's recent security events as CSV or TXT. Pure: no I/O, and NO permission
check (the command applies `MODERATE` for THIS group first; the licence log is a different, owner-only export).

CONTENT-FREE by construction: per event only the time (UTC and local), the event NAME (closed snake_case vocabulary), the
actor's id, the opaque target id, the result word, the permission NAME and the trace id. The event's free-text `detail` is
never exported, nor message content; a value outside its closed vocabulary is blanked rather than copied.
"""
from __future__ import annotations

import re
from datetime import datetime
from typing import Sequence

from ..audit import RESULTS, SecurityEvent
from ..permissions import Permission
from ..time_utils import ensure_utc, to_display_tz
from ..trace import is_valid_trace_id
from .models import ExportFile
from .reports_export import CSV, FORMATS, TXT  # noqa: F401  (one definition of the two formats)
from .settings_export import stamp
from .tabular import Built, render_csv, render_txt

ROW_CAP = 500           # the audit store returns at most this many of the newest events

HEADER = ("at", "at_local", "event", "actor_id", "target", "result", "permission", "trace")
_EVENT_NAME = re.compile(r"^[a-z][a-z0-9_]{0,63}$")
_PERMISSIONS = frozenset(p.value for p in Permission)


def _local(value: datetime, tz_name: str) -> str | None:
    try:
        return f"{to_display_tz(value, tz_name):%Y-%m-%d %H:%M}"
    except Exception:
        return None


def _cells(e: SecurityEvent, tz_name: str) -> list[object]:
    return [
        stamp(e.occurred_at), _local(e.occurred_at, tz_name),
        e.event_type if isinstance(e.event_type, str) and _EVENT_NAME.match(e.event_type) else None,
        e.actor_telegram_id if isinstance(e.actor_telegram_id, int) and not isinstance(e.actor_telegram_id, bool) else None,
        e.target_id,
        e.result if e.result in RESULTS else None,
        e.permission if e.permission in _PERMISSIONS else None,
        e.trace_id if is_valid_trace_id(e.trace_id) else None,
    ]


def build_audit_export(group_id: int, events: Sequence[SecurityEvent], now: datetime, display_timezone: str, fmt: str = CSV,
                       *, truncated: bool = False) -> Built:
    """`events` = oldest first (as `SecurityAudit.for_group` returns them). Events of another group are dropped."""
    if fmt not in FORMATS:
        raise ValueError("bad export format")
    now = ensure_utc(now)
    mine = [e for e in events if e.group_id == group_id]
    rows = [_cells(e, display_timezone) for e in mine]
    name = f"audit_{abs(group_id)}_{now:%Y%m%d}"
    if fmt == CSV:
        content, kept = render_csv(HEADER, rows)
    else:
        header = [("export", "security events"), ("group", group_id), ("exported_at", stamp(now)), ("timezone", display_timezone)]
        records = [list(zip(HEADER, cells)) for cells in rows]
        content, kept = render_txt(header, records, truncated_note="note: older events were left out (size limit)")
    cut = truncated or kept < len(mine)
    return Built(ExportFile(name, fmt, content, rows=kept), kept, cut)
