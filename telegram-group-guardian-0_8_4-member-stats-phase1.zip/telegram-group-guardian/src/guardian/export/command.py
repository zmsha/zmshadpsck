"""`/export settings|license|reports|audit` inside a group (parts 6.7b and 6.7c). Framework independent; reached from `ModerationCommandService._handle`.

The executor applies the first two gates BEFORE this class is reached, in the same fail-closed order as every moderator command:
 1. `permissions.require(MODERATE, context_chat_id=chat)`  -> DENIED (nothing leaked)
 2. the effective licence (`protection.allowed` for THIS chat) -> LICENSE_OFF
then here:
 3. strict argument parsing (`export.args`)                   -> INVALID
 4. `license` ONLY: `Permission.VIEW_AUDIT` for THIS chat (OWNER_ONLY: exactly OWNER_TELEGRAM_ID; the permission service audits
    the refusal) -> DENIED. Group admins, delegates and the backup owner never get a licence log.
    `audit` (6.7c): `MODERATE` re-checked here for THIS chat (defence in depth; the gate above is the same one). The security
    log it exports is content-free (event names, opaque ids, result, trace; never `detail`), which is why a moderator may have it.
    `reports` (6.7c): `MODERATE` (the gate above): the reports of THIS group only, paged newest first through `ReportService`.
 5. delivery available, per (chat, actor) cooldown (silent), a durable claim `op:export:<what>:<chat>:<message id>`
 6. audit `export_requested` (which export, never content) -> read the data (a read failure answers a safe error, never defaults)
    -> build the file -> `ExportDelivery.deliver(actor, file, key=...)` (the ONLY way out: the requester's private chat)
 7. the group gets ONE short line (no content, no file): sent / start-the-bot-first / too large / refused / failed.

The group id is always the chat the command was typed in (never read from the text), so a group can only export itself.
`reports`/`audit` are capped (`ROW_CAP` newest rows + a byte budget); the file and the reply say when older rows were left out.
Read only: nothing is written to settings or licences; it works during `dry_run`.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any, Callable

from ..audit import EXPORT_REQUESTED, RESULT_APPLIED, make_event, record_safely
from ..i18n import t
from ..idempotency import operation_key
from ..moderation.command_error import CommandError
from ..moderation.commands import Command, ParsedCommand
from ..moderation.messages import error_message
from ..permissions import Permission
from ..time_utils import utcnow
from . import args as export_args
from . import models as m
from .audit_export import ROW_CAP as AUDIT_CAP
from .audit_export import build_audit_export
from .license_export import HISTORY_LIMIT, build_license_export
from .reports_export import ROW_CAP as REPORTS_CAP
from .reports_export import build_reports_export
from .settings_export import build_settings_export

log = logging.getLogger(__name__)

COOLDOWN_SECONDS = 30       # per (chat, actor): an export is a heavy read plus a private message
_MAX_COOLDOWN_KEYS = 5_000
_PAGE = 50                  # `ReportService` page size (its own maximum)


class ExportCommands:
    def __init__(self, *, permissions: Any, delivery: Any, claims: Any, load_raw: Callable[[int], Any], licenses: Any,
                 audit_query: Any, audit: Any, display_timezone: str, make_result: Callable[..., Any], kinds: Any,
                 reports: Any = None, clock: Callable[[], datetime] = utcnow):
        self._perm, self._delivery, self._claims, self._load_raw = permissions, delivery, claims, load_raw
        self._licenses, self._audit_query, self._audit, self._reports = licenses, audit_query, audit, reports
        self._tz, self._result, self._kinds, self._clock = display_timezone, make_result, kinds, clock
        self._until: dict[tuple[int, int], datetime] = {}

    # ------------------------------------------------------------------ cooldown (in memory, bounded)
    def _ready(self, key: tuple[int, int], now: datetime) -> bool:
        until = self._until.get(key)
        return until is None or until <= now

    def _mark(self, key: tuple[int, int], now: datetime) -> None:
        if len(self._until) >= _MAX_COOLDOWN_KEYS:
            self._until = {k: v for k, v in self._until.items() if v > now}
            if len(self._until) >= _MAX_COOLDOWN_KEYS:
                self._until.clear()
        self._until[key] = now + timedelta(seconds=COOLDOWN_SECONDS)

    # ------------------------------------------------------------------ the command
    async def handle(self, parsed: ParsedCommand, chat_id: int, actor_id: int, message_id: int, lang: str):
        R, cmd = self._kinds, Command.EXPORT
        try:
            request = export_args.parse_export(parsed.args)
        except CommandError as exc:
            return self._result(R.INVALID, error_message(exc, lang) or t("invalid_input", lang), cmd)
        if request.what == export_args.LICENSE:
            # Owner only, decided on the server on EVERY command (PermissionDenied is turned into DENIED + audit by the caller).
            await self._perm.require(actor_id, chat_id, Permission.VIEW_AUDIT, context_chat_id=chat_id)
        elif request.what == export_args.AUDIT:
            await self._perm.require(actor_id, chat_id, Permission.MODERATE, context_chat_id=chat_id)
        if (self._delivery is None or not getattr(self._delivery, "enabled", True)
                or (request.what == export_args.REPORTS and self._reports is None)
                or (request.what == export_args.AUDIT and self._audit is None)):
            return self._result(R.ERROR, t("export_unavailable", lang), cmd)
        now = self._clock()
        cool = (chat_id, actor_id)
        if not self._ready(cool, now):
            return self._result(R.THROTTLED, "", cmd)
        key = operation_key("export", request.what, chat_id, message_id)
        try:
            claimed = await self._claims.claim(key)
        except Exception:
            log.error("export claim failed; nothing exported", extra={"group_id": chat_id}, exc_info=True)
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        if not claimed:
            return self._result(R.DUPLICATE, "", cmd)
        self._mark(cool, now)
        await record_safely(self._audit, make_event(
            EXPORT_REQUESTED, actor=actor_id, group_id=chat_id, target=request.what, result=RESULT_APPLIED, now=now))
        try:
            file, cut = await self._build(request, chat_id, actor_id, now)
        except Exception:
            log.error("export build failed", extra={"group_id": chat_id}, exc_info=True)
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        caption = t(f"export_caption_{request.what}", lang, group=str(chat_id))
        if cut:
            caption += " — " + t("export_caption_cut", lang, count=str(file.rows))
        outcome = await self._delivery.deliver(
            actor_id, file, key=f"{chat_id}:{message_id}:{request.what}", caption=caption, group_id=chat_id)
        return self._answer(outcome, request.what, lang, file.rows if cut else None)

    async def _build(self, request: export_args.ExportRequest, chat_id: int, actor_id: int, now: datetime):
        """-> (the file, whether older rows were left out). Any read failure RAISES (a safe error, never defaults)."""
        what = request.what
        if what == export_args.SETTINGS:
            return build_settings_export(chat_id, await self._load_raw(chat_id), now), False
        if what == export_args.LICENSE:
            license_ = await self._licenses.get(chat_id)
            history = await self._audit_query.license_history(actor_id, chat_id, HISTORY_LIMIT, context_chat_id=chat_id)
            return build_license_export(chat_id, license_, history, now, self._tz), False
        if what == export_args.REPORTS:
            rows, cut = await self._collect_reports(chat_id, request.statuses)
            built = build_reports_export(chat_id, rows, now, self._tz, request.fmt, status_key=request.status_key, truncated=cut)
        else:
            events = list(await self._audit.for_group(chat_id, AUDIT_CAP))            # THIS chat only, oldest first
            built = build_audit_export(chat_id, events, now, self._tz, request.fmt, truncated=len(events) >= AUDIT_CAP)
        return built.file, built.truncated

    async def _collect_reports(self, chat_id: int, statuses: Any):
        """Newest first by pages of `_PAGE` until the cap (+1 to learn that there are more); returned oldest first."""
        rows: list[Any] = []
        before: int | None = None
        for _ in range(REPORTS_CAP // _PAGE + 2):                                      # bounded: a store that ignores `before_id` cannot loop
            page = await self._reports.list_reports(chat_id, statuses, _PAGE, before)
            if not page:
                break
            if before is not None and page[-1].id >= before:
                break
            rows.extend(page)
            before = page[-1].id
            if len(page) < _PAGE or len(rows) > REPORTS_CAP:
                break
        cut = len(rows) > REPORTS_CAP
        rows = rows[:REPORTS_CAP]
        rows.reverse()
        return rows, cut

    def _answer(self, outcome: Any, what: str, lang: str, cut_rows: int | None = None):
        R, cmd = self._kinds, Command.EXPORT
        code = getattr(outcome, "code", None)
        if code == m.SENT:
            text = t("export_sent", lang, what=t(f"export_what_{what}", lang))
            redactions = getattr(outcome, "redactions", 0)
            if isinstance(redactions, int) and redactions > 0:
                text += "\n" + t("export_redacted", lang, count=str(redactions))
            if cut_rows is not None:
                text += "\n" + t("export_cut", lang, count=str(cut_rows))
            return self._result(R.DONE, text, cmd)
        if code == m.DUPLICATE:
            return self._result(R.DUPLICATE, "", cmd)
        if code == m.PRIVATE_NOT_STARTED:
            return self._result(R.INVALID, t("export_private_not_started", lang), cmd)
        if code in (m.TOO_LARGE, m.TOO_MANY_ROWS):
            return self._result(R.ERROR, t("export_too_large", lang), cmd)
        if code == m.REJECTED:
            return self._result(R.ERROR, t("export_rejected", lang), cmd)
        if code == m.FAILED:
            return self._result(R.TELEGRAM_FAILED, t("export_failed", lang), cmd)
        return self._result(R.ERROR, t("action_failed_safe", lang), cmd)    # invalid / anything unknown: fail closed
