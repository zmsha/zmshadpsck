"""Export, part 6.7a: the PRIVATE DELIVERY PATH. Independent of `owner_hub`; there is no command yet (6.7b adds it).

An export (settings, a licence log, reports, audit rows) can hold the most sensitive data the bot has, so everything that
leaves goes through this one door and it is deliberately narrow:

* DESTINATION = the requester's PRIVATE chat, derived from the requester's own user id (Telegram's private chat id equals the
  user id). There is no `chat_id` parameter and no public function that takes one; a non-positive id (a group, a channel, a
  bool) is refused. A group chat can therefore never receive an export, whatever a caller passes.
* SCREEN: every file passes `owner_hub.redactor.screen_file` (secret-shaped files refused, text redacted, a final check that no
  configured secret survived) AFTER the size/row caps. A refused file is never "cleaned and sent anyway".
* ONE DELIVERY PER OPERATION: a durable claim `op:exportsend:<requester>:<kind>:<key>` taken after the checks and before the
  send (at-most-once; a failed send is retried by running the command again, which has a new key).
* NEVER RAISES, never retries inside a call, bounded by a timeout. Failures come back as a CODE (`DeliveryResult`); the
  requester not having started the bot in private is its own code so a command can tell them what to do.
* AUDIT: `export_delivered` / `export_failed` with the requester, the group (when given), the KIND and size/row counts and the
  code. Never the file name's content, the rows or the caption.

It does not import `owner_hub.sender`, aiogram or anything that can send to a chosen chat: the transport is injected.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Iterable, Protocol

from ..audit import EXPORT_DELIVERED, EXPORT_FAILED, RESULT_APPLIED, RESULT_FAILED, SecurityAudit, make_event, record_safely
from ..idempotency import operation_key
from ..owner_hub.redactor import redact_text, screen_file
from ..time_utils import utcnow
from . import models as m
from .models import DeliveryResult, ExportFile, PrivateChatUnavailable

log = logging.getLogger(__name__)

SEND_TIMEOUT = 20.0     # seconds; a hung Telegram call must not hold a webhook handler for long


class ExportTransport(Protocol):
    """Framework adapter (`bot/export_transport.py`). `user_id` is the requester's id = their private chat id."""

    async def send_document(self, user_id: int, filename: str, data: bytes, caption: str | None) -> None: ...


def _is_user_id(value: object) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value > 0


class ExportDelivery:
    def __init__(self, transport: ExportTransport | None, *, claims: Any, audit: SecurityAudit | None = None,
                 secrets: Iterable[str] = (), timeout: float = SEND_TIMEOUT, clock=utcnow) -> None:
        self._transport, self._claims, self._audit = transport, claims, audit
        self._secrets = tuple(s for s in secrets if s)
        self._timeout, self._clock = timeout, clock

    @property
    def enabled(self) -> bool:
        return self._transport is not None

    async def deliver(self, requester_id: int, file: ExportFile, *, key: object, caption: str | None = None,
                      group_id: int | None = None) -> DeliveryResult:
        """Send `file` to the PRIVATE chat of `requester_id`. `key` identifies the operation (e.g. the command message id).
        Never raises (cancellation excepted)."""
        try:
            return await self._deliver(requester_id, file, key, caption, group_id)
        except asyncio.CancelledError:
            raise
        except Exception as exc:    # the contract is "never raises"; type name only (HTTP errors can carry the bot token)
            log.error("export delivery crashed (%s)", type(exc).__name__)
            return await self._finish(requester_id, file, group_id, DeliveryResult(m.FAILED))

    async def _deliver(self, requester_id, file, key, caption, group_id) -> DeliveryResult:
        if not _is_user_id(requester_id) or not isinstance(file, ExportFile) or self._transport is None:
            return await self._finish(requester_id, file, group_id, DeliveryResult(m.INVALID))
        data = file.data()
        if file.rows > m.MAX_ROWS:
            return await self._finish(requester_id, file, group_id, DeliveryResult(m.TOO_MANY_ROWS))
        if len(data) > m.MAX_BYTES:
            return await self._finish(requester_id, file, group_id, DeliveryResult(m.TOO_LARGE))
        verdict = screen_file(file.filename, data, self._secrets)
        if not verdict.allowed:
            code = m.TOO_LARGE if verdict.reason == "too_large" else m.REJECTED
            return await self._finish(requester_id, file, group_id, DeliveryResult(code), reason=verdict.reason)
        try:
            claimed = await self._claims.claim(operation_key("exportsend", requester_id, file.kind, key), self._clock())
        except Exception as exc:
            log.error("export claim failed (%s)", type(exc).__name__)
            return await self._finish(requester_id, file, group_id, DeliveryResult(m.FAILED))
        if not claimed:
            return DeliveryResult(m.DUPLICATE)      # a repeat of one operation: silent (the first delivery was audited)
        note = redact_text(caption, self._secrets)[: m.MAX_CAPTION] if caption else None
        try:
            await asyncio.wait_for(self._transport.send_document(requester_id, verdict.filename, verdict.data, note or None),
                                   timeout=self._timeout)
        except PrivateChatUnavailable:
            return await self._finish(requester_id, file, group_id, DeliveryResult(m.PRIVATE_NOT_STARTED, verdict.redactions))
        except asyncio.TimeoutError:
            return await self._finish(requester_id, file, group_id, DeliveryResult(m.FAILED, verdict.redactions), reason="timeout")
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            log.warning("export send failed (%s)", type(exc).__name__)
            return await self._finish(requester_id, file, group_id, DeliveryResult(m.FAILED, verdict.redactions), reason=type(exc).__name__)
        return await self._finish(requester_id, file, group_id, DeliveryResult(m.SENT, verdict.redactions))

    async def _finish(self, requester_id, file, group_id, result: DeliveryResult, *, reason: str | None = None) -> DeliveryResult:
        """Audit (best effort) and return. Content-free: kind, sizes and the closed code only."""
        try:
            kind = file.kind if isinstance(file, ExportFile) else "none"
            size = len(file.data()) if isinstance(file, ExportFile) else 0
            rows = file.rows if isinstance(file, ExportFile) else 0
            detail = f"kind={kind} bytes={size} rows={rows} code={result.code}" + (f" why={reason}" if reason else "")
            if result.redactions:
                detail += f" redactions={result.redactions}"
            event_type = EXPORT_DELIVERED if result.ok else EXPORT_FAILED
            await record_safely(self._audit, make_event(
                event_type, actor=requester_id if _is_user_id(requester_id) else None,
                group_id=group_id if isinstance(group_id, int) and not isinstance(group_id, bool) else None,
                target=kind, result=RESULT_APPLIED if result.ok else RESULT_FAILED, detail=detail, now=self._clock()))
        except Exception:
            log.warning("export audit failed", exc_info=True)
        return result
