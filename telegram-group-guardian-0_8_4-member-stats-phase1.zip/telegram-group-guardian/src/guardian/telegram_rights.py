"""Telegram-side rights: who is an admin of a chat and what the BOT itself may do there.

Framework-independent. The aiogram adapter lives in `bot/chat_info.py`; here we only
describe the data and the decisions. Unknown/missing rights are treated as NOT granted
(fail closed). Error text shown to users never includes API details.
"""
from __future__ import annotations

import enum
from dataclasses import dataclass
from typing import Any, Protocol

from .errors import TelegramLookupFailed

ADMIN_STATUSES = frozenset({"creator", "administrator"})


@dataclass(frozen=True, slots=True)
class ChatMemberInfo:
    status: str  # creator | administrator | member | restricted | left | kicked | unknown
    can_delete_messages: bool = False
    can_restrict_members: bool = False
    can_pin_messages: bool = False

    @property
    def is_creator(self) -> bool:
        return self.status == "creator"

    @property
    def is_admin(self) -> bool:
        return self.status in ADMIN_STATUSES

    def can_restrict(self) -> bool:
        return self.is_creator or (self.status == "administrator" and self.can_restrict_members)


def member_info_from_telegram(member: Any) -> ChatMemberInfo:
    """Duck-typed conversion of an aiogram ChatMember* object (None/missing flags => False).

    Telegram's creator always has every right, but the API object for the creator carries
    no `can_*` fields; we therefore set them from the status.
    """
    raw_status = getattr(member, "status", None)
    status = str(getattr(raw_status, "value", raw_status) or "unknown")
    if status == "creator":
        return ChatMemberInfo(status, True, True, True)

    def flag(name: str) -> bool:
        return getattr(member, name, None) is True  # None (unknown) is NOT a grant

    if status == "administrator":
        return ChatMemberInfo(status, flag("can_delete_messages"), flag("can_restrict_members"), flag("can_pin_messages"))
    return ChatMemberInfo(status)


@dataclass(frozen=True, slots=True)
class AdminInfo:
    """One administrator as listed by `getChatAdministrators` (display data only: never an authorization source)."""

    user_id: int
    name: str = ""            # raw display name; callers sanitize/escape before showing it
    username: str | None = None
    is_creator: bool = False
    is_anonymous: bool = False
    is_bot: bool = False
    title: str | None = None  # custom admin title
    can_delete_messages: bool = False
    can_restrict_members: bool = False

    @property
    def can_moderate(self) -> bool:
        """Can this admin act on a report (delete or restrict)? The creator always can."""
        return self.is_creator or self.can_delete_messages or self.can_restrict_members


def admin_info_from_telegram(member: Any) -> AdminInfo | None:
    """Duck-typed conversion of an aiogram ChatMemberOwner/ChatMemberAdministrator. Unusable entries => None."""
    raw_status = getattr(member, "status", None)
    status = str(getattr(raw_status, "value", raw_status) or "")
    if status not in ADMIN_STATUSES:
        return None
    user = getattr(member, "user", None)
    uid = getattr(user, "id", None)
    if not isinstance(uid, int) or isinstance(uid, bool) or uid <= 0:
        return None

    def text(value: Any) -> str | None:
        return value if isinstance(value, str) and value else None

    name = text(getattr(user, "full_name", None)) or text(getattr(user, "first_name", None)) or ""
    creator = status == "creator"

    def flag(attr: str) -> bool:
        return creator or getattr(member, attr, None) is True  # None (unknown) is NOT a grant

    return AdminInfo(
        user_id=uid, name=name, username=text(getattr(user, "username", None)), is_creator=creator,
        is_anonymous=getattr(member, "is_anonymous", None) is True, is_bot=getattr(user, "is_bot", None) is True,
        title=text(getattr(member, "custom_title", None)),
        can_delete_messages=flag("can_delete_messages"), can_restrict_members=flag("can_restrict_members"))


class ChatInfoProvider(Protocol):
    async def get_member(self, chat_id: int, user_id: int, *, fresh: bool = False) -> ChatMemberInfo:
        """Raise TelegramLookupFailed on any API/network problem (callers fail closed)."""
        ...

    async def get_bot_member(self, chat_id: int) -> ChatMemberInfo: ...

    async def list_admins(self, chat_id: int) -> list[AdminInfo]:
        """Display list for /admins and /report (cached briefly). Raise TelegramLookupFailed on any failure."""
        ...


class BotCapability(str, enum.Enum):
    DELETE_MESSAGES = "delete_messages"
    RESTRICT_MEMBERS = "restrict_members"
    PIN_MESSAGES = "pin_messages"


_CAPABILITY_FLAG = {
    BotCapability.DELETE_MESSAGES: "can_delete_messages",
    BotCapability.RESTRICT_MEMBERS: "can_restrict_members",
    BotCapability.PIN_MESSAGES: "can_pin_messages",
}


@dataclass(frozen=True, slots=True)
class CapabilityResult:
    ok: bool
    missing: tuple[BotCapability, ...] = ()
    lookup_failed: bool = False

    def user_message_key(self) -> str | None:
        """i18n key for a safe, generic message (never exposes API errors); None when ok."""
        if self.ok:
            return None
        return "bot_check_failed" if self.lookup_failed else "bot_missing_rights"


def missing_capabilities(info: ChatMemberInfo, needed: tuple[BotCapability, ...]) -> tuple[BotCapability, ...]:
    if info.is_creator:  # the bot is never the creator in practice, but handle it consistently
        return ()
    if info.status != "administrator":
        return tuple(needed)  # a plain member can do none of these
    return tuple(c for c in needed if not getattr(info, _CAPABILITY_FLAG[c]))


async def check_bot_capabilities(
    provider: ChatInfoProvider, chat_id: int, *needed: BotCapability
) -> CapabilityResult:
    """Can the bot perform `needed` actions in `chat_id`? Call BEFORE delete/restrict/pin."""
    try:
        info = await provider.get_bot_member(chat_id)
    except TelegramLookupFailed:
        return CapabilityResult(False, tuple(needed), lookup_failed=True)
    except Exception:
        return CapabilityResult(False, tuple(needed), lookup_failed=True)
    missing = missing_capabilities(info, tuple(needed))
    return CapabilityResult(not missing, missing)
