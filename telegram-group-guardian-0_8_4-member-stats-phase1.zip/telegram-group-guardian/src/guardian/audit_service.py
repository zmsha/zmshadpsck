"""Owner-only read access to the audit trails (Permission.VIEW_AUDIT), scoped to ONE group.

The stores' `audit_for_group` / `for_group` methods are plain repositories with no authorization.
Anything user-facing (owner panel, reports, exports in later phases) must go through this service
so that reading the audit is a server-side, owner-only decision like every other sensitive action.
"""
from __future__ import annotations

from .audit import SecurityAudit, SecurityEvent
from .licensing.models import AuditEvent
from .licensing.store import LicenseStore
from .permissions import Permission, PermissionService

MAX_LIMIT = 200
DEFAULT_LIMIT = 50


def _clamp(limit: object) -> int:
    if not isinstance(limit, int) or isinstance(limit, bool):
        return DEFAULT_LIMIT
    return max(1, min(limit, MAX_LIMIT))


class AuditQueryService:
    def __init__(self, licenses: LicenseStore, security: SecurityAudit, permissions: PermissionService):
        self._licenses = licenses
        self._security = security
        self._perm = permissions

    async def license_history(
        self, actor_id, group_id, limit: int = DEFAULT_LIMIT, *, context_chat_id=None
    ) -> list[AuditEvent]:
        """License state changes of `group_id` only (oldest first)."""
        await self._perm.require(actor_id, group_id, Permission.VIEW_AUDIT, context_chat_id=context_chat_id)
        return await self._licenses.audit_for_group(group_id, _clamp(limit))

    async def security_events(
        self, actor_id, group_id, limit: int = DEFAULT_LIMIT, *, context_chat_id=None
    ) -> list[SecurityEvent]:
        """Security events (denials, forged callbacks, delegation/trust/settings changes) of `group_id` only."""
        await self._perm.require(actor_id, group_id, Permission.VIEW_AUDIT, context_chat_id=context_chat_id)
        return await self._security.for_group(group_id, _clamp(limit))
