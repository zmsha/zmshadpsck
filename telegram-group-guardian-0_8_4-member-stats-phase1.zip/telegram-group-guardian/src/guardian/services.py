"""Dependency container injected into aiogram handlers (workflow data key: `services`)."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from datetime import datetime

from .audit import SecurityAudit
from .audit_service import AuditQueryService
from .auth import Authority
from .config import Settings
from .db.pool import Database
from .groups.service import DelegationService, GroupSettingsService, TrustService
from .idempotency import IdempotencyStore
from .licensing.admin import LicenseAdminService
from .licensing.service import LicenseService
from .membership import Notifier
from .moderation.service import SanctionService, WarningService
from .permissions import PermissionService
from .protection.engine import ProtectionEngine
from .telegram_rights import ChatInfoProvider


@dataclass(frozen=True, slots=True)
class Services:
    settings: Settings
    authority: Authority
    license_service: LicenseService
    database: Database
    notifier: Notifier
    started_at: datetime
    # --- Phase 2: security & access layer (all optional-free: always wired by create_app)
    permissions: PermissionService
    license_admin: LicenseAdminService
    delegations: DelegationService
    trust: TrustService
    group_settings: GroupSettingsService
    security_audit: SecurityAudit
    claims: IdempotencyStore
    chat_info: ChatInfoProvider
    audit_query: AuditQueryService
    # --- Phase 3
    protection_engine: ProtectionEngine
    warnings: WarningService
    sanctions: SanctionService
    # --- Phase 3 / part 7 (defaults keep older constructors valid)
    moderation_commands: Any = None  # LazyModerationCommands (same `handle(...)` as ModerationCommandService)
    usernames: Any = None            # VisibleUsers (UsernameResolver)
    # --- Phase 4 / part 2
    bot_trust: Any = None            # BotTrustService (trusted inline/joining bots)
    # --- Phase 4 / part 3
    welcome: Any = None              # WelcomeService (welcome text + join/leave service messages)
    # --- Phase 4 / part 4
    verification: Any = None         # VerificationService (new-member challenge, core)
    # --- Phase 4 / part 5
    newcomers: Any = None            # NewcomerService (new-member restriction window)
    # --- Phase 4 / part 7a
    panel: Any = None                # PanelService (Inline admin panel: signed buttons + press handler)
    # --- Phase 5 / part 5.2
    license_commands: Any = None     # LicenseCommandService (`تفعيل البوت` / `إيقاف البوت` / `حالة البوت`)
    # --- Phase 5 / part 5.3
    owner_panel: Any = None          # OwnerPanelService (private multi-group owner panel, read only)
    # --- Phase 5 / part 5.5
    owner_hub: Any = None            # OwnerHubSender (OWNER_GROUP_ID: safe, redacted, never raises)
    hub_reporter: Any = None         # HubReporter (startup report, statistics, license-change notices)
    # --- Phase 5 / part 5.6
    owner_templates: Any = None      # TemplateCommandService (`/templates`, `/template save|diff|delete`; owner only, preview only)
    # --- Phase 5 / part 5.8
    owner_sandbox: Any = None        # SandboxCommandService (`/sandbox ...`; owner only, simulated, never calls Telegram)
    # --- Phase 6 / part 6.2
    audit_retention: Any = None      # AuditRetentionService (lazy purge of old security-audit rows; license log never purged)
    # --- Phase 6 / part 6.3
    reports: Any = None              # ReportService (stored member reports; no commands until 6.4)
    # --- Phase 6 / part 6.5a
    stats: Any = None                # StatsService (read-only statistics over real data; the `/stats` command is part 6.5b)
    counters: Any = None             # CounterRecorder (best-effort daily counters fed by the engine and the commands)
    # --- Phase 6 / part 6.5b
    owner_backup: Any = None         # BackupCommandService (6.8b: `/backup` in the owner's PRIVATE chat; preview + code, then the file is sent THERE only)
    owner_restore: Any = None        # RestoreCommandService (6.9a: `/restore` in the owner's PRIVATE chat; validates a backup file and PREVIEWS a restore, writes nothing)
    owner_member_stats: Any = None   # MemberStatsCommandService (/userstats /topmembers /groupstats: PRIMARY OWNER only; a refusal is silence)
    member_stats: Any = None         # MemberStatsRecorder (permanent per-member counters; best effort, once per message)
    owner_stats: Any = None          # OwnerStatsService (`/stats` in the owner's PRIVATE chat: all groups; `/stats` in a group is the moderation command)
    # --- Phase 6 / part 6.6a
    report_schedule: Any = None      # ReportScheduleService (periodic-report switches + owed calendar periods; sends nothing until 6.6b)
    # --- Phase 6 / part 6.6b
    periodic_delivery: Any = None    # PeriodicDelivery (sends the owed periodic reports from the update middleware; nothing switches them on yet)
    owner_default_words: Any = None  # part 9.5: DefaultWordsCommandService (`اضافة كلمة افتراضية` ...; owner only, private chat)
    owner_api_check: Any = None      # part 9.6: ApiCheckCommandService (`فحص API` / `/apicheck`; owner only, private chat, read only)
    content_guard: Any = None        # part 9.2: ContentGuard (messages + new-member screening + admin review decisions)
    export_delivery: Any = None      # ExportDelivery (6.7a: private delivery path for exports; `/export settings|license` of 6.7b is its caller)
