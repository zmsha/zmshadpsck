"""Framework-independent glue between Telegram messages and `ModerationCommandService` (Phase 3 / part 7).

Duck-typed on aiogram `Message` objects (no aiogram import) so it is unit-tested with fakes; `bot/routers/moderation.py`
is the thin aiogram layer. Decisions (all covered by tests):
* Only plain TEXT messages of groups/supergroups; edited messages are never executed (the router only registers
  `message`, never `edited_message`).
* Reply target = `reply_to_message.from_user.id`; a reply to an anonymous-admin/channel message carries no user
  (`sender_chat=True`); in forum supergroups the implicit reply to the topic's service message is NOT a reply.
* `text_mention` entities (offset/length are UTF-16 code units) give the target id; the entity must start exactly at
  the first argument, and whatever words it covers collapse to one token so name words never become the reason.
  Arabic aliases are only recognised by the parser with a reply or an @username/numeric id, so they cannot be used
  with a text_mention (use `/ban` for that).
* The service's text is sent as an HTML reply; empty text (duplicate delivery) sends nothing; a failed reply never
  raises or undoes the action.
"""
from __future__ import annotations

import logging
import re
from typing import Any

from ..i18n import pick_language, t
from ..moderation.commands import MAX_ARGS, ParsedCommand, parse_command
from ..moderation.executor import CommandResult
from ..moderation.targets import ReplyInfo

log = logging.getLogger(__name__)
GROUP_TYPES = ("group", "supergroup")
_TOKEN = re.compile(r"\S+")


def _chat_type(message: Any) -> str:
    chat = getattr(message, "chat", None)
    raw = getattr(chat, "type", None)
    return str(getattr(raw, "value", raw) or "")


def is_group_message(message: Any) -> bool:
    return _chat_type(message) in GROUP_TYPES and isinstance(getattr(getattr(message, "chat", None), "id", None), int)


def reply_info(message: Any) -> ReplyInfo | None:
    replied = getattr(message, "reply_to_message", None)
    if replied is None:
        return None
    if getattr(replied, "forum_topic_created", None):
        return None  # topic root service message: Telegram links every topic message to it
    raw_mid = getattr(replied, "message_id", None)
    mid = raw_mid if isinstance(raw_mid, int) and not isinstance(raw_mid, bool) and raw_mid > 0 else None
    if getattr(replied, "sender_chat", None) is not None:
        return ReplyInfo(None, sender_chat=True, message_id=mid)
    user = getattr(replied, "from_user", None)
    uid = getattr(user, "id", None)
    return ReplyInfo(uid if isinstance(uid, int) and not isinstance(uid, bool) else None, sender_chat=False,
                     message_id=mid, is_bot=getattr(user, "is_bot", False) is True)


async def bot_username(bot: Any) -> str | None:
    try:
        return getattr(await bot.me(), "username", None)
    except Exception as exc:
        log.warning("getMe failed (%s)", type(exc).__name__)
        return None  # `/cmd@bot` addressed forms are then ignored; plain `/cmd` still works


async def match_command(message: Any, bot: Any) -> ParsedCommand | None:
    """The moderation command in this message, or None (not a group text message / not a command)."""
    if not is_group_message(message):
        return None
    text = getattr(message, "text", None)
    sender = getattr(message, "from_user", None)
    if not isinstance(text, str) or sender is None or getattr(sender, "is_bot", False):
        return None
    if not text.lstrip().startswith("/"):
        username = None  # Arabic aliases need no bot username: skip the getMe call
    else:
        username = await bot_username(bot)
    return parse_command(text, username, has_reply=reply_info(message) is not None)


def _u16(s: str) -> int:
    return len(s.encode("utf-16-le")) // 2


def resolve_mention(message: Any, parsed: ParsedCommand) -> tuple[ParsedCommand, int | None]:
    """Apply a `text_mention` entity placed on the first argument. Returns (parsed, user_id|None)."""
    text, entities = getattr(message, "text", None), getattr(message, "entities", None) or ()
    n_args = len(parsed.args)
    if not isinstance(text, str) or not entities or n_args == 0 or n_args >= MAX_ARGS:
        return parsed, None
    tokens = list(_TOKEN.finditer(text))
    n_cmd = len(tokens) - n_args
    if n_cmd < 1 or tokens[n_cmd].group() != parsed.args[0]:
        return parsed, None
    spans, pos16, last = [], 0, 0
    for m in tokens:
        pos16 += _u16(text[last:m.start()])
        spans.append((pos16, pos16 + _u16(m.group())))
        pos16, last = spans[-1][1], m.end()
    first_start, first_end = spans[n_cmd]
    for ent in entities:
        kind = str(getattr(getattr(ent, "type", None), "value", getattr(ent, "type", "")))
        user = getattr(ent, "user", None)
        uid = getattr(user, "id", None)
        if kind != "text_mention" or getattr(ent, "offset", None) != first_start:
            continue
        if not isinstance(uid, int) or isinstance(uid, bool) or uid <= 0:
            continue
        end = first_start + int(getattr(ent, "length", 0))
        if end < first_end:
            continue  # does not cover the whole first word
        rest: list[str] = []
        for i in range(n_cmd + 1, len(tokens)):
            s, e = spans[i]
            if e <= end:
                continue  # inside the mention (part of the name)
            if s < end:
                return parsed, None  # the entity ends in the middle of a word: ambiguous, ignore it
            rest.append(tokens[i].group())
        return ParsedCommand(parsed.command, (parsed.args[0], *rest), parsed.arabic), uid
    return parsed, None


async def execute(message: Any, parsed: ParsedCommand, *, protection: Any, services: Any,
                  make_markup: Any = None) -> CommandResult | None:
    sender = message.from_user
    reply = reply_info(message)
    mention_id = None
    if reply is None:
        parsed, mention_id = resolve_mention(message, parsed)
    lang = pick_language(getattr(sender, "language_code", None), services.settings.default_language)
    result = await services.moderation_commands.handle(
        parsed, chat_id=message.chat.id, actor_id=sender.id, message_id=int(message.message_id),
        protection=protection, reply=reply, mention_user_id=mention_id, language=lang)
    if result.text and result.redirect_chat_id is not None:
        await _deliver_to_destination(message, result, lang)
    elif result.text:
        markup = _panel_markup(result, message, sender, lang, services, make_markup)
        try:
            if markup is not None:
                await message.reply(result.text, reply_markup=markup)
            else:
                await message.reply(result.text)
        except Exception as exc:  # the action already happened (or was refused): never raise from here
            log.warning("moderation reply failed (%s)", type(exc).__name__)
    return result


async def _deliver_to_destination(message: Any, result: CommandResult, lang: str) -> None:
    """Part 6.4a: a report listing/details go to the owner-approved chat (they carry reporter ids and reasons). The group
    only gets a one-line notice; if the send fails it says so WITHOUT the content (never falls back to posting it here)."""
    sent = False
    try:
        await message.bot.send_message(result.redirect_chat_id, result.text)
        sent = True
    except Exception as exc:
        log.warning("report destination send failed (%s)", type(exc).__name__)
    try:
        await message.reply(t("report_dest_sent" if sent else "report_dest_failed", lang))
    except Exception as exc:
        log.warning("moderation reply failed (%s)", type(exc).__name__)


def _panel_markup(result: CommandResult, message: Any, sender: Any, lang: str, services: Any, make_markup: Any) -> Any:
    """The `/panel` keyboard, bound to the sender and this group; None => plain text (no panel service, or any failure)."""
    panel = getattr(services, "panel", None)
    if not result.panel or panel is None or make_markup is None:
        return None
    try:
        return make_markup(panel.home_buttons(message.chat.id, sender.id, lang))
    except Exception:
        log.error("panel keyboard failed", exc_info=True)
        return None


def observe_users(store: Any, message: Any, protection: Any) -> None:
    """Feed the visible-users store from a message, only where protection is currently licensed (data minimisation)."""
    if store is None or protection is None or not getattr(protection, "allowed", False) or not is_group_message(message):
        return
    chat_id = message.chat.id
    people = [getattr(message, "from_user", None), getattr(getattr(message, "reply_to_message", None), "from_user", None)]
    people += list(getattr(message, "new_chat_members", None) or ())
    for person in people:
        if person is not None and not getattr(person, "is_bot", False):
            store.observe(chat_id, getattr(person, "id", None), getattr(person, "username", None))
