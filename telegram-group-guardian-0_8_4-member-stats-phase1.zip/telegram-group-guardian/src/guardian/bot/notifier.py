"""aiogram adapter implementing membership.Notifier (best-effort delivery)."""
from __future__ import annotations

from aiogram import Bot


class TelegramNotifier:
    def __init__(self, bot: Bot, owner_telegram_id: int):
        self._bot = bot
        self._owner_id = owner_telegram_id

    async def notify_group(self, group_id: int, text: str) -> None:
        await self._bot.send_message(group_id, text)

    async def notify_owner(self, text: str) -> None:
        # Only reaches the owner if they have started the bot in private.
        await self._bot.send_message(self._owner_id, text)
