"""Official Telegram command menus (`setMyCommands`). Arabic aliases (`حظر`, `كتم`...) are NOT Telegram commands
(the menu only allows [a-z0-9_]{1,32}) so they are handled by the message parser and are not listed here.

Pure data + a thin registrar (aiogram imported lazily). Moderation commands are shown to chat administrators only;
that is a UX hint, never an authorization (the server checks permissions on every command)."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

log = logging.getLogger(__name__)

BASIC = ("start", "help", "status")
PUBLIC = ("id", "admins", "report")  # part 3.5-1: any member of a licensed group
MODERATION = ("ban", "unban", "mute", "unmute", "kick", "warn", "warnings", "clearwarns", "info", "pin", "unpin", "purge",
              "lock", "unlock", "slowmode", "antiflood", "protect", "trust", "untrust", "trusted", "welcome", "verify", "newbie", "settings", "panel", "reports", "stats", "export")

DESCRIPTIONS: dict[str, dict[str, str]] = {
    "en": {
        "start": "Welcome message", "help": "Help", "status": "Bot / license status",
        "ban": "Ban a member (reply or id, optional duration)", "unban": "Unban a member",
        "mute": "Mute a member (optional duration)", "unmute": "Unmute a member",
        "kick": "Remove a member (they may rejoin)", "warn": "Warn a member",
        "warnings": "Show a member's warnings", "clearwarns": "Clear a member's warnings",
        "info": "Show a member's moderation info", "pin": "Pin the replied-to message (optional: silent)",
        "unpin": "Unpin a message (reply) or the latest pinned one", "purge": "Delete recent messages (reply or count 1-100)", "id": "Show your ID and the group ID",
        "lock": "Lock message types for members (all, text, media, stickers, polls, previews)",
        "unlock": "Unlock message types for members", "slowmode": "Bot slow mode: min seconds between a member's messages",
        "antiflood": "Flood protection: on, off or N [seconds]", "protect": "Show/change protection settings",
        "trust": "Trust a member, domain or bot (reply, @user, domain X, bot ID)", "untrust": "Remove a member, domain or bot from the trust list",
        "trusted": "Show the trust lists and what each entry skips",
        "welcome": "Welcome message settings (on, off, set, reset, vars...)",
        "verify": "New-member verification settings (on, off, method, timeout...)",
        "newbie": "New-member restrictions (window, links, media, messages)",
        "settings": "Show all of the group's settings",
        "panel": "Open the admin button panel",
        "reports": "Reports: list (/reports) or manage: /report show|take|resolve|dismiss|type|priority N",
        "stats": "Group statistics: /stats [day|week|month]",
        "export": "Export a file to your private chat: /export settings|reports|audit (owner: also license)",
        "admins": "List the group admins", "report": "Report a message to the admins (reply to it)",
    },
    "ar": {
        "start": "رسالة الترحيب", "help": "المساعدة", "status": "حالة البوت / الترخيص",
        "ban": "حظر عضو (بالرد أو المعرّف، ومدة اختيارية)", "unban": "رفع الحظر عن عضو",
        "mute": "كتم عضو (ومدة اختيارية)", "unmute": "فك كتم عضو",
        "kick": "طرد عضو (يمكنه العودة)", "warn": "تحذير عضو",
        "warnings": "عرض تحذيرات عضو", "clearwarns": "مسح تحذيرات عضو",
        "info": "معلومات الإشراف عن عضو", "pin": "تثبيت الرسالة المردود عليها (اختياري: صامت)",
        "unpin": "إلغاء تثبيت رسالة (بالرد) أو آخر رسالة مثبّتة", "purge": "حذف آخر الرسائل (بالرد أو بعدد 1-100)", "id": "عرض معرّفك ومعرّف المجموعة",
        "lock": "قفل أنواع الرسائل على الأعضاء (الكل، النص، الوسائط، الملصقات، الاستطلاعات، المعاينات)",
        "unlock": "فتح أنواع الرسائل للأعضاء", "slowmode": "الوضع البطيء (من البوت): أقل فاصل بين رسائل العضو",
        "antiflood": "مكافحة الفيضان: تشغيل أو إيقاف أو عدد [ثواني]", "protect": "عرض/تغيير إعدادات الحماية",
        "trust": "توثيق عضو أو نطاق أو بوت (بالرد أو @user أو domain X أو bot ID)", "untrust": "إزالة عضو أو نطاق أو بوت من قائمة الثقة",
        "trusted": "عرض قوائم الثقة وما يتجاوزه كل استثناء",
        "welcome": "إعدادات الترحيب (on وoff وset وreset وvars...)",
        "verify": "إعدادات التحقق من الأعضاء الجدد (on وoff وmethod وtimeout...)",
        "newbie": "قيود الأعضاء الجدد (المدة والروابط والوسائط والرسائل)",
        "settings": "عرض كل إعدادات المجموعة",
        "panel": "فتح لوحة الأزرار للمشرف",
        "reports": "البلاغات: القائمة (/reports) أو الإدارة: /report show|take|resolve|dismiss|type|priority رقم",
        "stats": "إحصائيات المجموعة: /stats [day|week|month]",
        "export": "تصدير ملف إلى خاصك: /export settings|reports|audit (والمالك أيضًا license)",
        "admins": "عرض مشرفي المجموعة", "report": "إبلاغ المشرفين عن رسالة (بالرد عليها)",
    },
}


@dataclass(frozen=True, slots=True)
class MenuSpec:
    scope: str                     # "default" | "all_chat_administrators"
    language_code: str | None      # None = default list (English)
    commands: tuple[tuple[str, str], ...]


def build_menus() -> list[MenuSpec]:
    menus: list[MenuSpec] = []
    for scope, names in (("default", BASIC + PUBLIC), ("all_chat_administrators", BASIC + PUBLIC + MODERATION)):
        for lang_code, texts in (("en", None), ("ar", "ar")):
            table = DESCRIPTIONS["en" if texts is None else "ar"]
            menus.append(MenuSpec(scope, None if lang_code == "en" else "ar", tuple((n, table[n]) for n in names)))
    return menus


async def register_commands(bot: Any) -> int:
    """Best effort: returns how many menus were registered; failures are logged (type only) and never raise."""
    from aiogram.types import BotCommand, BotCommandScopeAllChatAdministrators, BotCommandScopeDefault

    done = 0
    for spec in build_menus():
        scope = BotCommandScopeDefault() if spec.scope == "default" else BotCommandScopeAllChatAdministrators()
        try:
            await bot.set_my_commands([BotCommand(command=c, description=d) for c, d in spec.commands],
                                      scope=scope, language_code=spec.language_code)
            done += 1
        except Exception as exc:
            log.error("setMyCommands failed (%s) scope=%s lang=%s", type(exc).__name__, spec.scope, spec.language_code)
    return done
