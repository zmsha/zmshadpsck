"""Central aiogram error handler: log with a trace id, reply generically, never leak internals."""
from __future__ import annotations

import logging
import uuid

from aiogram.types import ErrorEvent

from ...i18n import t
from ...services import Services

log = logging.getLogger(__name__)


async def on_error(event: ErrorEvent, services: Services) -> bool:
    trace_id = uuid.uuid4().hex[:8]
    log.error("unhandled error in update handler trace_id=%s", trace_id, exc_info=event.exception)
    message = event.update.message
    if message is not None and message.chat.type == "private":
        try:
            await message.answer(t("error_generic", services.settings.default_language, trace_id=trace_id))
        except Exception:
            log.warning("could not send error reply trace_id=%s", trace_id)
    return True  # handled; never propagate to Telegram as a failure
