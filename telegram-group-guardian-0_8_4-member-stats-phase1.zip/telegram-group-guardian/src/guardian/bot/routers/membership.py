"""my_chat_member adapter: registers groups as PENDING when the bot is added."""
from __future__ import annotations

import logging

from aiogram import Router
from aiogram.types import ChatMemberUpdated

from ...membership import handle_bot_added, was_bot_added
from ...services import Services

log = logging.getLogger(__name__)
router = Router(name="membership")


def _status(value: object) -> str:
    return str(getattr(value, "value", value))


@router.my_chat_member()
async def on_my_chat_member(event: ChatMemberUpdated, services: Services) -> None:
    chat = event.chat
    if chat.type not in ("group", "supergroup"):
        return
    old_status = _status(event.old_chat_member.status)
    new_status = _status(event.new_chat_member.status)
    if was_bot_added(old_status, new_status):
        await handle_bot_added(
            services.license_service,
            services.notifier,
            group_id=chat.id,
            title=chat.title,
            language=services.settings.default_language,
            audit=services.security_audit,
        )
    else:
        # Removal never changes the license (spec): only log it.
        log.info("bot membership changed", extra={"group_id": chat.id, "old": old_status, "new": new_status})
