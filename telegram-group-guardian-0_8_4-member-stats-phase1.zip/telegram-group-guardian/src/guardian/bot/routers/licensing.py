"""Group license commands (`تفعيل البوت [مدة]`, `إيقاف البوت`, `حالة البوت`, `/activate`, `/deactivate`).
Thin aiogram layer: the filter only matches those commands (so it never shadows other handlers); all decisions are made
server-side in `licensing/commands.py`. Only `message` is registered, so edited messages never execute a command."""
from __future__ import annotations

from aiogram import Bot, Router
from aiogram.types import Message

from ...services import Services
from .. import license_handler as h

router = Router(name="licensing")


async def _is_license_command(message: Message, bot: Bot):
    parsed = await h.match_command(message, bot)
    return {"license_command": parsed} if parsed is not None else False


@router.message(_is_license_command)
async def on_license_command(message: Message, services: Services, license_command) -> None:
    await h.execute(message, license_command, services=services)
