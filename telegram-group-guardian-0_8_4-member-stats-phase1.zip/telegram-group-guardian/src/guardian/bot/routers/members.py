"""Join / leave service messages (welcome + service-message control, phase 4.3). Thin aiogram layer: only `message`
updates (an edit can never trigger a welcome); logic lives in `bot/members_handler.py`."""
from __future__ import annotations

from aiogram import F, Router
from aiogram.types import CallbackQuery, Message

from ...protection_gate import ProtectionContext
from ...services import Services
from .. import members_handler as h

router = Router(name="members")


@router.message(F.new_chat_members)
async def on_new_members(message: Message, services: Services, protection: ProtectionContext | None = None) -> None:
    await h.on_new_members(message, protection, services)


@router.message(F.left_chat_member)
async def on_left_member(message: Message, services: Services, protection: ProtectionContext | None = None) -> None:
    await h.on_left_member(message, protection, services)


@router.callback_query(F.data.startswith("vf:"))
async def on_verify_callback(query: CallbackQuery, services: Services) -> None:
    result = await h.on_verify_callback(query, services)
    try:
        if result is None:
            await query.answer()
        else:
            await query.answer(result[0], show_alert=result[1])
    except Exception:
        h.log.warning("could not answer the verification callback")


@router.callback_query(F.data.startswith("cf:"))
async def on_content_review_callback(query: CallbackQuery, services: Services) -> None:
    result = await h.on_content_review_callback(query, services)
    try:
        if result is None:
            await query.answer()
            return
        await query.answer(result[0], show_alert=result[1])
        message = getattr(query, "message", None)
        if not result[1] and message is not None:  # decided now: remove the buttons so nobody presses them again
            await message.edit_reply_markup(reply_markup=None)
    except Exception:
        h.log.warning("could not answer the content review callback")
