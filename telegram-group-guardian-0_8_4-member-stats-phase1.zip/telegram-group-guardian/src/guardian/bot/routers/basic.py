"""/start, /help, /status (+ their Arabic aliases, part 9.3). Thin adapter: logic lives in i18n/licensing/auth and in
`bot/basic_commands.py` (the pure Arabic-alias parser)."""
from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command, CommandStart
from aiogram.types import Message

from ... import __version__
from ...auth import Role
from ...i18n import license_label, pick_language, t
from ...licensing.models import DenyReason, LicenseStatus
from ...services import Services
from ...time_utils import format_display
from ..basic_commands import COMMANDS, HELP, START, STATUS, parse_basic_command

router = Router(name="basic")

_GROUP_TYPES = ("group", "supergroup")


def _lang(message: Message, services: Services) -> str:
    code = message.from_user.language_code if message.from_user else None
    return pick_language(code, services.settings.default_language)


@router.message(CommandStart())
async def cmd_start(message: Message, services: Services) -> None:
    lang = _lang(message, services)
    name = message.from_user.full_name if message.from_user else ""
    key = "start_private" if message.chat.type == "private" else "start_group"
    await message.answer(t(key, lang, name=name))


@router.message(Command("help"))
async def cmd_help(message: Message, services: Services) -> None:
    await message.answer(t("help", _lang(message, services)))


async def send_all_commands(message: Message, services: Services) -> None:
    """`الاوامر`: every command. The owner's commands are added for the owner in the PRIVATE chat only (a hint, not authorization:
    the server checks every command again)."""
    lang = _lang(message, services)
    await message.answer(t("commands_all", lang))
    user_id = message.from_user.id if message.from_user else None
    if message.chat.type == "private" and services.authority.role_of(user_id) is Role.OWNER:
        await message.answer(t("commands_owner", lang))


@router.message(Command("commands"))
async def cmd_commands(message: Message, services: Services) -> None:
    """English twin of `الاوامر` (part 9.6): every command, plus the owner's section for the owner in the private chat."""
    await send_all_commands(message, services)


@router.message(Command("status"))
async def cmd_status(message: Message, services: Services) -> None:
    lang = _lang(message, services)
    chat = message.chat
    if chat.type == "private":
        user_id = message.from_user.id if message.from_user else None
        if services.authority.role_of(user_id) is Role.OWNER:
            settings = services.settings
            await message.answer(
                t(
                    "status_private_owner",
                    lang,
                    version=__version__,
                    environment=settings.environment,
                    database=t(f"db_{services.database.last_known_status}", lang),
                    webhook=t("webhook_on" if settings.webhook_register_on_startup else "webhook_off", lang),
                    timezone=settings.display_timezone,
                )
            )
        else:
            await message.answer(t("status_private_user", lang, version=__version__))
        return

    if chat.type in _GROUP_TYPES:
        # Read-only query about THIS chat only; it never changes a license.
        decision, license_ = await services.license_service.status_report(chat.id)
        if decision.reason is DenyReason.STORE_UNAVAILABLE:
            await message.answer(t("status_group_store_error", lang))
        elif license_ is None:
            await message.answer(t("status_group_unregistered", lang))
        else:
            status: LicenseStatus = decision.status or license_.status
            if decision.allowed and status is LicenseStatus.ACTIVE_PERMANENT:
                details = t("detail_permanent", lang)
            elif decision.allowed and license_.expires_at is not None:
                when = format_display(license_.expires_at, services.settings.display_timezone)
                details = t("detail_expires", lang, when=when)
            else:
                details = t("detail_protection_off", lang)
            await message.answer(t("status_group", lang, status=license_label(status, lang), details=details))


async def _is_arabic_basic(message: Message):
    """Arabic alias of /start /help /status (the whole message only; the parser decides what is accepted where)."""
    sender = message.from_user
    if sender is None or getattr(sender, "is_bot", False) or message.chat.type not in ("private", *_GROUP_TYPES):
        return False
    name = parse_basic_command(message.text, private=message.chat.type == "private")
    return {"basic_command": name} if name is not None else False


@router.message(_is_arabic_basic)
async def on_arabic_basic(message: Message, services: Services, basic_command: str) -> None:
    if basic_command == START:
        await cmd_start(message, services)
    elif basic_command == HELP:
        await cmd_help(message, services)
    elif basic_command == COMMANDS:
        await send_all_commands(message, services)
    elif basic_command == STATUS:
        await cmd_status(message, services)
