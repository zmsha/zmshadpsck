"""Owner panel (phase 5.3): `/owner` + `لوحة المالك` in the owner's PRIVATE chat, and `ow:` callbacks (5.6: also `/templates` + `/template ...`). Thin aiogram layer;
every decision is made server-side in `owner_panel/service.py` (see `bot/owner_panel_handler.py`)."""
from __future__ import annotations

from aiogram import Bot, F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from ...services import Services
from .. import owner_panel_handler as h

router = Router(name="owner_panel")


def make_markup(rows) -> InlineKeyboardMarkup:
    """Rows of (label, callback_data) -> Inline Keyboard (never a Reply Keyboard)."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=label, callback_data=data) for label, data in row] for row in rows])


async def _is_owner_command(message: Message, bot: Bot):
    parsed = await h.match_command(message, bot)
    return {"owner_command": parsed} if parsed is not None else False


@router.message(_is_owner_command)
async def on_owner_command(message: Message, services: Services, owner_command) -> None:
    await h.execute(message, owner_command, services=services, make_markup=make_markup)


async def _is_template_command(message: Message, bot: Bot):
    parsed = await h.match_template_command(message, bot)
    return {"template_command": parsed} if parsed is not None else False


@router.message(_is_template_command)
async def on_template_command(message: Message, services: Services, template_command) -> None:
    await h.execute_template(message, template_command, services=services)


async def _is_default_words_command(message: Message, bot: Bot):
    parsed = await h.match_default_words_command(message, bot)
    return {"default_words_command": parsed} if parsed is not None else False


@router.message(_is_default_words_command)
async def on_default_words_command(message: Message, services: Services, default_words_command) -> None:
    await h.execute_default_words(message, default_words_command, services=services)


async def _is_api_check_command(message: Message, bot: Bot):
    parsed = await h.match_api_check_command(message, bot)
    return {"api_check_command": parsed} if parsed is not None else False


@router.message(_is_api_check_command)
async def on_api_check_command(message: Message, services: Services, api_check_command) -> None:
    await h.execute_api_check(message, api_check_command, services=services)


async def _is_sandbox_command(message: Message, bot: Bot):
    parsed = await h.match_sandbox_command(message, bot)
    return {"sandbox_command": parsed} if parsed is not None else False


@router.message(_is_sandbox_command)
async def on_sandbox_command(message: Message, services: Services, sandbox_command) -> None:
    await h.execute_sandbox(message, sandbox_command, services=services)


async def _is_stats_command(message: Message, bot: Bot):
    parsed = await h.match_stats_command(message, bot)
    return {"stats_command": parsed} if parsed is not None else False


@router.message(_is_stats_command)
async def on_stats_command(message: Message, services: Services, stats_command) -> None:
    await h.execute_stats(message, stats_command, services=services)


async def _is_member_stats_command(message: Message, bot: Bot):
    parsed = await h.match_member_stats_command(message, bot)
    return {"member_stats_command": parsed} if parsed is not None else False


@router.message(_is_member_stats_command)
async def on_member_stats_command(message: Message, services: Services, member_stats_command) -> None:
    await h.execute_member_stats(message, member_stats_command, services=services)


async def _is_backup_command(message: Message, bot: Bot):
    parsed = await h.match_backup_command(message, bot)
    return {"backup_command": parsed} if parsed is not None else False


@router.message(_is_backup_command)
async def on_backup_command(message: Message, services: Services, backup_command) -> None:
    await h.execute_backup(message, backup_command, services=services)


async def _is_restore_command(message: Message, bot: Bot):
    parsed = await h.match_restore_command(message, bot)
    return {"restore_command": parsed} if parsed is not None else False


@router.message(_is_restore_command)
async def on_restore_command(message: Message, services: Services, restore_command) -> None:
    await h.execute_restore(message, restore_command, services=services)


@router.callback_query(F.data.startswith("ow:"))
async def on_owner_callback(query: CallbackQuery, services: Services) -> None:
    result = await h.on_owner_callback(query, services, make_markup)
    try:
        if result is None:
            await query.answer()
        else:
            await query.answer(result[0] or None, show_alert=result[1])
    except Exception:
        h.log.warning("could not answer the owner panel callback")
