"""Moderation commands (/ban /unban /mute /unmute /kick /warn /warnings /clearwarns + Arabic aliases).
Thin aiogram layer: the filter only matches real moderation commands (so it never shadows other handlers) and
returns the parsed command; all logic lives in `bot/moderation_handler.py`. Only `message` is registered, so edited
messages never execute a command."""
from __future__ import annotations

from aiogram import Bot, Router
from aiogram.types import Message

from ...protection_gate import ProtectionContext
from ...services import Services
from .. import moderation_handler as h
from .panel import make_markup

router = Router(name="moderation")


async def _is_moderation_command(message: Message, bot: Bot):
    parsed = await h.match_command(message, bot)
    return {"parsed_command": parsed} if parsed is not None else False


@router.message(_is_moderation_command)
async def on_moderation_command(message: Message, services: Services, parsed_command, protection: ProtectionContext | None = None) -> None:
    await h.execute(message, parsed_command, protection=protection, services=services, make_markup=make_markup)
