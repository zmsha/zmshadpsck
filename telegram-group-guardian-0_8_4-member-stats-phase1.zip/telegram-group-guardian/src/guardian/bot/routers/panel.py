"""Inline admin panel callbacks (phase 4.7a). Thin aiogram layer: only `callback_query` with our `pn:` prefix; all
decisions are made server-side in `panel/service.py` (see `bot/panel_handler.py`)."""
from __future__ import annotations

from aiogram import F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

from ...services import Services
from .. import panel_handler as h

router = Router(name="panel")


def make_markup(rows) -> InlineKeyboardMarkup:
    """Rows of (label, callback_data) -> Inline Keyboard (never a Reply Keyboard)."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=label, callback_data=data) for label, data in row] for row in rows])


@router.callback_query(F.data.startswith("pn:"))
async def on_panel_callback(query: CallbackQuery, services: Services) -> None:
    result = await h.on_panel_callback(query, services, make_markup)
    try:
        if result is None:
            await query.answer()
        else:
            await query.answer(result[0] or None, show_alert=result[1])
    except Exception:
        h.log.warning("could not answer the panel callback")
