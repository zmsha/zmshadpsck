"""Framework-independent glue between Telegram callback queries and `panel.service.PanelService` (phase 4.7a).

Duck-typed on aiogram `CallbackQuery` objects (no aiogram import) so it is unit-tested with fakes; `bot/routers/panel.py`
is the thin aiogram layer and supplies `make_markup` (rows of (label, callback_data) -> InlineKeyboardMarkup).

The group is the chat of the PRESSED message and the presser is Telegram's `from_user`; neither is ever read from the
callback data. Everything the service decides is applied here: toast, in-place edit of the panel message, or delete.
A failed edit/delete (message too old, "not modified", bot lost the right) never raises and never retries.
"""
from __future__ import annotations

import logging
from typing import Any, Callable

from ..i18n import pick_language, t

log = logging.getLogger(__name__)


async def on_panel_callback(query: Any, services: Any, make_markup: Callable[[Any], Any]) -> tuple[str, bool] | None:
    """-> (toast text, show_alert) for `callback.answer`, or None for a callback that is not ours / malformed."""
    panel = getattr(services, "panel", None)
    message = getattr(query, "message", None)
    chat = getattr(message, "chat", None)
    ctype = str(getattr(getattr(chat, "type", None), "value", getattr(chat, "type", "")) or "")
    presser = getattr(query, "from_user", None)
    lang = pick_language(getattr(presser, "language_code", None), services.settings.default_language)
    if panel is None:
        return None
    try:
        outcome = await panel.press(getattr(chat, "id", None), ctype, getattr(presser, "id", None),
                                    getattr(query, "data", None), lang, getattr(query, "id", None),
                                    getattr(message, "date", None))
    except Exception:
        log.error("panel press failed", exc_info=True)
        return t("pn_unavailable", lang), True
    if outcome is None:
        return None
    if outcome.delete:
        try:
            await message.delete()
        except Exception as exc:
            log.warning("panel close failed (%s)", type(exc).__name__)
    elif outcome.text is not None:
        try:
            markup = make_markup(outcome.buttons) if outcome.buttons else None
            await message.edit_text(outcome.text, reply_markup=markup)
        except Exception as exc:  # includes "message is not modified" when nothing changed
            log.warning("panel refresh edit failed (%s)", type(exc).__name__)
    return outcome.toast, outcome.alert
