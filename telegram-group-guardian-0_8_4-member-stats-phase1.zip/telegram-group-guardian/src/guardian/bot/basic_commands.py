"""Arabic aliases for the basic commands `/start`, `/help` and `/status` (part 9.3) and the full list `الاوامر` (part 9.5).

Pure text logic (no aiogram, no Telegram call, no I/O) so it is unit-tested directly; `bot/routers/basic.py` is the thin
aiogram layer that turns a match into the same reply the slash command gives.

Arabic words are not Telegram commands (the command menu only allows [a-z0-9_]), so they are plain message text. To keep
ordinary chat from ever being taken for a command:

* an alias is accepted only when it is the WHOLE message (no extra words);
* in the PRIVATE chat the short everyday words work (`مساعدة`, `ابدأ`, `حالة البوت`);
* in a GROUP only distinctive phrases work (`قائمة الاوامر`, `اوامر البوت`, `ابدأ البوت`), because a lone `مساعدة` in a group is
  usually a person asking the others for help, not a request for the bot's help text.

`حالة البوت` inside a group is the licence status command (`licensing/commands.py`, an earlier router), so it is not repeated
here: this module only adds the private-chat `/status` (bot status) in Arabic.
"""
from __future__ import annotations

from ..moderation.arabic import fold_arabic

MAX_COMMAND_LEN = 60

START = "start"
HELP = "help"
STATUS = "status"
COMMANDS = "commands"   # part 9.5: `الاوامر` = the full list of every command (everywhere, whole message only)


def _words(*phrases: str) -> frozenset[str]:
    return frozenset(" ".join(fold_arabic(p).split()) for p in phrases)


# Accepted in the private chat AND in groups (distinctive enough not to be ordinary chat).
_EVERYWHERE = {
    START: _words("ابدأ البوت", "بدء البوت"),
    HELP: _words("قائمة الأوامر", "أوامر البوت", "مساعدة البوت"),
    COMMANDS: _words("الأوامر", "كل الأوامر", "جميع الأوامر"),
}
# Accepted in the private chat only (short everyday words).
_PRIVATE_ONLY = {
    START: _words("ابدأ", "بدء", "البداية"),
    HELP: _words("مساعدة", "المساعدة", "ساعدني"),
    COMMANDS: _words("أوامر"),
    STATUS: _words("حالة البوت", "الحالة", "حالة"),
}


def parse_basic_command(text: object, *, private: bool) -> str | None:
    """`start` | `help` | `status` for an Arabic alias that is the whole message, else None (never raises)."""
    if not isinstance(text, str):
        return None
    stripped = text.strip()
    if not stripped or len(stripped) > MAX_COMMAND_LEN or stripped.startswith("/"):
        return None
    folded = " ".join(fold_arabic(stripped).split())
    for table in ((_EVERYWHERE, _PRIVATE_ONLY) if private else (_EVERYWHERE,)):
        for command, phrases in table.items():
            if folded in phrases:
                return command
    return None
