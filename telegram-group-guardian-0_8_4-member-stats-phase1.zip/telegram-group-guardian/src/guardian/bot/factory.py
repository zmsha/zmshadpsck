"""Construction of Bot and Dispatcher (webhook mode only; polling is intentionally not wired)."""
from __future__ import annotations

import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from ..protection_gate import ProtectionGate
from ..services import Services
from ..trace import TraceMiddleware
from .middlewares import ProtectionGateMiddleware
from . import moderation_handler
from .routers import basic, errors, licensing, members, membership, moderation, owner_panel, panel


log = logging.getLogger(__name__)


def create_bot(token: str) -> Bot:
    return Bot(token=token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))


def create_dispatcher(services: Services) -> Dispatcher:
    dp = Dispatcher(services=services)  # extra kwargs become handler-injectable workflow data
    dp.errors.register(errors.on_error)
    dp.update.outer_middleware(TraceMiddleware())  # part 6.1: one trace id per update, read by the audit layer
    gate = ProtectionGate(
        services.license_service, services.permissions, services.notifier, language=services.settings.default_language,
        audit=services.security_audit,
    )
    # Outer middleware: runs before any handler/filter, injects `protection`, and (Part 2) applies the
    # automatic protection engine only when the license allows it. It never blocks owner/status paths.
    observer = (lambda event, ctx: moderation_handler.observe_users(services.usernames, event, ctx))
    verification = getattr(services, "verification", None)
    retention = getattr(services, "audit_retention", None)
    ticks = [x.tick for x in (verification, retention) if x is not None]  # expired challenges + audit retention (6.2): both catch up after a Render sleep

    async def tick():
        for one in ticks:  # each tick is throttled and never raises; one failing must not skip the other
            try:
                await one()
            except Exception:
                log.error("background tick failed", exc_info=True)

    tick = tick if ticks else None
    delivery = getattr(services, "periodic_delivery", None)
    # Part 6.6b: periodic reports ride on group messages; the hook only schedules a background task and receives the
    # gate's verdict, so nothing is sent while the licence is inactive.
    group_tick = ((lambda event, ctx: delivery.on_update(getattr(event, "bot", None), ctx.chat_id, ctx.allowed))
                  if delivery is not None else None)
    content_guard = getattr(services, "content_guard", None)  # part 9.2: runs before the engine
    dp.message.outer_middleware(ProtectionGateMiddleware(gate, services.protection_engine, observer=observer, tick=tick,
                                                         group_tick=group_tick, content_guard=content_guard,
                                                         member_stats=getattr(services, "member_stats", None)))
    dp.edited_message.outer_middleware(ProtectionGateMiddleware(gate, services.protection_engine, is_edit=True,
                                                                content_guard=content_guard))
    dp.include_router(membership.router)
    dp.include_router(members.router)  # join/leave service messages only (F.new_chat_members / F.left_chat_member)
    dp.include_router(panel.router)  # callback_query `pn:` only (admin panel)
    dp.include_router(owner_panel.router)  # `/owner` in the owner's private chat + `ow:` callbacks only
    dp.include_router(licensing.router)  # filter-gated: only the license commands (owner activation / status)
    dp.include_router(basic.router)
    dp.include_router(moderation.router)  # filter-gated: only real moderation commands; keep new routers BEFORE or after freely
    return dp
