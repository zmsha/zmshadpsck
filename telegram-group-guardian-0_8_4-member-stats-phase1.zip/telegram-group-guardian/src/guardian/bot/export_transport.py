"""aiogram adapter of `export.delivery.ExportTransport` (thin). The target is ALWAYS the requester's user id (their private
chat); an unreachable private chat is reported as `PrivateChatUnavailable` so the caller can say "start the bot first"."""
from __future__ import annotations

from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.types import BufferedInputFile

from ..export.models import PrivateChatUnavailable


class AiogramExportTransport:
    def __init__(self, bot: Bot):
        self._bot = bot

    async def send_document(self, user_id: int, filename: str, data: bytes, caption: str | None) -> None:
        try:
            await self._bot.send_document(user_id, BufferedInputFile(data, filename=filename), caption=caption)
        except TelegramForbiddenError as exc:       # the user never started the bot / blocked it
            raise PrivateChatUnavailable() from exc
        except TelegramBadRequest as exc:
            if "chat not found" in str(exc).lower():
                raise PrivateChatUnavailable() from exc
            raise
