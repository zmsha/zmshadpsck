"""Framework-independent glue between Telegram updates and `owner_panel.service.OwnerPanelService` (phase 5.3; 5.4 passes `callback_query.id`, the idempotency key of an action press).

Duck-typed on aiogram objects (no aiogram import) so it is unit-tested with fakes; `bot/routers/owner_panel.py` is the thin
aiogram layer. The chat is the chat of the message and the actor is Telegram's `from_user`; nothing is read from text/data
for identity. Replies to a refused or non-owner user are silence (or a toast): nothing to learn, nothing to spam."""
from __future__ import annotations

import logging
from typing import Any, Callable

from ..i18n import pick_language, t
from ..backup.command import ParsedBackupCommand, parse_backup_command
from ..backup.restore_command import ParsedRestoreCommand, parse_restore_command
from ..backup.restore_service import DocumentRef
from ..member_stats.commands import ParsedMemberStats, parse_member_stats_command
from ..owner_panel.api_check_commands import ParsedApiCheck, parse_api_check_command
from ..owner_panel.command import ParsedOwnerCommand, parse_owner_command
from ..owner_panel.default_words_commands import ParsedDefaultWords, parse_default_words_command
from ..owner_panel.sandbox_commands import ParsedSandboxCommand, parse_sandbox_command
from ..owner_panel.template_commands import ParsedTemplateCommand, parse_template_command
from ..stats import owner_command as stats_owner
from . import moderation_handler as mh

log = logging.getLogger(__name__)


def _chat_type(obj: Any) -> str:
    return mh._chat_type(obj)


async def match_command(message: Any, bot: Any) -> ParsedOwnerCommand | None:
    """Only plain text of a PRIVATE chat from a real (non-bot) sender: groups never see the owner panel command."""
    text = getattr(message, "text", None)
    sender = getattr(message, "from_user", None)
    if _chat_type(message) != "private" or not isinstance(text, str) or sender is None or getattr(sender, "is_bot", False):
        return None
    username = await mh.bot_username(bot) if text.lstrip().startswith("/") else None
    return parse_owner_command(text, username)


async def match_sandbox_command(message: Any, bot: Any) -> ParsedSandboxCommand | None:
    """5.8: `/sandbox ...` and `تجربة ...` in a PRIVATE chat from a real (non-bot) sender."""
    text = getattr(message, "text", None)
    sender = getattr(message, "from_user", None)
    if _chat_type(message) != "private" or not isinstance(text, str) or sender is None or getattr(sender, "is_bot", False):
        return None
    username = await mh.bot_username(bot) if text.lstrip().startswith("/") else None
    return parse_sandbox_command(text, username)


async def execute_sandbox(message: Any, parsed: ParsedSandboxCommand, *, services: Any) -> str | None:
    service = getattr(services, "owner_sandbox", None)
    sender = getattr(message, "from_user", None)
    if service is None or sender is None:
        return None
    lang = pick_language(getattr(sender, "language_code", None), services.settings.default_language)
    try:
        reply = await service.run(parsed, chat_id=getattr(getattr(message, "chat", None), "id", None),
                                  chat_type=_chat_type(message), user_id=sender.id, lang=lang)
    except Exception:
        log.error("sandbox command failed", exc_info=True)
        return None
    if reply is None:
        return None
    try:
        await message.answer(reply.text)
    except Exception as exc:
        log.warning("sandbox reply send failed (%s)", type(exc).__name__)
    return reply.status


async def match_stats_command(message: Any, bot: Any):
    """6.5b: `/stats` and `الاحصائيات` in a PRIVATE chat from a real (non-bot) sender (the owner's all-groups view)."""
    text = getattr(message, "text", None)
    sender = getattr(message, "from_user", None)
    if _chat_type(message) != "private" or not isinstance(text, str) or sender is None or getattr(sender, "is_bot", False):
        return None
    username = await mh.bot_username(bot) if text.lstrip().startswith("/") else None
    return stats_owner.match(text, username)


async def execute_stats(message: Any, parsed: Any, *, services: Any) -> str | None:
    """-> the reply status or None when nothing was answered (not the owner, no service, send failed)."""
    service = getattr(services, "owner_stats", None)
    sender = getattr(message, "from_user", None)
    if service is None or sender is None:
        return None
    lang = pick_language(getattr(sender, "language_code", None), services.settings.default_language)
    try:
        reply = await service.run(parsed, chat_id=getattr(getattr(message, "chat", None), "id", None),
                                  chat_type=_chat_type(message), user_id=sender.id, lang=lang)
    except Exception:
        log.error("owner stats command failed", exc_info=True)
        return None
    if reply is None:
        return None
    try:
        await message.answer(reply.text)
    except Exception as exc:
        log.warning("owner stats reply send failed (%s)", type(exc).__name__)
    return reply.status


async def match_member_stats_command(message: Any, bot: Any) -> ParsedMemberStats | None:
    """`/userstats` `/topmembers` `/groupstats` (and the Arabic names): plain text of a group or of a private chat from a real
    (non-bot) sender. This only RECOGNISES the text; the service answers the primary owner and nobody else (silence otherwise)."""
    text = getattr(message, "text", None)
    sender = getattr(message, "from_user", None)
    if not isinstance(text, str) or sender is None or getattr(sender, "is_bot", False):
        return None
    if _chat_type(message) != "private" and not mh.is_group_message(message):
        return None
    username = await mh.bot_username(bot) if text.lstrip().startswith("/") else None
    return parse_member_stats_command(text, username)


async def execute_member_stats(message: Any, parsed: ParsedMemberStats, *, services: Any) -> str | None:
    """-> the reply status (tests/logs) or None when nothing was answered (not the owner, no service, send failed)."""
    service = getattr(services, "owner_member_stats", None)
    sender = getattr(message, "from_user", None)
    if service is None or sender is None:
        return None
    lang = pick_language(getattr(sender, "language_code", None), services.settings.default_language)
    try:
        reply = await service.run(parsed, chat_id=getattr(getattr(message, "chat", None), "id", None),
                                  chat_type=_chat_type(message), user_id=sender.id, reply=mh.reply_info(message), lang=lang)
    except Exception:
        log.error("member stats command failed", exc_info=True)
        return None
    if reply is None:
        return None
    try:
        await message.answer(reply.text)
    except Exception as exc:
        log.warning("member stats reply send failed (%s)", type(exc).__name__)
    return reply.status


async def match_backup_command(message: Any, bot: Any) -> ParsedBackupCommand | None:
    """6.8b: `/backup ...` and `نسخة احتياطية` in a PRIVATE chat from a real (non-bot) sender; everything else is not ours."""
    text = getattr(message, "text", None)
    sender = getattr(message, "from_user", None)
    if _chat_type(message) != "private" or not isinstance(text, str) or sender is None or getattr(sender, "is_bot", False):
        return None
    username = await mh.bot_username(bot) if text.lstrip().startswith("/") else None
    return parse_backup_command(text, username)


async def execute_backup(message: Any, parsed: ParsedBackupCommand, *, services: Any) -> str | None:
    """-> the reply status or None when nothing was answered (not the owner, no service, redelivered update, send failed)."""
    service = getattr(services, "owner_backup", None)
    sender = getattr(message, "from_user", None)
    if service is None or sender is None:
        return None
    lang = pick_language(getattr(sender, "language_code", None), services.settings.default_language)
    try:
        reply = await service.run(parsed, chat_id=getattr(getattr(message, "chat", None), "id", None), chat_type=_chat_type(message),
                                  user_id=sender.id, message_id=getattr(message, "message_id", None), lang=lang)
    except Exception:
        log.error("backup command failed", exc_info=True)
        return None
    if reply is None:
        return None
    try:
        await message.answer(reply.text)
    except Exception as exc:
        log.warning("backup reply send failed (%s)", type(exc).__name__)
    return reply.status


async def match_restore_command(message: Any, bot: Any) -> ParsedRestoreCommand | None:
    """6.9a: `/restore` or `استعادة نسخة` as the TEXT of a private message or as the CAPTION of a document; real (non-bot) sender only."""
    sender = getattr(message, "from_user", None)
    text = getattr(message, "text", None) or getattr(message, "caption", None)
    if _chat_type(message) != "private" or not isinstance(text, str) or sender is None or getattr(sender, "is_bot", False):
        return None
    username = await mh.bot_username(bot) if text.lstrip().startswith("/") else None
    return parse_restore_command(text, username)


def _document_of(message: Any) -> DocumentRef | None:
    """The document attached to the command message, else the one it replies to; None when neither carries a usable file."""
    for source in (message, getattr(message, "reply_to_message", None)):
        doc = getattr(source, "document", None) if source is not None else None
        file_id = getattr(doc, "file_id", None)
        if isinstance(file_id, str) and file_id:
            size = getattr(doc, "file_size", None)
            return DocumentRef(file_id, size if isinstance(size, int) and not isinstance(size, bool) else None)
    return None


async def execute_restore(message: Any, parsed: ParsedRestoreCommand, *, services: Any) -> str | None:
    """-> the reply status or None when nothing was answered (not the owner, no service, redelivered update, send failed)."""
    service = getattr(services, "owner_restore", None)
    sender = getattr(message, "from_user", None)
    if service is None or sender is None:
        return None
    lang = pick_language(getattr(sender, "language_code", None), services.settings.default_language)
    try:
        reply = await service.run(parsed, chat_id=getattr(getattr(message, "chat", None), "id", None), chat_type=_chat_type(message),
                                  user_id=sender.id, message_id=getattr(message, "message_id", None),
                                  document=_document_of(message), lang=lang)
    except Exception:
        log.error("restore command failed", exc_info=True)
        return None
    if reply is None:
        return None
    try:
        await message.answer(reply.text)
    except Exception as exc:
        log.warning("restore reply send failed (%s)", type(exc).__name__)
    return reply.status


async def match_default_words_command(message: Any, bot: Any) -> ParsedDefaultWords | None:
    """9.5: `اضافة كلمة افتراضية ...`, `/defaultword ...` and their forms; plain text of a PRIVATE chat from a real (non-bot) sender."""
    text = getattr(message, "text", None)
    sender = getattr(message, "from_user", None)
    if _chat_type(message) != "private" or not isinstance(text, str) or sender is None or getattr(sender, "is_bot", False):
        return None
    username = await mh.bot_username(bot) if text.lstrip().startswith("/") else None
    return parse_default_words_command(text, username)


async def execute_default_words(message: Any, parsed: ParsedDefaultWords, *, services: Any) -> str | None:
    """-> the reply status (tests/logs) or None when nothing was answered (not the owner, no service, send failed)."""
    service = getattr(services, "owner_default_words", None)
    sender = getattr(message, "from_user", None)
    if service is None or sender is None:
        return None
    lang = pick_language(getattr(sender, "language_code", None), services.settings.default_language)
    try:
        reply = await service.run(parsed, chat_id=getattr(getattr(message, "chat", None), "id", None),
                                  chat_type=_chat_type(message), user_id=sender.id, lang=lang)
    except Exception:
        log.error("default words command failed", exc_info=True)
        return None
    if reply is None:
        return None
    try:
        await message.answer(reply.text)
    except Exception as exc:
        log.warning("default words reply send failed (%s)", type(exc).__name__)
    return reply.status


async def match_api_check_command(message: Any, bot: Any) -> ParsedApiCheck | None:
    """9.6: `/apicheck [deep]`, `فحص API [عميق]` and their forms; plain text of a PRIVATE chat from a real (non-bot) sender."""
    text = getattr(message, "text", None)
    sender = getattr(message, "from_user", None)
    if _chat_type(message) != "private" or not isinstance(text, str) or sender is None or getattr(sender, "is_bot", False):
        return None
    username = await mh.bot_username(bot) if text.lstrip().startswith("/") else None
    return parse_api_check_command(text, username)


async def execute_api_check(message: Any, parsed: ParsedApiCheck, *, services: Any) -> str | None:
    """-> the reply status (tests/logs) or None when nothing was answered (not the owner, no service, send failed)."""
    service = getattr(services, "owner_api_check", None)
    sender = getattr(message, "from_user", None)
    if service is None or sender is None:
        return None
    lang = pick_language(getattr(sender, "language_code", None), services.settings.default_language)
    try:
        reply = await service.run(parsed, chat_id=getattr(getattr(message, "chat", None), "id", None),
                                  chat_type=_chat_type(message), user_id=sender.id, lang=lang)
    except Exception:
        log.error("api check command failed", exc_info=True)
        return None
    if reply is None:
        return None
    try:
        await message.answer(reply.text)
    except Exception as exc:
        log.warning("api check reply send failed (%s)", type(exc).__name__)
    return reply.status


async def match_template_command(message: Any, bot: Any) -> ParsedTemplateCommand | None:
    """5.6: `/templates`, `/template ...` and their Arabic forms; plain text of a PRIVATE chat from a real (non-bot) sender."""
    text = getattr(message, "text", None)
    sender = getattr(message, "from_user", None)
    if _chat_type(message) != "private" or not isinstance(text, str) or sender is None or getattr(sender, "is_bot", False):
        return None
    username = await mh.bot_username(bot) if text.lstrip().startswith("/") else None
    return parse_template_command(text, username)


async def execute_template(message: Any, parsed: ParsedTemplateCommand, *, services: Any) -> str | None:
    """-> the reply status (tests/logs) or None when nothing was answered (not the owner, no service, send failed)."""
    service = getattr(services, "owner_templates", None)
    sender = getattr(message, "from_user", None)
    if service is None or sender is None:
        return None
    lang = pick_language(getattr(sender, "language_code", None), services.settings.default_language)
    try:
        reply = await service.run(parsed, chat_id=getattr(getattr(message, "chat", None), "id", None),
                                  chat_type=_chat_type(message), user_id=sender.id, lang=lang)
    except Exception:
        log.error("template command failed", exc_info=True)
        return None
    if reply is None:
        return None
    try:
        await message.answer(reply.text)
    except Exception as exc:
        log.warning("template reply send failed (%s)", type(exc).__name__)
    return reply.status


async def execute(message: Any, parsed: ParsedOwnerCommand, *, services: Any, make_markup: Callable[[Any], Any]) -> str | None:
    """-> the outcome status (tests/logs) or None when nothing was done."""
    service = getattr(services, "owner_panel", None)
    sender = getattr(message, "from_user", None)
    if service is None or sender is None:
        return None
    lang = pick_language(getattr(sender, "language_code", None), services.settings.default_language)
    try:
        outcome = await service.open(getattr(getattr(message, "chat", None), "id", None), _chat_type(message), sender.id,
                                     parsed.search, lang)
    except Exception:
        log.error("owner panel open failed", exc_info=True)
        return None
    if outcome is None or outcome.text is None:
        return None
    try:
        await message.answer(outcome.text, reply_markup=make_markup(outcome.buttons) if outcome.buttons else None)
    except Exception as exc:
        log.warning("owner panel send failed (%s)", type(exc).__name__)
    return outcome.status


async def on_owner_callback(query: Any, services: Any, make_markup: Callable[[Any], Any]) -> tuple[str, bool] | None:
    """-> (toast text, show_alert) for `callback.answer`, or None for a callback that is not ours / not applicable."""
    service = getattr(services, "owner_panel", None)
    message = getattr(query, "message", None)
    presser = getattr(query, "from_user", None)
    lang = pick_language(getattr(presser, "language_code", None), services.settings.default_language)
    if service is None:
        return None
    try:
        outcome = await service.press(getattr(getattr(message, "chat", None), "id", None), _chat_type(message),
                                      getattr(presser, "id", None), getattr(query, "data", None), lang,
                                      getattr(query, "id", None))
    except Exception:
        log.error("owner panel press failed", exc_info=True)
        return t("ow_unavailable", lang), True
    if outcome is None:
        return None
    if outcome.delete:
        try:
            await message.delete()
        except Exception as exc:
            log.warning("owner panel close failed (%s)", type(exc).__name__)
    elif outcome.text is not None:
        try:
            await message.edit_text(outcome.text, reply_markup=make_markup(outcome.buttons) if outcome.buttons else None)
        except Exception as exc:  # includes "message is not modified" when nothing changed
            log.warning("owner panel refresh edit failed (%s)", type(exc).__name__)
    return outcome.toast, outcome.alert
