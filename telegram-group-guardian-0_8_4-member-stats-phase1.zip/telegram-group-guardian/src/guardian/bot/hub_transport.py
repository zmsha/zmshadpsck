"""aiogram adapter of `owner_hub.sender.HubTransport` (thin; the chat id always comes from the sender, never from a caller)."""
from __future__ import annotations

from aiogram import Bot
from aiogram.types import BufferedInputFile


class AiogramHubTransport:
    def __init__(self, bot: Bot):
        self._bot = bot

    async def send_message(self, chat_id: int, text: str) -> None:
        await self._bot.send_message(chat_id, text)

    async def send_document(self, chat_id: int, filename: str, data: bytes, caption: str | None) -> None:
        await self._bot.send_document(chat_id, BufferedInputFile(data, filename=filename), caption=caption)
