"""Framework-independent glue between Telegram messages and `LicenseCommandService` (Phase 5 / part 5.2).

Duck-typed on aiogram `Message` objects (no aiogram import) so it is unit-tested with fakes;
`bot/routers/licensing.py` is the thin aiogram layer. Only plain TEXT messages of groups/supergroups from a real
(non-bot) sender are considered, and only `message` is registered, so an EDITED message never runs a command.
The command works whatever the group's license state is (the protection middleware only enriches the update).
"""
from __future__ import annotations

import logging
from typing import Any

from ..i18n import pick_language
from ..licensing.commands import LicenseCommandResult, ParsedLicenseCommand, parse_license_command
from . import moderation_handler as mh

log = logging.getLogger(__name__)


async def match_command(message: Any, bot: Any) -> ParsedLicenseCommand | None:
    if not mh.is_group_message(message):
        return None
    text = getattr(message, "text", None)
    sender = getattr(message, "from_user", None)
    if not isinstance(text, str) or sender is None or getattr(sender, "is_bot", False):
        return None
    username = await mh.bot_username(bot) if text.lstrip().startswith("/") else None  # Arabic needs no getMe
    return parse_license_command(text, username)


async def execute(message: Any, parsed: ParsedLicenseCommand, *, services: Any) -> LicenseCommandResult | None:
    service = getattr(services, "license_commands", None)
    if service is None:
        return None
    sender = message.from_user
    lang = pick_language(getattr(sender, "language_code", None), services.settings.default_language)
    result = await service.handle(parsed, chat_id=message.chat.id, actor_id=sender.id,
                                  message_id=int(message.message_id), language=lang)
    if result.text:
        try:
            await message.reply(result.text)
        except Exception as exc:  # the command already ran (or was refused): never raise from here
            log.warning("license command reply failed (%s)", type(exc).__name__)
    return result
