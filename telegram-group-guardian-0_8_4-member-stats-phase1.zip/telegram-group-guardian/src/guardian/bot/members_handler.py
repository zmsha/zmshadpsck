"""Framework-independent logic of the join / leave service-message handlers (phase 4.3). The aiogram adapter is
`bot/routers/members.py`. Only reads the Telegram message and delegates to `members.welcome.WelcomeService`; the license
decision comes from the `ProtectionContext` the outer middleware computed for THIS update."""
from __future__ import annotations

import logging
from typing import Any

from ..members.welcome import Joined
from ..protection_gate import ProtectionContext
from ..services import Services

log = logging.getLogger(__name__)


def joined_members(message: Any) -> list[Joined]:
    out: list[Joined] = []
    for user in getattr(message, "new_chat_members", None) or ():
        uid = getattr(user, "id", None)
        if not isinstance(uid, int) or isinstance(uid, bool):
            continue
        name = getattr(user, "full_name", None) or getattr(user, "first_name", None) or ""
        username = getattr(user, "username", None)
        out.append(Joined(uid, str(name), bool(getattr(user, "is_bot", False)),
                          username if isinstance(username, str) and username else None))
    return out


def _message_id(message: Any) -> int | None:
    mid = getattr(message, "message_id", None)
    return mid if isinstance(mid, int) and not isinstance(mid, bool) else None


async def on_new_members(message: Any, protection: ProtectionContext | None, services: Services) -> None:
    if protection is None or not protection.allowed:
        return  # no license => no automatic action at all
    joined, title, mid = joined_members(message), getattr(message.chat, "title", None), _message_id(message)
    joined = await _screen_joined(joined, message, protection, services, title)
    if not joined:
        return
    verification = getattr(services, "verification", None)
    held: set[int] = set()  # challenged / re-enforced members: welcomed only after they pass (owner decision, part 8.2)
    if verification is not None:  # first: a challenged member must be restricted before anything else happens
        try:
            outcome = await verification.on_join(protection, mid, joined, title)
            held = {u for u in (*getattr(outcome, "challenged", ()), *getattr(outcome, "enforced", ()))
                    if isinstance(u, int) and not isinstance(u, bool)}
        except Exception:
            log.error("verification join handling failed", extra={"group_id": protection.chat_id}, exc_info=True)
    newcomers = getattr(services, "newcomers", None)
    if newcomers is not None:
        try:
            await newcomers.on_join(protection, joined)
        except Exception:
            log.error("newcomer tracking failed", extra={"group_id": protection.chat_id}, exc_info=True)
    welcome = getattr(services, "welcome", None)
    if welcome is None:
        return
    try:
        await welcome.on_join(protection, mid, [m for m in joined if m.user_id not in held], title)
    except Exception:
        log.error("join handling failed", extra={"group_id": protection.chat_id}, exc_info=True)


async def _screen_joined(joined: list[Joined], message: Any, protection: ProtectionContext, services: Services,
                         title: str | None) -> list[Joined]:
    """Part 9.2: screen each joined member (name, username, profile photo) BEFORE verification/welcome. A member that was banned
    or put under review is dropped from the list so no challenge/welcome/newcomer window touches them (a later unmute by the
    verification would otherwise undo the review mute). Any failure => the member simply continues as before."""
    guard = getattr(services, "content_guard", None)
    if guard is None or not joined:
        return joined
    from ..content_filter.service import NewMember

    by_id = {getattr(u, "id", None): u for u in (getattr(message, "new_chat_members", None) or ())}
    kept: list[Joined] = []
    for member in joined:
        user = by_id.get(member.user_id)
        info = NewMember(member.user_id, getattr(user, "first_name", None), getattr(user, "last_name", None),
                         member.username, member.is_bot)
        try:
            acted = await guard.screen_member(protection.chat_id, info, title)
        except Exception:
            log.error("content screening failed", extra={"group_id": protection.chat_id}, exc_info=True)
            acted = None
        if acted is None:
            kept.append(member)
    return kept


async def on_left_member(message: Any, protection: ProtectionContext | None, services: Services) -> None:
    if protection is None or not protection.allowed:
        return
    verification = getattr(services, "verification", None)
    if verification is not None:
        left = getattr(getattr(message, "left_chat_member", None), "id", None)
        try:
            await verification.on_leave(protection, left if isinstance(left, int) and not isinstance(left, bool) else None)
        except Exception:
            log.error("verification leave handling failed", extra={"group_id": protection.chat_id}, exc_info=True)
    welcome = getattr(services, "welcome", None)
    if welcome is None:
        return
    try:
        await welcome.on_leave(protection, _message_id(message))
    except Exception:
        log.error("leave handling failed", extra={"group_id": protection.chat_id}, exc_info=True)


GROUP_CHAT_TYPES = ("group", "supergroup")


async def on_verify_callback(query: Any, services: Services) -> tuple[str, bool] | None:
    """A press on a verification button. Returns (toast text, show_alert) for `callback.answer`, or None for a callback
    that is not ours / malformed. The group is the chat of the PRESSED message (never read from the callback data), the
    presser is Telegram's `from_user` (never from the data): a forged `vf:<id>:<value>` can only ever act as the presser
    on a challenge of the group the message is in, and only if that challenge belongs to the presser."""
    from ..members.verification import parse_callback

    verification = getattr(services, "verification", None)
    parsed = parse_callback(getattr(query, "data", None))
    if verification is None or parsed is None:
        return None
    message = getattr(query, "message", None)
    chat = getattr(message, "chat", None)
    group = getattr(chat, "id", None)
    ctype = str(getattr(getattr(chat, "type", None), "value", getattr(chat, "type", "")) or "")
    presser = getattr(getattr(query, "from_user", None), "id", None)
    if (ctype not in GROUP_CHAT_TYPES or not isinstance(group, int) or isinstance(group, bool)
            or not isinstance(presser, int) or isinstance(presser, bool) or presser <= 0):
        return None
    try:
        out = await verification.answer(group, parsed[0], presser, parsed[1])
    except Exception:
        log.error("verification callback failed", extra={"group_id": group}, exc_info=True)
        return None
    await _welcome_verified(out, services, group, presser, message, query)
    return out.text, out.alert


async def _welcome_verified(out: Any, services: Services, group: int, presser: int, message: Any, query: Any) -> None:
    """Welcome-after-pass (part 8.2): only for a success outcome that names the verified member. Never raises."""
    from ..members.verification import SUCCESS_KINDS

    welcome = getattr(services, "welcome", None)
    uid = getattr(out, "user_id", None)
    if welcome is None or getattr(out, "kind", None) not in SUCCESS_KINDS or not isinstance(uid, int) or isinstance(uid, bool):
        return
    name = getattr(out, "name", "") or ""
    if not name and uid == presser:  # the member pressed it themselves: Telegram's own display name
        from_user = getattr(query, "from_user", None)
        name = str(getattr(from_user, "full_name", None) or getattr(from_user, "first_name", None) or "")
    title = getattr(getattr(message, "chat", None), "title", None)
    try:
        await welcome.on_verified(group, Joined(uid, name), title, _challenge_id(query))
    except Exception:
        log.error("welcome after verification failed", extra={"group_id": group}, exc_info=True)


def _challenge_id(query: Any) -> int:
    from ..members.verification import parse_callback

    parsed = parse_callback(getattr(query, "data", None))
    return parsed[0] if parsed else 0


async def on_content_review_callback(query: Any, services: Services) -> tuple[str, bool] | None:
    """A press on a content-review button (`cf:<id>:c|r`), sent privately to an admin. The presser is Telegram's `from_user`
    (never callback data); the group and member come from the stored review; the guard checks the presser's MODERATE right for
    THAT group and applies only the first valid decision. None = not ours / malformed."""
    from ..content_filter.service import parse_callback

    guard = getattr(services, "content_guard", None)
    parsed = parse_callback(getattr(query, "data", None))
    presser = getattr(getattr(query, "from_user", None), "id", None)
    if guard is None or parsed is None or not isinstance(presser, int) or isinstance(presser, bool) or presser <= 0:
        return None
    try:
        return await guard.decide(parsed[0], parsed[1], parsed[2], presser)
    except Exception:
        log.error("content review callback failed", exc_info=True)
        return None
