"""aiogram adapter for `ModerationActions` (protection engine) AND `MemberActions` (moderation commands).

Phase 3 / part 6 adds ban / unban / mute / unmute / kick on top of the part-2 `delete_message` / `mute_member`.

Rules enforced here (all covered by tests with a signature-strict fake Bot):
* NEVER raises: every Telegram/aiogram failure becomes `ActionResult(False, kind)`; `str(exc)` is never
  logged (API errors can echo request details). One bounded retry only for a small `retry_after`.
* `until` is validated BEFORE the call: it must be timezone-aware and between 31 s and 366 days from now.
  Telegram treats `until_date` < 30 s or > 366 days as "forever", so an out-of-window value would silently
  become PERMANENT; such a call is refused (fail closed) instead of being sent.
* `unban_chat_member` is always sent with `only_if_banned=True`: without it, unbanning a user who is a
  regular member REMOVES them from the chat.
* mute = `restrictChatMember` with every permission flag explicitly False. unmute restores the group's
  DEFAULT permissions (`getChat().permissions`, sent with `use_independent_chat_permissions=True` so the
  exact default set is applied); if the defaults cannot be read the call is refused rather than guessing
  "everything allowed".
* kick = ban for a short TEMPORARY window (60 s) then unban. If the unban cannot be completed the user stays
  banned (never silently reported as a success): the result is `ActionResult(False, "kick_incomplete")` and
  the short window lets Telegram lift the ban by itself (documented Bot API behaviour; not verified live).

Duck-typed on aiogram exception classes by NAME and on the Bot methods (no aiogram import at module level, so the
module imports without aiogram; `ChatPermissions` is imported lazily and only if no factory is injected).
NOT verified against the real Telegram API / a real aiogram install in the build sandbox (no PyPI access).
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Any, Awaitable, Callable

import dataclasses

from ..moderation.config_args import LOCKABLE_FLAGS
from ..moderation.lock_commands import PermissionChange
from ..moderation.models import MAX_TEMP_SECONDS
from ..protection.engine import ActionResult, SendResult
from ..time_utils import ensure_utc, utcnow

log = logging.getLogger(__name__)

# Telegram: until_date < 30 s or > 366 days from now == "forever". We refuse anything outside a safe window.
MIN_UNTIL_SECONDS = 31
MAX_UNTIL_SECONDS = MAX_TEMP_SECONDS
MAX_TEXT_CHARS = 4096  # Telegram's sendMessage text limit
MAX_DELETE_BATCH = 100  # Telegram's deleteMessages: 1..100 message ids per call
KICK_BAN_WINDOW_SECONDS = 60  # kick = ban(for 60 s) + unban; the short window self-heals a failed unban

# Every flag of Bot API ChatPermissions we know about; unknown ones are skipped per installed aiogram version.
PERMISSION_FLAGS = (
    "can_send_messages", "can_send_audios", "can_send_documents", "can_send_photos", "can_send_videos",
    "can_send_video_notes", "can_send_voice_notes", "can_send_polls", "can_send_other_messages",
    "can_add_web_page_previews", "can_change_info", "can_invite_users", "can_pin_messages", "can_manage_topics",
)


def classify_error(exc: BaseException) -> str:
    """-> rate_limited | forbidden | not_found | other (never inspects more than the type name and a lowercase message)."""
    name = type(exc).__name__
    if getattr(exc, "retry_after", None) is not None or name == "TelegramRetryAfter":
        return "rate_limited"
    if name == "TelegramForbiddenError":
        return "forbidden"
    text = str(exc).lower()
    if "not found" in text or "message to delete" in text or "participant" in text or "user_not" in text:
        return "not_found"
    if ("not enough rights" in text or "administrator" in text or "can't remove" in text
            or "chat_admin_required" in text or "no rights" in text):
        return "forbidden"
    return "other"


def _all_denied_permissions() -> Any:
    """Default factory for the 'muted' permission set (lazy aiogram import)."""
    from aiogram.types import ChatPermissions

    known = getattr(ChatPermissions, "model_fields", None) or {}
    return ChatPermissions(**{name: False for name in PERMISSION_FLAGS if name in known})


def _inline_markup(buttons: Any) -> Any:
    """Rows of (label, callback_data) -> aiogram InlineKeyboardMarkup (imported lazily)."""
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=label, callback_data=data) for label, data in row] for row in buttons])


def _valid_buttons(buttons: Any) -> bool:
    """<= 8 rows x 8 buttons; label 1..64 chars; callback_data 1..64 BYTES (Telegram's limits)."""
    if not isinstance(buttons, (tuple, list)) or not buttons or len(buttons) > 8:
        return False
    for row in buttons:
        if not isinstance(row, (tuple, list)) or not row or len(row) > 8:
            return False
        for cell in row:
            if not (isinstance(cell, (tuple, list)) and len(cell) == 2 and all(isinstance(x, str) for x in cell)):
                return False
            label, data = cell
            if not (1 <= len(label) <= 64 and 1 <= len(data.encode("utf-8")) <= 64):
                return False
    return True


def _valid_ids(chat_id: Any, user_id: Any) -> bool:
    ok = lambda v: isinstance(v, int) and not isinstance(v, bool)  # noqa: E731
    return ok(chat_id) and chat_id != 0 and ok(user_id) and user_id > 0


def _valid_message(chat_id: Any, message_id: Any) -> bool:
    ok = lambda v: isinstance(v, int) and not isinstance(v, bool)  # noqa: E731
    return ok(chat_id) and chat_id != 0 and ok(message_id) and 0 < message_id < 2**31


def _permissions_with(current: Any, changes: dict[str, bool]) -> Any:
    """Copy of the group's CURRENT default permissions with only `changes` altered: every other flag is sent back
    exactly as Telegram returned it (aiogram models via `model_copy`; dataclass fakes in tests). Raises if the object
    cannot be copied; the caller then refuses instead of building a guessed set."""
    copier = getattr(current, "model_copy", None)
    if callable(copier):
        return copier(update=dict(changes))
    return dataclasses.replace(current, **changes)


class AiogramModerationActions:
    def __init__(
        self,
        bot: Any,
        *,
        max_retry_after: float = 3.0,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
        clock: Callable[[], datetime] = utcnow,
        muted_permissions: Callable[[], Any] = _all_denied_permissions,
        permissions_with: Callable[[Any, dict[str, bool]], Any] = _permissions_with,
        markup_factory: Callable[[Any], Any] = _inline_markup,
    ):
        self._bot = bot
        self._max_retry = max_retry_after
        self._sleep = sleep
        self._clock = clock
        self._muted_permissions = muted_permissions
        self._permissions_with = permissions_with
        self._markup_factory = markup_factory

    # ------------------------------------------------------------------ plumbing
    async def _attempt(self, label: str, call: Callable[[], Awaitable[Any]]) -> tuple[ActionResult, Any]:
        for attempt in (1, 2):
            try:
                value = await call()
                return ActionResult(True), value
            except Exception as exc:
                kind = classify_error(exc)
                retry_after = getattr(exc, "retry_after", None)
                if (kind == "rate_limited" and attempt == 1 and isinstance(retry_after, (int, float))
                        and 0 < retry_after <= self._max_retry):
                    await self._sleep(float(retry_after))
                    continue
                log.warning("%s failed (%s)", label, type(exc).__name__)  # never str(exc)
                return ActionResult(False, kind), None
        return ActionResult(False, "other"), None  # pragma: no cover

    async def _run(self, label: str, call: Callable[[], Awaitable[Any]]) -> ActionResult:
        return (await self._attempt(label, call))[0]

    def _refuse(self, label: str, why: str) -> ActionResult:
        log.warning("%s refused before calling Telegram (%s)", label, why)
        return ActionResult(False, "other")

    def _checked_until(self, label: str, until: datetime | None) -> tuple[ActionResult | None, datetime | None]:
        """(refusal, normalized_until). `until=None` => permanent. Out-of-window values are refused."""
        if until is None:
            return None, None
        try:
            utc = ensure_utc(until)
        except (ValueError, AttributeError, TypeError):
            return self._refuse(label, "until is not a timezone-aware datetime"), None
        remaining = (utc - self._clock()).total_seconds()
        if not MIN_UNTIL_SECONDS <= remaining <= MAX_UNTIL_SECONDS:
            return self._refuse(label, "until outside Telegram's temporary window"), None
        return None, utc

    # ------------------------------------------------------------------ part 2: protection engine
    async def delete_message(self, chat_id: int, message_id: int) -> ActionResult:
        return await self._run("deleteMessage", lambda: self._bot.delete_message(chat_id, message_id))

    # ------------------------------------------------------------------ part 4.3: welcome messages
    async def send_message(self, chat_id: int, text: str, buttons: Any = None) -> SendResult:
        """sendMessage (HTML, silent, no reply). Returns the new message id only when Telegram accepted it. The caller
        escapes every dynamic value for HTML; an empty or > 4096-char text is refused before calling Telegram.
        `buttons` (part 4.4): rows of (label, callback_data) sent as an inline keyboard; invalid buttons, or a keyboard that
        cannot be built, are refused WITHOUT sending (a prompt whose buttons are missing would strand the member)."""
        if not _valid_message(chat_id, 1) or not isinstance(text, str) or not text.strip() or len(text) > MAX_TEXT_CHARS:
            self._refuse("sendMessage", "invalid chat id or text")
            return SendResult(False, "other")
        extra: dict[str, Any] = {}
        if buttons is not None:
            if not _valid_buttons(buttons):
                self._refuse("sendMessage", "invalid buttons")
                return SendResult(False, "other")
            try:
                extra["reply_markup"] = self._markup_factory(buttons)
            except Exception as exc:  # e.g. aiogram not installed
                log.error("could not build the inline keyboard (%s)", type(exc).__name__)
                return SendResult(False, "other")
        result, sent = await self._attempt(
            "sendMessage",
            lambda: self._bot.send_message(chat_id, text, parse_mode="HTML", disable_notification=True, **extra))
        if not result.ok:
            return SendResult(False, result.error)
        message_id = getattr(sent, "message_id", None)
        if not isinstance(message_id, int) or isinstance(message_id, bool) or message_id <= 0:
            return SendResult(False, "other")  # accepted but unusable: never track a bogus id
        return SendResult(True, None, message_id)

    # ------------------------------------------------------------------ part 4.5: suspicion signals
    async def has_profile_photo(self, user_id: int) -> bool | None:
        """getUserProfilePhotos(limit=1). True/False when Telegram answered; None when unknown (error, or a user whose
        privacy settings hide the photo are reported by Telegram as 0 photos: that is a known false positive)."""
        if not _valid_ids(1, user_id):
            return None
        res, photos = await self._attempt("getUserProfilePhotos", lambda: self._bot.get_user_profile_photos(user_id, limit=1))
        total = getattr(photos, "total_count", None)
        if not res.ok or not isinstance(total, int) or isinstance(total, bool) or total < 0:
            return None
        return total > 0

    # ------------------------------------------------------------------ part 9.2: content filter (profile photo)
    async def fetch_profile_photo(self, user_id: int, max_bytes: int = 1_500_000) -> bytes | None:
        """The member's CURRENT profile photo (a small size) as bytes for Gemini Vision, or None when there is no photo, the
        member's privacy hides it, it is too large, or any step fails. Held in memory only: never written to disk or logged."""
        if not _valid_ids(1, user_id):
            return None
        res, photos = await self._attempt("getUserProfilePhotos", lambda: self._bot.get_user_profile_photos(user_id, limit=1))
        sets = getattr(photos, "photos", None)
        if not res.ok or not isinstance(sets, (list, tuple)) or not sets or not sets[0]:
            return None
        sizes = [p for p in sets[0] if isinstance(getattr(p, "file_id", None), str)]
        if not sizes:
            return None
        # the smallest size that is at least 320 px wide (enough for a classifier), else the largest available
        sizes.sort(key=lambda p: getattr(p, "width", 0) or 0)
        chosen = next((p for p in sizes if (getattr(p, "width", 0) or 0) >= 320), sizes[-1])
        res, info = await self._attempt("getFile", lambda: self._bot.get_file(chosen.file_id))
        path = getattr(info, "file_path", None)
        if not res.ok or not isinstance(path, str) or not path:
            return None
        res, buffer = await self._attempt("downloadFile", lambda: self._bot.download_file(path))
        if not res.ok or buffer is None:
            return None
        try:
            data = buffer if isinstance(buffer, (bytes, bytearray)) else buffer.read(max_bytes + 1)
        except Exception:
            return None
        return bytes(data) if 0 < len(data) <= max_bytes else None

    # ------------------------------------------------------------------ part 6: MemberActions
    async def ban_member(self, chat_id: int, user_id: int, until: datetime | None) -> ActionResult:
        """banChatMember. `until=None` = permanent. Past messages are NOT revoked."""
        if not _valid_ids(chat_id, user_id):
            return self._refuse("banChatMember", "invalid ids")
        refusal, utc = self._checked_until("banChatMember", until)
        if refusal is not None:
            return refusal
        return await self._run("banChatMember", lambda: self._bot.ban_chat_member(chat_id, user_id, until_date=utc))

    async def unban_member(self, chat_id: int, user_id: int) -> ActionResult:
        """unbanChatMember with only_if_banned=True (a plain member must never be removed by an unban)."""
        if not _valid_ids(chat_id, user_id):
            return self._refuse("unbanChatMember", "invalid ids")
        return await self._run(
            "unbanChatMember", lambda: self._bot.unban_chat_member(chat_id, user_id, only_if_banned=True))

    async def mute_member(self, chat_id: int, user_id: int, until: datetime | None) -> ActionResult:
        """restrictChatMember with every permission denied. `until=None` = permanent."""
        if not _valid_ids(chat_id, user_id):
            return self._refuse("restrictChatMember", "invalid ids")
        refusal, utc = self._checked_until("restrictChatMember", until)
        if refusal is not None:
            return refusal
        try:
            perms = self._muted_permissions()
        except Exception as exc:  # e.g. aiogram not installed: fail closed, never raise
            log.error("could not build the muted permission set (%s)", type(exc).__name__)
            return ActionResult(False, "other")
        return await self._run(
            "restrictChatMember",
            lambda: self._bot.restrict_chat_member(chat_id, user_id, permissions=perms, until_date=utc))

    async def unmute_member(self, chat_id: int, user_id: int) -> ActionResult:
        """Restore the group's DEFAULT permissions (not 'everything allowed'). Refused if they cannot be read."""
        if not _valid_ids(chat_id, user_id):
            return self._refuse("restrictChatMember", "invalid ids")
        res, chat = await self._attempt("getChat", lambda: self._bot.get_chat(chat_id))
        if not res.ok:
            return res
        defaults = getattr(chat, "permissions", None)
        if defaults is None:
            return self._refuse("restrictChatMember", "group default permissions unavailable")
        return await self._run(
            "restrictChatMember",
            lambda: self._bot.restrict_chat_member(
                chat_id, user_id, permissions=defaults, use_independent_chat_permissions=True))

    async def kick_member(self, chat_id: int, user_id: int) -> ActionResult:
        """Remove the user but let them rejoin: temporary ban then unban.

        Ban fails -> that failure is returned and unban is NOT attempted. Ban ok + unban fails (after one more
        try) -> `kick_incomplete`: the user is still banned (until the short window ends or an admin /unban)."""
        if not _valid_ids(chat_id, user_id):
            return self._refuse("kick", "invalid ids")
        banned = await self.ban_member(chat_id, user_id, self._clock() + timedelta(seconds=KICK_BAN_WINDOW_SECONDS))
        if not banned.ok:
            return banned
        last = await self.unban_member(chat_id, user_id)
        if not last.ok and last.error in ("rate_limited", "other"):
            last = await self.unban_member(chat_id, user_id)  # one extra try for transient errors only
        if last.ok:
            return ActionResult(True)
        log.error("kick incomplete: user banned but unban failed (%s)", last.error, extra={"group_id": chat_id})
        return ActionResult(False, "kick_incomplete")

    # ------------------------------------------------------------------ closing part 2: message commands
    async def pin_message(self, chat_id: int, message_id: int, silent: bool = False) -> ActionResult:
        """pinChatMessage. Needs the bot's can_pin_messages (checked by the caller). `silent` => no notification."""
        if not _valid_message(chat_id, message_id):
            return self._refuse("pinChatMessage", "invalid ids")
        return await self._run(
            "pinChatMessage",
            lambda: self._bot.pin_chat_message(chat_id, message_id, disable_notification=bool(silent)))

    async def unpin_message(self, chat_id: int, message_id: int | None = None) -> ActionResult:
        """unpinChatMessage. `message_id=None` => Telegram unpins the MOST RECENT pinned message."""
        if message_id is not None and not _valid_message(chat_id, message_id):
            return self._refuse("unpinChatMessage", "invalid ids")
        if message_id is None and not _valid_message(chat_id, 1):
            return self._refuse("unpinChatMessage", "invalid chat id")
        return await self._run("unpinChatMessage", lambda: self._bot.unpin_chat_message(chat_id, message_id=message_id))

    async def delete_messages(self, chat_id: int, message_ids: list[int]) -> ActionResult:
        """deleteMessages (bulk, 1..100 distinct ids). Telegram skips ids it cannot delete (older than 48 h, already
        gone) and returns no count, so success means "requested", not "N messages deleted"."""
        ids = list(message_ids) if isinstance(message_ids, (list, tuple)) else []
        if (not ids or len(ids) > MAX_DELETE_BATCH or len(set(ids)) != len(ids)
                or not all(_valid_message(chat_id, m) for m in ids)):
            return self._refuse("deleteMessages", "invalid ids")
        method = getattr(self._bot, "delete_messages", None)
        if method is None:  # older aiogram: never fall back to up to 100 single calls (rate limits)
            return self._refuse("deleteMessages", "not available in this aiogram version")
        return await self._run("deleteMessages", lambda: method(chat_id, ids))

    # ------------------------------------------------------------------ closing part 3: /lock /unlock
    async def set_default_permissions(self, chat_id: int, flags: tuple[str, ...], allowed: bool) -> PermissionChange:
        """Set the given default-permission flags of the GROUP (what ordinary members may send) to `allowed`.

        Get-modify-set: `setChatPermissions` REPLACES the whole set, so the current one is read with `getChat` and sent
        back with only `flags` changed; if it cannot be read or copied the call is refused (never a guessed "everything
        allowed"). Sent with `use_independent_chat_permissions=True` so each flag means exactly itself. Nothing is sent
        when the flags already have the wanted value (`changed=False`). Administrators are not affected by default
        permissions. Needs the bot's can_restrict_members (checked by the caller)."""
        ok_chat = isinstance(chat_id, int) and not isinstance(chat_id, bool) and chat_id < 0
        wanted = tuple(flags) if isinstance(flags, (tuple, list)) else ()
        if (not ok_chat or not isinstance(allowed, bool) or not wanted or len(set(wanted)) != len(wanted)
                or not all(f in LOCKABLE_FLAGS for f in wanted)):
            self._refuse("setChatPermissions", "invalid arguments")
            return PermissionChange(False, "other")
        res, chat = await self._attempt("getChat", lambda: self._bot.get_chat(chat_id))
        if not res.ok:
            return PermissionChange(False, res.error)
        current = getattr(chat, "permissions", None)
        if current is None:
            self._refuse("setChatPermissions", "group default permissions unavailable")
            return PermissionChange(False, "other")
        if all(getattr(current, f, None) is allowed for f in wanted):
            return PermissionChange(True, None, False)
        try:
            new = self._permissions_with(current, {f: allowed for f in wanted})
        except Exception as exc:
            log.error("could not build the new default permissions (%s)", type(exc).__name__)
            return PermissionChange(False, "other")
        res = await self._run(
            "setChatPermissions",
            lambda: self._bot.set_chat_permissions(chat_id, permissions=new, use_independent_chat_permissions=True))
        return PermissionChange(res.ok, res.error, res.ok)
