"""aiogram adapter for ProtectionGate: an OUTER middleware that only ENRICHES handler data.

It never blocks the update: owner license commands, the owner panel and /status must work even when
a group's license is expired/stopped/banned. Protection handlers read `protection` (a
ProtectionContext) and must act only when `protection.allowed` / `protection.can_sanction`.
Plain callable (no aiogram import) so it is testable without aiogram installed.
"""
from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable

from ..content_filter.service import ContentView
from ..protection.engine import MessageView, ProtectionEngine
from ..protection_gate import ProtectionContext, ProtectionGate, denied

log = logging.getLogger(__name__)

DATA_KEY = "protection"
# Content types written by a PERSON. Anything else (join/leave/pin/title/topic/video-chat service messages, "unknown")
# is a Telegram service message and is never inspected as a violation. A missing content_type (fakes) counts as a person.
USER_CONTENT_TYPES = frozenset({
    "text", "photo", "video", "audio", "document", "voice", "video_note", "sticker", "animation", "contact",
    "location", "venue", "poll", "dice", "game", "story", "paid_media",
})


MEDIA_CONTENT_TYPES = USER_CONTENT_TYPES - {"text"}


def _has_media(event: Any) -> bool:
    raw = getattr(event, "content_type", None)
    return raw is not None and str(getattr(raw, "value", raw)) in MEDIA_CONTENT_TYPES


def _is_service(event: Any) -> bool:
    raw = getattr(event, "content_type", None)
    if raw is None:
        return False
    return str(getattr(raw, "value", raw)) not in USER_CONTENT_TYPES


class ProtectionGateMiddleware:
    def __init__(self, gate: ProtectionGate, engine: ProtectionEngine | None = None, *, is_edit: bool = False,
                 observer: Callable[[Any, ProtectionContext], None] | None = None,
                 tick: Callable[[], Awaitable[Any]] | None = None,
                 group_tick: Callable[[Any, ProtectionContext], Any] | None = None,
                 content_guard: Any = None, member_stats: Any = None):
        self._gate = gate
        self._member_stats = member_stats  # part: permanent per-member statistics; NEW messages only (an edit never counts)
        self._content_guard = content_guard  # part 9.2: runs BEFORE the engine; a message it deleted never reaches the engine
        self._engine = engine
        self._is_edit = is_edit
        self._observer = observer  # e.g. feeds the visible-users store; must never block or raise
        self._group_tick = group_tick  # part 6.6b: per-group background work (periodic reports); synchronous hook that only schedules a task
        self._tick = tick  # throttled background work riding on updates (expiry of member verifications); never raises

    async def __call__(self, handler: Callable[[Any, dict], Awaitable[Any]], event: Any, data: dict) -> Any:
        ctx = await self._context_for(event)
        data[DATA_KEY] = ctx
        if self._observer is not None:
            try:
                self._observer(event, ctx)
            except Exception:
                log.error("middleware observer failed", exc_info=True)
        if self._tick is not None:
            try:
                await self._tick()
            except Exception:
                log.error("middleware tick failed", exc_info=True)
        if self._group_tick is not None:
            try:
                self._group_tick(event, ctx)
            except Exception:
                log.error("middleware group tick failed", exc_info=True)
        await self._count_message(event, ctx)
        if self._content_guard is not None and ctx.can_sanction:
            try:
                if await self._content_guard.handle_message(ctx, self._content_view(event, ctx)):
                    return None
            except Exception:
                log.error("content guard middleware failed", exc_info=True)
        if self._engine is not None and ctx.can_sanction:
            try:
                outcome = await self._engine.handle(ctx, self._view(event, ctx))
                if outcome.consumed:  # offending message deleted: nothing else should process it
                    return None
            except Exception:
                log.error("protection engine middleware failed", exc_info=True)
        return await handler(event, data)

    async def _count_message(self, event: Any, ctx: ProtectionContext) -> None:
        """One tick for a NEW message written by a real person in a licensed group. Never raises, never blocks the update.
        Not counted: edits, Telegram service messages, bots, anonymous/channel senders, private chats, unlicensed groups."""
        if self._member_stats is None or self._is_edit or not ctx.allowed or ctx.sender_id is None:
            return
        if ctx.chat_type not in ("group", "supergroup") or not isinstance(ctx.chat_id, int) or _is_service(event):
            return
        sender = getattr(event, "from_user", None)
        if sender is None or getattr(sender, "is_bot", False) is True or getattr(event, "sender_chat", None) is not None:
            return
        try:
            await self._member_stats.message(ctx.chat_id, ctx.sender_id, int(event.message_id))
        except Exception:
            log.error("member stats middleware failed", exc_info=True)

    def _view(self, event: Any, ctx: ProtectionContext) -> MessageView:
        text = getattr(event, "text", None) or getattr(event, "caption", None)
        entities = getattr(event, "entities", None) or getattr(event, "caption_entities", None) or ()
        via = getattr(getattr(event, "via_bot", None), "id", None)
        via = via if isinstance(via, int) and not isinstance(via, bool) and via > 0 else None
        return MessageView(ctx.chat_id, ctx.sender_id, int(event.message_id), text, tuple(entities), self._is_edit,
                           _is_service(event), via, _has_media(event))

    def _content_view(self, event: Any, ctx: ProtectionContext) -> ContentView:
        text = getattr(event, "text", None) or getattr(event, "caption", None)
        sender = getattr(event, "from_user", None)

        def name(attr: str) -> str | None:
            value = getattr(sender, attr, None)
            return value if isinstance(value, str) and value else None

        return ContentView(ctx.chat_id, ctx.sender_id, int(event.message_id), text if isinstance(text, str) else None,
                           name("first_name"), name("last_name"), name("username"),
                           getattr(getattr(event, "chat", None), "title", None), self._is_edit, _is_service(event))

    async def _context_for(self, event: Any) -> ProtectionContext:
        chat = getattr(event, "chat", None)
        chat_id = getattr(chat, "id", None)
        chat_type = str(getattr(getattr(chat, "type", None), "value", getattr(chat, "type", "")) or "")
        sender = getattr(event, "from_user", None)
        sender_id = getattr(sender, "id", None)
        anonymous = getattr(event, "sender_chat", None) is not None  # anon admin / channel post
        try:
            return await self._gate.evaluate(
                chat_id, chat_type, sender_id, title=getattr(chat, "title", None), anonymous_sender=anonymous
            )
        except Exception:  # evaluate() already fails closed; this is the last line of defence
            log.error("protection middleware failed", exc_info=True)
            return denied(chat_id if isinstance(chat_id, int) else None, chat_type, "gate_error", None)
