"""aiogram adapter that DOWNLOADS a document the owner sent (part 6.9a; thin, not exercised against Telegram in the build sandbox).

Contract used by `backup.restore_service`: `await download(file_id, max_bytes) -> bytes | None`; `None` = larger than `max_bytes`
(nothing is kept). Any other failure raises (the caller records only the exception TYPE: an HTTP error can carry the bot token).
Read only: it fetches a file the owner already sent to the bot, and sends nothing.
"""
from __future__ import annotations

import io

from aiogram import Bot


class AiogramFileDownloader:
    def __init__(self, bot: Bot):
        self._bot = bot

    async def download(self, file_id: str, max_bytes: int) -> bytes | None:
        info = await self._bot.get_file(file_id)
        if info.file_size is not None and info.file_size > max_bytes:
            return None
        if not info.file_path:
            raise RuntimeError("no file path")
        buffer = io.BytesIO()
        await self._bot.download_file(info.file_path, destination=buffer)
        data = buffer.getvalue()
        return None if len(data) > max_bytes else data
