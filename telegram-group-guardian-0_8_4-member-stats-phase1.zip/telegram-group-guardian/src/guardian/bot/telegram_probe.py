"""aiogram adapter of `owner_panel.api_check.TelegramProbe` (part 9.6): three read-only Bot API calls (`getMe`, `getWebhookInfo`,
`getChat`). Thin on purpose: every decision is made in `owner_panel/api_check.py`. aiogram is not imported here, so an error is
recognised there by its class name.

A `getChat` failure that means "the bot cannot see that chat" (not a member / chat not found / forbidden) is answered `False`;
anything else (network, rate limit, a refused token) is re-raised so the checker reports it as an unknown, not as a bad group."""
from __future__ import annotations

from typing import Any

from ..owner_panel.api_check import WebhookState

_CANNOT_SEE = frozenset({"TelegramBadRequest", "TelegramForbiddenError", "TelegramNotFound"})


class AiogramTelegramProbe:
    def __init__(self, bot: Any):
        self._bot = bot

    async def username(self) -> str:
        me = await self._bot.get_me()
        return str(getattr(me, "username", "") or "")

    async def webhook(self) -> WebhookState:
        info = await self._bot.get_webhook_info()
        pending = getattr(info, "pending_update_count", 0)
        return WebhookState(
            url=str(getattr(info, "url", "") or ""),
            pending=pending if isinstance(pending, int) and not isinstance(pending, bool) else 0,
            last_error_at=getattr(info, "last_error_date", None),
            last_error=getattr(info, "last_error_message", None))

    async def chat_reachable(self, chat_id: int) -> bool:
        try:
            await self._bot.get_chat(chat_id)
            return True
        except Exception as exc:
            if {c.__name__ for c in type(exc).__mro__} & _CANNOT_SEE:
                return False
            raise
