"""aiogram adapter for `telegram_rights.ChatInfoProvider` (getChatMember with a short cache).

* `fresh=True` bypasses the cache: authorization decisions always use fresh data.
* One bounded retry when Telegram answers with a small `retry_after`; any other failure
  becomes TelegramLookupFailed so callers fail closed.
* Duck-typed on purpose (no aiogram imports) so it can be unit-tested with fakes.
  NOT verified against the real Telegram API in the build sandbox.
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Awaitable, Callable

from ..errors import TelegramLookupFailed
from ..telegram_rights import AdminInfo, ChatMemberInfo, admin_info_from_telegram, member_info_from_telegram

log = logging.getLogger(__name__)
_MAX_CACHE = 5000


class AiogramChatInfo:
    def __init__(
        self,
        bot: Any,
        *,
        ttl: float = 30.0,
        max_retry_after: float = 3.0,
        clock: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
    ):
        self._bot = bot
        self._ttl = ttl
        self._max_retry = max_retry_after
        self._clock = clock
        self._sleep = sleep
        self._cache: dict[tuple[int, int], tuple[float, ChatMemberInfo]] = {}
        self._admins: dict[int, tuple[float, list[AdminInfo]]] = {}

    async def get_member(self, chat_id: int, user_id: int, *, fresh: bool = False) -> ChatMemberInfo:
        key = (chat_id, user_id)
        now = self._clock()
        if not fresh:
            hit = self._cache.get(key)
            if hit is not None and hit[0] > now:
                return hit[1]
        info = member_info_from_telegram(await self._call(chat_id, user_id))
        if len(self._cache) >= _MAX_CACHE:
            self._cache.clear()
        self._cache[key] = (self._clock() + self._ttl, info)
        return info

    async def get_bot_member(self, chat_id: int) -> ChatMemberInfo:
        try:
            me = await self._bot.me()
            bot_id = me.id
        except Exception as exc:
            raise TelegramLookupFailed("could not resolve bot identity") from exc
        return await self.get_member(chat_id, bot_id)

    async def list_admins(self, chat_id: int) -> list[AdminInfo]:
        """getChatAdministrators, cached for `ttl` seconds. Display only (never used to authorize)."""
        now = self._clock()
        hit = self._admins.get(chat_id)
        if hit is not None and hit[0] > now:
            return list(hit[1])
        try:
            raw = await self._bot.get_chat_administrators(chat_id)
        except Exception as exc:
            retry_after = getattr(exc, "retry_after", None)
            if isinstance(retry_after, (int, float)) and 0 < retry_after <= self._max_retry:
                await self._sleep(float(retry_after))
                try:
                    raw = await self._bot.get_chat_administrators(chat_id)
                except Exception as exc2:
                    log.warning("getChatAdministrators failed (%s)", type(exc2).__name__)
                    raise TelegramLookupFailed(type(exc2).__name__) from None
            else:
                log.warning("getChatAdministrators failed (%s)", type(exc).__name__)
                raise TelegramLookupFailed(type(exc).__name__) from None
        admins = [a for a in (admin_info_from_telegram(m) for m in raw or ()) if a is not None]
        if len(self._admins) >= _MAX_CACHE:
            self._admins.clear()
        self._admins[chat_id] = (now + self._ttl, admins)
        return list(admins)

    async def _call(self, chat_id: int, user_id: int) -> Any:
        for attempt in (1, 2):
            try:
                return await self._bot.get_chat_member(chat_id, user_id)
            except Exception as exc:
                retry_after = getattr(exc, "retry_after", None)
                if attempt == 1 and isinstance(retry_after, (int, float)) and 0 < retry_after <= self._max_retry:
                    await self._sleep(float(retry_after))
                    continue
                # Never include str(exc): API errors can echo request details.
                log.warning("getChatMember failed (%s)", type(exc).__name__)
                raise TelegramLookupFailed(type(exc).__name__) from None
        raise TelegramLookupFailed("unreachable")  # pragma: no cover
