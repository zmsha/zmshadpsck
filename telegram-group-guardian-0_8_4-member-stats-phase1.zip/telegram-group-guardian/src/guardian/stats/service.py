"""Statistics service (Phase 6 / part 6.5a): REAL data only, read-only, per group.

Sources (nothing is estimated or invented):
  warnings  -> `moderation_warnings`   (issued automatic/manual, revoked)
  sanctions -> `moderation_sanctions`  (mute/ban/kick by origin, lifted)
  reports   -> `group_reports`         (created by type, handled by outcome, open now)
  audit     -> `security_audit_log`    (events by type; limited by the audit retention, which is >= 30 days)
  counters  -> `daily_group_counters`  (violations acted on, commands handled, commands rejected)

WHO may read is decided by the caller: this service performs NO permission or licence check (like `ReportService`).
The `/stats` command of part 6.5b must require `MODERATE` for one group (or the primary owner for the overall view)
and the effective licence before it calls `group_stats`/`overall`. `overall` takes the group ids from its caller: it
never lists groups itself (the cross-group listing stays confined to the owner surfaces).

A source that fails does not fail the others: its section stays zero-filled and is named in `GroupStats.missing`.
"""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Callable, Sequence

from ..errors import InvalidInput
from ..moderation.models import check_group_id
from ..reports.models import OPEN_STATUSES
from ..time_utils import ensure_utc, utcnow
from .models import (REPORT_KEYS, SANCTION_KEYS, SECTION_AUDIT, SECTION_COUNTERS, SECTION_REPORTS, SECTION_SANCTIONS,
                     SECTION_WARNINGS, WARNING_KEYS, COUNTER_VALUES, GroupStats, PeriodRange, StatsPeriod, combine,
                     period_range)

log = logging.getLogger(__name__)

MAX_OVERALL_GROUPS = 500


def _filled(keys: tuple[str, ...], found: dict[str, int]) -> dict[str, int]:
    out = {k: 0 for k in keys}
    for k, v in found.items():
        if k in out:
            out[k] = int(v)
    return out


class StatsService:
    """Every source is optional (None => that section is reported as missing)."""

    def __init__(self, *, warnings: Any = None, sanctions: Any = None, reports: Any = None, audit: Any = None,
                 counters: Any = None, display_timezone: str = "Asia/Riyadh",
                 clock: Callable[[], datetime] = utcnow) -> None:
        self._warnings, self._sanctions, self._reports = warnings, sanctions, reports
        self._audit, self._counters = audit, counters
        self._tz, self._clock = display_timezone, clock

    def range_for(self, period: StatsPeriod, now: datetime | None = None) -> PeriodRange:
        return period_range(period, ensure_utc(now or self._clock()), self._tz)

    async def group_stats(self, group_id: int, period: StatsPeriod = StatsPeriod.DAY,
                          now: datetime | None = None) -> GroupStats:
        check_group_id(group_id)
        return await self.range_stats(group_id, self.range_for(StatsPeriod(period), now))

    async def range_stats(self, group_id: int, rng: PeriodRange) -> GroupStats:
        """The same read for an explicit range (part 6.6b: a CALENDAR period from `CalendarPeriod.to_range()`).
        No permission or licence decision here either; the caller (the periodic delivery) makes both."""
        check_group_id(group_id)
        if not isinstance(rng, PeriodRange):
            raise InvalidInput("a period range is required")
        missing: list[str] = []

        async def read(section: str, source: Any, call) -> dict[str, int] | None:
            if source is None:
                missing.append(section)
                return None
            try:
                return await call()
            except Exception:
                log.warning("stats section unreadable section=%s", section, extra={"group_id": group_id}, exc_info=True)
                missing.append(section)
                return None

        warnings = await read(SECTION_WARNINGS, self._warnings,
                              lambda: self._warnings.count_in_range(group_id, rng.start, rng.end))
        sanctions = await read(SECTION_SANCTIONS, self._sanctions,
                               lambda: self._sanctions.count_in_range(group_id, rng.start, rng.end))
        reports = await read(SECTION_REPORTS, self._reports, lambda: self._report_counts(group_id, rng))
        audit = await read(SECTION_AUDIT, self._audit,
                           lambda: self._audit.count_by_type(group_id, rng.start, rng.end))
        counters = await read(SECTION_COUNTERS, self._counters,
                              lambda: self._counters.totals(group_id, rng.start_day, rng.end_day))
        return GroupStats(
            group_id, rng, _filled(WARNING_KEYS, warnings or {}), _filled(SANCTION_KEYS, sanctions or {}),
            _filled(REPORT_KEYS, reports or {}), {k: int(v) for k, v in (audit or {}).items()},
            _filled(COUNTER_VALUES, counters or {}), tuple(missing))

    async def _report_counts(self, group_id: int, rng: PeriodRange) -> dict[str, int]:
        found = dict(await self._reports.count_in_range(group_id, rng.start, rng.end))
        found["open_now"] = await self._reports.count(group_id, OPEN_STATUSES)  # a point in time, not a period total
        return found

    async def overall(self, group_ids: Sequence[int], period: StatsPeriod = StatsPeriod.DAY,
                      now: datetime | None = None) -> GroupStats:
        """Sum over the groups the CALLER names (duplicates ignored). One clock reading is shared by all of them, so the
        parts always have the same range."""
        ids = list(dict.fromkeys(group_ids))
        if not ids:
            raise InvalidInput("no groups to summarise")
        if len(ids) > MAX_OVERALL_GROUPS:
            raise InvalidInput("too many groups")
        at = ensure_utc(now or self._clock())
        return combine([await self.group_stats(g, period, at) for g in ids])
