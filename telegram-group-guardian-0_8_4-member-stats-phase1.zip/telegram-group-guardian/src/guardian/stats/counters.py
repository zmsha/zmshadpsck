"""Best-effort writer of the daily counters. It is called from the hot paths (protection engine, command executor),
so it NEVER raises and never blocks a decision: a failed write only costs one tick of a statistic."""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Callable

from ..moderation.models import check_group_id
from ..time_utils import utcnow
from .models import Counter, day_bucket
from .store import CounterStore

log = logging.getLogger(__name__)


class CounterRecorder:
    def __init__(self, store: CounterStore, display_timezone: str = "Asia/Riyadh",
                 clock: Callable[[], datetime] = utcnow) -> None:
        self._store, self._tz, self._clock = store, display_timezone, clock

    async def bump(self, group_id: int, counter: Counter, now: datetime | None = None, amount: int = 1) -> bool:
        """True when the increment was stored; False (never an exception) otherwise."""
        try:
            check_group_id(group_id)
            counter = Counter(counter)
            if not isinstance(amount, int) or isinstance(amount, bool) or amount < 1:
                return False
            at = now or self._clock()
            await self._store.bump(group_id, day_bucket(at, self._tz), counter, amount, at)
            return True
        except Exception:
            log.warning("daily counter write failed counter=%s", getattr(counter, "value", counter),
                        extra={"group_id": group_id}, exc_info=True)
            return False
