"""Periodic reports, part 6.6b: DELIVERY. Part 6.6a decides which calendar periods are owed; this module sends them.

There is no scheduler (Render Free sleeps), so delivery rides on incoming updates exactly like the verification sweeper
and the audit retention: the message middleware calls `on_update(bot, chat_id, allowed)` for every group message. The
first update after a sleep therefore catches up (the newest owed periods, see `CATCH_UP_LIMIT`). A group nobody writes
in does not receive its report until somebody does: the stores deliberately cannot list groups.

Rules (each one has tests):
* LICENCE: nothing is sent unless the licence allows protection in that chat right now (`allowed` comes from the gate's
  context of the very update that triggered the tick). An inactive group owes and receives nothing; the periods stay
  owed and the catch-up limit applies when it is active again.
* DESTINATION: the group's approved report destination (6.4a), else the group itself. An unreadable setting means
  NOTHING is sent (fail closed, like the panel); a failed send never falls back to another chat.
* NOT MARKED ON FAILURE: `mark_done` runs only AFTER a successful send, so a failed send is retried. To make that safe
  without losing a report or sending it twice at the same time, each attempt takes a short DURABLE LEASE: an idempotency
  claim per (group, period, key, ten-minute window). Only the holder of the window's lease sends; a failure simply lets
  the next window try again. A report is sent at most once per window and, in the single-instance deployment, never
  concurrently; the one remaining duplicate is a crash between the send and `mark_done` (at-least-once, by design: a
  repeated report is better than a lost one).
* ORDER: per period oldest first, one failure stops that period (a newer mark would swallow the older one).
* BOUNDED: at most `MAX_PER_TICK` reports per run; the rest follow on the next run. A group is looked at at most once
  per `CHECK_INTERVAL` (and with exponential back-off after a failure), so ordinary traffic costs no database reads.
* NEVER BLOCKS: the work runs in a background task; the update is not delayed and nothing here ever raises into it.
* CONTENT: the report is the `/stats` sections for the finished period: numbers only, no identities, no free text.
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Callable

from ..audit import PERIODIC_REPORT_SENT, RESULT_APPLIED, SecurityAudit, make_event, record_safely
from ..idempotency import operation_key
from ..moderation.models import check_group_id
from ..reports.destination import destination_of
from ..time_utils import ensure_utc, utcnow
from .models import StatsPeriod
from .periodic import CalendarPeriod
from .render import render_periodic

log = logging.getLogger(__name__)

CHECK_INTERVAL = 300.0       # seconds between two looks at the same group
MAX_BACKOFF = 6 * 3600.0     # ceiling of the back-off after failures
LEASE_SECONDS = 600          # one sending attempt per (report, window)
MAX_PER_TICK = 3             # reports sent by one run
MAX_TASKS = 5                # background runs in flight at once (more are skipped until the next update)
MAX_TRACKED = 5000           # groups remembered by the in-memory throttle
_ORDER = (StatsPeriod.DAY, StatsPeriod.WEEK, StatsPeriod.MONTH)


def lease_key(group_id: int, period: StatsPeriod, key: str, at: datetime) -> str:
    """The durable lease of one sending attempt: the same report in the same ten-minute window yields the same key."""
    window = int(ensure_utc(at).timestamp() // LEASE_SECONDS)
    return operation_key("periodicsend", check_group_id(group_id), StatsPeriod(period).value, key, window)


@dataclass(frozen=True, slots=True)
class DeliveryRun:
    sent: int = 0            # reports that reached the chat in this run
    failed: bool = False     # a send / read failed (the group is retried with back-off)
    pending: bool = False    # more owed reports remain (limit reached or leased by another run)


class PeriodicDelivery:
    def __init__(self, *, schedule: Any, stats: Any, claims: Any, load_raw: Callable[[int], Any],
                 audit: SecurityAudit | None = None, language: str = "ar",
                 clock: Callable[[], datetime] = utcnow, mono: Callable[[], float] = time.monotonic) -> None:
        self._schedule, self._stats, self._claims, self._load_raw = schedule, stats, claims, load_raw
        self._audit, self._lang, self._clock, self._mono = audit, language, clock, mono
        self._next: dict[int, float] = {}       # group -> monotonic time of the next look
        self._fails: dict[int, int] = {}        # group -> consecutive failed runs
        self._running: set[int] = set()
        self._tasks: set[asyncio.Task] = set()
        self._sent: set[tuple[int, str, str]] = set()   # sent but not yet marked (mark_done failed): never re-sent

    # ------------------------------------------------------------------ the hook (synchronous, cheap, never raises)
    def on_update(self, bot: Any, chat_id: Any, allowed: bool) -> bool:
        """Called for every group message. True only when a background run was started."""
        try:
            if (bot is None or not allowed or not isinstance(chat_id, int) or isinstance(chat_id, bool)
                    or chat_id >= 0 or chat_id in self._running or len(self._tasks) >= MAX_TASKS):
                return False
            now = self._mono()
            if now < self._next.get(chat_id, 0.0):
                return False
            if len(self._next) >= MAX_TRACKED:
                self._next = {g: t for g, t in self._next.items() if t > now}
                if len(self._next) >= MAX_TRACKED:
                    self._next.clear()
            self._next[chat_id] = now + CHECK_INTERVAL
            self._running.add(chat_id)
            task = asyncio.get_running_loop().create_task(self._run(bot, chat_id))
            self._tasks.add(task)
            task.add_done_callback(self._tasks.discard)
            return True
        except Exception:
            log.error("periodic delivery hook failed", exc_info=True)
            return False

    async def _run(self, bot: Any, group_id: int) -> None:
        try:
            run = await self.deliver_group(bot, group_id)
            fails = self._fails.get(group_id, 0) + 1 if run.failed else 0
        except Exception:
            log.error("periodic delivery failed", exc_info=True, extra={"group_id": group_id})
            fails = self._fails.get(group_id, 0) + 1
            run = DeliveryRun(failed=True)
        finally:
            self._running.discard(group_id)
        if fails:
            self._fails[group_id] = min(fails, 16)
            self._next[group_id] = self._mono() + min(CHECK_INTERVAL * 2 ** fails, MAX_BACKOFF)
        else:
            self._fails.pop(group_id, None)
            if run.pending:
                self._next[group_id] = self._mono()     # more to send: look again at the next update

    async def aclose(self) -> None:
        """Cancel runs still in flight (shutdown). Whatever was not marked done is simply owed again next time."""
        for task in list(self._tasks):
            task.cancel()
        if self._tasks:
            await asyncio.gather(*self._tasks, return_exceptions=True)

    async def drain(self) -> None:
        """Wait for the runs in flight (tests, shutdown)."""
        if self._tasks:
            await asyncio.gather(*self._tasks, return_exceptions=True)

    # ------------------------------------------------------------------ the work
    async def deliver_group(self, bot: Any, group_id: int, now: datetime | None = None) -> DeliveryRun:
        """Send what `group_id` owes. Store errors propagate to `_run` (back-off); a send error is a failed run."""
        check_group_id(group_id)
        at = ensure_utc(now or self._clock())
        owed = await self._schedule.owed_all(group_id, at)
        if not owed:
            return DeliveryRun()
        try:
            destination = destination_of(await self._load_raw(group_id), group_id)
        except Exception:
            log.warning("periodic report settings unreadable; nothing sent", extra={"group_id": group_id}, exc_info=True)
            return DeliveryRun(failed=True)
        budget, sent, failed = MAX_PER_TICK, 0, False
        for period in _ORDER:
            entry = owed.get(period)
            if entry is None:
                continue
            for index, cal in enumerate(entry.periods):
                if (group_id, period.value, cal.key) in self._sent:
                    await self._finish(group_id, period, cal, at, resend=False)
                    continue
                if budget <= 0:
                    return DeliveryRun(sent, failed, True)
                if not await self._claims.claim(lease_key(group_id, period, cal.key, at), at):
                    return DeliveryRun(sent, failed, True)   # another run holds this window's lease: later
                text = await self._build(group_id, cal, entry.skipped if index == 0 else 0)
                budget -= 1
                try:
                    await bot.send_message(destination, text)
                except Exception as exc:
                    log.warning("periodic report send failed (%s)", type(exc).__name__, extra={"group_id": group_id})
                    failed = True
                    break    # a newer period must not be marked past this one
                sent += 1
                await self._finish(group_id, period, cal, at, resend=True)
        return DeliveryRun(sent, failed, False)

    async def _build(self, group_id: int, cal: CalendarPeriod, skipped: int) -> str:
        stats = await self._stats.range_stats(group_id, cal.to_range())
        return render_periodic(stats, self._lang, skipped=skipped)

    async def _finish(self, group_id: int, period: StatsPeriod, cal: CalendarPeriod, at: datetime, *, resend: bool) -> None:
        """Mark one period handled AFTER its send. A store failure leaves it remembered (no second send) and retried."""
        token = (group_id, period.value, cal.key)
        if resend:
            self._sent.add(token)
            if len(self._sent) > MAX_TRACKED:
                self._sent.clear()
                self._sent.add(token)
        try:
            await self._schedule.mark_done(group_id, period, cal.key, at)
        except Exception:
            log.error("periodic report mark_done failed", exc_info=True, extra={"group_id": group_id})
            return
        self._sent.discard(token)
        if resend:
            await record_safely(self._audit, make_event(
                PERIODIC_REPORT_SENT, group_id=group_id, now=at, target=period.value, result=RESULT_APPLIED,
                detail=f"period={period.value} key={cal.key}"))
