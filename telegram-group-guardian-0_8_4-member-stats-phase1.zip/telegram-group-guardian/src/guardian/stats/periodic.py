"""Periodic reports, part 6.6a: CALENDAR periods, the per-group switch and "which periods are owed". Nothing is sent.

Calendar periods are different from the rolling windows of `/stats` (`StatsPeriod`: today / last 7 / last 30 days):
  day   = one local calendar day                                  key 'YYYY-MM-DD'
  week  = Sunday 00:00 .. next Sunday 00:00 (local)               key 'YYYY-MM-DD' = the Sunday it starts on
  month = the calendar month (1st 00:00 .. next 1st 00:00)       key 'YYYY-MM'      (NOT the licence's 30-day month)
"Local" is `DISPLAY_TIMEZONE` (Asia/Riyadh = Makkah time by default); bounds are local midnights converted to UTC, so
the periods are DST-safe and are `[start, end)` like `PeriodRange`. A period key is the idempotent identity of one
report: (group, period, key) is handled at most once because `mark_done` never moves backwards.

What is "owed" (pure arithmetic over period ordinals, no loops, so a year of sleep costs nothing):
  * only COMPLETED periods (the one containing `now` is never owed);
  * only periods that end after `enabled_from` (the one containing the moment of switching on counts once it ends;
    earlier ones are never replayed);
  * only periods newer than `last_period_key`;
  * at most `CATCH_UP_LIMIT` of them, the NEWEST ones, oldest first; older ones are counted in `Owed.skipped` and are
    forgotten once the newest is marked done (a long sleep must not become a flood of reports).

Like `ReportService`/`StatsService` this module makes NO permission or licence decision: who may switch a report on, and
refusing to send while the licence is inactive, belong to the callers (a command, and the delivery of part 6.6b).
Store errors propagate; the delivery tick of 6.6b must catch them (a failing read means "nothing owed this time").
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from enum import Enum
from typing import Any, Callable
from zoneinfo import ZoneInfo

from ..audit import REPORT_SCHEDULE_SET, RESULT_APPLIED, SecurityAudit, make_event, record_safely
from ..errors import InvalidInput
from ..idempotency import operation_key
from ..moderation.models import check_group_id, check_user_id
from ..time_utils import UTC, ensure_utc, utcnow
from .models import PeriodRange, StatsPeriod, day_bucket
from .schedule_store import ScheduleEntry

log = logging.getLogger(__name__)

# How many owed periods one catch-up may hand over (the newest ones); see the module docstring.
CATCH_UP_LIMIT = {StatsPeriod.DAY: 3, StatsPeriod.WEEK: 2, StatsPeriod.MONTH: 2}
MAX_CATCH_UP = 60

_DATE_KEY = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}")
_MONTH_KEY = re.compile(r"[0-9]{4}-[0-9]{2}")


# --------------------------------------------------------------------------- calendar arithmetic
def _period(value: object) -> StatsPeriod:
    try:
        return StatsPeriod(value)
    except ValueError:
        raise InvalidInput("unknown report period") from None


def _local_midnight_utc(day: date, tz: ZoneInfo) -> datetime:
    return datetime(day.year, day.month, day.day, tzinfo=tz).astimezone(UTC)


def _week_start(day: date) -> date:
    """The Sunday on or before `day` (Monday=0 ... Sunday=6)."""
    return day - timedelta(days=(day.weekday() + 1) % 7)


def _ordinal_of(period: StatsPeriod, day: date) -> int:
    """Consecutive integer of the calendar period that contains the local date `day`."""
    if period is StatsPeriod.DAY:
        return day.toordinal()
    if period is StatsPeriod.WEEK:
        return _week_start(day).toordinal() // 7   # every Sunday's ordinal is a multiple of 7
    return day.year * 12 + day.month - 1


def _first_day(period: StatsPeriod, ordinal: int) -> date:
    try:
        if period is StatsPeriod.DAY:
            return date.fromordinal(ordinal)
        if period is StatsPeriod.WEEK:
            return date.fromordinal(ordinal * 7)
        return date(ordinal // 12, ordinal % 12 + 1, 1)
    except (ValueError, OverflowError):
        raise InvalidInput("report period out of range") from None


def _key_of(period: StatsPeriod, first: date) -> str:
    return f"{first.year:04d}-{first.month:02d}" if period is StatsPeriod.MONTH else first.isoformat()


@dataclass(frozen=True, slots=True)
class CalendarPeriod:
    """One calendar day / Sunday-week / month. `key` is its idempotent identity."""
    period: StatsPeriod
    key: str
    first_day: date          # first local day (inclusive)
    after_day: date          # first local day AFTER the period (exclusive)
    start: datetime          # UTC, inclusive
    end: datetime            # UTC, exclusive
    timezone: str

    @property
    def last_day(self) -> date:
        return self.after_day - timedelta(days=1)

    @property
    def ordinal(self) -> int:
        return _ordinal_of(self.period, self.first_day)

    def to_range(self) -> PeriodRange:
        """The same shape `/stats` reads with (`start_day..end_day` inclusive local dates for the daily counters)."""
        return PeriodRange(self.period, self.start, self.end, self.first_day, self.last_day, self.timezone)


def _build(period: StatsPeriod, ordinal: int, tz_name: str) -> CalendarPeriod:
    tz = ZoneInfo(tz_name)
    first, after = _first_day(period, ordinal), _first_day(period, ordinal + 1)
    return CalendarPeriod(period, _key_of(period, first), first, after, _local_midnight_utc(first, tz),
                          _local_midnight_utc(after, tz), tz_name)


def period_containing(period: StatsPeriod, at: datetime, tz_name: str) -> CalendarPeriod:
    period = _period(period)
    return _build(period, _ordinal_of(period, day_bucket(at, tz_name)), tz_name)


def last_completed(period: StatsPeriod, now: datetime, tz_name: str) -> CalendarPeriod:
    """The newest period that has fully ended at `now` (the one before the period containing `now`)."""
    period = _period(period)
    return _build(period, _ordinal_of(period, day_bucket(now, tz_name)) - 1, tz_name)


def parse_period_key(period: StatsPeriod, key: object, tz_name: str) -> CalendarPeriod:
    """The period a key names. Strict: wrong shape, impossible date, a 'week' key that is not a Sunday -> InvalidInput."""
    period = _period(period)
    if not isinstance(key, str):
        raise InvalidInput("period key must be text")
    try:
        if period is StatsPeriod.MONTH:
            if not _MONTH_KEY.fullmatch(key):
                raise ValueError
            first = date(int(key[:4]), int(key[5:7]), 1)
        else:
            if not _DATE_KEY.fullmatch(key):
                raise ValueError
            first = date(int(key[:4]), int(key[5:7]), int(key[8:10]))
            if period is StatsPeriod.WEEK and first.weekday() != 6:
                raise ValueError
    except ValueError:
        raise InvalidInput("invalid period key") from None
    return _build(period, _ordinal_of(period, first), tz_name)


def claim_key(group_id: int, period: StatsPeriod, key: str) -> str:
    """Durable idempotency-claim key of ONE report of ONE group (for the delivery of part 6.6b)."""
    return operation_key("periodic", check_group_id(group_id), _period(period).value, key)


# --------------------------------------------------------------------------- what is owed
@dataclass(frozen=True, slots=True)
class Owed:
    periods: tuple[CalendarPeriod, ...] = ()   # oldest first; the NEWEST owed ones, at most the catch-up limit
    skipped: int = 0                           # older owed periods dropped by the limit

    def __bool__(self) -> bool:
        return bool(self.periods)


def owed_periods(period: StatsPeriod, now: datetime, tz_name: str, *, enabled_from: datetime | None,
                 last_key: str | None, limit: int | None = None) -> Owed:
    period = _period(period)
    limit = CATCH_UP_LIMIT[period] if limit is None else limit
    if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= MAX_CATCH_UP:
        raise InvalidInput("catch-up limit out of range")
    if enabled_from is None:
        return Owed()
    newest = _ordinal_of(period, day_bucket(now, tz_name)) - 1
    below = _ordinal_of(period, day_bucket(enabled_from, tz_name)) - 1   # the period containing the switch-on is owed
    if last_key is not None:
        below = max(below, parse_period_key(period, last_key, tz_name).ordinal)
    count = newest - below
    if count <= 0:
        return Owed()
    take = min(count, limit)
    return Owed(tuple(_build(period, n, tz_name) for n in range(newest - take + 1, newest + 1)), count - take)


# --------------------------------------------------------------------------- the service
class SwitchCode(str, Enum):
    CHANGED = "changed"
    UNCHANGED = "unchanged"


@dataclass(frozen=True, slots=True)
class SwitchResult:
    code: SwitchCode
    enabled: bool          # the switch as requested (and, whatever the code, as it now stands)


class ReportScheduleService:
    """Per-group switches (day/week/month, OFF by default), the handled-up-to marker and the owed periods."""

    def __init__(self, store: Any, audit: SecurityAudit | None = None, *, display_timezone: str = "Asia/Riyadh",
                 clock: Callable[[], datetime] = utcnow) -> None:
        ZoneInfo(display_timezone)   # fail at construction, not at the first report
        self._store, self._audit, self._tz, self._clock = store, audit, display_timezone, clock

    async def entries(self, group_id: int) -> dict[StatsPeriod, ScheduleEntry]:
        """All three periods; one with no row is the default entry (off)."""
        check_group_id(group_id)
        found = {e.period: e for e in await self._store.get_all(group_id)}
        return {p: found.get(p) or ScheduleEntry(group_id, p) for p in StatsPeriod}

    async def is_enabled(self, group_id: int, period: StatsPeriod) -> bool:
        return (await self.entries(group_id))[_period(period)].enabled

    async def set_enabled(self, group_id: int, period: StatsPeriod, enabled: bool, actor_id: int,
                          now: datetime | None = None) -> SwitchResult:
        """Switch one period on/off. Audited (period word + on/off, never anything else) only when it really changed."""
        check_group_id(group_id)
        check_user_id(actor_id)
        period = _period(period)
        if not isinstance(enabled, bool):
            raise InvalidInput("enabled must be true or false")
        at = ensure_utc(now or self._clock())
        changed = await self._store.set_enabled(group_id, period, enabled, actor_id, at)
        if changed:
            await record_safely(self._audit, make_event(
                REPORT_SCHEDULE_SET, actor=actor_id, group_id=group_id, now=at, target=period.value,
                result=RESULT_APPLIED, detail=f"period={period.value} enabled={'on' if enabled else 'off'}"))
        return SwitchResult(SwitchCode.CHANGED if changed else SwitchCode.UNCHANGED, enabled)

    async def owed(self, group_id: int, period: StatsPeriod, now: datetime | None = None,
                   limit: int | None = None) -> Owed:
        """Periods of this group still to report (see the module docstring). A period that is off owes nothing."""
        period = _period(period)
        entry = (await self.entries(group_id))[period]
        if not entry.enabled:
            return Owed()
        return owed_periods(period, ensure_utc(now or self._clock()), self._tz, enabled_from=entry.enabled_from,
                            last_key=entry.last_period_key, limit=limit)

    async def owed_all(self, group_id: int, now: datetime | None = None) -> dict[StatsPeriod, Owed]:
        """Only the periods that owe something, from ONE read of the group's rows."""
        at = ensure_utc(now or self._clock())
        out: dict[StatsPeriod, Owed] = {}
        for period, entry in (await self.entries(group_id)).items():
            if entry.enabled:
                owed = owed_periods(period, at, self._tz, enabled_from=entry.enabled_from,
                                    last_key=entry.last_period_key)
                if owed:
                    out[period] = owed
        return out

    async def mark_done(self, group_id: int, period: StatsPeriod, key: str, now: datetime | None = None) -> bool:
        """Record that the report of `key` (and everything older) is handled. A period that has not ended yet is
        refused; a key that is not newer than the stored one is a harmless False. 6.6b calls it only AFTER a send."""
        check_group_id(group_id)
        period = _period(period)
        at = ensure_utc(now or self._clock())
        named = parse_period_key(period, key, self._tz)
        if named.end > at:
            raise InvalidInput("period has not ended yet")
        return await self._store.mark_done(group_id, period, named.key, at)
