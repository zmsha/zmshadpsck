"""In-memory schedule store (tests / local experiments only; state is lost on restart)."""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime

from .models import StatsPeriod
from .schedule_store import ScheduleEntry


class InMemoryScheduleStore:
    def __init__(self) -> None:
        self._rows: dict[tuple[int, str], ScheduleEntry] = {}

    async def get_all(self, group_id) -> list[ScheduleEntry]:
        return sorted((e for (g, _), e in self._rows.items() if g == group_id), key=lambda e: e.period.value)

    async def set_enabled(self, group_id, period, enabled, actor_id, now) -> bool:
        period = StatsPeriod(period)
        key = (group_id, period.value)
        current = self._rows.get(key)
        if enabled:
            if current is not None and current.enabled:
                return False
            base = current or ScheduleEntry(group_id, period)
            self._rows[key] = replace(base, enabled=True, enabled_from=now, changed_by=actor_id, updated_at=now)
            return True
        if current is None or not current.enabled:
            return False
        self._rows[key] = replace(current, enabled=False, changed_by=actor_id, updated_at=now)
        return True

    async def mark_done(self, group_id, period, key, now) -> bool:
        row_key = (group_id, StatsPeriod(period).value)
        current = self._rows.get(row_key)
        if current is None or (current.last_period_key is not None and current.last_period_key >= key):
            return False
        self._rows[row_key] = replace(current, last_period_key=key, updated_at=now)
        return True
