"""Persistence contract of the daily counters. EVERY method takes `group_id` and never touches another group's rows."""
from __future__ import annotations

from datetime import date, datetime
from typing import Protocol

from .models import Counter


class CounterStore(Protocol):
    async def bump(self, group_id: int, day: date, counter: Counter, amount: int, now: datetime) -> None:
        """Add `amount` (>= 1) to the (group, day, counter) total, creating the row on first use (atomic upsert)."""
        ...

    async def totals(self, group_id: int, start_day: date, end_day: date) -> dict[str, int]:
        """Sum per counter over `start_day..end_day` inclusive (counters with no row are simply absent)."""
        ...
