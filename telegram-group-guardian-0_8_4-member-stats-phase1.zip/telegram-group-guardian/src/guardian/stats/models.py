"""Statistics value types: periods, the counter vocabulary and the result of a read (Phase 6 / part 6.5a)."""
from __future__ import annotations

import enum
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

from ..time_utils import UTC, ensure_utc


class StatsPeriod(str, enum.Enum):
    """ROLLING windows ending today (local calendar days): day = today, week = last 7 days, month = last 30 days.
    (Calendar weeks/months are the periodic reports' business, part 6.6.)"""
    DAY = "day"
    WEEK = "week"
    MONTH = "month"


PERIOD_DAYS = {StatsPeriod.DAY: 1, StatsPeriod.WEEK: 7, StatsPeriod.MONTH: 30}


class Counter(str, enum.Enum):
    """Closed vocabulary of `daily_group_counters.counter` (repeated in migration 0009; a test keeps them in sync)."""
    VIOLATION = "violation"
    COMMAND = "command"
    COMMAND_REJECTED = "command_rejected"


COUNTER_VALUES = tuple(c.value for c in Counter)

# Section names (also the keys of GroupStats.missing).
SECTION_WARNINGS, SECTION_SANCTIONS, SECTION_REPORTS = "warnings", "sanctions", "reports"
SECTION_AUDIT, SECTION_COUNTERS = "audit", "counters"
SECTIONS = (SECTION_WARNINGS, SECTION_SANCTIONS, SECTION_REPORTS, SECTION_AUDIT, SECTION_COUNTERS)

# Zero-filled keys of each section (audit is open: one key per event type that occurred).
WARNING_KEYS = ("issued_auto", "issued_manual", "revoked")
SANCTION_KEYS = ("mute_auto", "mute_manual", "ban_auto", "ban_manual", "kick_auto", "kick_manual", "lifted")
REPORT_KEYS = ("created", "type_spam", "type_abuse", "type_scam", "type_other",
               "handled_action_taken", "handled_no_action", "handled_false_report", "open_now")


@dataclass(frozen=True, slots=True)
class PeriodRange:
    """`[start, end)` in UTC for timestamps; `start_day..end_day` (inclusive, local dates) for the daily counters."""
    period: StatsPeriod
    start: datetime
    end: datetime
    start_day: date
    end_day: date
    timezone: str


def day_bucket(now: datetime, tz_name: str) -> date:
    """The local calendar date of `now` (the `day` column of the counters)."""
    return ensure_utc(now).astimezone(ZoneInfo(tz_name)).date()


def _local_midnight_utc(day: date, tz: ZoneInfo) -> datetime:
    return datetime(day.year, day.month, day.day, tzinfo=tz).astimezone(UTC)


def period_range(period: StatsPeriod, now: datetime, tz_name: str) -> PeriodRange:
    """The window of `period` ending with the local day that contains `now` (DST-safe: bounds are local midnights)."""
    period = StatsPeriod(period)
    tz = ZoneInfo(tz_name)
    today = day_bucket(now, tz_name)
    first = today - timedelta(days=PERIOD_DAYS[period] - 1)
    return PeriodRange(period, _local_midnight_utc(first, tz), _local_midnight_utc(today + timedelta(days=1), tz),
                       first, today, tz_name)


def _zero(keys: tuple[str, ...]) -> dict[str, int]:
    return {k: 0 for k in keys}


@dataclass(frozen=True, slots=True)
class GroupStats:
    """What happened in one group (or, for `StatsService.overall`, summed over several) during `range`.

    A section that could not be read is EMPTY (zero-filled) and listed in `missing`, so a reader never mistakes a
    failed read for "nothing happened"."""
    group_id: int | None
    range: PeriodRange
    warnings: dict[str, int] = field(default_factory=lambda: _zero(WARNING_KEYS))
    sanctions: dict[str, int] = field(default_factory=lambda: _zero(SANCTION_KEYS))
    reports: dict[str, int] = field(default_factory=lambda: _zero(REPORT_KEYS))
    audit: dict[str, int] = field(default_factory=dict)
    counters: dict[str, int] = field(default_factory=lambda: _zero(COUNTER_VALUES))
    missing: tuple[str, ...] = ()
    groups: int = 1  # how many groups were summed (1 for a single group)

    @property
    def complete(self) -> bool:
        return not self.missing


def combine(items: list[GroupStats]) -> GroupStats:
    """Sum several groups' stats (same range). `group_id` becomes None; `missing` is the union of the parts'."""
    if not items:
        raise ValueError("nothing to combine")
    rng = items[0].range
    if any(i.range != rng for i in items):
        raise ValueError("cannot combine different ranges")

    def add(attr: str) -> dict[str, int]:
        out: dict[str, int] = {}
        for item in items:
            for k, v in getattr(item, attr).items():
                out[k] = out.get(k, 0) + v
        return out

    missing = tuple(s for s in SECTIONS if any(s in i.missing for i in items))
    return GroupStats(None, rng, add("warnings"), add("sanctions"), add("reports"), add("audit"), add("counters"),
                      missing, sum(i.groups for i in items))
