"""`/stats [day|week|month]` inside a group (part 6.5b). Framework independent; reached from `ModerationCommandService._handle`.

The executor applies the gates BEFORE this class is reached, in the same fail-closed order as every moderator command:
 1. `permissions.require(MODERATE, context_chat_id=chat)`  -> DENIED (nothing leaked)
 2. the effective licence (`protection.allowed` for THIS chat) -> LICENSE_OFF
then here: 3. strict argument parsing -> INVALID, 4. `StatsService.group_stats(THIS chat, period)` -> INFO.
The group id is always the chat the command was typed in (never read from the text), so one group can never see another's
numbers. Read only: no claim, no audit row of its own, works during `dry_run`. The answer is counts only (no member ids, no
report text), so it is posted in the group like the other moderator read commands.

The primary owner's all-groups view is NOT here: it is a private-chat command (`stats/owner_command.py`) so that cross-group
totals never appear in a group.
"""
from __future__ import annotations

import logging
from typing import Any, Callable

from ..i18n import t
from ..moderation.command_error import CommandError
from ..moderation.commands import Command, ParsedCommand
from ..moderation.messages import error_message
from .args import parse_period
from .render import render

log = logging.getLogger(__name__)


class StatsCommands:
    def __init__(self, *, stats: Any, make_result: Callable[..., Any], kinds: Any):
        self._stats, self._result, self._kinds = stats, make_result, kinds

    async def handle(self, parsed: ParsedCommand, chat_id: int, lang: str):
        R, cmd = self._kinds, Command.STATS
        try:
            period = parse_period(parsed.args)
        except CommandError as exc:
            return self._result(R.INVALID, error_message(exc, lang) or t("invalid_input", lang), cmd)
        if self._stats is None:
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        try:
            stats = await self._stats.group_stats(chat_id, period)
        except Exception:
            log.error("stats read failed", extra={"group_id": chat_id}, exc_info=True)
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        return self._result(R.INFO, render(stats, lang), cmd)
