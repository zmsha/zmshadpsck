"""The primary owner's all-groups `/stats [day|week|month]` (part 6.5b): PRIVATE chat only.

Sequence (fail closed; a refusal is SILENCE, like `/owner`):
 1. private chat and `chat_id == user_id`                      -> else None
 2. `Permission.OWNER_PANEL` via `check_global` (exactly OWNER_TELEGRAM_ID; the permission service audits a refusal) -> else None
 3. strict argument parsing                                      -> a localized usage message
 4. the group ids come from `OwnerPanelService.group_ids` (the only owner surface that lists groups; this class never lists)
 5. `StatsService.overall(ids, period)` and a render with the group count

The owner needs no group licence for this view (the owner works even when a group's licence ended); the numbers of an
unlicensed group are still its own stored data. Nothing is written and nothing is sent to a group.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from ..errors import InvalidInput
from ..i18n import t
from ..moderation.command_error import CommandError
from ..moderation.commands import Command, parse_command
from ..moderation.messages import error_message
from ..permissions import Permission
from .args import parse_period
from .render import render
from .service import MAX_OVERALL_GROUPS

log = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class StatsReply:
    status: str  # ok | usage | empty | unavailable
    text: str


def match(text: object, bot_username: str | None):
    """The parsed `/stats` (English or Arabic) or None. Reuses the group parser so both surfaces accept the same words."""
    parsed = parse_command(text, bot_username)
    return parsed if parsed is not None and parsed.command is Command.STATS else None


class OwnerStatsService:
    def __init__(self, *, stats: Any, owner_panel: Any, permissions: Any, language: str = "ar"):
        self._stats, self._panel, self._perm, self._language = stats, owner_panel, permissions, language

    async def _is_owner(self, user_id: object) -> bool:
        try:
            return bool((await self._perm.check_global(user_id, Permission.OWNER_PANEL)).allowed)
        except Exception:
            log.error("owner stats permission check failed", exc_info=True)
            return False

    async def run(self, parsed: Any, *, chat_id: object, chat_type: object, user_id: object,
                  lang: str | None = None) -> StatsReply | None:
        lang = lang or self._language
        if chat_type != "private" or not isinstance(chat_id, int) or isinstance(chat_id, bool) or chat_id <= 0:
            return None
        if chat_id != user_id or not await self._is_owner(user_id):
            return None
        try:
            period = parse_period(parsed.args)
        except CommandError as exc:
            return StatsReply("usage", error_message(exc, lang) or t("invalid_input", lang))
        if self._stats is None or self._panel is None:
            return StatsReply("unavailable", t("action_failed_safe", lang))
        try:
            ids, cut = await self._panel.group_ids(user_id, MAX_OVERALL_GROUPS)
            if not ids:
                return StatsReply("empty", t("stats_no_groups", lang))
            stats = await self._stats.overall(ids, period)
        except InvalidInput:
            return StatsReply("empty", t("stats_no_groups", lang))
        except Exception:
            log.error("owner stats failed", exc_info=True)
            return StatsReply("unavailable", t("action_failed_safe", lang))
        return StatsReply("ok", render(stats, lang, overall=True, cut_at=MAX_OVERALL_GROUPS if cut else None))
