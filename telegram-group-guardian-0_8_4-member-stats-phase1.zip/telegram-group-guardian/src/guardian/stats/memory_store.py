"""In-memory counter store (tests / local experiments only; state is lost on restart)."""
from __future__ import annotations

from datetime import date, datetime

from .models import Counter


class InMemoryCounterStore:
    def __init__(self) -> None:
        self._rows: dict[tuple[int, date, str], int] = {}

    async def bump(self, group_id, day, counter, amount, now) -> None:
        key = (group_id, day, Counter(counter).value)
        self._rows[key] = self._rows.get(key, 0) + int(amount)

    async def totals(self, group_id, start_day, end_day) -> dict[str, int]:
        out: dict[str, int] = {}
        for (g, day, counter), value in self._rows.items():
            if g == group_id and start_day <= day <= end_day:
                out[counter] = out.get(counter, 0) + value
        return out
