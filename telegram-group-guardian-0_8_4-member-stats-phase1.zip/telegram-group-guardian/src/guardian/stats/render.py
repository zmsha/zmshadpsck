"""Text rendering of a `GroupStats` (part 6.5b). Pure functions: no Telegram, no permissions, no I/O.

Telegram HTML. Every number is an int; the only free text (audit event names) is escaped by `t()` (do NOT escape it twice). A section that could not be
read is NEVER shown as zeros: it is replaced by a warning line naming it (`GroupStats.missing`).
"""
from __future__ import annotations

from ..i18n import t
from .models import (SECTION_AUDIT, SECTION_COUNTERS, SECTION_REPORTS, SECTION_SANCTIONS, SECTION_WARNINGS, GroupStats,
                     StatsPeriod)

MAX_AUDIT_LINES = 5  # the audit section lists the most frequent event types only


def _days(stats: GroupStats) -> str:
    rng = stats.range
    return rng.start_day.isoformat() if rng.start_day == rng.end_day else f"{rng.start_day.isoformat()} → {rng.end_day.isoformat()}"


def _warnings(s: GroupStats, lang: str) -> str:
    w = s.warnings
    return t("stats_warnings", lang, auto=w["issued_auto"], manual=w["issued_manual"], revoked=w["revoked"])


def _sanctions(s: GroupStats, lang: str) -> str:
    c = s.sanctions
    lines = [t("stats_sanctions_head", lang)]
    for kind in ("mute", "ban", "kick"):
        lines.append(t("stats_sanction_line", lang, kind=t(f"stats_kind_{kind}", lang),
                       auto=c[f"{kind}_auto"], manual=c[f"{kind}_manual"]))
    lines.append(t("stats_sanction_lifted", lang, lifted=c["lifted"]))
    return "\n".join(lines)


def _reports(s: GroupStats, lang: str) -> str:
    r = s.reports
    return "\n".join((
        t("stats_reports_head", lang, created=r["created"], open_now=r["open_now"]),
        t("stats_reports_types", lang, spam=r["type_spam"], abuse=r["type_abuse"], scam=r["type_scam"], other=r["type_other"]),
        t("stats_reports_handled", lang, action=r["handled_action_taken"], none=r["handled_no_action"],
          false=r["handled_false_report"]),
    ))


def _counters(s: GroupStats, lang: str) -> str:
    c = s.counters
    return t("stats_activity", lang, violations=c["violation"], commands=c["command"], rejected=c["command_rejected"])


def _audit(s: GroupStats, lang: str) -> str:
    total = sum(s.audit.values())
    ranked = sorted(s.audit.items(), key=lambda kv: (-kv[1], kv[0]))
    lines = [t("stats_audit_head", lang, total=total)]
    for name, n in ranked[:MAX_AUDIT_LINES]:
        lines.append(t("stats_audit_line", lang, name=str(name), n=n))
    if len(ranked) > MAX_AUDIT_LINES:
        lines.append(t("stats_audit_more", lang, n=len(ranked) - MAX_AUDIT_LINES))
    return "\n".join(lines)


_BLOCKS = (
    (SECTION_COUNTERS, _counters), (SECTION_WARNINGS, _warnings), (SECTION_SANCTIONS, _sanctions),
    (SECTION_REPORTS, _reports), (SECTION_AUDIT, _audit),
)


def render(stats: GroupStats, lang: str, *, overall: bool = False, cut_at: int | None = None) -> str:
    """The `/stats` message. `overall` = the owner's all-groups view (`stats.groups` groups); `cut_at` = the number of groups
    the view was limited to when there were more."""
    period = t(f"stats_period_{StatsPeriod(stats.range.period).value}", lang)
    head = (t("stats_title_overall", lang, period=period, groups=stats.groups) if overall
            else t("stats_title_group", lang, period=period))
    parts = [head, _days(stats)]
    if cut_at is not None:
        parts.append(t("stats_cut", lang, limit=cut_at))
    for section, block in _BLOCKS:
        if section in stats.missing:
            parts.append(t("stats_section_missing", lang, section=t(f"stats_section_{section}", lang)))
        else:
            parts.append(block(stats, lang))
    parts.append(t("stats_note", lang))
    return "\n".join(parts[:2]) + "\n\n" + "\n\n".join(parts[2:])


def render_periodic(stats: GroupStats, lang: str, *, skipped: int = 0) -> str:
    """A periodic report (part 6.6b): the same sections as `/stats`, for ONE completed calendar period. `skipped` = how
    many older owed periods were dropped by the catch-up limit (named so nobody thinks nothing happened)."""
    parts = [t(f"periodic_title_{StatsPeriod(stats.range.period).value}", lang), _days(stats)]
    if skipped > 0:
        parts.append(t("periodic_skipped", lang, n=int(skipped)))
    for section, block in _BLOCKS:
        if section in stats.missing:
            parts.append(t("stats_section_missing", lang, section=t(f"stats_section_{section}", lang)))
        else:
            parts.append(block(stats, lang))
    parts.append(t("periodic_note", lang))
    return "\n".join(parts[:2]) + "\n\n" + "\n\n".join(parts[2:])
