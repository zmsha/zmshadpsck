"""PostgreSQL schedule store (NOT executed against a real PostgreSQL in the build sandbox). Every statement filters by
group_id (or inserts it as $1). Each write is ONE statement, so two ticks racing cannot both win."""
from __future__ import annotations

from .models import StatsPeriod
from .schedule_store import ScheduleEntry


class PostgresScheduleStore:
    def __init__(self, database) -> None:
        self._db = database

    async def get_all(self, group_id) -> list[ScheduleEntry]:
        async with self._db.acquire() as conn:
            rows = await conn.fetch(
                "SELECT period, enabled, enabled_from, last_period_key, changed_by, updated_at "
                "FROM report_schedule WHERE group_id = $1 ORDER BY period", group_id)
        return [ScheduleEntry(group_id, StatsPeriod(r["period"]), bool(r["enabled"]), r["enabled_from"],
                              r["last_period_key"], r["changed_by"], r["updated_at"]) for r in rows]

    async def set_enabled(self, group_id, period, enabled, actor_id, now) -> bool:
        period = StatsPeriod(period).value
        async with self._db.acquire() as conn:
            if enabled:
                # The WHERE on the DO UPDATE makes "already on" a no-op that returns no row.
                row = await conn.fetchrow(
                    "INSERT INTO report_schedule (group_id, period, enabled, enabled_from, changed_by, updated_at) "
                    "VALUES ($1, $2, TRUE, $3, $4, $3) "
                    "ON CONFLICT (group_id, period) DO UPDATE "
                    "SET enabled = TRUE, enabled_from = EXCLUDED.enabled_from, changed_by = EXCLUDED.changed_by, "
                    "updated_at = EXCLUDED.updated_at WHERE report_schedule.enabled = FALSE "
                    "RETURNING group_id", group_id, period, now, actor_id)
            else:
                row = await conn.fetchrow(
                    "UPDATE report_schedule SET enabled = FALSE, changed_by = $3, updated_at = $4 "
                    "WHERE group_id = $1 AND period = $2 AND enabled = TRUE RETURNING group_id",
                    group_id, period, actor_id, now)
        return row is not None

    async def mark_done(self, group_id, period, key, now) -> bool:
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "UPDATE report_schedule SET last_period_key = $3, updated_at = $4 "
                "WHERE group_id = $1 AND period = $2 "
                "AND (last_period_key IS NULL OR last_period_key COLLATE \"C\" < $3) RETURNING group_id",
                group_id, StatsPeriod(period).value, key, now)
        return row is not None
