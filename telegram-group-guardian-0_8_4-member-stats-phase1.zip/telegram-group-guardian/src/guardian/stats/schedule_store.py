"""Persistence contract of the periodic-report schedule (part 6.6a). EVERY method takes `group_id` and never touches
another group's rows. No method lists groups: which groups to look at is the caller's business (see HANDOFF, part 6.6b)."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol

from .models import StatsPeriod


@dataclass(frozen=True, slots=True)
class ScheduleEntry:
    """One (group, period) switch. The defaults ARE the stored meaning of 'no row': off, never handled."""
    group_id: int
    period: StatsPeriod
    enabled: bool = False
    enabled_from: datetime | None = None    # UTC instant of the latest off -> on switch
    last_period_key: str | None = None      # newest calendar period already handled (never moves backwards)
    changed_by: int | None = None
    updated_at: datetime | None = None


class ScheduleStore(Protocol):
    async def get_all(self, group_id: int) -> list[ScheduleEntry]:
        """The group's rows (at most one per period). A period with no row is simply absent."""
        ...

    async def set_enabled(self, group_id: int, period: StatsPeriod, enabled: bool, actor_id: int, now: datetime) -> bool:
        """ONE compare-and-set. Switching ON when it is not already on creates/updates the row and stamps
        `enabled_from = now`; switching OFF only touches a row that is on (no row is ever created to say 'off').
        Returns True only when something changed; repeating the same switch returns False and keeps `enabled_from`."""
        ...

    async def mark_done(self, group_id: int, period: StatsPeriod, key: str, now: datetime) -> bool:
        """Advance `last_period_key` to `key` only if the stored key is absent or OLDER (never backwards, so a stale or
        repeated call is a harmless False). A group/period with no row is also False."""
        ...
