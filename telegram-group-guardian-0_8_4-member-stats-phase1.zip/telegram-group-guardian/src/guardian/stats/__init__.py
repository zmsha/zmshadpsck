"""Statistics (Phase 6 / part 6.5a): daily counters + a read-only `StatsService` over real data.

`StatsService` makes no permission decision. Part 6.5b adds the command layer: `args.py` (period words), `render.py` (text),
`commands.py` (`/stats` in a group: MODERATE + licence applied by the executor) and `owner_command.py` (the owner's all-groups view in private).
Part 6.6a adds the periodic-report schedule (`periodic.py`: calendar periods, per-group switches, owed periods; stores in
`schedule_*store.py`, migration 0010). Nothing there sends. Part 6.6b adds `periodic_delivery.py`: it sends the owed reports from the update middleware.
"""
from .counters import CounterRecorder  # noqa: F401
from .models import (  # noqa: F401
    Counter, GroupStats, PeriodRange, StatsPeriod, combine, day_bucket, period_range,
)
from .service import StatsService  # noqa: F401
from .periodic import (  # noqa: F401
    CATCH_UP_LIMIT, CalendarPeriod, Owed, ReportScheduleService, SwitchCode, SwitchResult, claim_key, last_completed,
    owed_periods, parse_period_key, period_containing,
)
from .schedule_store import ScheduleEntry  # noqa: F401
from .periodic_delivery import PeriodicDelivery, lease_key  # noqa: F401
