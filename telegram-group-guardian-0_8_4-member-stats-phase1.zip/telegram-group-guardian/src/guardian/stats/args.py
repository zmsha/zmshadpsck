"""Strict argument parsing of `/stats` (part 6.5b). Pure text logic: no Telegram, no permissions.

    /stats [day|week|month]            الاحصائيات [اليوم|الاسبوع|الشهر]

No word = today. Exactly zero or one word; any other word is an error (`CommandError`, localized `mod_err_<code>`), never
silently ignored: a mis-read period would show the wrong numbers. English and Arabic words are interchangeable after
`fold_arabic` (so alef/ta-marbuta variants and diacritics do not matter).
"""
from __future__ import annotations

from ..moderation.arabic import fold_arabic
from ..moderation.command_error import CommandError
from .models import StatsPeriod


def _table(mapping: dict[StatsPeriod, tuple[str, ...]]) -> dict[str, StatsPeriod]:
    return {fold_arabic(word): period for period, words in mapping.items() for word in words}


PERIOD_WORDS = _table({
    StatsPeriod.DAY: ("day", "today", "daily", "اليوم", "يوم", "يومي", "يوميا"),
    StatsPeriod.WEEK: ("week", "weekly", "7d", "الاسبوع", "اسبوع", "الأسبوع", "أسبوع", "اسبوعي", "اسبوعيا"),
    StatsPeriod.MONTH: ("month", "monthly", "30d", "الشهر", "شهر", "شهري", "شهريا"),
})


def parse_period(args: tuple[str, ...] | list[str]) -> StatsPeriod:
    """`[period]` -> the period (default: today). Raises `CommandError` `stats_usage` (more than one word) or
    `stats_period` (an unknown word)."""
    words = list(args)
    if len(words) > 1:
        raise CommandError("stats_usage")
    if not words:
        return StatsPeriod.DAY
    period = PERIOD_WORDS.get(fold_arabic(words[0]))
    if period is None:
        raise CommandError("stats_period")
    return period


def alias_args_ok(args: tuple[str, ...] | list[str]) -> bool:
    """Arabic `الاحصائيات ...` is a command only when everything after it is the command's own vocabulary (so a sentence
    that merely starts with the word is ordinary chat)."""
    try:
        parse_period(args)
    except CommandError:
        return False
    return True
