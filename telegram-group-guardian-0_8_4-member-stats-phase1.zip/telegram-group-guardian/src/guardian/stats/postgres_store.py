"""PostgreSQL counter store (NOT executed against a real PostgreSQL in the build sandbox). Every statement filters by
group_id (or inserts it as $1)."""
from __future__ import annotations

from .models import Counter


class PostgresCounterStore:
    def __init__(self, database) -> None:
        self._db = database

    async def bump(self, group_id, day, counter, amount, now) -> None:
        async with self._db.acquire() as conn:
            await conn.execute(
                "INSERT INTO daily_group_counters (group_id, day, counter, value, updated_at) "
                "VALUES ($1, $2, $3, $4, $5) "
                "ON CONFLICT (group_id, day, counter) DO UPDATE "
                "SET value = daily_group_counters.value + EXCLUDED.value, updated_at = EXCLUDED.updated_at",
                group_id, day, Counter(counter).value, int(amount), now)

    async def totals(self, group_id, start_day, end_day) -> dict[str, int]:
        async with self._db.acquire() as conn:
            rows = await conn.fetch(
                "SELECT counter, sum(value) AS total FROM daily_group_counters "
                "WHERE group_id = $1 AND day BETWEEN $2 AND $3 GROUP BY counter",
                group_id, start_day, end_day)
        return {r["counter"]: int(r["total"] or 0) for r in rows}
