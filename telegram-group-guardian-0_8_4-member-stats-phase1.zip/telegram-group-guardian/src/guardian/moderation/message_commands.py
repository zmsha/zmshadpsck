"""`/pin`, `/unpin`, `/purge` (Phase 3 / closing part 2). Framework independent; reached from
`ModerationCommandService._handle` AFTER the shared first two gates (MODERATE permission, then the license gate), so
nothing here can run for a denied actor or an unlicensed group.

Path of every command, in this order (each step fails closed; covered by tests):
 1. arguments (strict parser, `commands.interpret_message_args`)       -> INVALID
 2. the message(s) to act on, taken from the REPLY / the command's own message id -> INVALID
 3. `/purge` above `PURGE_CONFIRM_ABOVE` messages needs the word `confirm`/`تأكيد` -> INVALID (nothing happened)
 4. actor's own Telegram right (only for actors authorised as plain Telegram admins): delete-messages for
    `/purge`, pin-messages for `/pin` `/unpin`                          -> DENIED
 5. group `dry_run`: audit + preview, NOTHING else                       -> DRY_RUN (no Telegram, no claim)
 6. bot's rights (`DELETE_MESSAGES` / `PIN_MESSAGES`)                    -> BOT_RIGHTS
 7. `claims.claim(operation_key("mod", cmd, chat, message_id))`          -> DUPLICATE (silent) / ERROR
 8. Telegram action -> audit (ids and counts only, never message content)

Telegram limits (documented, not worked around):
* The Bot API cannot list a chat's history, so `/purge` works on a RANGE OF MESSAGE IDS: either from the replied-to
  message through the message just before the command, or the N ids before the command. Ids that do not exist
  (deleted, service messages in another sequence, other topics) are simply skipped by Telegram.
* `deleteMessages` returns no count and silently skips what it cannot delete (older than 48 hours, already gone), so
  the reply says deletion was REQUESTED for N ids; it never claims N messages disappeared.
* A range cannot exclude authors: every message in it is deleted, including admins'. Purging "a member's messages"
  is NOT supported (the Bot API cannot search by author and the bot does not keep message ids per user).
* The command message itself is kept (the confirmation is a reply to it; also it leaves a visible trace).
* `/unpin` without a reply unpins the most recent pinned message (Telegram semantics); `/unpin all` is not offered.
"""
from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable

from ..audit import MESSAGE_PINNED, MESSAGE_UNPINNED, MESSAGES_PURGED, SecurityAudit, make_event, record_safely
from ..i18n import t
from ..idempotency import IdempotencyStore, operation_key
from ..permissions import ActorLevel
from ..protection.settings import ProtectionSettings
from ..telegram_rights import BotCapability, check_bot_capabilities
from .commands import (
    PURGE_CONFIRM_ABOVE,
    PURGE_MAX,
    Command,
    CommandError,
    ParsedCommand,
    interpret_message_args,
)
from .messages import error_message
from .targets import ReplyInfo

log = logging.getLogger(__name__)

MODERATION_DRY_RUN = "moderation_dry_run"
MODERATION_ACTION_FAILED = "moderation_action_failed"

_NEEDS = {Command.PIN: BotCapability.PIN_MESSAGES, Command.UNPIN: BotCapability.PIN_MESSAGES,
          Command.PURGE: BotCapability.DELETE_MESSAGES}


def _valid_message_id(value: object) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and 0 < value < 2**31


class MessageCommands:
    def __init__(
        self, *, permissions: Any, chat_info: Any, actions: Any, claims: IdempotencyStore, audit: SecurityAudit | None,
        load_settings: Callable[[int], Awaitable[ProtectionSettings]], make_result: Callable[..., Any], kinds: Any,
        clock: Callable[[], Any],
    ):
        self._perm, self._chat_info, self._actions, self._claims = permissions, chat_info, actions, claims
        self._audit, self._load_settings, self._result, self._kinds, self._clock = audit, load_settings, make_result, kinds, clock

    # ------------------------------------------------------------------ entry point
    async def handle(self, parsed: ParsedCommand, decision: Any, chat_id: int, actor_id: int, message_id: int,
                     reply: ReplyInfo | None, lang: str):
        R, cmd = self._kinds, parsed.command

        def invalid(text: str):
            return self._result(R.INVALID, text, cmd)

        # 1 + 2: arguments and the message(s) to act on
        try:
            args = interpret_message_args(cmd, parsed.args, has_reply=reply is not None)
        except CommandError as exc:
            return invalid(error_message(exc, lang) or t("invalid_input", lang))
        if not _valid_message_id(message_id):
            return invalid(t("invalid_input", lang))
        reply_mid = reply.message_id if reply is not None else None
        ids: list[int] = []
        if cmd is Command.PIN:
            if not _valid_message_id(reply_mid):
                return invalid(t("mod_msg_bad_reply", lang))
        elif cmd is Command.UNPIN:
            if reply is not None and not _valid_message_id(reply_mid):
                return invalid(t("mod_msg_bad_reply", lang))
        else:
            if reply is not None:
                if not _valid_message_id(reply_mid):
                    return invalid(t("mod_msg_bad_reply", lang))
                first = reply_mid
            else:
                first = max(1, message_id - 1 - (args.count or 0) + 1)
            last = message_id - 1
            if last < 1 or first > last:
                return invalid(t("mod_purge_bad_range", lang))
            if last - first + 1 > PURGE_MAX:
                return invalid(t("mod_err_purge_range", lang))
            ids = list(range(first, last + 1))
            # 3: a big purge needs the explicit word (stateless confirmation; a new command message = a new claim)
            if len(ids) > PURGE_CONFIRM_ABOVE and not args.confirm:
                return invalid(t("mod_purge_need_confirm", lang, count=len(ids)))

        # 4: the actor's own Telegram right (project permission alone is not enough for a plain Telegram admin)
        denied = await self._actor_right(decision, chat_id, actor_id, cmd, lang)
        if denied is not None:
            return denied

        settings = await self._load_settings(chat_id)
        now = self._clock()
        # 5: dry-run
        if settings.dry_run:
            await record_safely(self._audit, make_event(
                MODERATION_DRY_RUN, actor=actor_id, group_id=chat_id, now=now, detail=cmd.value))
            text = t("mod_dry_run_msg", lang, action=t(f"mod_action_{cmd.value}", lang))
            return self._result(R.DRY_RUN, text, cmd)
        # 6: the bot's own rights
        cap = await check_bot_capabilities(self._chat_info, chat_id, _NEEDS[cmd])
        if not cap.ok:
            await record_safely(self._audit, make_event(
                MODERATION_ACTION_FAILED, actor=actor_id, group_id=chat_id, now=now, detail=f"{cmd.value} bot_rights_missing"))
            return self._result(R.BOT_RIGHTS, t(cap.user_message_key() or "bot_check_failed", lang), cmd)
        # 7: idempotency (a redelivered update never pins/deletes twice)
        try:
            claimed = await self._claims.claim(operation_key("mod", cmd.value, chat_id, message_id))
        except Exception:
            log.error("message command claim failed; no action", extra={"group_id": chat_id}, exc_info=True)
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        if not claimed:
            return self._result(R.DUPLICATE, "", cmd)
        # 8: Telegram + audit
        if cmd is Command.PIN:
            return await self._pin(chat_id, actor_id, reply_mid, args.silent, now, lang)
        if cmd is Command.UNPIN:
            return await self._unpin(chat_id, actor_id, reply_mid, now, lang)
        return await self._purge(chat_id, actor_id, ids, now, lang)

    # ------------------------------------------------------------------ actor right
    async def _actor_right(self, decision: Any, chat_id: int, actor_id: int, cmd: Command, lang: str):
        """Owner / backup owner / delegates are trusted by the project's own permission model. An actor who got
        MODERATE only because they are a Telegram admin must also hold the SPECIFIC Telegram right (an admin who may
        restrict members but not delete or pin must not use the bot to do it). Lookup failure => deny."""
        if getattr(decision, "level", None) is not ActorLevel.TELEGRAM_ADMIN:
            return None
        R = self._kinds
        try:
            info = await self._chat_info.get_member(chat_id, actor_id, fresh=True)
        except Exception:
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        ok = info.is_creator or (info.status == "administrator" and (
            info.can_delete_messages if cmd is Command.PURGE else info.can_pin_messages))
        if ok:
            return None
        key = "mod_actor_missing_delete" if cmd is Command.PURGE else "mod_actor_missing_pin"
        return self._result(R.DENIED, t(key, lang), cmd)

    # ------------------------------------------------------------------ actions
    def _failure(self, cmd: Command, error: str | None, lang: str):
        key = {"rate_limited": "mod_tg_rate_limited", "forbidden": "mod_msg_tg_forbidden",
               "not_found": "mod_msg_tg_not_found"}.get(error or "", "action_failed_safe")
        return self._result(self._kinds.TELEGRAM_FAILED, t(key, lang), cmd)

    async def _audit_failure(self, cmd: Command, actor_id: int, chat_id: int, now, error: str | None) -> None:
        await record_safely(self._audit, make_event(
            MODERATION_ACTION_FAILED, actor=actor_id, group_id=chat_id, now=now, detail=f"{cmd.value} error={error or 'other'}"))

    async def _pin(self, chat_id, actor_id, mid, silent, now, lang):
        res = await self._actions.pin_message(chat_id, mid, silent)
        if not getattr(res, "ok", False):
            err = getattr(res, "error", None)
            await self._audit_failure(Command.PIN, actor_id, chat_id, now, err)
            return self._failure(Command.PIN, err, lang)
        await record_safely(self._audit, make_event(
            MESSAGE_PINNED, actor=actor_id, group_id=chat_id, now=now, detail=f"msg={mid} silent={int(silent)}"))
        return self._result(self._kinds.DONE, t("mod_ok_pin_silent" if silent else "mod_ok_pin", lang), Command.PIN)

    async def _unpin(self, chat_id, actor_id, mid, now, lang):
        res = await self._actions.unpin_message(chat_id, mid)
        if not getattr(res, "ok", False):
            err = getattr(res, "error", None)
            if err == "not_found":  # nothing (or not this message) is pinned: harmless
                return self._result(self._kinds.NOOP, t("mod_unpin_nothing", lang), Command.UNPIN)
            await self._audit_failure(Command.UNPIN, actor_id, chat_id, now, err)
            return self._failure(Command.UNPIN, err, lang)
        await record_safely(self._audit, make_event(
            MESSAGE_UNPINNED, actor=actor_id, group_id=chat_id, now=now, detail=f"msg={mid if mid else 'latest'}"))
        return self._result(self._kinds.DONE, t("mod_ok_unpin" if mid else "mod_ok_unpin_latest", lang), Command.UNPIN)

    async def _purge(self, chat_id, actor_id, ids, now, lang):
        res = await self._actions.delete_messages(chat_id, ids)
        if not getattr(res, "ok", False):
            err = getattr(res, "error", None)
            await self._audit_failure(Command.PURGE, actor_id, chat_id, now, err)
            return self._failure(Command.PURGE, err, lang)
        await record_safely(self._audit, make_event(
            MESSAGES_PURGED, actor=actor_id, group_id=chat_id, now=now, detail=f"from={ids[0]} to={ids[-1]} count={len(ids)}"))
        return self._result(self._kinds.DONE, t("mod_ok_purge", lang, count=len(ids)), Command.PURGE)
