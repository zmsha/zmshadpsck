"""Executes the moderation commands (Phase 3 / part 5; `/id /info /admins /report` are delegated to `info_commands.py`). Framework independent: no aiogram,
Telegram is reached only through the injected `MemberActions` (the aiogram adapter is `bot/actions.py`, part 6).

Path of EVERY command, in this order (each step fails closed; covered by tests):
 1. `permissions.require(MODERATE, context_chat_id=chat)`   -> DENIED (no detail leaked)
 2. license/protection gate `protection.allowed`           -> LICENSE_OFF (owner license paths are elsewhere)
 3. parse args + resolve target (protected/self/bot checks) -> INVALID
 4. command preconditions from the live member status      -> NOOP / INVALID
 5. dry_run (group setting): audit + preview, NOTHING else  -> DRY_RUN (no Telegram, no claim, no records)
 6. `check_bot_capabilities(RESTRICT_MEMBERS)` (writes that call Telegram) -> BOT_RIGHTS
 7. `claims.claim(operation_key("mod", cmd, group, message_id))` -> DUPLICATE (silent) / ERROR
 8. Telegram action -> ledger/warning write (services audit it). Telegram failure => nothing recorded.
 A ledger failure AFTER a successful Telegram action keeps the action and is audited.

`/trust /untrust /trusted` (part 4.2) share steps 1-2 and continue in `trust_commands.py` (listing needs only MODERATE; changes
also need MANAGE_TRUST; domains go through `SettingsCommands.change_allow`).
`/pin /unpin /purge` (part 3.5-2) share steps 1-2 and then continue in `message_commands.py` (no member target).
`/lock /unlock` (part 3.5-3) share steps 1-2 and continue in `lock_commands.py`; `/slowmode /antiflood /protect` share steps
1-2 and continue in `settings_commands.py` (reads need only MODERATE; writes also need MANAGE_SETTINGS; `/protect dryrun`
is primary-owner only).

Decisions: no duration on ban/mute = permanent; at `warn_limit` active warnings the configured
`warn_action` is applied and the user's warnings are then cleared (a new cycle starts); if that action
fails the warnings stay (the next warning retries it). Anonymous admins (service account id) cannot run
commands because their identity is unknown. Read-only `/warnings` skips bot-rights/claim.
"""
from __future__ import annotations

import enum
import logging
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Callable, Protocol

from ..audit import (COMMAND_REJECTED, RESULT_APPLIED, RESULT_DENIED, SANCTION_LIFTED, SecurityAudit, make_event,
                     record_safely)
from ..errors import InvalidInput, PermissionDenied
from ..i18n import t
from ..idempotency import IdempotencyStore, operation_key
from ..permissions import Permission
from ..protection.settings import ProtectionSettings
from ..protection_gate import ProtectionContext
from ..reports import args as report_args
from ..reports.commands import ReportCommands
from ..export.command import ExportCommands
from ..stats.commands import StatsCommands
from ..telegram_rights import BotCapability, check_bot_capabilities
from ..time_utils import utcnow
from .commands import (
    LOCK_COMMANDS,
    MESSAGE_COMMANDS,
    MEMBER_SETTINGS_COMMANDS,
    OVERVIEW_COMMANDS,
    PANEL_COMMANDS,
    REPORT_COMMANDS,
    SETTINGS_COMMANDS,
    STATS_COMMANDS,
    EXPORT_COMMANDS,
    TRUST_COMMANDS,
    Command,
    CommandError,
    ParsedCommand,
    interpret_args,
)
from .duration import format_duration
from .info_commands import InfoCommands
from .lock_commands import LockCommands
from .message_commands import MessageCommands
from .member_commands import MemberSettingsCommands
from .settings_commands import SettingsCommands
from .trust_commands import TrustCommands
from .messages import error_message
from .models import SanctionKind
from .targets import ReplyInfo, Target, TargetError, TargetInput, UsernameResolver, resolve_target, split_target_args

log = logging.getLogger(__name__)

MODERATION_DRY_RUN = "moderation_dry_run"
MODERATION_ACTION_FAILED = "moderation_action_failed"
MODERATION_RECORD_ERROR = "moderation_record_error"
REJECTED_AUDIT_INTERVAL = 60  # seconds between audit rows for the same (actor, group, command, reason)

PUNITIVE = frozenset({Command.BAN, Command.MUTE, Command.KICK, Command.WARN})
INFO_COMMANDS = frozenset({Command.ID, Command.INFO, Command.ADMINS, Command.REPORT})  # part 3.5-1: info_commands.py
_PRESENT = frozenset({"member", "restricted", "administrator", "creator"})  # currently in the chat
_KIND = {Command.BAN: SanctionKind.BAN, Command.MUTE: SanctionKind.MUTE, Command.KICK: SanctionKind.KICK}
_MAX_LISTED_WARNINGS = 5


class ResultKind(str, enum.Enum):
    DONE = "done"
    DRY_RUN = "dry_run"
    NOOP = "noop"                      # nothing to do (already banned, not muted...)
    INFO = "info"                      # read-only answer
    DENIED = "denied"
    LICENSE_OFF = "license_off"
    INVALID = "invalid"
    BOT_RIGHTS = "bot_rights"
    DUPLICATE = "duplicate"            # redelivered update: reply nothing
    THROTTLED = "throttled"            # cooldown of a public command (/id /admins /report): reply nothing
    TELEGRAM_FAILED = "telegram_failed"
    ERROR = "error"


@dataclass(frozen=True, slots=True)
class CommandResult:
    kind: ResultKind
    text: str  # ready to send (Telegram HTML, values escaped); "" => send nothing
    command: Command | None = None
    target_id: int | None = None
    panel: bool = False  # `/panel`: the caller attaches the panel's inline keyboard (bound to the sender) to `text`
    redirect_chat_id: int | None = None  # part 6.4a: send `text` to this (owner-approved) chat instead; the group gets a notice

    @property
    def ok(self) -> bool:
        return self.kind in (ResultKind.DONE, ResultKind.DRY_RUN, ResultKind.NOOP, ResultKind.INFO)


class MemberActions(Protocol):
    """Telegram operations the commands need. Must NOT raise: failures come back as ActionResult.
    `until=None` means permanent. `kick_member` = ban then unban (the user may rejoin)."""

    async def ban_member(self, chat_id: int, user_id: int, until: datetime | None) -> Any: ...

    async def unban_member(self, chat_id: int, user_id: int) -> Any: ...

    async def mute_member(self, chat_id: int, user_id: int, until: datetime | None) -> Any: ...

    async def unmute_member(self, chat_id: int, user_id: int) -> Any: ...

    async def kick_member(self, chat_id: int, user_id: int) -> Any: ...


class ModerationCommandService:
    def __init__(
        self, *, permissions: Any, warnings: Any, sanctions: Any, settings_store: Any, actions: MemberActions,
        chat_info: Any, claims: IdempotencyStore, audit: SecurityAudit | None, bot_id: int,
        usernames: UsernameResolver | None = None, language: str = "ar", clock: Callable[[], datetime] = utcnow,
        group_settings: Any = None, trust: Any = None, bot_trust: Any = None, trust_store: Any = None,
        bot_trust_store: Any = None, reports: Any = None, display_timezone: str = "Asia/Riyadh",
        counters: Any = None, stats: Any = None, report_schedule: Any = None, export_delivery: Any = None, licenses: Any = None, audit_query: Any = None,
    ):
        self._perm, self._warnings, self._sanctions = permissions, warnings, sanctions
        self._settings_store, self._actions, self._chat_info = settings_store, actions, chat_info
        self._claims, self._audit, self._bot_id = claims, audit, bot_id
        self._usernames, self._language, self._clock = usernames, language, clock
        self._counters = counters  # CounterRecorder (optional, part 6.5a): commands handled / rejected, per group and day
        self._rejected_seen: dict[tuple, datetime] = {}  # throttle of COMMAND_REJECTED audit rows (part 6.2)
        self._info = InfoCommands(
            permissions=permissions, warnings=warnings, sanctions=sanctions, chat_info=chat_info, claims=claims,
            audit=audit, bot_id=bot_id, load_settings=self._load_settings, make_result=CommandResult, kinds=ResultKind,
            usernames=usernames, clock=clock, reports=reports)
        # Report management (part 6.4a): `/reports`, `/report show|take|...`, the approved destination.
        self._report_cmds = ReportCommands(
            permissions=permissions, reports=reports, claims=claims, group_settings=group_settings,
            load_raw=self._load_raw, chat_info=chat_info, audit=audit, make_result=CommandResult, kinds=ResultKind,
            display_timezone=display_timezone, clock=clock, schedule=report_schedule)
        # `/stats` (part 6.5b): reached only AFTER the MODERATE and licence gates of `_handle`.
        self._stats_cmds = StatsCommands(stats=stats, make_result=CommandResult, kinds=ResultKind)
        # `/export settings|license|reports|audit` (parts 6.7b/6.7c): reached only AFTER the MODERATE and licence gates of `_handle`.
        self._export_cmds = ExportCommands(
            permissions=permissions, delivery=export_delivery, claims=claims, load_raw=self._load_raw, licenses=licenses,
            audit_query=audit_query, audit=audit, display_timezone=display_timezone, make_result=CommandResult,
            kinds=ResultKind, reports=reports, clock=clock)
        self._messages = MessageCommands(
            permissions=permissions, chat_info=chat_info, actions=actions, claims=claims, audit=audit,
            load_settings=self._load_settings, make_result=CommandResult, kinds=ResultKind, clock=clock)
        self._locks = LockCommands(
            actions=actions, chat_info=chat_info, claims=claims, audit=audit, load_settings=self._load_settings,
            make_result=CommandResult, kinds=ResultKind, clock=clock)
        # `group_settings` (GroupSettingsService): without it the settings commands can read but never write.
        self._config = SettingsCommands(
            permissions=permissions, group_settings=group_settings, claims=claims, load_settings=self._load_settings,
            make_result=CommandResult, kinds=ResultKind, load_raw=self._load_raw)
        # Welcome / verification / new-member settings and the `/settings` overview (part 4.6).
        self._member_cfg = MemberSettingsCommands(
            permissions=permissions, group_settings=group_settings, claims=claims, load_raw=self._load_raw,
            load_settings=self._load_settings, chat_info=chat_info, trust_store=trust_store,
            bot_trust_store=bot_trust_store, make_result=CommandResult, kinds=ResultKind)
        # Trust lists (part 4.2). `trust`/`bot_trust` are the write services, `*_store` the read side (listing needs only
        # MODERATE); without them the trust commands answer a safe error instead of guessing.
        self._trust = TrustCommands(
            permissions=permissions, trust=trust, bot_trust=bot_trust, trust_store=trust_store,
            bot_trust_store=bot_trust_store, settings_commands=self._config, chat_info=chat_info, claims=claims,
            bot_id=bot_id, usernames=usernames, load_settings=self._load_settings, make_result=CommandResult,
            kinds=ResultKind, load_raw=self._load_raw)

    # ------------------------------------------------------------------ entry point
    async def handle(
        self, parsed: ParsedCommand, *, chat_id: int, actor_id: int, message_id: int,
        protection: ProtectionContext | None, reply: ReplyInfo | None = None, mention_user_id: int | None = None,
        language: str | None = None,
    ) -> CommandResult:
        lang = language or self._language
        cmd = parsed.command
        try:
            result = await self._handle(parsed, chat_id, actor_id, message_id, protection, reply, mention_user_id, lang)
            if result.kind is ResultKind.LICENSE_OFF:
                await self._audit_rejected(cmd, chat_id, actor_id, "license_off")
            await self._count_command(chat_id, result.kind)
            return result
        except PermissionDenied:
            await self._audit_rejected(cmd, chat_id, actor_id, "permission_denied")
            await self._count_command(chat_id, ResultKind.DENIED)
            return CommandResult(ResultKind.DENIED, t("permission_denied", lang), cmd)
        except Exception:
            log.error("moderation command failed", extra={"group_id": chat_id}, exc_info=True)
            return CommandResult(ResultKind.ERROR, t("action_failed_safe", lang), cmd)

    async def _count_command(self, chat_id: int, kind: ResultKind) -> None:
        """Statistics only (part 6.5a). Rejected = permission/licence refusals (unthrottled, unlike the audit row);
        handled = the actor was allowed and the licence was on. Redeliveries, cooldown hits and crashes count as neither.
        A failure here never changes the command's result."""
        if self._counters is None:
            return
        if kind in (ResultKind.DENIED, ResultKind.LICENSE_OFF):
            counter = "command_rejected"
        elif kind in (ResultKind.DUPLICATE, ResultKind.THROTTLED, ResultKind.ERROR):
            return
        else:
            counter = "command"
        try:
            await self._counters.bump(chat_id, counter, self._clock())
        except Exception:  # pragma: no cover - CounterRecorder already swallows its own errors
            log.warning("command counter failed", extra={"group_id": chat_id}, exc_info=True)

    async def _handle(self, parsed, chat_id, actor_id, message_id, protection, reply, mention_user_id, lang):
        cmd = parsed.command
        if cmd in REPORT_COMMANDS or (cmd is Command.REPORT and reply is None and report_args.is_admin_word(parsed.args)):
            # /reports and /report show|take|resolve|dismiss|type|priority (not a reply): MODERATE -> license -> strict parse
            return await self._report_cmds.handle(parsed, chat_id, actor_id, message_id, protection, lang)
        if cmd in INFO_COMMANDS:  # /id /info /admins /report: own policy (public vs moderator), same fail-closed rules
            return await self._info.handle(parsed, chat_id, actor_id, message_id, protection, reply, mention_user_id, lang)
        decision = await self._perm.require(actor_id, chat_id, Permission.MODERATE, context_chat_id=chat_id)
        if protection is None or not protection.allowed or protection.chat_id != chat_id:
            return CommandResult(ResultKind.LICENSE_OFF, t("mod_license_off", lang), cmd)
        if cmd in STATS_COMMANDS:  # /stats: counts of THIS group only (gates above already passed)
            return await self._stats_cmds.handle(parsed, chat_id, lang)
        if cmd in EXPORT_COMMANDS:  # /export settings|license|reports|audit: private delivery only (gates above already passed)
            return await self._export_cmds.handle(parsed, chat_id, actor_id, message_id, lang)
        if cmd in MESSAGE_COMMANDS:  # /pin /unpin /purge: act on messages, not on a member
            return await self._messages.handle(parsed, decision, chat_id, actor_id, message_id, reply, lang)
        if cmd in LOCK_COMMANDS:  # /lock /unlock: group default permissions
            return await self._locks.handle(parsed, chat_id, actor_id, message_id, lang)
        if cmd in SETTINGS_COMMANDS:  # /slowmode /antiflood /protect: protection settings
            return await self._config.handle(parsed, decision, chat_id, actor_id, message_id, lang)
        if cmd in MEMBER_SETTINGS_COMMANDS:  # /welcome /verify /newbie: welcome, verification, new-member policy
            return await self._member_cfg.handle(parsed, chat_id, actor_id, message_id, lang)
        if cmd in OVERVIEW_COMMANDS:  # /settings: read-only overview of everything
            return await self._member_cfg.overview(chat_id, lang)
        if cmd in PANEL_COMMANDS:  # /panel: same read-only overview + a keyboard bound to the sender (4.7a)
            shown = await self._member_cfg.overview(chat_id, lang)
            return CommandResult(shown.kind, shown.text, cmd, panel=shown.kind is ResultKind.INFO)
        if cmd in TRUST_COMMANDS:  # /trust /untrust /trusted: trust lists (members, domains, bots)
            return await self._trust.handle(parsed, decision, chat_id, actor_id, message_id, reply, mention_user_id, lang)
        try:
            token, rest = split_target_args(list(parsed.args), reply)
            args = interpret_args(cmd, rest)
            target = await resolve_target(
                TargetInput(reply, token, mention_user_id if token else None), group_id=chat_id, actor_id=actor_id,
                bot_id=self._bot_id, permissions=self._perm, chat_info=self._chat_info, usernames=self._usernames,
                require_unprotected=cmd in PUNITIVE)
        except (TargetError, CommandError) as exc:
            text = error_message(exc, lang) or t("invalid_input", lang)
            return CommandResult(ResultKind.INVALID, text, cmd)
        except InvalidInput:
            return CommandResult(ResultKind.INVALID, t("invalid_input", lang), cmd)

        settings = await self._load_settings(chat_id)
        now = self._clock()
        ctx = _Ctx(cmd, chat_id, actor_id, message_id, target, args.duration_seconds, args.reason, settings, now, lang)

        if cmd is Command.WARNINGS:
            return await self._list_warnings(ctx)
        early = self._precondition(ctx)
        if early is not None:
            if cmd is Command.UNBAN and early.kind is ResultKind.NOOP and not settings.dry_run:
                await self._lift_quietly(ctx, SanctionKind.BAN)  # stale ledger row: Telegram already says unbanned
            return early
        if settings.dry_run:
            return await self._dry_run(ctx)
        if cmd is not Command.CLEARWARNS:
            needs_rights = cmd is not Command.WARN or await self._warn_will_hit_limit(ctx)
            if needs_rights:
                cap = await check_bot_capabilities(self._chat_info, chat_id, BotCapability.RESTRICT_MEMBERS)
                if not cap.ok:
                    await record_safely(self._audit, make_event(
                        MODERATION_ACTION_FAILED, actor=actor_id, group_id=chat_id, now=now,
                        detail=f"{cmd.value} user={target.user_id} bot_rights_missing"))
                    return CommandResult(ResultKind.BOT_RIGHTS, t(cap.user_message_key() or "bot_check_failed", lang),
                                         cmd, target.user_id)
        key = operation_key("mod", cmd.value, chat_id, message_id)
        try:
            claimed = await self._claims.claim(key)
        except Exception:
            log.error("moderation claim failed; no action", extra={"group_id": chat_id}, exc_info=True)
            return CommandResult(ResultKind.ERROR, t("action_failed_safe", lang), cmd, target.user_id)
        if not claimed:
            return CommandResult(ResultKind.DUPLICATE, "", cmd, target.user_id)
        return await self._execute(ctx, key)

    async def overview(self, chat_id: int, lang: str) -> CommandResult:
        """The read-only `/settings` overview WITHOUT any gate. Only for callers that already applied the MODERATE and
        license gates for this very request (the panel's press handler); commands go through `handle`."""
        return await self._member_cfg.overview(chat_id, lang)

    async def panel_topic(self, topic: str, chat_id: int, lang: str):
        """(text, typed settings) of one welcome/verify/newbie/protect topic for a panel screen, or (text, None) for the
        read-only trust screen. No gate: the panel applied them."""
        if topic == "protect":
            return await self._config.panel_view(chat_id, lang)
        if topic == "trust":
            return await self._trust.panel_view(chat_id, lang), None
        return await self._member_cfg.panel_view(topic, chat_id, lang)

    async def panel_write(self, topic: str, patch: Any, chat_id: int, actor_id: int, claim_key: str, lang: str):
        """A panel button's settings write: the SAME path as `/welcome /verify /newbie` (MANAGE_SETTINGS -> claim ->
        compare -> `GroupSettingsService.update`); `protect` goes through `SettingsCommands` (the `/protect` path). The
        trust screen is read-only: any other topic is refused with ValueError. The caller must already have applied
        MODERATE + the live license."""
        if topic == "protect":
            return await self._config.panel_write(patch, chat_id, actor_id, claim_key, lang)
        return await self._member_cfg.panel_write(topic, patch, chat_id, actor_id, claim_key, lang)

    # ------------------------------------------------------------------ pre-checks
    def _precondition(self, ctx: "_Ctx") -> CommandResult | None:
        c, st, lang = ctx.cmd, ctx.target.status, ctx.lang
        present = st in _PRESENT

        def stop(kind: ResultKind, key: str) -> CommandResult:
            return CommandResult(kind, t(key, lang), c, ctx.target.user_id)

        if c is Command.BAN and st == "kicked":
            return stop(ResultKind.NOOP, "mod_already_banned")
        if c is Command.UNBAN and st != "kicked":
            return stop(ResultKind.NOOP, "mod_not_banned")
        if c in (Command.MUTE, Command.KICK, Command.WARN) and not present:
            return stop(ResultKind.INVALID, "mod_not_member")
        if c is Command.UNMUTE:
            if not present:
                return stop(ResultKind.INVALID, "mod_not_member")
            if st != "restricted":
                return stop(ResultKind.NOOP, "mod_not_muted")
        return None

    async def _load_raw(self, chat_id: int) -> dict:
        """The group's raw settings JSON ({} when none). Unlike `_load_settings` a read failure RAISES: a command that
        compares or renders must not pretend the defaults are the stored values."""
        row = await self._settings_store.get(chat_id)
        return dict(row.settings) if row is not None and isinstance(row.settings, dict) else {}

    async def _load_settings(self, chat_id: int) -> ProtectionSettings:
        try:
            row = await self._settings_store.get(chat_id)
        except Exception:
            log.warning("could not load group settings; using safe defaults", extra={"group_id": chat_id})
            return ProtectionSettings()
        return ProtectionSettings.from_raw(row.settings if row is not None else None)

    async def _warn_will_hit_limit(self, ctx: "_Ctx") -> bool:
        try:
            active = await self._warnings.count_active(ctx.actor, ctx.chat, ctx.target.user_id, context_chat_id=ctx.chat)
        except Exception:
            return True  # unknown => check rights (the stricter path)
        return active + 1 >= ctx.settings.warn_limit

    async def _dry_run(self, ctx: "_Ctx") -> CommandResult:
        await record_safely(self._audit, make_event(
            MODERATION_DRY_RUN, actor=ctx.actor, group_id=ctx.chat, now=ctx.now,
            detail=f"{ctx.cmd.value} user={ctx.target.user_id}"))
        text = t("mod_dry_run", ctx.lang, action=t(f"mod_action_{ctx.cmd.value}", ctx.lang), user=str(ctx.target.user_id))
        return CommandResult(ResultKind.DRY_RUN, text, ctx.cmd, ctx.target.user_id)

    # ------------------------------------------------------------------ execution
    async def _execute(self, ctx: "_Ctx", key: str) -> CommandResult:
        c = ctx.cmd
        if c in _KIND:
            seconds = None if c is Command.KICK else ctx.seconds
            return await self._restrict(ctx, _KIND[c], seconds, ctx.reason, key)
        if c is Command.UNBAN:
            return await self._lift(ctx, SanctionKind.BAN, self._actions.unban_member, "mod_ok_unban")
        if c is Command.UNMUTE:
            return await self._lift(ctx, SanctionKind.MUTE, self._actions.unmute_member, "mod_ok_unmute")
        if c is Command.WARN:
            return await self._warn(ctx, key)
        return await self._clear_warnings(ctx)

    def _span(self, seconds: int | None, lang: str) -> str:
        if not seconds:
            return t("mod_span_forever", lang)
        return t("mod_span_for", lang, duration=format_duration(seconds, lang))

    def _telegram_failure(self, ctx: "_Ctx", error: str | None, what: str) -> CommandResult:
        key = {"rate_limited": "mod_tg_rate_limited", "forbidden": "mod_tg_forbidden",
               "not_found": "mod_tg_not_found", "kick_incomplete": "mod_tg_kick_incomplete"}.get(error or "", "action_failed_safe")
        return CommandResult(ResultKind.TELEGRAM_FAILED, t(key, ctx.lang), ctx.cmd, ctx.target.user_id)

    async def _audit_rejected(self, cmd: Command, chat_id: int, actor_id: int, reason: str) -> None:
        """Part 6.2: a refused command leaves a trace (command name + reason only, never arguments or text).
        Throttled per (actor, group, command, reason) so a spammer cannot flood the log."""
        now = self._clock()
        key = (actor_id, chat_id, cmd.value, reason)
        last = self._rejected_seen.get(key)
        if last is not None and (now - last).total_seconds() < REJECTED_AUDIT_INTERVAL:
            return
        if len(self._rejected_seen) > 5_000:
            self._rejected_seen.clear()
        self._rejected_seen[key] = now
        await record_safely(self._audit, make_event(
            COMMAND_REJECTED, actor=actor_id, group_id=chat_id, now=now, target=cmd.value, result=RESULT_DENIED,
            detail=reason))

    async def _audit_failure(self, ctx: "_Ctx", what: str, error: str | None) -> None:
        await record_safely(self._audit, make_event(
            MODERATION_ACTION_FAILED, actor=ctx.actor, group_id=ctx.chat, now=ctx.now,
            detail=f"{what} user={ctx.target.user_id} error={error or 'other'}"))

    async def _restrict(self, ctx: "_Ctx", kind: SanctionKind, seconds: int | None, reason: str | None,
                        key: str) -> CommandResult:
        uid, gid = ctx.target.user_id, ctx.chat
        until = ctx.now + timedelta(seconds=seconds) if seconds else None
        if kind is SanctionKind.BAN:
            res = await self._actions.ban_member(gid, uid, until)
        elif kind is SanctionKind.MUTE:
            res = await self._actions.mute_member(gid, uid, until)
        else:
            res = await self._actions.kick_member(gid, uid)
        if not getattr(res, "ok", False):
            err = getattr(res, "error", None)
            await self._audit_failure(ctx, kind.value, err)
            return self._telegram_failure(ctx, err, kind.value)
        try:
            await self._sanctions.record(ctx.actor, gid, uid, kind, reason=reason, expires_at=until,
                                         idempotency_key=key, context_chat_id=gid)
        except Exception:
            log.error("sanction applied but not recorded", extra={"group_id": gid}, exc_info=True)
            await record_safely(self._audit, make_event(
                MODERATION_RECORD_ERROR, actor=ctx.actor, group_id=gid, now=ctx.now,
                detail=f"{kind.value} user={uid} applied_not_recorded"))
        text_key = {SanctionKind.BAN: "mod_ok_ban", SanctionKind.MUTE: "mod_ok_mute", SanctionKind.KICK: "mod_ok_kick"}[kind]
        text = t(text_key, ctx.lang, user=str(uid), span=self._span(seconds, ctx.lang))
        return CommandResult(ResultKind.DONE, text, ctx.cmd, uid)

    async def _lift(self, ctx: "_Ctx", kind: SanctionKind, action, ok_key: str) -> CommandResult:
        uid, gid = ctx.target.user_id, ctx.chat
        res = await action(gid, uid)
        if not getattr(res, "ok", False):
            err = getattr(res, "error", None)
            await self._audit_failure(ctx, f"un{kind.value}", err)
            return self._telegram_failure(ctx, err, kind.value)
        lifted = await self._lift_quietly(ctx, kind)
        if lifted == 0:  # Telegram lifted it but the ledger had no live row: SanctionService wrote no audit, so do it here
            await record_safely(self._audit, make_event(
                SANCTION_LIFTED, actor=ctx.actor, group_id=gid, now=ctx.now, target=uid, result=RESULT_APPLIED,
                detail=f"user={uid} kind={kind.value} count=0 telegram_only"))
        return CommandResult(ResultKind.DONE, t(ok_key, ctx.lang, user=str(uid)), ctx.cmd, uid)

    async def _lift_quietly(self, ctx: "_Ctx", kind: SanctionKind) -> int | None:
        """Returns how many ledger rows were lifted (None when the ledger update failed)."""
        try:
            return await self._sanctions.lift(ctx.actor, ctx.chat, ctx.target.user_id, kind, context_chat_id=ctx.chat)
        except Exception:
            log.error("sanction lifted in Telegram but ledger not updated", extra={"group_id": ctx.chat}, exc_info=True)
            await record_safely(self._audit, make_event(
                MODERATION_RECORD_ERROR, actor=ctx.actor, group_id=ctx.chat, now=ctx.now,
                detail=f"lift {kind.value} user={ctx.target.user_id} not_recorded"))

    # ------------------------------------------------------------------ warnings
    async def _warn(self, ctx: "_Ctx", key: str) -> CommandResult:
        uid, gid, s = ctx.target.user_id, ctx.chat, ctx.settings
        _, count, _ = await self._warnings.warn(ctx.actor, gid, uid, ctx.reason, idempotency_key=key, context_chat_id=gid)
        text = t("mod_ok_warn", ctx.lang, user=str(uid), count=count, limit=s.warn_limit)
        if count < s.warn_limit:
            return CommandResult(ResultKind.DONE, text, ctx.cmd, uid)
        kind = {"mute": SanctionKind.MUTE, "kick": SanctionKind.KICK, "ban": SanctionKind.BAN}[s.warn_action]
        seconds = None if kind is SanctionKind.KICK else (s.warn_action_seconds or None)
        outcome = await self._restrict(ctx, kind, seconds, ctx.reason or "warn limit", f"{key}:limit")
        if outcome.kind is ResultKind.DONE:
            try:
                await self._warnings.clear(ctx.actor, gid, uid, context_chat_id=gid)  # new cycle
            except Exception:
                log.error("warnings not cleared after limit action", extra={"group_id": gid}, exc_info=True)
        return CommandResult(ResultKind.DONE, f"{text}\n{outcome.text}", ctx.cmd, uid)

    async def _list_warnings(self, ctx: "_Ctx") -> CommandResult:
        uid = ctx.target.user_id
        rows = await self._warnings.list_active(ctx.actor, ctx.chat, uid, context_chat_id=ctx.chat)
        if not rows:
            return CommandResult(ResultKind.INFO, t("mod_warnings_none", ctx.lang, user=str(uid)), ctx.cmd, uid)
        recent = sorted(rows, key=lambda w: w.created_at, reverse=True)[:_MAX_LISTED_WARNINGS]
        items = "".join(f"\n• {w.created_at:%Y-%m-%d}" + (f" — {w.reason}" if w.reason else "") for w in recent)
        text = t("mod_ok_warnings", ctx.lang, user=str(uid), count=len(rows), limit=ctx.settings.warn_limit, items=items)
        return CommandResult(ResultKind.INFO, text, ctx.cmd, uid)

    async def _clear_warnings(self, ctx: "_Ctx") -> CommandResult:
        uid = ctx.target.user_id
        cleared = await self._warnings.clear(ctx.actor, ctx.chat, uid, context_chat_id=ctx.chat)
        if not cleared:
            return CommandResult(ResultKind.NOOP, t("mod_warnings_none", ctx.lang, user=str(uid)), ctx.cmd, uid)
        return CommandResult(ResultKind.DONE, t("mod_ok_clearwarns", ctx.lang, user=str(uid), count=cleared), ctx.cmd, uid)


@dataclass(frozen=True, slots=True)
class _Ctx:
    cmd: Command
    chat: int
    actor: int
    message_id: int
    target: Target
    seconds: int | None
    reason: str | None
    settings: ProtectionSettings
    now: datetime
    lang: str
