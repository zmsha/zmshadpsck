"""`/welcome`, `/verify`, `/newbie` and the read-only `/settings` overview (Phase 4 / part 4.6): show and change the
group's WELCOME, NEW-MEMBER VERIFICATION and NEW-MEMBER RESTRICTION settings from chat. Framework independent; reached
from `ModerationCommandService._handle` AFTER the shared first two gates (MODERATE permission, then the license gate),
so nothing here works for a group that is not licensed, and no setting made here can make a feature run in such a group
(the features themselves re-check the license on every event).

Reading (`/welcome`, `/verify`, `/newbie`, `/welcome vars`, `/settings`) needs only those two gates. Every WRITE then:
 1. parses strictly (`member_args`; an unknown word is INVALID, nothing is guessed)
 2. requires `MANAGE_SETTINGS` for THIS chat (Telegram admins of the group, GROUP_MANAGER delegates, the owner; a
    MODERATOR delegate may read but not change) -> DENIED
 3. claims `operation_key("mod", cmd, chat, message_id)` (a redelivered update never writes/audits twice) -> DUPLICATE
 4. compares with the EFFECTIVE current values: nothing to change => NOOP (no write, no audit)
 5. writes through `GroupSettingsService.update` (permission re-check, validation, `settings_changed` audit with key
    NAMES only; the welcome text itself is never written to the audit), serialised per group
 6. answers with the EFFECTIVE values read back (`from_raw`), never an echo of the input, plus an advisory line when the
    bot lacks the Telegram right the feature needs (advice only: the change is kept and the answer never blocks on it).
Settings changes are not punitive, so they also work while the group is in `dry_run`.

Nothing here touches the other settings keys of the group: a patch carries only the keys of its own command.
"""
from __future__ import annotations

import logging
from typing import Any, Callable

from ..errors import InvalidInput
from ..i18n import t
from ..idempotency import IdempotencyStore, operation_key
from ..members.settings import NewMemberPolicy, TEMPLATE_MAX_CHARS, VerificationSettings, WelcomeSettings
from ..permissions import Permission
from ..protection.tracking import KeyedLocks
from ..telegram_rights import BotCapability, check_bot_capabilities
from .commands import Command, CommandError, ParsedCommand
from .duration import format_duration
from .member_args import MemberArgs, parse_newbie_args, parse_verify_args, parse_welcome_args
from .messages import error_message
from .settings_commands import TOPIC_ORDER, render_lines

log = logging.getLogger(__name__)

_NEWBIE_FLAGS = ("newbie_block_links", "newbie_block_media", "newbie_block_messages")
_SETTINGS_CLASS = {"welcome": WelcomeSettings, "verify": VerificationSettings, "newbie": NewMemberPolicy}
_TOPIC_COMMAND = {"welcome": Command.WELCOME, "verify": Command.VERIFY, "newbie": Command.NEWBIE}


def _state(on: bool, lang: str) -> str:
    return t("cfg_on" if on else "cfg_off", lang)


# ----------------------------------------------------------------------------- rendering (effective values only)
def render_welcome(s: WelcomeSettings, lang: str) -> str:
    after = format_duration(s.welcome_delete_after_seconds, lang) if s.welcome_delete_after_seconds else t("ms_keep", lang)
    lines = [
        t("ms_line_welcome", lang, state=_state(s.welcome_enabled, lang),
          text=t("ms_text_custom" if s.welcome_text else "ms_text_default", lang),
          prev=_state(s.welcome_delete_previous, lang), after=after),
        t("ms_line_service", lang, join=t(f"ms_svc_{s.join_service}", lang), leave=t(f"ms_svc_{s.leave_service}", lang)),
    ]
    return "\n".join(lines)


def render_verify(s: VerificationSettings, lang: str) -> str:
    failure = (t("ms_failure_ban", lang, duration=format_duration(s.verify_ban_seconds, lang))
               if s.verify_failure == "ban" else t(f"ms_failure_{s.verify_failure}", lang))
    return t("ms_line_verify", lang, state=_state(s.verify_enabled, lang), scope=t(f"ms_scope_{s.verify_scope}", lang),
             method=t(f"ms_method_{s.verify_method}", lang), timeout=format_duration(s.verify_timeout_seconds, lang),
             attempts=s.verify_max_attempts, failure=failure)


def render_newbie(s: NewMemberPolicy, lang: str) -> str:
    if s.newbie_seconds == 0:
        return t("ms_line_newbie_off", lang, state=_state(False, lang))
    window = format_duration(s.newbie_seconds, lang)
    if not s.active:
        return t("ms_line_newbie_idle", lang, window=window)
    what = [t(key, lang) for flag, key in ((s.newbie_block_links, "ms_what_links"), (s.newbie_block_media, "ms_what_media"),
                                           (s.newbie_block_messages, "ms_what_messages")) if flag]
    return t("ms_line_newbie_on", lang, window=window, what=("، " if lang == "ar" else ", ").join(what))


def render_topic(topic: str, raw: Any, lang: str) -> str:
    cls = _SETTINGS_CLASS[topic]
    cfg = cls.from_raw(raw)
    return {"welcome": render_welcome, "verify": render_verify, "newbie": render_newbie}[topic](cfg, lang)


class MemberSettingsCommands:
    def __init__(self, *, permissions: Any, group_settings: Any, claims: IdempotencyStore,
                 load_raw: Callable[[int], Any], load_settings: Callable[[int], Any], chat_info: Any,
                 trust_store: Any, bot_trust_store: Any, make_result: Callable[..., Any], kinds: Any):
        self._perm, self._gs, self._claims = permissions, group_settings, claims
        self._load_raw, self._load_settings, self._chat_info = load_raw, load_settings, chat_info
        self._trust_store, self._bot_store = trust_store, bot_trust_store
        self._result, self._kinds = make_result, kinds
        self._locks = KeyedLocks()

    # ------------------------------------------------------------------ entry points
    async def handle(self, parsed: ParsedCommand, chat_id: int, actor_id: int, message_id: int, lang: str):
        R, cmd = self._kinds, parsed.command
        try:
            plan = self._interpret(parsed)
        except CommandError as exc:
            return self._result(R.INVALID, error_message(exc, lang) or t("invalid_input", lang), cmd)
        if plan.op == "vars":
            return self._result(R.INFO, t("ms_vars", lang, limit=TEMPLATE_MAX_CHARS), cmd)
        if plan.op == "show":
            raw = await self._load_raw(chat_id)
            return self._result(R.INFO, self._show_text(plan.topic, raw, lang), cmd)
        return await self._write(plan, chat_id, actor_id, message_id, cmd, lang)

    async def overview(self, chat_id: int, lang: str):
        """`/settings`: every group setting in one read-only answer (protection, welcome, verification, new members,
        trust counts). Gates are the shared MODERATE + license ones, applied by the caller."""
        R, cmd = self._kinds, Command.SETTINGS
        try:
            raw = await self._load_raw(chat_id)
            protection = await self._load_settings(chat_id)
            parts = [t("ms_overview_title", lang), render_lines(protection, TOPIC_ORDER, lang),
                     render_topic("welcome", raw, lang), render_topic("verify", raw, lang),
                     render_topic("newbie", raw, lang)]
            counts = None
            if self._trust_store is not None and self._bot_store is not None:
                counts = (len(await self._trust_store.list(chat_id)), len(await self._bot_store.list(chat_id)))
        except Exception:
            log.error("settings overview unreadable", extra={"group_id": chat_id}, exc_info=True)
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        if counts is not None:
            parts.append(t("ms_overview_trust", lang, users=counts[0], domains=len(protection.links_allow_domains),
                           bots=counts[1]))
        parts.append(t("ms_overview_hint", lang))
        return self._result(R.INFO, "\n".join(parts), cmd)

    # ------------------------------------------------------------------ interpretation / reads
    @staticmethod
    def _interpret(parsed: ParsedCommand) -> MemberArgs:
        cmd = parsed.command
        if cmd is Command.WELCOME:
            return parse_welcome_args(parsed.args, parsed.raw)
        if cmd is Command.VERIFY:
            return parse_verify_args(parsed.args)
        if cmd is Command.NEWBIE:
            return parse_newbie_args(parsed.args)
        raise CommandError("welcome_args")

    def _show_text(self, topic: str, raw: Any, lang: str) -> str:
        text = render_topic(topic, raw, lang)
        if topic == "welcome":
            cfg = WelcomeSettings.from_raw(raw)
            text += "\n" + (t("ms_welcome_text_show", lang, text=cfg.welcome_text) if cfg.welcome_text
                            else t("ms_welcome_text_default", lang))
        return text + "\n" + t(f"ms_hint_{topic}", lang)

    # ------------------------------------------------------------------ writes
    async def _write(self, plan: MemberArgs, chat_id: int, actor_id: int, message_id: int, cmd: Command, lang: str):
        kind, text, notes = await self._apply(plan.topic, plan.patch, chat_id, actor_id,
                                              operation_key("mod", cmd.value, chat_id, message_id), lang)
        return self._result(kind, "\n".join([text, *notes]) if text or notes else "", cmd)

    async def _apply(self, topic: str, patch: Any, chat_id: int, actor_id: int, claim_key: str, lang: str):
        """The ONE write path shared by the commands and the panel buttons (no parallel logic): MANAGE_SETTINGS ->
        claim -> compare with the effective values -> `GroupSettingsService.update`. -> (kind, text, advisory notes)."""
        R = self._kinds
        if self._gs is None:
            return R.ERROR, t("action_failed_safe", lang), []
        await self._perm.require(actor_id, chat_id, Permission.MANAGE_SETTINGS, context_chat_id=chat_id)  # PermissionDenied
        try:
            claimed = await self._claims.claim(claim_key)
        except Exception:
            log.error("member settings claim failed; nothing written", extra={"group_id": chat_id}, exc_info=True)
            return R.ERROR, t("action_failed_safe", lang), []
        if not claimed:
            return R.DUPLICATE, "", []

        cls = _SETTINGS_CLASS[topic]
        async with self._locks.hold(("member_cfg", chat_id)):
            current = cls.from_raw(await self._load_raw(chat_id))
            if all(getattr(current, key) == value for key, value in patch.items()):
                return R.NOOP, t("ms_noop", lang), []
            try:
                row = await self._gs.update(actor_id, chat_id, dict(patch), context_chat_id=chat_id)
            except InvalidInput:
                return R.INVALID, t("invalid_input", lang), []
        text = t("cfg_ok_updated", lang) + "\n" + render_topic(topic, row.settings, lang)
        return R.DONE, text, await self._advice(topic, patch, row.settings, chat_id, lang)

    # ------------------------------------------------------------------ panel (4.7b): same reads, same write path
    async def panel_view(self, topic: str, chat_id: int, lang: str):
        """-> (text, typed settings) of one topic for the panel screen. Raises on an unreadable store (caller fails closed).
        No gate here: the panel press handler already applied MODERATE + the live license for this very press."""
        if topic not in _SETTINGS_CLASS:
            raise ValueError("unknown topic")
        raw = await self._load_raw(chat_id)
        return render_topic(topic, raw, lang), _SETTINGS_CLASS[topic].from_raw(raw)

    async def panel_write(self, topic: str, patch: Any, chat_id: int, actor_id: int, claim_key: str, lang: str):
        """A panel button's write. Same checks as the commands (MANAGE_SETTINGS inside `_apply` -> PermissionDenied,
        claim, compare, `GroupSettingsService.update`); the caller applied MODERATE + the live license. The result's
        `text` carries ONLY the advisory notes (the panel re-renders the screen from the saved values)."""
        if topic not in _SETTINGS_CLASS:
            raise ValueError("unknown topic")
        kind, text, notes = await self._apply(topic, patch, chat_id, actor_id, claim_key, lang)
        keep = "\n".join(notes) if kind is self._kinds.DONE else text
        return self._result(kind, keep, _TOPIC_COMMAND[topic])

    async def _advice(self, topic: str, patch: Any, saved: Any, chat_id: int, lang: str) -> list[str]:
        """Advisory lines only. Never raises and never undoes the change."""
        notes: list[str] = []
        if topic == "welcome" and "welcome_text" in patch and not WelcomeSettings.from_raw(saved).welcome_enabled:
            notes.append(t("ms_note_welcome_off", lang))
        need: BotCapability | None = None
        key = ""
        if topic == "verify" and (patch.get("verify_enabled") is True or patch.get("verify_failure") in ("kick", "ban")):
            if VerificationSettings.from_raw(saved).verify_enabled:
                need, key = BotCapability.RESTRICT_MEMBERS, "ms_warn_rights_restrict"
        elif topic == "newbie" and NewMemberPolicy.from_raw(saved).active and (
                patch.get("newbie_seconds") or any(patch.get(k) is True for k in _NEWBIE_FLAGS)):
            need, key = BotCapability.DELETE_MESSAGES, "ms_warn_rights_delete"
        if need is not None:
            try:
                if not (await check_bot_capabilities(self._chat_info, chat_id, need)).ok:
                    notes.append(t(key, lang))
            except Exception:
                log.warning("bot rights advice unavailable", extra={"group_id": chat_id})
        return notes
