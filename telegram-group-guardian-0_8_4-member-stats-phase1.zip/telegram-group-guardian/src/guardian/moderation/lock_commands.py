"""`/lock` and `/unlock` (Phase 3 / closing part 3): change what ORDINARY MEMBERS may send in the group by editing the
group's default permissions (`setChatPermissions`). Framework independent; reached from `ModerationCommandService._handle`
AFTER the shared first two gates (MODERATE permission, then the license gate).

Path (each step fails closed; covered by tests):
 1. arguments (`config_args.parse_lock_args`; a type is required)               -> INVALID
 2. group `dry_run`: audit + preview, NOTHING else                                -> DRY_RUN (no Telegram, no claim)
 3. bot right `RESTRICT_MEMBERS` (the Bot API requires it for setChatPermissions)  -> BOT_RIGHTS
 4. `claims.claim(operation_key("mod", cmd, chat, message_id))`                   -> DUPLICATE (silent) / ERROR
 5. Telegram get-modify-set (adapter) -> already in the wanted state => NOOP, failure => TELEGRAM_FAILED
 6. audit (lock types only, never message content)

Why no extra actor check: a plain Telegram admin only passes MODERATE when Telegram says they may restrict members, which is
exactly the right Telegram requires to change permissions; owner and delegates are trusted by the project's model.

Documented limits (Telegram, not worked around):
* There is no "links" permission in Telegram: `/lock links` is refused with a pointer to `/protect links on`.
* Administrators are not affected by default permissions. Members with an INDIVIDUAL restriction keep it.
* A lock is permanent until `/unlock` (no timer: a free host may sleep, and an unlock that depends on it would be unsafe).
* `/unlock X` sets exactly the flags of X to allowed. It does not remember what the group had before `/lock`
  (a flag an admin disabled by hand before is enabled again by `/unlock`).
* can_change_info / can_invite_users / can_pin_messages / can_manage_topics are never changed by these commands.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Callable

from ..audit import CHAT_LOCKED, CHAT_UNLOCKED, SecurityAudit, make_event, record_safely
from ..i18n import t
from ..idempotency import IdempotencyStore, operation_key
from ..protection.settings import ProtectionSettings
from ..telegram_rights import BotCapability, check_bot_capabilities
from .commands import Command, CommandError, ParsedCommand
from .config_args import parse_lock_args
from .messages import error_message

log = logging.getLogger(__name__)

MODERATION_DRY_RUN = "moderation_dry_run"
MODERATION_ACTION_FAILED = "moderation_action_failed"


@dataclass(frozen=True, slots=True)
class PermissionChange:
    """Result of `set_default_permissions`: `changed=False` with ok=True means the flags already had the wanted value."""

    ok: bool
    error: str | None = None  # rate_limited | forbidden | not_found | other
    changed: bool = False


class LockCommands:
    def __init__(self, *, actions: Any, chat_info: Any, claims: IdempotencyStore, audit: SecurityAudit | None,
                 load_settings: Callable[[int], Any], make_result: Callable[..., Any], kinds: Any,
                 clock: Callable[[], Any]):
        self._actions, self._chat_info, self._claims, self._audit = actions, chat_info, claims, audit
        self._load_settings, self._result, self._kinds, self._clock = load_settings, make_result, kinds, clock

    async def handle(self, parsed: ParsedCommand, chat_id: int, actor_id: int, message_id: int, lang: str):
        R, cmd = self._kinds, parsed.command
        try:
            args = parse_lock_args(parsed.args)
        except CommandError as exc:
            return self._result(R.INVALID, error_message(exc, lang) or t("invalid_input", lang), cmd)
        allowed = cmd is Command.UNLOCK
        settings: ProtectionSettings = await self._load_settings(chat_id)
        now = self._clock()
        if settings.dry_run:
            await record_safely(self._audit, make_event(
                MODERATION_DRY_RUN, actor=actor_id, group_id=chat_id, now=now, detail=f"{cmd.value} {','.join(args.types)}"))
            return self._result(R.DRY_RUN, t("mod_dry_run_msg", lang, action=t(f"mod_action_{cmd.value}", lang)), cmd)
        cap = await check_bot_capabilities(self._chat_info, chat_id, BotCapability.RESTRICT_MEMBERS)
        if not cap.ok:
            await record_safely(self._audit, make_event(
                MODERATION_ACTION_FAILED, actor=actor_id, group_id=chat_id, now=now, detail=f"{cmd.value} bot_rights_missing"))
            return self._result(R.BOT_RIGHTS, t(cap.user_message_key() or "bot_check_failed", lang), cmd)
        try:
            claimed = await self._claims.claim(operation_key("mod", cmd.value, chat_id, message_id))
        except Exception:
            log.error("lock claim failed; no action", extra={"group_id": chat_id}, exc_info=True)
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        if not claimed:
            return self._result(R.DUPLICATE, "", cmd)
        res = await self._actions.set_default_permissions(chat_id, args.flags, allowed)
        if not getattr(res, "ok", False):
            err = getattr(res, "error", None)
            await record_safely(self._audit, make_event(
                MODERATION_ACTION_FAILED, actor=actor_id, group_id=chat_id, now=now, detail=f"{cmd.value} error={err or 'other'}"))
            key = {"rate_limited": "mod_tg_rate_limited", "forbidden": "lock_tg_forbidden"}.get(err or "", "action_failed_safe")
            return self._result(R.TELEGRAM_FAILED, t(key, lang), cmd)
        names = ", ".join(t(f"lock_type_{ty}", lang) for ty in args.types)
        if not getattr(res, "changed", False):
            return self._result(R.NOOP, t("lock_noop_unlock" if allowed else "lock_noop_lock", lang, types=names), cmd)
        await record_safely(self._audit, make_event(
            CHAT_UNLOCKED if allowed else CHAT_LOCKED, actor=actor_id, group_id=chat_id, now=now,
            detail=f"types={','.join(args.types)} flags={len(args.flags)}"))
        return self._result(R.DONE, t("lock_ok_unlock" if allowed else "lock_ok_lock", lang, types=names), cmd)
