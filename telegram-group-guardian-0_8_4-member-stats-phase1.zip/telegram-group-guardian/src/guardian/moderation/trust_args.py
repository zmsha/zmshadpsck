"""Argument parser of `/trust`, `/untrust` and `/trusted` (Phase 4 / part 2). Pure text logic, strict: an unknown word is an
error (never a note, never guessed).

    /trust                       (reply to a member)            trust that member
    /trust @user | 123456        trust a member (also `/trust user ...`)
    /trust domain example.com .. trust domains (the SAME list as `/protect allow`; sub-domains included)
    /trust bot 123456            trust a bot by numeric id (or reply to a message of that bot)
    /untrust ...                 same forms, removes
    /trusted [users|domains|bots] list (read only)

Arabic aliases of /trust and /untrust are accepted only with a reply, an explicit target, or a scope word, so ordinary
chat is never a command.
"""
from __future__ import annotations

from dataclasses import dataclass

from .arabic import fold_arabic
from .command_error import CommandError
from .config_args import parse_domains
from .targets import looks_like_target

MAX_WORDS = 20
MAX_DOMAINS_PER_COMMAND = 10


def _w(*words: str) -> frozenset[str]:
    return frozenset(fold_arabic(x) for x in words)


USER_WORDS = _w("user", "member", "عضو", "مستخدم", "شخص")
DOMAIN_WORDS = _w("domain", "domains", "site", "نطاق", "نطاقات", "دومين", "موقع")
BOT_WORDS = _w("bot", "بوت")
_LIST_SCOPES = {
    **{w: "users" for w in _w("users", "members", "user", "اعضاء", "الاعضاء", "المستخدمين", "مستخدمين")},
    **{w: "domains" for w in _w("domains", "sites", "نطاقات", "النطاقات", "المواقع")},
    **{w: "bots" for w in _w("bots", "بوتات", "البوتات")},
}
SCOPE_WORDS = USER_WORDS | DOMAIN_WORDS | BOT_WORDS


@dataclass(frozen=True, slots=True)
class TrustArgs:
    scope: str                       # user | domain | bot   (for /trusted: all | users | domains | bots)
    token: str | None = None         # explicit target (@username / numeric id) when there is no reply
    domains: tuple[str, ...] = ()


def is_subject_word(word: object) -> bool:
    """May this word start an intentional Arabic `/trust` form without a reply? (`@user`, an id, or a scope word.)"""
    return isinstance(word, str) and (looks_like_target(word) or fold_arabic(word) in SCOPE_WORDS)


def parse_trust_args(command: str, args: tuple[str, ...] | list[str], *, has_reply: bool) -> TrustArgs:
    """`command` is `trust` | `untrust` | `trusted`. Raises `CommandError`: too_many_args | trust_args |
    trust_need_target | trust_domain."""
    words = list(args)
    if len(words) > MAX_WORDS:
        raise CommandError("too_many_args")
    if command == "trusted":
        if not words:
            return TrustArgs("all")
        scope = _LIST_SCOPES.get(fold_arabic(words[0])) if len(words) == 1 else None
        if scope is None:
            raise CommandError("trust_args")
        return TrustArgs(scope)
    scope = "user"
    if words:
        head = fold_arabic(words[0])
        if head in DOMAIN_WORDS:
            scope, words = "domain", words[1:]
        elif head in BOT_WORDS:
            scope, words = "bot", words[1:]
        elif head in USER_WORDS:
            words = words[1:]
    if scope == "domain":
        try:
            domains = parse_domains(words)
        except CommandError:
            raise CommandError("trust_domain") from None
        if len(domains) > MAX_DOMAINS_PER_COMMAND:
            raise CommandError("trust_domain")
        return TrustArgs("domain", domains=domains)
    if has_reply:
        if words:  # a reply AND a target/extra words: never pick one silently
            raise CommandError("trust_args")
        return TrustArgs(scope)
    if not words:
        raise CommandError("trust_need_target")
    if len(words) != 1:
        raise CommandError("trust_args")
    return TrustArgs(scope, token=words[0])
