"""`/id`, `/info`, `/admins`, `/report` (Phase 3 / part 3.5-1). Framework independent, reached through
`ModerationCommandService.handle` (same entry point, same router, same wiring).

Policy (each point is covered by tests):
* ALL four need an active license for THIS chat (`protection.allowed` and `protection.chat_id == chat`).
  Public commands (`/id /admins /report`) answer NOTHING when it is off (no noise in pending/expired groups);
  `/info` follows the moderation path and says why.
* `/id`   anyone: own id + chat id. The replied-to member's id is added only for moderators.
* `/info` moderators only (`MODERATE`): id, live status, exemption from automation, active warnings, active
  restrictions. Never shows warning reasons or message content.
* `/admins` anyone: names only (no @username, no links, so listing never pings anybody).
* `/report` anyone, by REPLY to a member's message: posts a notice in the group that mentions the admins who can
  act (delete/restrict, max 10). Not allowed against the owner/admins/delegates/bots/yourself. It is notify-only:
  it works in `dry_run` too, because it changes nothing in the group.
* Service accounts / invalid ids are ignored. Abuse control: per-(chat,user) cooldown for `/id`, per-chat cooldown
  for `/admins`, per-(chat,reporter) cooldown for `/report`; a throttled call is SILENT (no reply, nothing else).
  Cooldowns live in memory (a restart/sleep resets them: documented limit).
* `/report` is idempotent per message (`claims`): a redelivered update never pings the admins twice. The audit
  entry stores ids only, never the reason or message text.
"""
from __future__ import annotations

import html
import logging
import unicodedata
from datetime import datetime, timedelta
from typing import Any, Awaitable, Callable

from ..audit import REPORT_FILED, SecurityAudit, make_event, record_safely
from ..auth import MAX_BIGINT, TELEGRAM_SERVICE_ACCOUNT_IDS
from ..errors import InvalidInput
from ..i18n import t
from ..idempotency import IdempotencyStore, operation_key
from ..permissions import Permission
from ..protection.settings import ProtectionSettings
from ..protection_gate import ProtectionContext
from ..telegram_rights import AdminInfo
from .commands import Command, CommandError, ParsedCommand
from .duration import format_duration
from .messages import error_message
from .targets import ReplyInfo, TargetError, TargetInput, UsernameResolver, resolve_target, split_target_args

log = logging.getLogger(__name__)

COOLDOWN_ID = 5          # seconds, per (chat, user)
COOLDOWN_ADMINS = 30     # seconds, per chat
COOLDOWN_REPORT = 60     # seconds, per (chat, reporter), counted from a report that was actually posted
MAX_PINGED_ADMINS = 10
MAX_LISTED_ADMINS = 30
MAX_NAME_LEN = 40
MAX_REASON_LEN = 200
MAX_ACTIVE_LISTED = 5
_MAX_COOLDOWN_KEYS = 10_000
_ZERO_WIDTH = "\u200b"

_STATUS_KEYS = {"member": "info_status_member", "restricted": "info_status_restricted",
                "administrator": "info_status_administrator", "creator": "info_status_creator",
                "left": "info_status_left", "kicked": "info_status_kicked"}


def clean_display(value: str | None, limit: int = MAX_NAME_LEN) -> str:
    """Telegram display names/titles/reasons are user-controlled: drop control/format/bidi characters, collapse
    whitespace, truncate. (HTML escaping is done by the caller / `t`.)"""
    if not value:
        return ""
    kept = "".join(ch for ch in unicodedata.normalize("NFC", str(value))
                   if unicodedata.category(ch) not in ("Cc", "Cf", "Cs", "Co", "Cn", "Zl", "Zp"))
    kept = " ".join(kept.split())
    return kept if len(kept) <= limit else kept[: limit - 1] + "…"


def message_link(chat_id: int, message_id: int | None) -> str | None:
    """`https://t.me/c/<internal id>/<message id>` for supergroups (`-100…` ids) only; None otherwise."""
    if message_id is None or not isinstance(chat_id, int) or isinstance(chat_id, bool):
        return None
    raw = str(chat_id)
    if not raw.startswith("-100") or not raw[4:].isdigit() or raw[4:].startswith("0"):
        return None
    return f"https://t.me/c/{raw[4:]}/{message_id}"


class _Cooldown:
    """In-memory, bounded. `ready` only looks, `mark` starts the cooldown."""

    def __init__(self) -> None:
        self._until: dict[tuple, datetime] = {}

    def ready(self, key: tuple, now: datetime) -> bool:
        until = self._until.get(key)
        return until is None or until <= now

    def mark(self, key: tuple, now: datetime, seconds: float) -> None:
        if len(self._until) >= _MAX_COOLDOWN_KEYS:
            self._until = {k: v for k, v in self._until.items() if v > now}
            if len(self._until) >= _MAX_COOLDOWN_KEYS:
                self._until.clear()
        self._until[key] = now + timedelta(seconds=seconds)


def _valid_actor(value: object) -> bool:
    return (isinstance(value, int) and not isinstance(value, bool) and 0 < value <= MAX_BIGINT
            and value not in TELEGRAM_SERVICE_ACCOUNT_IDS)


class InfoCommands:
    def __init__(
        self, *, permissions: Any, warnings: Any, sanctions: Any, chat_info: Any, claims: IdempotencyStore,
        audit: SecurityAudit | None, bot_id: int, load_settings: Callable[[int], Awaitable[ProtectionSettings]],
        make_result: Callable[..., Any], kinds: Any, usernames: UsernameResolver | None = None,
        clock: Callable[[], datetime], reports: Any = None,
    ):
        self._reports = reports  # ReportService (part 6.3); None = notify only, nothing stored
        self._perm, self._warnings, self._sanctions = permissions, warnings, sanctions
        self._chat_info, self._claims, self._audit, self._bot_id = chat_info, claims, audit, bot_id
        self._load_settings, self._result, self._kinds = load_settings, make_result, kinds
        self._usernames, self._clock = usernames, clock
        self._cool = _Cooldown()

    # ------------------------------------------------------------------ entry point
    async def handle(self, parsed: ParsedCommand, chat_id: int, actor_id: int, message_id: int,
                     protection: ProtectionContext | None, reply: ReplyInfo | None,
                     mention_user_id: int | None, lang: str):
        cmd = parsed.command
        R = self._kinds
        if cmd is Command.INFO:
            return await self._info(parsed, chat_id, actor_id, protection, reply, mention_user_id, lang)
        # ---- public commands: identity and license first, silently
        if not _valid_actor(actor_id):
            return self._result(R.DENIED, "", cmd)
        if protection is None or not protection.allowed or protection.chat_id != chat_id:
            return self._result(R.LICENSE_OFF, "", cmd)
        now = self._clock()
        if cmd is Command.ID:
            return await self._id(chat_id, actor_id, reply, now, lang)
        if cmd is Command.ADMINS:
            return await self._admins(chat_id, now, lang)
        return await self._report(parsed, chat_id, actor_id, message_id, reply, now, lang)

    # ------------------------------------------------------------------ /id
    async def _id(self, chat_id: int, actor_id: int, reply: ReplyInfo | None, now: datetime, lang: str):
        key = ("id", chat_id, actor_id)
        if not self._cool.ready(key, now):
            return self._result(self._kinds.THROTTLED, "", Command.ID)
        self._cool.mark(key, now, COOLDOWN_ID)
        extra = ""
        target_id = None
        if reply is not None and reply.user_id is not None and await self._is_moderator(actor_id, chat_id):
            target_id = reply.user_id
            extra = t("id_target_line", lang, target=str(target_id))
        text = t("id_text", lang, user=str(actor_id), chat=str(chat_id)) + extra
        return self._result(self._kinds.INFO, text, Command.ID, target_id)

    async def _is_moderator(self, actor_id: int, chat_id: int) -> bool:
        try:
            decision = await self._perm.check(actor_id, chat_id, Permission.MODERATE, context_chat_id=chat_id,
                                              audit_denial=False)
        except Exception:
            return False
        return bool(decision.allowed)

    # ------------------------------------------------------------------ /admins
    async def _admins(self, chat_id: int, now: datetime, lang: str):
        R = self._kinds
        key = ("admins", chat_id)
        if not self._cool.ready(key, now):
            return self._result(R.THROTTLED, "", Command.ADMINS)
        self._cool.mark(key, now, COOLDOWN_ADMINS)
        admins = await self._load_admins(chat_id)
        if admins is None:
            return self._result(R.ERROR, t("admins_failed", lang), Command.ADMINS)
        people = [a for a in admins if not a.is_bot]
        people.sort(key=lambda a: (not a.is_creator, clean_display(a.name).casefold(), a.user_id))
        if not people:
            return self._result(R.INFO, t("admins_none", lang), Command.ADMINS)
        lines = []
        for a in people[:MAX_LISTED_ADMINS]:
            name = clean_display(a.name) or t("admins_unnamed", lang)
            if a.is_anonymous:
                name = f"{name} ({t('admins_anonymous', lang)})"
            title = clean_display(a.title, 20)
            lines.append(("👑 " if a.is_creator else "• ") + html.escape(name) + (f" — {html.escape(title)}" if title else ""))
        more = len(people) - len(lines)
        text = t("admins_header", lang) + "\n" + "\n".join(lines)
        if more > 0:
            text += "\n" + t("admins_more", lang, count=more)
        return self._result(R.INFO, text, Command.ADMINS)

    async def _load_admins(self, chat_id: int) -> list[AdminInfo] | None:
        try:
            lister = self._chat_info.list_admins
            admins = await lister(chat_id)
        except Exception:
            return None
        return [a for a in admins if isinstance(a, AdminInfo)]

    # ------------------------------------------------------------------ /info (moderators)
    async def _info(self, parsed: ParsedCommand, chat_id: int, actor_id: int, protection: ProtectionContext | None,
                    reply: ReplyInfo | None, mention_user_id: int | None, lang: str):
        R, cmd = self._kinds, Command.INFO
        await self._perm.require(actor_id, chat_id, Permission.MODERATE, context_chat_id=chat_id)
        if protection is None or not protection.allowed or protection.chat_id != chat_id:
            return self._result(R.LICENSE_OFF, t("mod_license_off", lang), cmd)
        try:
            token, _rest = split_target_args(list(parsed.args), reply)
            target = await resolve_target(
                TargetInput(reply, token, mention_user_id if token else None), group_id=chat_id, actor_id=actor_id,
                bot_id=self._bot_id, permissions=self._perm, chat_info=self._chat_info, usernames=self._usernames,
                require_unprotected=False)
        except (TargetError, CommandError) as exc:
            return self._result(R.INVALID, error_message(exc, lang) or t("invalid_input", lang), cmd)
        except InvalidInput:
            return self._result(R.INVALID, t("invalid_input", lang), cmd)
        uid = target.user_id
        settings = await self._load_settings(chat_id)
        now = self._clock()
        try:
            exempt = bool(await self._perm.is_exempt_from_automation(uid, chat_id))
        except Exception:
            exempt = True
        trusted = False
        if not exempt:
            try:
                trusted = bool(await self._perm.is_trusted(uid, chat_id))
            except Exception:
                trusted = False  # display only: an unreadable trust list is simply not shown
        count = await self._safe(self._warnings.count_active(actor_id, chat_id, uid, context_chat_id=chat_id))
        active = await self._safe(self._sanctions.active(actor_id, chat_id, uid, context_chat_id=chat_id))
        status = t(_STATUS_KEYS.get(target.status, "info_status_unknown"), lang)
        text = t("info_text", lang, user=str(uid), status=status,
                 exempt=t("info_exempt_yes" if exempt else "info_exempt_no", lang),
                 warnings=(f"{count}/{settings.warn_limit}" if isinstance(count, int) else t("info_unavailable", lang)),
                 restrictions=self._restrictions(active, now, lang))
        if trusted:
            text += "\n" + t("info_trusted_line", lang)
        return self._result(R.INFO, text, cmd, uid)

    @staticmethod
    async def _safe(awaitable: Awaitable[Any]) -> Any:
        try:
            return await awaitable
        except Exception:
            log.warning("info lookup failed", exc_info=True)
            return None

    def _restrictions(self, active: Any, now: datetime, lang: str) -> str:
        if active is None:
            return t("info_unavailable", lang)
        rows = [s for s in active if s.is_active(now)]
        if not rows:
            return t("info_restrictions_none", lang)
        parts = []
        for s in rows[:MAX_ACTIVE_LISTED]:
            kind = t(f"mod_action_{s.kind.value}", lang)
            if s.expires_at is None:
                parts.append(f"{kind} ({t('mod_span_forever', lang)})")
            else:
                left = max(int((s.expires_at - now).total_seconds()), 1)
                parts.append(f"{kind} ({t('info_remaining', lang, duration=format_duration(left, lang))})")
        return "، ".join(parts) if lang == "ar" else ", ".join(parts)

    # ------------------------------------------------------------------ /report
    async def _report(self, parsed: ParsedCommand, chat_id: int, actor_id: int, message_id: int,
                      reply: ReplyInfo | None, now: datetime, lang: str):
        R, cmd = self._kinds, Command.REPORT
        if reply is None:
            return self._result(R.INVALID, t("report_need_reply", lang), cmd)
        key = ("report", chat_id, actor_id)
        if not self._cool.ready(key, now):
            return self._result(R.THROTTLED, "", cmd)
        try:
            target = await resolve_target(
                TargetInput(reply, None, None), group_id=chat_id, actor_id=actor_id, bot_id=self._bot_id,
                permissions=self._perm, chat_info=self._chat_info, usernames=None, require_unprotected=True)
        except TargetError as exc:
            return self._result(R.INVALID, self._report_error(exc, lang), cmd)
        admins = await self._load_admins(chat_id)
        if admins is None:
            return self._result(R.ERROR, t("report_failed", lang), cmd, target.user_id)
        pingable = [a for a in admins if not a.is_bot and not a.is_anonymous and a.can_moderate
                    and a.user_id not in TELEGRAM_SERVICE_ACCOUNT_IDS and a.user_id != actor_id]
        pingable.sort(key=lambda a: (not a.is_creator, a.user_id))
        pingable = pingable[:MAX_PINGED_ADMINS]
        if not pingable:
            return self._result(R.ERROR, t("report_no_admins", lang), cmd, target.user_id)
        try:
            claimed = await self._claims.claim(operation_key("report", chat_id, message_id))
        except Exception:
            log.error("report claim failed; nothing sent", extra={"group_id": chat_id}, exc_info=True)
            return self._result(R.ERROR, t("report_failed", lang), cmd, target.user_id)
        if not claimed:
            return self._result(R.DUPLICATE, "", cmd, target.user_id)
        self._cool.mark(key, now, COOLDOWN_REPORT)
        pings = "".join(f'<a href="tg://user?id={a.user_id}">{_ZERO_WIDTH}</a>' for a in pingable)
        text = t("report_head", lang, reporter=str(actor_id), target=str(target.user_id)) + pings
        link = message_link(chat_id, reply.message_id)
        if link:
            text += "\n" + f'<a href="{html.escape(link, quote=True)}">{html.escape(t("report_view_message", lang))}</a>'
        reason = clean_display(" ".join(parsed.args), MAX_REASON_LEN)
        if reason:
            text += "\n" + t("report_reason", lang, reason=reason)
        stored = await self._store_report(chat_id, actor_id, target.user_id, reply.message_id, message_id, parsed)
        await record_safely(self._audit, make_event(
            REPORT_FILED, actor=actor_id, group_id=chat_id, now=now, target=stored,
            detail=f"target={target.user_id} msg={reply.message_id or 0} notified={len(pingable)}"
                   + (f" report={stored}" if stored is not None else "")))
        return self._result(R.DONE, text, cmd, target.user_id)

    async def _store_report(self, chat_id: int, actor_id: int, target_id: int, reported_message_id: int | None,
                            command_message_id: int, parsed: ParsedCommand) -> int | None:
        """Part 6.3: keep the report. BEST EFFORT: a store failure is logged and never changes what the group sees
        (the admins were already going to be notified). Returns the report id, or None when nothing was stored."""
        if self._reports is None:
            return None
        try:
            report, _ = await self._reports.create(
                chat_id, actor_id, target_id, reported_message_id, " ".join(parsed.args) or None,
                idempotency_key=operation_key("reportrow", chat_id, command_message_id))
            return report.id
        except Exception:
            log.error("report could not be stored; the notice still goes out", extra={"group_id": chat_id}, exc_info=True)
            return None

    @staticmethod
    def _report_error(exc: TargetError, lang: str) -> str:
        key = {"self": "report_self", "protected": "report_admin_target", "bot": "report_bot_target",
               "unresolvable": "report_unresolvable", "lookup_failed": "report_failed"}.get(exc.code)
        return t(key, lang) if key else (error_message(exc, lang) or t("invalid_input", lang))
