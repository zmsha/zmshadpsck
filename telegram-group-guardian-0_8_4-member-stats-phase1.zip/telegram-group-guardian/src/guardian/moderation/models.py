"""Plain value types + shared validation for warnings and sanctions."""
from __future__ import annotations

import enum
from dataclasses import dataclass
from datetime import datetime, timedelta

from ..errors import InvalidInput

# Telegram treats a restriction shorter than 30 s or longer than 366 days as PERMANENT, so a
# "temporary" record must stay strictly inside that window (permanent => expires_at is None).
MIN_TEMP_SECONDS = 30
MAX_TEMP_SECONDS = 366 * 86400
MAX_REASON_LEN = 500
MAX_KEY_LEN = 200


class SanctionKind(str, enum.Enum):
    MUTE = "mute"
    BAN = "ban"
    KICK = "kick"


# Kinds that can still be "in force" later (a kick is instantaneous and never active).
RESTRICTING_KINDS = (SanctionKind.MUTE, SanctionKind.BAN)


@dataclass(frozen=True, slots=True)
class ModerationWarning:
    id: int
    group_id: int
    user_id: int
    issued_by: int | None  # None = automatic
    reason: str | None
    created_at: datetime
    expires_at: datetime | None = None
    revoked_at: datetime | None = None
    revoked_by: int | None = None
    idempotency_key: str | None = None

    def is_active(self, now: datetime) -> bool:
        return self.revoked_at is None and (self.expires_at is None or self.expires_at > now)


@dataclass(frozen=True, slots=True)
class Sanction:
    id: int
    group_id: int
    user_id: int
    kind: SanctionKind
    issued_by: int | None  # None = automatic (protection engine)
    reason: str | None
    created_at: datetime
    expires_at: datetime | None = None  # None = permanent (mute/ban) or not applicable (kick)
    lifted_at: datetime | None = None
    lifted_by: int | None = None
    violation: str | None = None
    idempotency_key: str | None = None

    @property
    def automatic(self) -> bool:
        return self.issued_by is None

    def is_active(self, now: datetime) -> bool:
        if self.kind is SanctionKind.KICK or self.lifted_at is not None:
            return False
        return self.expires_at is None or self.expires_at > now


# --------------------------------------------------------------------------- validation helpers
def check_user_id(value: object) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or not 0 < value < 2**63:
        raise InvalidInput("user id must be a positive integer")
    return value


def check_group_id(value: object) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or not -(2**63) <= value < 0:
        raise InvalidInput("group id must be a negative integer")
    return value


def check_key(value: str | None) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or not 1 <= len(value) <= MAX_KEY_LEN:
        raise InvalidInput("invalid idempotency key")
    return value


def check_expiry(kind: SanctionKind, now: datetime, expires_at: datetime | None) -> datetime | None:
    """Temporary records need 30 s <= duration <= 366 d; a kick never has an expiry."""
    if expires_at is None:
        return None
    if kind is SanctionKind.KICK:
        raise InvalidInput("a kick cannot have an expiry")
    if expires_at.tzinfo is None or expires_at.utcoffset() is None:
        raise InvalidInput("expiry must be timezone-aware")
    delta = expires_at - now
    if delta < timedelta(seconds=MIN_TEMP_SECONDS) or delta > timedelta(seconds=MAX_TEMP_SECONDS):
        raise InvalidInput("temporary duration out of range")
    return expires_at


def check_warning_expiry(now: datetime, expires_at: datetime | None) -> datetime | None:
    if expires_at is None:
        return None
    if expires_at.tzinfo is None or expires_at.utcoffset() is None:
        raise InvalidInput("expiry must be timezone-aware")
    if expires_at <= now:
        raise InvalidInput("warning expiry must be in the future")
    return expires_at
