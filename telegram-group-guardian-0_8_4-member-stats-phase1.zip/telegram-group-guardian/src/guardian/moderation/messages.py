"""Map moderation parse/validation errors to safe, localized user messages (no input echoed)."""
from __future__ import annotations

from ..i18n import MESSAGES, t


def error_message(exc: BaseException, lang: str = "ar") -> str | None:
    """Localized text for DurationError / TargetError / CommandError, else None (caller handles it)."""
    code = getattr(exc, "code", None)
    if not isinstance(code, str):
        return None
    name = type(exc).__name__
    if name == "DurationError":
        key = f"mod_err_duration_{code}"
    elif name == "TargetError":
        key = f"mod_err_target_{code}"
    elif name == "CommandError":
        key = f"mod_err_duration_{exc.detail}" if code == "duration" and getattr(exc, "detail", None) else f"mod_err_{code}"
    else:
        return None
    return t(key, lang) if key in MESSAGES["ar"] else None
