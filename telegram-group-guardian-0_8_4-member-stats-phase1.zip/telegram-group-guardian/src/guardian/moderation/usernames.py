"""`UsernameResolver` backed by users the bot has SEEN in a group (Phase 3 / part 7).

Why: the Bot API cannot turn an arbitrary @username into a user id. We remember `(group, username) -> id`
only for people who actually wrote (or were replied to) in a group whose license currently allows protection.

Safety / privacy decisions (documented, covered by tests):
* IN MEMORY ONLY, bounded (LRU, `max_entries`) with a TTL: nothing is persisted, so a restart/sleep of the Render
  free instance forgets everything and `@username` targets fall back to "username_unresolved" until the user
  speaks again. Reply / numeric id / text_mention targets never depend on this store.
* A username can be reassigned to another account, and a user can rename: observing a user REPLACES their old
  username mapping, and a username observed for a new id replaces the old owner. Entries expire after `ttl`.
* Only (username, numeric id) is kept; never names, messages or phone numbers.
Remaining risk (cannot be removed without a live lookup): a user who renamed and a stranger who took the old name
without either speaking again within the TTL. The executor still verifies the target is a current member.
"""
from __future__ import annotations

import re
from collections import OrderedDict
from datetime import datetime, timedelta
from typing import Any, Callable

from ..time_utils import utcnow

_USERNAME = re.compile(r"^[a-z][a-z0-9_]{4,31}$")


class VisibleUsers:
    def __init__(self, *, max_entries: int = 20000, ttl: timedelta = timedelta(days=7),
                 clock: Callable[[], datetime] = utcnow):
        self._max, self._ttl, self._clock = max_entries, ttl, clock
        self._by_name: OrderedDict[tuple[int, str], tuple[int, datetime]] = OrderedDict()
        self._name_of: dict[tuple[int, int], str] = {}

    def __len__(self) -> int:
        return len(self._by_name)

    def observe(self, group_id: Any, user_id: Any, username: Any) -> bool:
        """Remember a visible user. Returns False (and stores nothing) for anything invalid."""
        if not _valid_id(group_id) or not _valid_id(user_id) or user_id <= 0 or not isinstance(username, str):
            return False
        name = username.lstrip("@").lower()
        if not _USERNAME.match(name):
            return False
        self._drop(group_id, user_id)  # the user's previous name is no longer theirs
        previous = self._by_name.pop((group_id, name), None)
        if previous is not None:
            self._name_of.pop((group_id, previous[0]), None)  # the old owner of this name lost it
        self._by_name[(group_id, name)] = (user_id, self._clock())
        self._name_of[(group_id, user_id)] = name
        while len(self._by_name) > self._max:
            (g, _), (uid, _) = self._by_name.popitem(last=False)
            self._name_of.pop((g, uid), None)
        return True

    def forget(self, group_id: int, user_id: int) -> None:
        self._drop(group_id, user_id)

    def _drop(self, group_id: int, user_id: int) -> None:
        old = self._name_of.pop((group_id, user_id), None)
        if old is not None:
            self._by_name.pop((group_id, old), None)

    async def resolve(self, group_id: int, username: str) -> int | None:
        """Only entries of THIS group; expired entries are dropped and treated as unknown."""
        key = (group_id, str(username).lstrip("@").lower())
        hit = self._by_name.get(key)
        if hit is None:
            return None
        if self._clock() - hit[1] > self._ttl:
            self._drop(group_id, hit[0])
            return None
        return hit[0]


def _valid_id(v: Any) -> bool:
    return isinstance(v, int) and not isinstance(v, bool) and v != 0
