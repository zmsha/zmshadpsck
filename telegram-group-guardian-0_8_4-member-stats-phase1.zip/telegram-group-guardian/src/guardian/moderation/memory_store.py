"""In-memory stores (tests / local experiments only; state is lost on restart)."""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime
from typing import Sequence

from ..errors import InvalidInput
from .models import RESTRICTING_KINDS, ModerationWarning, Sanction, SanctionKind


class InMemoryWarningStore:
    def __init__(self) -> None:
        self._rows: list[ModerationWarning] = []
        self._next = 1

    async def add(self, group_id, user_id, issued_by, reason, now, expires_at=None, idempotency_key=None):
        if idempotency_key is not None:
            for row in self._rows:
                if row.group_id == group_id and row.idempotency_key == idempotency_key:
                    return row, False
        row = ModerationWarning(self._next, group_id, user_id, issued_by, reason, now, expires_at,
                                idempotency_key=idempotency_key)
        self._next += 1
        self._rows.append(row)
        return row, True

    async def list_active(self, group_id, user_id, now):
        return [r for r in self._rows if r.group_id == group_id and r.user_id == user_id and r.is_active(now)]

    async def count_active(self, group_id, user_id, now) -> int:
        return len(await self.list_active(group_id, user_id, now))

    async def revoke_all(self, group_id, user_id, revoked_by, now) -> int:
        n = 0
        for i, row in enumerate(self._rows):
            if row.group_id == group_id and row.user_id == user_id and row.is_active(now):
                self._rows[i] = replace(row, revoked_at=now, revoked_by=revoked_by)
                n += 1
        return n

    async def revoke_one(self, group_id, warning_id, revoked_by, now) -> bool:
        for i, row in enumerate(self._rows):
            if row.group_id == group_id and row.id == warning_id and row.revoked_at is None:
                self._rows[i] = replace(row, revoked_at=now, revoked_by=revoked_by)
                return True
        return False

    async def count_in_range(self, group_id, start, end) -> dict[str, int]:
        out = {"issued_auto": 0, "issued_manual": 0, "revoked": 0}
        for r in self._rows:
            if r.group_id != group_id:
                continue
            if start <= r.created_at < end:
                out["issued_auto" if r.issued_by is None else "issued_manual"] += 1
            if r.revoked_at is not None and start <= r.revoked_at < end:
                out["revoked"] += 1
        return out


class InMemorySanctionStore:
    def __init__(self) -> None:
        self._rows: list[Sanction] = []
        self._next = 1

    async def record(self, group_id, user_id, kind, issued_by, reason, now, expires_at=None, violation=None,
                     idempotency_key=None):
        if idempotency_key is not None:
            for row in self._rows:
                if row.idempotency_key == idempotency_key:  # global UNIQUE, like the SQL column
                    if row.group_id != group_id:
                        raise InvalidInput("idempotency key already used")
                    return row, False
        row = Sanction(self._next, group_id, user_id, kind, issued_by, reason, now, expires_at,
                       violation=violation, idempotency_key=idempotency_key)
        self._next += 1
        self._rows.append(row)
        return row, True

    async def get_active(self, group_id, user_id, now, kinds: Sequence[SanctionKind] | None = None):
        wanted = tuple(kinds) if kinds is not None else RESTRICTING_KINDS
        return [r for r in self._rows
                if r.group_id == group_id and r.user_id == user_id and r.kind in wanted and r.is_active(now)]

    async def lift(self, group_id, user_id, kind, lifted_by, now) -> int:
        n = 0
        for i, row in enumerate(self._rows):
            if (row.group_id == group_id and row.user_id == user_id and row.kind is kind
                    and row.is_active(now)):
                self._rows[i] = replace(row, lifted_at=now, lifted_by=lifted_by)
                n += 1
        return n

    async def count_auto_mutes(self, group_id, user_id, since) -> int:
        return sum(1 for r in self._rows
                   if r.group_id == group_id and r.user_id == user_id and r.kind is SanctionKind.MUTE
                   and r.issued_by is None and r.created_at > since)

    async def count_in_range(self, group_id, start, end) -> dict[str, int]:
        out: dict[str, int] = {"lifted": 0}
        for r in self._rows:
            if r.group_id != group_id:
                continue
            if start <= r.created_at < end:
                key = f"{r.kind.value}_{'auto' if r.issued_by is None else 'manual'}"
                out[key] = out.get(key, 0) + 1
            if r.lifted_at is not None and start <= r.lifted_at < end:
                out["lifted"] += 1
        return out
