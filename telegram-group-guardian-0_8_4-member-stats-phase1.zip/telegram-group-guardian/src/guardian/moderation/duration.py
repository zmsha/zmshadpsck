"""Safe duration parser for moderation commands (`30m`, `12h`, `7d`, Arabic units and digits).

Pure and side-effect free. Reuses the single documented upper bound from `models` (Telegram treats
restrictions > 366 days as permanent). The lower bound is 60 s (>= the 30 s Telegram floor) so a
duration that passes here can never fall under 30 s by the time the service validates the expiry.

"Permanent" is NOT a duration: use `is_permanent_word` and pass `expires_at=None` instead.
Unknown / zero / negative / decimal / out-of-range input raises `DurationError` (never guesses).
"""
from __future__ import annotations

import re
import unicodedata

from ..errors import InvalidInput
from .models import MAX_TEMP_SECONDS

MIN_DURATION_SECONDS = 60
MAX_DURATION_SECONDS = MAX_TEMP_SECONDS

_UNIT_SECONDS = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 7 * 86400}
_UNIT_ALIASES = {
    "s": "s", "sec": "s", "secs": "s", "second": "s", "seconds": "s", "ث": "s", "ثانيه": "s", "ثانية": "s", "ثواني": "s",
    "m": "m", "min": "m", "mins": "m", "minute": "m", "minutes": "m", "د": "m", "دقيقه": "m", "دقيقة": "m", "دقائق": "m", "دقايق": "m",
    "h": "h", "hr": "h", "hrs": "h", "hour": "h", "hours": "h", "س": "h", "ساعه": "h", "ساعة": "h", "ساعات": "h",
    "d": "d", "day": "d", "days": "d", "ي": "d", "يوم": "d", "ايام": "d", "أيام": "d",
    "w": "w", "week": "w", "weeks": "w", "اسبوع": "w", "أسبوع": "w", "اسابيع": "w", "أسابيع": "w",
}
PERMANENT_WORDS = frozenset({"perm", "permanent", "forever", "دائم", "دائمه", "دائمة", "للابد", "للأبد", "مؤبد"})

# Quick presets for future keyboards/UI: (label, seconds).
QUICK_DURATIONS: tuple[tuple[str, int], ...] = (("10m", 600), ("1h", 3600), ("1d", 86400), ("7d", 7 * 86400))

_INVISIBLE = dict.fromkeys(map(ord, "\u200b\u200c\u200d\u200e\u200f\u061c\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069\ufeff"))
_DIGITS = {**{0x0660 + i: ord("0") + i for i in range(10)}, **{0x06F0 + i: ord("0") + i for i in range(10)}}
_PATTERN = re.compile(r"^(\d{1,7})\s*([a-z\u0600-\u06ff]+)$")
_MINUS = ("-", "\u2212", "\u2013", "\u2014")


class DurationError(InvalidInput):
    """`code` is a stable machine key (empty|negative|zero|format|unit|too_short|too_long)."""

    def __init__(self, code: str):
        self.code = code
        super().__init__(f"invalid duration: {code}")


def normalize(text: object) -> str:
    """NFKC + Arabic/Persian digits -> ASCII, drop bidi/zero-width marks, lowercase, trim."""
    if not isinstance(text, str):
        return ""
    s = unicodedata.normalize("NFKC", text).translate(_INVISIBLE).translate(_DIGITS)
    return s.strip().lower().replace("\u0640", "")  # tatweel


def is_permanent_word(text: object) -> bool:
    return normalize(text) in PERMANENT_WORDS


def parse_duration(text: object) -> int:
    """Return whole seconds in [MIN_DURATION_SECONDS, MAX_DURATION_SECONDS] or raise DurationError."""
    s = normalize(text)
    if not s:
        raise DurationError("empty")
    if s.startswith(_MINUS):
        raise DurationError("negative")
    m = _PATTERN.match(s)
    if not m:
        raise DurationError("format")
    amount, unit = int(m.group(1)), _UNIT_ALIASES.get(m.group(2))
    if unit is None:
        raise DurationError("unit")
    if amount == 0:
        raise DurationError("zero")
    seconds = amount * _UNIT_SECONDS[unit]
    if seconds < MIN_DURATION_SECONDS:
        raise DurationError("too_short")
    if seconds > MAX_DURATION_SECONDS:
        raise DurationError("too_long")
    return seconds


_INTERVAL = re.compile(r"^(\d{1,7})\s*([a-z؀-ۿ]*)$")


def parse_interval(text: object, *, minimum: int, maximum: int) -> int:
    """Short interval in whole seconds for bot-side limits (slow mode, flood window). Unlike `parse_duration` a
    bare number means SECONDS and the floor is caller-defined. Same normalisation (Arabic digits, units); never guesses:
    empty / negative / zero / unknown unit / decimal / out-of-range raise `DurationError`."""
    s = normalize(text)
    if not s:
        raise DurationError("empty")
    if s.startswith(_MINUS):
        raise DurationError("negative")
    m = _INTERVAL.match(s)
    if not m:
        raise DurationError("format")
    unit = _UNIT_ALIASES.get(m.group(2), None) if m.group(2) else "s"
    if unit is None:
        raise DurationError("unit")
    amount = int(m.group(1))
    if amount == 0:
        raise DurationError("zero")
    seconds = amount * _UNIT_SECONDS[unit]
    if seconds < minimum:
        raise DurationError("too_short")
    if seconds > maximum:
        raise DurationError("too_long")
    return seconds


def format_duration(seconds: int, lang: str = "ar") -> str:
    """Compact human text for replies (largest exact unit)."""
    ar = lang == "ar"
    for size, ar_name, en_name in ((86400, "يوم", "d"), (3600, "ساعة", "h"), (60, "دقيقة", "m")):
        if seconds >= size and seconds % size == 0:
            n = seconds // size
            return f"{n} {ar_name}" if ar else f"{n}{en_name}"
    return f"{seconds} ثانية" if ar else f"{seconds}s"
