"""`CommandError`: the one exception of the command argument parsers (moved out of `commands.py` so that
`commands.py` and `config_args.py` can both use it without a circular import; `commands.CommandError` still works)."""
from __future__ import annotations

from ..errors import InvalidInput


class CommandError(InvalidInput):
    """`code`: duration (see `.detail` for the DurationError code) | too_many_args | pin_* | purge_* | lock_* |
    slowmode_* | antiflood_* | protect_*. Each code has a localized message `mod_err_<code>`."""

    def __init__(self, code: str, detail: str | None = None):
        self.code, self.detail = code, detail
        super().__init__(f"invalid command arguments: {code}")
