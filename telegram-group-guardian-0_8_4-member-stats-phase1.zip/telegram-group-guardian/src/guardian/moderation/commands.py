"""Safe parser for the moderation commands (English slash commands + Arabic aliases).

Pure text logic; no Telegram calls, no permission checks (those belong to the executor, part 5).

* English: `/ban`, `/ban@ThisBot` (a suffix for ANOTHER bot is ignored), case-insensitive.
* Arabic aliases (`حظر`, `الغاء الكتم`, ...) are not Telegram commands, so they are only accepted at
  the very start of a message AND only when they look intentional: a reply to a message, or a first
  argument that looks like a target (`@user` / numeric id). A plain sentence starting with "حذر" is
  therefore never treated as a command.
* Part 3.5 adds the read/notify commands `/id /info /admins /report`. `/id` and `/admins` are "standalone": their
  Arabic aliases (`ايدي`, `المشرفين`) are accepted only when they are the WHOLE message, never at the start of a
  sentence. `/info` and `/report` follow the general alias rule (reply or explicit target required).
* Part 3.5-2 adds `/pin /unpin /purge` (message commands: no member target; see `message_commands.py`). `/unpin`'s
  Arabic aliases are "standalone" (whole message) because it needs no reply; `/pin` and `/purge` follow the general
  alias rule (a reply, or a numeric first argument for `/purge`).
* No duration on ban/mute => permanent (documented default). A first argument that starts with a digit
  on ban/mute MUST be a valid duration, otherwise it is an error (never silently a reason).
"""
from __future__ import annotations

import enum
import re
import unicodedata
from dataclasses import dataclass

from ..export import args as export_args
from ..reports import args as report_args
from ..stats import args as stats_args
from . import config_args, member_args, trust_args
from .arabic import fold_arabic  # noqa: F401  (re-exported: tests and callers import it from here)
from .command_error import CommandError  # noqa: F401  (re-exported)
from .duration import DurationError, is_permanent_word, normalize, parse_duration
from .filter_phrases import parse_filter_phrase
from .targets import looks_like_target

MAX_ARGS = 20
MAX_TEXT = 4096


class Command(str, enum.Enum):
    BAN = "ban"
    UNBAN = "unban"
    MUTE = "mute"
    UNMUTE = "unmute"
    KICK = "kick"
    WARN = "warn"
    WARNINGS = "warnings"
    CLEARWARNS = "clearwarns"
    ID = "id"
    INFO = "info"
    ADMINS = "admins"
    REPORT = "report"
    REPORTS = "reports"
    STATS = "stats"
    EXPORT = "export"
    PIN = "pin"
    UNPIN = "unpin"
    PURGE = "purge"
    LOCK = "lock"
    UNLOCK = "unlock"
    SLOWMODE = "slowmode"
    ANTIFLOOD = "antiflood"
    PROTECT = "protect"
    TRUST = "trust"
    UNTRUST = "untrust"
    TRUSTED = "trusted"
    WELCOME = "welcome"
    VERIFY = "verify"
    NEWBIE = "newbie"
    SETTINGS = "settings"
    PANEL = "panel"


_ARABIC_ALIASES: dict[Command, tuple[str, ...]] = {
    Command.BAN: ("حظر", "بان"),
    Command.UNBAN: ("الغاء الحظر", "فك الحظر", "رفع الحظر"),
    Command.MUTE: ("كتم", "اكتم"),
    Command.UNMUTE: ("الغاء الكتم", "فك الكتم", "رفع الكتم"),
    Command.KICK: ("طرد", "اطرد"),
    Command.WARN: ("تحذير", "حذر", "انذار"),
    Command.WARNINGS: ("التحذيرات", "تحذيرات"),
    Command.CLEARWARNS: ("مسح التحذيرات", "حذف التحذيرات", "تصفير التحذيرات", "الغاء التحذيرات"),
    Command.ID: ("ايدي", "الايدي", "معرفي"),
    Command.INFO: ("معلومات", "معلومات العضو"),
    Command.ADMINS: ("المشرفين", "الادمنية"),
    Command.REPORT: ("بلاغ", "ابلاغ", "ابلغ"),
    # Part 6.4a. "بلاغات" alone is a plain word; it is a command only with the command's own vocabulary or as the whole message.
    Command.REPORTS: ("البلاغات", "قائمة البلاغات", "عرض البلاغات"),
    # Part 6.5b. Bare "احصائيات" is an ordinary word: a command only as the whole message or with the period vocabulary.
    Command.STATS: ("الاحصائيات", "احصائيات", "الاحصاءات", "احصاءات", "احصائيات المجموعة"),
    # Part 6.7b. Bare "تصدير" is an ordinary word: a command only followed by exactly one of the export vocabulary words.
    Command.EXPORT: ("تصدير",),
    Command.PIN: ("تثبيت", "ثبت الرسالة"),
    Command.UNPIN: ("الغاء التثبيت", "فك التثبيت", "الغاء تثبيت"),
    Command.PURGE: ("تنظيف", "مسح الرسائل", "حذف الرسائل"),
    Command.LOCK: ("قفل", "اقفل"),
    Command.UNLOCK: ("فتح", "افتح", "الغاء القفل", "فك القفل"),
    Command.SLOWMODE: ("الوضع البطيء", "الوضع البطئ", "وضع بطيء", "وضع بطئ"),
    Command.ANTIFLOOD: ("مكافحة الفيضان", "مضاد الفيضان", "منع الفيضان"),
    Command.PROTECT: ("اعدادات الحماية", "ضبط الحماية", "حماية", "الحماية"),
    # NOT the bare word "ثقة": a reply of "ثقة" (a compliment) must never add someone to the trust list.
    Command.TRUST: ("وثق", "اضف للموثوقين"),
    Command.UNTRUST: ("الغاء التوثيق", "الغاء الثقة", "سحب الثقة"),
    Command.TRUSTED: ("الموثوقين", "قائمة الثقة", "قائمة الموثوقين"),
    # Part 4.6. Bare words such as "التحقق" are ordinary chat: these aliases need the command's own vocabulary after them.
    Command.WELCOME: ("الترحيب", "رسالة الترحيب", "ضبط الترحيب"),
    Command.VERIFY: ("التحقق", "تحقق الاعضاء", "التحقق من الاعضاء"),
    Command.NEWBIE: ("الاعضاء الجدد", "قيود الاعضاء الجدد"),
    Command.SETTINGS: ("اعدادات المجموعة", "عرض الاعدادات"),
    # Part 4.7a. Never the bare word "لوحة": ordinary chat. Only the distinctive phrases, as the whole message.
    Command.PANEL: ("لوحة التحكم", "لوحة الاعدادات"),
}
# Aliases that are only accepted as the entire message (no reply/target is involved in these commands).
STANDALONE = frozenset({Command.ID, Command.ADMINS, Command.UNPIN, Command.TRUSTED, Command.SETTINGS, Command.PANEL})
# Commands anyone in a licensed group may run (read-only or notify-only); everything else needs MODERATE.
PUBLIC = frozenset({Command.ID, Command.ADMINS, Command.REPORT})
# Report management (part 6.4a): `/reports` and the non-reply forms of `/report` (show|take|resolve|dismiss|type|priority).
REPORT_COMMANDS = frozenset({Command.REPORTS})
# Statistics (part 6.5b): `/stats [day|week|month]` for moderators of THIS group (counts only, read only).
STATS_COMMANDS = frozenset({Command.STATS})
# Exports (part 6.7b): `/export settings|license`; moderators of THIS group for settings, the primary owner for the licence log.
EXPORT_COMMANDS = frozenset({Command.EXPORT})
# Commands that act on MESSAGES, not on a member (no target resolution): /pin /unpin /purge.
MESSAGE_COMMANDS = frozenset({Command.PIN, Command.UNPIN, Command.PURGE})
# Commands that configure the group (part 3.5-3): no member target. Their Arabic aliases are accepted only when the
# words after the alias are a known vocabulary (`config_args.alias_args_ok`), so ordinary chat such as "قفل الباب"
# or "فتح الموضوع" is never taken for a command.
LOCK_COMMANDS = frozenset({Command.LOCK, Command.UNLOCK})
SETTINGS_COMMANDS = frozenset({Command.SLOWMODE, Command.ANTIFLOOD, Command.PROTECT})
CONFIG_COMMANDS = LOCK_COMMANDS | SETTINGS_COMMANDS
# Trust lists (part 4.2): /trust /untrust change them, /trusted lists them. Arabic /trust and /untrust need a reply, an
# explicit target or a scope word (`trust_args.is_subject_word`).
TRUST_COMMANDS = frozenset({Command.TRUST, Command.UNTRUST, Command.TRUSTED})
# Welcome / verification / new-member settings (part 4.6) and the read-only overview of everything (`/settings`).
MEMBER_SETTINGS_COMMANDS = frozenset({Command.WELCOME, Command.VERIFY, Command.NEWBIE})
OVERVIEW_COMMANDS = frozenset({Command.SETTINGS})
# The Inline admin panel (part 4.7a): `/panel` opens it; the buttons are handled by `panel/service.py`.
PANEL_COMMANDS = frozenset({Command.PANEL})
# Commands that accept a duration (others treat every remaining word as the reason).
TIMED = frozenset({Command.BAN, Command.MUTE})

_SLASH = re.compile(r"^/([a-z]{1,32})(?:@([a-z0-9_]{1,64}))?$", re.IGNORECASE)


# longest alias first so "الغاء الحظر" wins over any shorter prefix; value = (word count, command)
_ALIAS_TABLE = sorted(
    ((tuple(fold_arabic(a).split()), cmd) for cmd, aliases in _ARABIC_ALIASES.items() for a in aliases),
    key=lambda item: -len(item[0]),
)


# Part 9.3: `حماية` / `الحماية` are short aliases of /protect; alone they are an ordinary word, so they need a sub-word.
_PROTECT_SHORT = frozenset({tuple(fold_arabic("حماية").split()), tuple(fold_arabic("الحماية").split())})


@dataclass(frozen=True, slots=True)
class ParsedCommand:
    command: Command
    args: tuple[str, ...]  # everything after the command word, whitespace-split
    arabic: bool = False
    raw: str = ""  # text after the command word(s), untouched; only filled for `/welcome` (its template keeps spacing)


@dataclass(frozen=True, slots=True)
class CommandArgs:
    duration_seconds: int | None  # None = permanent (ban/mute) or not applicable
    permanent: bool
    reason: str | None
    rest: tuple[str, ...] = ()  # leftover words after the target token was removed (for callers)


def parse_command(text: object, bot_username: str | None = None, *, has_reply: bool = False) -> ParsedCommand | None:
    """Return the command or None (not for us / not a moderation command). Never raises on odd input."""
    if not isinstance(text, str) or not text.strip() or len(text) > MAX_TEXT:
        return None
    body = text.lstrip()
    if body.startswith("/"):
        words = body.split()
        m = _SLASH.match(words[0])
        if not m:
            return None
        if m.group(2) and (not bot_username or m.group(2).lower() != bot_username.lstrip("@").lower()):
            return None  # addressed to another bot
        try:
            cmd = Command(m.group(1).lower())
        except ValueError:
            return None
        raw = body.split(None, 1)[1] if cmd is Command.WELCOME and len(words) > 1 else ""
        return ParsedCommand(cmd, tuple(words[1:MAX_ARGS + 1]), raw=raw)
    words = body.split()
    phrase = parse_filter_phrase(words)  # part 9.4: `تفعيل فلتر ai`, `اضافة كلمة X`... = `/protect filter|adult ...`
    if phrase is not None:
        return ParsedCommand(Command.PROTECT, phrase, arabic=True)
    folded = [fold_arabic(w) for w in words[:4]]
    for alias, cmd in _ALIAS_TABLE:
        n = len(alias)
        if tuple(folded[:n]) == alias:
            args = tuple(words[n:MAX_ARGS + n])
            if cmd in STANDALONE:
                if len(words) != n:
                    continue  # part of a sentence, not an intentional command
                return ParsedCommand(cmd, (), arabic=True)
            if cmd in CONFIG_COMMANDS:
                if not config_args.alias_args_ok(cmd.value, args):
                    continue  # not the command's own vocabulary: ordinary chat
                if cmd is Command.PROTECT and not args and alias in _PROTECT_SHORT:
                    continue  # the bare word "حماية" is ordinary chat; only the longer phrases work without arguments
                return ParsedCommand(cmd, args, arabic=True)
            if cmd in MEMBER_SETTINGS_COMMANDS:
                if not member_args.alias_args_ok(cmd.value, args):
                    continue  # not the command's own vocabulary: ordinary chat
                parts = body.split(None, n)
                raw = parts[n] if cmd is Command.WELCOME and len(parts) > n else ""
                return ParsedCommand(cmd, args, arabic=True, raw=raw)
            if cmd in (Command.TRUST, Command.UNTRUST):
                if not has_reply and not (args and trust_args.is_subject_word(args[0])):
                    return None  # ordinary chat
                return ParsedCommand(cmd, args, arabic=True)
            if cmd is Command.REPORTS:
                if not report_args.alias_args_ok(args):
                    continue  # not the command's own vocabulary: ordinary chat
                return ParsedCommand(cmd, args, arabic=True)
            if cmd is Command.STATS:
                if not stats_args.alias_args_ok(args):
                    continue  # not the command's own vocabulary: ordinary chat
                return ParsedCommand(cmd, args, arabic=True)
            if cmd is Command.EXPORT:
                if not export_args.alias_args_ok(args):
                    continue  # not the command's own vocabulary: ordinary chat
                return ParsedCommand(cmd, args, arabic=True)
            if cmd is Command.REPORT and not has_reply and report_args.looks_like_admin_form(args):
                return ParsedCommand(cmd, args, arabic=True)  # "بلاغ استلام 5": management, not a new report
            if not has_reply and not (args and looks_like_target(args[0])):
                return None  # looks like ordinary chat, not an intentional command
            return ParsedCommand(cmd, args, arabic=True)
    return None


def interpret_args(command: Command, rest: tuple[str, ...] | list[str]) -> CommandArgs:
    """Interpret the words left after the target was removed (see `targets.split_target_args`)."""
    words = list(rest)
    if len(words) > MAX_ARGS:
        raise CommandError("too_many_args")
    duration: int | None = None
    permanent = False
    if command in TIMED and words:
        first = normalize(words[0])
        if is_permanent_word(first):
            permanent = True
            words = words[1:]
        elif first[:1].isdigit() or first[:1] in ("-", "\u2212"):
            try:
                duration = parse_duration(first)
            except DurationError as exc:
                raise CommandError("duration", exc.code) from None
            words = words[1:]
    if command in TIMED and duration is None:
        permanent = True  # documented default: no duration => permanent
    reason = " ".join(words).strip() or None
    if reason:
        reason = "".join(ch for ch in unicodedata.normalize("NFC", reason) if ch.isprintable() or ch == " ")
        reason = reason.strip() or None
    return CommandArgs(duration, permanent, reason, tuple(words))


# ----------------------------------------------------------------------------- message commands (/pin /unpin /purge)
PURGE_MAX = 100          # Telegram's deleteMessages accepts 1..100 ids per call
PURGE_CONFIRM_ABOVE = 10  # a purge of MORE messages than this needs the explicit confirm word
_SILENT_WORDS = frozenset({"silent", "quiet", "صامت", "بصمت", "صمت"})
_CONFIRM_WORDS = frozenset({"confirm", "yes", "تاكيد", "اكيد", "موافق"})


@dataclass(frozen=True, slots=True)
class MessageArgs:
    silent: bool = False      # /pin: do not notify members
    count: int | None = None  # /purge N (no reply): how many ids before the command
    confirm: bool = False     # /purge ... confirm


def interpret_message_args(command: Command, args: tuple[str, ...] | list[str], *, has_reply: bool) -> MessageArgs:
    """Arguments of /pin /unpin /purge. Strict: an unknown word is an error (never silently ignored or taken as a
    reason), because a mis-parsed purge deletes real messages. Raises `CommandError` with a stable code
    (`pin_need_reply|pin_args|unpin_args|purge_need_arg|purge_ambiguous|purge_range|purge_args|too_many_args`)."""
    words = list(args)
    if len(words) > MAX_ARGS:
        raise CommandError("too_many_args")
    if command is Command.UNPIN:
        if words:
            raise CommandError("unpin_args")
        return MessageArgs()
    if command is Command.PIN:
        if not has_reply:
            raise CommandError("pin_need_reply")
        silent = False
        for w in words:
            if fold_arabic(w) in _SILENT_WORDS:
                silent = True
            else:
                raise CommandError("pin_args")
        return MessageArgs(silent=silent)
    if command is not Command.PURGE:
        raise CommandError("purge_args")
    count: int | None = None
    confirm = False
    for w in words:
        n = normalize(w)
        if n.isdigit() and n.isascii():
            if count is not None:
                raise CommandError("purge_args")
            if len(n) > 4:
                raise CommandError("purge_range")
            count = int(n)
        elif fold_arabic(w) in _CONFIRM_WORDS:
            confirm = True
        else:
            raise CommandError("purge_args")
    if has_reply and count is not None:
        raise CommandError("purge_ambiguous")
    if not has_reply and count is None:
        raise CommandError("purge_need_arg")
    if count is not None and not 1 <= count <= PURGE_MAX:
        raise CommandError("purge_range")
    return MessageArgs(count=count, confirm=confirm)
