"""`/slowmode`, `/antiflood` and `/protect` (Phase 3 / closing part 3): show and change the group's PROTECTION settings
from chat. Framework independent; reached from `ModerationCommandService._handle` AFTER the shared first two gates
(MODERATE permission, then the license gate).

Reading (`/slowmode`, `/antiflood`, `/protect`, `/protect allow list`) needs only those two gates. Every WRITE then:
 1. parses strictly (`config_args`; unknown word => INVALID, nothing is guessed)
 2. requires `MANAGE_SETTINGS` for THIS chat (Telegram admins of the group, GROUP_MANAGER delegates, the owner; a
    MODERATOR delegate may read but not change) -> DENIED. `/protect dryrun` is additionally PRIMARY-OWNER only: it is the
    owner's test switch and turning it on silences every automatic sanction.
 3. claims `operation_key("mod", cmd, chat, message_id)` (a redelivered update never writes/audits twice) -> DUPLICATE
 4. writes through `GroupSettingsService.update` (permission re-check, validation, `settings_changed` audit with key
    names only), serialised per group so two concurrent `allow add` cannot lose an entry
 5. answers with the EFFECTIVE values read back (`ProtectionSettings.from_raw`), never an echo of the input.
Settings changes are not punitive, so they also work while the group is in `dry_run` (needed to switch it off).

`/slowmode` is enforced BY THE BOT (the Bot API cannot set Telegram's own slow mode): it deletes a member's message sent
sooner than N seconds after their previous accepted one, needs the bot's delete right, never mutes, exempts the owner,
admins, delegates and the trust list, and lives in memory (resets on restart/sleep).
"""
from __future__ import annotations

import json
import logging
from typing import Any, Callable

from ..errors import InvalidInput
from ..i18n import t
from ..idempotency import IdempotencyStore, operation_key
from ..permissions import ActorLevel, Permission
from ..protection.adult_words import MAX_CUSTOM_JSON_BYTES, MAX_CUSTOM_WORDS
from ..protection.settings import MAX_DOMAINS, ProtectionSettings
from ..protection.tracking import KeyedLocks
from .commands import Command, CommandError, ParsedCommand
from .config_args import ProtectArgs, parse_antiflood_args, parse_protect_args, parse_slowmode_args
from .duration import format_duration
from .messages import error_message

log = logging.getLogger(__name__)

MAX_ALLOW_JSON_BYTES = 3500  # the settings validator allows 4096 bytes per patch; keep headroom
_TOPIC_OF_KEY = {
    "links_enabled": "links", "links_allow_invites": "links", "links_allow_domains": "links",
    "flood_enabled": "flood", "flood_max_messages": "flood", "flood_window_seconds": "flood",
    "duplicate_enabled": "duplicates", "duplicate_max_repeats": "duplicates", "duplicate_window_seconds": "duplicates",
    "slowmode_seconds": "slowmode", "escalation_mutes_seconds": "escalation", "escalation_window_seconds": "escalation",
    "warn_limit": "warn", "warn_action": "warn", "warn_action_seconds": "warn", "dry_run": "dryrun",
    "adult_enabled": "adult", "adult_custom_words": "adult",
    "cf_ai": "filter", "cf_emoji": "filter", "cf_scripts": "filter", "cf_names": "filter", "cf_photos": "filter",
    "cf_exempt": "filter",
}
_TOPIC_ORDER = ("links", "adult", "filter", "flood", "duplicates", "slowmode", "escalation", "warn", "dryrun")
# Keys a panel button may change (kept in sync with `panel.actions.PROTECT_KEYS`; a test asserts the equality).
PANEL_KEYS = frozenset({
    "links_enabled", "links_allow_invites", "flood_enabled", "flood_max_messages", "duplicate_enabled",
    "slowmode_seconds", "warn_limit", "warn_action", "warn_action_seconds"})
TOPIC_ORDER = _TOPIC_ORDER  # public alias (the `/settings` overview shows every protection topic)


def _state(on: bool, lang: str) -> str:
    return t("cfg_on" if on else "cfg_off", lang)


def render_lines(s: ProtectionSettings, topics: tuple[str, ...], lang: str) -> str:
    """One localized line per topic, in a fixed order, from the EFFECTIVE (clamped) settings."""
    lines: list[str] = []
    for topic in _TOPIC_ORDER:
        if topic not in topics:
            continue
        if topic == "links":
            invites = t("cfg_allowed" if s.links_allow_invites else "cfg_blocked", lang)
            lines.append(t("cfg_line_links", lang, state=_state(s.links_enabled, lang), invites=invites,
                           domains=len(s.links_allow_domains)))
        elif topic == "adult":
            lines.append(t("cfg_line_adult", lang, state=_state(s.adult_enabled, lang), custom=len(s.adult_custom_words)))
        elif topic == "filter":
            lines.append(t("cfg_line_filter", lang, ai=_state(s.cf_ai, lang), emoji=_state(s.cf_emoji, lang),
                           scripts=_state(s.cf_scripts, lang), names=_state(s.cf_names, lang),
                           photos=_state(s.cf_photos, lang), exempt=len(s.cf_exempt)))
        elif topic == "flood":
            lines.append(t("cfg_line_flood", lang, state=_state(s.flood_enabled, lang),
                           n=s.flood_max_messages, seconds=s.flood_window_seconds))
        elif topic == "duplicates":
            lines.append(t("cfg_line_duplicates", lang, state=_state(s.duplicate_enabled, lang),
                           n=s.duplicate_max_repeats, seconds=s.duplicate_window_seconds))
        elif topic == "slowmode":
            state = (t("cfg_slow_every", lang, seconds=s.slowmode_seconds) if s.slowmode_seconds
                     else t("cfg_off", lang))
            lines.append(t("cfg_line_slowmode", lang, state=state))
        elif topic == "escalation":
            steps = ("، " if lang == "ar" else ", ").join(format_duration(x, lang) for x in s.escalation_mutes_seconds)
            lines.append(t("cfg_line_escalation", lang, steps=steps,
                           window=format_duration(s.escalation_window_seconds, lang)))
        elif topic == "warn":
            lines.append(t("cfg_line_warn", lang, limit=s.warn_limit, action=_warn_action_text(s, lang)))
        else:
            lines.append(t("cfg_line_dryrun", lang, state=_state(s.dry_run, lang)))
    return "\n".join(lines)


def _warn_action_text(s: ProtectionSettings, lang: str) -> str:
    action = t(f"mod_action_{s.warn_action}", lang)
    if s.warn_action == "kick":
        return action
    span = (t("mod_span_for", lang, duration=format_duration(s.warn_action_seconds, lang))
            if s.warn_action_seconds else t("mod_span_forever", lang))
    return f"{action} {span}"


class SettingsCommands:
    def __init__(self, *, permissions: Any, group_settings: Any, claims: IdempotencyStore,
                 load_settings: Callable[[int], Any], make_result: Callable[..., Any], kinds: Any,
                 load_raw: Callable[[int], Any] | None = None):
        self._perm, self._gs, self._claims = permissions, group_settings, claims
        self._load_settings, self._result, self._kinds = load_settings, make_result, kinds
        self._load_raw = load_raw  # STRICT reader (raises on a store failure); only the panel uses it
        self._locks = KeyedLocks()

    # ------------------------------------------------------------------ entry point
    async def handle(self, parsed: ParsedCommand, decision: Any, chat_id: int, actor_id: int, message_id: int, lang: str):
        R, cmd = self._kinds, parsed.command
        try:
            plan = self._interpret(parsed)
        except CommandError as exc:
            return self._result(R.INVALID, error_message(exc, lang) or t("invalid_input", lang), cmd)

        if plan.op in ("show", "allow_list", "adult_list", "filter_exempt_list"):  # read-only: no permission beyond MODERATE, no claim
            return self._result(R.INFO, await self._read_text(plan, chat_id, lang), cmd)

        return await self._write(plan, decision, chat_id, actor_id, message_id, cmd, lang)

    async def change_allow(self, op: str, domains: tuple[str, ...], *, cmd: Command, decision: Any, chat_id: int,
                           actor_id: int, message_id: int, lang: str):
        """Add/remove domains of the ONE trusted-domain list (`links_allow_domains`) on behalf of `/trust domain` and
        `/untrust domain`: same permission (MANAGE_SETTINGS), claim, per-group lock, validation and audit as `/protect allow`."""
        if op not in ("allow_add", "allow_remove"):
            raise ValueError(op)
        return await self._write(ProtectArgs(op, domains=domains), decision, chat_id, actor_id, message_id, cmd, lang)

    # ------------------------------------------------------------------ panel (4.7c): same reads, same write path
    async def panel_view(self, chat_id: int, lang: str):
        """-> (text, effective ProtectionSettings) for the panel's protection screen. Raises on an unreadable store
        (the caller fails closed). No gate: the panel press handler already applied MODERATE + the live license."""
        s = await self._strict_settings(chat_id)
        return render_lines(s, _TOPIC_ORDER, lang), s

    async def _strict_settings(self, chat_id: int) -> ProtectionSettings:
        """Effective settings, but a read failure RAISES: `_load_settings` falls back to the defaults, and a panel must
        never show (or compare a write against) values that are not the stored ones."""
        if self._load_raw is None:
            raise RuntimeError("strict settings reader not configured")
        return ProtectionSettings.from_raw(await self._load_raw(chat_id))

    async def panel_write(self, patch: Any, chat_id: int, actor_id: int, claim_key: str, lang: str):
        """A panel button's protection write: MANAGE_SETTINGS -> claim -> compare with the EFFECTIVE values ->
        `GroupSettingsService.update` (validation + `settings_changed` audit with key names only), serialised per
        group like `/protect`. Only the keys in `PANEL_KEYS` are accepted (never `dry_run`, which is owner-only)."""
        R, cmd = self._kinds, Command.PROTECT
        if not isinstance(patch, dict) or not patch or not set(patch) <= PANEL_KEYS:
            raise ValueError("panel patch outside the allowed protection keys")
        if self._gs is None:
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        await self._perm.require(actor_id, chat_id, Permission.MANAGE_SETTINGS, context_chat_id=chat_id)  # PermissionDenied
        try:
            claimed = await self._claims.claim(claim_key)
        except Exception:
            log.error("panel settings claim failed; nothing written", extra={"group_id": chat_id}, exc_info=True)
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        if not claimed:
            return self._result(R.DUPLICATE, "", cmd)
        async with self._locks.hold(("cfg", chat_id)):
            current = await self._strict_settings(chat_id)
            if all(getattr(current, key) == value for key, value in patch.items()):
                return self._result(R.NOOP, t("ms_noop", lang), cmd)
            try:
                await self._gs.update(actor_id, chat_id, dict(patch), context_chat_id=chat_id)
            except InvalidInput:
                return self._result(R.INVALID, t("invalid_input", lang), cmd)
        return self._result(R.DONE, "", cmd)  # the panel re-renders the screen from the saved values

    async def _write(self, plan: ProtectArgs, decision: Any, chat_id: int, actor_id: int, message_id: int,
                     cmd: Command, lang: str):
        R = self._kinds
        # ---- writes
        if self._gs is None:
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        await self._perm.require(actor_id, chat_id, Permission.MANAGE_SETTINGS, context_chat_id=chat_id)  # DENIED via PermissionDenied
        if plan.owner_only and getattr(decision, "level", None) is not ActorLevel.OWNER:
            return self._result(R.DENIED, t("cfg_owner_only", lang), cmd)
        try:
            claimed = await self._claims.claim(operation_key("mod", cmd.value, chat_id, message_id))
        except Exception:
            log.error("settings claim failed; nothing written", extra={"group_id": chat_id}, exc_info=True)
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        if not claimed:
            return self._result(R.DUPLICATE, "", cmd)

        async with self._locks.hold(("cfg", chat_id)):
            current = await self._load_settings(chat_id)
            patch, early = self._patch_for(plan, current, cmd, lang)
            if early is not None:
                return early
            try:
                row = await self._gs.update(actor_id, chat_id, patch, context_chat_id=chat_id)
            except InvalidInput:
                return self._result(R.INVALID, t("invalid_input", lang), cmd)
        effective = ProtectionSettings.from_raw(row.settings)
        topics = tuple(sorted({_TOPIC_OF_KEY[k] for k in patch}, key=_TOPIC_ORDER.index))
        text = t("cfg_ok_updated", lang) + "\n" + render_lines(effective, topics, lang)
        return self._result(R.DONE, text, cmd)

    # ------------------------------------------------------------------ interpretation
    def _interpret(self, parsed: ParsedCommand) -> ProtectArgs:
        cmd = parsed.command
        if cmd is Command.SLOWMODE:
            seconds = parse_slowmode_args(parsed.args).seconds
            return ProtectArgs("show", topic="slowmode") if seconds is None else ProtectArgs(
                "set", {"slowmode_seconds": seconds})
        if cmd is Command.ANTIFLOOD:
            patch = parse_antiflood_args(parsed.args).patch
            return ProtectArgs("show", topic="flood") if patch is None else ProtectArgs("set", patch)
        return parse_protect_args(parsed.args)

    async def _read_text(self, plan: ProtectArgs, chat_id: int, lang: str) -> str:
        s = await self._load_settings(chat_id)
        if plan.op == "filter_exempt_list":
            if not s.cf_exempt:
                return t("cfg_exempt_empty", lang)
            return t("cfg_exempt_list", lang, count=len(s.cf_exempt), items="\n".join(f"• {i}" for i in s.cf_exempt))
        if plan.op == "adult_list":
            if not s.adult_custom_words:
                return t("cfg_adult_empty", lang)
            items = "\n".join(f"• {w}" for w in s.adult_custom_words)
            return t("cfg_adult_list", lang, count=len(s.adult_custom_words), items=items)
        if plan.op == "allow_list":
            if not s.links_allow_domains:
                return t("cfg_allow_empty", lang)
            items = "\n".join(f"• {d}" for d in s.links_allow_domains)
            return t("cfg_allow_list", lang, count=len(s.links_allow_domains), items=items)
        if plan.topic is not None:  # /slowmode or /antiflood without arguments: just that topic
            extra = "\n" + t("cfg_slow_note", lang) if plan.topic == "slowmode" else ""
            return render_lines(s, (plan.topic,), lang) + extra
        return t("cfg_show_title", lang) + "\n" + render_lines(s, _TOPIC_ORDER, lang)

    def _patch_for(self, plan: ProtectArgs, current: ProtectionSettings, cmd: Command, lang: str):
        """-> (patch, early_result). `early_result` is a ready CommandResult for NOOP / too-many cases."""
        R = self._kinds
        if plan.op == "set":
            return dict(plan.patch), None
        if plan.op.startswith("adult_"):
            return self._adult_patch(plan, current, cmd, lang)
        if plan.op.startswith("filter_exempt_"):
            return self._exempt_patch(plan, current, cmd, lang)
        have = list(current.links_allow_domains)
        if plan.op == "allow_add":
            new = have + [d for d in plan.domains if d not in have]
            if len(new) == len(have):
                return None, self._result(R.NOOP, t("cfg_allow_exists", lang), cmd)
            if len(new) > MAX_DOMAINS or len(json.dumps(new)) > MAX_ALLOW_JSON_BYTES:
                return None, self._result(R.INVALID, t("cfg_allow_full", lang, limit=MAX_DOMAINS), cmd)
            return {"links_allow_domains": new}, None
        if plan.op == "allow_remove":
            new = [d for d in have if d not in plan.domains]
            if len(new) == len(have):
                return None, self._result(R.NOOP, t("cfg_allow_not_found", lang), cmd)
            return {"links_allow_domains": new}, None
        # allow_clear
        if not have:
            return None, self._result(R.NOOP, t("cfg_allow_empty", lang), cmd)
        return {"links_allow_domains": []}, None

    def _adult_patch(self, plan: ProtectArgs, current: ProtectionSettings, cmd: Command, lang: str):
        """The group's OWN extra adult words (`/protect adult add|remove|clear`); the built-in list is never edited."""
        R = self._kinds
        have = list(current.adult_custom_words)
        if plan.op == "adult_add":
            new = have + [w for w in plan.words if w not in have]
            if len(new) == len(have):
                return None, self._result(R.NOOP, t("cfg_adult_exists", lang), cmd)
            if len(new) > MAX_CUSTOM_WORDS or len(json.dumps(new, ensure_ascii=False)) > MAX_CUSTOM_JSON_BYTES:
                return None, self._result(R.INVALID, t("cfg_adult_full", lang, limit=MAX_CUSTOM_WORDS), cmd)
            return {"adult_custom_words": new}, None
        if plan.op == "adult_remove":
            new = [w for w in have if w not in plan.words]
            if len(new) == len(have):
                return None, self._result(R.NOOP, t("cfg_adult_not_found", lang), cmd)
            return {"adult_custom_words": new}, None
        if not have:  # adult_clear
            return None, self._result(R.NOOP, t("cfg_adult_empty", lang), cmd)
        return {"adult_custom_words": []}, None

    def _exempt_patch(self, plan: ProtectArgs, current: ProtectionSettings, cmd: Command, lang: str):
        """`/protect filter exempt add|remove|clear`: user ids the content filter never touches."""
        from ..protection.settings import MAX_CF_EXEMPT

        R = self._kinds
        have = list(current.cf_exempt)
        if plan.op == "filter_exempt_add":
            new = have + [i for i in plan.ids if i not in have]
            if len(new) == len(have):
                return None, self._result(R.NOOP, t("cfg_exempt_exists", lang), cmd)
            if len(new) > MAX_CF_EXEMPT:
                return None, self._result(R.INVALID, t("cfg_exempt_full", lang, limit=MAX_CF_EXEMPT), cmd)
            return {"cf_exempt": new}, None
        if plan.op == "filter_exempt_remove":
            new = [i for i in have if i not in plan.ids]
            if len(new) == len(have):
                return None, self._result(R.NOOP, t("cfg_exempt_not_found", lang), cmd)
            return {"cf_exempt": new}, None
        if not have:
            return None, self._result(R.NOOP, t("cfg_exempt_empty", lang), cmd)
        return {"cf_exempt": []}, None
