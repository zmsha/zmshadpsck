"""Persistence contracts for warnings and sanctions. ALL methods take group_id and never read or
change rows of another group. `issued_by=None` means an automatic (system) action."""
from __future__ import annotations

from datetime import datetime
from typing import Protocol, Sequence

from .models import ModerationWarning, Sanction, SanctionKind


class WarningStore(Protocol):
    async def add(
        self, group_id: int, user_id: int, issued_by: int | None, reason: str | None, now: datetime,
        expires_at: datetime | None = None, idempotency_key: str | None = None,
    ) -> tuple[ModerationWarning, bool]:
        """Idempotent per (group, key): a repeated key returns (existing, False) and adds nothing."""
        ...

    async def list_active(self, group_id: int, user_id: int, now: datetime) -> list[ModerationWarning]: ...

    async def count_active(self, group_id: int, user_id: int, now: datetime) -> int: ...

    async def revoke_all(self, group_id: int, user_id: int, revoked_by: int, now: datetime) -> int:
        """Revoke every ACTIVE warning of the user in this group; returns how many."""
        ...

    async def revoke_one(self, group_id: int, warning_id: int, revoked_by: int, now: datetime) -> bool: ...

    async def count_in_range(self, group_id: int, start: datetime, end: datetime) -> dict[str, int]:
        """Statistics (6.5a), `start <= t < end`: `issued_auto`/`issued_manual` by creation time, `revoked` by revoke time."""
        ...


class SanctionStore(Protocol):
    async def record(
        self, group_id: int, user_id: int, kind: SanctionKind, issued_by: int | None, reason: str | None,
        now: datetime, expires_at: datetime | None = None, violation: str | None = None,
        idempotency_key: str | None = None,
    ) -> tuple[Sanction, bool]:
        """Idempotent per key: a repeated key returns (existing, False) and records nothing."""
        ...

    async def get_active(
        self, group_id: int, user_id: int, now: datetime, kinds: Sequence[SanctionKind] | None = None
    ) -> list[Sanction]: ...

    async def lift(self, group_id: int, user_id: int, kind: SanctionKind, lifted_by: int, now: datetime) -> int:
        """Lift every ACTIVE record of `kind` for the user in this group; returns how many."""
        ...

    async def count_auto_mutes(self, group_id: int, user_id: int, since: datetime) -> int:
        """Automatic mutes created strictly after `since` (escalation window)."""
        ...

    async def count_in_range(self, group_id: int, start: datetime, end: datetime) -> dict[str, int]:
        """Statistics (6.5a), `start <= t < end`: `<kind>_auto`/`<kind>_manual` by creation time, `lifted` by lift time."""
        ...
