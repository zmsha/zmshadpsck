"""Builds `ModerationCommandService` lazily because it needs the bot's own id (`getMe`), which is only available
asynchronously after the app starts. `Services.moderation_commands` is this wrapper; it exposes the same
`handle(...)`. If the identity lookup fails the command FAILS CLOSED (generic error), never runs without a bot id."""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Callable

from ..i18n import t
from .executor import CommandResult, ModerationCommandService, ResultKind

log = logging.getLogger(__name__)


class LazyModerationCommands:
    def __init__(self, bot: Any, build: Callable[[int], ModerationCommandService], *, language: str = "ar"):
        self._bot, self._build, self._language = bot, build, language
        self._service: ModerationCommandService | None = None
        self._lock = asyncio.Lock()

    async def _get(self) -> ModerationCommandService:
        if self._service is None:
            async with self._lock:
                if self._service is None:
                    me = await self._bot.me()
                    bot_id = me.id
                    if not isinstance(bot_id, int) or isinstance(bot_id, bool) or bot_id <= 0:
                        raise ValueError("invalid bot id")
                    self._service = self._build(bot_id)
        return self._service

    async def handle(self, parsed, **kwargs) -> CommandResult:
        try:
            service = await self._get()
        except Exception as exc:
            log.error("moderation service unavailable (%s)", type(exc).__name__)
            lang = kwargs.get("language") or self._language
            return CommandResult(ResultKind.ERROR, t("action_failed_safe", lang), getattr(parsed, "command", None))
        return await service.handle(parsed, **kwargs)

    async def overview(self, chat_id: int, lang: str) -> CommandResult:
        """Ungated read-only overview for the panel press handler (which applies its own gates). Builds the service on
        first use, so a press right after a restart/sleep works without any command having run. Fails closed."""
        try:
            service = await self._get()
        except Exception as exc:
            log.error("moderation service unavailable (%s)", type(exc).__name__)
            return CommandResult(ResultKind.ERROR, t("action_failed_safe", lang))
        return await service.overview(chat_id, lang)

    async def panel_topic(self, topic: str, chat_id: int, lang: str):
        """Read one settings topic for a panel screen (builds the service on first use). Raises when unavailable: the
        panel turns any exception into a refusal toast and changes nothing."""
        return await (await self._get()).panel_topic(topic, chat_id, lang)

    async def panel_write(self, topic: str, patch, chat_id: int, actor_id: int, claim_key: str, lang: str):
        """Write one panel setting. Raises PermissionDenied / other errors to the panel, which fails closed."""
        return await (await self._get()).panel_write(topic, patch, chat_id, actor_id, claim_key, lang)
