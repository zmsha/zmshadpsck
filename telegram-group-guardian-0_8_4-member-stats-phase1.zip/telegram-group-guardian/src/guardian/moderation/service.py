"""Manual warnings / sanction records. Every method authorizes through PermissionService FIRST
(MODERATE, bound to the chat where the command was typed), validates input, and touches rows of the
single `group_id` it is given. Commands (part 4) call these; they never touch Telegram.

NOT checked here (the command layer must, using live Telegram data): that the target is a protected
user (owner/admin/delegate/trusted/service account) or a member of the group, and the bot's rights.
"""
from __future__ import annotations

from datetime import datetime
from typing import Callable

from ..audit import (
    SANCTION_LIFTED,
    SANCTION_RECORDED,
    WARNING_ISSUED,
    WARNING_REVOKED,
    WARNINGS_CLEARED,
    SecurityAudit,
    make_event,
    record_safely,
    sanitize_text,
)
from ..errors import GroupNotRegistered, InvalidInput
from ..licensing.store import LicenseStore
from ..permissions import Permission, PermissionService
from ..time_utils import ensure_utc, utcnow
from .models import (
    MAX_REASON_LEN,
    ModerationWarning,
    Sanction,
    SanctionKind,
    check_expiry,
    check_group_id,
    check_key,
    check_user_id,
    check_warning_expiry,
)
from .store import SanctionStore, WarningStore

_AUDIT_REASON_LEN = 120


def clean_reason(reason: str | None) -> str | None:
    """Control chars/secrets stripped, whitespace collapsed, <= 500 chars; blank => None."""
    if reason is None:
        return None
    if not isinstance(reason, str):
        raise InvalidInput("reason must be text")
    return sanitize_text(reason, MAX_REASON_LEN)


def _audit_reason(reason: str | None) -> str:
    return f" reason={sanitize_text(reason, _AUDIT_REASON_LEN)}" if reason else ""


class _Base:
    def __init__(self, licenses: LicenseStore, permissions: PermissionService, audit: SecurityAudit | None,
                 clock: Callable[[], datetime]):
        self._licenses, self._perm, self._audit, self._clock = licenses, permissions, audit, clock

    async def _authorize(self, actor_id, group_id, context_chat_id) -> int:
        group_id = check_group_id(group_id)
        await self._perm.require(actor_id, group_id, Permission.MODERATE, context_chat_id=context_chat_id)
        if await self._licenses.get(group_id) is None:
            raise GroupNotRegistered("group is not registered")
        return group_id


class WarningService(_Base):
    def __init__(self, store: WarningStore, licenses: LicenseStore, permissions: PermissionService,
                 audit: SecurityAudit | None = None, *, clock: Callable[[], datetime] = utcnow):
        super().__init__(licenses, permissions, audit, clock)
        self._store = store

    async def warn(self, actor_id, group_id, user_id, reason: str | None = None, *,
                   expires_at: datetime | None = None, idempotency_key: str | None = None,
                   context_chat_id: int | None = None) -> tuple[ModerationWarning, int, bool]:
        """Returns (warning, active_count_after, created). A repeated idempotency key adds nothing."""
        group_id = await self._authorize(actor_id, group_id, context_chat_id)
        user_id = check_user_id(user_id)
        reason, key = clean_reason(reason), check_key(idempotency_key)
        now = self._clock()
        expires_at = check_warning_expiry(now, None if expires_at is None else ensure_utc(expires_at))
        warning, created = await self._store.add(group_id, user_id, actor_id, reason, now, expires_at, key)
        count = await self._store.count_active(group_id, user_id, now)
        if created:
            await record_safely(self._audit, make_event(
                WARNING_ISSUED, actor=actor_id, group_id=group_id, now=now,
                detail=f"user={user_id} active={count}{_audit_reason(reason)}"))
        return warning, count, created

    async def list_active(self, actor_id, group_id, user_id, *, context_chat_id=None) -> list[ModerationWarning]:
        group_id = await self._authorize(actor_id, group_id, context_chat_id)
        return await self._store.list_active(group_id, check_user_id(user_id), self._clock())

    async def count_active(self, actor_id, group_id, user_id, *, context_chat_id=None) -> int:
        group_id = await self._authorize(actor_id, group_id, context_chat_id)
        return await self._store.count_active(group_id, check_user_id(user_id), self._clock())

    async def clear(self, actor_id, group_id, user_id, *, context_chat_id=None) -> int:
        """Revoke all active warnings of the user (history is kept). Returns how many were cleared."""
        group_id = await self._authorize(actor_id, group_id, context_chat_id)
        user_id, now = check_user_id(user_id), self._clock()
        cleared = await self._store.revoke_all(group_id, user_id, actor_id, now)
        if cleared:
            await record_safely(self._audit, make_event(
                WARNINGS_CLEARED, actor=actor_id, group_id=group_id, now=now, detail=f"user={user_id} count={cleared}"))
        return cleared

    async def revoke(self, actor_id, group_id, warning_id, *, context_chat_id=None) -> bool:
        group_id = await self._authorize(actor_id, group_id, context_chat_id)
        if not isinstance(warning_id, int) or isinstance(warning_id, bool) or warning_id <= 0:
            raise InvalidInput("warning id must be a positive integer")
        now = self._clock()
        done = await self._store.revoke_one(group_id, warning_id, actor_id, now)
        if done:
            await record_safely(self._audit, make_event(
                WARNING_REVOKED, actor=actor_id, group_id=group_id, now=now, detail=f"warning={warning_id}"))
        return done


class SanctionService(_Base):
    def __init__(self, store: SanctionStore, licenses: LicenseStore, permissions: PermissionService,
                 audit: SecurityAudit | None = None, *, clock: Callable[[], datetime] = utcnow):
        super().__init__(licenses, permissions, audit, clock)
        self._store = store

    async def record(self, actor_id, group_id, user_id, kind: SanctionKind, *, reason: str | None = None,
                     expires_at: datetime | None = None, idempotency_key: str | None = None,
                     context_chat_id: int | None = None) -> tuple[Sanction, bool]:
        """Record a manual sanction AFTER the Telegram action succeeded (or in dry-run: never).
        Returns (sanction, created); a repeated key returns the existing row with created=False."""
        group_id = await self._authorize(actor_id, group_id, context_chat_id)
        user_id = check_user_id(user_id)
        if not isinstance(kind, SanctionKind):
            raise InvalidInput("unknown sanction kind")
        reason, key = clean_reason(reason), check_key(idempotency_key)
        now = self._clock()
        expires_at = check_expiry(kind, now, None if expires_at is None else ensure_utc(expires_at))
        sanction, created = await self._store.record(
            group_id, user_id, kind, actor_id, reason, now, expires_at, None, key)
        if created:
            until = expires_at.isoformat() if expires_at else "permanent"
            await record_safely(self._audit, make_event(
                SANCTION_RECORDED, actor=actor_id, group_id=group_id, now=now,
                detail=f"user={user_id} kind={kind.value} until={until}{_audit_reason(reason)}"))
        return sanction, created

    async def active(self, actor_id, group_id, user_id, *, kinds=None, context_chat_id=None) -> list[Sanction]:
        group_id = await self._authorize(actor_id, group_id, context_chat_id)
        return await self._store.get_active(group_id, check_user_id(user_id), self._clock(), kinds)

    async def lift(self, actor_id, group_id, user_id, kind: SanctionKind, *, context_chat_id=None) -> int:
        """Mark the user's active mute/ban lifted (after the Telegram unmute/unban). Returns how many."""
        group_id = await self._authorize(actor_id, group_id, context_chat_id)
        user_id = check_user_id(user_id)
        if kind not in (SanctionKind.MUTE, SanctionKind.BAN):
            raise InvalidInput("only a mute or a ban can be lifted")
        now = self._clock()
        lifted = await self._store.lift(group_id, user_id, kind, actor_id, now)
        if lifted:
            await record_safely(self._audit, make_event(
                SANCTION_LIFTED, actor=actor_id, group_id=group_id, now=now,
                detail=f"user={user_id} kind={kind.value} count={lifted}"))
        return lifted
