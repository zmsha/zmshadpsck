"""Arabic text folding shared by the command parsers (moved out of `commands.py`; `commands.fold_arabic` still works)."""
from __future__ import annotations

import re

from .duration import normalize

_DIACRITICS = re.compile("[ً-ٰٟـ]")
_FOLD = str.maketrans({"أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا", "ة": "ه", "ى": "ي"})


def fold_arabic(text: str) -> str:
    """Lowercase, ASCII digits, no bidi/zero-width marks, no diacritics/tatweel, alef/ta-marbuta/alef-maqsura folded."""
    return _DIACRITICS.sub("", normalize(text)).translate(_FOLD)
