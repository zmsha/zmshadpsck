"""`/trust`, `/untrust`, `/trusted` (Phase 4 / part 2): per-group trust lists for members, domains and bots.
Framework independent; reached from `ModerationCommandService._handle` AFTER the shared first two gates (MODERATE
permission, then the license gate).

What each entry bypasses is defined ONCE in `members/trust.py` (no blanket exemption) and repeated to the admin in every
answer that changes or lists a list, so nobody believes "trusted" means "unmoderated".

Reading (`/trusted`) needs only the two shared gates. Every WRITE then:
 1. parses strictly (`trust_args`; an unknown word is INVALID, nothing is guessed)
 2. requires `MANAGE_TRUST` for THIS chat (Telegram admins of the group, GROUP_MANAGER delegates, the owner; a MODERATOR
    delegate may list but not change) -> DENIED
 3. resolves the target: a member through the shared target resolver (reply / id / text_mention / visible @username;
    never the bot itself; a banned member cannot be newly trusted), a bot by numeric id or by replying to one of its
    messages (a bot's @username cannot be resolved by the Bot API)
 4. claims `operation_key("mod", cmd, chat, message_id)` (a redelivered update never writes/audits twice) -> DUPLICATE
 5. writes through the services (`TrustService`, `BotTrustService`, or, for domains, the SAME `links_allow_domains`
    list as `/protect allow` via `SettingsCommands.change_allow` which needs MANAGE_SETTINGS), serialised per group so
    the size caps hold under concurrency.
Trust commands are not punitive, so they also work while the group is in `dry_run`.

Known limit: a numeric id given to `/trust bot` is not verified to be a bot account (the Bot API member object that the
chat-info adapter keeps has no bot flag); replying to a bot's message is verified (`from_user.is_bot`).
"""
from __future__ import annotations

import html
import logging
import re
from typing import Any, Callable

from ..errors import InvalidInput
from ..i18n import t
from ..idempotency import IdempotencyStore, operation_key
from ..members import trust as rules
from ..permissions import Permission
from ..protection.settings import ProtectionSettings
from ..protection.tracking import KeyedLocks
from .commands import Command, CommandError, ParsedCommand
from .duration import normalize
from .messages import error_message
from .targets import ReplyInfo, TargetError, TargetInput, UsernameResolver, resolve_target
from .trust_args import TrustArgs, parse_trust_args

log = logging.getLogger(__name__)

LIST_LIMIT = 25  # entries shown per section of /trusted (the rest is summarised as "+N")
PANEL_LIST_LIMIT = 10  # the panel edits ONE message (4096-char limit): 10 x 253-char domains still fits
_NUMERIC = re.compile(r"^\d{1,19}$")


def _code(value: object) -> str:
    return f"<code>{html.escape(str(value), quote=False)}</code>"


class TrustCommands:
    def __init__(self, *, permissions: Any, trust: Any, bot_trust: Any, trust_store: Any, bot_trust_store: Any,
                 settings_commands: Any, chat_info: Any, claims: IdempotencyStore, bot_id: int,
                 usernames: UsernameResolver | None, load_settings: Callable[[int], Any],
                 make_result: Callable[..., Any], kinds: Any, load_raw: Callable[[int], Any] | None = None):
        self._load_raw = load_raw  # STRICT reader (raises on a store failure); only the panel view uses it
        self._perm, self._trust, self._bot_trust = permissions, trust, bot_trust
        self._trust_store, self._bot_store = trust_store, bot_trust_store
        self._settings_cmds, self._chat_info, self._claims = settings_commands, chat_info, claims
        self._bot_id, self._usernames = bot_id, usernames
        self._load_settings, self._result, self._kinds = load_settings, make_result, kinds
        self._locks = KeyedLocks()

    # ------------------------------------------------------------------ entry point
    async def handle(self, parsed: ParsedCommand, decision: Any, chat_id: int, actor_id: int, message_id: int,
                     reply: ReplyInfo | None, mention_user_id: int | None, lang: str):
        R, cmd = self._kinds, parsed.command
        try:
            plan = parse_trust_args(cmd.value, parsed.args, has_reply=reply is not None)
        except CommandError as exc:
            return self._result(R.INVALID, error_message(exc, lang) or t("invalid_input", lang), cmd)

        if cmd is Command.TRUSTED:  # read-only: no permission beyond MODERATE, no claim
            return await self._list(plan, chat_id, lang)

        await self._perm.require(actor_id, chat_id, Permission.MANAGE_TRUST, context_chat_id=chat_id)  # PermissionDenied
        add = cmd is Command.TRUST
        if plan.scope == "domain":
            if self._settings_cmds is None:
                return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
            return await self._settings_cmds.change_allow(
                "allow_add" if add else "allow_remove", plan.domains, cmd=cmd, decision=decision, chat_id=chat_id,
                actor_id=actor_id, message_id=message_id, lang=lang)

        service = self._trust if plan.scope == "user" else self._bot_trust
        if service is None:
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        try:
            subject = await self._resolve(plan, reply, mention_user_id, chat_id, actor_id, add)
        except (TargetError, CommandError) as exc:
            return self._result(R.INVALID, error_message(exc, lang) or t("invalid_input", lang), cmd)
        except InvalidInput:
            return self._result(R.INVALID, t("invalid_input", lang), cmd)

        try:
            claimed = await self._claims.claim(operation_key("mod", cmd.value, chat_id, message_id))
        except Exception:
            log.error("trust claim failed; nothing written", extra={"group_id": chat_id}, exc_info=True)
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        if not claimed:
            return self._result(R.DUPLICATE, "", cmd, subject)

        async with self._locks.hold(("trust", chat_id)):
            if plan.scope == "user":
                return await self._change_member(add, actor_id, chat_id, subject, cmd, lang)
            return await self._change_bot(add, actor_id, chat_id, subject, cmd, lang)

    # ------------------------------------------------------------------ resolution
    async def _resolve(self, plan: TrustArgs, reply: ReplyInfo | None, mention_user_id: int | None, chat_id: int,
                       actor_id: int, add: bool) -> int:
        if plan.scope == "bot":
            return self._resolve_bot(plan, reply)
        if reply is not None and reply.is_bot:
            raise CommandError("trust_use_bot")  # a bot account is trusted with `/trust bot`, never as a member
        target = await resolve_target(
            TargetInput(reply, plan.token, mention_user_id if plan.token else None), group_id=chat_id,
            actor_id=actor_id, bot_id=self._bot_id, permissions=self._perm, chat_info=self._chat_info,
            usernames=self._usernames, require_unprotected=False)
        if add and target.status == "kicked":
            raise CommandError("trust_banned")
        return target.user_id

    def _resolve_bot(self, plan: TrustArgs, reply: ReplyInfo | None) -> int:
        if reply is not None:
            if reply.sender_chat or reply.user_id is None or not reply.is_bot:
                raise CommandError("trust_not_bot")
            uid = reply.user_id
        else:
            token = normalize(plan.token)
            if not _NUMERIC.match(token):
                raise CommandError("trust_bot_id")  # usernames cannot be resolved by the Bot API
            uid = int(token)
        if not 0 < uid < 2**63:
            raise CommandError("trust_bot_id")
        if uid == self._bot_id:
            raise CommandError("trust_self_bot")
        return uid

    # ------------------------------------------------------------------ writes
    async def _change_member(self, add: bool, actor_id: int, chat_id: int, uid: int, cmd: Command, lang: str):
        R = self._kinds
        if add:
            current = await self._trust_store.list(chat_id)
            if any(row.user_id == uid for row in current):
                return self._result(R.NOOP, t("trust_user_exists", lang, id=uid), cmd, uid)
            if len(current) >= rules.MAX_TRUSTED_USERS:
                return self._result(R.INVALID, t("trust_full", lang, limit=rules.MAX_TRUSTED_USERS), cmd, uid)
            created = await self._trust.add(actor_id, chat_id, uid, None, context_chat_id=chat_id)
            if not created:
                return self._result(R.NOOP, t("trust_user_exists", lang, id=uid), cmd, uid)
            return self._result(R.DONE, t("trust_user_added", lang, id=uid) + "\n" + t("trust_user_rules", lang),
                                cmd, uid)
        removed = await self._trust.remove(actor_id, chat_id, uid, context_chat_id=chat_id)
        if not removed:
            return self._result(R.NOOP, t("trust_user_absent", lang, id=uid), cmd, uid)
        return self._result(R.DONE, t("trust_user_removed", lang, id=uid), cmd, uid)

    async def _change_bot(self, add: bool, actor_id: int, chat_id: int, bot_id: int, cmd: Command, lang: str):
        R = self._kinds
        if add:
            current = await self._bot_store.list(chat_id)
            if any(row.bot_id == bot_id for row in current):
                return self._result(R.NOOP, t("trust_bot_exists", lang, id=bot_id), cmd, bot_id)
            if len(current) >= rules.MAX_TRUSTED_BOTS:
                return self._result(R.INVALID, t("trust_full", lang, limit=rules.MAX_TRUSTED_BOTS), cmd, bot_id)
            created = await self._bot_trust.add(actor_id, chat_id, bot_id, None, context_chat_id=chat_id)
            if not created:
                return self._result(R.NOOP, t("trust_bot_exists", lang, id=bot_id), cmd, bot_id)
            return self._result(R.DONE, t("trust_bot_added", lang, id=bot_id) + "\n" + t("trust_bot_rules", lang),
                                cmd, bot_id)
        removed = await self._bot_trust.remove(actor_id, chat_id, bot_id, context_chat_id=chat_id)
        if not removed:
            return self._result(R.NOOP, t("trust_bot_absent", lang, id=bot_id), cmd, bot_id)
        return self._result(R.DONE, t("trust_bot_removed", lang, id=bot_id), cmd, bot_id)

    # ------------------------------------------------------------------ reads
    async def panel_view(self, chat_id: int, lang: str) -> str:
        """Text of the panel's read-only trust screen: the same lists as `/trusted` (shorter, to fit one message).
        Raises when a list is unreadable (the panel fails closed). No gate: the panel applied MODERATE + the license."""
        result = await self._list(TrustArgs("all"), chat_id, lang, limit=PANEL_LIST_LIMIT, strict=True)
        if getattr(getattr(result, "kind", None), "value", None) != "info" or not getattr(result, "text", ""):
            raise RuntimeError("trust lists unreadable")
        return result.text

    async def _list(self, plan: TrustArgs, chat_id: int, lang: str, *, limit: int = LIST_LIMIT, strict: bool = False):
        R, cmd = self._kinds, Command.TRUSTED
        want = {"all": ("users", "domains", "bots")}.get(plan.scope, (plan.scope,))
        try:
            parts = [t("trust_list_title", lang)]
            if "users" in want:
                rows = await self._trust_store.list(chat_id)
                parts.append(self._section("trust_users_head", [_code(r.user_id) for r in rows], lang, limit))
            if "domains" in want:
                if strict:  # the panel must not show an empty domain list because the store failed
                    if self._load_raw is None:
                        raise RuntimeError("strict settings reader not configured")
                    settings = ProtectionSettings.from_raw(await self._load_raw(chat_id))
                else:
                    settings = await self._load_settings(chat_id)
                parts.append(self._section(
                    "trust_domains_head", [html.escape(d, quote=False) for d in settings.links_allow_domains], lang, limit))
            if "bots" in want:
                rows = await self._bot_store.list(chat_id)
                parts.append(self._section("trust_bots_head", [_code(r.bot_id) for r in rows], lang, limit))
        except Exception:
            log.error("trust list unreadable", extra={"group_id": chat_id}, exc_info=True)
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        if plan.scope == "all":
            parts.append(t("trust_rules_note", lang))
        return self._result(R.INFO, "\n\n".join(parts), cmd)

    @staticmethod
    def _section(head_key: str, items: list[str], lang: str, limit: int = LIST_LIMIT) -> str:
        head = t(head_key, lang, count=len(items))
        if not items:
            return head + "\n" + t("trust_none", lang)
        shown = "\n".join(f"• {x}" for x in items[:limit])
        if len(items) > limit:
            shown += "\n" + t("trust_more", lang, n=len(items) - limit)
        return head + "\n" + shown
