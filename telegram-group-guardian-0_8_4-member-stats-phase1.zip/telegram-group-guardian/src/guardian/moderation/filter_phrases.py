"""Natural Arabic sentences for the content-filter settings (part 9.4). Pure text logic, no I/O.

They are shortcuts for `/protect adult ...` and `/protect filter ...` (the parser, the permission check and the audit are the
existing ones: this module only TRANSLATES a sentence into the `/protect` arguments):

    تفعيل الفلتر النصي | ايقاف الفلتر النصي            -> adult on|off
    اضافة كلمة W | حذف كلمة W                          -> adult add|remove W        (exactly one word)
    اضافة كلمات W1 W2 .. | حذف كلمات W1 W2 ..          -> adult add|remove W1 W2 .. (one or more words)
    قائمة الكلمات | مسح الكلمات                        -> adult list | clear        (the whole message only)
    تفعيل|تعطيل فلتر الذكاء الاصطناعي | فلتر ai         -> filter ai on|off
    تفعيل|تعطيل فلتر الايموجي | اللغات | الاسماء | الصور -> filter emoji|scripts|names|photos on|off

Ordinary chat must not become a command: the sentence must start with the verb and have EXACTLY the shape above (`اضافة كلمة`
takes one word; `حذف كلمة من الجملة` is not a command; `تفعيل الفلتر` alone is not one).
"""
from __future__ import annotations

from .arabic import fold_arabic

_DEFAULT_MARKERS = {fold_arabic(w) for w in ("افتراضية", "الافتراضية", "افتراضيه", "افتراضي", "الافتراضي", "افتراضيات", "الافتراضيات")}


def _f(text: str) -> tuple[str, ...]:
    return tuple(fold_arabic(text).split())


_ON = {fold_arabic(w) for w in ("تفعيل", "تشغيل", "فعل", "شغل")}
_OFF = {fold_arabic(w) for w in ("ايقاف", "إيقاف", "تعطيل", "اطفاء", "اطفاء", "وقف", "عطل", "الغاء")}
_ADD = {fold_arabic(w) for w in ("اضافة", "إضافة", "اضف", "أضف", "اضافه")}
_REMOVE = {fold_arabic(w) for w in ("حذف", "احذف", "ازالة", "إزالة", "ازل", "أزل", "مسح", "امسح")}
_ONE_WORD = fold_arabic("كلمة")
_MANY_WORDS = fold_arabic("كلمات")

_AI = ("الذكاء الاصطناعي", "الذكاء الصناعي", "الذكاء", "ai", "gemini", "جيميني", "جيمني")
# subject -> the `/protect` arguments that precede on|off
_SUBJECTS: dict[tuple[str, ...], tuple[str, ...]] = {}


def _subject(args: tuple[str, ...], *phrases: str) -> None:
    for phrase in phrases:
        _SUBJECTS[_f(phrase)] = args


_subject(("adult",), "الفلتر النصي", "فلتر نصي", "فلتر الكلمات", "الفلتر الاباحي", "فلتر الاباحي", "فلتر الكلمات الاباحية",
         "فلتر النصوص", "الفلتر النصوص")
for _prefix in ("فلتر", "الفلتر"):
    _subject(("filter", "ai"), *(f"{_prefix} {x}" for x in _AI))
    _subject(("filter", "emoji"), *(f"{_prefix} {x}" for x in ("الايموجي", "ايموجي", "الايموجيات", "الإيموجي", "الإيموجيات")))
    _subject(("filter", "scripts"), *(f"{_prefix} {x}" for x in ("اللغات", "لغات", "الكتابة", "انظمة الكتابة", "أنظمة الكتابة")))
    _subject(("filter", "names"), *(f"{_prefix} {x}" for x in ("الاسماء", "اسماء", "الأسماء", "أسماء")))
    _subject(("filter", "photos"), *(f"{_prefix} {x}" for x in ("الصور", "صور")))

_LIST = {_f(p) for p in ("قائمة الكلمات", "عرض الكلمات", "الكلمات الممنوعة", "الكلمات المحظورة")}
_CLEAR = {_f(p) for p in ("مسح الكلمات", "مسح كل الكلمات", "حذف الكلمات", "حذف كل الكلمات")}


def parse_filter_phrase(words: list[str] | tuple[str, ...]) -> tuple[str, ...] | None:
    """The `/protect` arguments for a whole-message Arabic sentence about the content filter, or None."""
    if not words or len(words) > 22:
        return None
    folded = tuple(fold_arabic(w) for w in words)
    if folded in _LIST:
        return ("adult", "list")
    if folded in _CLEAR:
        return ("adult", "clear")
    head = folded[0]
    if len(folded) >= 3 and folded[1] in (_ONE_WORD, _MANY_WORDS) and (head in _ADD or head in _REMOVE):
        rest = tuple(words[2:])
        if folded[2] in _DEFAULT_MARKERS:
            return None  # `اضافة كلمة افتراضية ...` is the OWNER's default-word command (part 9.5), never a group word
        if folded[1] == _ONE_WORD and len(rest) != 1:
            return None
        return ("adult", "add" if head in _ADD else "remove", *rest)
    if head in _ON or head in _OFF:
        args = _SUBJECTS.get(folded[1:])
        if args is not None:
            return (*args, "on" if head in _ON else "off")
    return None
