"""Strict argument parsers for the configuration commands `/lock /unlock /slowmode /antiflood /protect`
(Phase 3 closing part 3). Pure text logic: no Telegram, no permissions, no I/O.

Every parser either returns a typed, range-checked value or raises `CommandError` with a stable code (each has a
localized `mod_err_<code>` message). Nothing is ever guessed: an unknown word is an error, never ignored, because a
mis-parsed `/lock` or `/protect links off` changes how a whole group is protected.

Bounds come from `protection.settings` (the single source), so any value accepted here survives
`ProtectionSettings.from_raw` unchanged (a test asserts the parity).
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..protection.adult_words import normalize_word
from ..protection.links import normalize_domain
from ..protection.settings import (
    DEFAULT_ESCALATION,
    DUPLICATE_REPEATS,
    DUPLICATE_WINDOW,
    ESCALATION_WINDOW,
    FLOOD_MESSAGES,
    FLOOD_WINDOW,
    MAX_DOMAINS,
    MAX_MUTE,
    MIN_MUTE,
    SLOWMODE,
    WARN_ACTIONS,
    WARN_LIMIT,
)
from .arabic import fold_arabic
from .command_error import CommandError
from .duration import DurationError, is_permanent_word, normalize, parse_duration, parse_interval

MAX_WORDS = 20

# ----------------------------------------------------------------------------- /lock /unlock
# Telegram `ChatPermissions` flags the bot may change. NOT included on purpose: can_change_info, can_invite_users,
# can_pin_messages, can_manage_topics (opening those to every member through a chat command is too dangerous), and
# there is no "links" permission in Telegram at all (link blocking is `/protect links`).
FLAG_TEXT = ("can_send_messages",)
FLAG_MEDIA = ("can_send_photos", "can_send_videos", "can_send_audios", "can_send_documents",
              "can_send_video_notes", "can_send_voice_notes")
FLAG_STICKERS = ("can_send_other_messages",)  # stickers, GIFs, games, inline-bot results
FLAG_POLLS = ("can_send_polls",)
FLAG_PREVIEWS = ("can_add_web_page_previews",)
LOCK_TYPES: dict[str, tuple[str, ...]] = {
    "text": FLAG_TEXT, "media": FLAG_MEDIA, "stickers": FLAG_STICKERS, "polls": FLAG_POLLS, "previews": FLAG_PREVIEWS,
}
LOCK_TYPES["all"] = tuple(f for flags in list(LOCK_TYPES.values()) for f in flags)
LOCKABLE_FLAGS = frozenset(LOCK_TYPES["all"])

_TYPE_WORDS_RAW = {
    "all": ("all", "everything", "الكل", "كل", "الجميع"),
    "text": ("text", "messages", "chat", "الرسائل", "النص", "النصوص", "الكتابه", "الكتابة"),
    "media": ("media", "الوسائط", "الميديا", "ميديا", "وسائط"),
    "stickers": ("stickers", "sticker", "gifs", "gif", "الملصقات", "ملصقات", "الستيكرات", "الستيكر", "المتحركات"),
    "polls": ("polls", "poll", "الاستطلاعات", "استطلاعات", "الاستفتاءات", "التصويت"),
    "previews": ("previews", "preview", "المعاينه", "المعاينة", "المعاينات"),
}
_TYPE_WORDS = {fold_arabic(w): canon for canon, words in _TYPE_WORDS_RAW.items() for w in words}
_LINK_WORDS = frozenset(fold_arabic(w) for w in ("links", "link", "الروابط", "روابط", "رابط", "الرابط"))
MAX_LOCK_WORDS = 8


@dataclass(frozen=True, slots=True)
class LockArgs:
    types: tuple[str, ...]  # canonical names, de-duplicated, "all" absorbs the rest
    flags: tuple[str, ...]  # Telegram ChatPermissions flags, de-duplicated, in a stable order


def parse_lock_args(args: tuple[str, ...] | list[str]) -> LockArgs:
    """`/lock media polls`. A type is REQUIRED (a bare `/lock` never locks anything)."""
    words = list(args)
    if len(words) > MAX_LOCK_WORDS:
        raise CommandError("too_many_args")
    if not words:
        raise CommandError("lock_need_type")
    types: list[str] = []
    for w in words:
        f = fold_arabic(w)
        if f in _LINK_WORDS:
            raise CommandError("lock_links")
        canon = _TYPE_WORDS.get(f)
        if canon is None:
            raise CommandError("lock_unknown")
        if canon not in types:
            types.append(canon)
    if "all" in types:
        types = ["all"]
    flags: list[str] = []
    for ty in types:
        for fl in LOCK_TYPES[ty]:
            if fl not in flags:
                flags.append(fl)
    return LockArgs(tuple(types), tuple(flags))


# ----------------------------------------------------------------------------- shared small vocabularies
def _w(*words: str) -> frozenset[str]:
    return frozenset(fold_arabic(x) for x in words)


ON_WORDS = _w("on", "enable", "enabled", "yes", "true", "تشغيل", "تفعيل", "نعم", "مفعل", "تمكين")
OFF_WORDS = _w("off", "disable", "disabled", "no", "false", "ايقاف", "تعطيل", "لا", "متوقف", "الغاء", "اطفاء")
ALLOW_WORDS = _w("allow", "allowed", "سماح", "السماح", "مسموح", "اسمح")
BLOCK_WORDS = _w("block", "deny", "blocked", "منع", "ممنوع", "امنع")


def _bool_word(word: str, *, code: str, digits: bool = True) -> bool:
    f = fold_arabic(word)
    if f in ON_WORDS or (digits and f == "1"):
        return True
    if f in OFF_WORDS or (digits and f == "0"):
        return False
    raise CommandError(code)


def _is_number(word: str) -> bool:
    n = normalize(word)
    return n.isascii() and n.isdigit()


def _int_in(word: str, bounds: tuple[int, int], *, bad: str, range_: str) -> int:
    n = normalize(word)
    if not (n.isascii() and n.isdigit()):
        raise CommandError(bad)
    if len(n) > 6:
        raise CommandError(range_)
    value = int(n)
    if not bounds[0] <= value <= bounds[1]:
        raise CommandError(range_)
    return value


def _interval(word: str, bounds: tuple[int, int], *, bad: str, range_: str) -> int:
    try:
        return parse_interval(word, minimum=bounds[0], maximum=bounds[1])
    except DurationError as exc:
        raise CommandError(range_ if exc.code in ("too_short", "too_long", "zero") else bad) from None


# ----------------------------------------------------------------------------- /slowmode
@dataclass(frozen=True, slots=True)
class SlowmodeArgs:
    seconds: int | None  # None => just show the current value; 0 => off


def _slowmode_value(word: str) -> int:
    f = fold_arabic(word)
    if f in OFF_WORDS or f == "0":
        return 0
    return _interval(word, SLOWMODE, bad="slowmode_format", range_="slowmode_range")


def parse_slowmode_args(args: tuple[str, ...] | list[str]) -> SlowmodeArgs:
    """`/slowmode` (show) | `/slowmode off` | `/slowmode 30` | `/slowmode 30s` | `/slowmode 5m` (5 s .. 1 h)."""
    words = list(args)
    if not words:
        return SlowmodeArgs(None)
    if len(words) != 1:
        raise CommandError("slowmode_format")
    return SlowmodeArgs(_slowmode_value(words[0]))


# ----------------------------------------------------------------------------- /antiflood (and /protect flood|duplicates)
@dataclass(frozen=True, slots=True)
class ToggleArgs:
    patch: dict | None  # None => just show


def _toggle_or_numbers(words: list[str], *, enabled: str, count: str, window: str,
                       count_bounds: tuple[int, int], window_bounds: tuple[int, int], bad: str, range_: str) -> dict:
    """`on` | `off` | `N` | `N <window>` (a number also switches the feature on)."""
    if not words or len(words) > 2:
        raise CommandError(bad)
    first = fold_arabic(words[0])
    if len(words) == 1 and first in ON_WORDS:
        return {enabled: True}
    if len(words) == 1 and (first in OFF_WORDS or first == "0"):
        return {enabled: False}
    patch: dict = {enabled: True, count: _int_in(words[0], count_bounds, bad=bad, range_=range_)}
    if len(words) == 2:
        patch[window] = _interval(words[1], window_bounds, bad=bad, range_=range_)
    return patch


def _flood_patch(words: list[str], bad: str, range_: str) -> dict:
    return _toggle_or_numbers(words, enabled="flood_enabled", count="flood_max_messages", window="flood_window_seconds",
                              count_bounds=FLOOD_MESSAGES, window_bounds=FLOOD_WINDOW, bad=bad, range_=range_)


def _duplicates_patch(words: list[str], bad: str, range_: str) -> dict:
    return _toggle_or_numbers(words, enabled="duplicate_enabled", count="duplicate_max_repeats",
                              window="duplicate_window_seconds", count_bounds=DUPLICATE_REPEATS,
                              window_bounds=DUPLICATE_WINDOW, bad=bad, range_=range_)


def parse_antiflood_args(args: tuple[str, ...] | list[str]) -> ToggleArgs:
    """`/antiflood` (show) | `on` | `off` | `6` (messages) | `6 10` (messages per 10 s)."""
    words = list(args)
    if not words:
        return ToggleArgs(None)
    return ToggleArgs(_flood_patch(words, "antiflood_args", "antiflood_range"))


# ----------------------------------------------------------------------------- /protect
_SUB = {
    "show": _w("show", "status", "list", "عرض", "الحاله", "حاله"),
    "links": _w("links", "link", "الروابط", "روابط"),
    "invites": _w("invites", "invite", "الدعوات", "دعوات"),
    "filter": _w("filter", "content", "الفلتر", "فلتر", "المحتوى", "محتوى"),
    "adult": _w("adult", "porn", "nsfw", "الاباحي", "اباحي", "الاباحيه", "اباحيه", "الاباحيات", "اباحيات", "البورن", "بورن"),
    "allow": _w("allow", "allowlist", "whitelist", "سماح", "السماح", "النطاقات", "نطاقات"),
    "flood": _w("flood", "antiflood", "الفيضان", "فيضان"),
    "duplicates": _w("duplicates", "duplicate", "dups", "التكرار", "تكرار"),
    "slowmode": _w("slowmode", "slow", "بطيء", "بطئ", "البطيء"),
    "escalation": _w("escalation", "steps", "التصعيد", "تصعيد"),
    "window": _w("window", "النافذه", "نافذه"),
    "warnlimit": _w("warnlimit", "warns", "التحذيرات", "تحذيرات"),
    "warnaction": _w("warnaction", "اجراء"),
    "dryrun": _w("dryrun", "dry", "test", "التجربه", "تجربه"),
}
_PROTECT_SUBS = frozenset(w for words in _SUB.values() for w in words)
_ALLOW_LIST = _w("list", "show", "عرض", "قائمه")
_ALLOW_ADD = _w("add", "+", "اضافه", "اضف", "اضافة")
_ALLOW_REMOVE = _w("remove", "rm", "del", "delete", "-", "ازاله", "ازل", "حذف", "ازالة")
_ALLOW_CLEAR = _w("clear", "reset", "مسح", "تصفير")
_DEFAULT_WORDS = _w("default", "افتراضي", "الافتراضي")
_ACTION_WORDS = {fold_arabic("mute"): "mute", fold_arabic("كتم"): "mute", fold_arabic("kick"): "kick",
                 fold_arabic("طرد"): "kick", fold_arabic("ban"): "ban", fold_arabic("حظر"): "ban"}
assert set(_ACTION_WORDS.values()) == set(WARN_ACTIONS)


@dataclass(frozen=True, slots=True)
class ProtectArgs:
    op: str  # show | set | allow_list | allow_add | allow_remove | allow_clear
    patch: dict = field(default_factory=dict)
    domains: tuple[str, ...] = ()
    owner_only: bool = False  # `dryrun`: only the primary owner may change it
    topic: str | None = None  # for a read-only `show`: restrict the answer to one topic (`/slowmode`, `/antiflood`)
    words: tuple[str, ...] = ()  # `adult add|remove`: the normalised words (adult_words.normalize_word)
    ids: tuple[int, ...] = ()    # `filter exempt add|remove`: numeric Telegram user ids


def alias_args_ok(command: str, args: tuple[str, ...] | list[str]) -> bool:
    """May an ARABIC alias of this command be taken as intentional given the words after it? (Ordinary chat must not
    become a command: `قفل الباب` and `فتح الموضوع` are not; `قفل الوسائط` is.)"""
    words = [fold_arabic(a) for a in args]
    if command in ("lock", "unlock"):
        return 1 <= len(words) <= MAX_LOCK_WORDS and all(w in _TYPE_WORDS or w in _LINK_WORDS for w in words)
    if command == "slowmode":
        return not words or (len(words) == 1 and (words[0] in OFF_WORDS or words[0][:1].isdigit()))
    if command == "antiflood":
        return len(words) <= 2 and all(w in ON_WORDS or w in OFF_WORDS or w[:1].isdigit() for w in words)
    if command == "protect":
        return not words or words[0] in _PROTECT_SUBS
    return False


def _sub_of(word: str) -> str | None:
    f = fold_arabic(word)
    for name, words in _SUB.items():
        if f in words:
            return name
    return None


def _domains(words: list[str]) -> tuple[str, ...]:
    if not words:
        raise CommandError("protect_args")
    out: list[str] = []
    for w in words:
        d = normalize_domain(w)
        if d is None:
            raise CommandError("protect_domain")
        if d not in out:
            out.append(d)
    return tuple(out)


def _duration(word: str) -> int:
    try:
        return parse_duration(word)
    except DurationError as exc:
        raise CommandError("duration", exc.code) from None


def parse_protect_args(args: tuple[str, ...] | list[str]) -> ProtectArgs:
    """`/protect` | `show` | `links on|off` | `invites allow|block` | `allow list|add D..|remove D..|clear` |
    `flood on|off|N [S]` | `duplicates on|off|N [S]` | `slowmode off|S` | `escalation 10m 1h 1d|default` |
    `window 7d` | `warnlimit N` | `warnaction mute 1d|ban perm|kick` | `dryrun on|off` (owner only)."""
    words = list(args)
    if len(words) > MAX_WORDS:
        raise CommandError("too_many_args")
    if not words:
        return ProtectArgs("show")
    sub, rest = _sub_of(words[0]), words[1:]
    if sub is None:
        raise CommandError("protect_args")
    if sub == "show":
        if rest:
            raise CommandError("protect_args")
        return ProtectArgs("show")
    if sub == "allow":
        return _parse_allow(rest)
    if sub == "adult":
        return _parse_adult(rest)
    if sub == "filter":
        return _parse_filter(rest)
    if sub == "links":
        if len(rest) != 1:
            raise CommandError("protect_bool")
        return ProtectArgs("set", {"links_enabled": _bool_word(rest[0], code="protect_bool")})
    if sub == "invites":
        if len(rest) != 1:
            raise CommandError("protect_args")
        f = fold_arabic(rest[0])
        if f in ALLOW_WORDS:
            return ProtectArgs("set", {"links_allow_invites": True})
        if f in BLOCK_WORDS:
            return ProtectArgs("set", {"links_allow_invites": False})
        raise CommandError("protect_args")
    if sub == "flood":
        return ProtectArgs("set", _flood_patch(rest, "protect_args", "protect_range"))
    if sub == "duplicates":
        return ProtectArgs("set", _duplicates_patch(rest, "protect_args", "protect_range"))
    if sub == "slowmode":
        if len(rest) != 1:
            raise CommandError("protect_args")
        f = fold_arabic(rest[0])
        if f in OFF_WORDS or f == "0":
            return ProtectArgs("set", {"slowmode_seconds": 0})
        return ProtectArgs("set", {"slowmode_seconds": _interval(rest[0], SLOWMODE, bad="protect_args", range_="protect_range")})
    if sub == "escalation":
        return ProtectArgs("set", {"escalation_mutes_seconds": _parse_escalation(rest)})
    if sub == "window":
        if len(rest) != 1:
            raise CommandError("protect_args")
        seconds = _duration(rest[0])
        if not ESCALATION_WINDOW[0] <= seconds <= ESCALATION_WINDOW[1]:
            raise CommandError("protect_range")
        return ProtectArgs("set", {"escalation_window_seconds": seconds})
    if sub == "warnlimit":
        if len(rest) != 1:
            raise CommandError("protect_args")
        return ProtectArgs("set", {"warn_limit": _int_in(rest[0], WARN_LIMIT, bad="protect_args", range_="protect_range")})
    if sub == "warnaction":
        return ProtectArgs("set", _parse_warnaction(rest))
    # dryrun
    if len(rest) != 1:
        raise CommandError("protect_bool")
    return ProtectArgs("set", {"dry_run": _bool_word(rest[0], code="protect_bool")}, owner_only=True)


def _parse_allow(rest: list[str]) -> ProtectArgs:
    if not rest or (len(rest) == 1 and fold_arabic(rest[0]) in _ALLOW_LIST):
        return ProtectArgs("allow_list")
    op, tail = fold_arabic(rest[0]), rest[1:]
    if op in _ALLOW_ADD:
        return ProtectArgs("allow_add", domains=_domains(tail))
    if op in _ALLOW_REMOVE:
        return ProtectArgs("allow_remove", domains=_domains(tail))
    if op in _ALLOW_CLEAR and not tail:
        return ProtectArgs("allow_clear")
    raise CommandError("protect_args")


def _parse_adult(rest: list[str]) -> ProtectArgs:
    """`adult on|off` | `adult list` | `adult add W..` | `adult remove W..` | `adult clear` (the filter itself: protection/adult_words.py)."""
    if not rest:
        raise CommandError("protect_args")
    op, tail = fold_arabic(rest[0]), rest[1:]
    if len(rest) == 1 and op in _ALLOW_LIST:
        return ProtectArgs("adult_list")
    if len(rest) == 1 and op in _ALLOW_CLEAR:
        return ProtectArgs("adult_clear")
    if op in _ALLOW_ADD or op in _ALLOW_REMOVE:
        if not tail or len(tail) > 20:
            raise CommandError("protect_args")
        words: list[str] = []
        for w in tail:
            norm = normalize_word(w)
            if norm is None:
                raise CommandError("protect_adult_word")
            if norm not in words:
                words.append(norm)
        return ProtectArgs("adult_add" if op in _ALLOW_ADD else "adult_remove", words=tuple(words))
    if len(rest) == 1:
        return ProtectArgs("set", {"adult_enabled": _bool_word(rest[0], code="protect_bool")})
    raise CommandError("protect_args")


_FILTER_KEYS = {
    "ai": "cf_ai", "gemini": "cf_ai", "الذكاء": "cf_ai", "ذكاء": "cf_ai",
    "emoji": "cf_emoji", "emojis": "cf_emoji", "ايموجي": "cf_emoji", "الايموجي": "cf_emoji", "الايموجيات": "cf_emoji",
    "scripts": "cf_scripts", "script": "cf_scripts", "اللغات": "cf_scripts", "لغات": "cf_scripts", "الكتابه": "cf_scripts",
    "names": "cf_names", "name": "cf_names", "الاسماء": "cf_names", "اسماء": "cf_names",
    "photos": "cf_photos", "photo": "cf_photos", "الصور": "cf_photos", "صور": "cf_photos",
}


def _parse_filter(rest: list[str]) -> ProtectArgs:
    """`filter ai|emoji|scripts|names|photos on|off` | `filter exempt list|clear|add ID..|remove ID..`."""
    if not rest:
        raise CommandError("protect_args")
    head = fold_arabic(rest[0])
    if head in _FILTER_KEYS and len(rest) == 2:
        return ProtectArgs("set", {_FILTER_KEYS[head]: _bool_word(rest[1], code="protect_bool")})
    if head in ("exempt", "exempts", "استثناء", "استثناءات", "الاستثناءات", "استثناءات") or head.startswith("استثن"):
        if len(rest) == 2 and fold_arabic(rest[1]) in _ALLOW_LIST:
            return ProtectArgs("filter_exempt_list")
        if len(rest) == 2 and fold_arabic(rest[1]) in _ALLOW_CLEAR:
            return ProtectArgs("filter_exempt_clear")
        if len(rest) >= 3 and (fold_arabic(rest[1]) in _ALLOW_ADD or fold_arabic(rest[1]) in _ALLOW_REMOVE):
            if len(rest) > 22:
                raise CommandError("protect_args")
            ids: list[int] = []
            for raw in rest[2:]:
                value = normalize(raw)
                if not value.isdigit() or not 0 < int(value) < 2**63:
                    raise CommandError("protect_filter_id")
                if int(value) not in ids:
                    ids.append(int(value))
            return ProtectArgs("filter_exempt_add" if fold_arabic(rest[1]) in _ALLOW_ADD else "filter_exempt_remove",
                               ids=tuple(ids))
    raise CommandError("protect_args")


def _parse_escalation(rest: list[str]) -> list[int]:
    if not rest:
        raise CommandError("protect_args")
    if len(rest) == 1 and fold_arabic(rest[0]) in _DEFAULT_WORDS:
        return list(DEFAULT_ESCALATION)
    if len(rest) > 10:
        raise CommandError("protect_range")
    steps = []
    for w in rest:
        seconds = _duration(w)
        if not MIN_MUTE <= seconds <= MAX_MUTE:
            raise CommandError("protect_range")
        steps.append(seconds)
    return steps


def _parse_warnaction(rest: list[str]) -> dict:
    if not rest or len(rest) > 2:
        raise CommandError("protect_args")
    action = _ACTION_WORDS.get(fold_arabic(rest[0]))
    if action is None:
        raise CommandError("protect_args")
    if action == "kick":
        if len(rest) != 1:
            raise CommandError("protect_args")
        return {"warn_action": "kick"}
    if len(rest) != 2:  # mute/ban need an explicit duration or `perm` (never silently reuse an old value)
        raise CommandError("protect_args")
    seconds = 0 if is_permanent_word(rest[1]) else _duration(rest[1])
    return {"warn_action": action, "warn_action_seconds": seconds}


parse_domains = _domains  # public alias (used by `/trust domain`)
MAX_ALLOW_DOMAINS = MAX_DOMAINS
