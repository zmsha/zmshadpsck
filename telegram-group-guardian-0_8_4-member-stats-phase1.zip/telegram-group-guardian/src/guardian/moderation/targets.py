"""Moderation target resolution: reply, numeric user id, text-mention, or @username.

Framework-independent (duck-typed inputs, no aiogram). Fails closed: anything unclear is a
`TargetError` with a stable `code`; nothing is guessed.

Telegram limits (documented, not worked around):
  * A Bot API bot cannot turn an arbitrary @username into a user id. `UsernameResolver` is an
    injected lookup (e.g. users the bot has already seen in this group); without one, usernames
    are rejected as `username_unresolved`. `text_mention` entities and replies carry the id.
  * A reply to an anonymous-admin / channel post (`sender_chat`) has no user to sanction.

Checks (in order): id range -> not the actor (punitive only) -> not the bot -> member lookup
(`fresh=True`) -> not protected (punitive only: owner/backup/delegate/TG admin/service account;
uncertain => protected). The caller still owns permission checks, bot-rights checks and claims.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Protocol

from ..errors import InvalidInput
from .duration import normalize

# "@" is mandatory: a bare word is a reason, never a target.
_USERNAME = re.compile(r"^@([a-z][a-z0-9_]{4,31})$", re.IGNORECASE)
_NUMERIC = re.compile(r"^\d{1,19}$")


class TargetError(InvalidInput):
    """`code`: missing|ambiguous|format|invalid|unresolvable|username_unresolved|self|bot|lookup_failed|protected."""

    def __init__(self, code: str):
        self.code = code
        super().__init__(f"invalid target: {code}")


@dataclass(frozen=True, slots=True)
class ReplyInfo:
    user_id: int | None  # from_user.id of the replied-to message (None if absent)
    sender_chat: bool = False  # message posted on behalf of a chat/channel/anonymous admin
    message_id: int | None = None  # id of the replied-to message (used by /report for a link; never trusted for auth)
    is_bot: bool = False  # the replied-to message was sent by a bot account (`/trust` needs to tell users from bots)


@dataclass(frozen=True, slots=True)
class TargetInput:
    reply: ReplyInfo | None = None
    token: str | None = None
    mention_user_id: int | None = None  # id from a text_mention entity covering `token`


@dataclass(frozen=True, slots=True)
class Target:
    user_id: int
    via: str  # reply | mention | id | username
    status: str  # member status in the group: member|restricted|left|kicked|administrator|...


class UsernameResolver(Protocol):
    async def resolve(self, group_id: int, username: str) -> int | None: ...


def looks_like_target(token: object) -> bool:
    s = normalize(token)
    return bool(_NUMERIC.match(s) or _USERNAME.match(s))


def split_target_args(args: list[str], reply: ReplyInfo | None) -> tuple[str | None, list[str]]:
    """Return (target_token, remaining_args). With a reply the target comes from it, and a
    first argument that also looks like a target is ambiguous (never silently pick one)."""
    if reply is not None:
        if args and looks_like_target(args[0]):
            raise TargetError("ambiguous")
        return None, list(args)
    return (args[0] if args else None), list(args[1:])


async def resolve_target(
    inp: TargetInput, *, group_id: int, actor_id: int, bot_id: int, permissions: Any, chat_info: Any,
    usernames: UsernameResolver | None = None, require_unprotected: bool = True,
) -> Target:
    uid, via = await _extract(inp, group_id, usernames)
    if not isinstance(uid, int) or isinstance(uid, bool) or not 0 < uid < 2**63:
        raise TargetError("invalid")
    if uid == bot_id:
        raise TargetError("bot")
    if require_unprotected and uid == actor_id:
        raise TargetError("self")
    try:
        info = await chat_info.get_member(group_id, uid, fresh=True)
    except Exception:
        raise TargetError("lookup_failed") from None
    if require_unprotected and await permissions.is_protected(uid, group_id):
        raise TargetError("protected")
    return Target(uid, via, getattr(info, "status", "unknown"))


async def _extract(inp: TargetInput, group_id: int, usernames: UsernameResolver | None) -> tuple[int, str]:
    """reply -> text mention -> numeric id -> @username => (user id, how). No membership lookup, no protection check."""
    if inp.reply is not None:
        if inp.reply.sender_chat or inp.reply.user_id is None:
            raise TargetError("unresolvable")
        return inp.reply.user_id, "reply"
    if inp.mention_user_id is not None:
        return inp.mention_user_id, "mention"
    s = normalize(inp.token)
    if not s:
        raise TargetError("missing")
    if _NUMERIC.match(s):
        return int(s), "id"
    m = _USERNAME.match(s)
    if not m:
        raise TargetError("format")
    if usernames is None:
        raise TargetError("username_unresolved")
    try:
        found = await usernames.resolve(group_id, m.group(1).lower())
    except Exception:
        raise TargetError("username_unresolved") from None
    if not isinstance(found, int) or isinstance(found, bool) or found <= 0:  # chats/None are not users
        raise TargetError("username_unresolved")
    return found, "username"


extract_target_id = _extract  # public name for read-only callers (member statistics): they must NOT require current membership
