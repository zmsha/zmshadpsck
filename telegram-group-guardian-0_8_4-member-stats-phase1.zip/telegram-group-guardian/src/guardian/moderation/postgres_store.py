"""PostgreSQL stores for warnings and sanctions (NOT executed against a real PostgreSQL in the build
sandbox). Every statement filters by group_id (or inserts it as $1); foreign keys reject unknown groups.
Idempotency: a unique key makes a redelivered operation return the existing row instead of a second one."""
from __future__ import annotations

from datetime import datetime
from typing import Sequence

from ..errors import InvalidInput
from .models import RESTRICTING_KINDS, ModerationWarning, Sanction, SanctionKind

_WARN_COLS = "id, group_id, user_id, issued_by, reason, created_at, expires_at, revoked_at, revoked_by, idempotency_key"
_SANC_COLS = ("id, group_id, user_id, kind, issued_by, reason, created_at, expires_at, lifted_at, lifted_by, "
              "violation, idempotency_key")


def _warning(r) -> ModerationWarning:
    return ModerationWarning(
        id=r["id"], group_id=r["group_id"], user_id=r["user_id"], issued_by=r["issued_by"], reason=r["reason"],
        created_at=r["created_at"], expires_at=r["expires_at"], revoked_at=r["revoked_at"],
        revoked_by=r["revoked_by"], idempotency_key=r["idempotency_key"])


def _sanction(r) -> Sanction:
    return Sanction(
        id=r["id"], group_id=r["group_id"], user_id=r["user_id"], kind=SanctionKind(r["kind"]),
        issued_by=r["issued_by"], reason=r["reason"], created_at=r["created_at"], expires_at=r["expires_at"],
        lifted_at=r["lifted_at"], lifted_by=r["lifted_by"], violation=r["violation"],
        idempotency_key=r["idempotency_key"])


def _affected(status) -> int:
    """asyncpg returns e.g. 'UPDATE 3'."""
    try:
        return int(str(status).split()[-1])
    except (ValueError, IndexError):
        return 0


class PostgresWarningStore:
    def __init__(self, database) -> None:
        self._db = database

    async def add(self, group_id, user_id, issued_by, reason, now, expires_at=None, idempotency_key=None):
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "INSERT INTO moderation_warnings "
                "(group_id, user_id, issued_by, reason, created_at, expires_at, idempotency_key) "
                "VALUES ($1, $2, $3, $4, $5, $6, $7) "
                "ON CONFLICT (group_id, idempotency_key) WHERE idempotency_key IS NOT NULL DO NOTHING "
                f"RETURNING {_WARN_COLS}",
                group_id, user_id, issued_by, reason, now, expires_at, idempotency_key)
            if row is not None:
                return _warning(row), True
            existing = await conn.fetchrow(
                f"SELECT {_WARN_COLS} FROM moderation_warnings WHERE group_id = $1 AND idempotency_key = $2",
                group_id, idempotency_key)
        if existing is None:  # pragma: no cover - conflict implies the row exists
            raise InvalidInput("warning could not be recorded")
        return _warning(existing), False

    async def list_active(self, group_id, user_id, now):
        async with self._db.acquire() as conn:
            rows = await conn.fetch(
                f"SELECT {_WARN_COLS} FROM moderation_warnings WHERE group_id = $1 AND user_id = $2 "
                "AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at > $3) ORDER BY created_at, id",
                group_id, user_id, now)
        return [_warning(r) for r in rows]

    async def count_active(self, group_id, user_id, now) -> int:
        async with self._db.acquire() as conn:
            value = await conn.fetchval(
                "SELECT count(*) FROM moderation_warnings WHERE group_id = $1 AND user_id = $2 "
                "AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at > $3)",
                group_id, user_id, now)
        return int(value or 0)

    async def revoke_all(self, group_id, user_id, revoked_by, now) -> int:
        async with self._db.acquire() as conn:
            status = await conn.execute(
                "UPDATE moderation_warnings SET revoked_at = $3, revoked_by = $4 WHERE group_id = $1 "
                "AND user_id = $2 AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at > $3)",
                group_id, user_id, now, revoked_by)
        return _affected(status)

    async def revoke_one(self, group_id, warning_id, revoked_by, now) -> bool:
        async with self._db.acquire() as conn:
            status = await conn.execute(
                "UPDATE moderation_warnings SET revoked_at = $3, revoked_by = $4 WHERE group_id = $1 "
                "AND id = $2 AND revoked_at IS NULL",
                group_id, warning_id, now, revoked_by)
        return _affected(status) == 1

    async def count_in_range(self, group_id, start, end) -> dict[str, int]:
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT count(*) FILTER (WHERE issued_by IS NULL AND created_at >= $2 AND created_at < $3) AS issued_auto, "
                "count(*) FILTER (WHERE issued_by IS NOT NULL AND created_at >= $2 AND created_at < $3) AS issued_manual, "
                "count(*) FILTER (WHERE revoked_at >= $2 AND revoked_at < $3) AS revoked "
                "FROM moderation_warnings WHERE group_id = $1 "
                "AND ((created_at >= $2 AND created_at < $3) OR (revoked_at >= $2 AND revoked_at < $3))",
                group_id, start, end)
        if row is None:
            return {"issued_auto": 0, "issued_manual": 0, "revoked": 0}
        return {k: int(row[k] or 0) for k in ("issued_auto", "issued_manual", "revoked")}


class PostgresSanctionStore:
    def __init__(self, database) -> None:
        self._db = database

    async def record(self, group_id, user_id, kind, issued_by, reason, now, expires_at=None, violation=None,
                     idempotency_key=None):
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "INSERT INTO moderation_sanctions "
                "(group_id, user_id, kind, issued_by, reason, created_at, expires_at, violation, idempotency_key) "
                "VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) "
                f"ON CONFLICT (idempotency_key) DO NOTHING RETURNING {_SANC_COLS}",
                group_id, user_id, kind.value, issued_by, reason, now, expires_at, violation, idempotency_key)
            if row is not None:
                return _sanction(row), True
            existing = await conn.fetchrow(
                f"SELECT {_SANC_COLS} FROM moderation_sanctions WHERE group_id = $1 AND idempotency_key = $2",
                group_id, idempotency_key)
        if existing is None:  # the key belongs to ANOTHER group: never reveal or reuse that row
            raise InvalidInput("idempotency key already used")
        return _sanction(existing), False

    async def get_active(self, group_id, user_id, now, kinds: Sequence[SanctionKind] | None = None):
        wanted = [k.value for k in (kinds if kinds is not None else RESTRICTING_KINDS)]
        async with self._db.acquire() as conn:
            rows = await conn.fetch(
                f"SELECT {_SANC_COLS} FROM moderation_sanctions WHERE group_id = $1 AND user_id = $2 "
                "AND kind = ANY($3::text[]) AND kind <> 'kick' AND lifted_at IS NULL "
                "AND (expires_at IS NULL OR expires_at > $4) ORDER BY created_at, id",
                group_id, user_id, wanted, now)
        return [_sanction(r) for r in rows]

    async def lift(self, group_id, user_id, kind, lifted_by, now) -> int:
        async with self._db.acquire() as conn:
            status = await conn.execute(
                "UPDATE moderation_sanctions SET lifted_at = $4, lifted_by = $5 WHERE group_id = $1 "
                "AND user_id = $2 AND kind = $3 AND kind <> 'kick' AND lifted_at IS NULL "
                "AND (expires_at IS NULL OR expires_at > $4)",
                group_id, user_id, kind.value, now, lifted_by)
        return _affected(status)

    async def count_auto_mutes(self, group_id, user_id, since) -> int:
        async with self._db.acquire() as conn:
            value = await conn.fetchval(
                "SELECT count(*) FROM moderation_sanctions WHERE group_id = $1 AND user_id = $2 "
                "AND kind = 'mute' AND issued_by IS NULL AND created_at > $3",
                group_id, user_id, since)
        return int(value or 0)

    async def count_in_range(self, group_id, start, end) -> dict[str, int]:
        async with self._db.acquire() as conn:
            rows = await conn.fetch(
                "SELECT kind, (issued_by IS NULL) AS automatic, count(*) AS n FROM moderation_sanctions "
                "WHERE group_id = $1 AND created_at >= $2 AND created_at < $3 GROUP BY kind, (issued_by IS NULL)",
                group_id, start, end)
            lifted = await conn.fetchval(
                "SELECT count(*) FROM moderation_sanctions WHERE group_id = $1 AND lifted_at >= $2 AND lifted_at < $3",
                group_id, start, end)
        out = {f"{r['kind']}_{'auto' if r['automatic'] else 'manual'}": int(r["n"] or 0) for r in rows}
        out["lifted"] = int(lifted or 0)
        return out
