"""Strict argument parsers for `/welcome`, `/verify` and `/newbie` (Phase 4 / part 4.6). Pure text logic: no Telegram,
no permissions, no I/O.

Every parser returns a typed, range-checked `MemberArgs` or raises `CommandError` with a stable code (each has a
localized `mod_err_<code>` message). Nothing is guessed: an unknown word is an error, never ignored, because a
mis-parsed `/verify` or `/newbie` changes how every new member of a whole group is treated.

Bounds come from `members.settings` (the single source), so any value accepted here survives `from_raw` unchanged
(a test asserts the parity).

    /welcome                                 show (also: show | vars)
    /welcome on|off                          enable / disable the welcome message
    /welcome set <text>                      custom text (variables {name} {group} {id}; the raw text is used, so
                                             spaces and new lines are kept)
    /welcome reset                           back to the built-in text
    /welcome delete <10s..24h>|off           auto-delete the welcome after that time (off = keep)
    /welcome previous on|off                 delete the previous welcome when a new one is sent
    /welcome join|leave keep|delete          what to do with Telegram's own "joined"/"left" service message

    /verify                                  show
    /verify on|off
    /verify scope all|suspicious
    /verify method button|math|choice|admin
    /verify timeout <1m..24h>
    /verify failure restrict|kick|ban [<1m..7d>]
    /verify attempts <1..10>

    /newbie                                  show
    /newbie off | <1m..30d>                  length of the new-member restriction window
    /newbie links|media|messages on|off      what a new member may not send during the window
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..members.settings import (
    SERVICE_MODES,
    TEMPLATE_MAX_CHARS,
    VERIFY_ATTEMPTS,
    VERIFY_BAN,
    VERIFY_FAILURES,
    VERIFY_METHODS,
    VERIFY_SCOPES,
    VERIFY_TIMEOUT,
    WELCOME_DELETE_AFTER,
    NEWBIE_WINDOW,
    template_ok,
)
from .arabic import fold_arabic
from .command_error import CommandError
from .config_args import OFF_WORDS, ON_WORDS
from .duration import DurationError, normalize, parse_interval

MAX_WORDS = 20


def _w(*words: str) -> frozenset[str]:
    return frozenset(fold_arabic(x) for x in words)


@dataclass(frozen=True, slots=True)
class MemberArgs:
    op: str  # show | vars | set
    patch: dict = field(default_factory=dict)
    topic: str | None = None  # welcome | verify | newbie (for the answer after a write)


# ----------------------------------------------------------------------------- shared helpers
def _toggle(word: str, code: str) -> bool:
    f = fold_arabic(word)
    if f in ON_WORDS:
        return True
    if f in OFF_WORDS:
        return False
    raise CommandError(code)


def _is_off(word: str) -> bool:
    f = fold_arabic(word)
    return f in OFF_WORDS or f == "0"


def _span(word: str, bounds: tuple[int, int], *, bad: str, range_: str) -> int:
    try:
        return parse_interval(word, minimum=bounds[0], maximum=bounds[1])
    except DurationError as exc:
        raise CommandError(range_ if exc.code in ("too_short", "too_long", "zero") else bad) from None


def _choice(word: str, table: dict[str, str], code: str) -> str:
    value = table.get(fold_arabic(word))
    if value is None:
        raise CommandError(code)
    return value


def _table(canon_words: dict[str, tuple[str, ...]]) -> dict[str, str]:
    return {fold_arabic(w): canon for canon, words in canon_words.items() for w in words}


def _check_count(words: list[str]) -> None:
    if len(words) > MAX_WORDS:
        raise CommandError("too_many_args")


# ----------------------------------------------------------------------------- /welcome
_WELCOME_SUB = _table({
    "show": ("show", "status", "list", "عرض", "الحاله", "حاله"),
    "vars": ("vars", "variables", "المتغيرات", "متغيرات"),
    "set": ("set", "text", "تعيين", "ضبط", "نص", "غير"),
    "reset": ("reset", "default", "افتراضي", "الافتراضي", "اعاده", "استعاده"),
    "delete": ("delete", "autodelete", "حذف", "مدة"),
    "previous": ("previous", "prev", "السابق", "السابقه", "سابق"),
    "join": ("join", "joined", "الانضمام", "انضمام", "دخول"),
    "leave": ("leave", "left", "المغادره", "مغادره", "الخروج", "خروج"),
    "on": tuple(ON_WORDS),
    "off": tuple(OFF_WORDS),
})
_SERVICE_WORDS = _table({"keep": ("keep", "ابقاء", "ابقي", "احتفاظ", "اترك"), "delete": ("delete", "حذف", "امسح", "ازاله")})
WELCOME_SUBS = frozenset(_WELCOME_SUB)


def parse_welcome_args(args: tuple[str, ...] | list[str], raw: str = "") -> MemberArgs:
    """`raw` = the text after the command word(s), untouched (needed by `set`; `args` is whitespace-split and capped)."""
    words = list(args)
    if not words:
        return MemberArgs("show", topic="welcome")
    sub, rest = _WELCOME_SUB.get(fold_arabic(words[0])), words[1:]
    if sub is None:
        raise CommandError("welcome_args")
    if sub == "set":
        return MemberArgs("set", {"welcome_text": _template_from(raw)}, topic="welcome")
    _check_count(words)
    if sub in ("show", "vars"):
        if rest:
            raise CommandError("welcome_args")
        return MemberArgs(sub, topic="welcome")
    if sub in ("on", "off"):
        if rest:
            raise CommandError("welcome_args")
        return MemberArgs("set", {"welcome_enabled": sub == "on"}, topic="welcome")
    if sub == "reset":
        if rest:
            raise CommandError("welcome_args")
        return MemberArgs("set", {"welcome_text": None}, topic="welcome")
    if len(rest) != 1:
        raise CommandError("welcome_args")
    if sub == "delete":
        seconds = 0 if _is_off(rest[0]) else _span(rest[0], WELCOME_DELETE_AFTER, bad="welcome_args", range_="welcome_range")
        return MemberArgs("set", {"welcome_delete_after_seconds": seconds}, topic="welcome")
    if sub == "previous":
        return MemberArgs("set", {"welcome_delete_previous": _toggle(rest[0], "welcome_args")}, topic="welcome")
    mode = _choice(rest[0], _SERVICE_WORDS, "welcome_args")
    assert mode in SERVICE_MODES
    return MemberArgs("set", {"join_service" if sub == "join" else "leave_service": mode}, topic="welcome")


def _template_from(raw: str) -> str:
    """The text after the `set` word, exactly as typed (inner spaces/new lines kept, outer whitespace trimmed)."""
    parts = raw.lstrip().split(None, 1) if isinstance(raw, str) else []
    if len(parts) < 2 or not parts[1].strip():
        raise CommandError("welcome_need_text")
    text = parts[1].strip()
    if len(text) > TEMPLATE_MAX_CHARS or not template_ok(text):
        raise CommandError("welcome_bad_template")
    return text


# ----------------------------------------------------------------------------- /verify
_VERIFY_SUB = _table({
    "show": ("show", "status", "list", "عرض", "الحاله", "حاله"),
    "on": tuple(ON_WORDS),
    "off": tuple(OFF_WORDS),
    "scope": ("scope", "who", "النطاق", "نطاق", "الفئه"),
    "method": ("method", "type", "الطريقه", "طريقه", "النوع"),
    "timeout": ("timeout", "time", "المهله", "مهله", "الوقت"),
    "failure": ("failure", "fail", "onfail", "الفشل", "فشل", "العقوبه"),
    "attempts": ("attempts", "tries", "المحاولات", "محاولات"),
})
_SCOPE_WORDS = _table({
    "all": ("all", "everyone", "الكل", "الجميع", "للجميع", "كل"),
    "suspicious": ("suspicious", "suspect", "المشبوهين", "مشبوهين", "للمشبوهين", "المشبوه"),
})
_METHOD_WORDS = _table({
    "button": ("button", "click", "زر", "الزر"),
    "math": ("math", "arithmetic", "حساب", "الحساب", "رياضيات", "سؤال"),
    "choice": ("choice", "symbol", "emoji", "اختيار", "الاختيار", "رمز", "الرمز"),
    "admin": ("admin", "approval", "مشرف", "المشرف", "موافقه", "موافقة"),
})
_FAILURE_WORDS = _table({
    "restrict": ("restrict", "mute", "keep", "تقييد", "كتم", "ابقاء"),
    "kick": ("kick", "remove", "طرد"),
    "ban": ("ban", "حظر"),
})
VERIFY_SUBS = frozenset(_VERIFY_SUB)


def parse_verify_args(args: tuple[str, ...] | list[str]) -> MemberArgs:
    words = list(args)
    _check_count(words)
    if not words:
        return MemberArgs("show", topic="verify")
    sub, rest = _VERIFY_SUB.get(fold_arabic(words[0])), words[1:]
    if sub is None:
        raise CommandError("verify_args")
    if sub == "show":
        if rest:
            raise CommandError("verify_args")
        return MemberArgs("show", topic="verify")
    if sub in ("on", "off"):
        if rest:
            raise CommandError("verify_args")
        return MemberArgs("set", {"verify_enabled": sub == "on"}, topic="verify")
    if sub == "failure":
        return MemberArgs("set", _failure_patch(rest), topic="verify")
    if len(rest) != 1:
        raise CommandError("verify_args")
    word = rest[0]
    if sub == "scope":
        scope = _choice(word, _SCOPE_WORDS, "verify_args")
        assert scope in VERIFY_SCOPES
        return MemberArgs("set", {"verify_scope": scope}, topic="verify")
    if sub == "method":
        method = _choice(word, _METHOD_WORDS, "verify_args")
        assert method in VERIFY_METHODS
        return MemberArgs("set", {"verify_method": method}, topic="verify")
    if sub == "timeout":
        return MemberArgs("set", {"verify_timeout_seconds": _span(word, VERIFY_TIMEOUT, bad="verify_args", range_="verify_range")},
                          topic="verify")
    # attempts
    n = normalize(word)
    if not (n.isascii() and n.isdigit()):
        raise CommandError("verify_args")
    if len(n) > 3 or not VERIFY_ATTEMPTS[0] <= int(n) <= VERIFY_ATTEMPTS[1]:
        raise CommandError("verify_range")
    return MemberArgs("set", {"verify_max_attempts": int(n)}, topic="verify")


def _failure_patch(rest: list[str]) -> dict:
    if not rest or len(rest) > 2:
        raise CommandError("verify_args")
    action = _choice(rest[0], _FAILURE_WORDS, "verify_args")
    assert action in VERIFY_FAILURES
    if action != "ban":
        if len(rest) != 1:
            raise CommandError("verify_args")  # a duration only makes sense for a ban
        return {"verify_failure": action}
    patch: dict = {"verify_failure": "ban"}
    if len(rest) == 2:  # `ban` alone keeps the current ban length; `ban 1h` sets it
        patch["verify_ban_seconds"] = _span(rest[1], VERIFY_BAN, bad="verify_args", range_="verify_range")
    return patch


# ----------------------------------------------------------------------------- /newbie
_NEWBIE_SUB = _table({
    "show": ("show", "status", "list", "عرض", "الحاله", "حاله"),
    "off": tuple(OFF_WORDS),
    "links": ("links", "link", "الروابط", "روابط"),
    "media": ("media", "الوسائط", "الميديا", "ميديا", "وسائط"),
    "messages": ("messages", "text", "الرسائل", "رسائل", "الكتابه", "كتابه"),
})
NEWBIE_SUBS = frozenset(_NEWBIE_SUB)
_NEWBIE_FLAG = {"links": "newbie_block_links", "media": "newbie_block_media", "messages": "newbie_block_messages"}


def parse_newbie_args(args: tuple[str, ...] | list[str]) -> MemberArgs:
    words = list(args)
    _check_count(words)
    if not words:
        return MemberArgs("show", topic="newbie")
    sub = _NEWBIE_SUB.get(fold_arabic(words[0]))
    if sub is None:  # the only other valid first word is a duration
        if len(words) != 1:
            raise CommandError("newbie_args")
        seconds = _span(words[0], NEWBIE_WINDOW, bad="newbie_args", range_="newbie_range")
        return MemberArgs("set", {"newbie_seconds": seconds}, topic="newbie")
    rest = words[1:]
    if sub == "show":
        if rest:
            raise CommandError("newbie_args")
        return MemberArgs("show", topic="newbie")
    if sub == "off":
        if rest:
            raise CommandError("newbie_args")
        return MemberArgs("set", {"newbie_seconds": 0}, topic="newbie")
    if len(rest) != 1:
        raise CommandError("newbie_args")
    return MemberArgs("set", {_NEWBIE_FLAG[sub]: _toggle(rest[0], "newbie_args")}, topic="newbie")


# ----------------------------------------------------------------------------- Arabic alias gate
def alias_args_ok(command: str, args: tuple[str, ...] | list[str]) -> bool:
    """May an ARABIC alias of this command be taken as intentional given the words after it? Only when the first word
    is the command's own vocabulary (a bare alias such as `التحقق` is ordinary chat; the English slash form shows the
    settings)."""
    words = [fold_arabic(a) for a in args]
    if not words:
        return False
    if command == "welcome":
        return words[0] in WELCOME_SUBS
    if command == "verify":
        return words[0] in VERIFY_SUBS
    if command == "newbie":
        return words[0] in NEWBIE_SUBS or words[0][:1].isdigit()
    return False


__all__ = ["MemberArgs", "parse_welcome_args", "parse_verify_args", "parse_newbie_args", "alias_args_ok",
           "WELCOME_SUBS", "VERIFY_SUBS", "NEWBIE_SUBS"]
