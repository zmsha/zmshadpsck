"""In-memory implementations (tests / local experiments only; state is lost on restart)."""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime

from ..time_utils import ensure_utc
from .models import Challenge, ChallengeKind, ChallengeStatus, FailureAction, TrustedBot


class InMemoryChallengeStore:
    def __init__(self) -> None:
        self._rows: dict[int, Challenge] = {}
        self._next = 1

    def _find(self, group_id: int, challenge_id: int) -> Challenge | None:
        row = self._rows.get(challenge_id)
        return row if row is not None and row.group_id == group_id else None

    async def create(self, group_id, user_id, kind, answer, failure_action, ban_seconds, now, expires_at, idempotency_key):
        now, expires_at = ensure_utc(now), ensure_utc(expires_at)
        if expires_at <= now:
            raise ValueError("expires_at must be after now")
        for row in self._rows.values():
            if row.group_id == group_id and row.idempotency_key == idempotency_key:
                return row, False
        pending = await self.get_pending(group_id, user_id)
        if pending is not None:
            return pending, False
        row = Challenge(
            id=self._next, group_id=group_id, user_id=user_id, kind=ChallengeKind(kind), status=ChallengeStatus.PENDING,
            failure_action=FailureAction(failure_action), created_at=now, expires_at=expires_at,
            idempotency_key=idempotency_key, answer=answer,
            ban_seconds=ban_seconds if FailureAction(failure_action) is FailureAction.BAN else None,
        )
        self._rows[self._next] = row
        self._next += 1
        return row, True

    async def get(self, group_id, challenge_id):
        return self._find(group_id, challenge_id)

    async def get_pending(self, group_id, user_id):
        for row in self._rows.values():
            if row.group_id == group_id and row.user_id == user_id and row.is_pending:
                return row
        return None

    async def set_prompt_message(self, group_id, challenge_id, message_id) -> bool:
        row = self._find(group_id, challenge_id)
        if row is None or not row.is_pending or message_id <= 0:
            return False
        self._rows[challenge_id] = replace(row, prompt_message_id=message_id)
        return True

    async def record_attempt(self, group_id, challenge_id):
        row = self._find(group_id, challenge_id)
        if row is None or not row.is_pending:
            return None
        self._rows[challenge_id] = replace(row, attempts=row.attempts + 1)
        return row.attempts + 1

    async def resolve(self, group_id, challenge_id, status, now, resolved_by=None):
        status = ChallengeStatus(status)
        if status is ChallengeStatus.PENDING:
            raise ValueError("cannot resolve to pending")
        row = self._find(group_id, challenge_id)
        if row is None or not row.is_pending:
            return None
        done = replace(row, status=status, resolved_at=ensure_utc(now), resolved_by=resolved_by)
        self._rows[challenge_id] = done
        return done

    async def recent_unsuccessful(self, group_id, user_id, since) -> int:
        since = ensure_utc(since)
        bad = (ChallengeStatus.FAILED, ChallengeStatus.EXPIRED, ChallengeStatus.REJECTED)
        return sum(1 for r in self._rows.values() if r.group_id == group_id and r.user_id == user_id
                   and r.status in bad and r.resolved_at is not None and r.resolved_at >= since)

    async def list_pending(self, group_id):
        return sorted((r for r in self._rows.values() if r.group_id == group_id and r.is_pending),
                      key=lambda r: r.expires_at)

    async def list_due(self, now, limit):
        due = sorted((r for r in self._rows.values() if r.is_due(now)), key=lambda r: (r.expires_at, r.id))
        return due[: max(limit, 0)]

    async def purge_resolved(self, before) -> int:
        before = ensure_utc(before)
        gone = [i for i, r in self._rows.items() if r.resolved_at is not None and r.resolved_at < before]
        for i in gone:
            del self._rows[i]
        return len(gone)


class InMemoryBotTrustStore:
    def __init__(self) -> None:
        self._rows: dict[tuple[int, int], TrustedBot] = {}

    async def add(self, group_id, bot_id, added_by, note, now) -> bool:
        key = (group_id, bot_id)
        if key in self._rows:
            return False
        self._rows[key] = TrustedBot(group_id, bot_id, added_by, now, note)
        return True

    async def remove(self, group_id, bot_id) -> bool:
        return self._rows.pop((group_id, bot_id), None) is not None

    async def is_trusted(self, group_id, bot_id) -> bool:
        return (group_id, bot_id) in self._rows

    async def list(self, group_id):
        return sorted((r for (g, _), r in self._rows.items() if g == group_id), key=lambda r: r.added_at)
