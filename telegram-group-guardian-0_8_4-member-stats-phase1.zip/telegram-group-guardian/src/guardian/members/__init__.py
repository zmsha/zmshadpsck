"""Phase 4: new-member tools (welcome, verification, trusted bots). Pure models/settings/stores live here;
services, handlers and commands arrive in later parts (see PHASE4_PLAN.md)."""
