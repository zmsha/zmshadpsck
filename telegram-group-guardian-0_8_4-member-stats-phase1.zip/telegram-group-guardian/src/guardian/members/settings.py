"""Typed, clamped per-group welcome / verification / new-member settings (flat keys in the group's settings JSON).

Same contract as `protection/settings.py`: a missing or invalid value falls back to the SAFE default and is never
trusted raw. Bounds are module constants shared with the (later) command parsers so that a value a command accepts is
always a value `from_raw` keeps. Everything defaults to OFF: nothing happens in a group until its admins enable it
(and, independently, until the owner has licensed the group: these settings never bypass `ProtectionContext.allowed`).
"""
from __future__ import annotations

import string
from dataclasses import dataclass
from typing import Any

from .models import ChallengeKind, FailureAction

# --- bounds (inclusive) ------------------------------------------------------------------------------------------
TEMPLATE_MAX_CHARS = 400  # settings strings are capped at 500 by `validate_settings_patch`; leave headroom
WELCOME_DELETE_AFTER = (10, 86400)  # seconds; 0 = keep
VERIFY_TIMEOUT = (60, 86400)  # >= Telegram's 30 s restriction floor with margin
VERIFY_ATTEMPTS = (1, 10)
VERIFY_BAN = (60, 7 * 86400)
NEWBIE_WINDOW = (60, 30 * 86400)  # seconds; 0 = off

# Documented template variables (the ONLY names a template may use). `{{` and `}}` are literal braces.
WELCOME_VARIABLES = ("name", "group", "id")
SERVICE_MODES = ("keep", "delete")  # what to do with Telegram's own "X joined / left" service message
VERIFY_SCOPES = ("all", "suspicious")
VERIFY_METHODS = tuple(k.value for k in ChallengeKind)
VERIFY_FAILURES = tuple(a.value for a in FailureAction)


def template_ok(text: object) -> bool:
    """True for a non-empty template (<= TEMPLATE_MAX_CHARS) whose placeholders are all in WELCOME_VARIABLES, with no
    attribute/index/format-spec tricks (`{name.__class__}`, `{id:>10}`), no unbalanced braces and no NUL."""
    if not isinstance(text, str) or not text.strip() or len(text) > TEMPLATE_MAX_CHARS or "\x00" in text:
        return False
    try:
        for _, field, spec, conv in string.Formatter().parse(text):
            if field is None:
                continue
            if field not in WELCOME_VARIABLES or spec or conv:
                return False
    except ValueError:
        return False
    return True


def render_template(text: str, *, name: str, group: str, user_id: int) -> str:
    """Substitute the documented variables. Only call with a template that passed `template_ok`; values are inserted
    verbatim (the caller escapes for the parse mode it sends with)."""
    return text.format(name=name, group=group, id=user_id)


def _bool(raw: dict, key: str, default: bool) -> bool:
    v = raw.get(key, default)
    return v if isinstance(v, bool) else default


def _int_or_zero(raw: dict, key: str, bounds: tuple[int, int]) -> int:
    """0 = off; otherwise inside `bounds`. Anything else => 0 (never act on a value we cannot vouch for)."""
    v = raw.get(key, 0)
    if isinstance(v, bool) or not isinstance(v, int):
        return 0
    return v if v == 0 or bounds[0] <= v <= bounds[1] else 0


def _int(raw: dict, key: str, default: int, bounds: tuple[int, int]) -> int:
    v = raw.get(key, default)
    if isinstance(v, bool) or not isinstance(v, int):
        return default
    return v if bounds[0] <= v <= bounds[1] else default


def _choice(raw: dict, key: str, default: str, allowed: tuple[str, ...]) -> str:
    v = raw.get(key, default)
    return v if isinstance(v, str) and v in allowed else default


@dataclass(frozen=True, slots=True)
class WelcomeSettings:
    welcome_enabled: bool = False
    welcome_text: str | None = None  # None = built-in default text in the group's language
    welcome_delete_previous: bool = True  # delete the bot's previous welcome when a new one is sent (no clutter)
    welcome_delete_after_seconds: int = 0  # 0 = keep the welcome
    join_service: str = "keep"  # keep | delete Telegram's "joined" service message
    leave_service: str = "keep"  # keep | delete Telegram's "left" service message

    @classmethod
    def from_raw(cls, raw: Any) -> "WelcomeSettings":
        if not isinstance(raw, dict):
            return cls()
        text = raw.get("welcome_text")
        return cls(
            welcome_enabled=_bool(raw, "welcome_enabled", False),
            welcome_text=text if template_ok(text) else None,
            welcome_delete_previous=_bool(raw, "welcome_delete_previous", True),
            welcome_delete_after_seconds=_int_or_zero(raw, "welcome_delete_after_seconds", WELCOME_DELETE_AFTER),
            join_service=_choice(raw, "join_service", "keep", SERVICE_MODES),
            leave_service=_choice(raw, "leave_service", "keep", SERVICE_MODES),
        )


@dataclass(frozen=True, slots=True)
class VerificationSettings:
    verify_enabled: bool = False
    verify_scope: str = "all"  # all | suspicious
    verify_method: str = "button"  # button | math | choice | admin
    verify_timeout_seconds: int = 300
    verify_failure: str = "restrict"  # restrict | kick | ban  (least destructive first)
    verify_ban_seconds: int = 3600  # only used by verify_failure=ban
    verify_max_attempts: int = 3

    @classmethod
    def from_raw(cls, raw: Any) -> "VerificationSettings":
        if not isinstance(raw, dict):
            return cls()
        return cls(
            verify_enabled=_bool(raw, "verify_enabled", False),
            verify_scope=_choice(raw, "verify_scope", "all", VERIFY_SCOPES),
            verify_method=_choice(raw, "verify_method", "button", VERIFY_METHODS),
            verify_timeout_seconds=_int(raw, "verify_timeout_seconds", 300, VERIFY_TIMEOUT),
            verify_failure=_choice(raw, "verify_failure", "restrict", VERIFY_FAILURES),
            verify_ban_seconds=_int(raw, "verify_ban_seconds", 3600, VERIFY_BAN),
            verify_max_attempts=_int(raw, "verify_max_attempts", 3, VERIFY_ATTEMPTS),
        )


@dataclass(frozen=True, slots=True)
class NewMemberPolicy:
    """What a member who joined less than `newbie_seconds` ago may NOT send. 0 = no restriction window at all.
    Links/media here are enforced by the bot (delete only, no escalation); `newbie_block_messages` is a silent period."""

    newbie_seconds: int = 0
    newbie_block_links: bool = True
    newbie_block_media: bool = True
    newbie_block_messages: bool = False

    @property
    def active(self) -> bool:
        return self.newbie_seconds > 0 and (self.newbie_block_links or self.newbie_block_media or self.newbie_block_messages)

    @classmethod
    def from_raw(cls, raw: Any) -> "NewMemberPolicy":
        if not isinstance(raw, dict):
            return cls()
        return cls(
            newbie_seconds=_int_or_zero(raw, "newbie_seconds", NEWBIE_WINDOW),
            newbie_block_links=_bool(raw, "newbie_block_links", True),
            newbie_block_media=_bool(raw, "newbie_block_media", True),
            newbie_block_messages=_bool(raw, "newbie_block_messages", False),
        )
