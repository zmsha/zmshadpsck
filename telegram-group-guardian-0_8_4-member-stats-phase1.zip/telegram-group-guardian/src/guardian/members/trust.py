"""Trust lists (Phase 4 / part 2): WHAT each kind of trust bypasses. This module is the single source of truth.

There is deliberately NO blanket exemption: a trust entry skips only the listed rules; everything else still applies.

Rule names (stable strings, shared with the protection engine and the verification layer of part 4.4):
  links         the link / invite filter
  duplicate     repeated-message detection
  slowmode      the bot-enforced slow mode
  flood         the message-rate (flood) rule
  verification  the new-member challenge of part 4.4 (the member is not challenged)
  newbie        the new-member restriction window of part 4.5 (a trusted member is not restricted as a newcomer)

* Trusted USER (`group_trusted_users`, this group only) skips: links, duplicate, slowmode, verification, newbie.
  Still applies to a trusted user: FLOOD (a compromised or careless account bursting messages), every manual command an
  admin runs on them (/ban /mute /warn ...: trust is not protection), and all rules in every OTHER group.
* Trusted DOMAIN (`links_allow_domains`, edited by `/trust domain` or `/protect allow`) skips: links, and only for URLs
  whose host is that domain or a true sub-domain (evil-example.com does not match example.com). It never allows Telegram
  invite links (that is `/protect invites allow`) and never affects any other rule or any other host.
* Trusted BOT (`group_trusted_bots`) skips: links, only for messages sent THROUGH that inline bot (`via_bot`), and
  verification when the bot itself is added to the group. It never makes the bot an admin, never exempts the user who
  used the bot from flood/duplicate/slowmode, and never stops an admin from removing the bot.

Failure policy: when a trust lookup fails the engine does not sanction (uncertain => no action), exactly as for every
other lookup of the protection layer.
"""
from __future__ import annotations

RULE_LINKS = "links"
RULE_DUPLICATE = "duplicate"
RULE_FLOOD = "flood"
RULE_SLOWMODE = "slowmode"
RULE_VERIFICATION = "verification"
RULE_NEWBIE = "newbie"  # part 4.5: the new-member restriction window (links / media / messages)

USER_BYPASS = frozenset({RULE_LINKS, RULE_DUPLICATE, RULE_SLOWMODE, RULE_VERIFICATION, RULE_NEWBIE})
DOMAIN_BYPASS = frozenset({RULE_LINKS})
BOT_BYPASS = frozenset({RULE_LINKS, RULE_VERIFICATION})
# What a message sent through a trusted bot skips (the join-time verification part of BOT_BYPASS is for part 4.4).
VIA_BOT_MESSAGE_BYPASS = frozenset({RULE_LINKS})

MAX_TRUSTED_USERS = 200
MAX_TRUSTED_BOTS = 50
