"""Welcome messages and control of Telegram's join/leave service messages (phase 4.3). Framework independent.

Rules (each covered by tests):
* NOTHING happens unless the license allows the group right now (`ProtectionContext.allowed`, evaluated per update from
  the clock, so a service that slept past `expires_at` does nothing on its first update). The bot being removed and
  re-added never changes that. A settings read that fails => do nothing (fail closed). A delayed clean-up delete
  re-checks the license when it fires.
* Everything is OFF by default (`WelcomeSettings`): a group gets a welcome only after its admins enable it.
* Per-group: settings are read by `group_id`; the in-memory state (last welcome, burst counter) is keyed by group.
* Template: only the documented variables `{name} {group} {id}` (validated by `template_ok` when stored and again
  when read). The template's own text is HTML-escaped, `{name}` becomes a mention link of the (escaped) display name,
  `{group}` the escaped title; values are never re-interpreted as a template. An invalid/oversized result falls back to
  the built-in text. `{id}` is the first welcomed member's id; `{name}` lists up to `MAX_NAMES` joined members.
* Bots (and the bot itself) are never welcomed. One welcome per join service message (idempotent: a redelivered
  update claims the same key and does nothing).
* Rate limit: at most `BURST_LIMIT` welcomes per `BURST_WINDOW` seconds per group; extra joins (a raid) get no welcome.
* The previous welcome is deleted AFTER the new one was sent (if sending fails the old one stays). Optional timed
  deletion (`welcome_delete_after_seconds`).
* Telegram's own "joined"/"left" service messages are deleted only when the group chose `delete`, and never in
  `dry_run`. No "goodbye" text is ever sent.
* LIMITS (documented, not hidden): the last-welcome id and the timed deletions live in process memory, so a restart or
  a Render Free sleep forgets them: the welcome then simply stays in the chat (never a wrong deletion). Telegram may
  not send join/leave service messages at all in some groups; nothing here can force it.
"""
from __future__ import annotations

import asyncio
import html
import logging
import time
from collections import OrderedDict
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Awaitable, Callable, Sequence

from ..groups.store import SettingsStore
from ..i18n import SUPPORTED
from ..idempotency import IdempotencyStore, operation_key
from ..licensing.service import LicenseService
from ..protection.tracking import SlidingCounter
from ..protection_gate import ProtectionContext
from ..time_utils import utcnow
from .settings import WelcomeSettings, render_template, template_ok

log = logging.getLogger(__name__)

DEFAULT_TEMPLATES = {"ar": "أهلًا بك {name} في {group} 👋", "en": "Welcome {name} to {group} 👋"}
MAX_NAMES = 3
NAME_MAX_CHARS = 64
TITLE_MAX_CHARS = 128
MAX_TEXT = 4000            # below Telegram's 4096 limit
BURST_LIMIT, BURST_WINDOW = 5, 60.0
MAX_TRACKED_GROUPS = 5000
MAX_PENDING_DELETES = 1000


@dataclass(frozen=True, slots=True)
class Joined:
    user_id: int
    name: str
    is_bot: bool = False
    username: str | None = None  # without "@"; None/empty = the account has no public username


@dataclass(frozen=True, slots=True)
class JoinOutcome:
    welcomed: bool = False
    service_deleted: bool = False
    reason: str = "none"  # none | not_allowed | settings_unavailable | claim_unavailable | disabled | no_humans | duplicate | rate_limited | send_failed


def _clip(text: str, limit: int) -> str:
    text = " ".join(str(text).split())  # no newlines / control runs inside a name or title
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _valid_id(value: object) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value > 0


def build_welcome(template: str | None, lang: str, members: Sequence[Joined], title: str | None) -> str:
    """The HTML text to send. Never raises: any problem falls back to the built-in text."""
    first = members[0].user_id
    names = ", ".join(
        f'<a href="tg://user?id={m.user_id}">{html.escape(_clip(m.name, NAME_MAX_CHARS) or str(m.user_id), quote=False)}</a>'
        for m in members[:MAX_NAMES]
    )
    if len(members) > MAX_NAMES:
        names += f" +{len(members) - MAX_NAMES}"
    group = html.escape(_clip(title or "", TITLE_MAX_CHARS), quote=False)

    def render(tmpl: str) -> str:
        return render_template(html.escape(tmpl, quote=False), name=names, group=group, user_id=first)

    candidates = [template] if template and template_ok(template) else []
    candidates.append(DEFAULT_TEMPLATES.get(lang, DEFAULT_TEMPLATES["ar"]))
    for tmpl in candidates:
        try:
            text = render(tmpl)
        except (KeyError, IndexError, ValueError):
            continue
        if text.strip() and len(text) <= MAX_TEXT:
            return text
    return DEFAULT_TEMPLATES["ar"].format(name=names[:200], group="")[:MAX_TEXT]  # pragma: no cover


Scheduler = Callable[[float, Callable[[], Awaitable[None]]], bool]


class WelcomeService:
    def __init__(
        self,
        settings_store: SettingsStore,
        actions: Any,                      # needs `send_message(chat_id, text)` and `delete_message(chat_id, message_id)`
        claims: IdempotencyStore,
        licenses: LicenseService,
        *,
        language: str = "ar",
        clock: Callable[[], datetime] = utcnow,
        monotonic: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
        schedule: Scheduler | None = None,
    ):
        self._settings = settings_store
        self._actions = actions
        self._claims = claims
        self._licenses = licenses
        self._language = language if language in SUPPORTED else "ar"
        self._clock = clock
        self._mono = monotonic
        self._sleep = sleep
        self._schedule: Scheduler = schedule or self._default_schedule
        self._burst = SlidingCounter(MAX_TRACKED_GROUPS)
        self._last: "OrderedDict[int, int]" = OrderedDict()  # group_id -> last welcome message id (memory only)
        self._tasks: set[asyncio.Task] = set()

    # ------------------------------------------------------------------ public
    async def on_join(
        self, ctx: ProtectionContext, service_message_id: int | None, joined: Sequence[Joined], title: str | None = None
    ) -> JoinOutcome:
        loaded = await self._load(ctx)
        if isinstance(loaded, JoinOutcome):
            return loaded
        cfg, lang, dry_run = loaded
        group = ctx.chat_id
        service_deleted = False
        if cfg.join_service == "delete" and not dry_run and _valid_id(service_message_id):
            service_deleted = (await self._actions.delete_message(group, service_message_id)).ok
        if not cfg.welcome_enabled:
            return JoinOutcome(False, service_deleted, "disabled")
        humans = [m for m in joined if isinstance(m, Joined) and not m.is_bot and _valid_id(m.user_id)]
        if not humans:
            return JoinOutcome(False, service_deleted, "no_humans")
        if not _valid_id(service_message_id):
            return JoinOutcome(False, service_deleted, "duplicate")  # no stable key => cannot be idempotent
        try:
            first_time = await self._claims.claim(operation_key("welcome", group, service_message_id), self._clock())
        except Exception:
            log.warning("welcome claim store unavailable", extra={"group_id": group})
            return JoinOutcome(False, service_deleted, "claim_unavailable")
        if not first_time:
            return JoinOutcome(False, service_deleted, "duplicate")
        reason = await self._send_welcome(group, cfg, lang, humans, title)
        return JoinOutcome(reason == "none", service_deleted, reason)

    async def on_verified(self, group_id: int, member: Joined, title: str | None, challenge_id: int) -> JoinOutcome:
        """Part 8.2 (owner decision): the welcome of a member who PASSED / was APPROVED. Called only after the verification
        service reported success for this very challenge; the licence is re-checked now (fail closed), the claim is per
        challenge (a repeated press never welcomes twice) and the same settings / burst limit / cleanup as `on_join` apply."""
        if not isinstance(group_id, int) or isinstance(group_id, bool) or group_id >= 0 or not isinstance(member, Joined) or member.is_bot or not _valid_id(member.user_id) \
                or not _valid_id(challenge_id):
            return JoinOutcome(False, False, "no_humans")
        try:
            allowed = bool((await self._licenses.check(group_id, self._clock())).allowed)
        except Exception:
            allowed = False
        if not allowed:
            return JoinOutcome(False, False, "not_allowed")
        ctx = ProtectionContext(group_id, "supergroup", True, "none", member.user_id, False)
        loaded = await self._load(ctx)
        if isinstance(loaded, JoinOutcome):
            return loaded
        cfg, lang, _dry_run = loaded
        if not cfg.welcome_enabled:
            return JoinOutcome(False, False, "disabled")
        try:
            first_time = await self._claims.claim(operation_key("welcomepass", group_id, challenge_id), self._clock())
        except Exception:
            log.warning("welcome claim store unavailable", extra={"group_id": group_id})
            return JoinOutcome(False, False, "claim_unavailable")
        if not first_time:
            return JoinOutcome(False, False, "duplicate")
        reason = await self._send_welcome(group_id, cfg, lang, [member], title)
        return JoinOutcome(reason == "none", False, reason)

    async def _send_welcome(self, group: int, cfg: WelcomeSettings, lang: str, humans: Sequence[Joined],
                            title: str | None) -> str:
        """Burst limit, send, remember / delete-previous / timed delete. Returns the JoinOutcome reason ("none" = sent)."""
        if self._burst.hit(group, self._mono(), BURST_WINDOW) > BURST_LIMIT:
            return "rate_limited"
        text = build_welcome(cfg.welcome_text, lang, humans, title)
        sent = await self._actions.send_message(group, text)
        if not sent.ok or sent.message_id is None:
            return "send_failed"
        previous = self._last.get(group)
        self._remember(group, sent.message_id)
        if cfg.welcome_delete_previous and previous is not None and previous != sent.message_id:
            await self._actions.delete_message(group, previous)  # best effort: a failure only leaves clutter
        if cfg.welcome_delete_after_seconds > 0:
            self._schedule(float(cfg.welcome_delete_after_seconds), self._timed_delete(group, sent.message_id))
        return "none"

    async def on_leave(self, ctx: ProtectionContext, service_message_id: int | None) -> bool:
        """Delete Telegram's "left" service message when the group chose so. True when a delete succeeded."""
        loaded = await self._load(ctx)
        if isinstance(loaded, JoinOutcome):
            return False
        cfg, _lang, dry_run = loaded
        if cfg.leave_service != "delete" or dry_run or not _valid_id(service_message_id):
            return False
        return (await self._actions.delete_message(ctx.chat_id, service_message_id)).ok

    async def aclose(self) -> None:
        for task in list(self._tasks):
            task.cancel()
        if self._tasks:
            await asyncio.gather(*self._tasks, return_exceptions=True)
        self._tasks.clear()

    # ------------------------------------------------------------------ internals
    async def _load(self, ctx: ProtectionContext) -> tuple[WelcomeSettings, str, bool] | JoinOutcome:
        if not ctx.allowed or ctx.chat_id is None:
            return JoinOutcome(False, False, "not_allowed")
        try:
            row = await self._settings.get(ctx.chat_id)
        except Exception:
            log.warning("welcome settings unavailable", extra={"group_id": ctx.chat_id})
            return JoinOutcome(False, False, "settings_unavailable")
        raw = row.settings if row is not None and isinstance(row.settings, dict) else {}
        lang = row.language if row is not None and row.language in SUPPORTED else self._language
        return WelcomeSettings.from_raw(raw), lang, raw.get("dry_run") is True

    def _remember(self, group: int, message_id: int) -> None:
        self._last[group] = message_id
        self._last.move_to_end(group)
        while len(self._last) > MAX_TRACKED_GROUPS:
            self._last.popitem(last=False)

    def _timed_delete(self, group: int, message_id: int) -> Callable[[], Awaitable[None]]:
        async def run() -> None:
            try:
                if not (await self._licenses.check(group, self._clock())).allowed:
                    return  # license ended meanwhile: no automatic action
            except Exception:
                return  # cannot verify => do nothing
            await self._actions.delete_message(group, message_id)
            if self._last.get(group) == message_id:
                del self._last[group]

        return run

    def _default_schedule(self, delay: float, job: Callable[[], Awaitable[None]]) -> bool:
        if len(self._tasks) >= MAX_PENDING_DELETES:
            return False  # the welcome simply stays; never an unbounded task pile

        async def runner() -> None:
            await self._sleep(delay)
            await job()

        try:
            task = asyncio.get_running_loop().create_task(runner())
        except RuntimeError:  # no running loop
            return False
        self._tasks.add(task)
        task.add_done_callback(self._task_done)
        return True

    def _task_done(self, task: asyncio.Task) -> None:
        self._tasks.discard(task)
        if not task.cancelled() and task.exception() is not None:
            log.warning("timed welcome delete failed", exc_info=task.exception())
