"""Trusted-bot list service. Same contract as `groups.service.TrustService`: authorize through PermissionService FIRST
(MANAGE_TRUST for THIS group), then touch only this group's rows, audit what changed."""
from __future__ import annotations

from datetime import datetime
from typing import Callable

from ..audit import TRUST_BOT_ADDED, TRUST_BOT_REMOVED, SecurityAudit, make_event, record_safely, sanitize_text
from ..errors import GroupNotRegistered, InvalidInput
from ..licensing.store import LicenseStore
from ..permissions import Permission, PermissionService
from ..time_utils import utcnow
from .models import TrustedBot
from .store import BotTrustStore


def _bot(value: object) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or not 0 < value < 2**63:
        raise InvalidInput("bot id must be a positive integer")
    return value


class BotTrustService:
    def __init__(self, store: BotTrustStore, licenses: LicenseStore, permissions: PermissionService,
                 audit: SecurityAudit | None = None, *, clock: Callable[[], datetime] = utcnow):
        self._store, self._licenses, self._perm, self._audit, self._clock = store, licenses, permissions, audit, clock

    async def add(self, actor_id, group_id, bot_id, note: str | None = None, *, context_chat_id=None) -> bool:
        await self._perm.require(actor_id, group_id, Permission.MANAGE_TRUST, context_chat_id=context_chat_id)
        bot_id = _bot(bot_id)
        if await self._licenses.get(group_id) is None:
            raise GroupNotRegistered("group is not registered")
        now = self._clock()
        created = await self._store.add(group_id, bot_id, actor_id, sanitize_text(note, 200), now)
        if created:
            await record_safely(self._audit, make_event(TRUST_BOT_ADDED, actor=actor_id, group_id=group_id,
                                                        detail=f"bot={bot_id}", now=now))
        return created

    async def remove(self, actor_id, group_id, bot_id, *, context_chat_id=None) -> bool:
        await self._perm.require(actor_id, group_id, Permission.MANAGE_TRUST, context_chat_id=context_chat_id)
        bot_id = _bot(bot_id)
        removed = await self._store.remove(group_id, bot_id)
        if removed:
            await record_safely(self._audit, make_event(TRUST_BOT_REMOVED, actor=actor_id, group_id=group_id,
                                                        detail=f"bot={bot_id}", now=self._clock()))
        return removed

    async def list(self, actor_id, group_id, *, context_chat_id=None) -> list[TrustedBot]:
        await self._perm.require(actor_id, group_id, Permission.MANAGE_TRUST, context_chat_id=context_chat_id)
        return await self._store.list(group_id)
