"""New-member verification, core (phase 4.4). Framework independent.

What it does (each rule has tests):
* On a join service message, when the group enabled `verify_enabled` with `verify_scope=all` and a button/math/choice
  method, every human who is not exempt gets ONE challenge: the member is muted (all permissions denied, no end date) and
  a prompt with inline buttons is posted. A correct answer resolves PASSED and restores the group's default permissions.
* Wrong answers are counted in the store (atomic); at the limit the challenge FAILED. A passed deadline EXPIRED. Both then
  apply the group's failure action: `restrict` (member stays muted, an admin can /unmute), `kick` (removed, may rejoin) or
  `ban` (temporary, `verify_ban_seconds`).
* NOTHING happens unless the license allows the group right now. Join: the update's `ProtectionContext.allowed`. Answer /
  expiry: the license is re-checked from the clock at that moment (a service that slept past `expires_at` does nothing).
  A group whose license ended keeps its pending rows untouched (no automatic action, not even an unmute); when the license
  returns the sweeper resolves them. The bot being removed and re-added never changes any of this.
* Exempt: owner/delegates/Telegram admins (`is_exempt_from_automation`) and the group's trusted users
  (`members/trust.RULE_VERIFICATION`). Any lookup failure => no challenge (uncertain => no action); at expiry an
  uncertain lookup leaves the row pending for the next sweep. If the member became exempt meanwhile the challenge is
  CANCELLED and the member unmuted instead of punished.
* `dry_run` never restricts or punishes: no challenge at join; a challenge that expires while dry_run is on is CANCELLED
  and the member unmuted.
* Idempotent: the challenge key is (group, join service message id, user); a redelivered update, or a re-join while a
  challenge is pending, creates nothing and prompts nothing. All resolutions are compare-and-set (`ChallengeStore.resolve`):
  the loser of a race (callback vs. timer vs. sweeper) does nothing.
* Expiry after a Render Free sleep: per-challenge timers live in memory and are lost, so `tick()` (called from the update
  middleware, throttled) runs `sweep()` over `list_due`. The first update after waking resolves what expired meanwhile.
* The member leaving cancels a pending challenge (`on_leave`).

Part 4.5 additions:
* `verify_method=admin`: the member is muted and the prompt carries Approve / Reject buttons. Only an actor with the
  MODERATE permission IN THIS GROUP (checked on the server per press, never from the button) may press them; the member can
  never approve themselves. Approve => APPROVED + unmute; Reject or timeout => the group's failure action.
* `verify_scope=suspicious`: only members showing at least one signal are challenged (owner decision): no public username,
  no profile photo, or a join wave (`WAVE_COUNT` human joins within `WAVE_WINDOW` s in the group). The photo is looked up
  only when the username is present; an unknown answer is not a signal. Wave counters are in memory (reset by a sleep).
* Anti-rejoin: a member with a FAILED / EXPIRED / REJECTED challenge in the last `REJOIN_WINDOW` gets no fresh attempt:
  the group's failure action is re-applied at once (restrict => muted again, kick => removed, ban => temporary ban), once
  per join message (claim). Applies in both scopes, never in dry_run, never to exempt/trusted members.

LIMITS (documented, not hidden):
* Not implemented here: restrictions for new members live in `members/newcomers.py` + the protection engine.
* Telegram reports 0 photos for users who hide them by privacy settings: with scope=suspicious such members count as
  "no photo". Real users without a username are common too; the owner's definition is "any signal", so the scope can be wide.
* Bots are never challenged (a bot cannot press a button); the trusted-bot bypass is therefore moot until a bot-join policy.
* The challenges are click puzzles, not image CAPTCHAs: they stop naive scripts only. For math/choice the effective wrong-
  answer limit is capped at `MAX_GUESS_ATTEMPTS` (6 options => a blind guesser passes with probability <= 50%).
* Welcome-after-pass (owner decision, part 8.2): a member who got a challenge (or a rejoin enforcement) is NOT welcomed on join;
  `answer()` reports the verified member (`AnswerOutcome.user_id/name`) and the join handler then asks `WelcomeService.on_verified`.
  Failed / expired / rejected members are never welcomed. The display name of a challenged member is kept in memory only: after
  a sleep it falls back to the numeric id inside the mention. Members who were never challenged are welcomed on join as before.
* Outcomes are kept as challenge rows (status, attempts, resolver); no separate audit-log event is written.
* Needs the bot's "restrict members" right (+ "ban users" for kick/ban). Without it the challenge is CANCELLED and the member
  is NOT restricted (fail open on a missing right, never a stuck prompt).
"""
from __future__ import annotations

import asyncio
import html
import logging
import random
import re
import time
from collections import OrderedDict
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Awaitable, Callable, Sequence

from ..groups.store import SettingsStore
from ..i18n import SUPPORTED
from ..idempotency import IdempotencyStore, operation_key
from ..licensing.service import LicenseService
from ..permissions import Permission
from ..protection.tracking import SlidingCounter
from ..protection_gate import ProtectionContext
from ..time_utils import utcnow
from .models import Challenge, ChallengeKind, ChallengeStatus, FailureAction
from .settings import VerificationSettings
from .store import ChallengeStore
from .welcome import Joined, _clip, _valid_id

log = logging.getLogger(__name__)

CALLBACK_PREFIX = "vf"
_DATA_RE = re.compile(r"^vf:([0-9]{1,18}):([a-z0-9]{1,12})$")
OPTIONS = 6                    # buttons in a math / choice challenge
MAX_GUESS_ATTEMPTS = 3         # effective cap on wrong answers for math / choice
MAX_PER_JOIN = 10              # challenges created for one join service message
BURST_LIMIT, BURST_WINDOW = 30, 60.0
MAX_TRACKED_GROUPS = 5000
MAX_PENDING_TIMERS = 1000
SWEEP_INTERVAL = 30.0          # seconds between throttled sweeps
SWEEP_BATCH = 20
NAME_MAX_CHARS = 64
WAVE_COUNT, WAVE_WINDOW = 5, 120.0     # this many human joins within this many seconds in one group = a join wave
REJOIN_WINDOW = timedelta(hours=6)     # a failed/expired/rejected challenge this recent blocks a fresh attempt
APPROVE, REJECT = "ap", "rj"           # callback values of the admin-approval buttons

# key -> (emoji, Arabic name, English name)
SYMBOLS = {
    "cat": ("🐱", "قطة", "cat"), "dog": ("🐶", "كلب", "dog"), "fish": ("🐟", "سمكة", "fish"),
    "car": ("🚗", "سيارة", "car"), "tree": ("🌳", "شجرة", "tree"), "star": ("⭐", "نجمة", "star"),
    "moon": ("🌙", "قمر", "moon"), "sun": ("☀️", "شمس", "sun"), "apple": ("🍎", "تفاحة", "apple"),
    "bird": ("🐦", "طائر", "bird"), "house": ("🏠", "منزل", "house"), "book": ("📘", "كتاب", "book"),
}

TEXTS = {
    "ar": {
        "title": "🔐 التحقق من العضو",
        "intro": "{mention}، أثبت أنك لست بوتًا خلال {minutes} دقيقة.",
        "restrict": "وإلا بقي تقييدك قائمًا.", "kick": "وإلا ستُزال من المجموعة.", "ban": "وإلا ستُحظر مؤقتًا.",
        "button_q": "اضغط الزر أدناه.", "button_label": "✅ أنا لست بوتًا",
        "admin_intro": "{mention} ينتظر موافقة أحد المشرفين خلال {minutes} دقيقة.", "admin_q": "للمشرفين فقط:",
        "approve_label": "✅ موافقة", "reject_label": "⛔ رفض", "approved": "✅ تمت الموافقة", "rejected": "⛔ تم رفض العضو",
        "not_admin": "للمشرفين فقط",
        "math_q": "كم ناتج {a} {op} {b} ؟", "choice_q": "اضغط الزر الذي يمثّل: {name}",
        "passed": "✅ تم التحقق، أهلًا بك", "passed_unmute_failed": "✅ تم التحقق لكن تعذّر رفع التقييد؛ تواصل مع مشرف",
        "wrong": "❌ إجابة خاطئة، المحاولات المتبقية: {left}", "failed": "❌ فشل التحقق",
        "expired": "⌛ انتهت المهلة", "not_yours": "هذا التحقق ليس لك", "gone": "انتهى هذا التحقق أو حُسم",
        "unavailable": "الخدمة غير متاحة الآن",
    },
    "en": {
        "title": "🔐 Member verification",
        "intro": "{mention}, prove you are not a bot within {minutes} minute(s).",
        "restrict": "Otherwise your restriction stays.", "kick": "Otherwise you will be removed from the group.",
        "ban": "Otherwise you will be banned temporarily.",
        "button_q": "Press the button below.", "button_label": "✅ I am not a bot",
        "admin_intro": "{mention} is waiting for an admin's approval within {minutes} minute(s).", "admin_q": "Admins only:",
        "approve_label": "✅ Approve", "reject_label": "⛔ Reject", "approved": "✅ Approved", "rejected": "⛔ Member rejected",
        "not_admin": "Admins only",
        "math_q": "What is {a} {op} {b} ?", "choice_q": "Press the button that shows: {name}",
        "passed": "✅ Verified, welcome", "passed_unmute_failed": "✅ Verified, but the restriction could not be lifted; contact an admin",
        "wrong": "❌ Wrong answer, attempts left: {left}", "failed": "❌ Verification failed",
        "expired": "⌛ Time is up", "not_yours": "This verification is not for you", "gone": "This verification has ended",
        "unavailable": "Service unavailable right now",
    },
}


@dataclass(frozen=True, slots=True)
class Puzzle:
    question: str
    answer: str
    options: tuple[tuple[str, str], ...]  # (button label, value carried in callback data)


def make_puzzle(kind: ChallengeKind, lang: str, rng: random.Random) -> Puzzle:
    tx = TEXTS.get(lang, TEXTS["ar"])
    if kind is ChallengeKind.BUTTON:
        return Puzzle(tx["button_q"], "ok", ((tx["button_label"], "ok"),))
    if kind is ChallengeKind.MATH:
        a, b = rng.randint(2, 9), rng.randint(1, 9)
        if rng.random() < 0.5:
            result, question = a + b, tx["math_q"].format(a=a, op="+", b=b)
        else:  # (a + b) - b: never negative
            result, question = a, tx["math_q"].format(a=a + b, op="−", b=b)
        pool = [v for v in range(0, 21) if v != result]
        values = rng.sample(pool, OPTIONS - 1) + [result]
        rng.shuffle(values)
        return Puzzle(question, str(result), tuple((str(v), str(v)) for v in values))
    if kind is ChallengeKind.CHOICE:
        keys = rng.sample(sorted(SYMBOLS), OPTIONS)
        target = rng.choice(keys)
        name = SYMBOLS[target][1 if lang == "ar" else 2]
        return Puzzle(tx["choice_q"].format(name=name), target, tuple((SYMBOLS[k][0], k) for k in keys))
    if kind is ChallengeKind.ADMIN:
        return Puzzle(tx["admin_q"], "", ((tx["approve_label"], APPROVE), (tx["reject_label"], REJECT)))
    raise ValueError("unsupported challenge kind")


def buttons_for(challenge_id: int, puzzle_options: Sequence[tuple[str, str]]) -> tuple[tuple[tuple[str, str], ...], ...]:
    """Rows of (label, callback_data), 3 per row (a single button gets its own row)."""
    cells = tuple((label, f"{CALLBACK_PREFIX}:{challenge_id}:{value}") for label, value in puzzle_options)
    return tuple(cells[i:i + 3] for i in range(0, len(cells), 3))


def parse_callback(data: object) -> tuple[int, str] | None:
    if not isinstance(data, str):
        return None
    m = _DATA_RE.match(data)
    return (int(m.group(1)), m.group(2)) if m else None


@dataclass(frozen=True, slots=True)
class VerifyOutcome:
    challenged: tuple[int, ...] = ()
    enforced: tuple[int, ...] = ()  # rejoiners who failed recently: the failure action was re-applied (no new challenge)
    reason: str = "none"  # none | not_allowed | settings_unavailable | disabled | dry_run | no_key | no_humans | nothing_to_do


@dataclass(frozen=True, slots=True)
class AnswerOutcome:
    kind: str   # passed | passed_unmute_failed | wrong | failed | expired | not_yours | gone | unavailable | approved | rejected | not_admin
    text: str
    alert: bool = False
    user_id: int | None = None  # the VERIFIED member on a success kind (passed | passed_unmute_failed | approved), else None
    name: str = ""              # display name remembered at join time ("" after a restart)

SUCCESS_KINDS = frozenset({"passed", "passed_unmute_failed", "approved"})
MAX_REMEMBERED_NAMES = 2000


Scheduler = Callable[[float, Callable[[], Awaitable[None]]], bool]


class VerificationService:
    def __init__(
        self,
        settings_store: SettingsStore,
        actions: Any,       # mute_member, unmute_member, kick_member, ban_member, delete_message, send_message(chat, text, buttons)
        challenges: ChallengeStore,
        licenses: LicenseService,
        permissions: Any,   # is_exempt_from_automation(user, group), is_trusted(user, group), check(user, group, perm, ...)
        *,
        claims: IdempotencyStore,
        language: str = "ar",
        clock: Callable[[], datetime] = utcnow,
        monotonic: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
        schedule: Scheduler | None = None,
        rng: random.Random | None = None,
    ):
        self._settings = settings_store
        self._actions = actions
        self._store = challenges
        self._licenses = licenses
        self._perm = permissions
        self._claims = claims
        self._language = language if language in SUPPORTED else "ar"
        self._clock = clock
        self._mono = monotonic
        self._sleep = sleep
        self._schedule: Scheduler = schedule or self._default_schedule
        self._rng = rng or random.SystemRandom()
        self._burst = SlidingCounter(MAX_TRACKED_GROUPS)
        self._wave = SlidingCounter(MAX_TRACKED_GROUPS)
        self._tasks: set[asyncio.Task] = set()
        self._names: "OrderedDict[tuple[int, int], str]" = OrderedDict()  # (group, challenge id) -> display name (memory only)
        self._last_sweep = float("-inf")
        self._sweeping = False

    # ------------------------------------------------------------------ join
    async def on_join(
        self, ctx: ProtectionContext, service_message_id: int | None, joined: Sequence[Joined], title: str | None = None
    ) -> VerifyOutcome:
        if not ctx.allowed or ctx.chat_id is None:
            return VerifyOutcome(reason="not_allowed")
        loaded = await self._load(ctx.chat_id)
        if loaded is None:
            return VerifyOutcome(reason="settings_unavailable")
        vs, lang, dry_run = loaded
        if not vs.verify_enabled:
            return VerifyOutcome(reason="disabled")
        if dry_run:
            return VerifyOutcome(reason="dry_run")
        if not _valid_id(service_message_id):
            return VerifyOutcome(reason="no_key")  # no stable key => cannot be idempotent
        humans = [m for m in joined if isinstance(m, Joined) and not m.is_bot and _valid_id(m.user_id)]
        if not humans:
            return VerifyOutcome(reason="no_humans")
        done: list[int] = []
        enforced: list[int] = []
        for m in humans[:MAX_PER_JOIN]:
            wave = self._wave.hit(ctx.chat_id, self._mono(), WAVE_WINDOW) >= WAVE_COUNT
            if self._burst.hit(ctx.chat_id, self._mono(), BURST_WINDOW) > BURST_LIMIT:
                break
            try:
                skip = await self._perm.is_exempt_from_automation(m.user_id, ctx.chat_id) or await self._perm.is_trusted(
                    m.user_id, ctx.chat_id)
            except Exception:
                log.warning("verification exemption lookup failed", extra={"group_id": ctx.chat_id})
                continue  # uncertain => no challenge
            if skip:
                continue
            if await self._failed_recently(ctx.chat_id, m.user_id):
                if await self._enforce_rejoin(ctx.chat_id, m.user_id, vs, service_message_id):
                    enforced.append(m.user_id)
                continue
            if vs.verify_scope == "suspicious" and not await self.suspicion_signals(m, wave):
                continue
            if await self._challenge(ctx.chat_id, m, vs, lang, service_message_id):
                done.append(m.user_id)
        return VerifyOutcome(tuple(done), tuple(enforced), "none" if (done or enforced) else "nothing_to_do")

    async def suspicion_signals(self, member: Joined, wave: bool) -> tuple[str, ...]:
        """Why a joiner looks suspicious (owner decision): no username, no profile photo, or part of a join wave."""
        signals: list[str] = []
        if not member.username:
            signals.append("no_username")
        elif await self._has_photo(member.user_id) is False:  # None (unknown) is not a signal
            signals.append("no_photo")
        if wave:
            signals.append("wave")
        return tuple(signals)

    async def _has_photo(self, user_id: int) -> bool | None:
        lookup = getattr(self._actions, "has_profile_photo", None)
        if lookup is None:
            return None
        try:
            return await lookup(user_id)
        except Exception:
            return None

    async def _failed_recently(self, group: int, user_id: int) -> bool:
        try:
            return await self._store.recent_unsuccessful(group, user_id, self._clock() - REJOIN_WINDOW) > 0
        except Exception:
            log.warning("verification history unavailable", extra={"group_id": group})
            return False  # no evidence => the normal path (a fresh challenge) applies

    async def _enforce_rejoin(self, group: int, user_id: int, vs: VerificationSettings, message_id: int) -> bool:
        try:
            first = await self._claims.claim(operation_key("verify_rejoin", group, message_id, user_id), self._clock())
        except Exception:
            return False
        if not first:
            return False
        if vs.verify_failure == "kick":
            res = await self._actions.kick_member(group, user_id)
        elif vs.verify_failure == "ban":
            res = await self._actions.ban_member(group, user_id, self._clock() + timedelta(seconds=vs.verify_ban_seconds))
        else:
            res = await self._actions.mute_member(group, user_id, None)
        return res.ok

    async def _challenge(self, group: int, member: Joined, vs: VerificationSettings, lang: str, message_id: int) -> bool:
        kind = ChallengeKind(vs.verify_method)
        puzzle = make_puzzle(kind, lang, self._rng)
        now = self._clock()
        failure = FailureAction(vs.verify_failure)
        try:
            row, created = await self._store.create(
                group, member.user_id, kind, puzzle.answer or None, failure,
                vs.verify_ban_seconds if failure is FailureAction.BAN else None,
                now, now + timedelta(seconds=vs.verify_timeout_seconds),
                operation_key("verify", group, message_id, member.user_id))
        except Exception:
            log.warning("verification store unavailable", extra={"group_id": group})
            return False
        if not created:
            return False  # redelivery, or a challenge is already pending for this member
        if not (await self._actions.mute_member(group, member.user_id, None)).ok:
            await self._cancel(row)  # cannot restrict (missing right): do not leave a prompt nobody can enforce
            return False
        text = self._prompt_text(member, vs, lang, puzzle)
        sent = await self._actions.send_message(group, text, buttons_for(row.id, puzzle.options))
        if not sent.ok or sent.message_id is None:
            await self._actions.unmute_member(group, member.user_id)  # best effort: never leave a muted member with no prompt
            await self._cancel(row)
            return False
        try:
            await self._store.set_prompt_message(group, row.id, sent.message_id)
        except Exception:
            log.warning("could not store the prompt message id", extra={"group_id": group})
        self._remember_name(group, row.id, member.name)
        self._schedule(float(vs.verify_timeout_seconds), self._timer(group, row.id))
        return True

    def _remember_name(self, group: int, challenge_id: int, name: str) -> None:
        self._names[(group, challenge_id)] = _clip(name, 64)
        while len(self._names) > MAX_REMEMBERED_NAMES:
            self._names.popitem(last=False)

    def _success(self, kind: str, text: str, alert: bool, row: Challenge) -> AnswerOutcome:
        name = self._names.pop((row.group_id, row.id), "")
        return AnswerOutcome(kind, text, alert, row.user_id, name)

    @staticmethod
    def _prompt_text(member: Joined, vs: VerificationSettings, lang: str, puzzle: Puzzle) -> str:
        tx = TEXTS.get(lang, TEXTS["ar"])
        name = html.escape(_clip(member.name, NAME_MAX_CHARS) or str(member.user_id), quote=False)
        mention = f'<a href="tg://user?id={member.user_id}">{name}</a>'
        minutes = max(1, -(-vs.verify_timeout_seconds // 60))
        intro = tx["admin_intro" if vs.verify_method == "admin" else "intro"]
        return (f"{tx['title']}\n{intro.format(mention=mention, minutes=minutes)} {tx[vs.verify_failure]}\n"
                f"{html.escape(puzzle.question, quote=False)}")

    # ------------------------------------------------------------------ answer (callback)
    async def answer(self, group_id: int, challenge_id: int, presser_id: int, value: str) -> AnswerOutcome:
        """Resolve a button press. `group_id` MUST be the chat the pressed message is in (never taken from the callback data)."""
        loaded = await self._load(group_id)
        lang = loaded[1] if loaded else self._language
        tx = TEXTS.get(lang, TEXTS["ar"])
        if loaded is None or not await self._license_ok(group_id):
            return AnswerOutcome("unavailable", tx["unavailable"], True)
        vs = loaded[0]
        try:
            row = await self._store.get(group_id, challenge_id)
        except Exception:
            return AnswerOutcome("unavailable", tx["unavailable"], True)
        if row is None or not row.is_pending:
            return AnswerOutcome("gone", tx["gone"], True)
        if row.kind is ChallengeKind.ADMIN:
            return await self._admin_answer(row, presser_id, value, tx)
        if presser_id != row.user_id:
            return AnswerOutcome("not_yours", tx["not_yours"], True)
        now = self._clock()
        if row.is_due(now):
            await self._finish_failed(row, ChallengeStatus.EXPIRED)
            return AnswerOutcome("expired", tx["expired"], True)
        if value == row.answer:
            done = await self._store.resolve(group_id, challenge_id, ChallengeStatus.PASSED, now, presser_id)
            if done is None:
                return AnswerOutcome("gone", tx["gone"], True)
            await self._delete_prompt(done)
            if not (await self._actions.unmute_member(group_id, row.user_id)).ok:
                log.warning("verified member could not be unmuted", extra={"group_id": group_id})
                return self._success("passed_unmute_failed", tx["passed_unmute_failed"], True, row)
            return self._success("passed", tx["passed"], False, row)
        attempts = await self._store.record_attempt(group_id, challenge_id)
        if attempts is None:
            return AnswerOutcome("gone", tx["gone"], True)
        limit = min(vs.verify_max_attempts, MAX_GUESS_ATTEMPTS)
        if attempts >= limit:
            await self._finish_failed(row, ChallengeStatus.FAILED)
            return AnswerOutcome("failed", tx["failed"], True)
        return AnswerOutcome("wrong", tx["wrong"].format(left=limit - attempts), True)

    async def _admin_answer(self, row: Challenge, presser_id: int, value: str, tx: dict) -> AnswerOutcome:
        group = row.group_id
        if value not in (APPROVE, REJECT):
            return AnswerOutcome("gone", tx["gone"], True)
        try:
            decision = await self._perm.check(presser_id, group, Permission.MODERATE, context_chat_id=group,
                                              audit_denial=False)
        except Exception:
            return AnswerOutcome("unavailable", tx["unavailable"], True)
        if not decision.allowed or presser_id == row.user_id:
            return AnswerOutcome("not_admin", tx["not_admin"], True)
        now = self._clock()
        if row.is_due(now):
            await self._finish_failed(row, ChallengeStatus.EXPIRED)
            return AnswerOutcome("expired", tx["expired"], True)
        if value == APPROVE:
            done = await self._store.resolve(group, row.id, ChallengeStatus.APPROVED, now, presser_id)
            if done is None:
                return AnswerOutcome("gone", tx["gone"], True)
            await self._delete_prompt(done)
            if not (await self._actions.unmute_member(group, row.user_id)).ok:
                log.warning("approved member could not be unmuted", extra={"group_id": group})
                return self._success("passed_unmute_failed", tx["passed_unmute_failed"], True, row)
            return self._success("approved", tx["approved"], False, row)
        if await self._finish_failed(row, ChallengeStatus.REJECTED, presser_id):
            return AnswerOutcome("rejected", tx["rejected"], False)
        return AnswerOutcome("gone", tx["gone"], True)

    # ------------------------------------------------------------------ leave
    async def on_leave(self, ctx: ProtectionContext, user_id: int | None) -> bool:
        """The member left: cancel their pending challenge (no restriction/punishment to apply)."""
        if not ctx.allowed or ctx.chat_id is None or not _valid_id(user_id):
            return False
        try:
            row = await self._store.get_pending(ctx.chat_id, user_id)
        except Exception:
            return False
        return await self._cancel(row) if row is not None else False

    # ------------------------------------------------------------------ expiry
    async def tick(self) -> int:
        """Throttled sweep for the update middleware. Never raises; at most one sweep runs at a time."""
        now = self._mono()
        if self._sweeping or now - self._last_sweep < SWEEP_INTERVAL:
            return 0
        self._last_sweep = now
        self._sweeping = True
        try:
            return await self.sweep()
        except Exception:
            log.error("verification sweep failed", exc_info=True)
            return 0
        finally:
            self._sweeping = False

    async def sweep(self, limit: int = SWEEP_BATCH) -> int:
        """Resolve challenges whose deadline passed (cross-group read; the license is checked per group)."""
        try:
            due = await self._store.list_due(self._clock(), limit)
        except Exception:
            log.warning("verification sweep: store unavailable")
            return 0
        handled = 0
        licensed: dict[int, bool] = {}
        for row in due:
            if row.group_id not in licensed:
                licensed[row.group_id] = await self._license_ok(row.group_id)
            if not licensed[row.group_id]:
                continue  # license ended: no automatic action; the row waits
            if await self._finish_failed(row, ChallengeStatus.EXPIRED):
                handled += 1
        return handled

    def _timer(self, group: int, challenge_id: int) -> Callable[[], Awaitable[None]]:
        async def run() -> None:
            if not await self._license_ok(group):
                return
            try:
                row = await self._store.get(group, challenge_id)
            except Exception:
                return
            if row is not None and row.is_due(self._clock()):
                await self._finish_failed(row, ChallengeStatus.EXPIRED)

        return run

    async def _finish_failed(self, row: Challenge, status: ChallengeStatus, resolved_by: int | None = None) -> bool:
        """FAILED/EXPIRED -> failure action, unless the member is exempt now or the group is in dry_run (then CANCELLED +
        unmute). Uncertain (lookup/settings error) => leave the row pending. False when nothing was resolved."""
        group = row.group_id
        loaded = await self._load(group)
        if loaded is None:
            return False
        try:
            exempt = await self._perm.is_exempt_from_automation(row.user_id, group) or await self._perm.is_trusted(
                row.user_id, group)
        except Exception:
            return False
        if exempt or loaded[2]:
            if await self._cancel(row):
                await self._actions.unmute_member(group, row.user_id)
                return True
            return False
        done = await self._store.resolve(group, row.id, status, self._clock(), resolved_by)
        if done is None:
            return False  # another worker handled it
        await self._delete_prompt(done)
        if done.failure_action is FailureAction.KICK:
            res = await self._actions.kick_member(group, done.user_id)
        elif done.failure_action is FailureAction.BAN:
            seconds = done.ban_seconds or 3600
            res = await self._actions.ban_member(group, done.user_id, self._clock() + timedelta(seconds=seconds))
        else:
            return True  # restrict: the member simply stays muted
        if not res.ok:
            log.warning("verification failure action did not complete (%s)", res.error, extra={"group_id": group})
        return True

    # ------------------------------------------------------------------ internals
    async def _cancel(self, row: Challenge) -> bool:
        try:
            done = await self._store.resolve(row.group_id, row.id, ChallengeStatus.CANCELLED, self._clock())
        except Exception:
            return False
        if done is not None:
            await self._delete_prompt(done)
        return done is not None

    async def _delete_prompt(self, row: Challenge) -> None:
        if row.prompt_message_id:
            await self._actions.delete_message(row.group_id, row.prompt_message_id)  # best effort

    async def _license_ok(self, group: int) -> bool:
        try:
            return bool((await self._licenses.check(group, self._clock())).allowed)
        except Exception:
            return False

    async def _load(self, group: int) -> tuple[VerificationSettings, str, bool] | None:
        try:
            row = await self._settings.get(group)
        except Exception:
            log.warning("verification settings unavailable", extra={"group_id": group})
            return None
        raw = row.settings if row is not None and isinstance(row.settings, dict) else {}
        lang = row.language if row is not None and row.language in SUPPORTED else self._language
        return VerificationSettings.from_raw(raw), lang, raw.get("dry_run") is True

    async def aclose(self) -> None:
        for task in list(self._tasks):
            task.cancel()
        if self._tasks:
            await asyncio.gather(*self._tasks, return_exceptions=True)
        self._tasks.clear()

    def _default_schedule(self, delay: float, job: Callable[[], Awaitable[None]]) -> bool:
        if len(self._tasks) >= MAX_PENDING_TIMERS:
            return False  # the sweeper still resolves it

        async def runner() -> None:
            await self._sleep(delay)
            await job()

        try:
            task = asyncio.get_running_loop().create_task(runner())
        except RuntimeError:
            return False
        self._tasks.add(task)
        task.add_done_callback(self._task_done)
        return True

    def _task_done(self, task: asyncio.Task) -> None:
        self._tasks.discard(task)
        if not task.cancelled() and task.exception() is not None:
            log.warning("verification timer failed", exc_info=task.exception())
