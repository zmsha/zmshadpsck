"""Persistence contracts for the new-member tools. Group-scoped methods take group_id and never return rows of
another group. The ONE cross-group read is `ChallengeStore.list_due` (the expiry sweeper); the sweeper must check
each group's license before acting."""
from __future__ import annotations

from datetime import datetime
from typing import Protocol

from .models import Challenge, ChallengeKind, ChallengeStatus, FailureAction, TrustedBot


class ChallengeStore(Protocol):
    async def create(
        self, group_id: int, user_id: int, kind: ChallengeKind, answer: str | None, failure_action: FailureAction,
        ban_seconds: int | None, now: datetime, expires_at: datetime, idempotency_key: str,
    ) -> tuple[Challenge, bool]:
        """Idempotent. Same (group, key) -> (existing, False). A different key while the member already has a
        PENDING challenge in this group -> (that pending one, False). Otherwise (new, True)."""
        ...

    async def get(self, group_id: int, challenge_id: int) -> Challenge | None: ...

    async def get_pending(self, group_id: int, user_id: int) -> Challenge | None: ...

    async def set_prompt_message(self, group_id: int, challenge_id: int, message_id: int) -> bool:
        """Only while pending. False when not pending / unknown."""
        ...

    async def record_attempt(self, group_id: int, challenge_id: int) -> int | None:
        """Atomically +1 and return the new count; None when the challenge is not pending."""
        ...

    async def resolve(
        self, group_id: int, challenge_id: int, status: ChallengeStatus, now: datetime, resolved_by: int | None = None,
    ) -> Challenge | None:
        """Compare-and-set from PENDING only. Returns the resolved row, or None when it was already resolved or
        unknown (the caller must then do nothing: another worker/redelivery handled it). `status` must not be PENDING."""
        ...

    async def recent_unsuccessful(self, group_id: int, user_id: int, since: datetime) -> int:
        """How many of this member's challenges in this group ended FAILED / EXPIRED / REJECTED at or after `since`
        (anti-rejoin evidence; passed/approved/cancelled never count)."""
        ...

    async def list_pending(self, group_id: int) -> list[Challenge]: ...

    async def list_due(self, now: datetime, limit: int) -> list[Challenge]:
        """Cross-group, oldest deadline first (sweeper only)."""
        ...

    async def purge_resolved(self, before: datetime) -> int:
        """Delete resolved rows resolved before `before`; returns the number removed."""
        ...


class BotTrustStore(Protocol):
    async def add(self, group_id: int, bot_id: int, added_by: int, note: str | None, now: datetime) -> bool: ...

    async def remove(self, group_id: int, bot_id: int) -> bool: ...

    async def is_trusted(self, group_id: int, bot_id: int) -> bool: ...

    async def list(self, group_id: int) -> list[TrustedBot]: ...
