"""Pure entities of the new-member tools (no I/O). Every entity carries its group_id."""
from __future__ import annotations

import enum
from dataclasses import dataclass
from datetime import datetime

from ..time_utils import ensure_utc


class ChallengeKind(str, enum.Enum):
    BUTTON = "button"  # press "I am human"
    MATH = "math"      # simple arithmetic question, answer picked from buttons
    CHOICE = "choice"  # pick the matching symbol from buttons (no images: Pillow is not available)
    ADMIN = "admin"    # an admin approves/rejects


class ChallengeStatus(str, enum.Enum):
    PENDING = "pending"
    PASSED = "passed"        # member solved the challenge
    FAILED = "failed"        # too many wrong attempts
    EXPIRED = "expired"      # deadline passed
    APPROVED = "approved"    # admin approved (kind=admin)
    REJECTED = "rejected"    # admin rejected (kind=admin)
    CANCELLED = "cancelled"  # member left / became exempt / license stopped


class FailureAction(str, enum.Enum):
    RESTRICT = "restrict"  # keep the member muted
    KICK = "kick"          # remove (can rejoin)
    BAN = "ban"            # temporary ban (ban_seconds)


@dataclass(frozen=True, slots=True)
class Challenge:
    id: int
    group_id: int
    user_id: int
    kind: ChallengeKind
    status: ChallengeStatus
    failure_action: FailureAction
    created_at: datetime
    expires_at: datetime
    idempotency_key: str
    answer: str | None = None
    attempts: int = 0
    ban_seconds: int | None = None
    prompt_message_id: int | None = None
    resolved_at: datetime | None = None
    resolved_by: int | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "created_at", ensure_utc(self.created_at))
        object.__setattr__(self, "expires_at", ensure_utc(self.expires_at))
        if self.resolved_at is not None:
            object.__setattr__(self, "resolved_at", ensure_utc(self.resolved_at))

    @property
    def is_pending(self) -> bool:
        return self.status is ChallengeStatus.PENDING

    def is_due(self, now: datetime) -> bool:
        return self.is_pending and ensure_utc(now) >= self.expires_at


@dataclass(frozen=True, slots=True)
class TrustedBot:
    group_id: int
    bot_id: int
    added_by: int
    added_at: datetime
    note: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "added_at", ensure_utc(self.added_at))
