"""New-member restriction window (phase 4.5): who joined when, in process memory.

The policy (`NewMemberPolicy`, settings keys `newbie_*`) is enforced by `ProtectionEngine` (delete only, never a mute, no
offense): while a member is inside `newbie_seconds` of their join, their links / media / messages are deleted according to
the group's policy. This module only remembers join times.

Rules (tests cover each): recorded only when the license allows the group at that update, the policy is active, and the
member is neither exempt (owner / delegate / Telegram admin) nor trusted (`members/trust.RULE_NEWBIE`); a lookup failure
records nothing (uncertain => no restriction). Bots are not tracked. Keyed by group: no leakage between groups.

LIMIT (documented, not hidden): the join times live in process memory. A restart or a Render Free sleep forgets them, so a
newcomer's window then ends early (it can only become MORE lenient, never a wrong deletion).
"""
from __future__ import annotations

import logging
from collections import OrderedDict
from datetime import datetime
from typing import Any, Callable, Sequence

from ..groups.store import SettingsStore
from ..protection_gate import ProtectionContext
from ..time_utils import ensure_utc, utcnow
from .settings import NewMemberPolicy
from .welcome import Joined, _valid_id

log = logging.getLogger(__name__)

MAX_TRACKED = 20_000


class NewcomerTracker:
    def __init__(self, max_entries: int = MAX_TRACKED):
        self._max = max_entries
        self._joined: "OrderedDict[tuple[int, int], datetime]" = OrderedDict()

    def record(self, group_id: int, user_id: int, at: datetime) -> None:
        key = (group_id, user_id)
        self._joined[key] = ensure_utc(at)
        self._joined.move_to_end(key)
        while len(self._joined) > self._max:
            self._joined.popitem(last=False)

    def joined_at(self, group_id: int, user_id: int) -> datetime | None:
        return self._joined.get((group_id, user_id))

    def forget(self, group_id: int, user_id: int) -> None:
        self._joined.pop((group_id, user_id), None)


class NewcomerService:
    def __init__(self, settings_store: SettingsStore, permissions: Any, tracker: NewcomerTracker,
                 *, clock: Callable[[], datetime] = utcnow):
        self._settings = settings_store
        self._perm = permissions
        self.tracker = tracker
        self._clock = clock

    async def on_join(self, ctx: ProtectionContext, joined: Sequence[Joined]) -> int:
        """Start the restriction window for the humans who just joined. Returns how many were recorded."""
        if not ctx.allowed or ctx.chat_id is None:
            return 0
        try:
            row = await self._settings.get(ctx.chat_id)
        except Exception:
            log.warning("newcomer settings unavailable", extra={"group_id": ctx.chat_id})
            return 0
        policy = NewMemberPolicy.from_raw(row.settings if row is not None and isinstance(row.settings, dict) else None)
        if not policy.active:
            return 0
        n = 0
        for m in joined:
            if not isinstance(m, Joined) or m.is_bot or not _valid_id(m.user_id):
                continue
            try:
                skip = await self._perm.is_exempt_from_automation(m.user_id, ctx.chat_id) or await self._perm.is_trusted(
                    m.user_id, ctx.chat_id)
            except Exception:
                continue  # uncertain => do not restrict
            if skip:
                self.tracker.forget(ctx.chat_id, m.user_id)
                continue
            self.tracker.record(ctx.chat_id, m.user_id, self._clock())
            n += 1
        return n
