"""PostgreSQL implementations (NOT executed against a real PostgreSQL in the build sandbox). Every group-scoped
statement filters by group_id. State changes are single compare-and-set statements (no read-then-write races)."""
from __future__ import annotations

from .models import Challenge, ChallengeKind, ChallengeStatus, FailureAction, TrustedBot

_COLS = ("id, group_id, user_id, kind, status, answer, attempts, failure_action, ban_seconds, prompt_message_id, "
         "created_at, expires_at, resolved_at, resolved_by, idempotency_key")


def _challenge(row) -> Challenge:
    return Challenge(
        id=row["id"], group_id=row["group_id"], user_id=row["user_id"], kind=ChallengeKind(row["kind"]),
        status=ChallengeStatus(row["status"]), failure_action=FailureAction(row["failure_action"]),
        created_at=row["created_at"], expires_at=row["expires_at"], idempotency_key=row["idempotency_key"],
        answer=row["answer"], attempts=row["attempts"], ban_seconds=row["ban_seconds"],
        prompt_message_id=row["prompt_message_id"], resolved_at=row["resolved_at"], resolved_by=row["resolved_by"],
    )


class PostgresChallengeStore:
    def __init__(self, database) -> None:
        self._db = database

    async def create(self, group_id, user_id, kind, answer, failure_action, ban_seconds, now, expires_at, idempotency_key):
        if expires_at <= now:
            raise ValueError("expires_at must be after now")
        fa = FailureAction(failure_action)
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "INSERT INTO member_verifications (group_id, user_id, kind, answer, failure_action, ban_seconds, "
                "created_at, expires_at, idempotency_key) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) "
                "ON CONFLICT DO NOTHING RETURNING " + _COLS,
                group_id, user_id, ChallengeKind(kind).value, answer, fa.value,
                ban_seconds if fa is FailureAction.BAN else None, now, expires_at, idempotency_key,
            )
            if row is not None:
                return _challenge(row), True
            # Conflict: same (group, key) redelivery, or a pending challenge for this member already exists.
            existing = await conn.fetchrow(
                "SELECT " + _COLS + " FROM member_verifications WHERE group_id = $1 AND idempotency_key = $2",
                group_id, idempotency_key,
            )
            if existing is None:
                existing = await conn.fetchrow(
                    "SELECT " + _COLS + " FROM member_verifications "
                    "WHERE group_id = $1 AND user_id = $2 AND status = 'pending'",
                    group_id, user_id,
                )
        if existing is None:  # the pending row was resolved between the two statements: let the caller retry
            raise RuntimeError("challenge create raced with a resolution; retry")
        return _challenge(existing), False

    async def get(self, group_id, challenge_id):
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT " + _COLS + " FROM member_verifications WHERE group_id = $1 AND id = $2", group_id, challenge_id
            )
        return None if row is None else _challenge(row)

    async def get_pending(self, group_id, user_id):
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT " + _COLS + " FROM member_verifications "
                "WHERE group_id = $1 AND user_id = $2 AND status = 'pending'", group_id, user_id
            )
        return None if row is None else _challenge(row)

    async def set_prompt_message(self, group_id, challenge_id, message_id) -> bool:
        if message_id <= 0:
            return False
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "UPDATE member_verifications SET prompt_message_id = $3 "
                "WHERE group_id = $1 AND id = $2 AND status = 'pending' RETURNING id", group_id, challenge_id, message_id
            )
        return row is not None

    async def record_attempt(self, group_id, challenge_id):
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "UPDATE member_verifications SET attempts = attempts + 1 "
                "WHERE group_id = $1 AND id = $2 AND status = 'pending' AND attempts < 20 RETURNING attempts",
                group_id, challenge_id,
            )
        return None if row is None else row["attempts"]

    async def resolve(self, group_id, challenge_id, status, now, resolved_by=None):
        status = ChallengeStatus(status)
        if status is ChallengeStatus.PENDING:
            raise ValueError("cannot resolve to pending")
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "UPDATE member_verifications SET status = $3, resolved_at = $4, resolved_by = $5 "
                "WHERE group_id = $1 AND id = $2 AND status = 'pending' RETURNING " + _COLS,
                group_id, challenge_id, status.value, now, resolved_by,
            )
        return None if row is None else _challenge(row)

    async def list_pending(self, group_id):
        async with self._db.acquire() as conn:
            rows = await conn.fetch(
                "SELECT " + _COLS + " FROM member_verifications WHERE group_id = $1 AND status = 'pending' "
                "ORDER BY expires_at, id", group_id
            )
        return [_challenge(r) for r in rows]

    async def recent_unsuccessful(self, group_id, user_id, since) -> int:
        async with self._db.acquire() as conn:
            n = await conn.fetchval(
                "SELECT count(*) FROM member_verifications WHERE group_id = $1 AND user_id = $2 "
                "AND status IN ('failed', 'expired', 'rejected') AND resolved_at >= $3", group_id, user_id, since)
        return int(n or 0)

    async def list_due(self, now, limit):
        async with self._db.acquire() as conn:
            rows = await conn.fetch(
                "SELECT " + _COLS + " FROM member_verifications WHERE status = 'pending' AND expires_at <= $1 "
                "ORDER BY expires_at, id LIMIT $2", now, max(limit, 0)
            )
        return [_challenge(r) for r in rows]

    async def purge_resolved(self, before) -> int:
        async with self._db.acquire() as conn:
            rows = await conn.fetch(
                "DELETE FROM member_verifications WHERE status <> 'pending' AND resolved_at < $1 RETURNING id", before
            )
        return len(rows)


class PostgresBotTrustStore:
    def __init__(self, database) -> None:
        self._db = database

    async def add(self, group_id, bot_id, added_by, note, now) -> bool:
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "INSERT INTO group_trusted_bots (group_id, bot_id, added_by, added_at, note) "
                "VALUES ($1, $2, $3, $4, $5) ON CONFLICT (group_id, bot_id) DO NOTHING RETURNING bot_id",
                group_id, bot_id, added_by, now, note,
            )
        return row is not None

    async def remove(self, group_id, bot_id) -> bool:
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "DELETE FROM group_trusted_bots WHERE group_id = $1 AND bot_id = $2 RETURNING bot_id", group_id, bot_id
            )
        return row is not None

    async def is_trusted(self, group_id, bot_id) -> bool:
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT 1 AS ok FROM group_trusted_bots WHERE group_id = $1 AND bot_id = $2", group_id, bot_id
            )
        return row is not None

    async def list(self, group_id):
        async with self._db.acquire() as conn:
            rows = await conn.fetch(
                "SELECT group_id, bot_id, added_by, added_at, note FROM group_trusted_bots "
                "WHERE group_id = $1 ORDER BY added_at, bot_id", group_id
            )
        return [TrustedBot(r["group_id"], r["bot_id"], r["added_by"], r["added_at"], r["note"]) for r in rows]
