"""Report service (part 6.3): create, list, take, resolve, dismiss.

Scope: persistence and the state machine only. WHO may call these methods is decided by the caller (the `/report`
command today; the management commands and the panel in part 6.4 must check `Permission.MODERATE` first): there is no
command or button in this part, so nothing here is reachable by a user except the `/report` write path.

State machine:  open --take--> taken --resolve/dismiss--> resolved|dismissed      (open --resolve/dismiss--> too)
Closed reports never reopen. Every move is one compare-and-set in the store, so two admins racing cannot both win;
the loser gets `ALREADY_TAKEN`/`CLOSED`. Repeating the SAME move by the SAME actor is `UNCHANGED` (no audit row).
"""
from __future__ import annotations

import enum
import logging
import re
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Callable, Sequence

from ..audit import (REPORT_DISMISSED, REPORT_RESOLVED, REPORT_TAKEN, REPORT_UPDATED, RESULT_APPLIED, SecurityAudit, make_event,
                     record_safely)
from ..auth import MAX_BIGINT
from ..errors import InvalidInput
from ..time_utils import utcnow
from ..trace import current_trace_id
from .models import (MAX_KEY_LEN, OPEN_STATUSES, Report, ReportOutcome, ReportPriority, ReportStatus, ReportType,
                     clean_reason)

log = logging.getLogger(__name__)

MAX_PAGE = 50
_KEY_RE = re.compile(r"^[A-Za-z0-9:_\-.]+$")
_RESOLVE_OUTCOMES = (ReportOutcome.ACTION_TAKEN, ReportOutcome.NO_ACTION)
_DISMISS_OUTCOMES = (ReportOutcome.NO_ACTION, ReportOutcome.FALSE_REPORT)


class TransitionCode(str, enum.Enum):
    OK = "ok"                        # the move was applied now
    UNCHANGED = "unchanged"          # already in that state by the same actor/outcome: nothing written
    NOT_FOUND = "not_found"          # no such report in THIS group
    ALREADY_TAKEN = "already_taken"  # another actor holds it
    CLOSED = "closed"                # already resolved/dismissed (differently)


@dataclass(frozen=True, slots=True)
class TransitionResult:
    code: TransitionCode
    report: Report | None = None

    @property
    def ok(self) -> bool:
        return self.code in (TransitionCode.OK, TransitionCode.UNCHANGED)


def _id(value: object, name: str, *, optional: bool = False) -> int | None:
    if value is None and optional:
        return None
    if not isinstance(value, int) or isinstance(value, bool) or not 0 < value <= MAX_BIGINT:
        raise InvalidInput(f"invalid {name}")
    return value


def _group(value: object) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or not -MAX_BIGINT <= value < 0:
        raise InvalidInput("invalid group_id")
    return value


def _enum(cls, value: object, name: str):
    try:
        return cls(value)
    except ValueError:
        raise InvalidInput(f"invalid {name}") from None


class ReportService:
    def __init__(self, store: Any, audit: SecurityAudit | None = None, clock: Callable[[], datetime] = utcnow):
        self._store, self._audit, self._clock = store, audit, clock

    # ------------------------------------------------------------------ create
    async def create(
        self, group_id: int, reporter_id: int, target_user_id: int, message_id: int | None = None,
        reason: str | None = None, report_type: ReportType | str = ReportType.OTHER,
        priority: ReportPriority | str = ReportPriority.NORMAL, idempotency_key: str | None = None,
    ) -> tuple[Report, bool]:
        """Store a new OPEN report. Returns (report, created); a repeated `idempotency_key` in the same group returns
        the existing report with created=False. The audit entry for filing is written by the `/report` command (it
        also covers the notification), so this method writes none."""
        group_id = _group(group_id)
        reporter_id, target_user_id = _id(reporter_id, "reporter_id"), _id(target_user_id, "target_user_id")
        message_id = _id(message_id, "message_id", optional=True)
        report_type, priority = _enum(ReportType, report_type, "type"), _enum(ReportPriority, priority, "priority")
        if idempotency_key is not None and (not isinstance(idempotency_key, str) or not 0 < len(idempotency_key) <= MAX_KEY_LEN
                                            or not _KEY_RE.match(idempotency_key)):
            raise InvalidInput("invalid idempotency key")
        return await self._store.add(group_id, reporter_id, target_user_id, message_id, clean_reason(reason),
                                     report_type, priority, self._clock(), current_trace_id(), idempotency_key)

    # ------------------------------------------------------------------ read
    async def get(self, group_id: int, report_id: int) -> Report | None:
        return await self._store.get(_group(group_id), _id(report_id, "report_id"))

    async def list_reports(self, group_id: int, statuses: Sequence[ReportStatus] | None = None, limit: int = 20,
                           before_id: int | None = None) -> list[Report]:
        """Newest first. `limit` is clamped to 1..MAX_PAGE; `before_id` pages (only ids below it)."""
        if statuses is not None:
            statuses = tuple(_enum(ReportStatus, s, "status") for s in statuses)
        if isinstance(limit, bool) or not isinstance(limit, int):
            raise InvalidInput("invalid limit")
        return await self._store.list_reports(_group(group_id), statuses, min(max(limit, 1), MAX_PAGE),
                                              _id(before_id, "before_id", optional=True))

    async def list_open(self, group_id: int, limit: int = 20, before_id: int | None = None) -> list[Report]:
        return await self.list_reports(group_id, OPEN_STATUSES, limit, before_id)

    async def count(self, group_id: int, statuses: Sequence[ReportStatus] | None = None) -> int:
        if statuses is not None:
            statuses = tuple(_enum(ReportStatus, s, "status") for s in statuses)
        return await self._store.count(_group(group_id), statuses)

    # ------------------------------------------------------------------ moves
    async def take(self, group_id: int, report_id: int, actor_id: int) -> TransitionResult:
        group_id, report_id, actor_id = _group(group_id), _id(report_id, "report_id"), _id(actor_id, "actor_id")
        moved = await self._store.transition(group_id, report_id, (ReportStatus.OPEN,), ReportStatus.TAKEN, actor_id,
                                             self._clock())
        if moved is not None:
            await self._audit_move(REPORT_TAKEN, moved, actor_id, "status=taken")
            return TransitionResult(TransitionCode.OK, moved)
        current = await self._store.get(group_id, report_id)
        if current is None:
            return TransitionResult(TransitionCode.NOT_FOUND)
        if current.status is ReportStatus.TAKEN:
            same = current.assigned_to == actor_id
            return TransitionResult(TransitionCode.UNCHANGED if same else TransitionCode.ALREADY_TAKEN, current)
        return TransitionResult(TransitionCode.CLOSED, current)

    async def resolve(self, group_id: int, report_id: int, actor_id: int,
                      outcome: ReportOutcome | str = ReportOutcome.ACTION_TAKEN) -> TransitionResult:
        return await self._close(group_id, report_id, actor_id, ReportStatus.RESOLVED, outcome, _RESOLVE_OUTCOMES,
                                 REPORT_RESOLVED)

    async def dismiss(self, group_id: int, report_id: int, actor_id: int,
                      outcome: ReportOutcome | str = ReportOutcome.NO_ACTION) -> TransitionResult:
        return await self._close(group_id, report_id, actor_id, ReportStatus.DISMISSED, outcome, _DISMISS_OUTCOMES,
                                 REPORT_DISMISSED)

    async def set_type(self, group_id: int, report_id: int, actor_id: int, report_type: ReportType | str) -> TransitionResult:
        """Part 6.4a: reclassify an OPEN/TAKEN report. Same value = UNCHANGED (nothing written, no audit); a closed
        report is never edited (CLOSED)."""
        return await self._reclassify(group_id, report_id, actor_id, "report_type",
                                      _enum(ReportType, report_type, "type"))

    async def set_priority(self, group_id: int, report_id: int, actor_id: int,
                           priority: ReportPriority | str) -> TransitionResult:
        return await self._reclassify(group_id, report_id, actor_id, "priority",
                                      _enum(ReportPriority, priority, "priority"))

    async def _reclassify(self, group_id, report_id, actor_id, field: str, value) -> TransitionResult:
        group_id, report_id, actor_id = _group(group_id), _id(report_id, "report_id"), _id(actor_id, "actor_id")
        moved = await self._store.set_meta(group_id, report_id, field, value.value, self._clock())
        if moved is not None:
            label = "type" if field == "report_type" else "priority"
            await self._audit_move(REPORT_UPDATED, moved, actor_id, f"{label}={value.value}")
            return TransitionResult(TransitionCode.OK, moved)
        current = await self._store.get(group_id, report_id)
        if current is None:
            return TransitionResult(TransitionCode.NOT_FOUND)
        if not current.is_open:
            return TransitionResult(TransitionCode.CLOSED, current)
        return TransitionResult(TransitionCode.UNCHANGED, current)  # open and already has that value

    async def _close(self, group_id, report_id, actor_id, status: ReportStatus, outcome, allowed, event) -> TransitionResult:
        group_id, report_id, actor_id = _group(group_id), _id(report_id, "report_id"), _id(actor_id, "actor_id")
        outcome = _enum(ReportOutcome, outcome, "outcome")
        if outcome not in allowed:
            raise InvalidInput("outcome not allowed for this action")
        moved = await self._store.transition(group_id, report_id, OPEN_STATUSES, status, actor_id, self._clock(), outcome)
        if moved is not None:
            await self._audit_move(event, moved, actor_id, f"status={status.value} outcome={outcome.value}")
            return TransitionResult(TransitionCode.OK, moved)
        current = await self._store.get(group_id, report_id)
        if current is None:
            return TransitionResult(TransitionCode.NOT_FOUND)
        if current.status is status and current.handled_by == actor_id and current.outcome is outcome:
            return TransitionResult(TransitionCode.UNCHANGED, current)
        return TransitionResult(TransitionCode.CLOSED, current)

    async def _audit_move(self, event: str, report: Report, actor_id: int, detail: str) -> None:
        # ids and closed vocabulary only: never the reporter's text
        await record_safely(self._audit, make_event(
            event, actor=actor_id, group_id=report.group_id, now=report.updated_at, target=report.id,
            result=RESULT_APPLIED, detail=detail))
