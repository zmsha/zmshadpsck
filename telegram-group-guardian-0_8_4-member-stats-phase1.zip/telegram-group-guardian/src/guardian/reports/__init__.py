"""Report store (Phase 6 / part 6.3): persistence + state machine of member reports (`/report`).

No commands, no panel screens and no authorization decisions live here: those arrive with part 6.4. The service only
guarantees group isolation, closed vocabularies, valid status transitions and idempotency.
"""
from .models import (  # noqa: F401
    CLOSED_STATUSES, OPEN_STATUSES, Report, ReportOutcome, ReportPriority, ReportStatus, ReportType, clean_reason,
)
from .service import ReportService, TransitionCode, TransitionResult  # noqa: F401
