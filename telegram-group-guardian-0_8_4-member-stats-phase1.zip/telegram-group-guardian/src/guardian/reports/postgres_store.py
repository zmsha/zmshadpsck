"""PostgreSQL report store (NOT executed against a real PostgreSQL in the build sandbox). Every statement filters by
group_id (or inserts it as $1). The transition is ONE compare-and-set UPDATE (status guard in the WHERE clause)."""
from __future__ import annotations

from ..errors import InvalidInput
from .models import (CLOSED_STATUSES, META_FIELDS, Report, ReportOutcome, ReportPriority, ReportStatus,
                     ReportType)

_COLS = ("id, group_id, reporter_id, target_user_id, message_id, reason, report_type, priority, status, created_at, "
         "updated_at, assigned_to, outcome, handled_by, handled_at, trace_id, idempotency_key")


def _report(r) -> Report:
    return Report(
        id=r["id"], group_id=r["group_id"], reporter_id=r["reporter_id"], target_user_id=r["target_user_id"],
        message_id=r["message_id"], reason=r["reason"], report_type=ReportType(r["report_type"]),
        priority=ReportPriority(r["priority"]), status=ReportStatus(r["status"]), created_at=r["created_at"],
        updated_at=r["updated_at"], assigned_to=r["assigned_to"],
        outcome=ReportOutcome(r["outcome"]) if r["outcome"] is not None else None, handled_by=r["handled_by"],
        handled_at=r["handled_at"], trace_id=r["trace_id"], idempotency_key=r["idempotency_key"])


class PostgresReportStore:
    def __init__(self, database) -> None:
        self._db = database

    async def add(self, group_id, reporter_id, target_user_id, message_id, reason, report_type, priority, now,
                  trace_id=None, idempotency_key=None):
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "INSERT INTO group_reports (group_id, reporter_id, target_user_id, message_id, reason, report_type, "
                "priority, created_at, updated_at, trace_id, idempotency_key) "
                "VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $8, $9, $10) "
                "ON CONFLICT (group_id, idempotency_key) WHERE idempotency_key IS NOT NULL DO NOTHING "
                f"RETURNING {_COLS}",
                group_id, reporter_id, target_user_id, message_id, reason, ReportType(report_type).value,
                ReportPriority(priority).value, now, trace_id, idempotency_key)
            if row is not None:
                return _report(row), True
            existing = await conn.fetchrow(
                f"SELECT {_COLS} FROM group_reports WHERE group_id = $1 AND idempotency_key = $2",
                group_id, idempotency_key)
        if existing is None:  # pragma: no cover - a conflict implies the row exists
            raise InvalidInput("report could not be recorded")
        return _report(existing), False

    async def get(self, group_id, report_id):
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                f"SELECT {_COLS} FROM group_reports WHERE group_id = $1 AND id = $2", group_id, report_id)
        return _report(row) if row is not None else None

    async def list_reports(self, group_id, statuses, limit, before_id=None):
        values = None if statuses is None else [ReportStatus(s).value for s in statuses]
        async with self._db.acquire() as conn:
            rows = await conn.fetch(
                f"SELECT {_COLS} FROM group_reports WHERE group_id = $1 "
                "AND ($2::text[] IS NULL OR status = ANY($2::text[])) AND ($3::bigint IS NULL OR id < $3) "
                "ORDER BY id DESC LIMIT $4",
                group_id, values, before_id, max(0, int(limit)))
        return [_report(r) for r in rows]

    async def count(self, group_id, statuses) -> int:
        values = None if statuses is None else [ReportStatus(s).value for s in statuses]
        async with self._db.acquire() as conn:
            value = await conn.fetchval(
                "SELECT count(*) FROM group_reports WHERE group_id = $1 "
                "AND ($2::text[] IS NULL OR status = ANY($2::text[]))", group_id, values)
        return int(value or 0)

    async def count_in_range(self, group_id, start, end) -> dict[str, int]:
        async with self._db.acquire() as conn:
            created = await conn.fetch(
                "SELECT report_type, count(*) AS n FROM group_reports "
                "WHERE group_id = $1 AND created_at >= $2 AND created_at < $3 GROUP BY report_type",
                group_id, start, end)
            handled = await conn.fetch(
                "SELECT outcome, count(*) AS n FROM group_reports "
                "WHERE group_id = $1 AND handled_at >= $2 AND handled_at < $3 GROUP BY outcome",
                group_id, start, end)
        out: dict[str, int] = {}
        total = 0
        for r in created:
            out[f"type_{r['report_type']}"] = int(r["n"] or 0)
            total += int(r["n"] or 0)
        out["created"] = total
        for r in handled:
            out[f"handled_{r['outcome']}"] = int(r["n"] or 0)
        return out

    async def transition(self, group_id, report_id, expected, new_status, actor, now, outcome=None):
        new_status = ReportStatus(new_status)
        expected_values = [ReportStatus(s).value for s in expected]
        async with self._db.acquire() as conn:
            if new_status is ReportStatus.TAKEN:
                row = await conn.fetchrow(
                    "UPDATE group_reports SET status = $3, assigned_to = $4, updated_at = $5 "
                    "WHERE group_id = $1 AND id = $2 AND status = ANY($6::text[]) "
                    f"RETURNING {_COLS}",
                    group_id, report_id, new_status.value, actor, now, expected_values)
            elif new_status in CLOSED_STATUSES:
                if outcome is None:
                    raise InvalidInput("a closed report needs an outcome")
                row = await conn.fetchrow(
                    "UPDATE group_reports SET status = $3, handled_by = $4, handled_at = $5, updated_at = $5, "
                    "outcome = $7 "
                    "WHERE group_id = $1 AND id = $2 AND status = ANY($6::text[]) "
                    f"RETURNING {_COLS}",
                    group_id, report_id, new_status.value, actor, now, expected_values, ReportOutcome(outcome).value)
            else:
                raise InvalidInput("unsupported transition")
        return _report(row) if row is not None else None

    # Fixed statements per field: a column name is never built from caller input.
    _META_SQL = {
        "report_type": ("UPDATE group_reports SET report_type = $3, updated_at = $4 "
                        "WHERE group_id = $1 AND id = $2 AND status IN ('open', 'taken') AND report_type <> $3 "
                        f"RETURNING {_COLS}"),
        "priority": ("UPDATE group_reports SET priority = $3, updated_at = $4 "
                     "WHERE group_id = $1 AND id = $2 AND status IN ('open', 'taken') AND priority <> $3 "
                     f"RETURNING {_COLS}"),
    }

    async def set_meta(self, group_id, report_id, field, value, now):
        if field not in META_FIELDS:
            raise InvalidInput("unsupported field")
        text = (ReportType if field == "report_type" else ReportPriority)(value).value
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(self._META_SQL[field], group_id, report_id, text, now)
        return _report(row) if row is not None else None
