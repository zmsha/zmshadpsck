"""Text rendering of one stored report (shared by `/reports`, `/report show` and the panel screen, parts 6.4a/6.4b).

Pure functions: no Telegram, no permissions. The caller decides WHERE the text may be shown (the approved destination).
A listing line never carries the reporter's text; the details do (that is why both are routed together).
"""
from __future__ import annotations

import html
from datetime import datetime

from ..i18n import t
from ..moderation.info_commands import clean_display, message_link
from ..time_utils import to_display_tz
from .models import Report

PRIORITY_ICON = {"low": "🔹", "normal": "🔸", "high": "🔴"}


def when(value: datetime, fmt: str, tz: str) -> str:
    try:
        return f"{to_display_tz(value, tz):{fmt}}"
    except Exception:
        return value.strftime(fmt)


def line(r: Report, lang: str, tz: str) -> str:
    return t("report_line", lang, id=r.id, icon=PRIORITY_ICON[r.priority.value],
             type=t(f"report_type_{r.report_type.value}", lang), status=t(f"report_status_{r.status.value}", lang),
             target=r.target_user_id, when=when(r.created_at, "%m-%d %H:%M", tz))


def details(r: Report, chat_id: int, lang: str, tz: str) -> str:
    reason = clean_display(r.reason, 200) or t("report_no_reason", lang)
    text = t("report_show", lang, id=r.id, status=t(f"report_status_{r.status.value}", lang),
             type=t(f"report_type_{r.report_type.value}", lang), priority=t(f"report_prio_{r.priority.value}", lang),
             reporter=r.reporter_id, target=r.target_user_id, reason=reason, when=when(r.created_at, "%Y-%m-%d %H:%M", tz))
    link = message_link(chat_id, r.message_id)
    if link:
        text += "\n" + f'<a href="{html.escape(link, quote=True)}">{html.escape(t("report_view_message", lang))}</a>'
    if r.assigned_to is not None and r.is_open:
        text += "\n" + t("report_show_taken_by", lang, holder=r.assigned_to)
    if r.handled_by is not None and r.outcome is not None and r.handled_at is not None:
        text += "\n" + t("report_show_handled", lang, handler=r.handled_by,
                         outcome=t(f"report_outcome_{r.outcome.value}", lang), when=when(r.handled_at, "%Y-%m-%d %H:%M", tz))
    return text
