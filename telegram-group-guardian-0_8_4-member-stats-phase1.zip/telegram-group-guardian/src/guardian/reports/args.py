"""Strict argument parsing of the report management commands (part 6.4a). Pure text logic: no Telegram, no permissions.

Two command families (English words and Arabic words are interchangeable after `fold_arabic`):

* `/report <action> <id> [word]` and `بلاغ <action> <id> [word]` (no reply) with
  `show|take|resolve|dismiss|type|priority` (عرض|استلام|حسم|رفض|نوع|أولوية).
  A `/report` that IS a reply is always a new report (its words are the reason), so a reason such as "take it down" can
  never be taken for a management action.
* `/reports [status] [before_id]` lists; `/reports destination [group|<chat id>]` shows or changes the approved destination.

Every unknown word is an error (`CommandError`), never silently ignored or taken as a reason: a mis-read `resolve` would
close somebody's report. Error codes `report_*` have localized messages `mod_err_<code>`.
"""
from __future__ import annotations

import enum
import re
from dataclasses import dataclass

from ..auth import MAX_BIGINT
from ..moderation.arabic import fold_arabic
from ..moderation.command_error import CommandError
from ..stats.args import PERIOD_WORDS
from ..stats.models import StatsPeriod
from .models import META_FIELDS, ReportOutcome, ReportPriority, ReportStatus, ReportType  # noqa: F401

MAX_ID_DIGITS = 18
_DIGITS = re.compile(r"^[0-9]{1,%d}$" % MAX_ID_DIGITS)
_CHAT_ID = re.compile(r"^-[0-9]{1,%d}$" % MAX_ID_DIGITS)


class ReportAction(str, enum.Enum):
    SHOW = "show"
    TAKE = "take"
    RESOLVE = "resolve"
    DISMISS = "dismiss"
    TYPE = "type"
    PRIORITY = "priority"


def _table(mapping: dict) -> dict[str, object]:
    out: dict[str, object] = {}
    for value, words in mapping.items():
        for word in words:
            out[fold_arabic(word)] = value
    return out


ACTION_WORDS = _table({
    ReportAction.SHOW: ("show", "view", "عرض", "تفاصيل"),
    ReportAction.TAKE: ("take", "استلام", "استلم"),
    ReportAction.RESOLVE: ("resolve", "حسم", "حل", "معالجة"),
    ReportAction.DISMISS: ("dismiss", "رفض", "تجاهل"),
    ReportAction.TYPE: ("type", "نوع"),
    ReportAction.PRIORITY: ("priority", "أولوية"),
})
TYPE_WORDS = _table({
    ReportType.SPAM: ("spam", "سبام", "مزعج"),
    ReportType.ABUSE: ("abuse", "إساءة"),
    ReportType.SCAM: ("scam", "احتيال", "نصب"),
    ReportType.OTHER: ("other", "أخرى", "آخر"),
})
PRIORITY_WORDS = _table({
    ReportPriority.LOW: ("low", "منخفضة", "منخفض"),
    ReportPriority.NORMAL: ("normal", "عادية", "عادي"),
    ReportPriority.HIGH: ("high", "عالية", "عالي", "مرتفعة", "مرتفع"),
})
RESOLVE_WORDS = _table({
    ReportOutcome.ACTION_TAKEN: ("action", "done", "إجراء", "تم"),
    ReportOutcome.NO_ACTION: ("none", "noaction", "no_action", "بدون"),
})
DISMISS_WORDS = _table({
    ReportOutcome.NO_ACTION: ("none", "noaction", "no_action", "بدون"),
    ReportOutcome.FALSE_REPORT: ("false", "كاذب", "كاذبة", "خاطئ"),
})
# `/reports` status filter: a tuple of statuses, or None for every status.
_OPEN = (ReportStatus.OPEN, ReportStatus.TAKEN)
_CLOSED = (ReportStatus.RESOLVED, ReportStatus.DISMISSED)
STATUS_WORDS = _table({
    "open": ("open", "pending", "مفتوحة", "مفتوح"),
    "taken": ("taken", "مستلمة", "مستلم"),
    "resolved": ("resolved", "محسومة", "محلولة"),
    "dismissed": ("dismissed", "مرفوضة"),
    "closed": ("closed", "مغلقة"),
    "all": ("all", "الكل"),
})
_STATUS_FILTER: dict[str, tuple[ReportStatus, ...] | None] = {
    "open": _OPEN, "taken": (ReportStatus.TAKEN,), "resolved": (ReportStatus.RESOLVED,),
    "dismissed": (ReportStatus.DISMISSED,), "closed": _CLOSED, "all": None,
}
def status_of(word: object) -> tuple[str, tuple[ReportStatus, ...] | None] | None:
    """A `/reports` status word -> (its key, the statuses it selects; None = every status), or None if it is not one."""
    key = STATUS_WORDS.get(fold_arabic(word)) if isinstance(word, str) else None
    return None if key is None else (key, _STATUS_FILTER[key])  # type: ignore[index]


DEST_WORDS = frozenset(fold_arabic(w) for w in ("destination", "dest", "وجهة", "الوجهة"))
GROUP_WORDS = frozenset(fold_arabic(w) for w in ("group", "here", "off", "المجموعة", "هنا", "إيقاف"))


@dataclass(frozen=True, slots=True)
class AdminArgs:
    action: ReportAction
    report_id: int
    outcome: ReportOutcome | None = None
    report_type: ReportType | None = None
    priority: ReportPriority | None = None


@dataclass(frozen=True, slots=True)
class ListArgs:
    status_key: str = "open"
    statuses: tuple[ReportStatus, ...] | None = _OPEN
    before_id: int | None = None


@dataclass(frozen=True, slots=True)
class DestArgs:
    op: str  # "show" | "group" | "set"
    chat_id: int | None = None


def _id(word: str) -> int:
    s = fold_arabic(word)
    if not _DIGITS.match(s) or not 0 < int(s) <= MAX_BIGINT:
        raise CommandError("report_id")
    return int(s)


def action_of(word: object) -> ReportAction | None:
    return ACTION_WORDS.get(fold_arabic(word)) if isinstance(word, str) else None  # type: ignore[return-value]


def looks_like_admin_form(args: tuple[str, ...] | list[str]) -> bool:
    """Used by the Arabic-alias parser: `بلاغ <action word> <number>` is intentional; anything else is ordinary chat."""
    return len(args) >= 2 and action_of(args[0]) is not None and bool(_DIGITS.match(fold_arabic(args[1])))


def is_admin_word(args: tuple[str, ...] | list[str]) -> bool:
    """First word is a management action (used by the executor for a `/report` that is not a reply)."""
    return bool(args) and action_of(args[0]) is not None


def parse_admin(args: tuple[str, ...] | list[str]) -> AdminArgs:
    words = list(args)
    action = action_of(words[0]) if words else None
    if action is None:
        raise CommandError("report_usage")
    if len(words) < 2:
        raise CommandError("report_id")
    report_id, rest = _id(words[1]), words[2:]
    if action in (ReportAction.SHOW, ReportAction.TAKE):
        if rest:
            raise CommandError("report_usage")
        return AdminArgs(action, report_id)
    if action in (ReportAction.RESOLVE, ReportAction.DISMISS):
        table = RESOLVE_WORDS if action is ReportAction.RESOLVE else DISMISS_WORDS
        default = ReportOutcome.ACTION_TAKEN if action is ReportAction.RESOLVE else ReportOutcome.NO_ACTION
        if len(rest) > 1:
            raise CommandError("report_usage")
        if not rest:
            return AdminArgs(action, report_id, outcome=default)
        outcome = table.get(fold_arabic(rest[0]))
        if outcome is None:
            raise CommandError("report_outcome")
        return AdminArgs(action, report_id, outcome=outcome)  # type: ignore[arg-type]
    if len(rest) != 1:
        raise CommandError("report_type" if action is ReportAction.TYPE else "report_priority")
    if action is ReportAction.TYPE:
        value = TYPE_WORDS.get(fold_arabic(rest[0]))
        if value is None:
            raise CommandError("report_type")
        return AdminArgs(action, report_id, report_type=value)  # type: ignore[arg-type]
    value = PRIORITY_WORDS.get(fold_arabic(rest[0]))
    if value is None:
        raise CommandError("report_priority")
    return AdminArgs(action, report_id, priority=value)  # type: ignore[arg-type]


def is_destination(args: tuple[str, ...] | list[str]) -> bool:
    return bool(args) and fold_arabic(args[0]) in DEST_WORDS


def parse_destination(args: tuple[str, ...] | list[str]) -> DestArgs:
    """`destination` -> show; `destination group` -> back to the group itself; `destination -100123...` -> that chat."""
    words = list(args)[1:]
    if not words:
        return DestArgs("show")
    if len(words) > 1:
        raise CommandError("report_dest")
    word = fold_arabic(words[0])
    if word in GROUP_WORDS:
        return DestArgs("group")
    if not _CHAT_ID.match(word) or not -MAX_BIGINT <= int(word) < 0:
        raise CommandError("report_dest")
    return DestArgs("set", int(word))


SCHEDULE_WORDS = frozenset(fold_arabic(w) for w in ("schedule", "جدولة", "الجدولة"))
ON_WORDS = frozenset(fold_arabic(w) for w in ("on", "enable", "تفعيل", "تشغيل", "فعل"))
OFF_WORDS = frozenset(fold_arabic(w) for w in ("off", "disable", "ايقاف", "إيقاف", "تعطيل", "الغاء"))


@dataclass(frozen=True, slots=True)
class ScheduleArgs:
    period: StatsPeriod | None = None   # None = show all three
    enabled: bool | None = None         # None = show


def is_schedule(args: tuple[str, ...] | list[str]) -> bool:
    return bool(args) and fold_arabic(args[0]) in SCHEDULE_WORDS


def parse_schedule(args: tuple[str, ...] | list[str]) -> ScheduleArgs:
    """`schedule` -> show the three switches; `schedule <day|week|month> <on|off>` -> change one. Anything else is an error
    (a lone period or a stray word never switches anything)."""
    words = list(args)[1:]
    if not words:
        return ScheduleArgs()
    if len(words) != 2:
        raise CommandError("report_schedule")
    period = PERIOD_WORDS.get(fold_arabic(words[0]))
    word = fold_arabic(words[1])
    if period is None or (word not in ON_WORDS and word not in OFF_WORDS):
        raise CommandError("report_schedule")
    return ScheduleArgs(period, word in ON_WORDS)


def parse_list(args: tuple[str, ...] | list[str]) -> ListArgs:
    """`[status] [before_id]`, either optional, status first."""
    words = list(args)
    if len(words) > 2:
        raise CommandError("report_usage")
    key, before = "open", None
    if words and fold_arabic(words[0]) in STATUS_WORDS:
        key = STATUS_WORDS[fold_arabic(words[0])]  # type: ignore[assignment]
        words = words[1:]
    elif words and not _DIGITS.match(fold_arabic(words[0])):
        raise CommandError("report_status")
    if words:
        before = _id(words[0])
    return ListArgs(key, _STATUS_FILTER[key], before)


def alias_args_ok(args: tuple[str, ...] | list[str]) -> bool:
    """Arabic `البلاغات ...` is a command only when everything after it is the command's own vocabulary."""
    if is_schedule(args):
        try:
            parse_schedule(args)
        except CommandError:
            return False
        return True
    if is_destination(args):
        try:
            parse_destination(args)
        except CommandError:
            return False
        return True
    try:
        parse_list(args)
    except CommandError:
        return False
    return True
