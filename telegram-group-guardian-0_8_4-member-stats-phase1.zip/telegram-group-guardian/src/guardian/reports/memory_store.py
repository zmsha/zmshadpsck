"""In-memory report store (tests / local experiments only; state is lost on restart)."""
from __future__ import annotations

from dataclasses import replace

from ..errors import InvalidInput
from .models import (CLOSED_STATUSES, META_FIELDS, Report, ReportOutcome, ReportPriority, ReportStatus,
                     ReportType)


class InMemoryReportStore:
    def __init__(self) -> None:
        self._rows: list[Report] = []
        self._next = 1

    async def add(self, group_id, reporter_id, target_user_id, message_id, reason, report_type, priority, now,
                  trace_id=None, idempotency_key=None):
        if idempotency_key is not None:
            for row in self._rows:
                if row.group_id == group_id and row.idempotency_key == idempotency_key:
                    return row, False
        row = Report(self._next, group_id, reporter_id, target_user_id, message_id, reason, ReportType(report_type),
                     ReportPriority(priority), ReportStatus.OPEN, now, now, trace_id=trace_id,
                     idempotency_key=idempotency_key)
        self._next += 1
        self._rows.append(row)
        return row, True

    async def get(self, group_id, report_id):
        return next((r for r in self._rows if r.group_id == group_id and r.id == report_id), None)

    async def list_reports(self, group_id, statuses, limit, before_id=None):
        rows = [r for r in self._rows if r.group_id == group_id
                and (statuses is None or r.status in statuses) and (before_id is None or r.id < before_id)]
        rows.sort(key=lambda r: r.id, reverse=True)
        return rows[: max(0, int(limit))]

    async def count(self, group_id, statuses) -> int:
        return sum(1 for r in self._rows if r.group_id == group_id and (statuses is None or r.status in statuses))

    async def count_in_range(self, group_id, start, end) -> dict[str, int]:
        out: dict[str, int] = {}
        for r in self._rows:
            if r.group_id != group_id:
                continue
            if start <= r.created_at < end:
                out["created"] = out.get("created", 0) + 1
                key = f"type_{r.report_type.value}"
                out[key] = out.get(key, 0) + 1
            if r.handled_at is not None and r.outcome is not None and start <= r.handled_at < end:
                key = f"handled_{r.outcome.value}"
                out[key] = out.get(key, 0) + 1
        return out

    async def transition(self, group_id, report_id, expected, new_status, actor, now, outcome=None):
        for i, row in enumerate(self._rows):
            if row.group_id != group_id or row.id != report_id or row.status not in expected:
                continue
            if new_status is ReportStatus.TAKEN:
                new = replace(row, status=new_status, assigned_to=actor, updated_at=now)
            elif new_status in CLOSED_STATUSES:
                if outcome is None:
                    raise InvalidInput("a closed report needs an outcome")
                new = replace(row, status=new_status, handled_by=actor, handled_at=now, outcome=outcome, updated_at=now)
            else:  # back to OPEN is not a supported transition
                raise InvalidInput("unsupported transition")
            self._rows[i] = new
            return new
        return None

    async def set_meta(self, group_id, report_id, field, value, now):
        if field not in META_FIELDS:
            raise InvalidInput("unsupported field")
        enum_cls = ReportType if field == "report_type" else ReportPriority
        new_value = enum_cls(value)
        for i, row in enumerate(self._rows):
            if row.group_id != group_id or row.id != report_id or not row.is_open or getattr(row, field) is new_value:
                continue
            new = replace(row, **{field: new_value}, updated_at=now)
            self._rows[i] = new
            return new
        return None
