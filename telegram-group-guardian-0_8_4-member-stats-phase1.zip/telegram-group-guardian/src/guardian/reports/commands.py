"""Report management from chat (part 6.4a): `/reports`, `/report show|take|resolve|dismiss|type|priority`, and the approved
destination (`/reports destination`). Framework independent; reached from `ModerationCommandService._handle`.

Path of EVERY command (each step fails closed; covered by tests):
 1. `permissions.require(MODERATE, context_chat_id=chat)`  -> DENIED by the caller (PermissionDenied), nothing leaked
 2. license gate (`protection.allowed` for THIS chat)       -> LICENSE_OFF
 3. strict argument parsing (`reports.args`)                -> INVALID
 4. writes: claim `operation_key("repmgmt", chat, message_id)` (a redelivered update never acts or audits twice) ->
    DUPLICATE; the move itself is the service's compare-and-set (two admins racing: exactly one wins)
Every report is looked up by (THIS chat, id): another group's report number is simply "not found".
Closing a report records WHO and WHAT (outcome) only; it never sanctions anyone: sanctions stay with `/ban /mute ...`.

Destination (owner approved). `/reports destination` shows it to moderators; changing it needs
`Permission.REPORT_DESTINATION` (primary owner only), a reachable chat (the bot is a member), a claim, and writes through
`GroupSettingsService.update` (validated, `settings_changed` audit with key names only) plus a `report_destination_set`
audit row with the chat ids. Listings and details (they carry reporter ids and reasons) go to the destination; the group
gets a one-line notice. If the destination cannot be read, nothing is listed (fail closed, never into the wrong chat).
"""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Callable

from ..audit import REPORT_DESTINATION_SET, RESULT_APPLIED, SecurityAudit, make_event, record_safely
from ..errors import InvalidInput
from ..i18n import t
from ..idempotency import IdempotencyStore, operation_key
from ..moderation.command_error import CommandError
from ..moderation.commands import Command, ParsedCommand
from ..moderation.messages import error_message
from ..permissions import Permission
from ..protection.tracking import KeyedLocks
from ..time_utils import utcnow
from .args import (AdminArgs, DestArgs, ListArgs, ReportAction, is_destination, is_schedule, parse_admin, parse_destination,
                   parse_list, parse_schedule)
from . import render
from .destination import DESTINATION_KEY, destination_of
from .models import Report
from .service import TransitionCode, TransitionResult

log = logging.getLogger(__name__)

PAGE_SIZE = 10
_REACHABLE = frozenset({"creator", "administrator", "member", "restricted"})


class ReportCommands:
    def __init__(
        self, *, permissions: Any, reports: Any, claims: IdempotencyStore, group_settings: Any, load_raw: Callable[[int], Any],
        chat_info: Any, audit: SecurityAudit | None, make_result: Callable[..., Any], kinds: Any,
        display_timezone: str = "Asia/Riyadh", clock: Callable[[], datetime] = utcnow, schedule: Any = None,
    ):
        self._schedule = schedule  # ReportScheduleService (6.6a): the periodic-report switches
        self._perm, self._reports, self._claims, self._gs = permissions, reports, claims, group_settings
        self._load_raw, self._chat_info, self._audit = load_raw, chat_info, audit
        self._result, self._kinds, self._tz, self._clock = make_result, kinds, display_timezone, clock
        self._locks = KeyedLocks()

    # ------------------------------------------------------------------ entry point
    async def handle(self, parsed: ParsedCommand, chat_id: int, actor_id: int, message_id: int, protection: Any, lang: str):
        R, cmd = self._kinds, parsed.command
        await self._perm.require(actor_id, chat_id, Permission.MODERATE, context_chat_id=chat_id)  # PermissionDenied
        if protection is None or not protection.allowed or protection.chat_id != chat_id:
            return self._result(R.LICENSE_OFF, t("mod_license_off", lang), cmd)
        if self._reports is None:
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        try:
            if cmd is Command.REPORTS:
                if is_schedule(parsed.args):
                    return await self._schedule_cmd(parse_schedule(parsed.args), chat_id, actor_id, message_id, cmd, lang)
                if is_destination(parsed.args):
                    return await self._destination(parse_destination(parsed.args), chat_id, actor_id, message_id, cmd, lang)
                return await self._list(parse_list(parsed.args), chat_id, cmd, lang)
            plan = parse_admin(parsed.args)
        except CommandError as exc:
            return self._result(R.INVALID, error_message(exc, lang) or t("invalid_input", lang), cmd)
        if plan.action is ReportAction.SHOW:
            return await self._show(plan, chat_id, cmd, lang)
        return await self._change(plan, chat_id, actor_id, message_id, cmd, lang)

    # ------------------------------------------------------------------ periodic-report switches (6.7 decision)
    async def _schedule_cmd(self, plan, chat_id: int, actor_id: int, message_id: int, cmd: Command, lang: str):
        """`/reports schedule` shows the switches (moderators); `schedule <period> on|off` changes one and needs
        `MANAGE_SETTINGS` for THIS chat (checked on the server every time). The licence gate already passed in `handle`."""
        R = self._kinds
        if self._schedule is None:
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        if plan.enabled is None:
            try:
                entries = await self._schedule.entries(chat_id)
            except Exception:
                log.error("report schedule unreadable", extra={"group_id": chat_id}, exc_info=True)
                return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
            lines = [t("report_sched_line", lang, period=t(f"report_sched_{p.value}", lang),
                       state=t("report_sched_on" if e.enabled else "report_sched_off", lang)) for p, e in entries.items()]
            return self._result(R.INFO, t("report_sched_title", lang) + "\n" + "\n".join(lines) + "\n" + t("report_sched_note", lang), cmd)
        await self._perm.require(actor_id, chat_id, Permission.MANAGE_SETTINGS, context_chat_id=chat_id)  # PermissionDenied
        try:
            claimed = await self._claims.claim(operation_key("repsched", chat_id, message_id))
        except Exception:
            log.error("report schedule claim failed", extra={"group_id": chat_id}, exc_info=True)
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        if not claimed:
            return self._result(R.DUPLICATE, "", cmd)
        try:
            outcome = await self._schedule.set_enabled(chat_id, plan.period, plan.enabled, actor_id, self._clock())
        except Exception:    # e.g. a foreign-key error for a group that is not registered
            log.error("report schedule change failed", extra={"group_id": chat_id}, exc_info=True)
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        period = t(f"report_sched_{plan.period.value}", lang)
        if getattr(outcome, "code", None) is not None and outcome.code.value == "unchanged":
            return self._result(R.NOOP, t("report_sched_noop", lang, period=period), cmd)
        return self._result(R.DONE, t("report_sched_set_on" if plan.enabled else "report_sched_set_off", lang, period=period), cmd)

    # ------------------------------------------------------------------ reads (routed to the destination)
    async def _destination_for(self, chat_id: int) -> int | None:
        """The chat the output must go to (None = this chat); RAISES when the settings cannot be read."""
        dest = destination_of(await self._load_raw(chat_id), chat_id)
        return None if dest == chat_id else dest

    async def _list(self, plan: ListArgs, chat_id: int, cmd: Command, lang: str):
        R = self._kinds
        try:
            redirect = await self._destination_for(chat_id)
        except Exception:
            log.error("report destination unreadable; nothing listed", extra={"group_id": chat_id}, exc_info=True)
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        rows = await self._reports.list_reports(chat_id, plan.statuses, PAGE_SIZE + 1, plan.before_id)
        total = await self._reports.count(chat_id, plan.statuses)
        shown = rows[:PAGE_SIZE]
        label = t(f"report_filter_{plan.status_key}", lang)
        if not shown:
            return self._result(R.INFO, t("report_list_empty", lang, filter=label), cmd, redirect_chat_id=redirect)
        lines = [self._line(r, lang) for r in shown]
        text = t("report_list_title", lang, filter=label, count=total) + "\n" + "\n".join(lines)
        if len(rows) > PAGE_SIZE:
            text += "\n" + t("report_more", lang, status=plan.status_key, before=shown[-1].id)
        return self._result(R.INFO, text, cmd, redirect_chat_id=redirect)

    async def _show(self, plan: AdminArgs, chat_id: int, cmd: Command, lang: str):
        R = self._kinds
        try:
            redirect = await self._destination_for(chat_id)
        except Exception:
            log.error("report destination unreadable; nothing shown", extra={"group_id": chat_id}, exc_info=True)
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        report = await self._reports.get(chat_id, plan.report_id)
        if report is None:
            return self._result(R.INVALID, t("report_not_found", lang, id=plan.report_id), cmd)
        return self._result(R.INFO, self._details(report, chat_id, lang), cmd, report.target_user_id,
                            redirect_chat_id=redirect)

    # ------------------------------------------------------------------ writes
    async def _change(self, plan: AdminArgs, chat_id: int, actor_id: int, message_id: int, cmd: Command, lang: str):
        R = self._kinds
        try:
            claimed = await self._claims.claim(operation_key("repmgmt", chat_id, message_id))
        except Exception:
            log.error("report claim failed; nothing changed", extra={"group_id": chat_id}, exc_info=True)
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        if not claimed:
            return self._result(R.DUPLICATE, "", cmd)
        a, rid = plan.action, plan.report_id
        if a is ReportAction.TAKE:
            moved = await self._reports.take(chat_id, rid, actor_id)
        elif a is ReportAction.RESOLVE:
            moved = await self._reports.resolve(chat_id, rid, actor_id, plan.outcome)
        elif a is ReportAction.DISMISS:
            moved = await self._reports.dismiss(chat_id, rid, actor_id, plan.outcome)
        elif a is ReportAction.TYPE:
            moved = await self._reports.set_type(chat_id, rid, actor_id, plan.report_type)
        else:
            moved = await self._reports.set_priority(chat_id, rid, actor_id, plan.priority)
        return self._answer(moved, plan, cmd, lang)

    def _answer(self, moved: TransitionResult, plan: AdminArgs, cmd: Command, lang: str):
        R, rid = self._kinds, plan.report_id
        target = moved.report.target_user_id if moved.report is not None else None
        code = moved.code
        if code is TransitionCode.NOT_FOUND:
            return self._result(R.INVALID, t("report_not_found", lang, id=rid), cmd)
        if code is TransitionCode.ALREADY_TAKEN:
            holder = moved.report.assigned_to if moved.report is not None else 0
            return self._result(R.INVALID, t("report_already_taken", lang, id=rid, holder=holder or 0), cmd, target)
        if code is TransitionCode.CLOSED:
            status = t(f"report_status_{moved.report.status.value}", lang) if moved.report is not None else ""
            return self._result(R.INVALID, t("report_closed", lang, id=rid, status=status), cmd, target)
        if code is TransitionCode.UNCHANGED:
            return self._result(R.NOOP, t("report_unchanged", lang, id=rid), cmd, target)
        a = plan.action
        if a is ReportAction.TAKE:
            text = t("report_ok_taken", lang, id=rid)
        elif a is ReportAction.RESOLVE:
            text = t("report_ok_resolved", lang, id=rid, outcome=t(f"report_outcome_{plan.outcome.value}", lang))
        elif a is ReportAction.DISMISS:
            text = t("report_ok_dismissed", lang, id=rid, outcome=t(f"report_outcome_{plan.outcome.value}", lang))
        elif a is ReportAction.TYPE:
            text = t("report_ok_type", lang, id=rid, value=t(f"report_type_{plan.report_type.value}", lang))
        else:
            text = t("report_ok_priority", lang, id=rid, value=t(f"report_prio_{plan.priority.value}", lang))
        return self._result(R.DONE, text, cmd, target)

    # ------------------------------------------------------------------ destination
    async def _destination(self, plan: DestArgs, chat_id: int, actor_id: int, message_id: int, cmd: Command, lang: str):
        R = self._kinds
        if plan.op == "show":
            try:
                dest = destination_of(await self._load_raw(chat_id), chat_id)
            except Exception:
                log.error("report destination unreadable", extra={"group_id": chat_id}, exc_info=True)
                return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
            key = "report_dest_show_group" if dest == chat_id else "report_dest_show_custom"
            return self._result(R.INFO, t(key, lang, dest=dest), cmd)
        # ---- change: the PRIMARY OWNER only (PermissionDenied -> the caller answers DENIED)
        await self._perm.require(actor_id, chat_id, Permission.REPORT_DESTINATION, context_chat_id=chat_id)
        if self._gs is None:
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        new = None if plan.op == "group" or plan.chat_id == chat_id else plan.chat_id
        if new is not None and not await self._reachable(new):
            return self._result(R.INVALID, t("report_dest_unreachable", lang), cmd)
        try:
            claimed = await self._claims.claim(operation_key("repdest", chat_id, message_id))
        except Exception:
            log.error("destination claim failed; nothing written", extra={"group_id": chat_id}, exc_info=True)
            return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
        if not claimed:
            return self._result(R.DUPLICATE, "", cmd)
        async with self._locks.hold(("repdest", chat_id)):
            try:
                current = destination_of(await self._load_raw(chat_id), chat_id)
            except Exception:
                log.error("report destination unreadable; nothing written", extra={"group_id": chat_id}, exc_info=True)
                return self._result(R.ERROR, t("action_failed_safe", lang), cmd)
            wanted = chat_id if new is None else new
            if current == wanted:
                return self._result(R.NOOP, t("report_dest_noop", lang), cmd)
            try:
                await self._gs.update(actor_id, chat_id, {DESTINATION_KEY: new}, context_chat_id=chat_id)
            except InvalidInput:
                return self._result(R.INVALID, t("invalid_input", lang), cmd)
        await record_safely(self._audit, make_event(
            REPORT_DESTINATION_SET, actor=actor_id, group_id=chat_id, now=self._clock(), target=wanted,
            result=RESULT_APPLIED, detail=f"destination={'group' if new is None else new}"))
        if new is None:
            return self._result(R.DONE, t("report_dest_cleared", lang), cmd)
        return self._result(R.DONE, t("report_dest_set", lang, dest=new), cmd)

    async def _reachable(self, dest: int) -> bool:
        """The bot is a present member of the approved chat. Any lookup failure = not reachable (never guessed)."""
        try:
            info = await self._chat_info.get_bot_member(dest)
        except Exception:
            return False
        return getattr(info, "status", None) in _REACHABLE

    # ------------------------------------------------------------------ rendering (shared with the panel: reports/render.py)
    def _line(self, r: Report, lang: str) -> str:
        return render.line(r, lang, self._tz)

    def _details(self, r: Report, chat_id: int, lang: str) -> str:
        return render.details(r, chat_id, lang, self._tz)
