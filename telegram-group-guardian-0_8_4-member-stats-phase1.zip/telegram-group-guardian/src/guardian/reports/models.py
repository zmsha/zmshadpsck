"""Plain value types and shared validation for stored reports.

Closed vocabularies (the SQL CHECK lists in migration 0008 repeat them; a test keeps both in sync). The reporter's free
text is stored sanitized and capped (`clean_reason`): it is the report's own body, never copied into the audit log.
"""
from __future__ import annotations

import enum
import unicodedata
from dataclasses import dataclass
from datetime import datetime

from ..audit import sanitize_text

MAX_REASON_LEN = 200
MAX_KEY_LEN = 200


class ReportType(str, enum.Enum):
    SPAM = "spam"
    ABUSE = "abuse"
    SCAM = "scam"
    OTHER = "other"


class ReportPriority(str, enum.Enum):
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"


class ReportStatus(str, enum.Enum):
    OPEN = "open"
    TAKEN = "taken"
    RESOLVED = "resolved"
    DISMISSED = "dismissed"


class ReportOutcome(str, enum.Enum):
    ACTION_TAKEN = "action_taken"
    NO_ACTION = "no_action"
    FALSE_REPORT = "false_report"


META_FIELDS = ("report_type", "priority")  # the two columns a moderator may still change on an open report (6.4a)
OPEN_STATUSES = (ReportStatus.OPEN, ReportStatus.TAKEN)
CLOSED_STATUSES = (ReportStatus.RESOLVED, ReportStatus.DISMISSED)


@dataclass(frozen=True, slots=True)
class Report:
    id: int
    group_id: int
    reporter_id: int
    target_user_id: int
    message_id: int | None            # the REPORTED message (the replied-to one); None when unknown
    reason: str | None
    report_type: ReportType
    priority: ReportPriority
    status: ReportStatus
    created_at: datetime
    updated_at: datetime
    assigned_to: int | None = None    # set while TAKEN, kept after closing
    outcome: ReportOutcome | None = None
    handled_by: int | None = None     # who resolved/dismissed
    handled_at: datetime | None = None
    trace_id: str | None = None       # the update that filed it (part 6.1)
    idempotency_key: str | None = None

    @property
    def is_open(self) -> bool:
        return self.status in OPEN_STATUSES


def clean_reason(value: str | None) -> str | None:
    """Stored reason: no control/format/bidi characters, secrets redacted, whitespace collapsed, <= MAX_REASON_LEN."""
    if value is None:
        return None
    kept = "".join(ch for ch in unicodedata.normalize("NFC", str(value))
                   if unicodedata.category(ch) not in ("Cc", "Cf", "Cs", "Co", "Cn", "Zl", "Zp"))
    return sanitize_text(kept, MAX_REASON_LEN)
