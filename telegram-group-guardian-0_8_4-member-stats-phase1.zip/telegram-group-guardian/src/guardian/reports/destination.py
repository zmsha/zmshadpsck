"""The approved destination of a group's report MANAGEMENT output (part 6.4a).

Stored in the group's settings JSON under `reports_destination`: absent / null / anything invalid = the group itself
(the safe default); otherwise a NEGATIVE chat id that the PRIMARY OWNER approved (`Permission.REPORT_DESTINATION`, owner
only). Group admins can read it but never change it. It is deliberately NOT one of `owner_templates.TEMPLATE_KEYS`, so a
template can never copy one group's destination to another.

The listing (`/reports`) and the details (`/report show`) carry reporter ids and the reporters' own words, so they are
the only outputs routed there; short confirmations stay in the chat where the admin typed the command.
"""
from __future__ import annotations

from typing import Any

from ..auth import MAX_BIGINT

DESTINATION_KEY = "reports_destination"


def valid_destination(value: object) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and -MAX_BIGINT <= value < 0


def destination_of(raw: Any, group_id: int) -> int:
    """The chat that receives report listings/details for `group_id`: the approved chat id, else the group itself."""
    if isinstance(raw, dict):
        value = raw.get(DESTINATION_KEY)
        if valid_destination(value):
            return value
    return group_id


def is_custom(raw: Any, group_id: int) -> bool:
    return destination_of(raw, group_id) != group_id
