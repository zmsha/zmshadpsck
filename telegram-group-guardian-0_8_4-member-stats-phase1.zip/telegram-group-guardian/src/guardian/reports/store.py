"""Persistence contract for reports. EVERY method takes `group_id` and never reads or changes another group's rows."""
from __future__ import annotations

from datetime import datetime
from typing import Protocol, Sequence

from .models import Report, ReportOutcome, ReportPriority, ReportStatus, ReportType


class ReportStore(Protocol):
    async def add(
        self, group_id: int, reporter_id: int, target_user_id: int, message_id: int | None, reason: str | None,
        report_type: ReportType, priority: ReportPriority, now: datetime, trace_id: str | None = None,
        idempotency_key: str | None = None,
    ) -> tuple[Report, bool]:
        """Idempotent per (group, key): a repeated key returns (existing, False) and stores nothing."""
        ...

    async def get(self, group_id: int, report_id: int) -> Report | None: ...

    async def list_reports(self, group_id: int, statuses: Sequence[ReportStatus] | None, limit: int,
                   before_id: int | None = None) -> list[Report]:
        """Newest first (highest id first); `before_id` pages: only rows with id < before_id."""
        ...

    async def count(self, group_id: int, statuses: Sequence[ReportStatus] | None) -> int: ...

    async def count_in_range(self, group_id: int, start: datetime, end: datetime) -> dict[str, int]:
        """Statistics (6.5a), `start <= t < end`: `created` and `type_<type>` by creation time, `handled_<outcome>` by
        handling time (closed vocabularies only; keys with no rows are absent)."""
        ...

    async def transition(
        self, group_id: int, report_id: int, expected: Sequence[ReportStatus], new_status: ReportStatus, actor: int,
        now: datetime, outcome: ReportOutcome | None = None,
    ) -> Report | None:
        """Compare-and-set: moves the row to `new_status` ONLY if its current status is in `expected`; returns the
        updated row, or None when the row is missing / in another group / not in an expected status.
        TAKEN sets `assigned_to=actor`; RESOLVED/DISMISSED set `handled_by=actor`, `handled_at=now` and `outcome`."""
        ...

    async def set_meta(self, group_id: int, report_id: int, field: str, value: str, now: datetime) -> Report | None:
        """Compare-and-set of ONE classification field (`field` is `report_type` or `priority`, `value` its vocabulary
        string). Applies only while the report is OPEN/TAKEN AND the stored value differs; returns the updated row, or
        None when the row is missing / in another group / closed / already has that value."""
        ...
