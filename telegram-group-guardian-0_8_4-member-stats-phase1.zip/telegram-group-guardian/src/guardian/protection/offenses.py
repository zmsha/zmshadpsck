"""Durable escalation ledger for AUTOMATIC mutes, backed by `moderation_sanctions`.

The engine depends only on the `OffenseLedger` interface (same shape the in-memory counters had):
* offense number = automatic mutes of this user in this group inside the window, plus one;
* a restriction (mute/ban) still in force means in-flight messages are only deleted, never re-sanctioned.
Because records live in the database, escalation survives restarts/sleep of the free host.
Only SUCCESSFUL mutes are recorded, so a failed Telegram call never escalates the next one.
"""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import Protocol

from ..moderation.models import RESTRICTING_KINDS, SanctionKind, check_expiry
from ..moderation.store import SanctionStore


class OffenseLedger(Protocol):
    async def is_restricted(self, group_id: int, user_id: int, now: datetime) -> bool: ...

    async def next_offense(self, group_id: int, user_id: int, window_seconds: int, now: datetime) -> int: ...

    async def record_mute(self, group_id: int, user_id: int, violation: str, seconds: int, now: datetime,
                          idempotency_key: str | None = None) -> None: ...


class SanctionOffenseLedger:
    def __init__(self, store: SanctionStore):
        self._store = store

    async def is_restricted(self, group_id, user_id, now) -> bool:
        return bool(await self._store.get_active(group_id, user_id, now, RESTRICTING_KINDS))

    async def next_offense(self, group_id, user_id, window_seconds, now) -> int:
        since = now - timedelta(seconds=window_seconds)
        return await self._store.count_auto_mutes(group_id, user_id, since) + 1

    async def record_mute(self, group_id, user_id, violation, seconds, now, idempotency_key=None) -> None:
        expires = check_expiry(SanctionKind.MUTE, now, now + timedelta(seconds=seconds))
        await self._store.record(group_id, user_id, SanctionKind.MUTE, None, None, now, expires,
                                 violation, idempotency_key)
