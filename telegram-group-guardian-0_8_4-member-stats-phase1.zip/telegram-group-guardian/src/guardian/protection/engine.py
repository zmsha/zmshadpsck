"""Automatic protection for ONE message: detect (links / duplicate / flood) then delete + escalating mute.

Safety rules enforced here (each covered by tests):
* Acts only when the gate says `can_sanction` for THIS chat and THIS sender; otherwise no-op.
* Never bans: automatic action is delete + temporary mute only. Uncertain => no action.
* dry_run => decision is audited but NO Telegram call and NO idempotency claim is made.
* One sanction per message: `claim(operation_key("sanction", group, user, message_id))` before acting
  (webhook redelivery cannot repeat it; if the claim store fails we do NOT act).
* Bot rights are checked before delete/restrict; missing/unknown rights => no action, owner told
  (throttled), event audited.
* After a mute, in-flight messages from the same user are only deleted (no extra offense/mute).
* Escalation is durable: offenses are the automatic mutes recorded in `moderation_sanctions` (offenses.py);
  the read-decide-mute-record section is serialised per (group, user). If the ledger is unreadable the
  message is still deleted but NO mute is guessed.
* Telegram errors are classified by the actions adapter and never raised here.
* Trust (part 4.2, `members/trust.py`): a trusted sender (`ctx.sender_trusted`) skips ONLY links/duplicates/slow mode, never
  flood; a message sent through a trusted inline bot (`via_bot_id`) skips only the link rule. A failed bot-trust lookup
  skips the link rule too (uncertain => no action).
* Adult-word filter (part 9.1, `adult_words.py`): a listed word in a text/caption (also in an EDIT) is a violation like links:
  delete + escalating mute. Whole words only, evasions (diacritics, spacing, look-alike digits) are normalised; no trust
  entry bypasses it. Photos/videos/GIFs are NOT inspected (text and captions only).
* Newcomer window (part 4.5, `members/newcomers.py`): while a member is within `newbie_seconds` of their join, a message
  with a link (honouring the allow-list), media, or any message (per the group's `newbie_block_*`) is deleted: delete only,
  no mute, no offense, rank below links/duplicates/flood. A trusted sender skips it (`RULE_NEWBIE`). No join time known
  (restart/sleep) => no restriction.
* Bot-enforced slow mode (`slowmode_seconds`; Telegram's own slow mode cannot be set through the Bot API): a message
  sent sooner than N seconds after the member's previous ACCEPTED message is deleted. It is the mildest rule: it never
  mutes, never counts as an offense, ranks below links/duplicates/flood, ignores edits and service messages, and a
  redelivered update of the accepted message itself is never treated as a violation. State is in memory (resets on
  restart/sleep, which only makes it more lenient).
"""
from __future__ import annotations

import enum
import logging
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Awaitable, Callable, Protocol, Sequence

from ..audit import SecurityAudit, make_event, record_safely
from ..groups.store import SettingsStore
from ..i18n import t
from ..idempotency import IdempotencyStore, operation_key
from ..members import trust as trust_rules
from ..members.settings import NewMemberPolicy
from ..membership import Notifier
from ..moderation.memory_store import InMemorySanctionStore
from ..protection_gate import ProtectionContext
from ..telegram_rights import BotCapability, ChatInfoProvider, check_bot_capabilities
from ..time_utils import utcnow
from .adult_words import find_adult
from .links import find_links, violating_links
from .offenses import OffenseLedger, SanctionOffenseLedger
from .settings import ProtectionSettings
from .tracking import KeyedLocks, LastSeen, SlidingCounter, text_digest

log = logging.getLogger(__name__)

AUTO_SANCTION = "auto_sanction"
AUTO_SANCTION_DRY_RUN = "auto_sanction_dry_run"
PROTECTION_BLOCKED = "protection_blocked_bot_rights"
PROTECTION_LEDGER_ERROR = "protection_ledger_error"

VIOLATION_LINKS, VIOLATION_DUPLICATE, VIOLATION_FLOOD, VIOLATION_SLOWMODE = "links", "duplicate", "flood", "slowmode"
VIOLATION_ADULT = "adult"  # part 9.1: a listed adult / sexually explicit word in the text or caption (edits included)
VIOLATION_NEWBIE = trust_rules.RULE_NEWBIE  # part 4.5: a newcomer's link / media / message inside the restriction window
_OWNER_NOTICE_EVERY = 600.0  # seconds, per group


class OutcomeKind(str, enum.Enum):
    NONE = "none"
    DRY_RUN = "dry_run"
    DUPLICATE_DELIVERY = "duplicate_delivery"
    ACTED = "acted"
    BOT_RIGHTS_MISSING = "bot_rights_missing"
    UNSAFE_NO_ACTION = "unsafe_no_action"  # could not verify rights / dedupe: did nothing


@dataclass(frozen=True, slots=True)
class Outcome:
    kind: OutcomeKind
    violation: str | None = None
    deleted: bool = False
    muted_seconds: int | None = None

    @property
    def consumed(self) -> bool:
        """The offending message was removed: later handlers should not process it."""
        return self.deleted


NO_ACTION = Outcome(OutcomeKind.NONE)


@dataclass(frozen=True, slots=True)
class MessageView:
    chat_id: int
    user_id: int
    message_id: int
    text: str | None
    entities: Sequence[Any] = ()
    is_edit: bool = False
    service: bool = False  # a Telegram service message (join/leave/pin/...): never a violation
    via_bot_id: int | None = None  # id of the inline bot the message was sent through (Message.via_bot), if any
    has_media: bool = False  # photo/video/audio/document/voice/sticker/... (not plain text)


@dataclass(frozen=True, slots=True)
class ActionResult:
    ok: bool
    error: str | None = None  # rate_limited | forbidden | not_found | other | kick_incomplete (part 6)


@dataclass(frozen=True, slots=True)
class SendResult(ActionResult):
    """Result of sending a message: `message_id` is set only when Telegram accepted it."""

    message_id: int | None = None


class ModerationActions(Protocol):
    async def delete_message(self, chat_id: int, message_id: int) -> ActionResult: ...

    async def mute_member(self, chat_id: int, user_id: int, until: datetime) -> ActionResult: ...


class ProtectionEngine:
    def __init__(
        self,
        settings_store: SettingsStore,
        actions: ModerationActions,
        chat_info: ChatInfoProvider,
        claims: IdempotencyStore,
        audit: SecurityAudit | None,
        notifier: Notifier | None = None,
        *,
        language: str = "ar",
        clock: Callable[[], datetime] = utcnow,
        ledger: OffenseLedger | None = None,
        bot_trust: Any = None,
        newcomers: Any = None,
        counters: Any = None,
        member_stats: Any = None,
    ):
        self._settings_store = settings_store
        self._actions = actions
        self._chat_info = chat_info
        self._claims = claims
        self._audit = audit
        self._notifier = notifier
        self._language = language
        self._clock = clock
        self._flood = SlidingCounter()
        self._dups = SlidingCounter()
        self._slow = LastSeen()
        # Default (tests/local): in-memory sanction records. The app passes the PostgreSQL-backed ledger.
        self._ledger: OffenseLedger = ledger or SanctionOffenseLedger(InMemorySanctionStore())
        self._locks = KeyedLocks()
        self._bot_trust = bot_trust  # BotTrustStore (optional): trusted inline bots
        self._newcomers = newcomers  # NewcomerTracker (optional): join times for the part-4.5 restriction window
        self._counters = counters    # CounterRecorder (optional, part 6.5a): one tick per message the engine ACTED on
        self._member_stats = member_stats  # MemberStatsRecorder (optional): the sender's violation / deletion tick, once per message
        self._owner_notified: dict[int, float] = {}

    async def load_settings(self, group_id: int) -> ProtectionSettings:
        try:
            row = await self._settings_store.get(group_id)
        except Exception:
            log.warning("could not load group settings; using safe defaults", extra={"group_id": group_id})
            return ProtectionSettings()
        return ProtectionSettings.from_raw(row.settings if row is not None else None)

    async def handle(self, ctx: ProtectionContext, msg: MessageView, now: datetime | None = None) -> Outcome:
        if not ctx.can_sanction or ctx.chat_id != msg.chat_id or ctx.sender_id != msg.user_id:
            return NO_ACTION
        now = now or self._clock()
        try:
            cfg = await self.load_settings(msg.chat_id)
            bypass = await self._bypass_for(ctx, msg)
            newbie = await self._newbie_policy(msg, now, bypass)
            violation = self._detect(cfg, msg, now.timestamp(), bypass, newbie)
            if violation is None:
                return NO_ACTION
            outcome = await self._sanction(cfg, msg, violation, now)
            if outcome.kind is OutcomeKind.ACTED:  # claimed once per message => a redelivery never counts twice
                await self._count_violation(msg.chat_id, now)
                await self._count_member(msg, outcome, now)
            return outcome
        except Exception:
            log.error("protection engine failed; no action", extra={"group_id": msg.chat_id}, exc_info=True)
            return Outcome(OutcomeKind.UNSAFE_NO_ACTION)

    async def _count_violation(self, group_id: int, now: datetime) -> None:
        """Statistics only (part 6.5a): a failure here must never change what the engine decided or did."""
        if self._counters is None:
            return
        try:
            await self._counters.bump(group_id, "violation", now)
        except Exception:  # pragma: no cover - CounterRecorder already swallows its own errors
            log.warning("violation counter failed", extra={"group_id": group_id}, exc_info=True)

    async def _count_member(self, msg: MessageView, outcome: Outcome, now: datetime) -> None:
        """Per-member statistics only: a failure here must never change what the engine decided or did."""
        if self._member_stats is None:
            return
        try:
            await self._member_stats.message_acted_on(msg.chat_id, msg.user_id, msg.message_id, outcome.deleted, now)
        except Exception:  # pragma: no cover - the recorder already swallows its own errors
            log.warning("member stats tick failed", extra={"group_id": msg.chat_id}, exc_info=True)

    # ------------------------------------------------------------------ detection
    async def _bypass_for(self, ctx: ProtectionContext, msg: MessageView) -> frozenset[str]:
        """Rules this message skips because of trust (never more than members/trust.py lists)."""
        bypass: frozenset[str] = trust_rules.USER_BYPASS if ctx.sender_trusted else frozenset()
        if msg.via_bot_id is not None and self._bot_trust is not None:
            try:
                if await self._bot_trust.is_trusted(msg.chat_id, msg.via_bot_id):
                    bypass = bypass | trust_rules.VIA_BOT_MESSAGE_BYPASS
            except Exception:
                log.warning("bot trust lookup failed; link rule skipped", extra={"group_id": msg.chat_id})
                bypass = bypass | trust_rules.VIA_BOT_MESSAGE_BYPASS
        return bypass

    async def _newbie_policy(self, msg: MessageView, now: datetime, bypass: frozenset[str]) -> NewMemberPolicy | None:
        """The group's newcomer policy when this sender is still inside the window, else None. Any doubt => None."""
        if self._newcomers is None or trust_rules.RULE_NEWBIE in bypass:
            return None
        joined = self._newcomers.joined_at(msg.chat_id, msg.user_id)
        if joined is None:
            return None
        try:
            row = await self._settings_store.get(msg.chat_id)
        except Exception:
            log.warning("newcomer policy unavailable; no restriction", extra={"group_id": msg.chat_id})
            return None
        policy = NewMemberPolicy.from_raw(row.settings if row is not None and isinstance(row.settings, dict) else None)
        if not policy.active or (now - joined).total_seconds() >= policy.newbie_seconds:
            if not policy.active or now >= joined:
                self._newcomers.forget(msg.chat_id, msg.user_id)  # window over (or policy off): stop tracking
            return None
        return policy

    @staticmethod
    def _newbie_violation(cfg: ProtectionSettings, policy: NewMemberPolicy, msg: MessageView) -> bool:
        if not msg.is_edit and (policy.newbie_block_messages or (policy.newbie_block_media and msg.has_media)):
            return True
        text = msg.text or ""
        # Links honour the group's allow-list (`/protect allow`, trusted domains) and invite policy.
        return bool(policy.newbie_block_links and text
                    and violating_links(find_links(text, msg.entities), cfg.links_allow_domains,
                                        allow_invites=cfg.links_allow_invites))

    def _detect(self, cfg: ProtectionSettings, msg: MessageView, ts: float,
                bypass: frozenset[str] = frozenset(), newbie: NewMemberPolicy | None = None) -> str | None:
        if msg.service:
            return None
        key = (msg.chat_id, msg.user_id)
        found = None
        text = msg.text or ""
        # Adult words rank FIRST and no trust entry skips them (trust only relaxes links/duplicates/slow mode).
        if cfg.adult_enabled and text and find_adult(text, cfg.adult_custom_words) is not None:
            found = VIOLATION_ADULT
        if found is None and cfg.links_enabled and text and trust_rules.RULE_LINKS not in bypass:
            links = find_links(text, msg.entities)
            if violating_links(links, cfg.links_allow_domains, allow_invites=cfg.links_allow_invites):
                found = VIOLATION_LINKS
        if found is None and newbie is not None and self._newbie_violation(cfg, newbie, msg):
            found = VIOLATION_NEWBIE
        if msg.is_edit:  # edits are inspected for links only; they never count as flood/duplicates
            return found
        flood_n = self._flood.hit(key, ts, cfg.flood_window_seconds)
        dup_n = 0
        if len(text.strip()) >= cfg.duplicate_min_length and trust_rules.RULE_DUPLICATE not in bypass:
            dup_n = self._dups.hit((*key, text_digest(text)), ts, cfg.duplicate_window_seconds)
        if found is None and cfg.duplicate_enabled and dup_n >= cfg.duplicate_max_repeats:
            found = VIOLATION_DUPLICATE
        if found is None and cfg.flood_enabled and flood_n > cfg.flood_max_messages:
            found = VIOLATION_FLOOD
        if cfg.slowmode_seconds and trust_rules.RULE_SLOWMODE not in bypass:
            if found is None:
                found = self._slow_violation(key, msg.message_id, ts, cfg.slowmode_seconds)
            if found is None:
                self._slow.put(key, ts, msg.message_id)  # only a fully accepted message restarts the interval
        return found

    def _slow_violation(self, key: tuple, message_id: int, ts: float, seconds: int) -> str | None:
        last = self._slow.get(key)
        if last is None or last[1] == message_id:  # first message / redelivery of the accepted one: never a violation
            return None
        return VIOLATION_SLOWMODE if 0 <= ts - last[0] < seconds else None  # clock went backwards => lenient

    # ------------------------------------------------------------------ sanction
    async def _sanction(self, cfg: ProtectionSettings, msg: MessageView, violation: str, now: datetime) -> Outcome:
        g, u = msg.chat_id, msg.user_id
        if cfg.dry_run:
            await record_safely(self._audit, make_event(
                AUTO_SANCTION_DRY_RUN, actor=u, group_id=g, detail=violation, now=now))
            return Outcome(OutcomeKind.DRY_RUN, violation)

        try:
            first = await self._claims.claim(operation_key("sanction", g, u, msg.message_id), now)
        except Exception:
            log.warning("sanction claim unavailable; not acting", extra={"group_id": g})
            return Outcome(OutcomeKind.UNSAFE_NO_ACTION, violation)
        if not first:
            return Outcome(OutcomeKind.DUPLICATE_DELIVERY, violation)

        if violation in (VIOLATION_SLOWMODE, VIOLATION_NEWBIE):  # mild rules: delete only, no mute, no offense
            return await self._slowmode_delete(msg, violation, now)

        cap = await check_bot_capabilities(
            self._chat_info, g, BotCapability.DELETE_MESSAGES, BotCapability.RESTRICT_MEMBERS)
        if cap.lookup_failed:
            await record_safely(self._audit, make_event(
                PROTECTION_BLOCKED, actor=u, group_id=g, detail="rights_unknown", now=now))
            return Outcome(OutcomeKind.UNSAFE_NO_ACTION, violation)
        can_delete = BotCapability.DELETE_MESSAGES not in cap.missing
        can_mute = BotCapability.RESTRICT_MEMBERS not in cap.missing
        if not can_delete and not can_mute:
            await record_safely(self._audit, make_event(
                PROTECTION_BLOCKED, actor=u, group_id=g, detail="rights_missing", now=now))
            await self._notify_owner_throttled(g, now)
            return Outcome(OutcomeKind.BOT_RIGHTS_MISSING, violation)

        deleted = False
        if can_delete:
            deleted = (await self._actions.delete_message(g, msg.message_id)).ok

        muted_seconds: int | None = None
        if can_mute:
            async with self._locks.hold((g, u)):
                muted_seconds = await self._escalating_mute(cfg, msg, violation, now)

        await record_safely(self._audit, make_event(
            AUTO_SANCTION, actor=u, group_id=g, now=now,
            detail=f"{violation} deleted={deleted} mute={muted_seconds or 0}"))
        return Outcome(OutcomeKind.ACTED, violation, deleted, muted_seconds)

    async def _slowmode_delete(self, msg: MessageView, violation: str, now: datetime) -> Outcome:
        """Slow-mode violation: delete only (needs just the delete right). No mute, no offense, no escalation."""
        g, u = msg.chat_id, msg.user_id
        cap = await check_bot_capabilities(self._chat_info, g, BotCapability.DELETE_MESSAGES)
        if cap.lookup_failed:
            await record_safely(self._audit, make_event(
                PROTECTION_BLOCKED, actor=u, group_id=g, detail="rights_unknown", now=now))
            return Outcome(OutcomeKind.UNSAFE_NO_ACTION, violation)
        if not cap.ok:
            await record_safely(self._audit, make_event(
                PROTECTION_BLOCKED, actor=u, group_id=g, detail="rights_missing", now=now))
            await self._notify_owner_throttled(g, now)
            return Outcome(OutcomeKind.BOT_RIGHTS_MISSING, violation)
        deleted = (await self._actions.delete_message(g, msg.message_id)).ok
        await record_safely(self._audit, make_event(
            AUTO_SANCTION, actor=u, group_id=g, now=now, detail=f"{violation} deleted={deleted} mute=0"))
        return Outcome(OutcomeKind.ACTED, violation, deleted, None)

    async def _escalating_mute(self, cfg: ProtectionSettings, msg: MessageView, violation: str,
                               now: datetime) -> int | None:
        """Mute for the n-th offense; None = no mute (already restricted, ledger unreadable, or Telegram refused)."""
        g, u = msg.chat_id, msg.user_id
        try:
            if await self._ledger.is_restricted(g, u, now):
                return None  # in-flight message: deleted only, no extra offense
            offense = await self._ledger.next_offense(g, u, cfg.escalation_window_seconds, now)
        except Exception:
            log.warning("offense ledger unreadable; deleting only, no mute", extra={"group_id": g}, exc_info=True)
            await record_safely(self._audit, make_event(
                PROTECTION_LEDGER_ERROR, actor=u, group_id=g, detail="read", now=now))
            return None
        seconds = cfg.mute_for(offense)
        if not (await self._actions.mute_member(g, u, now + timedelta(seconds=seconds))).ok:
            return None
        self._flood.reset((g, u))
        try:
            await self._ledger.record_mute(g, u, violation, seconds, now,
                                           operation_key("sanction", g, u, msg.message_id))
        except Exception:  # the mute is in force; only the escalation memory is missing
            log.error("could not record automatic mute", extra={"group_id": g}, exc_info=True)
            await record_safely(self._audit, make_event(
                PROTECTION_LEDGER_ERROR, actor=u, group_id=g, detail="write", now=now))
        return seconds

    async def _notify_owner_throttled(self, group_id: int, now: datetime) -> None:
        if self._notifier is None:
            return
        ts = now.timestamp()
        last = self._owner_notified.get(group_id)
        if last is not None and ts - last < _OWNER_NOTICE_EVERY:
            return
        self._owner_notified[group_id] = ts
        try:
            await self._notifier.notify_owner(t("owner_bot_rights_missing", self._language, group_id=str(group_id)))
        except Exception:
            log.warning("owner notification failed", exc_info=True)
