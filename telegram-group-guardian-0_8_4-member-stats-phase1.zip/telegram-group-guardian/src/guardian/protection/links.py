"""Link detection + per-group domain allowlist (pure, no I/O).

What it detects (and the documented LIMITS):
* Telegram entities `url` and `text_link` (hidden link behind visible text: the real target is
  `entity.url`). Entity offsets/lengths are UTF-16 code units; we slice accordingly.
* Fallback regex on the text for `http(s)://`, `tg://`, `www.` and bare domains with a curated TLD
  list (so `file.py` / `e.g.` are NOT links). Zero-width characters are stripped before matching.
* Invite links: t.me/+hash, t.me/joinchat/..., tg://join.
LIMITS (cannot be detected from the Telegram API alone): the destination of URL shorteners (bit.ly,
tinyurl...) is never resolved - a shortener is judged by its own domain (allowlist it or not);
links inside images/stickers/voice, spaced/obfuscated forms ("example . com"), and links in inline
keyboards of other bots are not seen. Telegram's own entity parsing is authoritative; bare-domain
regex is a best-effort supplement and deliberately conservative to avoid punishing innocent text.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Iterable, Sequence
from urllib.parse import urlsplit

TELEGRAM_HOSTS = frozenset({"t.me", "telegram.me", "telegram.dog"})
KIND_WEB, KIND_INVITE, KIND_TME = "web", "invite", "tme"

_ZERO_WIDTH = dict.fromkeys(map(ord, "\u200b\u200c\u200d\u2060\ufeff\u00ad\u200e\u200f"))
_TRAIL = ".,;:!?)]}»\"'،؛"
_SCHEME_RE = re.compile(r"(?i)(?:https?://|tg://|www\.)[^\s<>\"']+")
_COMMON_TLDS = (
    "com|net|org|info|biz|io|me|ly|gl|co|cc|tv|xyz|top|site|online|click|link|app|dev|shop|store|live|"
    "club|vip|pro|icu|cn|ru|ir|tk|ml|ga|cf|gq|in|us|uk|de|fr|sa|ae|eg|iq|ws|to|sh|gg|fm|ai|bet|win|fun"
)
_BARE_RE = re.compile(
    rf"(?i)(?<![\w@./-])((?:[a-z0-9](?:[a-z0-9-]{{0,61}}[a-z0-9])?\.)+(?:{_COMMON_TLDS}))(?![\w-])(?::\d{{1,5}})?(/[^\s<>\"']*)?"
)
_HOST_RE = re.compile(r"^(?:[a-z0-9_](?:[a-z0-9_-]{0,61}[a-z0-9_])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$")
MAX_URL_LEN = 2048


@dataclass(frozen=True, slots=True)
class Link:
    host: str   # normalized (lower-case, punycode, no port/userinfo/trailing dot)
    kind: str   # web | invite | tme


def normalize_host(host: str) -> str | None:
    host = (host or "").strip().lower().rstrip(".")
    if not host or len(host) > 253:
        return None
    try:
        host = host.encode("idna").decode("ascii")
    except UnicodeError:
        return None
    return host if _HOST_RE.match(host) or _is_ip(host) else None


def _is_ip(host: str) -> bool:
    parts = host.split(".")
    return len(parts) == 4 and all(p.isdigit() and 0 <= int(p) <= 255 for p in parts)


def normalize_domain(value: object) -> str | None:
    """Clean an allowlist entry ('https://WWW.Example.com/x' -> 'example.com'); None if invalid."""
    if not isinstance(value, str):
        return None
    raw = value.strip().translate(_ZERO_WIDTH)
    if not raw or len(raw) > 253 or any(c.isspace() for c in raw):
        return None
    if "://" not in raw:
        raw = "//" + raw
    try:
        host = urlsplit(raw).hostname
    except ValueError:
        return None
    host = normalize_host(host or "")
    if host is None:
        return None
    return host[4:] if host.startswith("www.") and host.count(".") >= 2 else host


def parse_link(raw: str) -> Link | None:
    raw = (raw or "").strip().translate(_ZERO_WIDTH).rstrip(_TRAIL)
    if not raw or len(raw) > MAX_URL_LEN:
        return None
    low = raw.lower()
    if low.startswith("tg://"):
        rest = low[5:]
        return Link("t.me", KIND_INVITE if rest.startswith("join") else KIND_TME)
    candidate = raw if "://" in raw else "//" + raw
    try:
        parts = urlsplit(candidate)
        host = normalize_host(parts.hostname or "")
        path = parts.path or ""
    except ValueError:
        return None
    if host is None:
        return None  # unparseable: uncertain => not a violation
    if host in TELEGRAM_HOSTS:
        first = path.lstrip("/").split("/", 1)[0].lower()
        kind = KIND_INVITE if first.startswith("+") or first == "joinchat" else KIND_TME
        return Link("t.me", kind)
    return Link(host, KIND_WEB)


def _entity_type(entity: Any) -> str:
    t = getattr(entity, "type", None)
    return str(getattr(t, "value", t) or "")


def _slice_utf16(text: str, offset: int, length: int) -> str:
    data = text.encode("utf-16-le")
    return data[2 * offset: 2 * (offset + length)].decode("utf-16-le", errors="ignore")


def find_links(text: str | None, entities: Iterable[Any] | None = None) -> list[Link]:
    found: list[Link] = []
    seen: set[Link] = set()

    def add(link: Link | None) -> None:
        if link is not None and link not in seen:
            seen.add(link)
            found.append(link)

    text = text or ""
    for ent in entities or ():
        kind = _entity_type(ent)
        try:
            if kind == "text_link":
                add(parse_link(getattr(ent, "url", None) or ""))
            elif kind == "url":
                add(parse_link(_slice_utf16(text, int(ent.offset), int(ent.length))))
        except (TypeError, ValueError, AttributeError):
            continue
    cleaned = text.translate(_ZERO_WIDTH)
    for m in _SCHEME_RE.finditer(cleaned):
        add(parse_link(m.group(0)))
    for m in _BARE_RE.finditer(cleaned):
        add(parse_link(m.group(1) + (m.group(2) or "")))
    return found


def host_matches(host: str, allowed: str) -> bool:
    """Exact host or a true subdomain (evil-example.com does NOT match example.com)."""
    return host == allowed or host.endswith("." + allowed)


def violating_links(
    links: Sequence[Link], allow_domains: Iterable[str], *, allow_invites: bool = False
) -> list[Link]:
    allow = tuple(allow_domains)
    bad = []
    for link in links:
        if link.kind == KIND_INVITE:
            ok = allow_invites
        elif link.kind == KIND_TME:
            ok = any(host_matches("t.me", d) for d in allow)  # only if t.me itself is allowlisted
        else:
            ok = any(host_matches(link.host, d) for d in allow)
        if not ok:
            bad.append(link)
    return bad
