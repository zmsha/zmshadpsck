"""Typed, clamped per-group protection settings read from the group's flat settings JSON.

Everything is parsed defensively: a missing/invalid value falls back to the SAFE default and is never
trusted raw. Keys are flat snake_case (the Phase 2 validator allows <=50 keys, depth 3).
Defaults are protective but conservative (mute only, never ban).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..moderation.duration import MAX_DURATION_SECONDS, MIN_DURATION_SECONDS
from .adult_words import MAX_CUSTOM_WORDS, normalize_word
from .links import normalize_domain

MIN_MUTE, MAX_MUTE = 60, 30 * 86400  # Telegram treats <30s or >366d as "forever": stay well inside
DEFAULT_ESCALATION = (600, 3600, 86400)
MAX_DOMAINS = 100
# Inclusive bounds, shared with the `/protect` `/antiflood` `/slowmode` parsers (`moderation/config_args.py`) so a value a
# command accepts is always a value `ProtectionSettings.from_raw` keeps (tests assert this parity).
FLOOD_MESSAGES = (2, 100)
FLOOD_WINDOW = (2, 600)
DUPLICATE_REPEATS = (2, 50)
DUPLICATE_WINDOW = (5, 3600)
ESCALATION_WINDOW = (3600, 365 * 86400)
WARN_LIMIT = (1, 20)
SLOWMODE = (5, 3600)  # seconds between two messages of one member; 0 = off (bot-enforced, see engine.py)


def _int(raw: dict, key: str, default: int, lo: int, hi: int) -> int:
    v = raw.get(key, default)
    if isinstance(v, bool) or not isinstance(v, int):
        return default
    return v if lo <= v <= hi else default


def _bool(raw: dict, key: str, default: bool) -> bool:
    v = raw.get(key, default)
    return v if isinstance(v, bool) else default


def _escalation(raw: dict) -> tuple[int, ...]:
    v = raw.get("escalation_mutes_seconds")
    if not isinstance(v, list) or not 1 <= len(v) <= 10:
        return DEFAULT_ESCALATION
    out = []
    for item in v:
        if isinstance(item, bool) or not isinstance(item, int) or not MIN_MUTE <= item <= MAX_MUTE:
            return DEFAULT_ESCALATION
        out.append(item)
    return tuple(out)


WARN_ACTIONS = ("mute", "kick", "ban")


def _choice(raw: dict, key: str, default: str, allowed: tuple[str, ...]) -> str:
    v = raw.get(key, default)
    return v if isinstance(v, str) and v in allowed else default


def _warn_seconds(raw: dict) -> int:
    """0 = permanent (mute/ban); otherwise inside the moderation duration bounds. Invalid => default 1 day."""
    v = raw.get("warn_action_seconds", 86400)
    if isinstance(v, bool) or not isinstance(v, int):
        return 86400
    return v if v == 0 or MIN_DURATION_SECONDS <= v <= MAX_DURATION_SECONDS else 86400


def _slowmode(raw: dict) -> int:
    """0 = off; otherwise inside SLOWMODE. Anything else => off (never enforce a value we cannot vouch for)."""
    v = raw.get("slowmode_seconds", 0)
    if isinstance(v, bool) or not isinstance(v, int):
        return 0
    return v if v == 0 or SLOWMODE[0] <= v <= SLOWMODE[1] else 0


def _domains(raw: dict) -> tuple[str, ...]:
    v = raw.get("links_allow_domains")
    if not isinstance(v, list):
        return ()
    out: list[str] = []
    for item in v[:MAX_DOMAINS]:
        d = normalize_domain(item)
        if d and d not in out:
            out.append(d)
    return tuple(out)


def _adult_words(raw: dict) -> tuple[str, ...]:
    """The group's own extra words: folded, unique, at most MAX_CUSTOM_WORDS. Anything invalid is dropped."""
    v = raw.get("adult_custom_words")
    if not isinstance(v, list):
        return ()
    out: list[str] = []
    for item in v[:MAX_CUSTOM_WORDS]:
        w = normalize_word(item)
        if w and w not in out:
            out.append(w)
    return tuple(out)


MAX_CF_EXEMPT = 50


def _cf_exempt(raw: dict) -> tuple[int, ...]:
    """Telegram user ids the content filter never touches (besides the owner/admins who are always exempt)."""
    v = raw.get("cf_exempt")
    if not isinstance(v, list):
        return ()
    out: list[int] = []
    for item in v:
        if isinstance(item, int) and not isinstance(item, bool) and 0 < item < 2**63 and item not in out:
            out.append(item)
        if len(out) >= MAX_CF_EXEMPT:
            break
    return tuple(out)


@dataclass(frozen=True, slots=True)
class ProtectionSettings:
    links_enabled: bool = True
    links_allow_domains: tuple[str, ...] = ()
    links_allow_invites: bool = False
    escalation_mutes_seconds: tuple[int, ...] = DEFAULT_ESCALATION
    escalation_window_seconds: int = 7 * 86400
    flood_enabled: bool = True
    flood_max_messages: int = 6
    flood_window_seconds: int = 10
    duplicate_enabled: bool = True
    duplicate_max_repeats: int = 3
    duplicate_window_seconds: int = 60
    duplicate_min_length: int = 4
    dry_run: bool = False
    # Manual warnings (Phase 3 part 4): at `warn_limit` active warnings apply `warn_action`.
    warn_limit: int = 3
    warn_action: str = "mute"  # mute | kick | ban
    warn_action_seconds: int = 86400  # 0 = permanent; ignored for kick
    # Bot-enforced slow mode (Phase 3 closing part 3): a member's message sent sooner than this after their previous
    # accepted one is deleted (no mute, no offense). 0 = off. Telegram's own slow mode cannot be set through the Bot API.
    slowmode_seconds: int = 0
    # Adult-word filter (part 9.1): text/caption containing a listed word is deleted and the sender gets the escalating mute.
    adult_enabled: bool = True
    adult_custom_words: tuple[str, ...] = ()
    # Content filter (part 9.2). `adult_enabled` is the master switch of the TEXT filter; these refine it:
    cf_ai: bool = True        # let Gemini judge suspicious (not clear) content; clear violations are always handled locally
    cf_emoji: bool = True     # a banned emoji (banned_emojis.txt) in a message or a member name = immediate ban
    cf_scripts: bool = True   # a letter of a blocked writing system (blocked_scripts.txt) in a message = delete + immediate ban
    cf_names: bool = True     # screen new members' first/last name and username
    cf_photos: bool = True    # screen new members' profile photo with Gemini Vision (needs Gemini keys; never stored)
    cf_exempt: tuple[int, ...] = ()  # user ids the content filter never touches

    def mute_for(self, offense_number: int) -> int:
        """Seconds to mute for the n-th offense inside the escalation window (1-based)."""
        steps = self.escalation_mutes_seconds
        return steps[min(max(offense_number, 1), len(steps)) - 1]

    @classmethod
    def from_raw(cls, raw: Any) -> "ProtectionSettings":
        if not isinstance(raw, dict):
            return cls()
        return cls(
            links_enabled=_bool(raw, "links_enabled", True),
            links_allow_domains=_domains(raw),
            links_allow_invites=_bool(raw, "links_allow_invites", False),
            escalation_mutes_seconds=_escalation(raw),
            escalation_window_seconds=_int(raw, "escalation_window_seconds", 7 * 86400, *ESCALATION_WINDOW),
            flood_enabled=_bool(raw, "flood_enabled", True),
            flood_max_messages=_int(raw, "flood_max_messages", 6, *FLOOD_MESSAGES),
            flood_window_seconds=_int(raw, "flood_window_seconds", 10, *FLOOD_WINDOW),
            duplicate_enabled=_bool(raw, "duplicate_enabled", True),
            duplicate_max_repeats=_int(raw, "duplicate_max_repeats", 3, *DUPLICATE_REPEATS),
            duplicate_window_seconds=_int(raw, "duplicate_window_seconds", 60, *DUPLICATE_WINDOW),
            duplicate_min_length=_int(raw, "duplicate_min_length", 4, 1, 100),
            dry_run=_bool(raw, "dry_run", False),
            warn_limit=_int(raw, "warn_limit", 3, *WARN_LIMIT),
            warn_action=_choice(raw, "warn_action", "mute", WARN_ACTIONS),
            warn_action_seconds=_warn_seconds(raw),
            slowmode_seconds=_slowmode(raw),
            adult_enabled=_bool(raw, "adult_enabled", True),
            adult_custom_words=_adult_words(raw),
            cf_ai=_bool(raw, "cf_ai", True),
            cf_emoji=_bool(raw, "cf_emoji", True),
            cf_scripts=_bool(raw, "cf_scripts", True),
            cf_names=_bool(raw, "cf_names", True),
            cf_photos=_bool(raw, "cf_photos", True),
            cf_exempt=_cf_exempt(raw),
        )
