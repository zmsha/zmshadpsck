"""Adult / sexually explicit WORD filter (part 9.1). Pure and framework independent: text in, bool out.

What it does
* Normalises the text so common evasions do not work: Arabic diacritics, tatweel and zero-width marks, alef / ya / ta-marbuta
  folding, repeated letters (`سكسسسس`), spaced-out letters (`س ك س`, `p o r n`), separators inside a word (`س.ك.س`,
  `p_o_r_n`) and look-alike digits / symbols in Latin words (`p0rn`, `n.u.d.e`, `$ex` is NOT guessed: only digits/symbols that
  replace a letter inside a Latin word).
* Matches WHOLE words only (after stripping one common Arabic prefix such as و / ب / ف / ل / ال), so a harmless word that merely
  contains a listed word is never flagged.
* Group admins may add their own words (`/protect adult add ...`); the built-in list is fixed.

Limits (documented, not hidden): this inspects TEXT and CAPTIONS only. It cannot see what is inside a photo, video, GIF or
sticker. A word that is harmless in some contexts and listed anyway can be a false positive; admins who disagree can turn the
filter off with `/protect adult off`.
"""
from __future__ import annotations

import re
import unicodedata

MAX_CUSTOM_WORDS = 100
MAX_WORD_LEN = 30
MAX_CUSTOM_JSON_BYTES = 3000  # the settings validator allows 4096 bytes per patch; keep headroom

_ZERO_WIDTH = dict.fromkeys(map(ord, "\u200b\u200c\u200d\u200e\u200f\u202a\u202b\u202c\u202d\u202e\u2060\u2066\u2067\u2068\u2069\ufeff"))
_DIACRITICS = re.compile("[\u064b-\u065f\u0670\u06d6-\u06ed\u0640]")
_ARABIC_FOLD = str.maketrans({"أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا", "ة": "ه", "ى": "ي", "ؤ": "و", "ئ": "ي", "گ": "ك",
                              "ک": "ك", "ی": "ي", "پ": "ب"})
_LATIN_LOOKALIKE = str.maketrans({"0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t", "@": "a", "$": "s", "!": "i"})
_REPEAT = re.compile(r"(.)\1+")
_NON_WORD = re.compile(r"[^\w]+|_+", re.UNICODE)
_HAS_ARABIC = re.compile("[\u0600-\u06ff]")
_HAS_LATIN = re.compile("[a-z]")
_PREFIXES = ("وبال", "وال", "بال", "فال", "كال", "لل", "ال", "و", "ب", "ف", "ل", "ك")

# Built-in lexicon: clearly sexual / pornographic terms only (no ordinary profanity, no medical or ethnic words).
# Stored in the same normalised form `fold()` produces (repeats collapsed), so they are compared as-is.
_ARABIC_WORDS = (
    "سكس", "سيكس", "نيك", "ينيك", "نيكني", "منيوك", "منيوكه", "متناك", "متناكه", "شرموطه", "شرموط", "شراميط", "قحبه",
    "قحاب", "عاهره", "كس", "كسم", "كسمك", "كسختك", "زب", "زبي", "طيز", "بزاز", "سحاق", "سحاقيه", "لواط", "اباحي",
    "اباحيه", "اباحيات", "بورن", "بورنو", "نودز", "نيود", "سكسي", "مومس",
)
_LATIN_WORDS = (
    "porn", "porno", "pornhub", "xvideos", "xnxx", "xhamster", "redtube", "youporn", "brazzers", "hentai", "nsfw",
    "nude", "nudes", "blowjob", "handjob", "cumshot", "pussy", "tits", "onlyfans", "milf", "orgy",
    "sexcam", "sexchat", "camgirl", "escort",
)
_PHRASES = ("افلام اباحيه", "مقاطع اباحيه", "صور اباحيه", "قنوات اباحيه", "فيديوهات اباحيه", "sex video", "sex videos",
            "sex chat", "adult video", "adult videos", "adult content")


def prefold(text: object) -> str:
    """Lowercase NFKC text without invisible marks / diacritics / tatweel and with Arabic letters folded (repeats KEPT)."""
    if not isinstance(text, str):
        return ""
    s = unicodedata.normalize("NFKC", text).translate(_ZERO_WIDTH).lower()
    return _DIACRITICS.sub("", s).translate(_ARABIC_FOLD)


def fold(text: object) -> str:
    """`prefold` plus runs of one repeated letter collapsed to a single letter (`سكسسسس` -> `سكس`)."""
    return _REPEAT.sub(r"\1", prefold(text))


def _tokens(text: str) -> list[str]:
    return [tok for tok in _NON_WORD.split(text) if tok]


def _glue_singles(tokens: list[str]) -> list[str]:
    """`["س", "ك", "س"]` -> `["سكس"]`: a run of 3+ single characters is also tried as one word (spaced-out evasion)."""
    out: list[str] = []
    run: list[str] = []
    for tok in tokens + [""]:
        if len(tok) == 1 and not tok.isdigit():
            run.append(tok)
            continue
        if len(run) >= 3:
            out.append("".join(run))
        run = []
    return out


def _delook(token: str) -> str | None:
    """Latin word written with digits/symbols for letters (`p0rn`): the de-obfuscated form, or None when it does not apply."""
    if not (token.isascii() and any(c in "013457@$!" for c in token) and _HAS_LATIN.search(token)):
        return None
    return _REPEAT.sub(r"\1", token.translate(_LATIN_LOOKALIKE))


def normalize_word(word: object) -> str | None:
    """A custom word as stored/compared: folded, single token, 2..MAX_WORD_LEN characters, letters/digits only."""
    f = fold(word)
    if not isinstance(word, str) or not 2 <= len(f) <= MAX_WORD_LEN or _NON_WORD.search(f):
        return None
    return f


_BUILTIN = frozenset(fold(w) for w in (*_ARABIC_WORDS, *_LATIN_WORDS))
_BUILTIN_PHRASES = tuple(fold(p) for p in _PHRASES)


def _strip_prefixes(token: str) -> list[str]:
    forms = [token]
    if _HAS_ARABIC.search(token):
        for p in _PREFIXES:
            if token.startswith(p) and len(token) - len(p) >= 2:
                forms.append(token[len(p):])
    return forms


def find_adult(text: object, custom: tuple[str, ...] | list[str] = ()) -> str | None:
    """The first listed word / phrase found in `text` (folded form, for audit/tests only), or None."""
    if not isinstance(text, str) or not text.strip():
        return None
    if "xxx" in _tokens(text.lower()):  # the generic repeat-collapse would turn it into "x", so it is checked on the raw token
        return "xxx"
    folded = fold(text)
    words = _BUILTIN | frozenset(c for c in custom if isinstance(c, str))
    tokens = _tokens(folded)
    candidates = list(tokens) + _glue_singles(tokens)
    for tok in list(candidates):
        d = _delook(tok)
        if d:
            candidates.append(d)
    for tok in candidates:
        for form in _strip_prefixes(tok):
            if form in words:
                return form
    spaced = " " + " ".join(tokens) + " "
    for phrase in (*_BUILTIN_PHRASES, *(c for c in custom if isinstance(c, str) and " " in c)):
        if f" {phrase} " in spaced:
            return phrase
    return None
