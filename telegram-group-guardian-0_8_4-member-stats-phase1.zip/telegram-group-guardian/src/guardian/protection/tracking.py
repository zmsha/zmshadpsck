"""Bounded in-memory sliding-window counters (process-local: reset on restart/sleep - documented).

Used for flood and duplicate-message detection (volatile by design). Keys are (group_id, user_id[, digest]);
message text is never stored (only a short digest). A hard cap on keys (LRU eviction) bounds memory.
Escalation offenses are NOT here any more: they live in `moderation_sanctions` (see `offenses.py`).
"""
from __future__ import annotations

import asyncio
import hashlib
from collections import OrderedDict, deque
from contextlib import asynccontextmanager
from typing import Hashable

MAX_KEYS = 20_000


class SlidingCounter:
    def __init__(self, max_keys: int = MAX_KEYS):
        self._max = max_keys
        self._data: "OrderedDict[Hashable, deque[float]]" = OrderedDict()

    def hit(self, key: Hashable, now: float, window: float) -> int:
        """Record an event and return how many events (including this one) fall in the window."""
        q = self._data.get(key)
        if q is None:
            q = deque()
            self._data[key] = q
            if len(self._data) > self._max:
                self._data.popitem(last=False)
        else:
            self._data.move_to_end(key)
        q.append(now)
        cutoff = now - window
        while q and q[0] <= cutoff:
            q.popleft()
        return len(q)

    def reset(self, key: Hashable) -> None:
        self._data.pop(key, None)

    def __len__(self) -> int:
        return len(self._data)


class LastSeen:
    """Bounded LRU map key -> (timestamp, message_id) of a member's last ACCEPTED message (bot slow mode).
    Process-local like the counters above: it resets on restart/sleep, which only ever makes slow mode more lenient."""

    def __init__(self, max_keys: int = MAX_KEYS):
        self._max = max_keys
        self._data: "OrderedDict[Hashable, tuple[float, int]]" = OrderedDict()

    def get(self, key: Hashable) -> tuple[float, int] | None:
        return self._data.get(key)

    def put(self, key: Hashable, ts: float, message_id: int) -> None:
        self._data[key] = (ts, message_id)
        self._data.move_to_end(key)
        while len(self._data) > self._max:
            self._data.popitem(last=False)

    def forget(self, key: Hashable) -> None:
        self._data.pop(key, None)

    def __len__(self) -> int:
        return len(self._data)


def text_digest(text: str) -> str:
    normalized = " ".join(text.lower().split())
    return hashlib.sha1(normalized.encode("utf-8", "ignore")).hexdigest()[:16]


class KeyedLocks:
    """Per-key asyncio locks that disappear when unused (bounded memory). Serialises the
    read-decide-act-record section for one (group, user) so concurrent updates cannot double-escalate."""

    def __init__(self) -> None:
        self._locks: dict[Hashable, list] = {}  # key -> [lock, users]

    @asynccontextmanager
    async def hold(self, key: Hashable):
        entry = self._locks.get(key)
        if entry is None:
            entry = self._locks[key] = [asyncio.Lock(), 0]
        entry[1] += 1
        try:
            async with entry[0]:
                yield
        finally:
            entry[1] -= 1
            if entry[1] == 0:
                self._locks.pop(key, None)

    def __len__(self) -> int:
        return len(self._locks)
