"""Safe one-way sender to `OWNER_GROUP_ID` (phase 5.5).

Guarantees (all tested):
* the destination is FIXED at construction (the configured owner group); no caller can pick another chat, so the hub cannot
  be used to push data elsewhere;
* every text and caption passes through the redactor first; files pass `screen_file` (`.env` and key material are refused);
* `send_*` and `post_text` NEVER raise: a failing hub (bot removed, chat id wrong, Telegram down, timeout) is logged without
  details that could hold a secret, then silenced by an exponential cooldown so a broken hub does not slow every event;
* sending is a pure notification: there is NO retry of the operation that produced the notice (the caller already finished it);
  at most one bounded attempt per call;
* if `OWNER_GROUP_ID` is unset the hub is simply disabled.
"""
from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Callable, Iterable, Protocol

from ..time_utils import utcnow
from .redactor import redact_text, screen_file

log = logging.getLogger(__name__)

MAX_TEXT = 4000                       # Telegram allows 4096; keep headroom for the ellipsis and closing tags
MAX_CAPTION = 1000                    # Telegram allows 1024
SEND_TIMEOUT = 8.0                    # seconds; a hung Telegram call must not stall a webhook handler
BASE_COOLDOWN = timedelta(seconds=60)
MAX_COOLDOWN = timedelta(minutes=15)
_BALANCED_TAGS = ("b", "i", "u", "s", "code", "pre")
_TAG_RE = re.compile(r"<(/?)([a-z]+)(?:\s[^>]*)?>")


class HubTransport(Protocol):
    """Framework adapter (`bot/hub_transport.py`). The chat id is passed by the sender, never by a caller of the hub."""

    async def send_message(self, chat_id: int, text: str) -> None: ...

    async def send_document(self, chat_id: int, filename: str, data: bytes, caption: str | None) -> None: ...


@dataclass(frozen=True, slots=True)
class HubResult:
    delivered: bool
    reason: str     # sent | disabled | empty | cooldown | failed | timeout | file_rejected:<why>


@dataclass(slots=True)
class HubHealth:
    """Read-only snapshot for reports/tests."""
    enabled: bool
    consecutive_failures: int = 0
    last_failure_at: datetime | None = None
    last_success_at: datetime | None = None
    last_error_kind: str | None = None
    skipped_in_cooldown: int = 0
    cooldown_until: datetime | None = None


def fit_html(text: str, limit: int = MAX_TEXT) -> str:
    """Cut `text` to `limit` characters at a line boundary WITHOUT leaving a half tag or an unclosed <b>/<code>/... (Telegram
    rejects the whole message on broken HTML, which would silently drop the report)."""
    if len(text) <= limit:
        return text
    cut = text[: limit - 1]
    newline = cut.rfind("\n")
    if newline > limit // 2:
        cut = cut[:newline]
    cut = re.sub(r"<[^>]*$", "", cut)           # half tag at the end
    cut = re.sub(r"&[A-Za-z#0-9]{0,8}$", "", cut)  # half entity at the end
    stack: list[str] = []
    for match in _TAG_RE.finditer(cut):
        closing, name = match.group(1), match.group(2)
        if name not in _BALANCED_TAGS:
            continue
        if closing:
            if name in stack:
                while stack and stack.pop() != name:
                    pass
        else:
            stack.append(name)
    return cut + "…" + "".join(f"</{name}>" for name in reversed(stack))


class OwnerHubSender:
    def __init__(self, transport: HubTransport | None, chat_id: int | None, *, secrets: Iterable[str] = (),
                 clock: Callable[[], datetime] = utcnow, timeout: float = SEND_TIMEOUT,
                 base_cooldown: timedelta = BASE_COOLDOWN, max_cooldown: timedelta = MAX_COOLDOWN):
        self._transport = transport
        self._chat_id = chat_id
        self._secrets = tuple(s for s in secrets if s)
        self._clock, self._timeout = clock, timeout
        self._base, self._max = base_cooldown, max_cooldown
        self._failures = 0
        self._cooldown_until: datetime | None = None
        self._skipped = 0
        self._last_failure: datetime | None = None
        self._last_success: datetime | None = None
        self._last_kind: str | None = None
        self._tasks: set[asyncio.Task] = set()

    # ------------------------------------------------------------------ state
    @property
    def enabled(self) -> bool:
        return self._transport is not None and self._chat_id is not None

    def health(self) -> HubHealth:
        return HubHealth(self.enabled, self._failures, self._last_failure, self._last_success, self._last_kind,
                         self._skipped, self._cooldown_until)

    def _in_cooldown(self) -> bool:
        if self._cooldown_until is None:
            return False
        if self._clock() >= self._cooldown_until:
            return False  # the next attempt is allowed (a success resets the counter)
        self._skipped += 1
        return True

    def _failed(self, kind: str) -> None:
        now = self._clock()
        self._failures += 1
        self._last_failure, self._last_kind = now, kind
        delay = min(self._base * (2 ** (self._failures - 1)), self._max)
        self._cooldown_until = now + delay
        # type name only: exception text of HTTP clients can contain the request URL (the bot token)
        log.warning("owner hub delivery failed (%s); %d consecutive; paused %ds", kind, self._failures, int(delay.total_seconds()))

    def _succeeded(self) -> None:
        self._failures, self._cooldown_until = 0, None
        self._last_success = self._clock()

    # ------------------------------------------------------------------ sending
    async def send_text(self, text: str | None) -> HubResult:
        """One attempt, bounded by a timeout. Never raises."""
        try:
            if not self.enabled:
                return HubResult(False, "disabled")
            body = fit_html(redact_text(text, self._secrets))
            if not body.strip():
                return HubResult(False, "empty")
            if self._in_cooldown():
                return HubResult(False, "cooldown")
            return await self._deliver(self._transport.send_message(self._chat_id, body))  # type: ignore[union-attr]
        except Exception as exc:  # defensive: the contract is "never raises"
            self._failed(type(exc).__name__)
            return HubResult(False, "failed")

    async def send_file(self, filename: object, data: object, caption: str | None = None) -> HubResult:
        """Refuses `.env`/key files; other text files are sent redacted. Never raises."""
        try:
            if not self.enabled:
                return HubResult(False, "disabled")
            verdict = screen_file(filename, data, self._secrets)
            if not verdict.allowed:
                log.warning("owner hub refused a file (%s)", verdict.reason)
                return HubResult(False, f"file_rejected:{verdict.reason}")
            if self._in_cooldown():
                return HubResult(False, "cooldown")
            cap = fit_html(redact_text(caption, self._secrets), MAX_CAPTION) if caption else None
            return await self._deliver(self._transport.send_document(self._chat_id, verdict.filename, verdict.data, cap))  # type: ignore[union-attr]
        except Exception as exc:
            self._failed(type(exc).__name__)
            return HubResult(False, "failed")

    async def _deliver(self, awaitable) -> HubResult:
        try:
            await asyncio.wait_for(awaitable, timeout=self._timeout)
        except asyncio.TimeoutError:
            self._failed("timeout")
            return HubResult(False, "timeout")
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self._failed(type(exc).__name__)
            return HubResult(False, "failed")
        self._succeeded()
        return HubResult(True, "sent")

    # ------------------------------------------------------------------ fire and forget
    def post_text(self, text: str | None) -> None:
        """Schedule a notice without delaying the caller (e.g. an owner-panel callback). Never raises. Needs a running loop;
        without one the notice is dropped (it is only a notification)."""
        if not self.enabled:
            return
        try:
            task = asyncio.get_running_loop().create_task(self.send_text(text))
        except RuntimeError:
            return
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    async def drain(self) -> None:
        """Wait for scheduled notices (shutdown / tests)."""
        if self._tasks:
            await asyncio.gather(*list(self._tasks), return_exceptions=True)


class DisabledHub(OwnerHubSender):
    """Used when OWNER_GROUP_ID is not configured."""

    def __init__(self) -> None:
        super().__init__(None, None)
