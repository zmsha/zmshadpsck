"""`Notifier` wrapper: every owner notice (new group, registration failure, missing bot rights) is also copied to the owner hub.

The wrapped notifier keeps its exact behaviour (including raising when the private message fails, which callers already
guard); the copy to the hub is attempted afterwards either way and can never raise or delay protection (it is scheduled, not awaited). Group notices (`notify_group`) are NOT mirrored: they are messages for that group's members.
"""
from __future__ import annotations

from typing import Any


class HubMirroringNotifier:
    def __init__(self, inner: Any, hub: Any):
        self._inner, self._hub = inner, hub

    async def notify_group(self, group_id: int, text: str) -> None:
        await self._inner.notify_group(group_id, text)

    async def notify_owner(self, text: str) -> None:
        try:
            await self._inner.notify_owner(text)
        finally:
            self._hub.post_text(text)  # fire and forget: protection never waits for the hub
