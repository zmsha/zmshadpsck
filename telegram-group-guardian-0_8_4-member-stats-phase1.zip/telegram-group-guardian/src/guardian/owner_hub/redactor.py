"""Secret redaction for everything that may leave the bot towards Telegram (phase 5.5).

`redact_text` removes: the exact configured secrets (and their URL-quoted forms), bot-token-shaped strings, whole database
URLs, `NAME=value` / `NAME: value` pairs whose NAME looks secret (BOT_TOKEN, PASSWORD, ...), PEM private-key blocks,
`Authorization`/Bearer values and long random-looking key strings. `screen_file` decides whether a file may be sent at all:
`.env` files, key stores and anything that looks like a dotenv are REFUSED (never "cleaned and sent"); other text files are
sent only after redaction and a final check that no known secret survived.
"""
from __future__ import annotations

import posixpath
import re
from dataclasses import dataclass
from typing import Iterable
from urllib.parse import quote

from ..logging_setup import REDACTED, redact as _base_redact

MAX_FILE_BYTES = 1_000_000
ALLOWED_EXTENSIONS = frozenset({".txt", ".csv", ".tsv", ".json", ".md", ".log"})
MAX_FILENAME_LEN = 80

_SECRET_WORDS = (
    "token", "secret", "password", "passwd", "pwd", "passphrase", "api_key", "apikey", "api-key", "private_key", "privatekey",
    "private-key", "encryption_key", "encryption-key", "database_url", "db_url", "dsn", "credential", "auth_key", "signing_key",
    "access_key", "secret_key",
)
_NAME = r"[A-Za-z_][A-Za-z0-9_.\-]{0,63}"
_PAIR_RE = re.compile(rf"(?P<name>{_NAME})(?P<sep>[\"']?\s*[=:]\s*)(?P<value>\"[^\"\n]*\"|'[^'\n]*'|[^\s\"',;]+)")
_DSN_RE = re.compile(r"\b(?:postgres(?:ql)?|mysql|mongodb(?:\+srv)?|redis|amqps?)://[^\s\"'<>]+", re.IGNORECASE)
_PEM_RE = re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?(?:-----END [A-Z ]*PRIVATE KEY-----|\Z)", re.DOTALL)
_PEM_HEADER_RE = re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")
_BEARER_RE = re.compile(r"(?i)\b(authorization\s*[:=]\s*)?(bearer|basic)\s+[A-Za-z0-9._~+/=\-]{8,}")
_LONG_KEY_RE = re.compile(r"(?<![A-Za-z0-9+/=_\-])[A-Za-z0-9+/=_\-]{40,}(?![A-Za-z0-9+/=_\-])")
_DOTENV_LINE_RE = re.compile(r"^\s*(?:export\s+)?[A-Z][A-Z0-9_]{2,}\s*=", re.MULTILINE)

_BLOCKED_NAME_RE = re.compile(
    r"(^|[._\-])(env|dotenv|secrets?|credentials?|passwords?|keystore|id_rsa|id_ed25519|id_ecdsa|netrc|pgpass)([._\-]|$)", re.IGNORECASE)
_BLOCKED_EXTENSIONS = frozenset({
    ".env", ".pem", ".key", ".p12", ".pfx", ".jks", ".keystore", ".kdbx", ".gpg", ".asc", ".crt", ".cer", ".der", ".ppk",
    ".sqlite", ".sqlite3", ".db", ".sql", ".bak", ".dump", ".zip", ".gz", ".tar", ".7z", ".rar",
})


def _looks_secret_name(name: str) -> bool:
    lowered = name.lower()
    return any(word in lowered for word in _SECRET_WORDS)


def _secret_variants(secrets: Iterable[str]) -> list[str]:
    out: set[str] = set()
    for secret in secrets:
        if not secret or len(secret) < 4:
            continue
        out.add(secret)
        quoted = quote(secret, safe="")
        if quoted != secret:
            out.add(quoted)
    return sorted(out, key=len, reverse=True)


def _mask_pair(match: re.Match) -> str:
    if _looks_secret_name(match.group("name")):
        return f"{match.group('name')}{match.group('sep')}{REDACTED}"
    return match.group(0)


def _mask_long_key(match: re.Match) -> str:
    token = match.group(0)
    # only random-looking strings: letters AND digits, so long plain words / separators / paths are not touched
    if re.search(r"[A-Za-z]", token) and re.search(r"\d", token):
        return REDACTED
    return token


def redact_text(text: str | None, secrets: Iterable[str] = ()) -> str:
    """Never raises; `None` -> ''. Idempotent (redacting twice changes nothing more)."""
    if not text:
        return ""
    out = str(text)
    for secret in _secret_variants(secrets):
        out = out.replace(secret, REDACTED)
    out = _PEM_RE.sub(REDACTED, out)
    out = _DSN_RE.sub(REDACTED, out)
    out = _BEARER_RE.sub(REDACTED, out)
    out = _PAIR_RE.sub(_mask_pair, out)
    out = _base_redact(out)  # bot tokens + URL passwords (the logging redactor)
    out = _LONG_KEY_RE.sub(_mask_long_key, out)
    return out


# ---------------------------------------------------------------------------------------------------- files
@dataclass(frozen=True, slots=True)
class FileVerdict:
    allowed: bool
    reason: str = "ok"              # ok | empty | bad_name | blocked_name | blocked_extension | extension_not_allowed |
                                    # too_large | not_text | dotenv_content | private_key | secret_survived
    filename: str = ""              # sanitized name to use when allowed
    data: bytes = b""               # redacted bytes to send when allowed
    redactions: int = 0             # how many places were masked in the content (0 = nothing found)


def _refuse(reason: str) -> FileVerdict:
    return FileVerdict(False, reason)


def safe_filename(name: str, secrets: Iterable[str] = ()) -> str:
    """Basename only, secrets masked, ASCII-safe characters; the extension is kept and an empty stem becomes `file`."""
    base = posixpath.basename(str(name).replace("\\", "/")).strip()
    stem, ext = posixpath.splitext(redact_text(base, secrets))
    stem = re.sub(r"[^\w\-]", "_", stem, flags=re.ASCII)
    stem = re.sub(r"_+", "_", stem).strip("_-") or "file"
    ext = re.sub(r"[^\w.]", "", ext, flags=re.ASCII).lower()
    return (stem[: MAX_FILENAME_LEN - len(ext)] + ext)[:MAX_FILENAME_LEN]


def screen_file(filename: object, data: object, secrets: Iterable[str] = ()) -> FileVerdict:
    """Decide whether `data` may be sent as a document. Never raises."""
    secrets = tuple(secrets)
    if not isinstance(filename, str) or not filename.strip() or "\x00" in filename:
        return _refuse("bad_name")
    if not isinstance(data, (bytes, bytearray)):
        return _refuse("not_text")
    raw = bytes(data)
    if not raw.strip():
        return _refuse("empty")
    lowered = posixpath.basename(filename.replace("\\", "/")).strip().lower()
    ext = posixpath.splitext(lowered)[1]
    if lowered.startswith(".env") or ext == ".env" or _BLOCKED_NAME_RE.search(lowered):
        return _refuse("blocked_name")
    if ext in _BLOCKED_EXTENSIONS:
        return _refuse("blocked_extension")
    if ext not in ALLOWED_EXTENSIONS:
        return _refuse("extension_not_allowed")
    if len(raw) > MAX_FILE_BYTES:
        return _refuse("too_large")
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        return _refuse("not_text")
    if "\x00" in text:
        return _refuse("not_text")
    if _PEM_HEADER_RE.search(text):
        return _refuse("private_key")
    env_lines = _DOTENV_LINE_RE.findall(text)
    if len(env_lines) >= 3 and any(_looks_secret_name(line.split("=")[0]) for line in env_lines):
        return _refuse("dotenv_content")  # a dotenv-shaped file is refused, never "cleaned and sent"
    cleaned = redact_text(text, secrets)
    for secret in _secret_variants(secrets):
        if secret in cleaned:  # defence in depth; cannot happen unless redact_text is broken
            return _refuse("secret_survived")
    name = safe_filename(filename, secrets)
    if not name or posixpath.splitext(name.lower())[1] not in ALLOWED_EXTENSIONS:
        return _refuse("bad_name")
    return FileVerdict(True, "ok", name, cleaned.encode("utf-8"), redactions=cleaned.count(REDACTED) - text.count(REDACTED))
