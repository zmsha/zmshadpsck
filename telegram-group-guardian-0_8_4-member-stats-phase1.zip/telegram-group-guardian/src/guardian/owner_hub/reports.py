"""Texts and the reporter of the owner hub (phase 5.5). Read-only: it only looks at licenses and tells the hub sender.

Texts come from `i18n` (values are HTML-escaped there). Nothing here mentions tokens, URLs, hosts or credentials: a report
holds counts, group titles/ids, statuses and times only, and the sender redacts again before delivery.
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Any, Callable, Sequence

from ..i18n import Raw, license_label, t
from ..licensing.models import GroupLicense, LicenseStatus, effective_status
from ..time_utils import format_display, utcnow

log = logging.getLogger(__name__)

EXPIRING_DAYS = 7
MAX_EXPIRING_LINES = 5
SOURCE_PANEL = "panel"
SOURCE_COMMAND = "command"
_ACTIONS = frozenset({"activate_permanent", "activate_temporary", "renew", "stop", "reject", "ban", "unban", "allow"})


def stats_text(licenses: Sequence[GroupLicense], now: datetime, tz: str, lang: str) -> str:
    """Counts by EFFECTIVE status (a lapsed temporary license is 'expired' even if the row was not updated yet) and the groups
    whose time ends within a week."""
    if not licenses:
        return t("hub_stats_none", lang)
    counts: dict[LicenseStatus, int] = {}
    expiring: list[tuple[datetime, GroupLicense]] = []
    horizon = now + timedelta(days=EXPIRING_DAYS)
    for lic in licenses:
        status = effective_status(lic, now)
        counts[status] = counts.get(status, 0) + 1
        if status is LicenseStatus.ACTIVE_TEMPORARY and lic.expires_at is not None and lic.expires_at <= horizon:
            expiring.append((lic.expires_at, lic))
    lines = Raw("\n".join(t("hub_stats_line", lang, label=license_label(s, lang), n=counts[s]) for s in LicenseStatus if s in counts))
    text = t("hub_stats", lang, total=len(licenses), lines=lines)
    if expiring:
        expiring.sort(key=lambda pair: pair[0])
        shown = Raw("\n".join(
            t("hub_expiring_line", lang, title=lic.title or t("title_unknown", lang), group_id=str(lic.group_id),
              when=format_display(when, tz))
            for when, lic in expiring[:MAX_EXPIRING_LINES]))
        text += "\n\n" + t("hub_stats_expiring", lang, days=EXPIRING_DAYS, lines=shown)
    return text


def license_change_text(lic: GroupLicense, action: str, source: str, now: datetime, tz: str, lang: str) -> str:
    expiry = Raw("")
    if lic.expires_at is not None and lic.status is LicenseStatus.ACTIVE_TEMPORARY:
        expiry = Raw(t("hub_expiry_line", lang, when=format_display(lic.expires_at, tz)))
    action_key = f"hub_act_{action}" if action in _ACTIONS else "hub_act_renew"
    return t("hub_license_change", lang, title=lic.title or t("title_unknown", lang), group_id=str(lic.group_id),
             action=t(action_key, lang), status=license_label(lic.status, lang), expiry=expiry,
             source=t("hub_source_command" if source == SOURCE_COMMAND else "hub_source_panel", lang),
             when=format_display(now, tz))


class HubReporter:
    """What the app tells the owner group. Every method never raises and never blocks protection."""

    def __init__(self, hub: Any, licenses: Any, *, display_timezone: str = "Asia/Riyadh", language: str = "ar",
                 version: str = "", environment: str = "production", clock: Callable[[], datetime] = utcnow):
        self._hub, self._licenses, self._tz, self._lang = hub, licenses, display_timezone, language
        self._version, self._environment, self._clock = version, environment, clock
        self._tasks: set[asyncio.Task] = set()

    async def stats(self) -> str:
        try:
            rows = await self._licenses.list_all()
        except Exception:
            log.warning("hub stats could not read the groups", exc_info=True)
            return t("hub_stats_unavailable", self._lang)
        return stats_text(rows, self._clock(), self._tz, self._lang)

    async def startup(self, *, db_status: str) -> None:
        """One report per process start (a Render Free wake-up is a start: expect one after each sleep). `db_status` is the
        last known state (`ok` | `unavailable` | `unknown`); statistics are only read when the database is known to be up."""
        try:
            now = self._clock()
            stats = await self.stats() if db_status == "ok" else t("hub_stats_unavailable", self._lang)
            db_key = {"ok": "hub_db_ok", "unavailable": "hub_db_down"}.get(db_status, "hub_db_unknown")
            text = t("hub_startup", self._lang, version=self._version, environment=self._environment,
                     when=format_display(now, self._tz), db=t(db_key, self._lang), stats=Raw(stats))
            await self._hub.send_text(text)
        except Exception:
            log.warning("hub startup report failed", exc_info=True)

    def post_startup(self, db_status: str) -> None:
        """Schedule the startup report so a slow or broken hub never delays the service becoming ready. Never raises."""
        if not getattr(self._hub, "enabled", False):
            return
        try:
            task = asyncio.get_running_loop().create_task(self.startup(db_status=db_status))
        except RuntimeError:
            return
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    async def drain(self) -> None:
        if self._tasks:
            await asyncio.gather(*list(self._tasks), return_exceptions=True)
        drain = getattr(self._hub, "drain", None)
        if drain is not None:
            await drain()

    def license_changed(self, lic: GroupLicense | None, action: str | None, source: str) -> None:
        """Notice after a license change that was ALREADY applied. Scheduled, not awaited; a failure changes nothing."""
        if lic is None or action is None:
            return
        try:
            self._hub.post_text(license_change_text(lic, action, source, self._clock(), self._tz, self._lang))
        except Exception:
            log.warning("hub license notice failed", exc_info=True)
