"""Owner hub (phase 5.5+): the `OWNER_GROUP_ID` control centre.

5.5 = a safe one-way sender (reports, license-change notices, allowed files) and the redactor every outgoing text/file passes
through. The hub is OBSERVATION only: nothing here changes a license or any protection setting, and a failing hub never
stops protection or repeats a sensitive operation.
"""
