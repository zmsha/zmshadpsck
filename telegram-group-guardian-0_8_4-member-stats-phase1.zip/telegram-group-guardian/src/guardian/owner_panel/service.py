"""Server-side logic of the OWNER panel (phase 5.3 reading, 5.4 license actions): opening it and handling every press.

Framework independent (no aiogram). Fixed sequence; ANY failure answers a refusal and changes nothing (fail closed):
 open  (`/owner [search]`, `لوحة المالك [بحث]`): private chat only -> `Permission.OWNER_PANEL` (exactly OWNER_TELEGRAM_ID,
       from Telegram's `from_user`; a non-owner gets SILENCE, audited) -> sets/clears the search -> first list page.
 press : structure -> private chat -> signature (HMAC over the pressed chat + screen/args) -> owner check on EVERY press
         (a crafted callback from anyone else is audited as `forged_callback` and refused) -> render from FRESH data.
This file never writes: it reads (`LicenseStore.list_all`, `get`) and delegates license changes to the injected `actions`
(`owner_panel/actions.py` -> the license admin service). An action press adds: group re-read -> EFFECTIVE status must still be the
one drawn on the button (else "stale", nothing applied) -> one claim per callback id -> admin service (owner check again,
transition check, atomic write+audit) -> the group's fresh details screen with the result as a toast. The signature and the
group id in a button are display hints; the owner check is what protects the data, never the hidden buttons.
The search text lives in memory only (it is lost when the free host sleeps: the list then simply shows every group).
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, replace
from datetime import datetime
from typing import Any, Callable

from ..audit import FORGED_CALLBACK, SecurityAudit, make_event, record_safely
from ..errors import GroupNotRegistered, InvalidInput, PermissionDenied
from ..i18n import license_label, t
from ..licensing.models import effective_status
from ..permissions import Permission
from ..time_utils import utcnow
from . import actions as act, codec, insight_views as iv, views
from .views import Buttons

log = logging.getLogger(__name__)

MAX_GROUPS = 2000        # rows read per render (far above "hundreds of groups"); more => the list says it is cut
MAX_SEARCHES = 16        # remembered search texts (bounded memory)


@dataclass(frozen=True, slots=True)
class OwnerOutcome:
    """What the aiogram layer must do. `toast` goes to `callback.answer`; `text`+`buttons` replace the panel message in
    place (or are sent as a new message when opening); `delete` removes it. `status` is a stable code (tests, logs)."""
    status: str
    toast: str = ""
    alert: bool = False
    text: str | None = None
    buttons: Buttons | None = None
    delete: bool = False


class OwnerPanelService:
    def __init__(self, *, permissions: Any, licenses: Any, audit: SecurityAudit | None, secret: str | bytes,
                 display_timezone: str = "Asia/Riyadh", language: str = "ar",
                 clock: Callable[[], datetime] = utcnow, max_groups: int = MAX_GROUPS, actions: Any = None,
                 hub: Any = None, templates: Any = None, overview: Any = None, applier: Any = None):
        self._perm, self._licenses, self._audit = permissions, licenses, audit
        self._actions = actions   # act.OwnerActions; None = read only (no action buttons, every action press refused)
        self._hub = hub           # owner_hub.reports.HubReporter | None: a notice AFTER a change was applied (never before, never blocks)
        self._templates = templates   # owner_hub.templates.TemplateService | None (5.6: read-only template screens)
        self._applier = applier       # owner_templates.apply.TemplateApplyService | None (5.7: apply a template to ONE group)
        self._overview = overview     # owner_hub.overview.GroupOverviewService | None (5.6: settings + events of a group)
        self._key = codec.derive_key(secret)
        self._tz, self._language, self._clock, self._max = display_timezone, language, clock, max_groups
        self._queries: dict[int, str] = {}

    # ------------------------------------------------------------------ helpers
    def _builder(self, chat_id: int) -> views.Builder:
        return lambda screen, **fields: codec.build(self._key, chat_id, screen, **fields)

    def _remember(self, owner_id: int, query: str) -> None:
        if not query:
            self._queries.pop(owner_id, None)
            return
        if owner_id not in self._queries and len(self._queries) >= MAX_SEARCHES:
            self._queries.pop(next(iter(self._queries)))
        self._queries[owner_id] = query

    async def _load(self) -> tuple[list, bool]:
        rows = list(await self._licenses.list_all(self._max + 1))
        return (rows[: self._max], True) if len(rows) > self._max else (rows, False)

    async def group_ids(self, user_id: object, limit: int) -> tuple[list[int], bool]:
        """Registered group ids for the owner's OVERALL statistics (part 6.5b): ([ids], more_than_limit). Owner-checked here
        too (a non-owner gets PermissionDenied), because this is the one place that may list groups for another feature."""
        if not await self._is_owner(user_id):
            raise PermissionDenied(Permission.OWNER_PANEL.value, "not_owner")
        rows, _ = await self._load()
        ids = [r.group_id for r in rows]
        return ids[:limit], len(ids) > limit

    async def _is_owner(self, user_id: object) -> bool:
        try:
            return bool((await self._perm.check_global(user_id, Permission.OWNER_PANEL)).allowed)
        except Exception:
            log.error("owner panel permission check failed", exc_info=True)
            return False

    async def _list(self, chat_id: int, owner_id: int, filt: str, page: int, lang: str) -> OwnerOutcome:
        now = self._clock()
        try:
            rows, cut = await self._load()
        except Exception:
            log.error("owner panel could not read the groups", exc_info=True)
            return OwnerOutcome("unavailable", t("ow_unavailable", lang), True)
        query = self._queries.get(owner_id, "")
        text, buttons = views.render_list(views.select(rows, filt, query, now), filt=filt, page=page, query=query, now=now,
                                          lang=lang, b=self._builder(chat_id), truncated_at=self._max if cut else None,
                                          with_templates=self._templates is not None)
        return OwnerOutcome("list", text=text, buttons=buttons)

    # ------------------------------------------------------------------ opening
    async def open(self, chat_id: object, chat_type: object, user_id: object, search: object = None,
                   lang: str | None = None) -> OwnerOutcome | None:
        """`/owner [search]`. None = answer nothing (not private, or not the owner: audited by the permission service)."""
        lang = lang or self._language
        if chat_type != "private" or not isinstance(chat_id, int) or isinstance(chat_id, bool) or chat_id <= 0:
            return None
        if not await self._is_owner(user_id) or chat_id != user_id:
            return None
        query = views.normalise_query(search) if search else ""
        if isinstance(search, str) and len(" ".join(search.split())) > views.MAX_QUERY_LEN:
            return OwnerOutcome("query_too_long", text=t("ow_query_too_long", lang, limit=views.MAX_QUERY_LEN))
        self._remember(user_id, query)  # a bare `/owner` clears an old search
        return await self._list(chat_id, user_id, "a", 0, lang)

    # ------------------------------------------------------------------ press
    async def press(self, chat_id: object, chat_type: object, presser_id: object, data: object,
                    lang: str | None = None, callback_id: object = None) -> OwnerOutcome | None:
        """None = not an owner-panel callback / not in a private chat (answer silently). `callback_id` = Telegram's
        `callback_query.id` (the idempotency key of an action press)."""
        lang = lang or self._language
        cb = codec.parse(data)
        actor = presser_id if isinstance(presser_id, int) and not isinstance(presser_id, bool) and presser_id > 0 else None
        if cb is None:
            if isinstance(data, str) and data.startswith(codec.PREFIX + ":"):
                await record_safely(self._audit, make_event(FORGED_CALLBACK, actor=actor,
                                                            detail="malformed owner panel callback", now=self._clock()))
            return None
        if chat_type != "private" or actor is None or not isinstance(chat_id, int) or isinstance(chat_id, bool) or chat_id != actor:
            return None
        if not codec.verify(self._key, chat_id, cb):
            await record_safely(self._audit, make_event(FORGED_CALLBACK, actor=actor, detail="invalid owner panel signature",
                                                        now=self._clock()))
            return OwnerOutcome("forged", t("ow_invalid", lang), True)
        if not await self._is_owner(actor):
            await record_safely(self._audit, make_event(FORGED_CALLBACK, actor=actor,
                                                        detail="owner panel press by a non-owner", now=self._clock()))
            return OwnerOutcome("not_owner", t("ow_not_owner", lang), True)
        if cb.screen == codec.CLOSE:
            return OwnerOutcome("closed", delete=True)
        if cb.screen == codec.SEARCH_HELP:
            return OwnerOutcome("search_help", t("ow_search_help", lang, limit=views.MAX_QUERY_LEN), True)
        if cb.screen == codec.CLEAR_SEARCH:
            self._remember(actor, "")
            return await self._list(chat_id, actor, "a", 0, lang)
        if cb.screen == codec.LIST:
            return await self._list(chat_id, actor, cb.filter, cb.page, lang)
        if cb.screen == codec.FILTERS:
            return await self._filters(chat_id, actor, cb.filter, cb.page, lang)
        if cb.screen == codec.DETAIL and cb.group_id is not None:
            return await self._detail(chat_id, cb, lang)
        if cb.screen in (codec.OVERVIEW, codec.PICK, codec.DIFF, codec.TEMPLATES, codec.APPLY_ASK, codec.APPLY_DO):
            return await self._insight(chat_id, actor, cb, lang, callback_id)
        if cb.screen in (codec.MENU, codec.ASK, codec.DO) and cb.group_id is not None:
            if self._actions is None:
                return OwnerOutcome("actions_unavailable", t("ow_actions_unavailable", lang), True)
            if cb.screen == codec.MENU:
                return await self._menu(chat_id, cb, lang)
            if cb.screen == codec.ASK:
                return await self._ask(chat_id, cb, lang)
            return await self._do(chat_id, actor, cb, callback_id, lang)
        return OwnerOutcome("ignored")

    async def _filters(self, chat_id: int, owner_id: int, filt: str, page: int, lang: str) -> OwnerOutcome:
        now = self._clock()
        try:
            rows, _ = await self._load()
        except Exception:
            log.error("owner panel could not read the groups", exc_info=True)
            return OwnerOutcome("unavailable", t("ow_unavailable", lang), True)
        query = self._queries.get(owner_id, "")
        counted = views.counts([r for r in rows if views.matches(r, query)], now)
        text, buttons = views.render_filters(counted, current=filt, page=page, query=query, lang=lang, b=self._builder(chat_id))
        return OwnerOutcome("filters", text=text, buttons=buttons)

    async def _detail(self, chat_id: int, cb: codec.OwnerCallback, lang: str) -> OwnerOutcome:
        b = self._builder(chat_id)
        try:
            row = await self._licenses.get(cb.group_id)
        except Exception:
            log.error("owner panel could not read a group", extra={"group_id": cb.group_id}, exc_info=True)
            return OwnerOutcome("unavailable", t("ow_unavailable", lang), True)
        if row is None:
            text, buttons = views.render_missing(lang=lang, b=b, filt=cb.filter, page=cb.page)
            return OwnerOutcome("missing", text=text, buttons=buttons)
        text, buttons = views.render_detail(row, now=self._clock(), tz=self._tz, lang=lang, b=b, filt=cb.filter, page=cb.page,
                                            with_actions=self._actions is not None, with_insight=self._overview is not None)
        return OwnerOutcome("detail", text=text, buttons=buttons)

    # ------------------------------------------------------------------ read-only insight screens (5.6)
    async def _insight(self, chat_id: int, actor: int, cb: codec.OwnerCallback, lang: str, callback_id: object = None) -> OwnerOutcome:
        """Settings + events of a group, the template list/picker and the diff preview. Every service call re-checks the owner;
        none of them writes. A missing service, a missing group/template or any failure answers a refusal (fail closed)."""
        b = self._builder(chat_id)
        needs = self._templates if cb.screen in (codec.PICK, codec.DIFF, codec.TEMPLATES) else self._overview
        if cb.screen in (codec.APPLY_ASK, codec.APPLY_DO):
            needs = self._applier
        if needs is None or (cb.screen == codec.PICK and self._overview is None):
            return OwnerOutcome("insight_unavailable", t("ow_insight_unavailable", lang), True)
        try:
            return await self._insight_screen(chat_id, actor, cb, lang, b, callback_id)
        except PermissionDenied:
            return OwnerOutcome("not_owner", t("ow_not_owner", lang), True)
        except (GroupNotRegistered, InvalidInput):
            text, buttons = views.render_missing(lang=lang, b=b, filt=cb.filter, page=cb.page)
            return OwnerOutcome("missing", text=text, buttons=buttons)
        except Exception:
            log.error("owner panel insight screen failed", extra={"group_id": cb.group_id}, exc_info=True)
            return OwnerOutcome("unavailable", t("ow_unavailable", lang), True)

    async def _insight_screen(self, chat_id: int, actor: int, cb: codec.OwnerCallback, lang: str, b,
                              callback_id: object = None) -> OwnerOutcome:
        now = self._clock()
        if cb.screen == codec.TEMPLATES:
            text, buttons = iv.render_templates(await self._templates.list(actor), tz=self._tz, lang=lang, b=b,
                                                filt=cb.filter, page=cb.page)
            return OwnerOutcome("templates", text=text, buttons=buttons)
        if cb.screen == codec.OVERVIEW:
            ov = await self._overview.overview(actor, cb.group_id)
            text, buttons = iv.render_overview(ov, now=now, tz=self._tz, lang=lang, b=b, filt=cb.filter, page=cb.page,
                                               can_compare=self._templates is not None)
            return OwnerOutcome("overview", text=text, buttons=buttons)
        row = await self._licenses.get(cb.group_id)
        if row is None:
            raise GroupNotRegistered("group is not registered")
        if cb.screen == codec.PICK:
            text, buttons = iv.render_picker(row, await self._templates.list(actor), lang=lang, b=b, filt=cb.filter, page=cb.page)
            return OwnerOutcome("pick", text=text, buttons=buttons)
        if cb.screen == codec.APPLY_ASK:       # 5.7: the confirmation screen (changes nothing)
            preview = await self._applier.preview(actor, cb.template_id, [cb.group_id])
            if preview is None:
                text, buttons = iv.render_template_missing(lang=lang, b=b, group_id=cb.group_id, filt=cb.filter, page=cb.page)
                return OwnerOutcome("template_missing", text=text, buttons=buttons)
            if not preview.items:
                raise GroupNotRegistered("group is not registered")
            if not preview.items[0].entries:
                return await self._diff_screen(actor, cb, row, lang, b)
            text, buttons = iv.render_apply_confirm(preview.template, preview.items[0], row, lang=lang, b=b, filt=cb.filter,
                                                    page=cb.page)
            return OwnerOutcome("apply_confirm", text=text, buttons=buttons)
        if cb.screen == codec.APPLY_DO:        # 5.7: one claim per press, stale-state guard and owner check inside the service
            if not isinstance(callback_id, str) or not re.fullmatch(r"[A-Za-z0-9_\-]{1,64}", callback_id):
                return OwnerOutcome("invalid", t("ow_invalid", lang), True)
            result = (await self._applier.execute(actor, cb.template_id, [(cb.group_id, cb.digest)], callback_id))[0]
            if result.status == "duplicate":
                return OwnerOutcome("duplicate")
            toast = {"applied": t("tpl_toast_applied", lang, keys=result.keys), "no_change": t("tpl_toast_no_change", lang),
                     "stale": t("ow_stale", lang), "missing": t("tpl_missing", lang)}.get(result.status, t("ow_action_failed", lang))
            outcome = await self._diff_screen(actor, cb, row, lang, b)
            return replace(outcome, status=result.status, toast=toast, alert=result.status not in ("applied", "no_change"))
        return await self._diff_screen(actor, cb, row, lang, b)

    async def _diff_screen(self, actor: int, cb: codec.OwnerCallback, row, lang: str, b) -> OwnerOutcome:
        diff = await self._templates.diff(actor, cb.template_id, cb.group_id)   # preview only: nothing is applied
        if diff is None:
            text, buttons = iv.render_template_missing(lang=lang, b=b, group_id=cb.group_id, filt=cb.filter, page=cb.page)
            return OwnerOutcome("template_missing", text=text, buttons=buttons)
        text, buttons = iv.render_diff(diff, row, lang=lang, b=b, filt=cb.filter, page=cb.page, can_apply=self._applier is not None)
        return OwnerOutcome("diff", text=text, buttons=buttons)

    # ------------------------------------------------------------------ actions (5.4)
    async def _read_row(self, chat_id: int, cb: codec.OwnerCallback, lang: str):
        """-> (row, None) or (None, the outcome to answer)."""
        try:
            row = await self._licenses.get(cb.group_id)
        except Exception:
            log.error("owner panel could not read a group", extra={"group_id": cb.group_id}, exc_info=True)
            return None, OwnerOutcome("unavailable", t("ow_unavailable", lang), True)
        if row is None:
            text, buttons = views.render_missing(lang=lang, b=self._builder(chat_id), filt=cb.filter, page=cb.page)
            return None, OwnerOutcome("missing", text=text, buttons=buttons)
        return row, None

    async def _menu(self, chat_id: int, cb: codec.OwnerCallback, lang: str) -> OwnerOutcome:
        row, refusal = await self._read_row(chat_id, cb, lang)
        if refusal is not None:
            return refusal
        text, buttons = views.render_duration_menu(row, now=self._clock(), lang=lang, b=self._builder(chat_id),
                                                   filt=cb.filter, page=cb.page)
        return OwnerOutcome("menu", text=text, buttons=buttons)

    async def _ask(self, chat_id: int, cb: codec.OwnerCallback, lang: str) -> OwnerOutcome:
        row, refusal = await self._read_row(chat_id, cb, lang)
        if refusal is not None:
            return refusal
        now = self._clock()
        if act.STATUS_CODE[effective_status(row, now)] != cb.status:
            return await self._detail_with(chat_id, cb, lang, "stale", t("ow_stale", lang), True)
        text, buttons = views.render_confirm(row, cb.action, now=now, lang=lang, b=self._builder(chat_id), filt=cb.filter,
                                             page=cb.page)
        return OwnerOutcome("confirm", text=text, buttons=buttons)

    async def _detail_with(self, chat_id: int, cb: codec.OwnerCallback, lang: str, status: str, toast: str,
                           alert: bool) -> OwnerOutcome:
        """The group's FRESH details screen (so the owner sees the real state) carrying a result toast."""
        outcome = await self._detail(chat_id, cb, lang)
        if outcome.text is None:        # the group could not be read: keep that refusal as it is
            return outcome
        return replace(outcome, status=status, toast=toast, alert=alert)

    async def _do(self, chat_id: int, actor: int, cb: codec.OwnerCallback, callback_id: object, lang: str) -> OwnerOutcome:
        result = await self._actions.run(actor, cb.group_id, cb.action, cb.status, callback_id)
        kind = result.kind
        if kind == "done" and self._hub is not None:
            try:                                           # 5.9: the notice is best effort; a failing hook never undoes or hides a change
                self._hub.license_changed(result.license, result.action, "panel")
            except Exception as exc:
                log.warning("owner hub notice failed (%s)", type(exc).__name__)
        if kind in ("done", "no_change"):
            return await self._detail_with(chat_id, cb, lang, kind, act.done_text(result, lang, self._tz), False)
        if kind == "duplicate":
            return OwnerOutcome("duplicate")           # a redelivered press: already handled, say nothing
        if kind == "invalid":
            return OwnerOutcome("invalid", t("ow_invalid", lang), True)
        if kind == "denied":
            return OwnerOutcome("not_owner", t("ow_not_owner", lang), True)
        if kind == "missing":
            text, buttons = views.render_missing(lang=lang, b=self._builder(chat_id), filt=cb.filter, page=cb.page)
            return OwnerOutcome("missing", text=text, buttons=buttons)
        if kind == "stale":
            return await self._detail_with(chat_id, cb, lang, "stale", t("ow_stale", lang), True)
        if kind == "bad_state":
            label = license_label(result.status, lang) if result.status is not None else ""
            return await self._detail_with(chat_id, cb, lang, "bad_state", t("ow_bad_state", lang, status=label), True)
        if kind == "retry":
            return await self._detail_with(chat_id, cb, lang, "retry", t("ow_retry", lang), True)
        return await self._detail_with(chat_id, cb, lang, "failed", t("ow_action_failed", lang), True)
