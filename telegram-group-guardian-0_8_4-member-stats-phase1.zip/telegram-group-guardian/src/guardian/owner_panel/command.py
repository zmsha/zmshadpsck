"""Parser of the owner panel command: `/owner [search]`, `/owner@bot [search]`, `لوحة المالك [بحث]` (phase 5.3).

Pure. It only recognises the text; WHO may use it is decided by the service (exact OWNER_TELEGRAM_ID, private chat)."""
from __future__ import annotations

from dataclasses import dataclass

from ..moderation.arabic import fold_arabic

MAX_COMMAND_LEN = 200
_ARABIC = fold_arabic("لوحة المالك")


@dataclass(frozen=True, slots=True)
class ParsedOwnerCommand:
    search: str = ""   # raw text after the command (the service normalises and length-checks it)


def parse_owner_command(text: object, bot_username: str | None = None) -> ParsedOwnerCommand | None:
    if not isinstance(text, str):
        return None
    stripped = text.strip()
    if not stripped or len(stripped) > MAX_COMMAND_LEN:
        return None
    if stripped.startswith("/"):
        parts = stripped.split(None, 1)
        name, at, target = parts[0][1:].partition("@")
        if name.lower() != "owner":
            return None
        if at and (not bot_username or target.lower() != bot_username.lower()):
            return None  # addressed to another bot (or we do not know our own name)
        return ParsedOwnerCommand(parts[1].strip() if len(parts) > 1 else "")
    words = stripped.split()
    if len(words) >= 2 and " ".join(fold_arabic(w) for w in words[:2]) == _ARABIC:
        return ParsedOwnerCommand(" ".join(words[2:]))
    return None
