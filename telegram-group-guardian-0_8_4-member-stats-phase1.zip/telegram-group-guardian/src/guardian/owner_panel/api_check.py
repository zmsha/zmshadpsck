"""API check (part 9.6): looks at every external service the bot uses and says whether it works. Read only, never raises.

Services looked at: the Telegram Bot API (the token, the webhook, and the owner group when one is set), Gemini (every configured
key, see `GeminiClient.check_keys`) and the PostgreSQL database. Nothing is sent to any chat, nothing is changed except what a
real answer teaches the Gemini key pool (an exhausted or refused key is remembered, exactly as in a normal call).

No secret ever appears in a report: not the token, not a Gemini key, not the database URL, not the webhook address (only whether
it matches the expected one). A Telegram error text is cut short and any link in it is removed before it is shown.

Everything outside this module is injected (the Telegram probe, the database, the Gemini client), so the logic is unit-tested
with fakes; the aiogram adapter is `bot/telegram_probe.py`.
"""
from __future__ import annotations

import asyncio
import logging
import re
import time
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Iterable, Protocol

from ..content_filter.gemini import KeyReport
from ..owner_hub.redactor import redact_text
from ..time_utils import utcnow

log = logging.getLogger(__name__)

CALL_TIMEOUT = 10.0          # seconds, each external call
SLOW_DB_MS = 2000
BACKLOG_PENDING = 100        # pending webhook updates above this are worth a warning
RECENT_ERROR = timedelta(hours=24)
MAX_ERROR_TEXT = 80

# Telegram token / generic service states
S_OK, S_INVALID, S_PAUSED, S_NETWORK, S_ERROR = "ok", "invalid", "paused", "network", "error"
# webhook states
W_OK, W_MISSING, W_MISMATCH, W_UNKNOWN = "ok", "missing", "mismatch", "unknown"
# owner group states
H_UNSET, H_OK, H_UNREACHABLE, H_UNKNOWN = "unset", "ok", "unreachable", "unknown"
# database states
D_OK, D_SLOW, D_DOWN = "ok", "slow", "down"

_LINK = re.compile(r"(?i)(?:https?://|www\.|t\.me/|tg://)\S+")


@dataclass(frozen=True, slots=True)
class WebhookState:
    url: str = ""
    pending: int = 0
    last_error_at: datetime | None = None
    last_error: str | None = None


class TelegramProbe(Protocol):
    async def username(self) -> str: ...                       # getMe; raises on failure
    async def webhook(self) -> WebhookState: ...                # getWebhookInfo; raises on failure
    async def chat_reachable(self, chat_id: int) -> bool: ...   # getChat; False = the bot cannot see that chat; raises on network trouble


@dataclass(frozen=True, slots=True)
class TelegramReport:
    token: str = S_ERROR                 # S_*
    username: str = ""
    retry_after: int | None = None       # token paused
    webhook: str = W_UNKNOWN             # W_*
    pending: int = 0
    backlog: bool = False
    error_text: str | None = None        # a RECENT delivery error (sanitised, short)
    error_at: datetime | None = None
    hub: str = H_UNSET                   # H_*


@dataclass(frozen=True, slots=True)
class DatabaseReport:
    state: str = D_DOWN                  # D_*
    millis: int | None = None


@dataclass(frozen=True, slots=True)
class ApiReport:
    at: datetime
    deep: bool
    telegram: TelegramReport
    model: str
    configured_keys: int                 # how many Gemini keys are set (0 = none)
    max_keys: int
    keys: tuple[KeyReport, ...]
    database: DatabaseReport

    @property
    def ready_keys(self) -> int:
        return sum(1 for k in self.keys if k.state == "working")

    @property
    def empty_slots(self) -> tuple[int, ...]:
        used = {k.slot for k in self.keys}
        return tuple(i for i in range(1, self.max_keys + 1) if i not in used)


def classify_error(exc: BaseException) -> tuple[str, int | None]:
    """-> (S_* state, retry seconds) from an exception, by CLASS NAME (so aiogram need not be imported here)."""
    names = {c.__name__ for c in type(exc).__mro__}
    if "TelegramUnauthorizedError" in names:
        return S_INVALID, None
    if "TelegramRetryAfter" in names:
        raw = getattr(exc, "retry_after", None)
        return S_PAUSED, (int(raw) if isinstance(raw, (int, float)) and not isinstance(raw, bool) and raw > 0 else None)
    if names & {"TelegramNetworkError", "TelegramServerError", "TimeoutError", "CancelledError"} or isinstance(exc, (OSError, asyncio.TimeoutError)):
        return S_NETWORK, None
    return S_ERROR, None


def clean_error_text(text: object, secrets: Iterable[str] = ()) -> str | None:
    """A Telegram delivery error as short text with no link and no secret (or None). The secrets are removed BEFORE the text is
    cut, so a half-cut secret can never survive."""
    if not isinstance(text, str):
        return None
    cleaned = " ".join(_LINK.sub("[link]", redact_text(text, secrets)).split())
    return cleaned[:MAX_ERROR_TEXT] or None


class ApiChecker:
    def __init__(self, *, settings: Any, database: Any, telegram: TelegramProbe | None, gemini: Any = None, max_keys: int = 5,
                 clock=utcnow, timeout: float = CALL_TIMEOUT):
        self._settings, self._db, self._tg, self._gemini = settings, database, telegram, gemini
        self._max_keys, self._clock, self._timeout = max_keys, clock, timeout

    def _secrets(self) -> tuple[str, ...]:
        getter = getattr(self._settings, "secret_values", None)
        try:
            return tuple(getter()) if callable(getter) else ()
        except Exception:
            return ()

    async def run(self, *, deep: bool = False) -> ApiReport:
        telegram, keys, db = await asyncio.gather(self._telegram(), self._gemini_keys(deep), self._database())
        configured = len(getattr(self._settings, "gemini_api_keys", ()) or ())
        model = getattr(self._gemini, "model", "") or getattr(self._settings, "gemini_model", "") or ""
        return ApiReport(self._clock(), deep, telegram, model, configured, self._max_keys, tuple(keys), db)

    # ---------------------------------------------------------------------------------------------- Telegram
    async def _telegram(self) -> TelegramReport:
        if self._tg is None:
            return TelegramReport()
        try:
            return await self._telegram_inner()
        except Exception:  # pragma: no cover - the parts below catch their own errors
            log.error("telegram check failed", exc_info=True)
            return TelegramReport()

    async def _telegram_inner(self) -> TelegramReport:
        token, username, retry = S_ERROR, "", None
        try:
            username = await asyncio.wait_for(self._tg.username(), self._timeout)
            token = S_OK
        except Exception as exc:
            token, retry = classify_error(exc)
            log.warning("telegram getMe check failed (%s)", type(exc).__name__)
        webhook, pending, backlog, error_text, error_at = W_UNKNOWN, 0, False, None, None
        if token in (S_OK, S_PAUSED, S_ERROR):   # a refused or unreachable token cannot answer a second question
            try:
                state = await asyncio.wait_for(self._tg.webhook(), self._timeout)
                expected = getattr(self._settings, "webhook_url", None)
                webhook = W_MISSING if not state.url else (W_MISMATCH if expected and state.url != expected else W_OK)
                pending = max(0, int(state.pending or 0))
                backlog = pending > BACKLOG_PENDING
                if state.last_error_at is not None and self._clock() - state.last_error_at <= RECENT_ERROR:
                    error_text, error_at = clean_error_text(state.last_error, self._secrets()), state.last_error_at
            except Exception as exc:
                log.warning("telegram webhook check failed (%s)", type(exc).__name__)
        hub = H_UNSET
        group = getattr(self._settings, "owner_group_id", None)
        if group is not None:
            hub = H_UNKNOWN
            if token in (S_OK, S_PAUSED, S_ERROR):
                try:
                    hub = H_OK if await asyncio.wait_for(self._tg.chat_reachable(group), self._timeout) else H_UNREACHABLE
                except Exception as exc:
                    hub = H_UNKNOWN
                    log.warning("owner group check failed (%s)", type(exc).__name__)
        return TelegramReport(token, username if token == S_OK else "", retry, webhook, pending, backlog, error_text, error_at, hub)

    # ---------------------------------------------------------------------------------------------- Gemini
    async def _gemini_keys(self, deep: bool) -> list[KeyReport]:
        if self._gemini is None:
            return []
        try:
            return list(await self._gemini.check_keys(deep=deep, timeout=self._timeout))
        except Exception:
            log.error("gemini key check failed", exc_info=True)
            return []

    # ---------------------------------------------------------------------------------------------- database
    async def _database(self) -> DatabaseReport:
        async def ping() -> None:
            async with self._db.acquire() as conn:
                await conn.fetchval("SELECT 1")

        started = time.monotonic()
        try:
            await asyncio.wait_for(ping(), self._timeout)
        except Exception as exc:
            log.warning("database check failed (%s)", type(exc).__name__)
            return DatabaseReport(D_DOWN)
        millis = int((time.monotonic() - started) * 1000)
        return DatabaseReport(D_SLOW if millis > SLOW_DB_MS else D_OK, millis)
