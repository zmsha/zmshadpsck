"""License ACTIONS of the owner panel (phase 5.4): the action table, which buttons a group shows, and the executor.

This is the ONLY file of the package that changes anything, and it never touches the license store's write side: every change
goes through `LicenseAdminService` (server-side `CHANGE_LICENSE` = the primary owner only, transition validated against the
current EFFECTIVE status, compare-and-set store write with the audit record in the same transaction).

Safety rules (all enforced here, not by the buttons):
* every action needs the EFFECTIVE status the owner saw when the button was drawn (`expected`): if the group changed since
  (another press, expiry, the owner's other chat) the press is refused as stale and nothing is applied;
* one press = one claim (`op:ow:<group>:<callback id>`): a redelivered press never applies twice; a press without a usable
  callback id changes nothing;
* durations are fixed choices measured from NOW (a month is 30 days, the 5.1/5.2 decision); the panel never takes free text;
* stopping, rejecting and banning always ask for confirmation, and so does replacing an active license (shorter, or
  permanent -> timed), because both can cut protection off.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Callable

from ..errors import ConcurrentModification, GroupNotRegistered, InvalidInput, InvalidTransition, PermissionDenied
from ..i18n import license_label, t
from ..idempotency import operation_key
from ..licensing.admin import Outcome, RENEW
from ..licensing.models import ACTIVE_STATUSES, GroupLicense, LicenseStatus, effective_status
from ..time_utils import format_display, utcnow

log = logging.getLogger(__name__)

S = LicenseStatus
MENU = "menu"                                   # pseudo action: opens the duration menu
_CALLBACK_ID = re.compile(r"[0-9A-Za-z_.\-]{1,100}", re.ASCII)

STATUS_CODE: dict[LicenseStatus, str] = {
    S.PENDING: "p", S.ACTIVE_PERMANENT: "d", S.ACTIVE_TEMPORARY: "t", S.EXPIRED: "x", S.STOPPED: "s", S.REJECTED: "r",
    S.BANNED: "b",
}


@dataclass(frozen=True, slots=True)
class ActionSpec:
    code: str
    method: str                  # LicenseAdminService method name
    days: int | None = None      # temporary activation length (from now)
    dangerous: bool = False      # always asks for confirmation


SPECS: dict[str, ActionSpec] = {s.code: s for s in (
    ActionSpec("ap", "activate_permanent"),
    ActionSpec("t1", "activate_temporary", 1), ActionSpec("t7", "activate_temporary", 7),
    ActionSpec("t30", "activate_temporary", 30), ActionSpec("t90", "activate_temporary", 90),
    ActionSpec("t180", "activate_temporary", 180), ActionSpec("t365", "activate_temporary", 365),
    ActionSpec("st", "stop", dangerous=True), ActionSpec("rj", "reject", dangerous=True),
    ActionSpec("bn", "ban", dangerous=True),
    ActionSpec("ub", "unban"), ActionSpec("al", "allow"),
)}
DURATION_CODES = ("t1", "t7", "t30", "t90", "t180", "t365")

# What each status offers (tokens: an action code or MENU). The admin service stays the authority: a token that is not valid
# from the current status is refused there too (a test checks that this table never offers a refused transition).
ROWS: dict[LicenseStatus, tuple[tuple[str, ...], ...]] = {
    S.PENDING: (("ap", MENU), ("rj", "bn")),
    S.ACTIVE_PERMANENT: ((MENU,), ("st", "bn")),
    S.ACTIVE_TEMPORARY: ((MENU, "ap"), ("st", "bn")),
    S.EXPIRED: (("ap", MENU), ("rj", "bn")),
    S.STOPPED: (("ap", MENU), ("rj", "bn")),
    S.REJECTED: (("al", "bn"),),
    S.BANNED: (("ub",),),
}


def rows_for(status: LicenseStatus) -> tuple[tuple[str, ...], ...]:
    return ROWS[status]


def replaces_active(code: str, status: LicenseStatus) -> bool:
    spec = SPECS[code]
    return spec.method in ("activate_permanent", "activate_temporary") and status in ACTIVE_STATUSES


def needs_confirm(code: str, status: LicenseStatus) -> bool:
    return SPECS[code].dangerous or replaces_active(code, status)


# ---------------------------------------------------------------------------------------------------- texts
def days_phrase(n: int, lang: str) -> str:
    """'يوم واحد' / '7 أيام' / '30 يومًا' (Arabic number agreement) and '1 day' / '7 days'."""
    if n == 1:
        return t("ow_btn_days_one", lang)
    return t("ow_btn_days_few" if n <= 10 else "ow_btn_days_many", lang, n=n)


def name_of(code: str, lang: str) -> str:
    """Plain (no emoji) name of an action, for the confirmation text."""
    spec = SPECS[code]
    if spec.days is not None:
        return t("ow_act_temp", lang, duration=days_phrase(spec.days, lang))
    if code == "ap":
        return t("ow_act_ap", lang)
    if code == "st":
        return t("ow_act_st", lang)
    if code == "rj":
        return t("ow_act_rj", lang)
    if code == "bn":
        return t("ow_act_bn", lang)
    if code == "ub":
        return t("ow_act_ub", lang)
    return t("ow_act_al", lang)


def warning_of(code: str, lang: str) -> str:
    if code == "st":
        return t("ow_warn_st", lang)
    if code == "rj":
        return t("ow_warn_rj", lang)
    if code == "bn":
        return t("ow_warn_bn", lang)
    return t("ow_warn_replace", lang)


# ---------------------------------------------------------------------------------------------------- executor
@dataclass(frozen=True, slots=True)
class ActionResult:
    """kind: done | no_change | stale | bad_state | missing | retry | denied | failed | duplicate | invalid."""
    kind: str
    action: str | None = None              # the admin action actually applied (activate_*, renew, stop, ...)
    license: GroupLicense | None = None
    status: LicenseStatus | None = None    # current effective status (stale / bad_state)


class OwnerActions:
    def __init__(self, *, license_admin: Any, licenses: Any, claims: Any, clock: Callable[[], datetime] = utcnow):
        self._admin, self._licenses, self._claims, self._clock = license_admin, licenses, claims, clock

    async def run(self, actor_id: object, group_id: int, code: str, expected: str, callback_id: object) -> ActionResult:
        """Never raises. The caller has ALREADY verified the signature and that `actor_id` is the owner; the admin service
        checks `CHANGE_LICENSE` again (a different layer must agree before anything is written)."""
        spec = SPECS.get(code)
        if spec is None or not isinstance(callback_id, str) or not _CALLBACK_ID.fullmatch(callback_id):
            return ActionResult("invalid")
        try:
            key = operation_key("ow", group_id, callback_id)
        except ValueError:
            return ActionResult("invalid")
        now = self._clock()
        try:
            current = await self._licenses.get(group_id)
        except Exception:
            log.error("owner panel action could not read the group", extra={"group_id": group_id}, exc_info=True)
            return ActionResult("failed")
        if current is None:
            return ActionResult("missing")
        effective = effective_status(current, now)
        if STATUS_CODE[effective] != expected:
            return ActionResult("stale", status=effective, license=current)
        try:
            first = await self._claims.claim(key)
        except Exception:
            log.error("owner panel action claim failed", extra={"group_id": group_id}, exc_info=True)
            return ActionResult("failed", status=effective, license=current)
        if not first:
            return ActionResult("duplicate")
        method = getattr(self._admin, spec.method)
        try:
            if spec.days is not None:
                result = await method(actor_id, group_id, now + timedelta(days=spec.days))
            else:
                result = await method(actor_id, group_id)
        except PermissionDenied:
            return ActionResult("denied")
        except GroupNotRegistered:
            return ActionResult("missing")
        except InvalidTransition:
            return ActionResult("bad_state", status=effective, license=current)
        except ConcurrentModification:
            return ActionResult("retry", status=effective, license=current)
        except InvalidInput:
            return ActionResult("failed", status=effective, license=current)
        except Exception:
            log.error("owner panel action failed", extra={"group_id": group_id}, exc_info=True)
            return ActionResult("failed", status=effective, license=current)
        kind = "no_change" if result.outcome is Outcome.NO_CHANGE else "done"
        return ActionResult(kind, result.action, result.license)


def done_text(result: ActionResult, lang: str, tz: str) -> str:
    """Toast text of a finished action (`done` / `no_change`)."""
    lic = result.license
    if result.kind == "no_change":
        return t("ow_done_no_change", lang, status=license_label(lic.status, lang) if lic else "")
    action = result.action
    when = format_display(lic.expires_at, tz) if lic is not None and lic.expires_at is not None else ""
    if action == RENEW:
        return t("ow_done_renewed", lang, when=when)
    if action == "activate_temporary":
        return t("ow_done_activated_temp", lang, when=when)
    if action == "activate_permanent":
        return t("ow_done_activated_perm", lang)
    if action == "stop":
        return t("ow_done_stopped", lang)
    if action == "reject":
        return t("ow_done_rejected", lang)
    if action == "ban":
        return t("ow_done_banned", lang)
    if action == "unban":
        return t("ow_done_unbanned", lang)
    return t("ow_done_allowed", lang)
