"""Signed callback data of the OWNER panel (phase 5.3, actions added in 5.4).

Callback data is attacker-controlled: anybody can craft any string and press it. So parsing is a strict whitelist and
every string carries an HMAC tag (key derived from the webhook secret, domain separated from the group panel's key) over
`chat | payload`, where `chat` is the chat of the PRESSED message (never read from the data). The ACTOR is never in the
data: it is Telegram's `from_user`, checked against OWNER_TELEGRAM_ID on every press by the service.

Formats (all ASCII, <= 64 bytes, last field = 12 hex tag):
    ow:l:<filter>:<page>          list page            ow:f:<filter>:<page>    filter menu (current filter/page)
    ow:d:<group>:<filter>:<page>  group details        ow:s:<tag> / ow:c:<tag> search help / clear search
    ow:x:<tag>                    close
    ow:m:<group>:<filter>:<page>  duration menu (5.4)
    ow:a:<act>:<status>:<group>:<filter>:<page>   ask for confirmation of a dangerous action (5.4)
    ow:y:<act>:<status>:<group>:<filter>:<page>   run the action (5.4); `status` = the EFFECTIVE status the owner saw
                                                  when the button was drawn: a stale screen is refused, never applied
    ow:o:<group>:<filter>:<page>  settings + events of a group (5.6, read only)   ow:q:... template picker for a diff (5.6)
    ow:v:<tpl>:<group>:<filter>:<page>  diff preview template vs group (5.6; changes NOTHING)
    ow:t:<filter>:<page>          the owner's templates (5.6, read only)
    ow:k:<tpl>:<group>:<filter>:<page>          confirmation screen "apply this template to this group" (5.7; changes nothing)
    ow:z:<tpl>:<group>:<digest6>:<filter>:<page> apply it (5.7); `digest6` = fingerprint of the differences the owner saw
"""
from __future__ import annotations

import hashlib
import hmac
import re
from dataclasses import dataclass

PREFIX = "ow"
MAX_CALLBACK_BYTES = 64
TAG_LEN = 12
FILTER_CODES = "apdtxsrb"            # all, pending, permanent, temporary, expired, stopped, rejected, banned
MAX_PAGE = 9999
_MIN_GROUP, _MAX_GROUP = -(2**63), -1

STATUS_CODES = "pdtxsrb"             # pending, permanent, temporary, expired, stopped, rejected, banned (no "all")
# Action codes (5.4): ap = activate permanently, t<days> = activate/renew for that many days (month = 30 days),
# st = stop, rj = reject, bn = ban, ub = unban, al = allow again (rejected -> pending).
ACTION_CODES = ("ap", "t1", "t7", "t30", "t90", "t180", "t365", "st", "rj", "bn", "ub", "al")

LIST, FILTERS, DETAIL, SEARCH_HELP, CLEAR_SEARCH, CLOSE = "l", "f", "d", "s", "c", "x"
MENU, ASK, DO = "m", "a", "y"
OVERVIEW, PICK, DIFF, TEMPLATES = "o", "q", "v", "t"   # 5.6: read-only screens (nothing here changes anything)
APPLY_ASK, APPLY_DO = "k", "z"                          # 5.7: confirm / run "apply a template to one group"
_DIFF_LIKE = (DIFF, APPLY_ASK)                          # payload `<screen>:<tpl>:<group>:<filter>:<page>`
MAX_TEMPLATE_ID = 999_999_999
_PLAIN = (SEARCH_HELP, CLEAR_SEARCH, CLOSE)
_GROUP_SCREENS = (DETAIL, MENU, OVERVIEW, PICK)   # payload `<screen>:<group>:<filter>:<page>`
_LIST_SCREENS = (LIST, FILTERS, TEMPLATES)        # payload `<screen>:<filter>:<page>`
_ACTION_SCREENS = (ASK, DO)           # payload `<screen>:<act>:<status>:<group>:<filter>:<page>`

_TAG = re.compile(r"[0-9a-f]{12}", re.ASCII)
_PAGE = re.compile(r"[0-9]{1,4}", re.ASCII)
_GROUP = re.compile(r"-[1-9][0-9]{0,18}", re.ASCII)
_TEMPLATE = re.compile(r"[1-9][0-9]{0,8}", re.ASCII)
_DIGEST = re.compile(r"[0-9a-f]{6}", re.ASCII)


@dataclass(frozen=True, slots=True)
class OwnerCallback:
    screen: str
    tag: str
    filter: str = "a"
    page: int = 0
    group_id: int | None = None
    action: str | None = None
    status: str | None = None
    template_id: int | None = None
    digest: str | None = None

    def payload(self) -> str:
        return _payload(self.screen, self.filter, self.page, self.group_id, self.action, self.status, self.template_id,
                        self.digest)


def derive_key(secret: str | bytes) -> bytes:
    raw = secret.encode("utf-8") if isinstance(secret, str) else bytes(secret)
    if not raw:
        raise ValueError("owner panel secret must not be empty")
    return hmac.new(raw, b"guardian-owner-panel-callback-v1", hashlib.sha256).digest()


def _payload(screen: str, filt: str, page: int, group_id: int | None, action: str | None = None,
             status: str | None = None, template_id: int | None = None, digest: str | None = None) -> str:
    if screen in _PLAIN:
        return screen
    if screen in _LIST_SCREENS:
        return f"{screen}:{filt}:{page}"
    if screen in _DIFF_LIKE:
        return f"{screen}:{template_id}:{group_id}:{filt}:{page}"
    if screen == APPLY_DO:
        return f"{screen}:{template_id}:{group_id}:{digest}:{filt}:{page}"
    if screen in _GROUP_SCREENS:
        return f"{screen}:{group_id}:{filt}:{page}"
    if screen in _ACTION_SCREENS:
        return f"{screen}:{action}:{status}:{group_id}:{filt}:{page}"
    raise ValueError("unsupported owner panel screen")


def _tag(key: bytes, chat_id: int, payload: str) -> str:
    return hmac.new(key, f"ow|{chat_id}|{payload}".encode("ascii"), hashlib.sha256).hexdigest()[:TAG_LEN]


def _check_chat(chat_id: object) -> bool:
    return isinstance(chat_id, int) and not isinstance(chat_id, bool) and chat_id > 0  # the owner's PRIVATE chat


def build(key: bytes, chat_id: int, screen: str, *, filter: str = "a", page: int = 0, group_id: int | None = None,
          action: str | None = None, status: str | None = None, template_id: int | None = None,
          digest: str | None = None) -> str:
    if not _check_chat(chat_id):
        raise ValueError("the owner panel lives in a private chat (positive chat id)")
    if screen not in (*_LIST_SCREENS, *_DIFF_LIKE, APPLY_DO, *_GROUP_SCREENS, *_ACTION_SCREENS, *_PLAIN):
        raise ValueError("unsupported owner panel screen")
    if filter not in FILTER_CODES or len(filter) != 1:
        raise ValueError("unknown filter")
    if not isinstance(page, int) or isinstance(page, bool) or not 0 <= page <= MAX_PAGE:
        raise ValueError("page out of range")
    if screen in (*_DIFF_LIKE, APPLY_DO) and (not isinstance(template_id, int) or isinstance(template_id, bool)
                                              or not 1 <= template_id <= MAX_TEMPLATE_ID):
        raise ValueError("template_id out of range")
    if screen == APPLY_DO and (not isinstance(digest, str) or not _DIGEST.fullmatch(digest)):
        raise ValueError("digest must be 6 lowercase hex characters")
    if screen in (*_GROUP_SCREENS, *_ACTION_SCREENS, *_DIFF_LIKE, APPLY_DO) and (not isinstance(group_id, int) or isinstance(group_id, bool)
                                                         or not _MIN_GROUP <= group_id <= _MAX_GROUP):
        raise ValueError("group_id must be a negative integer")
    if screen in _ACTION_SCREENS:
        if action not in ACTION_CODES:
            raise ValueError("unknown action")
        if not isinstance(status, str) or len(status) != 1 or status not in STATUS_CODES:
            raise ValueError("unknown status")
    payload = _payload(screen, filter, page, group_id, action, status, template_id, digest)
    data = f"{PREFIX}:{payload}:{_tag(key, chat_id, payload)}"
    if len(data.encode("ascii")) > MAX_CALLBACK_BYTES:
        raise ValueError("callback data too long")
    return data


def parse(data: object) -> OwnerCallback | None:
    """Structure only (the signature needs the chat). None = not a well-formed owner callback."""
    if not isinstance(data, str) or len(data) > MAX_CALLBACK_BYTES or not data.isascii():
        return None
    parts = data.split(":")
    if len(parts) < 3 or parts[0] != PREFIX or not _TAG.fullmatch(parts[-1]):
        return None
    screen, tag, body = parts[1], parts[-1], parts[2:-1]
    if screen in _PLAIN:
        return OwnerCallback(screen, tag) if not body else None
    action = status = gid = tid = digest = None
    if screen in _LIST_SCREENS and len(body) == 2:
        filt, page = body
    elif screen in _DIFF_LIKE and len(body) == 4:
        tid, gid, filt, page = body
        if not _TEMPLATE.fullmatch(tid) or not 1 <= int(tid) <= MAX_TEMPLATE_ID:
            return None
    elif screen == APPLY_DO and len(body) == 5:
        tid, gid, digest, filt, page = body
        if not _TEMPLATE.fullmatch(tid) or not 1 <= int(tid) <= MAX_TEMPLATE_ID or not _DIGEST.fullmatch(digest):
            return None
    elif screen in _GROUP_SCREENS and len(body) == 3:
        gid, filt, page = body
    elif screen in _ACTION_SCREENS and len(body) == 5:
        action, status, gid, filt, page = body
        if action not in ACTION_CODES or len(status) != 1 or status not in STATUS_CODES:
            return None
    else:
        return None
    if gid is not None and (not _GROUP.fullmatch(gid) or not _MIN_GROUP <= int(gid) <= _MAX_GROUP):
        return None
    if len(filt) != 1 or filt not in FILTER_CODES or not _PAGE.fullmatch(page):
        return None
    return OwnerCallback(screen, tag, filt, int(page), int(gid) if gid is not None else None, action, status,
                         int(tid) if tid is not None else None, digest)


def verify(key: bytes, chat_id: object, cb: OwnerCallback) -> bool:
    if not _check_chat(chat_id):
        return False
    return hmac.compare_digest(cb.tag, _tag(key, chat_id, cb.payload()))
