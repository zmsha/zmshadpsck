"""Pure rendering of the READ-ONLY screens of part 5.6: a group's settings and events, the template picker, the template
list and the diff preview. No I/O, nothing here changes anything: the buttons only point at other signed read screens.

Texts are Telegram-HTML: every user-controlled value (group titles, template names, welcome text, domains, audit detail)
goes through `i18n.t` (which escapes) after `views.clean` (single line, no control/bidi characters, truncated).
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Sequence

from ..i18n import license_label, t
from ..licensing.models import effective_status
from ..owner_templates.overview import GroupOverview
from ..owner_templates.templates import SettingsTemplate, TemplateDiff
from ..time_utils import format_display
from . import codec
from .views import LABEL_MAX, Buttons, Builder, clean

TEXT_LIMIT = 3600          # Telegram allows 4096 characters per message: stay well inside
VALUE_MAX = 60
DETAIL_MAX = 80
MAX_DIFF_LINES = 40
MAX_PICK = 8


def fmt_value(value: Any, lang: str) -> str:
    """One settings value as short single-line text (never raw JSON, never unbounded)."""
    if value is None:
        return t("ow_none", lang)
    if isinstance(value, bool):
        return t("ow_val_on" if value else "ow_val_off", lang)
    if isinstance(value, (list, tuple)):
        return clean("، ".join(str(v) for v in value[:20]), VALUE_MAX) or t("ow_none", lang)
    return clean(str(value), VALUE_MAX) or t("ow_none", lang)


def _fit(lines: list[str], lang: str) -> str:
    out: list[str] = []
    size = 0
    for line in lines:
        if size + len(line) + 1 > TEXT_LIMIT:
            out.append(t("ow_cut", lang))
            break
        out.append(line)
        size += len(line) + 1
    return "\n".join(out)


def _title(license_: Any, lang: str) -> str:
    return clean(getattr(license_, "title", None), 120) or t("title_unknown", lang)


def _footer(lang: str, b: Builder, *, back: str, filt: str, page: int, group_id: int | None = None,
            more: tuple[tuple[str, str], ...] = ()) -> tuple[tuple[tuple[str, str], ...], ...]:
    fields = {"filter": filt, "page": page}
    if group_id is not None:
        fields["group_id"] = group_id
    rows = [more] if more else []
    rows.append(((t("ow_btn_back", lang), b(back, **fields)), (t("ow_btn_close", lang), b(codec.CLOSE))))
    return tuple(rows)


def render_overview(ov: GroupOverview, *, now: datetime, tz: str, lang: str, b: Builder, filt: str, page: int,
                    can_compare: bool) -> tuple[str, Buttons]:
    lic = ov.license
    status = effective_status(lic, now)
    lines = [t("ow_overview_title", lang, title=_title(lic, lang), group_id=str(lic.group_id), status=license_label(status, lang)),
             t("ow_overview_settings", lang)]
    lines += [t("ow_setting_line", lang, setting=k, value=fmt_value(v, lang)) for k, v in ov.settings.items()]
    lines.append(t("ow_overview_events", lang, count=len(ov.events)))
    if not ov.events:
        lines.append(t("ow_overview_no_events", lang))
    for e in ov.events:
        lines.append(t("ow_event_line", lang, when=format_display(e.when, tz), kind=e.kind, what=clean(e.what, 40),
                       actor=str(e.actor) if e.actor is not None else t("ow_none", lang),
                       detail=clean(e.detail, DETAIL_MAX) or t("ow_none", lang)))
    more = ((t("ow_btn_compare", lang), b(codec.PICK, group_id=lic.group_id, filter=filt, page=page)),) if can_compare else ()
    rows = list(_footer(lang, b, back=codec.DETAIL, filt=filt, page=page, group_id=lic.group_id, more=more))
    rows.insert(-1, ((t("ow_btn_refresh", lang), b(codec.OVERVIEW, group_id=lic.group_id, filter=filt, page=page)),))
    return _fit(lines, lang), tuple(rows)


def render_picker(license_: Any, templates: Sequence[SettingsTemplate], *, lang: str, b: Builder, filt: str,
                  page: int) -> tuple[str, Buttons]:
    gid = license_.group_id
    if not templates:
        text = t("tpl_pick_empty", lang, title=_title(license_, lang), group_id=str(gid))
        return text, _footer(lang, b, back=codec.OVERVIEW, filt=filt, page=page, group_id=gid)
    text = t("tpl_pick_title", lang, title=_title(license_, lang), group_id=str(gid))
    more = tuple(((f"⚖ {clean(tpl.name, LABEL_MAX - 3)}", b(codec.DIFF, template_id=tpl.id, group_id=gid, filter=filt, page=page)),)
                 for tpl in templates[:MAX_PICK])
    rows = [*more, *_footer(lang, b, back=codec.OVERVIEW, filt=filt, page=page, group_id=gid)]
    return text, tuple(rows)


def diff_text(diff: TemplateDiff, license_: Any, lang: str) -> str:
    lines = [t("tpl_diff_title", lang, name=clean(diff.template.name, 60), title=_title(license_, lang),
               group_id=str(diff.group_id), changes=len(diff.entries), same=diff.same)]
    if not diff.entries:
        lines.append(t("tpl_diff_same", lang))
    for entry in diff.entries[:MAX_DIFF_LINES]:
        lines.append(t("tpl_diff_line", lang, setting=entry.key, group=fmt_value(entry.group, lang),
                       template=fmt_value(entry.template, lang)))
    if len(diff.entries) > MAX_DIFF_LINES:
        lines.append(t("ow_cut", lang))
    lines.append(t("tpl_diff_footer", lang))
    return _fit(lines, lang)


def render_diff(diff: TemplateDiff, license_: Any, *, lang: str, b: Builder, filt: str, page: int,
                can_apply: bool = False) -> tuple[str, Buttons]:
    more = ((t("ow_btn_apply", lang), b(codec.APPLY_ASK, template_id=diff.template.id, group_id=diff.group_id, filter=filt,
                                        page=page)),) if can_apply and diff.entries else ()
    return diff_text(diff, license_, lang), _footer(lang, b, back=codec.PICK, filt=filt, page=page, group_id=diff.group_id,
                                                    more=more)


def apply_ask_text(template: SettingsTemplate, license_: Any, changes: int, lang: str) -> str:
    return t("tpl_apply_ask", lang, name=clean(template.name, 60), title=_title(license_, lang),
             group_id=str(license_.group_id), changes=changes)


def render_apply_confirm(template: SettingsTemplate, item: Any, license_: Any, *, lang: str, b: Builder, filt: str,
                         page: int) -> tuple[str, Buttons]:
    """The confirmation screen: the exact keys that will change; the button carries the fingerprint of what was shown."""
    lines = [apply_ask_text(template, license_, len(item.entries), lang)]
    for entry in item.entries[:MAX_DIFF_LINES]:
        lines.append(t("tpl_diff_line", lang, setting=entry.key, group=fmt_value(entry.group, lang),
                       template=fmt_value(entry.template, lang)))
    if len(item.entries) > MAX_DIFF_LINES:
        lines.append(t("ow_cut", lang))
    gid = item.group_id
    rows = (((t("ow_btn_confirm", lang), b(codec.APPLY_DO, template_id=template.id, group_id=gid, digest=item.digest[:6],
                                           filter=filt, page=page)),),
            ((t("ow_btn_cancel", lang), b(codec.DIFF, template_id=template.id, group_id=gid, filter=filt, page=page)),
             (t("ow_btn_close", lang), b(codec.CLOSE))))
    return _fit(lines, lang), rows


def _items_lines(preview: Any, lang: str, per_group: int = 6) -> list[str]:
    lines: list[str] = []
    for item in preview.items:
        lines.append(t("tpl_apply_item", lang, title=clean(item.title, 60) or t("title_unknown", lang),
                       group_id=str(item.group_id), changes=len(item.entries)))
        for entry in item.entries[:per_group]:
            lines.append(t("tpl_apply_change", lang, setting=entry.key, group=fmt_value(entry.group, lang),
                           template=fmt_value(entry.template, lang)))
        if len(item.entries) > per_group:
            lines.append(t("ow_cut", lang))
    for gid in preview.skipped:
        lines.append(t("tpl_apply_skipped", lang, group_id=str(gid)))
    return lines


def apply_preview_text(preview: Any, code: str | None, minutes: int, lang: str) -> str:
    lines = [t("tpl_apply_title", lang, name=clean(preview.template.name, 60), count=len(preview.items))]
    lines += _items_lines(preview, lang)
    if code is None:
        lines.append(t("tpl_apply_nothing", lang))
    else:
        lines.append(t("tpl_apply_hint", lang, minutes=minutes, code=code))
    return _fit(lines, lang)


def apply_result_text(name: str, outcomes: Sequence[Any], lang: str) -> str:
    lines = [t("tpl_apply_result", lang, name=clean(name, 60))]
    for o in outcomes:
        lines.append(t("tpl_apply_result_line", lang, group_id=str(o.group_id), outcome=t(f"tpl_out_{o.status}", lang, keys=o.keys)))
    return _fit(lines, lang)


def defaults_text(view: Any, tz: str, lang: str) -> str:
    cur = view.current
    if not cur.settings:
        return t("dfl_empty", lang)
    lines = [t("dfl_show", lang, version=cur.version, when=format_display(cur.updated_at, tz) if cur.updated_at else t("ow_none", lang))]
    for e in view.entries[:MAX_DIFF_LINES]:
        lines.append(t("tpl_diff_line", lang, setting=e.key, group=fmt_value(e.group, lang), template=fmt_value(e.template, lang)))
    if not view.entries:
        lines.append(t("tpl_diff_same", lang))
    return _fit(lines, lang)


def defaults_stage_text(stage: Any, minutes: int, lang: str) -> str:
    lines = [t("dfl_stage_title", lang, source=clean(stage.source, 60) if stage.source else t("dfl_source_reset", lang),
               changes=len(stage.entries))]
    for e in stage.entries[:MAX_DIFF_LINES]:
        lines.append(t("tpl_diff_line", lang, setting=e.key, group=fmt_value(e.group, lang), template=fmt_value(e.template, lang)))
    lines.append(t("dfl_stage_same", lang) if not stage.entries else "")
    lines.append(t("dfl_hint", lang, minutes=minutes, code=stage.code))
    return _fit([l for l in lines if l], lang)


def templates_text(templates: Sequence[SettingsTemplate], tz: str, lang: str) -> str:
    lines = [t("tpl_list_header", lang, count=len(templates))]
    if not templates:
        lines.append(t("tpl_list_empty", lang))
    for tpl in templates:
        lines.append(t("tpl_list_row", lang, id=str(tpl.id), name=clean(tpl.name, 60), keys=len(tpl.settings),
                       when=format_display(tpl.updated_at, tz),
                       source=str(tpl.source_group_id) if tpl.source_group_id is not None else t("ow_none", lang)))
    return _fit(lines, lang)


def render_templates(templates: Sequence[SettingsTemplate], *, tz: str, lang: str, b: Builder, filt: str,
                     page: int) -> tuple[str, Buttons]:
    rows = (((t("ow_btn_back", lang), b(codec.LIST, filter=filt, page=page)), (t("ow_btn_close", lang), b(codec.CLOSE))),)
    return templates_text(templates, tz, lang), rows


def render_template_missing(*, lang: str, b: Builder, group_id: int, filt: str, page: int) -> tuple[str, Buttons]:
    return t("tpl_missing", lang), _footer(lang, b, back=codec.PICK, filt=filt, page=page, group_id=group_id)
