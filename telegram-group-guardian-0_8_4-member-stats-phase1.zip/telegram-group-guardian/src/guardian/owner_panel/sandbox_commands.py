"""Owner commands for the sandbox (phase 5.8), private chat of the primary owner only. Every reply is labelled «🧪 وهمي».

    /sandbox                              status                         تجربة
    /sandbox start <template|group_id|default>   begin from a copy       تجربة بدء
    /sandbox say [u1..u9] <text>          simulate a message             تجربة رسالة
    /sandbox media [u1..u9] [text]        a message with media           تجربة وسائط
    /sandbox join [u1..u9]                a member joins (newcomer window) تجربة انضمام
    /sandbox wait <seconds>               move the virtual clock         تجربة انتظر
    /sandbox set <key> <value>            change a setting INSIDE the sandbox   تجربة اضبط
    /sandbox settings | log               what changed / what happened   تجربة الاعدادات | سجل
    /sandbox diff <group_id>              sandbox vs a real group (preview only)   تجربة قارن
    /sandbox save <name>                  store the sandbox settings as a template   تجربة احفظ
    /sandbox end                          drop the session               تجربة انهاء

Nothing here talks to Telegram or changes a group. Getting a result into a real group = `save` + `/template apply` (confirmed).
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from typing import Any

from ..errors import GroupNotRegistered, InvalidInput, PermissionDenied
from ..i18n import t
from ..moderation.arabic import fold_arabic
from ..owner_sandbox.sandbox import MAX_TEXT, MAX_USERS, MAX_WAIT, SandboxEntry
from ..owner_sandbox.service import NoSession
from ..time_utils import format_display
from .template_commands import TemplateReply
from .views import clean

log = logging.getLogger(__name__)

MAX_COMMAND_LEN = MAX_TEXT + 80
_GROUP = re.compile(r"-[1-9][0-9]{0,18}", re.ASCII)
_USER = re.compile(r"[uU]([1-9])", re.ASCII)
_VERBS = {"start": "start", "say": "say", "media": "media", "join": "join", "wait": "wait", "set": "set", "settings": "settings",
          "log": "log", "diff": "diff", "save": "save", "end": "end", "status": "status"}
_AR_VERBS = {fold_arabic(k): v for k, v in {"بدء": "start", "رسالة": "say", "وسائط": "media", "انضمام": "join", "انتظر": "wait",
                                            "اضبط": "set", "الاعدادات": "settings", "سجل": "log", "قارن": "diff", "احفظ": "save",
                                            "انهاء": "end", "حالة": "status"}.items()}
_AR_ROOT = fold_arabic("تجربة")
_NEEDS_ARG = {"start", "wait", "set", "diff", "save"}
_VIOLATIONS = ("links", "flood", "duplicate", "slowmode", "newbie")


@dataclass(frozen=True, slots=True)
class ParsedSandboxCommand:
    action: str                        # usage | status | start | say | media | join | wait | set | settings | log | diff | save | end
    source: str | int | None = None    # start: None = built-in defaults, int = group id, str = template name
    user: int = 1
    text: str | None = None
    key: str | None = None
    value: Any = None
    seconds: int | None = None
    group_id: int | None = None
    name: str | None = None


def _user_and_rest(rest: str) -> tuple[int, str]:
    parts = rest.split(None, 1)
    if parts and _USER.fullmatch(parts[0]):
        return int(parts[0][1]), (parts[1] if len(parts) > 1 else "")
    return 1, rest


def _build(verb: str, rest: str) -> ParsedSandboxCommand:
    usage = ParsedSandboxCommand("usage")
    rest = rest.strip()
    if verb in _NEEDS_ARG and not rest:
        return usage
    if verb == "start":
        word = fold_arabic(rest)
        if word in ("default", fold_arabic("افتراضي")):
            return ParsedSandboxCommand("start")
        return ParsedSandboxCommand("start", source=int(word) if _GROUP.fullmatch(word) else rest)
    if verb in ("say", "media"):
        user, text = _user_and_rest(rest)
        if verb == "say" and not text:
            return usage
        return ParsedSandboxCommand(verb, user=user, text=text)
    if verb == "join":
        user, extra = _user_and_rest(rest)
        return ParsedSandboxCommand("join", user=user) if not extra else usage
    if verb == "wait":
        word = fold_arabic(rest)
        return ParsedSandboxCommand("wait", seconds=int(word)) if word.isdecimal() and word.isascii() and len(word) <= 9 and 0 < int(word) <= MAX_WAIT else usage
    if verb == "set":
        parts = rest.split(None, 1)
        if len(parts) != 2:
            return usage
        try:
            value = json.loads(parts[1])
        except ValueError:
            value = parts[1]
        return ParsedSandboxCommand("set", key=parts[0], value=value)
    if verb == "diff":
        word = fold_arabic(rest)
        return ParsedSandboxCommand("diff", group_id=int(word)) if _GROUP.fullmatch(word) else usage
    if verb == "save":
        return ParsedSandboxCommand("save", name=rest)
    return ParsedSandboxCommand(verb) if not rest else usage        # status | settings | log | end


def parse_sandbox_command(text: object, bot_username: str | None = None) -> ParsedSandboxCommand | None:
    if not isinstance(text, str):
        return None
    stripped = text.strip()
    if not stripped or len(stripped) > MAX_COMMAND_LEN:
        return None
    if stripped.startswith("/"):
        head, _, rest = stripped.partition(" ")
        name, at, target = head[1:].partition("@")
        if name.lower() != "sandbox":
            return None
        if at and (not bot_username or target.lower() != bot_username.lower()):
            return None
        rest = rest.strip()
        if not rest:
            return ParsedSandboxCommand("status")
        verb, _, tail = rest.partition(" ")
        action = _VERBS.get(verb.lower())
        return _build(action, tail) if action else ParsedSandboxCommand("usage")
    head, _, rest = stripped.partition(" ")
    if fold_arabic(head) != _AR_ROOT:
        return None
    rest = rest.strip()
    if not rest:
        return ParsedSandboxCommand("status")
    verb, _, tail = rest.partition(" ")
    action = _AR_VERBS.get(fold_arabic(verb))
    return _build(action, tail) if action else None


def fmt_span(seconds: int, lang: str) -> str:
    for limit, key, div in ((60, "sbx_span_s", 1), (3600, "sbx_span_m", 60), (86400, "sbx_span_h", 3600)):
        if seconds < limit:
            return t(key, lang, n=max(1, round(seconds / div)))
    return t("sbx_span_d", lang, n=round(seconds / 86400))


def entry_line(e: SandboxEntry, lang: str) -> str:
    if e.kind == "message":
        text = clean(e.text, 60) or t("ow_none", lang)
        if e.verdict == "ok":
            return t("sbx_msg_ok", lang, user=e.user, text=text)
        if e.verdict == "muted":
            return t("sbx_msg_muted", lang, user=e.user, text=text, span=fmt_span(e.muted_seconds or 1, lang))
        if e.verdict == "unsafe":
            return t("sbx_msg_unsafe", lang, user=e.user, text=text)
        parts = []
        if e.deleted:
            parts.append(t("sbx_would_delete", lang))
        if e.muted_seconds:
            parts.append(t("sbx_would_mute", lang, span=fmt_span(e.muted_seconds, lang)))
        label = t(f"sbx_v_{e.violation}", lang) if e.violation in _VIOLATIONS else str(e.violation)
        return t("sbx_msg_acted", lang, user=e.user, text=text, violation=label, what="، ".join(parts) or t("sbx_would_nothing", lang))
    if e.kind == "join":
        return t("sbx_joined", lang, user=e.user)
    if e.kind == "wait":
        return t("sbx_waited", lang, span=fmt_span(int(e.text or 0), lang))
    return t("sbx_set_line", lang, change=clean(e.text, 80))


class SandboxCommandService:
    def __init__(self, sandbox: Any, templates: Any, licenses: Any, *, display_timezone: str = "Asia/Riyadh", language: str = "ar"):
        self._sandbox, self._templates, self._licenses, self._tz, self._language = sandbox, templates, licenses, display_timezone, language

    def _reply(self, status: str, text: str, lang: str) -> TemplateReply:
        return TemplateReply(status, t("sbx_banner", lang) + "\n" + text)

    async def run(self, parsed: ParsedSandboxCommand, *, chat_id: object, chat_type: object, user_id: object,
                  lang: str | None = None) -> TemplateReply | None:
        """None = answer nothing (not a private chat, or not the owner)."""
        lang = lang or self._language
        if chat_type != "private" or not isinstance(chat_id, int) or isinstance(chat_id, bool) or chat_id <= 0 or chat_id != user_id:
            return None
        try:
            await self._templates.require_owner(user_id)
        except PermissionDenied:
            return None
        except Exception:
            log.error("sandbox owner check failed", exc_info=True)
            return None
        try:
            status, text = await self._run(parsed, user_id, lang)
        except PermissionDenied:
            return None
        except NoSession:
            status, text = "no_session", t("sbx_none", lang)
        except (GroupNotRegistered, InvalidInput):
            status, text = ("bad_input", t("sbx_bad_input", lang))
        except Exception:
            log.error("sandbox command failed", exc_info=True)
            status, text = "failed", t("tpl_cmd_failed", lang)
        return self._reply(status, text, lang)

    async def _run(self, p: ParsedSandboxCommand, owner: int, lang: str) -> tuple[str, str]:
        sb, a = self._sandbox, p.action
        if a == "usage":
            return "usage", t("sbx_usage", lang)
        if a == "start":
            sess = await sb.start(owner, p.source)
            return "started", t("sbx_started", lang, source=self._source(sess, lang))
        if a == "status":
            try:
                sess = await sb.status(owner)
            except NoSession:
                return "no_session", t("sbx_none", lang)
            changes = len([k for k in sess.settings if sess.settings[k] != sess.origin.get(k)])
            return "status", t("sbx_status", lang, source=self._source(sess, lang), events=sess._n, violations=sess.violations,
                               when=format_display(sess.clock(), self._tz), changes=changes)
        if a in ("say", "media"):
            entry = await sb.say(owner, p.user, p.text or "", media=a == "media")
            return "message", entry_line(entry, lang)
        if a == "join":
            return "joined", entry_line(await sb.join(owner, p.user), lang)
        if a == "wait":
            return "waited", entry_line(await sb.wait(owner, p.seconds), lang)
        if a == "set":
            try:
                entry = await sb.set(owner, p.key, p.value)
            except InvalidInput:
                return "set_invalid", t("sbx_set_bad", lang)
            return "set", t("sbx_set_ok", lang, setting=clean(p.key, 40), value=clean(repr(p.value), 60))
        if a == "settings":
            sess = await sb.status(owner)
            lines = [t("sbx_settings_header", lang, count=0)]
            changed = [(k, sess.origin.get(k), v) for k, v in sess.settings.items() if v != sess.origin.get(k)]
            lines[0] = t("sbx_settings_header", lang, count=len(changed))
            lines += [t("tpl_diff_line", lang, setting=k, group=_v(o, lang), template=_v(n, lang)) for k, o, n in changed[:40]]
            if not changed:
                lines.append(t("sbx_settings_same", lang))
            return "settings", "\n".join(lines)
        if a == "log":
            entries = await sb.log(owner)
            lines = [t("sbx_log_header", lang, count=len(entries))] + [f"{e.n}. {entry_line(e, lang)}" for e in entries]
            return "log", "\n".join(lines)
        if a == "diff":
            entries, same = await sb.diff(owner, p.group_id)
            lic = await self._licenses.get(p.group_id)
            lines = [t("sbx_diff_title", lang, title=clean(getattr(lic, "title", None), 60) or t("title_unknown", lang),
                       group_id=str(p.group_id), changes=len(entries), same=same)]
            lines += [t("tpl_diff_line", lang, setting=e.key, group=_v(e.group, lang), template=_v(e.template, lang)) for e in entries[:40]]
            if not entries:
                lines.append(t("tpl_diff_same", lang))
            lines.append(t("sbx_diff_footer", lang, group_id=str(p.group_id)))
            return "diff", "\n".join(lines)
        if a == "save":
            template, _created = await sb.save(owner, p.name)
            return "saved", t("sbx_saved", lang, name=template.name, id=str(template.id))
        events, violations = await sb.end(owner)
        return "ended", t("sbx_ended", lang, events=events, violations=violations)

    @staticmethod
    def _source(sess, lang: str) -> str:
        if sess.source == "default":
            return t("sbx_source_default", lang)
        kind = sess.source.split(":", 1)[0]
        return t("sbx_source_group" if kind == "group" else "sbx_source_template", lang, name=clean(sess.source_name, 60))


def _v(value: Any, lang: str) -> str:
    from .insight_views import fmt_value
    return fmt_value(value, lang)
