"""Owner command that checks every API the bot uses (part 9.6), private chat of the primary owner only:

    /apicheck            quick check: Telegram (token, webhook, owner group), every Gemini key, the database      فحص API
    /apicheck deep       also tries each Gemini key with one tiny request, which shows a daily quota that ran out   فحص API عميق
    /apis [deep]         the same

(Arabic details) `فحص|افحص|حالة|اختبار|اختبر` + one of `API` (also `الAPI`, `ال API`, `الـ API`), `الواجهات`, `المفاتيح`, `الخدمات`
(and their short forms), optionally followed by `عميق` | `كامل` | `شامل`. Alef/hamza, ta marbuta/ha and ya/alef maqsura are
interchangeable everywhere (`fold_arabic`).

The parser only RECOGNISES text; who may use it is decided by `ApiCheckCommandService` (exactly the owner, private chat): anybody
else gets SILENCE, like the other owner commands. The report never shows a token, a key, the database URL or the webhook address.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from ..content_filter.gemini import (R_EXHAUSTED, R_EXPIRED, R_INVALID, R_MODEL, R_NETWORK, R_PAUSED, R_SERVER, R_UNKNOWN,
                                     R_WORKING, KeyReport)
from ..errors import PermissionDenied
from ..i18n import Raw, t
from ..moderation.arabic import fold_arabic
from ..permissions import Permission
from ..time_utils import format_display
from .api_check import (D_DOWN, D_OK, D_SLOW, H_OK, H_UNKNOWN, H_UNREACHABLE, H_UNSET, S_INVALID, S_NETWORK, S_OK, S_PAUSED, W_MISMATCH,
                        W_MISSING, W_OK, ApiReport)

log = logging.getLogger(__name__)

MAX_COMMAND_LEN = 60


def _set(*words: str) -> frozenset[str]:
    return frozenset(fold_arabic(w) for w in words)


_VERBS = _set("فحص", "افحص", "حالة", "حاله", "اختبار", "اختبر")
_TARGETS = _set("api", "apis", "الapi", "الapis", "الواجهات", "واجهات", "المفاتيح", "مفاتيح", "الخدمات", "خدمات")
_THE = _set("ال")                      # `ال API` / `الـ API` written with a space (the tatweel is removed by the folding)
_API_WORDS = _set("api", "apis")
_DEEP_AR = _set("عميق", "عميقا", "كامل", "كامله", "شامل", "شامله")
_DEEP_EN = frozenset({"deep", "full"})


@dataclass(frozen=True, slots=True)
class ParsedApiCheck:
    action: str            # check | usage
    deep: bool = False


def parse_api_check_command(text: object, bot_username: str | None = None) -> ParsedApiCheck | None:
    if not isinstance(text, str):
        return None
    stripped = text.strip()
    if not stripped or len(stripped) > MAX_COMMAND_LEN:
        return None
    words = stripped.split()
    if stripped.startswith("/"):
        name, at, target = words[0][1:].partition("@")
        if name.lower() not in ("apicheck", "apis"):
            return None
        if at and (not bot_username or target.lower() != bot_username.lower()):
            return None  # addressed to another bot (or we do not know our own name)
        rest = [w.lower() for w in words[1:]]
        if not rest:
            return ParsedApiCheck("check")
        return ParsedApiCheck("check", True) if len(rest) == 1 and rest[0] in _DEEP_EN else ParsedApiCheck("usage")
    folded = [fold_arabic(w) for w in words]
    if folded[0] not in _VERBS or len(folded) < 2:
        return None
    body = folded[1:]
    if len(body) >= 2 and body[0] in _THE and body[1] in _API_WORDS:   # `ال API`
        body = body[1:]
    if not body or body[0] not in _TARGETS:
        return None
    tail = body[1:]
    if not tail:
        return ParsedApiCheck("check")
    if len(tail) == 1 and tail[0] in _DEEP_AR | _DEEP_EN:
        return ParsedApiCheck("check", True)
    return None   # anything else after the words is ordinary talk, not a command


# ------------------------------------------------------------------------------------------------ text
def _telegram_lines(report: ApiReport, lang: str) -> list[str]:
    tg = report.telegram
    lines = [t("api_sec_tg", lang)]
    if tg.token == S_OK:
        lines.append(t("api_tg_token_ok", lang, bot=f"@{tg.username}" if tg.username else "—"))
    elif tg.token == S_INVALID:
        lines.append(t("api_tg_token_invalid", lang))
    elif tg.token == S_PAUSED:
        lines.append(t("api_tg_token_paused", lang, secs=str(tg.retry_after)) if tg.retry_after else t("api_tg_token_paused_unknown", lang))
    elif tg.token == S_NETWORK:
        lines.append(t("api_tg_token_network", lang))
    else:
        lines.append(t("api_tg_token_error", lang))
    if tg.webhook == W_OK:
        lines.append(t("api_tg_wh_backlog" if tg.backlog else "api_tg_wh_ok", lang, pending=str(tg.pending)))
    elif tg.webhook == W_MISSING:
        lines.append(t("api_tg_wh_missing", lang))
    elif tg.webhook == W_MISMATCH:
        lines.append(t("api_tg_wh_mismatch", lang))
    else:
        lines.append(t("api_tg_wh_unknown", lang))
    return lines


def render(report: ApiReport, tz: str, lang: str) -> str:
    out: list[str] = [t("api_title", lang, mode=Raw(t("api_mode_deep", lang)) if report.deep else "", when=format_display(report.at, tz)), ""]
    out += _telegram_lines(report, lang)
    tg = report.telegram
    if tg.error_text and tg.error_at is not None:
        out.append(t("api_tg_wh_error", lang, when=format_display(tg.error_at, tz), error=tg.error_text))
    out.append(t({H_UNSET: "api_hub_unset", H_OK: "api_hub_ok", H_UNREACHABLE: "api_hub_bad", H_UNKNOWN: "api_hub_unknown"}[tg.hub], lang))
    out += ["", t("api_sec_gemini", lang, model=report.model or "—")]
    if report.configured_keys == 0 and not report.keys:
        out.append(t("api_gem_none", lang))
    else:
        for key in report.keys:
            out.append(_key_line(key, tz, lang))
        if report.empty_slots and report.keys:
            out.append(t("api_gem_empty_slots", lang, slots="، ".join(map(str, report.empty_slots)) if lang == "ar" else ", ".join(map(str, report.empty_slots))))
        out.append(t("api_gem_summary" if report.ready_keys else "api_gem_summary_none", lang, ready=str(report.ready_keys), total=str(len(report.keys))))
    db = report.database
    out += ["", t("api_sec_db", lang)]
    out.append(t({D_OK: "api_db_ok", D_SLOW: "api_db_slow", D_DOWN: "api_db_down"}[db.state], lang, ms=str(db.millis if db.millis is not None else 0)))
    out += ["", t("api_hint_deep" if report.deep else "api_hint_light", lang)]
    return "\n".join(out)


def _key_line(key: KeyReport, tz: str, lang: str) -> str:
    n = str(key.slot)
    if key.state == R_WORKING:
        return t("api_key_working", lang, n=n)
    if key.state == R_EXHAUSTED:
        return t("api_key_exhausted", lang, n=n, when=format_display(key.until, tz) if key.until else "—")
    if key.state == R_PAUSED:
        return t("api_key_paused", lang, n=n, secs=str(key.retry_after or 60))
    if key.state == R_INVALID:
        return t("api_key_invalid", lang, n=n)
    if key.state == R_EXPIRED:
        return t("api_key_expired", lang, n=n)
    if key.state == R_NETWORK:
        return t("api_key_network", lang, n=n)
    if key.state == R_SERVER:
        return t("api_key_server", lang, n=n)
    if key.state == R_MODEL:
        return t("api_key_model", lang, n=n)
    return t("api_key_unknown", lang, n=n)   # R_UNKNOWN and anything not known


@dataclass(frozen=True, slots=True)
class ApiCheckReply:
    status: str   # ok | usage | failed
    text: str


class ApiCheckCommandService:
    def __init__(self, checker: Any, permissions: Any, *, display_timezone: str = "Asia/Riyadh", language: str = "ar"):
        self._checker, self._perm, self._tz, self._language = checker, permissions, display_timezone, language

    async def run(self, parsed: ParsedApiCheck, *, chat_id: object, chat_type: object, user_id: object,
                  lang: str | None = None) -> ApiCheckReply | None:
        """-> a reply, or None (not a private chat / not the owner: no answer at all)."""
        lang = lang or self._language
        if chat_type != "private" or not isinstance(chat_id, int) or isinstance(chat_id, bool) or chat_id <= 0 or chat_id != user_id:
            return None
        try:
            decision = await self._perm.check_global(user_id, Permission.OWNER_PANEL)
        except PermissionDenied:
            return None
        except Exception:
            log.error("api check owner check failed", exc_info=True)
            return None
        if not decision.allowed:
            return None
        if parsed.action == "usage":
            return ApiCheckReply("usage", t("api_usage", lang))
        try:
            report = await self._checker.run(deep=parsed.deep)
            return ApiCheckReply("ok", render(report, self._tz, lang))
        except Exception:
            log.error("api check failed", exc_info=True)
            return ApiCheckReply("failed", t("api_failed", lang))
