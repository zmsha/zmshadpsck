"""Owner commands for settings templates (phase 5.6), private chat of the primary owner only:

    /templates                              list            القوالب
    /template save <name> <group_id>        copy a group's EFFECTIVE settings into a template   حفظ قالب <اسم> <معرّف>
    /template diff <name> <group_id>        preview the differences (changes nothing)           قارن قالب <اسم> <معرّف>
    /template delete <name>                 delete a template (never touches a group)           حذف قالب <اسم>
    /template apply <name> <id> [<id>..]    PREVIEW applying it to up to 20 groups + a code      تطبيق قالب <اسم> <معرّفات>
    /template confirm <code>                apply exactly what the preview showed (once)         تأكيد قالب <الرمز>
    /defaults [show]                        the global defaults for NEW groups                    الافتراضيات
    /defaults set <name> | reset            PREVIEW new defaults (a template / the built-in values) + a code
    /defaults confirm <code>                approve them (new groups only; existing groups are never touched)
    (Arabic, part 9.3)   الافتراضيات | عرض الافتراضيات | تعيين الافتراضيات <اسم> | اعادة الافتراضيات | تاكيد الافتراضيات <الرمز>
                         or the English shape: الافتراضيات عرض | تعيين <اسم> | اعادة | تاكيد <الرمز>

The parser only RECOGNISES text; who may use it is decided by `TemplateService` (exactly OWNER_TELEGRAM_ID): anybody else gets
SILENCE (the denial is audited by the permission service). None of these commands changes a group.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import Any

from ..errors import GroupNotRegistered, InvalidInput, PermissionDenied
from ..i18n import t
from ..moderation.arabic import fold_arabic
from ..owner_templates.defaults import DefaultsStage
from ..owner_templates.templates import MAX_TEMPLATES, NAME_MAX, TemplateLimitReached, normalize_name
from . import insight_views as iv

log = logging.getLogger(__name__)

MAX_COMMAND_LEN = 200
_GROUP = re.compile(r"-[1-9][0-9]{0,18}", re.ASCII)
_AR_LIST = {fold_arabic("القوالب"), fold_arabic("قوالب")}
_AR_WORDS = {fold_arabic("حفظ"): "save", fold_arabic("حذف"): "delete", fold_arabic("قارن"): "diff",
             fold_arabic("تطبيق"): "apply", fold_arabic("تاكيد"): "confirm"}
_AR_DEFAULTS = fold_arabic("الافتراضيات")
_AR_DEFAULTS_FORMS = {fold_arabic("الافتراضيات"), fold_arabic("افتراضيات")}
_AR_DEFAULTS_VERBS = {fold_arabic(w): action for action, words in {
    "defaults_show": ("عرض", "اعرض", "الحاله"), "defaults_set": ("تعيين", "عين", "ضبط", "اضبط", "حدد"),
    "defaults_reset": ("اعاده", "اعد", "استعاده", "تصفير"), "defaults_confirm": ("تاكيد", "اعتماد", "اعتمد")}.items() for w in words}
_CODE = re.compile(r"[A-Za-z0-9]{4,12}", re.ASCII)
MAX_APPLY_GROUPS = 20
_AR_TEMPLATE = fold_arabic("قالب")
_NEEDS_GROUP = {"save", "diff"}


@dataclass(frozen=True, slots=True)
class ParsedTemplateCommand:
    action: str                    # list | save | diff | delete | usage
    name: str | None = None        # raw (the service normalises it)
    group_id: int | None = None
    group_ids: tuple[int, ...] = ()   # apply
    code: str | None = None           # confirm / defaults_confirm


def _build(action: str, words: list[str]) -> ParsedTemplateCommand:
    if action == "list":
        return ParsedTemplateCommand("list") if not words else ParsedTemplateCommand("usage")
    if action in _NEEDS_GROUP:
        gid = fold_arabic(words[-1]) if words else ""
        if len(words) < 2 or not _GROUP.fullmatch(gid):
            return ParsedTemplateCommand("usage")
        return ParsedTemplateCommand(action, " ".join(words[:-1]), int(gid))
    if action == "apply":
        for i, word in enumerate(words):
            if _GROUP.fullmatch(fold_arabic(word)):
                ids = [fold_arabic(w) for w in words[i:]]
                if i == 0 or not all(_GROUP.fullmatch(x) for x in ids) or len(ids) > MAX_APPLY_GROUPS:
                    return ParsedTemplateCommand("usage")
                return ParsedTemplateCommand("apply", " ".join(words[:i]), group_ids=tuple(dict.fromkeys(int(x) for x in ids)))
        return ParsedTemplateCommand("usage")
    if action in ("confirm", "defaults_confirm"):
        return (ParsedTemplateCommand(action, code=words[0].upper())
                if len(words) == 1 and _CODE.fullmatch(words[0]) else ParsedTemplateCommand("usage"))
    if action == "defaults_set" and words:
        return ParsedTemplateCommand("defaults_set", " ".join(words))
    if action in ("defaults_show", "defaults_reset") and not words:
        return ParsedTemplateCommand(action)
    if action == "delete" and words:
        return ParsedTemplateCommand("delete", " ".join(words))
    return ParsedTemplateCommand("usage")


def parse_template_command(text: object, bot_username: str | None = None) -> ParsedTemplateCommand | None:
    if not isinstance(text, str):
        return None
    stripped = text.strip()
    if not stripped or len(stripped) > MAX_COMMAND_LEN:
        return None
    words = stripped.split()
    if stripped.startswith("/"):
        name, at, target = words[0][1:].partition("@")
        if name.lower() not in ("template", "templates", "defaults"):
            return None
        if at and (not bot_username or target.lower() != bot_username.lower()):
            return None  # addressed to another bot (or we do not know our own name)
        if name.lower() == "templates":
            return _build("list", words[1:])
        if name.lower() == "defaults":
            sub = words[1].lower() if len(words) > 1 else "show"
            return _build(f"defaults_{sub}", words[2:]) if sub in ("show", "set", "reset", "confirm") else ParsedTemplateCommand("usage")
        if len(words) == 1:
            return ParsedTemplateCommand("usage")
        sub = words[1].lower()
        if sub in ("save", "diff", "delete", "list", "apply", "confirm"):
            return _build(sub, words[2:])
        return ParsedTemplateCommand("usage")
    folded = [fold_arabic(w) for w in words]
    if len(words) == 1 and folded[0] in _AR_LIST:
        return ParsedTemplateCommand("list")
    if len(words) == 1 and folded[0] == _AR_DEFAULTS:
        return ParsedTemplateCommand("defaults_show")
    if len(words) >= 3 and folded[0] in _AR_WORDS and folded[1] == _AR_TEMPLATE:
        return _build(_AR_WORDS[folded[0]], words[2:])
    return _parse_arabic_defaults(words, folded)


def _parse_arabic_defaults(words: list[str], folded: list[str]) -> ParsedTemplateCommand | None:
    """`/defaults ...` in Arabic: verb + الافتراضيات (`تعيين الافتراضيات قالب`) or the English order (`الافتراضيات اعادة`)."""
    if len(words) >= 2 and folded[0] in _AR_DEFAULTS_VERBS and folded[1] in _AR_DEFAULTS_FORMS:
        return _build(_AR_DEFAULTS_VERBS[folded[0]], words[2:])
    if len(words) >= 2 and folded[0] in _AR_DEFAULTS_FORMS and folded[1] in _AR_DEFAULTS_VERBS:
        return _build(_AR_DEFAULTS_VERBS[folded[1]], words[2:])
    return None


_V57 = frozenset({"apply", "confirm", "defaults_show", "defaults_set", "defaults_reset", "defaults_confirm"})


@dataclass(frozen=True, slots=True)
class TemplateReply:
    status: str
    text: str


class TemplateCommandService:
    def __init__(self, templates: Any, licenses: Any, *, display_timezone: str = "Asia/Riyadh", language: str = "ar",
                 applier: Any = None, defaults: Any = None, pending: Any = None):
        self._templates, self._licenses, self._tz, self._language = templates, licenses, display_timezone, language
        self._applier, self._defaults, self._pending = applier, defaults, pending   # 5.7 (None = those commands are unavailable)

    async def run(self, parsed: ParsedTemplateCommand, *, chat_id: object, chat_type: object, user_id: object,
                  lang: str | None = None) -> TemplateReply | None:
        """None = answer nothing (not a private chat, or not the owner)."""
        lang = lang or self._language
        if chat_type != "private" or not isinstance(chat_id, int) or isinstance(chat_id, bool) or chat_id <= 0 or chat_id != user_id:
            return None
        try:
            await self._templates.require_owner(user_id)
        except PermissionDenied:
            return None
        except Exception:
            log.error("template command owner check failed", exc_info=True)
            return None
        try:
            return await self._run(parsed, user_id, lang)
        except PermissionDenied:
            return None
        except TemplateLimitReached:
            return TemplateReply("limit", t("tpl_cmd_limit", lang, limit=MAX_TEMPLATES))
        except GroupNotRegistered:
            return TemplateReply("group_unknown", t("tpl_cmd_group_unknown", lang))
        except InvalidInput:
            return TemplateReply("invalid", t("tpl_cmd_group_unknown", lang))
        except Exception:
            log.error("template command failed", exc_info=True)
            return TemplateReply("failed", t("tpl_cmd_failed", lang))

    async def _run(self, parsed: ParsedTemplateCommand, owner: int, lang: str) -> TemplateReply:
        if parsed.action == "usage":
            return TemplateReply("usage", t("tpl_cmd_usage", lang))
        if parsed.action == "list":
            return TemplateReply("list", iv.templates_text(await self._templates.list(owner), self._tz, lang))
        if parsed.action in _V57:
            if self._applier is None or self._defaults is None or self._pending is None:
                return TemplateReply("failed", t("tpl_cmd_failed", lang))
            return await self._run57(parsed, owner, lang)
        try:
            normalize_name(parsed.name)
        except InvalidInput:
            return TemplateReply("name_invalid", t("tpl_cmd_name_invalid", lang, limit=NAME_MAX))
        if parsed.action == "save":
            template, created = await self._templates.save_from_group(owner, parsed.name, parsed.group_id)
            key = "tpl_cmd_saved" if created else "tpl_cmd_updated"
            return TemplateReply("saved" if created else "updated",
                                 t(key, lang, name=template.name, id=str(template.id), group_id=str(parsed.group_id),
                                   keys=len(template.settings)))
        template = await self._templates.find(owner, parsed.name)
        if template is None:
            return TemplateReply("not_found", t("tpl_cmd_not_found", lang))
        if parsed.action == "delete":
            if not await self._templates.delete(owner, template.id):
                return TemplateReply("not_found", t("tpl_cmd_not_found", lang))
            return TemplateReply("deleted", t("tpl_cmd_deleted", lang, name=template.name))
        diff = await self._templates.diff(owner, template.id, parsed.group_id)   # preview only
        if diff is None:
            return TemplateReply("not_found", t("tpl_cmd_not_found", lang))
        return TemplateReply("diff", iv.diff_text(diff, await self._licenses.get(parsed.group_id), lang))

    async def _find(self, owner: int, name: str | None):
        try:
            normalize_name(name)
        except InvalidInput:
            return None
        return await self._templates.find(owner, name)

    async def _run57(self, parsed: ParsedTemplateCommand, owner: int, lang: str) -> TemplateReply:
        minutes = self._pending.ttl_minutes
        action = parsed.action
        if action == "apply":
            template = await self._find(owner, parsed.name)
            preview = None if template is None else await self._applier.preview(owner, template.id, parsed.group_ids)
            if preview is None:
                return TemplateReply("not_found", t("tpl_cmd_not_found", lang))
            todo = [(i.group_id, i.digest) for i in preview.items if i.entries]
            code = self._pending.create(owner, "apply", (template.id, todo)) if todo else None
            return TemplateReply("apply_preview" if code else "apply_nothing", iv.apply_preview_text(preview, code, minutes, lang))
        if action == "confirm":
            staged = self._pending.take(owner, "apply", parsed.code)
            if staged is None:
                return TemplateReply("confirm_unknown", t("tpl_confirm_unknown", lang))
            template_id, todo = staged
            template = await self._templates.get(owner, template_id)
            outcomes = await self._applier.execute(owner, template_id, todo, parsed.code)
            return TemplateReply("applied", iv.apply_result_text(template.name if template else "?", outcomes, lang))
        if action == "defaults_show":
            return TemplateReply("defaults", iv.defaults_text(await self._defaults.show(owner), self._tz, lang))
        if action in ("defaults_set", "defaults_reset"):
            template_id = None
            if action == "defaults_set":
                template = await self._find(owner, parsed.name)
                if template is None:
                    return TemplateReply("not_found", t("tpl_cmd_not_found", lang))
                template_id = template.id
            stage: DefaultsStage | None = await self._defaults.stage(owner, template_id)
            if stage is None:
                return TemplateReply("not_found", t("tpl_cmd_not_found", lang))
            return TemplateReply("defaults_preview", iv.defaults_stage_text(stage, minutes, lang))
        status, row = await self._defaults.confirm(owner, parsed.code)       # defaults_confirm
        if status == "approved":
            return TemplateReply("defaults_approved", t("dfl_applied", lang, version=row.version))
        if status == "conflict":
            return TemplateReply("defaults_conflict", t("dfl_conflict", lang))
        return TemplateReply("confirm_unknown", t("tpl_confirm_unknown", lang))
