"""Pure rendering + selection logic of the owner panel (no I/O, no aiogram). Nothing here changes anything.

The action buttons of 5.4 only POINT at signed callbacks (`codec`); what they do is decided server-side (`actions`).

Texts are Telegram-HTML: every user-controlled value (group titles, notes) goes through `i18n.t` (which escapes) or
`html.escape`. Button labels are plain text (never HTML-escaped, never longer than `LABEL_MAX`)."""
from __future__ import annotations

import re
from datetime import datetime
from typing import Callable

from ..i18n import license_label, t
from ..licensing.commands import _remaining  # the same "remaining time" wording as `حالة البوت`
from ..licensing.models import ACTIVE_STATUSES, GroupLicense, LicenseStatus, effective_status
from ..moderation.arabic import fold_arabic
from ..time_utils import format_display
from . import actions as act, codec

PAGE_SIZE = 8
LABEL_MAX = 38
MAX_QUERY_LEN = 64
NOTE_MAX = 200
Buttons = tuple[tuple[tuple[str, str], ...], ...]  # rows of (label, callback_data)
Builder = Callable[..., str]                        # (screen, **fields) -> signed callback data

FILTER_STATUS: dict[str, LicenseStatus | None] = {
    "a": None, "p": LicenseStatus.PENDING, "d": LicenseStatus.ACTIVE_PERMANENT, "t": LicenseStatus.ACTIVE_TEMPORARY,
    "x": LicenseStatus.EXPIRED, "s": LicenseStatus.STOPPED, "r": LicenseStatus.REJECTED, "b": LicenseStatus.BANNED,
}
assert "".join(FILTER_STATUS) == codec.FILTER_CODES
_ICON = {
    LicenseStatus.PENDING: "🕓", LicenseStatus.ACTIVE_PERMANENT: "✅", LicenseStatus.ACTIVE_TEMPORARY: "⏳",
    LicenseStatus.EXPIRED: "⌛", LicenseStatus.STOPPED: "⏸", LicenseStatus.REJECTED: "❌", LicenseStatus.BANNED: "⛔",
}
_PRIORITY = {LicenseStatus.PENDING: 0}  # groups waiting for the owner come first
_CONTROL = re.compile(r"[\x00-\x1f\x7f​-‏‪-‮⁦-⁩]")


def clean(text: str | None, limit: int) -> str:
    """Single-line, control/bidi-free, truncated (titles are chosen by group admins: never trusted)."""
    text = " ".join(_CONTROL.sub(" ", text or "").split())
    return text if len(text) <= limit else text[: limit - 1] + "…"


def normalise_query(text: object) -> str:
    return " ".join(fold_arabic(text).split()) if isinstance(text, str) else ""


def matches(license_: GroupLicense, query: str) -> bool:
    """Case/alef/digit-insensitive substring match on the title or on the group id (`query` already normalised)."""
    if not query:
        return True
    title = fold_arabic(license_.title or "")
    return query in title or query in str(license_.group_id)


def ordered(rows: list[GroupLicense], now: datetime) -> list[GroupLicense]:
    return sorted(rows, key=lambda r: (_PRIORITY.get(effective_status(r, now), 1), -r.updated_at.timestamp(), r.group_id))


def counts(rows: list[GroupLicense], now: datetime) -> dict[str, int]:
    out = {code: 0 for code in codec.FILTER_CODES}
    for row in rows:
        out["a"] += 1
        status = effective_status(row, now)
        for code, wanted in FILTER_STATUS.items():
            if wanted is status:
                out[code] += 1
    return out


def select(rows: list[GroupLicense], filt: str, query: str, now: datetime) -> list[GroupLicense]:
    wanted = FILTER_STATUS[filt]
    return ordered([r for r in rows if matches(r, query) and (wanted is None or effective_status(r, now) is wanted)], now)


def filter_label(code: str, lang: str) -> str:
    status = FILTER_STATUS[code]
    return t("ow_filter_all", lang) if status is None else license_label(status, lang)


def page_count(total: int) -> int:
    return max(1, -(-total // PAGE_SIZE))


def _row_label(row: GroupLicense, now: datetime, lang: str) -> str:
    name = clean(row.title, LABEL_MAX - 3) or str(row.group_id)
    return f"{_ICON[effective_status(row, now)]} {name}"


def render_list(rows: list[GroupLicense], *, filt: str, page: int, query: str, now: datetime, lang: str, b: Builder,
                truncated_at: int | None = None, with_templates: bool = False) -> tuple[str, Buttons]:
    """`rows` = the already selected rows (see `select`). The page is clamped (a stale button never breaks the list)."""
    pages = page_count(len(rows))
    page = max(0, min(page, pages - 1))
    chunk = rows[page * PAGE_SIZE:(page + 1) * PAGE_SIZE]
    lines = [t("ow_list_header", lang, filter=filter_label(filt, lang), count=len(rows), page=page + 1, pages=pages)]
    if query:
        lines.append(t("ow_list_query", lang, query=clean(query, MAX_QUERY_LEN)))
    if truncated_at:
        lines.append(t("ow_list_truncated", lang, limit=truncated_at))
    if not chunk:
        lines.append(t("ow_list_empty", lang))
    for row in chunk:
        status = effective_status(row, now)
        lines.append(t("ow_list_row", lang, icon=_ICON[status], title=clean(row.title, 60) or t("title_unknown", lang),
                       group_id=str(row.group_id), status=license_label(status, lang)))
    buttons: list[tuple[tuple[str, str], ...]] = [
        ((_row_label(r, now, lang), b(codec.DETAIL, group_id=r.group_id, filter=filt, page=page)),) for r in chunk]
    nav: list[tuple[str, str]] = []
    if page > 0:
        nav.append((t("ow_btn_prev", lang), b(codec.LIST, filter=filt, page=page - 1)))
    nav.append((t("ow_btn_page", lang, page=page + 1, pages=pages), b(codec.LIST, filter=filt, page=page)))
    if page < pages - 1:
        nav.append((t("ow_btn_next", lang), b(codec.LIST, filter=filt, page=page + 1)))
    buttons.append(tuple(nav))
    tools = [(t("ow_btn_filter", lang), b(codec.FILTERS, filter=filt, page=page)),
             ((t("ow_btn_clear", lang), b(codec.CLEAR_SEARCH)) if query else (t("ow_btn_search", lang), b(codec.SEARCH_HELP)))]
    buttons.append(tuple(tools))
    if with_templates:   # 5.6: the owner's settings templates (read only)
        buttons.append(((t("ow_btn_templates", lang), b(codec.TEMPLATES, filter=filt, page=page)),))
    buttons.append(((t("ow_btn_refresh", lang), b(codec.LIST, filter=filt, page=page)), (t("ow_btn_close", lang), b(codec.CLOSE))))
    return "\n".join(lines), tuple(buttons)


def render_filters(counted: dict[str, int], *, current: str, page: int, query: str, lang: str, b: Builder) -> tuple[str, Buttons]:
    text = t("ow_filter_title", lang)
    if query:
        text += "\n" + t("ow_list_query", lang, query=clean(query, MAX_QUERY_LEN))
    rows = [((f"{'✅ ' if code == current else ''}{filter_label(code, lang)} ({counted[code]})",
              b(codec.LIST, filter=code, page=0)),) for code in codec.FILTER_CODES]
    rows.append(((t("ow_btn_back", lang), b(codec.LIST, filter=current, page=page)), (t("ow_btn_close", lang), b(codec.CLOSE))))
    return text, tuple(rows)


def _when(value: datetime | None, tz: str, lang: str) -> str:
    return format_display(value, tz) if value is not None else t("ow_none", lang)


_MENU_LABEL = {
    LicenseStatus.PENDING: "ow_btn_menu_activate", LicenseStatus.STOPPED: "ow_btn_menu_activate",
    LicenseStatus.ACTIVE_PERMANENT: "ow_btn_menu_set", LicenseStatus.ACTIVE_TEMPORARY: "ow_btn_menu_renew",
    LicenseStatus.EXPIRED: "ow_btn_menu_renew",
}


def _action_label(code: str, status: LicenseStatus, lang: str) -> str:
    spec = act.SPECS[code]
    if spec.days is not None:
        return act.days_phrase(spec.days, lang)
    if code == "ap":
        return t("ow_btn_make_perm" if status is LicenseStatus.ACTIVE_TEMPORARY else "ow_btn_act_perm", lang)
    if code == "st":
        return t("ow_btn_stop", lang)
    if code == "rj":
        return t("ow_btn_reject", lang)
    if code == "bn":
        return t("ow_btn_ban", lang)
    if code == "ub":
        return t("ow_btn_unban", lang)
    return t("ow_btn_allow", lang)


def _action_button(code: str, row: GroupLicense, status: LicenseStatus, *, lang: str, b: Builder, filt: str,
                   page: int) -> tuple[str, str]:
    """Dangerous (or active-replacing) actions point at the confirmation screen, the others run on the press."""
    screen = codec.ASK if act.needs_confirm(code, status) else codec.DO
    return (_action_label(code, status, lang),
            b(screen, action=code, status=act.STATUS_CODE[status], group_id=row.group_id, filter=filt, page=page))


def _action_rows(row: GroupLicense, status: LicenseStatus, *, lang: str, b: Builder, filt: str,
                 page: int) -> list[tuple[tuple[str, str], ...]]:
    out: list[tuple[tuple[str, str], ...]] = []
    for tokens in act.rows_for(status):
        line = []
        for token in tokens:
            if token == act.MENU:
                line.append((t(_MENU_LABEL[status], lang), b(codec.MENU, group_id=row.group_id, filter=filt, page=page)))
            else:
                line.append(_action_button(token, row, status, lang=lang, b=b, filt=filt, page=page))
        out.append(tuple(line))
    return out


def render_detail(row: GroupLicense, *, now: datetime, tz: str, lang: str, b: Builder, filt: str, page: int,
                  with_actions: bool = False, with_insight: bool = False) -> tuple[str, Buttons]:
    status = effective_status(row, now)
    if status is LicenseStatus.ACTIVE_PERMANENT:
        expires = t("ow_expires_permanent", lang)
    elif status is LicenseStatus.ACTIVE_TEMPORARY and row.expires_at is not None:
        expires = t("ow_expires_at", lang, when=format_display(row.expires_at, tz),
                    remaining=_remaining(row.expires_at - now, lang))
    elif row.expires_at is not None:
        expires = t("ow_expired_at", lang, when=format_display(row.expires_at, tz))
    else:
        expires = t("ow_none", lang)
    text = t("ow_detail", lang,
             title=clean(row.title, 120) or t("title_unknown", lang), group_id=str(row.group_id),
             status=license_label(status, lang),
             protection=t("ow_protection_on" if status in ACTIVE_STATUSES else "ow_protection_off", lang),
             activated=_when(row.activated_at, tz, lang), expires=expires,
             activated_by=str(row.activated_by) if row.activated_by is not None else t("ow_none", lang),
             updated=_when(row.updated_at, tz, lang))
    note = clean(row.note, NOTE_MAX)
    if note:
        text += t("ow_detail_note", lang, note=note)
    rows = _action_rows(row, status, lang=lang, b=b, filt=filt, page=page) if with_actions else []
    if with_insight:     # 5.6: settings + events of this group (read only)
        rows.append(((t("ow_btn_overview", lang), b(codec.OVERVIEW, group_id=row.group_id, filter=filt, page=page)),))
    rows.append(((t("ow_btn_back", lang), b(codec.LIST, filter=filt, page=page)),))
    rows.append(((t("ow_btn_refresh", lang), b(codec.DETAIL, group_id=row.group_id, filter=filt, page=page)),
                 (t("ow_btn_close", lang), b(codec.CLOSE))))
    return text, tuple(rows)


def render_duration_menu(row: GroupLicense, *, now: datetime, lang: str, b: Builder, filt: str,
                         page: int) -> tuple[str, Buttons]:
    status = effective_status(row, now)
    text = t("ow_menu_duration", lang, title=clean(row.title, 120) or t("title_unknown", lang), group_id=str(row.group_id),
             status=license_label(status, lang))
    buttons = [tuple(_action_button(code, row, status, lang=lang, b=b, filt=filt, page=page) for code in pair)
               for pair in zip(act.DURATION_CODES[::2], act.DURATION_CODES[1::2])]
    buttons.append(((t("ow_btn_back", lang), b(codec.DETAIL, group_id=row.group_id, filter=filt, page=page)),
                    (t("ow_btn_close", lang), b(codec.CLOSE))))
    return text, tuple(buttons)


def render_confirm(row: GroupLicense, code: str, *, now: datetime, lang: str, b: Builder, filt: str,
                   page: int) -> tuple[str, Buttons]:
    status = effective_status(row, now)
    text = t("ow_confirm", lang, action=act.name_of(code, lang), title=clean(row.title, 120) or t("title_unknown", lang),
             group_id=str(row.group_id), status=license_label(status, lang), warning=act.warning_of(code, lang))
    return text, (
        ((t("ow_btn_confirm", lang),
          b(codec.DO, action=code, status=act.STATUS_CODE[status], group_id=row.group_id, filter=filt, page=page)),),
        ((t("ow_btn_cancel", lang), b(codec.DETAIL, group_id=row.group_id, filter=filt, page=page)),
         (t("ow_btn_close", lang), b(codec.CLOSE))),
    )


def render_missing(*, lang: str, b: Builder, filt: str, page: int) -> tuple[str, Buttons]:
    return t("ow_detail_missing", lang), (((t("ow_btn_back", lang), b(codec.LIST, filter=filt, page=page)),
                                          (t("ow_btn_close", lang), b(codec.CLOSE))),)
