"""Owner commands for the DEFAULT word list of the content filter (part 9.5), private chat of the primary owner only:

    /defaultword add <word> [<word>..]      add words that every group's filter blocks      اضافة كلمة افتراضية <كلمة>
    /defaultword remove <word> [<word>..]   remove words (also bundled ones)                حذف كلمة افتراضية <كلمة>
    /defaultwords [list]                    show the default words                          عرض الكلمات الافتراضية

(Arabic details) `اضافة|اضف` / `حذف|احذف|ازالة|ازل` + `كلمة` (one word) or `كلمات` (one or more) + `افتراضية`, then the words.
Alef/hamza (`أ إ آ ا`), ta marbuta/ha (`ة ه`) and ya/alef maqsura (`ي ى`) are interchangeable everywhere (`fold_arabic`), so
`إضافة كلمة افتراضيه` is the same command. The list: `عرض الكلمات الافتراضية`, `الكلمات الافتراضية`, `قائمة الكلمات الافتراضية`.

The parser only RECOGNISES text (the word `افتراضية` makes it intentional: ordinary chat never matches); who may use it is decided
by `DefaultWordsCommandService` (exactly the owner, private chat): anybody else gets SILENCE, like the other owner commands."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from ..audit import DEFAULT_WORDS_CHANGED, RESULT_APPLIED, SecurityAudit, make_event, record_safely
from ..content_filter.default_words import DefaultWordsService
from ..errors import PermissionDenied
from ..i18n import t
from ..moderation.arabic import fold_arabic
from ..permissions import Permission

log = logging.getLogger(__name__)

MAX_COMMAND_LEN = 600
MAX_WORDS = 20


def _set(*words: str) -> frozenset[str]:
    return frozenset(fold_arabic(w) for w in words)


_ADD = _set("اضافة", "إضافة", "اضف", "أضف", "اضافه", "ضيف", "اضافت")
_REMOVE = _set("حذف", "احذف", "ازالة", "إزالة", "ازل", "أزل", "ازاله", "مسح", "امسح", "شيل")
_LIST_VERBS = _set("عرض", "اعرض", "قائمة", "قائمه", "اظهار", "اظهر", "ارني")
_ONE = _set("كلمة", "الكلمة", "كلمه")
_MANY = _set("كلمات", "الكلمات")
_DEFAULT = _set("افتراضية", "الافتراضية", "افتراضيه", "افتراضي", "الافتراضي", "افتراضيات", "الافتراضيات", "افتراضيا")


@dataclass(frozen=True, slots=True)
class ParsedDefaultWords:
    action: str                     # add | remove | list | usage
    words: tuple[str, ...] = ()     # raw words (the service normalises them)


def is_default_marker(word: object) -> bool:
    """True for `افتراضية` in any spelling (used by the group parser to leave this vocabulary to the owner command)."""
    return isinstance(word, str) and fold_arabic(word) in _DEFAULT


def parse_default_words_command(text: object, bot_username: str | None = None) -> ParsedDefaultWords | None:
    if not isinstance(text, str):
        return None
    stripped = text.strip()
    if not stripped or len(stripped) > MAX_COMMAND_LEN:
        return None
    words = stripped.split()
    if stripped.startswith("/"):
        name, at, target = words[0][1:].partition("@")
        if name.lower() not in ("defaultword", "defaultwords"):
            return None
        if at and (not bot_username or target.lower() != bot_username.lower()):
            return None  # addressed to another bot (or we do not know our own name)
        sub = words[1].lower() if len(words) > 1 else "list"
        rest = tuple(words[2:])
        if sub == "list":
            return ParsedDefaultWords("list") if not rest else ParsedDefaultWords("usage")
        if sub in ("add", "remove") and 0 < len(rest) <= MAX_WORDS:
            return ParsedDefaultWords(sub, rest)
        return ParsedDefaultWords("usage")
    folded = [fold_arabic(w) for w in words]
    # list: [verb] الكلمات الافتراضية
    body = folded[1:] if folded[0] in _LIST_VERBS else folded
    if len(body) == 2 and body[0] in _MANY and body[1] in _DEFAULT:
        return ParsedDefaultWords("list")
    # add / remove: verb كلمة|كلمات افتراضية <words>
    if len(folded) >= 3 and folded[0] in (_ADD | _REMOVE) and folded[2] in _DEFAULT and folded[1] in (_ONE | _MANY):
        action = "add" if folded[0] in _ADD else "remove"
        rest = tuple(words[3:])
        if not rest or len(rest) > MAX_WORDS or (folded[1] in _ONE and len(rest) != 1):
            return ParsedDefaultWords("usage")
        return ParsedDefaultWords(action, rest)
    return None


def _join(words) -> str:
    return "، ".join(words) if words else "—"


class DefaultWordsCommandService:
    def __init__(self, words: DefaultWordsService, permissions: Any, audit: SecurityAudit | None = None, *, language: str = "ar"):
        self._words, self._perm, self._audit, self._language = words, permissions, audit, language

    async def run(self, parsed: ParsedDefaultWords, *, chat_id: object, chat_type: object, user_id: object,
                  lang: str | None = None):
        """-> `TemplateReply`-shaped `(status, text)` or None (not a private chat / not the owner: no answer)."""
        lang = lang or self._language
        if chat_type != "private" or not isinstance(chat_id, int) or isinstance(chat_id, bool) or chat_id <= 0 or chat_id != user_id:
            return None
        try:
            decision = await self._perm.check_global(user_id, Permission.OWNER_TEMPLATES)
        except PermissionDenied:
            return None
        except Exception:
            log.error("default words owner check failed", exc_info=True)
            return None
        if not decision.allowed:
            return None
        try:
            return await self._run(parsed, user_id, lang)
        except Exception:
            log.error("default words command failed", exc_info=True)
            return DefaultWordsReply("failed", t("dw_failed", lang))

    async def _run(self, parsed: ParsedDefaultWords, owner: int, lang: str) -> "DefaultWordsReply":
        if parsed.action == "usage":
            return DefaultWordsReply("usage", t("dw_usage", lang))
        if parsed.action == "list":
            return DefaultWordsReply("list", self._list_text(lang))
        change = await (self._words.add if parsed.action == "add" else self._words.remove)(owner, parsed.words)
        parts: list[str] = []
        if change.added:
            parts.append(t("dw_added", lang, count=len(change.added), words=_join(change.added)))
        if change.removed:
            parts.append(t("dw_removed", lang, count=len(change.removed), words=_join(change.removed)))
        if change.unchanged:
            parts.append(t("dw_exists" if parsed.action == "add" else "dw_missing", lang, count=len(change.unchanged),
                           words=_join(change.unchanged)))
        if change.invalid:
            parts.append(t("dw_invalid", lang, words=_join(change.invalid)))
        if change.limit_reached:
            parts.append(t("dw_limit", lang))
        if change.added or change.removed:
            await record_safely(self._audit, make_event(
                DEFAULT_WORDS_CHANGED, actor=owner, result=RESULT_APPLIED,
                detail=f"action={parsed.action} count={len(change.added) + len(change.removed)}"))   # never the words themselves
        status = "changed" if (change.added or change.removed) else "unchanged"
        return DefaultWordsReply(status, "\n".join(parts))

    def _list_text(self, lang: str) -> str:
        view = self._words.view()
        sample = list(view.bundled_sample)
        text = ""
        for keep in (len(sample), 60, 30, 10, 0):
            shown = sample[:keep]
            more = len(sample) - len(shown)
            text = t("dw_list", lang, explicit=view.bundled_explicit, insults=view.bundled_insults, hints=view.bundled_hints,
                     added_count=len(view.added), added=_join(view.added), removed_count=len(view.removed),
                     removed=_join(view.removed), sample_count=len(sample),
                     sample=_join(shown) + (f" … (+{more})" if more else ""))
            if len(text) <= 3800:
                break
        return text


@dataclass(frozen=True, slots=True)
class DefaultWordsReply:
    status: str
    text: str
