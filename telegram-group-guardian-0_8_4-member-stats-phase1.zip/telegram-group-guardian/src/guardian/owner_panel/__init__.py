"""Owner panel (phase 5): the private, multi-group control centre of the PRIMARY owner.

5.3 = read only (list, search, filter, details). Changing a license from the panel arrives in 5.4 (through the existing license admin
service, never directly); nothing in this package writes anything.
"""
