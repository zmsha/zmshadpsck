"""Durable idempotency keys (survive restarts/sleep of the free host, unlike the in-memory dedup).

`claim(key)` returns True exactly once per key. Use `update_key(update_id)` for webhook
updates and `operation_key(...)` for repeatable sensitive operations (e.g. one sanction
per update). A claim is "at most once": if processing crashes after the claim the work is
NOT retried (the webhook returns 200 anyway; see HANDOFF.md).
"""
from __future__ import annotations

import re
from datetime import datetime, timedelta
from typing import Protocol

from .time_utils import utcnow

_KEY_RE = re.compile(r"^[A-Za-z0-9:_\-.]{1,200}$")
DEFAULT_RETENTION = timedelta(days=7)


def update_key(update_id: int) -> str:
    return f"update:{int(update_id)}"


def operation_key(scope: str, *parts: object) -> str:
    key = ":".join(["op", scope, *[str(p) for p in parts]])
    if not _KEY_RE.match(key):
        raise ValueError("invalid idempotency key")
    return key


class IdempotencyStore(Protocol):
    async def claim(self, key: str, now: datetime | None = None) -> bool: ...

    async def purge_older_than(self, cutoff: datetime) -> int: ...


def _check(key: str) -> str:
    if not isinstance(key, str) or not _KEY_RE.match(key):
        raise ValueError("invalid idempotency key")
    return key


class InMemoryIdempotency:
    def __init__(self) -> None:
        self._keys: dict[str, datetime] = {}

    async def claim(self, key: str, now: datetime | None = None) -> bool:
        _check(key)
        if key in self._keys:
            return False
        self._keys[key] = now or utcnow()
        return True

    async def purge_older_than(self, cutoff: datetime) -> int:
        old = [k for k, ts in self._keys.items() if ts < cutoff]
        for k in old:
            del self._keys[k]
        return len(old)


class PostgresIdempotency:
    def __init__(self, database) -> None:
        self._db = database

    async def claim(self, key: str, now: datetime | None = None) -> bool:
        _check(key)
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "INSERT INTO idempotency_keys (key, created_at) VALUES ($1, $2) "
                "ON CONFLICT (key) DO NOTHING RETURNING key",
                key,
                now or utcnow(),
            )
        return row is not None

    async def purge_older_than(self, cutoff: datetime) -> int:
        async with self._db.acquire() as conn:
            status = await conn.execute("DELETE FROM idempotency_keys WHERE created_at < $1", cutoff)
        try:  # asyncpg returns e.g. 'DELETE 12'
            return int(str(status).split()[-1])
        except (ValueError, IndexError):
            return 0


class PurgingClaims:
    """Wraps a store and purges expired keys every `every` claims (no background worker needed)."""

    def __init__(self, inner: IdempotencyStore, *, every: int = 500, retention: timedelta = DEFAULT_RETENTION):
        self._inner = inner
        self._every = max(1, every)
        self._retention = retention
        self._count = 0

    async def claim(self, key: str, now: datetime | None = None) -> bool:
        claimed = await self._inner.claim(key, now)
        self._count += 1
        if self._count % self._every == 0:
            try:
                await self._inner.purge_older_than((now or utcnow()) - self._retention)
            except Exception:  # housekeeping only
                pass
        return claimed

    async def purge_older_than(self, cutoff: datetime) -> int:
        return await self._inner.purge_older_than(cutoff)
