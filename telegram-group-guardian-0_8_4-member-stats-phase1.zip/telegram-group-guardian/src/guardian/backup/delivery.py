"""The backup's own delivery path (part 6.8b): the owner's PRIVATE chat only, up to 10 MB, VERIFY-ONLY screening.

Why not `ExportDelivery`: its `screen_file` masks every 40+ character alphanumeric run (that would overwrite the SHA-256 values
inside the backup and break its integrity) and caps files at 1 MB. A backup must arrive BYTE-FOR-BYTE, so this path never
changes a byte: it only REFUSES.

Order (nothing is sent unless every step passes):
 1. the requester is a real user id (positive int) and not one of `forbidden_chat_ids` (the owner group id is always passed)
 2. the file is a `BackupResult`, its name is exactly `guardian-backup-YYYYMMDD-HHMMSS-utc.json`, and it is <= 10 MB
 3. refuse (never clean): a PEM private key, a known secret (also URL-quoted / JSON-escaped), a bot-token / URL-password shape
 4. `parse_document` + `verify_integrity` on THE BYTES THAT WILL BE SENT (format, version, counts, checksums)
 5. a durable one-shot claim `op:backupsend:<requester>:<key>` (at-most-once; a failed send is retried by a new command)
 6. one send, bounded by a timeout, no retry; never raises (cancellation excepted)
 7. audit `backup_delivered|backup_failed`: sizes, row count and the closed code only, never the file or its name's content.

There is no `chat_id` parameter anywhere: the destination is the requester's user id (their private chat).
"""
from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass
from typing import Any, Iterable

from ..audit import BACKUP_DELIVERED, BACKUP_FAILED, RESULT_APPLIED, RESULT_FAILED, SecurityAudit, make_event, record_safely
from ..export.models import PrivateChatUnavailable
from ..idempotency import operation_key
from ..time_utils import utcnow
from .collector import BackupResult, _secret_forms, leaks_secret
from .format import MAX_BACKUP_BYTES, BackupFormatError, parse_document, verify_integrity

log = logging.getLogger(__name__)

SEND_TIMEOUT = 60.0                 # seconds (a 10 MB upload on a free host); a hung call must not hold a webhook handler forever
MAX_CAPTION = 400
_NAME = re.compile(r"guardian-backup-[0-9]{8}-[0-9]{6}-utc\.json")

SENT, PRIVATE_NOT_STARTED, TOO_LARGE, REJECTED, CORRUPT = "sent", "private_not_started", "too_large", "rejected", "corrupt"
DUPLICATE, INVALID, FAILED = "duplicate", "invalid", "failed"
CODES = frozenset({SENT, PRIVATE_NOT_STARTED, TOO_LARGE, REJECTED, CORRUPT, DUPLICATE, INVALID, FAILED})


@dataclass(frozen=True, slots=True)
class BackupDeliveryResult:
    code: str

    @property
    def ok(self) -> bool:
        return self.code == SENT


def _is_user_id(value: object) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value > 0


class BackupDelivery:
    def __init__(self, transport: Any, *, claims: Any, audit: SecurityAudit | None = None, secrets: Iterable[str] = (),
                 forbidden_chat_ids: Iterable[int | None] = (), timeout: float = SEND_TIMEOUT, clock=utcnow) -> None:
        self._transport, self._claims, self._audit = transport, claims, audit
        self._forms = _secret_forms(tuple(secrets))
        self._forbidden = frozenset(i for i in forbidden_chat_ids if isinstance(i, int))
        self._timeout, self._clock = timeout, clock

    @property
    def enabled(self) -> bool:
        return self._transport is not None

    async def deliver(self, requester_id: int, backup: BackupResult, *, key: object, caption: str | None = None) -> BackupDeliveryResult:
        try:
            return await self._deliver(requester_id, backup, key, caption)
        except asyncio.CancelledError:
            raise
        except Exception as exc:        # the contract is "never raises"; the type name only (HTTP errors can carry the bot token)
            log.error("backup delivery crashed (%s)", type(exc).__name__)
            return await self._finish(requester_id, backup, BackupDeliveryResult(FAILED))

    async def _deliver(self, requester_id, backup, key, caption) -> BackupDeliveryResult:
        if (not _is_user_id(requester_id) or requester_id in self._forbidden or self._transport is None
                or not isinstance(backup, BackupResult) or not isinstance(backup.data, (bytes, bytearray))):
            return await self._finish(requester_id, backup, BackupDeliveryResult(INVALID))
        data = bytes(backup.data)
        if not isinstance(backup.name, str) or not _NAME.fullmatch(backup.name):
            return await self._finish(requester_id, backup, BackupDeliveryResult(REJECTED), reason="bad_name")
        if len(data) > MAX_BACKUP_BYTES:
            return await self._finish(requester_id, backup, BackupDeliveryResult(TOO_LARGE))
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            return await self._finish(requester_id, backup, BackupDeliveryResult(CORRUPT), reason="not_text")
        if leaks_secret(text, self._forms):
            return await self._finish(requester_id, backup, BackupDeliveryResult(REJECTED), reason="secret")
        try:
            verify_integrity(parse_document(data))
        except BackupFormatError as exc:
            return await self._finish(requester_id, backup, BackupDeliveryResult(CORRUPT), reason=str(getattr(exc, "code", "bad")))
        try:
            claimed = await self._claims.claim(operation_key("backupsend", requester_id, key), self._clock())
        except Exception as exc:
            log.error("backup claim failed (%s)", type(exc).__name__)
            return await self._finish(requester_id, backup, BackupDeliveryResult(FAILED), reason="claim")
        if not claimed:
            return BackupDeliveryResult(DUPLICATE)         # the same operation again: silent (the first one was audited)
        note = " ".join(caption.split())[:MAX_CAPTION] if isinstance(caption, str) and caption else None
        try:
            await asyncio.wait_for(self._transport.send_document(requester_id, backup.name, data, note), timeout=self._timeout)
        except PrivateChatUnavailable:
            return await self._finish(requester_id, backup, BackupDeliveryResult(PRIVATE_NOT_STARTED))
        except asyncio.TimeoutError:
            return await self._finish(requester_id, backup, BackupDeliveryResult(FAILED), reason="timeout")
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            log.warning("backup send failed (%s)", type(exc).__name__)
            return await self._finish(requester_id, backup, BackupDeliveryResult(FAILED), reason=type(exc).__name__)
        return await self._finish(requester_id, backup, BackupDeliveryResult(SENT))

    async def _finish(self, requester_id, backup, result: BackupDeliveryResult, *, reason: str | None = None) -> BackupDeliveryResult:
        try:
            size = len(backup.data) if isinstance(backup, BackupResult) and isinstance(backup.data, (bytes, bytearray)) else 0
            rows = backup.total_rows if isinstance(backup, BackupResult) else 0
            detail = f"bytes={size} rows={rows} code={result.code}" + (f" why={reason}" if reason else "")
            await record_safely(self._audit, make_event(
                BACKUP_DELIVERED if result.ok else BACKUP_FAILED, actor=requester_id if _is_user_id(requester_id) else None,
                target="backup", result=RESULT_APPLIED if result.ok else RESULT_FAILED, detail=detail, now=self._clock()))
        except Exception:
            log.warning("backup audit failed", exc_info=True)
        return result
