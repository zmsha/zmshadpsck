"""PostgreSQL writer for the restore (part 6.9b). NOT executed against a real PostgreSQL in the build sandbox.

THE ONLY module of the backup package that writes. It implements `restore.RestoreTransaction` over one asyncpg transaction:
statements are built from the static table registry (identifiers are whitelisted; every value is a bound parameter), the file's
(encoded) values are decoded with the registry's column kinds, and every database error is mapped to a closed `RestoreError`
(the driver's message is never kept: it can echo values). Nothing here decides WHAT to restore; `restore.RestoreExecutor` does.
"""
from __future__ import annotations

import json
import logging
import re
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator

from .format import BY_NAME, decode_value
from .postgres_state import read_state_on
from .preview import GLOBAL_REPLACED, GROUPS_TABLE, LOG_TABLE, REPLACED_PER_GROUP, CurrentState
from .restore import ID_CONFLICT_TABLES, ID_TABLES, RestoreError

log = logging.getLogger(__name__)

ADVISORY_LOCK_KEY = 6_090_002                    # "restore"; one restore at a time across the whole database
LOCK_ORDER = tuple(sorted((GROUPS_TABLE, LOG_TABLE, *REPLACED_PER_GROUP, *GLOBAL_REPLACED)))   # one fixed order: no lock cycles
LOCK_TIMEOUT = "10s"
STATEMENT_TIMEOUT = "120s"
CHUNK = 500
_IDENT = re.compile(r"^[a-z][a-z0-9_]*$")
_SEQ = re.compile(r'^[A-Za-z0-9_."]+$')
_ALLOWED = frozenset(LOCK_ORDER)
assert all(_IDENT.match(t) for t in LOCK_ORDER)

_UNIQUE_NAMES = {"UniqueViolationError", "ForeignKeyViolationError", "CheckViolationError", "NotNullViolationError",
                 "IntegrityConstraintViolationError", "ExclusionViolationError", "DataError"}
_LOCK_NAMES = {"LockNotAvailableError", "DeadlockDetectedError"}


def _table(name: str) -> str:
    if name not in _ALLOWED or not _IDENT.match(name):
        raise ValueError("table not allowed")
    return name


def insert_sql(table: str, *, columns: tuple[str, ...] | None = None) -> str:
    """`INSERT INTO t (cols) VALUES ($1, $2::jsonb, ...)` for every registry column (or the given subset)."""
    spec = BY_NAME[_table(table)]
    cols = [c for c in spec.columns if columns is None or c.name in columns]
    marks = [f"${i}::jsonb" if c.kind == "json" else f"${i}" for i, c in enumerate(cols, 1)]
    return f"INSERT INTO {table} ({', '.join(c.name for c in cols)}) VALUES ({', '.join(marks)})"


def _values(table: str, row: dict[str, Any], columns: tuple[str, ...] | None = None) -> list[Any]:
    out = []
    for c in BY_NAME[table].columns:
        if columns is not None and c.name not in columns:
            continue
        value = decode_value(c.kind, row[c.name])
        out.append(json.dumps(value, ensure_ascii=False, separators=(",", ":")) if c.kind == "json" else value)
    return out


LOG_COLUMNS = ("group_id", "actor_telegram_id", "action", "previous_status", "new_status", "expires_at", "reason", "occurred_at")
LOG_INSERT = ("INSERT INTO license_audit_log (group_id, actor_telegram_id, action, previous_status, new_status, expires_at, reason, occurred_at) "
              "SELECT $1::bigint, $2::bigint, $3::text, $4::text, $5::text, $6::timestamptz, $7::text, $8::timestamptz")
LOG_NOT_EXISTS = (" WHERE NOT EXISTS (SELECT 1 FROM license_audit_log WHERE group_id = $1::bigint AND occurred_at = $8::timestamptz "
                  "AND action = $3::text AND new_status = $5::text AND previous_status IS NOT DISTINCT FROM $4::text "
                  "AND actor_telegram_id IS NOT DISTINCT FROM $2::bigint AND expires_at IS NOT DISTINCT FROM $6::timestamptz "
                  "AND reason IS NOT DISTINCT FROM $7::text)")
UPDATE_LICENSE_SQL = ("UPDATE telegram_groups SET license_status = $2, activated_at = $3, expires_at = $4, activated_by = $5, "
                      "status_note = $6 WHERE group_id = $1")
ID_CONFLICT_SQL = "SELECT count(*) FROM {table} WHERE id = ANY($1::bigint[]) AND NOT (group_id = ANY($2::bigint[]))"
KEY_CONFLICT_SQL = ("SELECT count(*) FROM moderation_sanctions WHERE idempotency_key = ANY($1::text[]) "
                    "AND NOT (group_id = ANY($2::bigint[]))")


def affected(status: object) -> int:
    """The row count of an asyncpg command tag (`DELETE 3`, `INSERT 0 1`); 0 when it cannot be read."""
    try:
        return int(str(status).split()[-1])
    except (ValueError, IndexError):
        return 0


def map_error(exc: BaseException) -> RestoreError:
    """A closed code from the driver's exception TYPE; the message (which can carry values) is dropped."""
    if isinstance(exc, RestoreError):
        return exc
    name = type(exc).__name__
    if name in _LOCK_NAMES:
        return RestoreError("lock_timeout")
    if name in _UNIQUE_NAMES:
        return RestoreError("constraint_failed")
    return RestoreError("db_failed")


class _Tx:
    def __init__(self, conn: Any) -> None:
        self._c = conn

    async def lock(self) -> None:
        c = self._c
        await c.execute(f"SET LOCAL lock_timeout = '{LOCK_TIMEOUT}'")
        await c.execute(f"SET LOCAL statement_timeout = '{STATEMENT_TIMEOUT}'")
        await c.fetchval("SELECT pg_advisory_xact_lock($1)", ADVISORY_LOCK_KEY)
        for table in LOCK_ORDER:
            await c.execute(f"LOCK TABLE {_table(table)} IN SHARE ROW EXCLUSIVE MODE")

    async def read_state(self) -> CurrentState:
        return await read_state_on(self._c)

    async def id_conflicts(self, table: str, ids: list[int], group_ids: list[int]) -> bool:
        if table not in ID_CONFLICT_TABLES:
            raise ValueError("table not allowed")
        return int(await self._c.fetchval(ID_CONFLICT_SQL.format(table=_table(table)), ids, group_ids)) > 0

    async def sanction_key_conflicts(self, keys: list[str], group_ids: list[int]) -> bool:
        return int(await self._c.fetchval(KEY_CONFLICT_SQL, keys, group_ids)) > 0

    async def create_groups(self, rows: list[dict[str, Any]]) -> int:
        await self._many(GROUPS_TABLE, rows)
        return len(rows)

    async def update_license(self, rows: list[dict[str, Any]]) -> int:
        cols = ("group_id",) + ("license_status", "activated_at", "expires_at", "activated_by", "status_note")
        n = 0
        for row in rows:
            n += affected(await self._c.execute(UPDATE_LICENSE_SQL, *_values(GROUPS_TABLE, row, cols)))
        return n

    async def delete_for_groups(self, table: str, group_ids: list[int]) -> int:
        if table not in REPLACED_PER_GROUP:
            raise ValueError("table not allowed")
        if not group_ids:
            return 0
        return affected(await self._c.execute(f"DELETE FROM {_table(table)} WHERE group_id = ANY($1::bigint[])", group_ids))

    async def delete_all(self, table: str) -> int:
        if table not in GLOBAL_REPLACED:
            raise ValueError("table not allowed")
        return affected(await self._c.execute(f"DELETE FROM {_table(table)}"))

    async def insert_rows(self, table: str, rows: list[dict[str, Any]]) -> int:
        if table not in REPLACED_PER_GROUP and table not in GLOBAL_REPLACED:
            raise ValueError("table not allowed")
        await self._many(table, rows)
        return len(rows)

    async def _many(self, table: str, rows: list[dict[str, Any]]) -> None:
        sql = insert_sql(table)
        for i in range(0, len(rows), CHUNK):
            await self._c.executemany(sql, [_values(table, r) for r in rows[i:i + CHUNK]])

    async def append_license_log(self, rows: list[dict[str, Any]], *, skip_existing: bool) -> int:
        """APPEND to the licence log (new ids from the sequence). With `skip_existing`, a row identical to one already there is skipped."""
        sql = LOG_INSERT + (LOG_NOT_EXISTS if skip_existing else "")
        n = 0
        for row in rows:
            n += affected(await self._c.execute(sql, *_values(LOG_TABLE, row, LOG_COLUMNS)))
        return n

    async def reset_sequences(self, tables: tuple[str, ...]) -> None:
        """Move each `id` sequence past the restored ids and never backwards (a reused id of a deleted row could mislead old references)."""
        c = self._c
        for table in tables:
            if table not in ID_TABLES:
                raise ValueError("table not allowed")
            seq = await c.fetchval("SELECT pg_get_serial_sequence($1, 'id')", _table_or_templates(table))
            if not isinstance(seq, str) or not _SEQ.match(seq):
                raise RestoreError("db_failed")
            state = (await c.fetch(f"SELECT last_value, is_called FROM {seq}"))[0]
            next_free = int(state["last_value"]) + (1 if state["is_called"] else 0)
            top = int(await c.fetchval(f"SELECT COALESCE(max(id), 0) FROM {_table_or_templates(table)}"))
            await c.fetchval("SELECT setval($1::regclass, $2, false)", seq, max(next_free, top + 1))


def _table_or_templates(name: str) -> str:
    if name not in ID_TABLES or not _IDENT.match(name):
        raise ValueError("table not allowed")
    return name


class PostgresRestoreWriter:
    def __init__(self, database: Any) -> None:
        self._db = database

    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[_Tx]:
        try:
            async with self._db.acquire() as conn:
                async with conn.transaction():
                    yield _Tx(conn)
        except RestoreError:
            raise
        except GeneratorExit:
            raise
        except Exception as exc:
            mapped = map_error(exc)
            log.error("restore transaction rolled back (%s -> %s)", type(exc).__name__, mapped.code)
            raise mapped from None
