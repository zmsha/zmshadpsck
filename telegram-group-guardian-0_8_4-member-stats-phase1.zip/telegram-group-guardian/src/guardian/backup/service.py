"""The owner's backup operation (part 6.8b): preview + single-use code, then build, verify and deliver. No Telegram, no aiogram.

Sequence of `prepare` (the preview; nothing is read from the database):
 1. exactly OWNER_TELEGRAM_ID (`check_global(BACKUP)`; the permission service audits a refusal) -> else None = SILENCE
 2. a single-use code bound to the owner and to the kind `backup` (`PendingActions`, memory only, expires)
 3. audit `backup_requested` (the fact only)

Sequence of `confirm` (fail closed; every refusal before step 6 consumes nothing it should not):
 1. owner check again (the code alone proves nothing)                                  -> else None
 2. durable claim `op:backup:<owner>:<command message id>` (a redelivered update is SILENT)
 3. cool-down since the last run and "one backup at a time" (memory is bounded on the free host) -> reported, code NOT consumed
 4. `PendingActions.take` (wrong owner/kind/unknown/expired -> `unknown_code`, nothing consumed)
 5. `BackupCollector.collect()` (whitelisted tables, one read-only snapshot, complete or refused, secrets refuse)
 6. `BackupDelivery.deliver(owner, file, ...)` (private chat of the owner ONLY, verify-only screening, 10 MB) -> audit
The destination is the owner's user id: there is no chat parameter anywhere and the owner group id is a forbidden destination.
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Callable

from ..audit import BACKUP_FAILED, BACKUP_REQUESTED, RESULT_APPLIED, RESULT_FAILED, make_event, record_safely
from ..idempotency import operation_key
from ..permissions import Permission
from ..time_utils import utcnow
from .collector import BackupError
from .delivery import (CORRUPT, DUPLICATE, FAILED, INVALID, PRIVATE_NOT_STARTED, REJECTED, SENT, TOO_LARGE)

log = logging.getLogger(__name__)

KIND = "backup"
COOLDOWN_SECONDS = 300

# statuses (closed)
PREVIEW, UNKNOWN_CODE, COOLDOWN, BUSY, UNAVAILABLE = "preview", "unknown_code", "cooldown", "busy", "unavailable"
SECRET_FOUND, TOO_MANY = "secret_found", "too_large"


@dataclass(frozen=True, slots=True)
class BackupOutcome:
    status: str
    code: str | None = None          # preview: the confirmation code
    minutes: int = 0                 # preview: how long the code lives
    rows: int = 0                    # sent
    size: int = 0                    # sent (bytes)
    flags: tuple[str, ...] = ()      # sent: tables whose long strings the heuristic redactor would have changed (info only)
    wait_seconds: int = 0            # cooldown


class BackupService:
    def __init__(self, *, collector: Any, delivery: Any, pending: Any, permissions: Any, claims: Any, audit: Any = None,
                 clock: Callable[[], datetime] = utcnow, cooldown: int = COOLDOWN_SECONDS) -> None:
        self._collector, self._delivery, self._pending, self._perm = collector, delivery, pending, permissions
        self._claims, self._audit, self._clock, self._cooldown = claims, audit, clock, int(cooldown)
        self._lock = asyncio.Lock()
        self._last: datetime | None = None

    @property
    def available(self) -> bool:
        return self._collector is not None and self._delivery is not None and getattr(self._delivery, "enabled", True)

    async def is_owner(self, user_id: object) -> bool:
        try:
            return bool((await self._perm.check_global(user_id, Permission.BACKUP)).allowed)
        except Exception:
            log.error("backup owner check failed", exc_info=True)
            return False

    async def prepare(self, owner_id: object) -> BackupOutcome | None:
        if not await self.is_owner(owner_id):
            return None
        if not self.available:
            return BackupOutcome(UNAVAILABLE)
        code = self._pending.create(owner_id, KIND, {"requested": True})
        await record_safely(self._audit, make_event(BACKUP_REQUESTED, actor=owner_id, target="backup", result=RESULT_APPLIED,
                                                    detail="code_issued", now=self._clock()))
        return BackupOutcome(PREVIEW, code=code, minutes=self._pending.ttl_minutes)

    async def confirm(self, owner_id: object, code: object, message_id: object) -> BackupOutcome | None:
        if not await self.is_owner(owner_id):
            return None
        if not self.available:
            return BackupOutcome(UNAVAILABLE)
        if not isinstance(message_id, int) or isinstance(message_id, bool) or message_id <= 0:
            return BackupOutcome(UNAVAILABLE)
        try:
            claimed = await self._claims.claim(operation_key("backup", owner_id, message_id))
        except Exception:
            log.error("backup claim failed", exc_info=True)
            return BackupOutcome(UNAVAILABLE)
        if not claimed:
            return None                                          # a redelivered update: silent
        now = self._clock()
        if self._lock.locked():
            return BackupOutcome(BUSY)
        if self._last is not None and now < self._last + timedelta(seconds=self._cooldown):
            wait = int((self._last + timedelta(seconds=self._cooldown) - now).total_seconds()) + 1
            return BackupOutcome(COOLDOWN, wait_seconds=wait)
        async with self._lock:
            if self._pending.take(owner_id, KIND, code) is None:
                return BackupOutcome(UNKNOWN_CODE)
            self._last = now
            return await self._run(owner_id, message_id)

    async def _run(self, owner_id: int, message_id: int) -> BackupOutcome:
        try:
            result = await self._collector.collect()
        except BackupError as exc:
            await self._failed(owner_id, exc.code, exc.detail if exc.code == SECRET_FOUND else None)
            return BackupOutcome(exc.code if exc.code in (SECRET_FOUND, TOO_MANY) else FAILED)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            await self._failed(owner_id, "collect_crashed", type(exc).__name__)
            return BackupOutcome(FAILED)
        outcome = await self._delivery.deliver(owner_id, result, key=message_id, caption=None)
        code = getattr(outcome, "code", None)
        if code == SENT:
            return BackupOutcome(SENT, rows=result.total_rows, size=result.size, flags=tuple(result.screen_flags))
        if code in (PRIVATE_NOT_STARTED, TOO_LARGE, REJECTED, CORRUPT, FAILED):
            return BackupOutcome(code)
        if code == DUPLICATE:
            return BackupOutcome(DUPLICATE)
        return BackupOutcome(FAILED)                              # invalid / anything unknown: fail closed

    async def _failed(self, owner_id: int, code: str, why: str | None) -> None:
        detail = f"code={code}" + (f" why={why}" if why else "")
        await record_safely(self._audit, make_event(BACKUP_FAILED, actor=owner_id, target="backup", result=RESULT_FAILED,
                                                    detail=detail, now=self._clock()))
