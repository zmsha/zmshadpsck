"""The owner's restore operations: `preview` (part 6.9a, writes nothing) and `confirm` (part 6.9b, ONE transaction).

`preview` issues two single-use codes bound to the owner, to the file's FINGERPRINT and to the signature of the preview shown:
code A (restore the data) and code B (also apply the licence state: a separate, explicit confirmation). `confirm` needs the same
file again plus code A (and code B for `with_license`); the executor re-reads the state inside its locks and refuses if it no
longer matches what the owner approved. Sequence of `preview` (fail closed):
 1. exactly OWNER_TELEGRAM_ID (`check_global(RESTORE)`; a refusal is audited by the permission service) -> else None = SILENCE
 2. a document is attached (else the usage text); its declared size is within the 10 MB cap (checked BEFORE downloading)
 3. durable claim `op:restorepreview:<owner>:<command message id>` (a redelivered update is SILENT)
 4. one preview at a time and a short cool-down (the file and its parsed form live in memory on the free host)
 5. download (bounded) -> `validate_backup` (CPU work off the event loop) -> read the CURRENT state (counts only) -> `build_preview`
 6. audit `restore_previewed` (counts and the fingerprint) or `restore_rejected` (closed code + table/rule name)
The file's bytes are never logged, audited or echoed; an error names a table or rule, never a value.
"""
from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Callable, Iterable

from ..audit import (RESTORE_APPLIED, RESTORE_FAILED, RESTORE_PREVIEWED, RESTORE_REJECTED, RESTORE_STARTED, RESULT_APPLIED,
                     RESULT_FAILED, make_event, record_safely)
from ..idempotency import operation_key
from ..permissions import Permission
from ..time_utils import utcnow
from .collector import schema_state
from .format import MAX_BACKUP_BYTES
from .preview import RestorePreview, build_preview
from .restore import RestoreError, RestoreResult, preview_signature
from .validate import RestoreValidationError, validate_backup

log = logging.getLogger(__name__)

COOLDOWN_SECONDS = 20
CONFIRM_COOLDOWN_SECONDS = 120
KIND_RESTORE, KIND_LICENSE = "restore", "restore_license"
DOWNLOAD_TIMEOUT = 60.0
STATE_TIMEOUT = 30.0

# statuses (closed)
PREVIEWED, NO_FILE, TOO_LARGE, DOWNLOAD_FAILED, INVALID = "previewed", "no_file", "too_large", "download_failed", "invalid"
BUSY, COOLDOWN, UNAVAILABLE, FAILED = "busy", "cooldown", "unavailable", "failed"
APPLIED, UNKNOWN_CODE, WRONG_FILE, ROLLED_BACK = "applied", "unknown_code", "wrong_file", "rolled_back"

_SAFE_DETAIL = re.compile(r"[a-z][a-z0-9_.]{0,80}|[0-9]{1,4}>[0-9]{1,4}")


def safe_detail(detail: object) -> str:
    """A table / column / rule name from OUR code, or nothing (a name taken from the file itself is never shown)."""
    return detail if isinstance(detail, str) and _SAFE_DETAIL.fullmatch(detail) is not None else ""


@dataclass(frozen=True, slots=True)
class DocumentRef:
    file_id: str
    size: int | None = None            # the size Telegram reports (may be missing)


@dataclass(frozen=True, slots=True)
class RestoreOutcome:
    status: str
    preview: RestorePreview | None = None
    code: str = ""                     # invalid / rolled_back: the closed code; previewed: confirmation code A
    where: str = ""                    # invalid / rolled_back: a table/column/rule name (safe)
    wait_seconds: int = 0              # cooldown
    license_code: str = ""             # previewed: confirmation code B (applies the licence state; separate)
    minutes: int = 0                   # previewed: how long the codes live
    result: RestoreResult | None = None   # applied


class RestorePreviewService:
    def __init__(self, *, downloader: Any, state_reader: Any, permissions: Any, claims: Any, audit: Any = None,
                 secrets: Iterable[str] = (), schema_version: int | None = None, clock: Callable[[], datetime] = utcnow,
                 cooldown: int = COOLDOWN_SECONDS, max_bytes: int = MAX_BACKUP_BYTES, pending: Any = None, executor: Any = None,
                 confirm_cooldown: int = CONFIRM_COOLDOWN_SECONDS) -> None:
        self._downloader, self._reader, self._perm, self._claims, self._audit = downloader, state_reader, permissions, claims, audit
        self._secrets = tuple(secrets)
        self._schema = int(schema_version) if schema_version is not None else schema_state()[0]
        self._clock, self._cooldown, self._max = clock, int(cooldown), int(max_bytes)
        self._pending, self._executor, self._confirm_cooldown = pending, executor, int(confirm_cooldown)
        self._lock = asyncio.Lock()
        self._last: datetime | None = None
        self._last_confirm: datetime | None = None

    @property
    def available(self) -> bool:
        return self._downloader is not None and self._reader is not None

    @property
    def can_confirm(self) -> bool:
        return self.available and self._pending is not None and self._executor is not None

    async def is_owner(self, user_id: object) -> bool:
        try:
            return bool((await self._perm.check_global(user_id, Permission.RESTORE)).allowed)
        except Exception:
            log.error("restore owner check failed", exc_info=True)
            return False

    # ------------------------------------------------------------------------------------------------ shared gate
    async def _gate(self, owner_id: object, document: DocumentRef | None, message_id: object, op: str) -> RestoreOutcome | None | bool:
        """True = go on; an outcome / None = answer that (None = silence). Owner, availability, file present, size, durable claim."""
        if not await self.is_owner(owner_id):
            return None
        if not self.available or (op == "restore" and not self.can_confirm):
            return RestoreOutcome(UNAVAILABLE)
        if document is None:
            return RestoreOutcome(NO_FILE)
        if not isinstance(message_id, int) or isinstance(message_id, bool) or message_id <= 0 \
                or not isinstance(document.file_id, str) or not document.file_id:
            return RestoreOutcome(UNAVAILABLE)
        if document.size is not None and (not isinstance(document.size, int) or document.size > self._max):
            await self._rejected(owner_id, "too_large_file", "")
            return RestoreOutcome(TOO_LARGE)
        try:
            claimed = await self._claims.claim(operation_key("restorepreview" if op == "preview" else "restore", owner_id, message_id))
        except Exception:
            log.error("restore claim failed", exc_info=True)
            return RestoreOutcome(UNAVAILABLE)
        return True if claimed else None                         # a redelivered update: silent

    def _wait(self, last: datetime | None, seconds: int, now: datetime) -> RestoreOutcome | None:
        if self._lock.locked():
            return RestoreOutcome(BUSY)
        if last is not None and now < last + timedelta(seconds=seconds):
            return RestoreOutcome(COOLDOWN, wait_seconds=int((last + timedelta(seconds=seconds) - now).total_seconds()) + 1)
        return None

    # ------------------------------------------------------------------------------------------------ preview (6.9a)
    async def preview(self, owner_id: object, document: DocumentRef | None, message_id: object) -> RestoreOutcome | None:
        gate = await self._gate(owner_id, document, message_id, "preview")
        if gate is not True:
            return gate
        now = self._clock()
        busy = self._wait(self._last, self._cooldown, now)
        if busy is not None:
            return busy
        async with self._lock:
            self._last = now
            return await self._run_preview(owner_id, document)

    async def _load(self, owner_id: int, document: DocumentRef) -> Any:
        """The validated backup, or the `RestoreOutcome` that refuses the file (audited). Never raises except cancellation."""
        try:
            data = await asyncio.wait_for(self._downloader.download(document.file_id, self._max), timeout=DOWNLOAD_TIMEOUT)
        except asyncio.CancelledError:
            raise
        except Exception as exc:                                 # the type name only (an HTTP error can carry the bot token)
            log.warning("restore download failed (%s)", type(exc).__name__)
            await self._rejected(owner_id, "download_failed", type(exc).__name__.lower())
            return RestoreOutcome(DOWNLOAD_FAILED)
        if data is None:
            await self._rejected(owner_id, "too_large_file", "")
            return RestoreOutcome(TOO_LARGE)
        try:
            return await asyncio.to_thread(validate_backup, data, current_schema_version=self._schema, secrets=self._secrets,
                                           max_bytes=self._max, now=self._clock())
        except RestoreValidationError as exc:
            where = safe_detail(exc.detail)
            await self._rejected(owner_id, exc.code, where)
            return RestoreOutcome(INVALID, code=exc.code, where=where)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            log.error("restore validation crashed (%s)", type(exc).__name__)
            await self._rejected(owner_id, "validation_crashed", "")
            return RestoreOutcome(FAILED)
        finally:
            del data

    async def _run_preview(self, owner_id: int, document: DocumentRef) -> RestoreOutcome:
        backup = await self._load(owner_id, document)
        if isinstance(backup, RestoreOutcome):
            return backup
        try:
            current = await asyncio.wait_for(self._reader.read(), timeout=STATE_TIMEOUT)
            preview = build_preview(backup, current, self._clock())
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            log.error("restore state read failed (%s)", type(exc).__name__)
            await self._rejected(owner_id, "state_failed", "")
            return RestoreOutcome(FAILED)
        code = license_code = ""
        minutes = 0
        if self._pending is not None:                            # single-use codes: memory only, expire, bound to this file AND this preview
            payload = {"fingerprint": preview.fingerprint, "signature": preview_signature(preview)}
            code = self._pending.create(owner_id, KIND_RESTORE, dict(payload))
            license_code = self._pending.create(owner_id, KIND_LICENSE, dict(payload))
            minutes = self._pending.ttl_minutes
        detail = (f"fp={preview.fingerprint} rows={preview.backup_rows} groups={len(preview.groups)} "
                  f"removed={preview.removed_total} added={preview.added_total}")
        await record_safely(self._audit, make_event(RESTORE_PREVIEWED, actor=owner_id, target="restore", result=RESULT_APPLIED,
                                                    detail=detail, now=self._clock()))
        return RestoreOutcome(PREVIEWED, preview=preview, code=code, license_code=license_code, minutes=minutes)

    # ------------------------------------------------------------------------------------------------ confirm (6.9b)
    async def confirm(self, owner_id: object, document: DocumentRef | None, message_id: object, code: object,
                      license_code: object = None) -> RestoreOutcome | None:
        gate = await self._gate(owner_id, document, message_id, "restore")
        if gate is not True:
            return gate
        now = self._clock()
        busy = self._wait(self._last_confirm, self._confirm_cooldown, now)
        if busy is not None:
            return busy
        async with self._lock:
            return await self._run_confirm(owner_id, document, code, license_code)

    async def _run_confirm(self, owner_id: int, document: DocumentRef, code: object, license_code: object) -> RestoreOutcome:
        # Both codes are only LOOKED AT until the file is proven to be the one approved; a wrong file consumes nothing.
        want_license = license_code is not None
        approved = self._pending.peek(owner_id, KIND_RESTORE, code)
        if approved is None or (want_license and self._pending.peek(owner_id, KIND_LICENSE, license_code) is None):
            return RestoreOutcome(UNKNOWN_CODE)
        backup = await self._load(owner_id, document)
        if isinstance(backup, RestoreOutcome):
            return backup
        licence_payload = self._pending.peek(owner_id, KIND_LICENSE, license_code) if want_license else approved
        if not isinstance(approved, dict) or approved.get("fingerprint") != backup.fingerprint \
                or not isinstance(licence_payload, dict) or licence_payload.get("fingerprint") != backup.fingerprint \
                or licence_payload.get("signature") != approved.get("signature"):
            await self._rejected(owner_id, "wrong_file", "")
            return RestoreOutcome(WRONG_FILE)
        approved = self._pending.take(owner_id, KIND_RESTORE, code)       # single use: consumed from here on, whatever happens next
        if want_license:
            self._pending.take(owner_id, KIND_LICENSE, license_code)
        if not isinstance(approved, dict):
            return RestoreOutcome(UNKNOWN_CODE)
        self._last_confirm = self._clock()                               # the cool-down starts when a restore really starts, not on a typo
        await record_safely(self._audit, make_event(RESTORE_STARTED, actor=owner_id, target="restore", result=RESULT_APPLIED,
                                                    detail=f"fp={backup.fingerprint} with_license={int(want_license)}", now=self._clock()))
        try:
            result = await self._executor.execute(backup, expected_signature=str(approved.get("signature")), owner_id=owner_id,
                                                  with_license=want_license)
        except asyncio.CancelledError:
            raise
        except RestoreError as exc:
            where = safe_detail(exc.detail)
            await self._restore_failed(owner_id, exc.code, where)
            return RestoreOutcome(ROLLED_BACK, code=exc.code, where=where)
        except Exception as exc:
            log.error("restore crashed (%s)", type(exc).__name__)
            await self._restore_failed(owner_id, "crashed", "")
            return RestoreOutcome(ROLLED_BACK, code="db_failed")
        detail = (f"fp={result.fingerprint} with_license={int(result.with_license)} replaced={result.groups_replaced} "
                  f"added={result.groups_added} removed={result.rows_removed} inserted={result.rows_inserted} "
                  f"log={result.log_appended} licensed={result.license_updated}")
        await record_safely(self._audit, make_event(RESTORE_APPLIED, actor=owner_id, target="restore", result=RESULT_APPLIED,
                                                    detail=detail, now=self._clock()))
        return RestoreOutcome(APPLIED, result=result)

    async def _restore_failed(self, owner_id: int, code: str, where: str) -> None:
        detail = f"code={code}" + (f" where={where}" if where else "") + " rolled_back=1"
        await record_safely(self._audit, make_event(RESTORE_FAILED, actor=owner_id, target="restore", result=RESULT_FAILED,
                                                    detail=detail, now=self._clock()))

    async def _rejected(self, owner_id: int, code: str, where: str) -> None:
        detail = f"code={code}" + (f" where={where}" if where else "")
        await record_safely(self._audit, make_event(RESTORE_REJECTED, actor=owner_id, target="restore", result=RESULT_FAILED,
                                                    detail=detail, now=self._clock()))
