"""Backup file format, version 1 (phase 6.8a).

ONE JSON document, compact and canonical (UTF-8, sorted keys, no NaN):

    {"manifest": {format, format_version, schema_version, schema_name, app_version, created_at, tables, total_rows,
                  tables_digest, excluded},
     "tables":   {"<table>": [ {<column>: <value>, ...}, ... ], ...}}

* `manifest.tables[<table>] = {"rows": N, "sha256": <hex>}`: the SHA-256 of the canonical JSON text of that table's row list.
* `manifest.tables_digest`: SHA-256 over the lines `name:rows:sha256` (tables sorted by name), so a dropped or added table is
  detected too. There is no encryption in 6.8 (checksums only): the checksums detect accidents, not a deliberate edit.
* Values: integers, booleans, text, JSON (objects/arrays/scalars) and timestamps as UTC ISO-8601 `...Z` strings with microseconds.
* Which tables and columns exist is decided ONLY by `TABLES` below (explicit column lists, never `SELECT *`), so a secret or a
  transient table can never enter a backup by accident; `EXCLUDED_TABLES` names what is left out on purpose and why.
"""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

FORMAT_NAME = "guardian-backup"
FORMAT_VERSION = 1
MAX_BACKUP_BYTES = 10 * 1024 * 1024  # decision 3 of the plan: 10 MB, no truncation (a partial backup is refused instead)

ERROR_CODES = ("too_large", "secret_found", "read_failed", "unavailable", "bad_value")
INTEGRITY_CODES = ("too_large", "bad_json", "bad_shape", "bad_format", "bad_version", "missing_table", "unknown_table",
                   "row_count_mismatch", "checksum_mismatch", "digest_mismatch")

_IDENT = re.compile(r"^[a-z][a-z0-9_]{0,62}$")
INT, TEXT, BOOL, TS, JSON = "int", "text", "bool", "ts", "json"
KINDS = (INT, TEXT, BOOL, TS, JSON)


class BackupError(Exception):
    """A backup could not be built. `code` is a closed word; the message names at most a table/column, never a value."""

    def __init__(self, code: str, detail: str = "") -> None:
        if code not in ERROR_CODES:
            raise ValueError(f"unknown backup error code: {code!r}")
        super().__init__(f"{code}: {detail}" if detail else code)
        self.code = code
        self.detail = detail


class BackupFormatError(Exception):
    """A backup file failed the structural/integrity check (`INTEGRITY_CODES`)."""

    def __init__(self, code: str, detail: str = "") -> None:
        if code not in INTEGRITY_CODES:
            raise ValueError(f"unknown integrity code: {code!r}")
        super().__init__(f"{code}: {detail}" if detail else code)
        self.code = code
        self.detail = detail


@dataclass(frozen=True, slots=True)
class Column:
    name: str
    kind: str

    def __post_init__(self) -> None:
        if not _IDENT.match(self.name) or self.kind not in KINDS:
            raise ValueError(f"bad column spec: {self.name!r}/{self.kind!r}")


@dataclass(frozen=True, slots=True)
class TableSpec:
    name: str
    columns: tuple[Column, ...]
    key: tuple[str, ...]  # the primary key: rows are read in this order, page by page

    def __post_init__(self) -> None:
        names = [c.name for c in self.columns]
        if not _IDENT.match(self.name) or not names or len(set(names)) != len(names):
            raise ValueError(f"bad table spec: {self.name!r}")
        if not self.key or any(k not in names for k in self.key):
            raise ValueError(f"bad key for {self.name!r}")

    @property
    def column_names(self) -> tuple[str, ...]:
        return tuple(c.name for c in self.columns)


def _t(name: str, cols: str, key: str) -> TableSpec:
    columns = tuple(Column(n, k) for n, k in (item.split(":") for item in cols.split()))
    return TableSpec(name, columns, tuple(key.split()))


# Parents first (the order a restore will need). Column kinds mirror the SQL types; a test compares them to the migrations.
TABLES: tuple[TableSpec, ...] = (
    _t("telegram_groups",
       "group_id:int title:text license_status:text activated_at:ts expires_at:ts activated_by:int status_note:text "
       "created_at:ts updated_at:ts", "group_id"),
    _t("license_audit_log",
       "id:int group_id:int actor_telegram_id:int action:text previous_status:text new_status:text expires_at:ts "
       "reason:text occurred_at:ts", "id"),
    _t("group_settings", "group_id:int language:text settings:json updated_at:ts updated_by:int", "group_id"),
    _t("group_delegations",
       "id:int group_id:int user_id:int role:text granted_by:int granted_at:ts revoked_at:ts revoked_by:int", "id"),
    _t("group_trusted_users", "group_id:int user_id:int added_by:int added_at:ts note:text", "group_id user_id"),
    _t("group_trusted_bots", "group_id:int bot_id:int added_by:int added_at:ts note:text", "group_id bot_id"),
    _t("moderation_warnings",
       "id:int group_id:int user_id:int issued_by:int reason:text created_at:ts expires_at:ts revoked_at:ts "
       "revoked_by:int idempotency_key:text", "id"),
    _t("moderation_sanctions",
       "id:int group_id:int user_id:int kind:text issued_by:int reason:text created_at:ts expires_at:ts lifted_at:ts "
       "lifted_by:int idempotency_key:text violation:text", "id"),
    _t("group_reports",
       "id:int group_id:int reporter_id:int target_user_id:int message_id:int reason:text report_type:text priority:text "
       "status:text assigned_to:int outcome:text handled_by:int handled_at:ts created_at:ts updated_at:ts trace_id:text "
       "idempotency_key:text", "id"),
    _t("settings_templates",
       "id:int name:text name_key:text settings:json created_by:int created_at:ts updated_at:ts source_group_id:int", "id"),
    _t("global_default_settings", "singleton:bool settings:json version:int updated_by:int updated_at:ts", "singleton"),
)
TABLE_NAMES = tuple(t.name for t in TABLES)
BY_NAME = {t.name: t for t in TABLES}

# Left out ON PURPOSE (every table the migrations create is either in TABLES or here; a test enforces it).
EXCLUDED_TABLES: dict[str, str] = {
    "security_audit_log": "exported separately (/export audit); append-only and purged by retention",
    "idempotency_keys": "transient operation leases",
    "member_verifications": "transient challenges (they hold the expected answer)",
    "daily_group_counters": "derived statistics, rebuilt by activity",
    "member_activity_stats": "permanent per-member statistics (migration 0013): NOT yet part of the backup format because adding a table raises `format_version`; a restore never touches this table, so the numbers survive it. Planned for a later part",
    "content_violations": "operational escalation counters of the content filter (ids and closed words only; they age out after 30 days)",
    "content_reviews": "transient admin review cases of the content filter (ids only); open cases expire with their 24 h mute",
    "content_default_words": "the owner's additions/removals of default filter words (part 9.5; closed-vocabulary words only): re-run `اضافة كلمة افتراضية` / `حذف كلمة افتراضية` after a rebuild; a restore never touches this table",
    "gemini_key_state": "operational quota state of the Gemini keys (a fingerprint, never a key); rebuilt by the first call",
    "report_schedule": "operational delivery state (periodic reports are switched on again with /reports schedule)",
    "global_settings": "generic key/value store that nothing reads or writes; its content is unknown, so it is not copied",
}
NOT_DATA_TABLES = frozenset({"schema_migrations"})  # the migration runner's own bookkeeping


# ------------------------------------------------------------------------------------------------ canonical JSON
def canonical(value: Any) -> str:
    """Compact, key-sorted JSON text (NaN/Infinity refused); the one serialisation every checksum is computed over."""
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def sha256_hex(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def rows_text(row_texts: list[str]) -> str:
    """The canonical text of a row list, built from already-serialised rows (identical to `canonical(list_of_rows)`)."""
    return "[" + ",".join(row_texts) + "]"


def tables_digest(tables: dict[str, dict[str, Any]]) -> str:
    return sha256_hex("\n".join(f"{name}:{tables[name]['rows']}:{tables[name]['sha256']}" for name in sorted(tables)))


# ------------------------------------------------------------------------------------------------ values
def encode_timestamp(value: datetime) -> str:
    if value.tzinfo is None or value.utcoffset() is None:
        raise ValueError("naive timestamp")
    return value.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


_TS_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{6}Z$")


def decode_timestamp(text: str) -> datetime:
    if not isinstance(text, str) or not _TS_RE.match(text):
        raise ValueError("bad timestamp")
    return datetime.strptime(text, "%Y-%m-%dT%H:%M:%S.%fZ").replace(tzinfo=timezone.utc)


def encode_value(kind: str, value: Any) -> Any:
    """NULL stays None. Strict: a value of the wrong type raises ValueError (the caller turns it into `bad_value`)."""
    if value is None:
        return None
    if kind == INT:
        if type(value) is not int:
            raise ValueError("not an integer")
        return value
    if kind == BOOL:
        if type(value) is not bool:
            raise ValueError("not a boolean")
        return value
    if kind == TEXT:
        if not isinstance(value, str):
            raise ValueError("not text")
        return value
    if kind == TS:
        if not isinstance(value, datetime):
            raise ValueError("not a timestamp")
        return encode_timestamp(value)
    if kind == JSON:
        try:
            canonical(value)  # NaN / Infinity / non-serialisable values
        except (TypeError, ValueError, RecursionError):
            raise ValueError("not JSON") from None
        return value
    raise ValueError("unknown kind")


def decode_value(kind: str, value: Any) -> Any:
    """The inverse of `encode_value` (for the restore, 6.9): timestamps become aware UTC datetimes."""
    if value is None:
        return None
    if kind == TS:
        return decode_timestamp(value)
    return encode_value(kind, value)


def encode_row(spec: TableSpec, raw: Any) -> dict[str, Any]:
    """Exactly the spec's columns, no more (an extra column in `raw` is ignored, a missing one is an error)."""
    out: dict[str, Any] = {}
    for column in spec.columns:
        try:
            out[column.name] = encode_value(column.kind, raw[column.name])
        except (KeyError, ValueError, TypeError):
            raise BackupError("bad_value", f"{spec.name}.{column.name}") from None
    return out


# ------------------------------------------------------------------------------------------------ the document
def build_document_text(manifest: dict[str, Any], table_texts: dict[str, str]) -> str:
    """`{"manifest": ..., "tables": {...}}` as canonical text, tables sorted by name (== `canonical` of the parsed document)."""
    body = ",".join(f"{canonical(name)}:{table_texts[name]}" for name in sorted(table_texts))
    return '{"manifest":' + canonical(manifest) + ',"tables":{' + body + "}}"


def parse_document(data: object, max_bytes: int = MAX_BACKUP_BYTES) -> dict[str, Any]:
    """Bytes -> the document dict; structural checks only (see `verify_integrity` for the checksums). Never reads a file."""
    if not isinstance(data, (bytes, bytearray)):
        raise BackupFormatError("bad_json")
    if len(data) > max_bytes:
        raise BackupFormatError("too_large")
    try:
        doc = json.loads(bytes(data).decode("utf-8"), parse_constant=_refuse_constant)
    except (UnicodeDecodeError, ValueError, RecursionError):
        raise BackupFormatError("bad_json") from None
    if not isinstance(doc, dict) or set(doc) != {"manifest", "tables"} or not isinstance(doc["manifest"], dict) \
            or not isinstance(doc["tables"], dict):
        raise BackupFormatError("bad_shape")
    return doc


def _refuse_constant(name: str) -> Any:
    raise ValueError(name)


def verify_integrity(doc: dict[str, Any]) -> dict[str, Any]:
    """Format name/version, table list, row counts, per-table SHA-256 and the tables digest. Returns the manifest.

    It does NOT judge the content (schema version against the running one, column names, secrets): that is 6.9a's validation.
    """
    manifest = doc["manifest"]
    if manifest.get("format") != FORMAT_NAME:
        raise BackupFormatError("bad_format")
    if type(manifest.get("format_version")) is not int or manifest["format_version"] != FORMAT_VERSION:
        raise BackupFormatError("bad_version")
    listed, tables = manifest.get("tables"), doc["tables"]
    if not isinstance(listed, dict):
        raise BackupFormatError("bad_shape")
    if set(listed) != set(tables):
        raise BackupFormatError("missing_table", sorted(set(listed) ^ set(tables))[0])
    for name in sorted(tables):
        if name not in BY_NAME:
            raise BackupFormatError("unknown_table", name)
    for name in sorted(tables):
        rows, entry = tables[name], listed[name]
        if not isinstance(rows, list) or not isinstance(entry, dict) or not all(isinstance(r, dict) for r in rows):
            raise BackupFormatError("bad_shape", name)
        if type(entry.get("rows")) is not int or entry["rows"] != len(rows):
            raise BackupFormatError("row_count_mismatch", name)
        try:
            text = canonical(rows)
        except ValueError:
            raise BackupFormatError("bad_shape", name) from None
        if entry.get("sha256") != sha256_hex(text):
            raise BackupFormatError("checksum_mismatch", name)
    if manifest.get("tables_digest") != tables_digest(listed):
        raise BackupFormatError("digest_mismatch")
    return manifest
