"""`/restore` in the owner's PRIVATE chat (parts 6.9a + 6.9b): parsing, the document reference and the localized texts.

    /restore                                    PREVIEW (the backup .json as a document with this caption, or a reply to it)
    /restore confirm <A>                        RESTORE the data of that same file (re-send the file with this caption)
    /restore confirm <A> with_license <B>       ... and ALSO apply the file's licence state (a separate code B)
    استعادة | استعادة نسخة [احتياطية]  |  ... تأكيد <A> [ترخيص <B>]

The parser only RECOGNISES text (a private chat, a real sender); who may use it is decided by `RestorePreviewService`: anybody
but exactly OWNER_TELEGRAM_ID gets SILENCE. There is no group form and no menu entry (a private owner command like `/backup`).
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import Any

from ..i18n import t
from ..moderation.arabic import fold_arabic
from ..owner_templates.pending import ALPHABET, CODE_LEN
from . import restore_service as svc
from .preview import APPEND_ONLY, CREATE_MISSING, GroupLine, RestorePreview

log = logging.getLogger(__name__)

MAX_COMMAND_LEN = 100
MAX_GROUP_LINES = 8
_AR_RESTORE = fold_arabic("استعادة")
_AR_COPY = fold_arabic("نسخة")
_AR_BACKUP = frozenset({fold_arabic("احتياطية"), fold_arabic("احتياطي")})
_AR_CONFIRM = frozenset({fold_arabic("تأكيد")})
_AR_LICENSE = frozenset({fold_arabic("ترخيص"), fold_arabic("الترخيص")})
_CODE = re.compile(rf"[{ALPHABET}]{{{CODE_LEN}}}")

_INVALID_KEYS = {
    "too_large": "rs_bad_file", "bad_json": "rs_bad_file", "bad_shape": "rs_bad_file", "bad_format": "rs_bad_file",
    "bad_version": "rs_bad_file",
    "missing_table": "rs_corrupt", "unknown_table": "rs_corrupt", "row_count_mismatch": "rs_corrupt",
    "checksum_mismatch": "rs_corrupt", "digest_mismatch": "rs_corrupt",
    "schema_too_new": "rs_schema_new", "schema_too_old": "rs_schema_old", "incomplete": "rs_incomplete",
    "bad_manifest": "rs_bad_content", "bad_columns": "rs_bad_content", "bad_value": "rs_bad_content", "bad_rule": "rs_bad_content",
    "duplicate_key": "rs_bad_content", "orphan_row": "rs_bad_content", "secret_found": "rs_secret",
}


@dataclass(frozen=True, slots=True)
class ParsedRestoreCommand:
    action: str                 # preview | confirm | usage
    code: str | None = None             # confirm: code A
    license_code: str | None = None     # confirm: code B (with_license)


def _confirm_args(rest: list[str], license_words: frozenset[str], fold: bool) -> ParsedRestoreCommand:
    """`<A>` or `<A> with_license <B>` (the words already isolated); anything else is the usage text."""
    norm = (lambda w: fold_arabic(w)) if fold else (lambda w: w.lower())
    if len(rest) == 1 and _CODE.fullmatch(rest[0].upper()):
        return ParsedRestoreCommand("confirm", rest[0].upper())
    if len(rest) == 3 and norm(rest[1]) in license_words and _CODE.fullmatch(rest[0].upper()) and _CODE.fullmatch(rest[2].upper()):
        return ParsedRestoreCommand("confirm", rest[0].upper(), rest[2].upper())
    return ParsedRestoreCommand("usage")


def parse_restore_command(text: object, bot_username: str | None = None) -> ParsedRestoreCommand | None:
    """The parsed `/restore` (or the Arabic form), or None (ordinary chat / another bot's command)."""
    if not isinstance(text, str) or not text.strip() or len(text) > MAX_COMMAND_LEN:
        return None
    words = text.split()
    if text.lstrip().startswith("/"):
        name, at, target = words[0][1:].partition("@")
        if name.lower() != "restore":
            return None
        if at and (not bot_username or target.lower() != bot_username.lower()):
            return None
        if len(words) == 1:
            return ParsedRestoreCommand("preview")
        if words[1].lower() == "confirm":
            return _confirm_args(words[2:], frozenset({"with_license"}), False)
        return ParsedRestoreCommand("usage")
    folded = [fold_arabic(w) for w in words]
    if folded[0] != _AR_RESTORE:
        return None
    if len(words) == 1 or (len(words) == 2 and folded[1] == _AR_COPY) \
            or (len(words) == 3 and folded[1] == _AR_COPY and folded[2] in _AR_BACKUP):
        return ParsedRestoreCommand("preview")
    i = 1
    if folded[1] == _AR_COPY:
        i = 3 if len(words) > 2 and folded[2] in _AR_BACKUP else 2   # `استعادة نسخة [احتياطية] تأكيد ...`
    if len(words) > i and folded[i] in _AR_CONFIRM:
        return _confirm_args(words[i + 1:], _AR_LICENSE, True)
    return None


@dataclass(frozen=True, slots=True)
class RestoreReply:
    status: str
    text: str


class RestoreCommandService:
    def __init__(self, service: Any, *, language: str = "ar") -> None:
        self._service, self._language = service, language

    async def run(self, parsed: ParsedRestoreCommand, *, chat_id: object, chat_type: object, user_id: object, message_id: object,
                  document: svc.DocumentRef | None, lang: str | None = None) -> RestoreReply | None:
        """None = answer nothing (not a private chat, not the owner, a redelivered update)."""
        lang = lang or self._language
        if chat_type != "private" or not isinstance(chat_id, int) or isinstance(chat_id, bool) or chat_id <= 0 or chat_id != user_id:
            return None
        try:
            if parsed.action == "usage":
                if not await self._service.is_owner(user_id):      # even the usage text is for the owner only
                    return None
                return RestoreReply("usage", t("rs_usage", lang))
            if parsed.action == "confirm":
                out = await self._service.confirm(user_id, document, message_id, parsed.code, parsed.license_code)
            else:
                out = await self._service.preview(user_id, document, message_id)
        except Exception:
            log.error("restore command failed", exc_info=True)
            return RestoreReply("failed", t("rs_failed", lang))
        return None if out is None else self._reply(out, lang)

    @staticmethod
    def _reply(out: Any, lang: str) -> RestoreReply:
        s = out.status
        if s == svc.PREVIEWED:
            return RestoreReply(s, render_preview(out.preview, lang, code=out.code, license_code=out.license_code, minutes=out.minutes))
        if s == svc.APPLIED:
            return RestoreReply(s, render_applied(out.result, lang))
        if s == svc.ROLLED_BACK:
            return RestoreReply(s, t(_ROLLBACK_KEYS.get(out.code, "rs_r_db_failed"), lang, where=out.where or "-"))
        if s == svc.COOLDOWN:
            return RestoreReply(s, t("rs_cooldown", lang, seconds=str(out.wait_seconds)))
        if s == svc.INVALID:
            key = _INVALID_KEYS.get(out.code, "rs_bad_content")
            text = t(key, lang, where=out.where or "-")
            return RestoreReply(s, text)
        keys = {svc.NO_FILE: "rs_usage", svc.UNKNOWN_CODE: "rs_unknown_code", svc.WRONG_FILE: "rs_wrong_file", svc.TOO_LARGE: "rs_too_large", svc.DOWNLOAD_FAILED: "rs_download_failed",
                svc.BUSY: "rs_busy", svc.UNAVAILABLE: "rs_unavailable"}
        return RestoreReply(s, t(keys.get(s, "rs_failed"), lang))


_ROLLBACK_KEYS = {"state_changed": "rs_r_state_changed", "id_conflict": "rs_r_id_conflict", "key_conflict": "rs_r_key_conflict",
                  "constraint_failed": "rs_r_constraint", "lock_timeout": "rs_r_lock_timeout", "verify_failed": "rs_r_verify_failed",
                  "db_failed": "rs_r_db_failed"}


def render_applied(r: Any, lang: str) -> str:
    lic = t("rs_applied_license_on", lang, n=str(r.license_updated)) if r.with_license else t("rs_applied_license_off", lang)
    return "\n".join([t("rs_applied_head", lang, fp=r.fingerprint.upper()),
                      t("rs_applied_groups", lang, replaced=str(r.groups_replaced), added=str(r.groups_added)),
                      t("rs_applied_rows", lang, removed=str(r.rows_removed), inserted=str(r.rows_inserted)),
                      t("rs_applied_log", lang, n=str(r.log_appended)), lic])


def _group_order(line: GroupLine) -> tuple:
    return (not line.is_new, -(line.current + line.backup), line.group_id)


def render_preview(p: RestorePreview, lang: str, *, code: str = "", license_code: str = "", minutes: int = 0) -> str:
    """The preview as one phone-sized message (a fixed number of group lines; the rest is counted)."""
    out = [t("rs_head", lang, date=p.created_at.strftime("%Y-%m-%d %H:%M"), age=str(p.age_days), schema=str(p.schema_version),
             app=p.app_version, rows=str(p.backup_rows), fp=p.fingerprint.upper()),
           t("rs_groups", lang, replaced=str(p.groups_replaced), new=str(p.groups_new), kept=str(p.groups_kept)),
           t("rs_tables_head", lang)]
    for line in p.tables:
        if line.policy == CREATE_MISSING:
            out.append(t("rs_line_create_missing", lang, table=line.table, new=str(line.added)))
        elif line.policy == APPEND_ONLY:
            out.append(t("rs_line_append_only", lang, table=line.table, current=str(line.current), backup=str(line.backup)))
        else:
            out.append(t(f"rs_line_{line.policy}", lang, table=line.table, current=str(line.current), backup=str(line.backup)))
    out.append(t("rs_license", lang, n=str(p.license_differs)))
    shown = sorted(p.groups, key=_group_order)[:MAX_GROUP_LINES]
    if shown:
        out.append(t("rs_groups_head", lang, n=str(len(shown))))
        for g in shown:
            out.append(t("rs_group_new" if g.is_new else "rs_group_replace", lang, group=str(g.group_id),
                         current=str(g.current), backup=str(g.backup)))
        if len(p.groups) > len(shown):
            out.append(t("rs_groups_more", lang, n=str(len(p.groups) - len(shown))))
    for warning, arg in p.warnings:
        out.append(t(f"rs_w_{warning}", lang, n=arg))
    if code:
        out.append(t("rs_confirm", lang, code=code, minutes=str(minutes)))
        if license_code:
            out.append(t("rs_confirm_license", lang, code=code, license_code=license_code))
    else:
        out.append(t("rs_footer", lang))
    return "\n".join(out)
