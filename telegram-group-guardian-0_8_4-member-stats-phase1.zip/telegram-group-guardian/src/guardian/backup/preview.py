"""Restore PREVIEW (part 6.9a): what a restore of a validated backup WOULD do, computed without writing anything.

Pure: `build_preview(validated_backup, current_state, now)`; `CurrentState` is read-only data (counts and the licence state of
each group) supplied by a `RestoreStateReader` (PostgreSQL: `postgres_state.py`, SELECTs only). Nothing in this module can write.

The restore POLICY the preview describes (decided in 6.9a; part 6.9b executes exactly this, in ONE transaction):

* Scope is per GROUP. A group in the backup and in the database is REPLACED; a group only in the backup is ADDED; a group only
  in the database is LEFT UNTOUCHED (a restore never deletes a group, and never touches a group the file does not mention).
* Replaced per group (current rows of that group removed, the backup's rows inserted): `group_settings`, `group_delegations`,
  `group_trusted_users`, `group_trusted_bots`, `moderation_warnings`, `moderation_sanctions`, `group_reports`.
* `telegram_groups`: an EXISTING row is not modified. A MISSING group is created as `pending` with no expiry (protection stays
  OFF until the owner licenses it: fail closed). The backup's licence state is applied only with the separate `with_license` option.
* `license_audit_log` is append-only (a database trigger forbids any change or removal of its rows): it is NEVER replaced or deleted. Without
  `with_license` it is not touched; with it, only entries not already present are appended (the exact number is computed at restore time).
* Global tables are replaced as a whole: `settings_templates` (every current template is removed) and `global_default_settings`
  (the single row). The preview says how many current rows go away.
* Excluded tables (see `format.EXCLUDED_TABLES`) are never touched.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Protocol

from ..time_utils import utcnow
from .format import TABLE_NAMES
from .validate import ValidatedBackup

# Per-group tables replaced group by group.
REPLACED_PER_GROUP = ("group_settings", "group_delegations", "group_trusted_users", "group_trusted_bots",
                      "moderation_warnings", "moderation_sanctions", "group_reports")
GLOBAL_REPLACED = ("settings_templates", "global_default_settings")
LOG_TABLE = "license_audit_log"
GROUPS_TABLE = "telegram_groups"
COUNTED_PER_GROUP = REPLACED_PER_GROUP + (LOG_TABLE,)   # what the state reader counts per group

# Policies (closed vocabulary; the command layer maps each to a message).
REPLACE_GROUP, CREATE_MISSING, APPEND_ONLY, REPLACE_ALL = "replace_group", "create_missing", "append_only", "replace_all"
POLICY = {GROUPS_TABLE: CREATE_MISSING, LOG_TABLE: APPEND_ONLY,
          **{t: REPLACE_GROUP for t in REPLACED_PER_GROUP}, **{t: REPLACE_ALL for t in GLOBAL_REPLACED}}

# Warning codes (closed vocabulary).
W_OLD_BACKUP, W_REMOVES_ROWS, W_NEW_GROUPS, W_KEPT_GROUPS, W_LICENSE_DIFFERS, W_OLDER_DEFAULTS = (
    "old_backup", "removes_rows", "new_groups_pending", "groups_kept", "license_differs", "older_defaults")
OLD_BACKUP_AFTER = timedelta(days=7)
MAX_GROUP_LINES = 8


@dataclass(frozen=True, slots=True)
class CurrentGroup:
    status: str
    expires_at: str | None          # encoded UTC text (`...Z`), comparable with the file's values


@dataclass(frozen=True, slots=True)
class CurrentState:
    """A read-only picture of the live database: only counts and licence states (never a row's content)."""
    groups: dict[int, CurrentGroup]
    counts: dict[str, dict[int, int]]      # per-group table -> group id -> row count
    global_counts: dict[str, int]          # `settings_templates` / `global_default_settings` -> row count
    defaults_version: int | None = None    # version of the current global defaults (None = no row)


class RestoreStateReader(Protocol):
    async def read(self) -> CurrentState:
        """One consistent, read-only view (PostgreSQL: a REPEATABLE READ read-only transaction)."""


@dataclass(frozen=True, slots=True)
class TableLine:
    table: str
    policy: str
    current: int        # rows now in the database that this restore concerns
    backup: int         # rows in the file
    removed: int        # current rows that would disappear
    added: int          # rows that would be inserted (the licence log's append count is decided at restore time: 0 here)


@dataclass(frozen=True, slots=True)
class GroupLine:
    group_id: int
    is_new: bool                    # not in the database: it would be created (pending)
    current: int                    # rows now, over the per-group replaced tables
    backup: int                     # rows in the file, same tables
    license_differs: bool           # exists in both and the backup's licence state differs from the current one (applied only with_license)
    license_now: str = ""           # the group's CURRENT licence status and expiry ("" for a new group): part of what the owner approved


@dataclass(frozen=True, slots=True)
class RestorePreview:
    fingerprint: str
    created_at: datetime
    schema_version: int
    app_version: str
    backup_rows: int
    tables: tuple[TableLine, ...]
    groups: tuple[GroupLine, ...]          # EVERY group of the file, ascending (the display caps the lines, not the data)
    groups_replaced: int
    groups_new: int
    groups_kept: int                       # in the database, absent from the file: untouched
    license_differs: int
    log_backup: int                        # licence-log rows of the file's groups in the file
    log_current: int                       # ... and now in the database
    defaults_current: int | None
    defaults_backup: int | None
    removed_total: int
    added_total: int
    age_days: int
    warnings: tuple[tuple[str, str], ...] = field(default_factory=tuple)   # (code, a short argument: a number or "")

    @property
    def writes_anything(self) -> bool:      # a preview never does; kept as an explicit, testable fact
        return False


def _per_group(rows: list[dict[str, Any]]) -> dict[int, int]:
    out: dict[int, int] = {}
    for row in rows:
        out[row["group_id"]] = out.get(row["group_id"], 0) + 1
    return out


def build_preview(backup: ValidatedBackup, current: CurrentState, now: datetime | None = None) -> RestorePreview:
    """Pure: the same inputs always give the same preview, and nothing is written anywhere."""
    now = (now or utcnow()).astimezone(timezone.utc)
    in_file = {row["group_id"]: row for row in backup.tables[GROUPS_TABLE]}
    file_counts = {t: _per_group(backup.tables[t]) for t in COUNTED_PER_GROUP}
    lines: list[TableLine] = []

    existing = [g for g in backup.group_ids if g in current.groups]
    new = [g for g in backup.group_ids if g not in current.groups]
    lines.append(TableLine(GROUPS_TABLE, POLICY[GROUPS_TABLE], len(existing), len(backup.group_ids), 0, len(new)))

    for table in REPLACED_PER_GROUP:
        cur = sum(current.counts.get(table, {}).get(g, 0) for g in backup.group_ids)
        n = len(backup.tables[table])
        lines.append(TableLine(table, REPLACE_GROUP, cur, n, cur, n))

    log_cur = sum(current.counts.get(LOG_TABLE, {}).get(g, 0) for g in backup.group_ids)
    log_file = len(backup.tables[LOG_TABLE])
    lines.append(TableLine(LOG_TABLE, APPEND_ONLY, log_cur, log_file, 0, 0))

    for table in GLOBAL_REPLACED:
        cur = int(current.global_counts.get(table, 0))
        n = len(backup.tables[table])
        lines.append(TableLine(table, REPLACE_ALL, cur, n, cur, n))

    group_lines: list[GroupLine] = []
    differs = 0
    for g in backup.group_ids:
        cur_rows = sum(current.counts.get(t, {}).get(g, 0) for t in REPLACED_PER_GROUP)
        file_rows = sum(file_counts[t].get(g, 0) for t in REPLACED_PER_GROUP)
        known = current.groups.get(g)
        row = in_file[g]
        diff = known is not None and (known.status != row["license_status"] or known.expires_at != row["expires_at"])
        differs += 1 if diff else 0
        group_lines.append(GroupLine(g, known is None, cur_rows, file_rows, diff, "" if known is None else f"{known.status}|{known.expires_at}"))

    in_backup = set(backup.group_ids)
    kept = len([g for g in current.groups if g not in in_backup])
    removed = sum(line.removed for line in lines)
    added = sum(line.added for line in lines)
    age = max(0, int((now - backup.created_at).total_seconds() // 86400))
    defaults_backup = backup.tables["global_default_settings"][0]["version"] if backup.tables["global_default_settings"] else None

    warnings: list[tuple[str, str]] = []
    if now - backup.created_at > OLD_BACKUP_AFTER:
        warnings.append((W_OLD_BACKUP, str(age)))
    if removed:
        warnings.append((W_REMOVES_ROWS, str(removed)))
    if new:
        warnings.append((W_NEW_GROUPS, str(len(new))))
    if kept:
        warnings.append((W_KEPT_GROUPS, str(kept)))
    if differs:
        warnings.append((W_LICENSE_DIFFERS, str(differs)))
    if defaults_backup is not None and current.defaults_version is not None and defaults_backup < current.defaults_version:
        warnings.append((W_OLDER_DEFAULTS, f"{defaults_backup}<{current.defaults_version}"))

    return RestorePreview(
        fingerprint=backup.fingerprint, created_at=backup.created_at, schema_version=backup.schema_version,
        app_version=backup.app_version, backup_rows=backup.total_rows, tables=tuple(lines), groups=tuple(group_lines),
        groups_replaced=len(existing), groups_new=len(new), groups_kept=kept, license_differs=differs,
        log_backup=log_file, log_current=log_cur, defaults_current=current.defaults_version, defaults_backup=defaults_backup,
        removed_total=removed, added_total=added, age_days=age, warnings=tuple(warnings))


assert [t for t in TABLE_NAMES if t not in (GROUPS_TABLE, LOG_TABLE, *REPLACED_PER_GROUP, *GLOBAL_REPLACED)] == [], \
    "every registered table needs a restore policy"
