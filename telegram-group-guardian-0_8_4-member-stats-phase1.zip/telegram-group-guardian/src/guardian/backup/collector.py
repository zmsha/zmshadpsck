"""Backup collector (phase 6.8a): reads the registered tables through a read-only snapshot and builds ONE backup file.

* Only `format.TABLES` (explicit columns) is read; nothing is discovered at run time.
* A backup is COMPLETE or it is refused: over the size cap -> `BackupError("too_large")`, never a truncated file.
* Fail closed on secrets: the exact configured secrets (also URL-quoted / JSON-escaped), a PEM private key or a bot-token /
  URL-password shaped string anywhere in the data -> `secret_found` (the table name only, never the value).
* NO permission check, no licence check, no sending, no audit: the owner-only `/backup` command is 6.8b.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, AsyncContextManager, Callable, Iterable, Protocol
from urllib.parse import quote

from ..db.migrations import discover
from ..logging_setup import redact as _log_redact
from ..owner_hub.redactor import _PEM_HEADER_RE, redact_text
from .format import (BackupError, EXCLUDED_TABLES, FORMAT_NAME, FORMAT_VERSION, MAX_BACKUP_BYTES, TABLES, TableSpec,
                     build_document_text, canonical, encode_row, rows_text, sha256_hex, tables_digest)

PAGE_SIZE = 500
MAX_PAGES_PER_TABLE = 100_000  # a loop guard only; the byte cap stops a real backup long before


class BackupSnapshot(Protocol):
    async def read_page(self, spec: TableSpec, after: tuple | None, limit: int) -> list[Any]:
        """Up to `limit` rows of `spec` ordered by `spec.key`, strictly after the key tuple `after` (None = from the start)."""


class BackupReader(Protocol):
    def snapshot(self) -> AsyncContextManager[BackupSnapshot]:
        """One consistent, read-only view for the whole collection (PostgreSQL: a REPEATABLE READ read-only transaction)."""


@dataclass(frozen=True, slots=True)
class BackupResult:
    name: str                       # suggested file name (ASCII, .json)
    data: bytes                     # the whole file, <= the size cap
    manifest: dict[str, Any]        # what the file's own manifest says (counts, checksums, versions)
    screen_flags: tuple[str, ...]   # tables whose text the heuristic redactor WOULD change (see 6.8b: such a file must not be passed through it)

    @property
    def size(self) -> int:
        return len(self.data)

    @property
    def total_rows(self) -> int:
        return int(self.manifest["total_rows"])


def schema_state() -> tuple[int, str]:
    """(number, name) of the newest migration file, e.g. (10, '0010_<name>')."""
    version = discover()[-1][0]
    return int(version[:4]), version


def _secret_forms(secrets: Iterable[str]) -> list[str]:
    forms: set[str] = set()
    for secret in secrets:
        if not secret or len(secret) < 4:
            continue
        forms.update({secret, quote(secret, safe=""), json.dumps(secret, ensure_ascii=False)[1:-1]})
    return sorted(forms, key=len, reverse=True)


def leaks_secret(text: str, forms: list[str]) -> bool:
    return (any(f in text for f in forms) or _PEM_HEADER_RE.search(text) is not None or _log_redact(text) != text)


class BackupCollector:
    def __init__(self, reader: BackupReader, *, app_version: str, schema_version: int | None = None,
                 schema_name: str | None = None, secrets: Iterable[str] = (),
                 clock: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
                 max_bytes: int = MAX_BACKUP_BYTES, page_size: int = PAGE_SIZE,
                 tables: tuple[TableSpec, ...] = TABLES) -> None:
        if schema_version is None or schema_name is None:
            schema_version, schema_name = schema_state()
        if page_size < 1 or max_bytes < 1:
            raise ValueError("page_size and max_bytes must be positive")
        self._reader, self._app_version = reader, app_version
        self._schema_version, self._schema_name = int(schema_version), str(schema_name)
        self._forms = _secret_forms(secrets)
        self._secrets = tuple(secrets)
        self._clock, self._max, self._page, self._tables = clock, max_bytes, page_size, tuple(tables)

    async def collect(self) -> BackupResult:
        now = self._clock()
        if now.tzinfo is None or now.utcoffset() is None:
            raise ValueError("clock must return an aware datetime")
        now = now.astimezone(timezone.utc)
        texts: dict[str, str] = {}
        entries: dict[str, dict[str, Any]] = {}
        flags: list[str] = []
        used = 0
        try:
            async with self._reader.snapshot() as snap:
                for spec in self._tables:
                    row_texts, used = await self._read_table(snap, spec, used)
                    text = rows_text(row_texts)
                    if leaks_secret(text, self._forms):
                        raise BackupError("secret_found", spec.name)
                    if redact_text(text, self._secrets) != text:
                        flags.append(spec.name)
                    texts[spec.name] = text
                    entries[spec.name] = {"rows": len(row_texts), "sha256": sha256_hex(text)}
        except BackupError:
            raise
        except Exception as exc:  # the reader/driver; only the TYPE name is kept (a driver message may echo the DSN)
            code = "unavailable" if type(exc).__name__ == "StoreUnavailable" else "read_failed"
            raise BackupError(code, type(exc).__name__) from None
        manifest = {
            "format": FORMAT_NAME, "format_version": FORMAT_VERSION,
            "schema_version": self._schema_version, "schema_name": self._schema_name,
            "app_version": self._app_version, "created_at": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "tables": entries, "total_rows": sum(e["rows"] for e in entries.values()),
            "tables_digest": tables_digest(entries), "excluded": sorted(EXCLUDED_TABLES),
        }
        data = build_document_text(manifest, texts).encode("utf-8")
        if len(data) > self._max:
            raise BackupError("too_large", f"{len(data)}>{self._max}")
        name = f"guardian-backup-{now.strftime('%Y%m%d-%H%M%S')}-utc.json"
        return BackupResult(name, data, manifest, tuple(flags))

    async def _read_table(self, snap: BackupSnapshot, spec: TableSpec, used: int) -> tuple[list[str], int]:
        row_texts: list[str] = []
        after: tuple | None = None
        for _ in range(MAX_PAGES_PER_TABLE):
            page = list(await snap.read_page(spec, after, self._page))
            if len(page) > self._page:
                raise BackupError("read_failed", f"{spec.name}: page too large")
            for raw in page:
                text = canonical(encode_row(spec, raw))
                row_texts.append(text)
                used += len(text.encode("utf-8")) + 1
            if used > self._max:  # stop reading as soon as the file cannot fit
                raise BackupError("too_large", spec.name)
            if len(page) < self._page:
                return row_texts, used
            try:
                key = tuple(page[-1][k] for k in spec.key)
            except (KeyError, TypeError):
                raise BackupError("read_failed", f"{spec.name}: key column missing") from None
            if after is not None and not key > after:  # the reader must move forward, or this would loop
                raise BackupError("read_failed", f"{spec.name}: no progress")
            after = key
        raise BackupError("read_failed", f"{spec.name}: too many pages")
