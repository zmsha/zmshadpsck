"""Restore EXECUTION (part 6.9b): apply a validated backup in ONE transaction, exactly as the 6.9a preview described it.

Pure orchestration over a `RestoreWriter` (PostgreSQL: `postgres_restore.py`; tests: an in-memory writer with the same
contract). Everything that can fail fails INSIDE the transaction, which then rolls back completely: the database is either
exactly as before or exactly as the policy says, never in between.

Inside the transaction, in this order:
 1. LOCK: one restore at a time (advisory lock) and every touched table locked against concurrent writers;
 2. RE-READ the current state and rebuild the preview; its signature must equal the one the owner approved (`state_changed`
    otherwise: the owner confirmed THAT preview, not whatever the data became since);
 3. PREFLIGHT: ids / the global sanction key of the file must not collide with rows of groups the restore does not touch
    (`id_conflict` / `key_conflict`: a backup from another database is refused, never remapped);
 4. groups: MISSING groups are created (`pending`, no expiry; with `with_license` as the file says); EXISTING rows are untouched,
    except their licence columns with `with_license`; every licence change is written to `license_audit_log`;
 5. the file's licence-log rows are APPENDED (only with `with_license`, only those not already present; nothing is ever updated or deleted);
 6. per-group tables: the group's current rows removed, the file's inserted; global tables replaced as a whole;
 7. id sequences moved past the restored ids (never backwards); 8. a final count check against the preview (`verify_failed`).
The licence state is applied ONLY when `with_license` is true; the service demands its own, separate confirmation code for it.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from datetime import datetime
from typing import Any, AsyncContextManager, Callable, Protocol

from ..time_utils import utcnow
from .format import encode_timestamp
from .preview import (COUNTED_PER_GROUP, GLOBAL_REPLACED, GROUPS_TABLE, LOG_TABLE, REPLACED_PER_GROUP, CurrentState, RestorePreview,
                      build_preview)
from .validate import ValidatedBackup

ERROR_CODES = ("state_changed", "id_conflict", "key_conflict", "constraint_failed", "lock_timeout", "verify_failed", "db_failed")
ID_TABLES = ("group_delegations", "moderation_warnings", "moderation_sanctions", "group_reports", "settings_templates")
ID_CONFLICT_TABLES = ("group_delegations", "moderation_warnings", "moderation_sanctions", "group_reports")   # per-group tables with an `id`
LICENSE_COLUMNS = ("license_status", "activated_at", "expires_at", "activated_by", "status_note")
RESTORE_ACTION = "restore"


class RestoreError(Exception):
    """The restore did not happen (the transaction rolled back). `code` is closed; `detail` is a table name or nothing."""

    def __init__(self, code: str, detail: str = "") -> None:
        if code not in ERROR_CODES:
            raise ValueError(f"unknown restore error code: {code!r}")
        super().__init__(f"{code}: {detail}" if detail else code)
        self.code, self.detail = code, detail


class RestoreTransaction(Protocol):
    """One OPEN transaction. Every method works inside it; an exception leaves it to be rolled back by the writer."""
    async def lock(self) -> None: ...
    async def read_state(self) -> CurrentState: ...
    async def id_conflicts(self, table: str, ids: list[int], group_ids: list[int]) -> bool: ...
    async def sanction_key_conflicts(self, keys: list[str], group_ids: list[int]) -> bool: ...
    async def create_groups(self, rows: list[dict[str, Any]]) -> int: ...
    async def update_license(self, rows: list[dict[str, Any]]) -> int: ...
    async def delete_for_groups(self, table: str, group_ids: list[int]) -> int: ...
    async def delete_all(self, table: str) -> int: ...
    async def insert_rows(self, table: str, rows: list[dict[str, Any]]) -> int: ...
    async def append_license_log(self, rows: list[dict[str, Any]], *, skip_existing: bool) -> int: ...
    async def reset_sequences(self, tables: tuple[str, ...]) -> None: ...


class RestoreWriter(Protocol):
    def transaction(self) -> AsyncContextManager[RestoreTransaction]:
        """Commit when the block ends normally, roll back on any exception."""


@dataclass(frozen=True, slots=True)
class RestoreResult:
    fingerprint: str
    with_license: bool
    groups_replaced: int
    groups_added: int
    rows_removed: int            # per-group + global tables (the licence log is never removed)
    rows_inserted: int
    log_appended: int            # backup licence-log rows appended + one row per licence change this restore made
    license_updated: int         # groups whose licence state this restore changed (0 without `with_license`)
    per_table: tuple[tuple[str, int, int], ...]     # (table, removed, inserted)


def preview_signature(p: RestorePreview) -> str:
    """12 hex characters naming WHAT the owner approved: the file and the per-table / per-group effect (no time-dependent field)."""
    body = {"fp": p.fingerprint,
            "tables": [[l.table, l.policy, l.current, l.backup, l.removed, l.added] for l in p.tables],
            "groups": [[g.group_id, g.is_new, g.current, g.backup, g.license_differs, g.license_now] for g in p.groups],
            "kept": p.groups_kept, "defaults": [p.defaults_current, p.defaults_backup]}
    return hashlib.sha256(json.dumps(body, sort_keys=True, separators=(",", ":")).encode()).hexdigest()[:12]


def _license_of(row: dict[str, Any]) -> tuple:
    return tuple(row[c] for c in LICENSE_COLUMNS[:3])        # status, activated_at, expires_at: what "differs" means in the preview


class RestoreExecutor:
    def __init__(self, writer: Any, *, clock: Callable[[], datetime] = utcnow) -> None:
        self._writer, self._clock = writer, clock

    async def execute(self, backup: ValidatedBackup, *, expected_signature: str, owner_id: int, with_license: bool) -> RestoreResult:
        """All or nothing. Raises `RestoreError` (closed code); any other failure is mapped by the writer to a `RestoreError` too."""
        groups = list(backup.group_ids)
        async with self._writer.transaction() as tx:
            await tx.lock()
            current = await tx.read_state()
            now = self._clock()
            preview = build_preview(backup, current, now)
            if preview_signature(preview) != expected_signature:
                raise RestoreError("state_changed")
            await self._preflight(tx, backup, groups)

            by_group = {row["group_id"]: row for row in backup.tables[GROUPS_TABLE]}
            new_ids = [g for g in groups if g not in current.groups]
            license_rows: list[dict[str, Any]] = []
            updated_rows: list[dict[str, Any]] = []
            for g in groups:
                row = by_group[g]
                known = current.groups.get(g)
                if known is None:
                    if with_license and row["license_status"] != "pending":
                        license_rows.append(self._log_row(g, owner_id, None, row, now, backup.fingerprint))
                elif with_license and (known.status != row["license_status"] or known.expires_at != row["expires_at"]):
                    updated_rows.append(row)
                    license_rows.append(self._log_row(g, owner_id, known.status, row, now, backup.fingerprint))

            created = await tx.create_groups([self._new_group_row(by_group[g], with_license) for g in new_ids])
            license_updated = await tx.update_license(updated_rows) if updated_rows else 0
            appended = await tx.append_license_log(list(backup.tables[LOG_TABLE]), skip_existing=True) if with_license else 0
            appended += await tx.append_license_log(license_rows, skip_existing=False) if license_rows else 0

            per_table: list[tuple[str, int, int]] = []
            for table in REPLACED_PER_GROUP:
                removed = await tx.delete_for_groups(table, groups)
                inserted = await tx.insert_rows(table, list(backup.tables[table]))
                per_table.append((table, removed, inserted))
            for table in GLOBAL_REPLACED:
                removed = await tx.delete_all(table)
                inserted = await tx.insert_rows(table, list(backup.tables[table]))
                per_table.append((table, removed, inserted))
            await tx.reset_sequences(ID_TABLES)

            expected = {line.table: line for line in preview.tables}
            for table, removed, inserted in per_table:
                if removed != expected[table].removed or inserted != expected[table].added:
                    raise RestoreError("verify_failed", table)
            if created != len(new_ids):
                raise RestoreError("verify_failed", GROUPS_TABLE)
            await self._verify(tx, backup)
        return RestoreResult(
            fingerprint=backup.fingerprint, with_license=with_license, groups_replaced=len(groups) - len(new_ids),
            groups_added=len(new_ids), rows_removed=sum(r for _, r, _ in per_table), rows_inserted=sum(i for _, _, i in per_table),
            log_appended=appended, license_updated=license_updated, per_table=tuple(per_table))

    @staticmethod
    async def _preflight(tx: Any, backup: ValidatedBackup, groups: list[int]) -> None:
        for table in ID_CONFLICT_TABLES:
            ids = [row["id"] for row in backup.tables[table]]
            if ids and await tx.id_conflicts(table, ids, groups):
                raise RestoreError("id_conflict", table)
        keys = [row["idempotency_key"] for row in backup.tables["moderation_sanctions"] if row["idempotency_key"] is not None]
        if keys and await tx.sanction_key_conflicts(keys, groups):
            raise RestoreError("key_conflict", "moderation_sanctions")

    @staticmethod
    def _new_group_row(row: dict[str, Any], with_license: bool) -> dict[str, Any]:
        """A group the database does not know. Without `with_license` it is created UNLICENSED (protection off) whatever the file says."""
        if with_license:
            return dict(row)
        out = dict(row)
        out.update(license_status="pending", activated_at=None, expires_at=None, activated_by=None, status_note=None)
        return out

    @staticmethod
    def _log_row(group_id: int, owner_id: int, previous: str | None, row: dict[str, Any], now: datetime, fingerprint: str) -> dict[str, Any]:
        return {"group_id": group_id, "actor_telegram_id": owner_id, "action": RESTORE_ACTION, "previous_status": previous,
                "new_status": row["license_status"], "expires_at": row["expires_at"], "reason": f"restore:{fingerprint}",
                "occurred_at": encode_timestamp(now)}

    @staticmethod
    async def _verify(tx: Any, backup: ValidatedBackup) -> None:
        """After the writes, inside the transaction: the database holds exactly the file's rows for every replaced table."""
        state = await tx.read_state()
        groups = backup.group_ids
        for table in REPLACED_PER_GROUP:
            got = sum(state.counts.get(table, {}).get(g, 0) for g in groups)
            if got != len(backup.tables[table]):
                raise RestoreError("verify_failed", table)
        for table in GLOBAL_REPLACED:
            if state.global_counts.get(table, 0) != len(backup.tables[table]):
                raise RestoreError("verify_failed", table)
        for g in groups:
            if g not in state.groups:
                raise RestoreError("verify_failed", GROUPS_TABLE)


assert set(ID_CONFLICT_TABLES) <= set(REPLACED_PER_GROUP) and set(ID_TABLES) == set(ID_CONFLICT_TABLES) | {"settings_templates"}
assert set(COUNTED_PER_GROUP) == set(REPLACED_PER_GROUP) | {LOG_TABLE}
