"""Backup (phase 6.8a): the file FORMAT and the COLLECTOR only.

No command, no sending, no restore, no permission check: part 6.8b adds the owner-only `/backup` command and the delivery,
part 6.9 the restore. Nothing here talks to Telegram or imports aiogram.
"""
