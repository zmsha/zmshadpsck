"""Restore validation (part 6.9a): may THIS file even be previewed? Pure: bytes in, a verdict out.

No database, no Telegram, no clock side effects, no writes of any kind. It judges, in order (the first failure wins):

 1. structure and integrity: `parse_document` + `verify_integrity` (format name/version, table list, counts, SHA-256, digest);
 2. the manifest: schema version (>= `MIN_SCHEMA_VERSION` and <= the running one), names, creation time, `total_rows`;
 3. completeness: EVERY registered table is present (a backup is complete or refused) and no other table is;
 4. every row: exactly the registered columns, strict types (timestamps decoded), a non-null primary key, no duplicate key;
 5. the SQL rules the live schema would enforce (CHECK constraints, unique indexes), so a row that would fail the database
    later fails here, with a table/rule name, before anything is shown as restorable;
 6. foreign keys inside the file (every per-group row belongs to a group in `telegram_groups`);
 7. secrets: the configured secrets (also URL-quoted / JSON-escaped), a PEM key, a bot-token / URL-password shape -> refused.

An error carries a closed code and at most a table/column/rule name, never a value (the file may be hostile).
The checksums detect accidents, not a deliberate edit (there is no encryption or signature in 6.x); the content rules above
are what keeps an edited file from smuggling an invalid state.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Iterable

from ..time_utils import utcnow
from .collector import _secret_forms, leaks_secret
from .format import (BY_NAME, INTEGRITY_CODES, MAX_BACKUP_BYTES, TABLE_NAMES, BackupFormatError, canonical, decode_value,
                     parse_document, verify_integrity)

MIN_SCHEMA_VERSION = 10   # the first schema the v1 table registry (`format.TABLES`) describes
MAX_FUTURE_SKEW = timedelta(days=1)
_MAX_APP_VERSION = 40

EXTRA_CODES = ("bad_manifest", "schema_too_old", "schema_too_new", "incomplete", "bad_columns", "bad_value", "bad_rule",
               "duplicate_key", "orphan_row", "secret_found")
VALIDATION_CODES = tuple(INTEGRITY_CODES) + EXTRA_CODES

LICENSE_STATUSES = frozenset({"pending", "active_permanent", "active_temporary", "expired", "stopped", "rejected", "banned"})
ROLES = frozenset({"group_manager", "moderator"})
SANCTION_KINDS = frozenset({"mute", "ban", "kick"})
REPORT_TYPES = frozenset({"spam", "abuse", "scam", "other"})
REPORT_PRIORITIES = frozenset({"low", "normal", "high"})
REPORT_STATUSES = frozenset({"open", "taken", "resolved", "dismissed"})
REPORT_OUTCOMES = frozenset({"action_taken", "no_action", "false_report"})
LANGUAGES = frozenset({"ar", "en"})
_TRACE = re.compile(r"[0-9a-f]{16}")
_CREATED = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z")
_SCHEMA_NAME = re.compile(r"\d{4}_[a-z0-9_]{1,60}")

# Tables whose rows carry a `group_id` that must exist in `telegram_groups` (the foreign keys of the live schema).
GROUP_TABLES = ("license_audit_log", "group_settings", "group_delegations", "group_trusted_users", "group_trusted_bots",
                "moderation_warnings", "moderation_sanctions", "group_reports")


class RestoreValidationError(Exception):
    """The file cannot be previewed. `code` is closed (`VALIDATION_CODES`); `detail` is a table/column/rule name only."""

    def __init__(self, code: str, detail: str = "") -> None:
        if code not in VALIDATION_CODES:
            raise ValueError(f"unknown validation code: {code!r}")
        super().__init__(f"{code}: {detail}" if detail else code)
        self.code = code
        self.detail = detail


@dataclass(frozen=True, slots=True)
class ValidatedBackup:
    """A backup that passed every check. `tables` holds the file's own (encoded) rows; nothing here is applied anywhere."""
    manifest: dict[str, Any]
    tables: dict[str, list[dict[str, Any]]]
    created_at: datetime
    schema_version: int
    app_version: str
    fingerprint: str                       # the first 12 hex characters of the tables digest (names THIS content, not the file name)
    group_ids: tuple[int, ...]             # every group in `telegram_groups`, ascending

    @property
    def total_rows(self) -> int:
        return int(self.manifest["total_rows"])


# ------------------------------------------------------------------------------------------------ small predicates
def _is_int(v: object) -> bool:
    return type(v) is int


def _pos_or_none(v: object) -> bool:
    return v is None or (_is_int(v) and v > 0)


def _len_ok(v: object, low: int, high: int) -> bool:
    return isinstance(v, str) and low <= len(v) <= high


def _len_or_none(v: object, high: int, low: int = 0) -> bool:
    return v is None or _len_ok(v, low, high)


def _before(a: object, b: object) -> bool:
    """`a` strictly before `b` (encoded UTC timestamps compare as text because they are fixed-width)."""
    return isinstance(a, str) and isinstance(b, str) and a < b


Rule = tuple[str, Callable[[dict[str, Any]], bool]]

# Every rule mirrors a CHECK constraint of the live schema (a test compares each vocabulary and rule name to the migrations).
RULES: dict[str, tuple[Rule, ...]] = {
    "telegram_groups": (
        ("group_id_negative", lambda r: _is_int(r["group_id"]) and r["group_id"] < 0),
        ("license_status", lambda r: r["license_status"] in LICENSE_STATUSES),
        ("permanent_no_expiry", lambda r: r["license_status"] != "active_permanent" or r["expires_at"] is None),
        ("temporary_has_expiry", lambda r: r["license_status"] != "active_temporary" or r["expires_at"] is not None),
        ("active_has_activation", lambda r: r["license_status"] not in ("active_permanent", "active_temporary")
         or (r["activated_at"] is not None and r["activated_by"] is not None)),
    ),
    "license_audit_log": (
        ("group_id_negative", lambda r: _is_int(r["group_id"]) and r["group_id"] < 0),
        ("new_status", lambda r: r["new_status"] in LICENSE_STATUSES),
        ("previous_status", lambda r: r["previous_status"] is None or r["previous_status"] in LICENSE_STATUSES),
        ("action_not_blank", lambda r: isinstance(r["action"], str) and r["action"].strip() != ""),
        ("reason_len", lambda r: _len_or_none(r["reason"], 500)),
    ),
    "group_settings": (
        ("language", lambda r: r["language"] is None or r["language"] in LANGUAGES),
        ("settings_object", lambda r: isinstance(r["settings"], dict)),
    ),
    "group_delegations": (
        ("user_id_positive", lambda r: _is_int(r["user_id"]) and r["user_id"] > 0),
        ("role", lambda r: r["role"] in ROLES),
        ("revoked_pair", lambda r: (r["revoked_at"] is None) == (r["revoked_by"] is None)),
    ),
    "group_trusted_users": (
        ("user_id_positive", lambda r: _is_int(r["user_id"]) and r["user_id"] > 0),
        ("note_len", lambda r: _len_or_none(r["note"], 200)),
    ),
    "group_trusted_bots": (
        ("bot_id_positive", lambda r: _is_int(r["bot_id"]) and r["bot_id"] > 0),
        ("added_by_positive", lambda r: _is_int(r["added_by"]) and r["added_by"] > 0),
        ("note_len", lambda r: _len_or_none(r["note"], 200)),
    ),
    "moderation_warnings": (
        ("user_id_positive", lambda r: _is_int(r["user_id"]) and r["user_id"] > 0),
        ("reason_len", lambda r: _len_or_none(r["reason"], 500)),
        ("idempotency_key_len", lambda r: _len_or_none(r["idempotency_key"], 200, 1)),
        ("expiry_after_create", lambda r: r["expires_at"] is None or _before(r["created_at"], r["expires_at"])),
        ("revoked_pair", lambda r: (r["revoked_at"] is None) == (r["revoked_by"] is None)),
        ("actors_positive", lambda r: _pos_or_none(r["issued_by"]) and _pos_or_none(r["revoked_by"])),
    ),
    "moderation_sanctions": (
        ("user_id_positive", lambda r: _is_int(r["user_id"]) and r["user_id"] > 0),
        ("kind", lambda r: r["kind"] in SANCTION_KINDS),
        ("reason_len", lambda r: _len_or_none(r["reason"], 500)),
        ("violation_len", lambda r: _len_or_none(r["violation"], 40, 1)),
        ("idempotency_key_len", lambda r: _len_or_none(r["idempotency_key"], 200, 1)),
        ("expiry_after_create", lambda r: r["expires_at"] is None or _before(r["created_at"], r["expires_at"])),
        ("kick_no_expiry", lambda r: r["kind"] != "kick" or r["expires_at"] is None),
        ("lifter_needs_lift", lambda r: r["lifted_by"] is None or r["lifted_at"] is not None),
        ("actors_positive", lambda r: _pos_or_none(r["issued_by"]) and _pos_or_none(r["lifted_by"])),
    ),
    "group_reports": (
        ("reporter_positive", lambda r: _is_int(r["reporter_id"]) and r["reporter_id"] > 0),
        ("target_positive", lambda r: _is_int(r["target_user_id"]) and r["target_user_id"] > 0),
        ("message_id_positive", lambda r: _pos_or_none(r["message_id"])),
        ("reason_len", lambda r: _len_or_none(r["reason"], 200)),
        ("report_type", lambda r: r["report_type"] in REPORT_TYPES),
        ("priority", lambda r: r["priority"] in REPORT_PRIORITIES),
        ("status", lambda r: r["status"] in REPORT_STATUSES),
        ("outcome", lambda r: r["outcome"] is None or r["outcome"] in REPORT_OUTCOMES),
        ("handlers_positive", lambda r: _pos_or_none(r["assigned_to"]) and _pos_or_none(r["handled_by"])),
        ("trace_id", lambda r: r["trace_id"] is None or (isinstance(r["trace_id"], str) and _TRACE.fullmatch(r["trace_id"]) is not None)),
        ("idempotency_key_len", lambda r: _len_or_none(r["idempotency_key"], 200, 1)),
        ("state_consistent", lambda r: _report_state_ok(r)),
    ),
    "settings_templates": (
        ("name_len", lambda r: _len_ok(r["name"], 1, 40)),
        ("name_key_len", lambda r: _len_ok(r["name_key"], 1, 40)),
        ("settings_object", lambda r: isinstance(r["settings"], dict)),
        ("created_by_positive", lambda r: _is_int(r["created_by"]) and r["created_by"] > 0),
        ("source_group_negative", lambda r: r["source_group_id"] is None or (_is_int(r["source_group_id"]) and r["source_group_id"] < 0)),
    ),
    "global_default_settings": (
        ("singleton_true", lambda r: r["singleton"] is True),
        ("settings_object", lambda r: isinstance(r["settings"], dict)),
        ("version_positive", lambda r: _is_int(r["version"]) and r["version"] >= 1),
        ("updated_by_positive", lambda r: _pos_or_none(r["updated_by"])),
    ),
}


def _report_state_ok(r: dict[str, Any]) -> bool:
    status = r["status"]
    none = lambda *names: all(r[n] is None for n in names)  # noqa: E731
    some = lambda *names: all(r[n] is not None for n in names)  # noqa: E731
    if status == "open":
        return none("assigned_to", "handled_by", "handled_at", "outcome")
    if status == "taken":
        return some("assigned_to") and none("handled_by", "handled_at", "outcome")
    if status in ("resolved", "dismissed"):
        return some("handled_by", "handled_at", "outcome")
    return False


# A unique index of the live schema: (table, columns, only rows where `where` holds). Rows with a NULL in `columns` never collide.
@dataclass(frozen=True, slots=True)
class Unique:
    name: str
    table: str
    columns: tuple[str, ...]
    where: Callable[[dict[str, Any]], bool] | None = None


UNIQUES: tuple[Unique, ...] = (
    Unique("delegation_live", "group_delegations", ("group_id", "user_id"), lambda r: r["revoked_at"] is None),
    Unique("warning_idempotency", "moderation_warnings", ("group_id", "idempotency_key")),
    Unique("sanction_idempotency", "moderation_sanctions", ("idempotency_key",)),
    Unique("report_idempotency", "group_reports", ("group_id", "idempotency_key")),
    Unique("template_name", "settings_templates", ("name_key",)),
)


# ------------------------------------------------------------------------------------------------ the validation
def validate_backup(data: object, *, current_schema_version: int, secrets: Iterable[str] = (), max_bytes: int = MAX_BACKUP_BYTES,
                    now: datetime | None = None) -> ValidatedBackup:
    """Raises `RestoreValidationError`; returns a `ValidatedBackup` only when every check passed. Never touches anything."""
    now = now or utcnow()
    try:
        doc = parse_document(data, max_bytes)
        manifest = verify_integrity(doc)
    except BackupFormatError as exc:
        raise RestoreValidationError(exc.code, exc.detail) from None
    created, schema_version, app_version = _check_manifest(manifest, current_schema_version, now)
    tables = doc["tables"]
    if set(tables) != set(TABLE_NAMES):
        raise RestoreValidationError("incomplete", sorted(set(TABLE_NAMES) - set(tables))[0])
    if type(manifest.get("total_rows")) is not int or manifest["total_rows"] != sum(len(rows) for rows in tables.values()):
        raise RestoreValidationError("bad_manifest", "total_rows")
    _check_secrets(bytes(data).decode("utf-8"), tables, manifest, list(secrets))
    decoded: dict[str, list[dict[str, Any]]] = {}
    for name in TABLE_NAMES:
        decoded[name] = _check_rows(name, tables[name])
    group_ids = _check_groups(decoded)
    _check_uniques(decoded)
    return ValidatedBackup(manifest, decoded, created, schema_version, app_version,
                           str(manifest["tables_digest"])[:12], group_ids)


def _check_manifest(manifest: dict[str, Any], current: int, now: datetime) -> tuple[datetime, int, str]:
    version = manifest.get("schema_version")
    if type(version) is not int or version < 1:
        raise RestoreValidationError("bad_manifest", "schema_version")
    if version > current:
        raise RestoreValidationError("schema_too_new", f"{version}>{current}")
    if version < MIN_SCHEMA_VERSION:
        raise RestoreValidationError("schema_too_old", str(version))
    name = manifest.get("schema_name")
    if not isinstance(name, str) or _SCHEMA_NAME.fullmatch(name) is None or int(name[:4]) != version:
        raise RestoreValidationError("bad_manifest", "schema_name")
    app = manifest.get("app_version")
    if not isinstance(app, str) or not 1 <= len(app) <= _MAX_APP_VERSION or not app.isprintable():
        raise RestoreValidationError("bad_manifest", "app_version")
    text = manifest.get("created_at")
    if not isinstance(text, str) or _CREATED.fullmatch(text) is None:
        raise RestoreValidationError("bad_manifest", "created_at")
    try:
        created = datetime.strptime(text, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    except ValueError:
        raise RestoreValidationError("bad_manifest", "created_at") from None
    if created > now.astimezone(timezone.utc) + MAX_FUTURE_SKEW:
        raise RestoreValidationError("bad_manifest", "created_at_future")
    excluded = manifest.get("excluded")
    if not isinstance(excluded, list) or not all(isinstance(x, str) for x in excluded):
        raise RestoreValidationError("bad_manifest", "excluded")
    return created, version, app


def _check_secrets(text: str, tables: dict[str, list], manifest: dict[str, Any], secrets: list[str]) -> None:
    forms = _secret_forms(secrets)
    if not leaks_secret(text, forms):
        return
    if leaks_secret(canonical(manifest), forms):
        raise RestoreValidationError("secret_found", "manifest")
    for name in TABLE_NAMES:                    # name the table only, never the value
        if leaks_secret(canonical(tables[name]), forms):
            raise RestoreValidationError("secret_found", name)
    raise RestoreValidationError("secret_found")


def _check_rows(name: str, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    spec = BY_NAME[name]
    wanted = set(spec.column_names)
    seen: set[tuple] = set()
    out: list[dict[str, Any]] = []
    rules = RULES[name]
    for raw in rows:
        if set(raw) != wanted:
            raise RestoreValidationError("bad_columns", name)
        row: dict[str, Any] = {}
        for column in spec.columns:
            try:
                decode_value(column.kind, raw[column.name])   # strict type / timestamp-shape check
            except (ValueError, TypeError):
                raise RestoreValidationError("bad_value", f"{name}.{column.name}") from None
            row[column.name] = raw[column.name]
        key = tuple(row[k] for k in spec.key)
        if any(part is None for part in key):
            raise RestoreValidationError("bad_value", f"{name}.{spec.key[0]}")
        if key in seen:
            raise RestoreValidationError("duplicate_key", name)
        seen.add(key)
        for rule_name, ok in rules:
            try:
                good = bool(ok(row))
            except (KeyError, TypeError, ValueError):
                good = False
            if not good:
                raise RestoreValidationError("bad_rule", f"{name}.{rule_name}")
        out.append(row)
    return out


def _check_groups(decoded: dict[str, list[dict[str, Any]]]) -> tuple[int, ...]:
    groups = {row["group_id"] for row in decoded["telegram_groups"]}
    for name in GROUP_TABLES:
        for row in decoded[name]:
            if row["group_id"] not in groups:
                raise RestoreValidationError("orphan_row", name)
    return tuple(sorted(groups))


def _check_uniques(decoded: dict[str, list[dict[str, Any]]]) -> None:
    for unique in UNIQUES:
        seen: set[tuple] = set()
        for row in decoded[unique.table]:
            if unique.where is not None and not unique.where(row):
                continue
            key = tuple(row[c] for c in unique.columns)
            if any(part is None for part in key):
                continue
            if key in seen:
                raise RestoreValidationError("duplicate_key", f"{unique.table}.{unique.name}")
            seen.add(key)
