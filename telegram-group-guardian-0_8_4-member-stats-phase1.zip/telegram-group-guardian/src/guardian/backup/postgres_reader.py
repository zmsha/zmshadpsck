"""PostgreSQL reader for the backup collector (NOT executed against a real PostgreSQL in the build sandbox).

READ ONLY: one REPEATABLE READ read-only transaction for the whole backup (a consistent snapshot across tables), `SELECT`s
built from the static `TableSpec` registry (identifiers are validated at import; every value is a bind parameter). It
selects across ALL groups on purpose: only the owner-only backup (6.8b) may use it.
"""
from __future__ import annotations

import json
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator

from .format import JSON, TableSpec


def page_sql(spec: TableSpec, has_after: bool) -> str:
    cols = ", ".join(spec.column_names)
    key = ", ".join(spec.key)
    where = ""
    if has_after:
        marks = ", ".join(f"${i + 1}" for i in range(len(spec.key)))
        where = f" WHERE ({key}) > ({marks})" if len(spec.key) > 1 else f" WHERE {key} > $1"
    return f"SELECT {cols} FROM {spec.name}{where} ORDER BY {key} LIMIT ${len(spec.key) + 1 if has_after else 1}"


class _Snapshot:
    def __init__(self, conn: Any) -> None:
        self._conn = conn

    async def read_page(self, spec: TableSpec, after: tuple | None, limit: int) -> list[dict[str, Any]]:
        args: list[Any] = list(after) if after is not None else []
        args.append(int(limit))
        records = await self._conn.fetch(page_sql(spec, after is not None), *args)
        json_cols = [c.name for c in spec.columns if c.kind == JSON]
        rows: list[dict[str, Any]] = []
        for record in records:
            row = {name: record[name] for name in spec.column_names}
            for name in json_cols:  # asyncpg returns jsonb as TEXT unless a codec is set
                if isinstance(row[name], (str, bytes, bytearray)):
                    row[name] = json.loads(row[name])
            rows.append(row)
        return rows


class PostgresBackupReader:
    def __init__(self, database: Any) -> None:
        self._db = database

    @asynccontextmanager
    async def snapshot(self) -> AsyncIterator[_Snapshot]:
        async with self._db.acquire() as conn:
            async with conn.transaction(isolation="repeatable_read", readonly=True):
                yield _Snapshot(conn)
