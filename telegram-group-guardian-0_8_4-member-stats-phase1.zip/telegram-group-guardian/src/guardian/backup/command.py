"""`/backup` in the owner's PRIVATE chat (part 6.8b): parsing and the localized replies.

    /backup                      preview what a backup holds + a single-use code      نسخة احتياطية
    /backup confirm <code>       build it and send the file HERE (once)               تأكيد نسخة <الرمز>

The parser only RECOGNISES text (private chat, a real sender); who may use it is decided by `BackupService`: anybody but
exactly OWNER_TELEGRAM_ID gets SILENCE. There is no group form, no menu entry (a private owner command like `/template`),
and nothing is ever sent to `OWNER_GROUP_ID` or any other chat.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import Any

from ..i18n import t
from ..moderation.arabic import fold_arabic
from . import service as svc
from .format import MAX_BACKUP_BYTES, TABLES

log = logging.getLogger(__name__)

MAX_COMMAND_LEN = 100
_CODE = re.compile(r"[A-Za-z0-9]{4,12}", re.ASCII)
_AR_COPY = fold_arabic("نسخة")
_AR_BACKUP = frozenset({fold_arabic("احتياطية"), fold_arabic("احتياطي")})
_AR_CONFIRM = fold_arabic("تأكيد")


@dataclass(frozen=True, slots=True)
class ParsedBackupCommand:
    action: str                 # preview | confirm | usage
    code: str | None = None


def parse_backup_command(text: object, bot_username: str | None = None) -> ParsedBackupCommand | None:
    """The parsed `/backup ...` or Arabic form, or None (ordinary chat / another bot's command)."""
    if not isinstance(text, str) or not text.strip() or len(text) > MAX_COMMAND_LEN:
        return None
    words = text.split()
    if text.lstrip().startswith("/"):
        name, at, target = words[0][1:].partition("@")
        if name.lower() != "backup":
            return None
        if at and (not bot_username or target.lower() != bot_username.lower()):
            return None
        rest = words[1:]
        if not rest:
            return ParsedBackupCommand("preview")
        if rest[0].lower() == "confirm" and len(rest) == 2 and _CODE.fullmatch(rest[1]):
            return ParsedBackupCommand("confirm", rest[1].upper())
        return ParsedBackupCommand("usage")
    folded = [fold_arabic(w) for w in words]
    if len(words) == 2 and folded[0] == _AR_COPY and folded[1] in _AR_BACKUP:
        return ParsedBackupCommand("preview")
    if len(words) == 3 and folded[0] == _AR_CONFIRM and folded[1] == _AR_COPY:
        return ParsedBackupCommand("confirm", words[2].upper()) if _CODE.fullmatch(words[2]) else ParsedBackupCommand("usage")
    return None


@dataclass(frozen=True, slots=True)
class BackupReply:
    status: str
    text: str


class BackupCommandService:
    def __init__(self, service: Any, *, language: str = "ar") -> None:
        self._service, self._language = service, language

    async def run(self, parsed: ParsedBackupCommand, *, chat_id: object, chat_type: object, user_id: object, message_id: object,
                  lang: str | None = None) -> BackupReply | None:
        """None = answer nothing (not a private chat, not the owner, a redelivered update)."""
        lang = lang or self._language
        if chat_type != "private" or not isinstance(chat_id, int) or isinstance(chat_id, bool) or chat_id <= 0 or chat_id != user_id:
            return None
        try:
            if parsed.action == "usage":
                if not await self._service.is_owner(user_id):      # even the usage text is for the owner only
                    return None
                return BackupReply("usage", t("bk_usage", lang))
            if parsed.action == "preview":
                out = await self._service.prepare(user_id)
            else:
                out = await self._service.confirm(user_id, parsed.code, message_id)
        except Exception:
            log.error("backup command failed", exc_info=True)
            return BackupReply("failed", t("bk_failed", lang))
        return None if out is None else self._reply(out, lang)

    @staticmethod
    def _reply(out: Any, lang: str) -> BackupReply:
        s = out.status
        if s == svc.PREVIEW:
            return BackupReply(s, t("bk_preview", lang, tables=str(len(TABLES)), max=str(MAX_BACKUP_BYTES // (1024 * 1024)),
                                    minutes=str(out.minutes), code=out.code))
        if s == svc.SENT:
            text = t("bk_sent", lang, rows=str(out.rows), kb=str(max(1, out.size // 1024)))
            if out.flags:
                text += "\n" + t("bk_sent_flags", lang, tables=", ".join(out.flags))
            return BackupReply(s, text)
        if s == svc.COOLDOWN:
            return BackupReply(s, t("bk_cooldown", lang, seconds=str(out.wait_seconds)))
        keys = {svc.UNKNOWN_CODE: "bk_unknown_code", svc.BUSY: "bk_busy", svc.UNAVAILABLE: "bk_unavailable",
                svc.SECRET_FOUND: "bk_secret", svc.TOO_MANY: "bk_too_large", "private_not_started": "bk_private_not_started",
                "rejected": "bk_rejected", "corrupt": "bk_corrupt", "duplicate": "bk_duplicate"}
        return BackupReply(s, t(keys.get(s, "bk_failed"), lang))
