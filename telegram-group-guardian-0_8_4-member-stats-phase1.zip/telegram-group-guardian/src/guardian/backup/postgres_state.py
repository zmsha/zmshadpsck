"""PostgreSQL reader of the CURRENT state for the restore preview (NOT executed against a real PostgreSQL in the build sandbox).

READ ONLY: one REPEATABLE READ read-only transaction; only `SELECT` of counts and licence states, built from the static table
lists in `preview.py` (identifiers are checked at import; there are no values to bind). It crosses groups on purpose and is
used only by the owner-only `/restore` preview.
"""
from __future__ import annotations

import re
from typing import Any

from .format import encode_timestamp
from .preview import COUNTED_PER_GROUP, GLOBAL_REPLACED, CurrentGroup, CurrentState

_IDENT = re.compile(r"^[a-z][a-z0-9_]*$")
assert all(_IDENT.match(t) for t in COUNTED_PER_GROUP + GLOBAL_REPLACED)

GROUPS_SQL = "SELECT group_id, license_status, expires_at FROM telegram_groups ORDER BY group_id"


def count_sql(table: str) -> str:
    if table not in COUNTED_PER_GROUP:
        raise ValueError("not a per-group table")
    return f"SELECT group_id, count(*) AS n FROM {table} GROUP BY group_id"


def global_count_sql(table: str) -> str:
    if table not in GLOBAL_REPLACED:
        raise ValueError("not a global table")
    return f"SELECT count(*) AS n FROM {table}"


DEFAULTS_VERSION_SQL = "SELECT max(version) AS v FROM global_default_settings"


async def read_state_on(conn: Any) -> CurrentState:
    """The current state on an ALREADY OPEN connection (SELECT only). Shared with the restore transaction, which re-reads inside its locks."""
    groups = {int(r["group_id"]): CurrentGroup(str(r["license_status"]),
                                               encode_timestamp(r["expires_at"]) if r["expires_at"] is not None else None)
              for r in await conn.fetch(GROUPS_SQL)}
    counts = {t: {int(r["group_id"]): int(r["n"]) for r in await conn.fetch(count_sql(t))} for t in COUNTED_PER_GROUP}
    global_counts: dict[str, int] = {}
    for t in GLOBAL_REPLACED:
        rows = await conn.fetch(global_count_sql(t))
        global_counts[t] = int(rows[0]["n"]) if rows else 0
    version_rows = await conn.fetch(DEFAULTS_VERSION_SQL)
    version = version_rows[0]["v"] if version_rows else None
    return CurrentState(groups, counts, global_counts, int(version) if version is not None else None)


class PostgresRestoreStateReader:
    def __init__(self, database: Any) -> None:
        self._db = database

    async def read(self) -> CurrentState:
        async with self._db.acquire() as conn:
            async with conn.transaction(isolation="repeatable_read", readonly=True):
                return await read_state_on(conn)
