"""Logging with secret redaction applied to the FINAL formatted line (incl. tracebacks)."""
from __future__ import annotations

import logging
import re
import sys
from typing import Iterable

REDACTED = "***"
# No leading \b: Bot API URLs look like ".../bot<token>/method" (letter right before the digits).
_TOKEN_RE = re.compile(r"(?<!\d)\d{5,}:[A-Za-z0-9_-]{20,}")
_URL_CREDS_RE = re.compile(r"(?P<scheme>[a-zA-Z][a-zA-Z0-9+.-]*://)(?P<user>[^:/@\s]*):(?P<pw>[^@\s]+)@")


def redact(text: str, secrets: Iterable[str] = ()) -> str:
    """Remove known secrets, bot-token-shaped strings and URL passwords from `text`."""
    for secret in sorted({s for s in secrets if s}, key=len, reverse=True):
        text = text.replace(secret, REDACTED)
    text = _TOKEN_RE.sub(REDACTED, text)
    return _URL_CREDS_RE.sub(lambda m: f"{m.group('scheme')}{m.group('user')}:{REDACTED}@", text)


class RedactingFormatter(logging.Formatter):
    def __init__(self, secrets: Iterable[str] = ()):
        super().__init__("%(asctime)s %(levelname)s %(name)s %(message)s", "%Y-%m-%dT%H:%M:%S%z")
        self._secrets = tuple(secrets)

    def format(self, record: logging.LogRecord) -> str:
        return redact(super().format(record), self._secrets)


def configure_logging(level: str = "INFO", secrets: Iterable[str] = ()) -> None:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(RedactingFormatter(secrets))
    root = logging.getLogger()
    root.handlers[:] = [handler]
    root.setLevel(level)
    # Library loggers can include request URLs (the bot token appears in Bot API URLs),
    # so never let them go below INFO even when the app runs at DEBUG.
    floor = max(logging.getLevelName(level), logging.INFO)
    for noisy in ("aiogram", "httpx", "httpcore", "asyncio", "uvicorn.access"):
        logging.getLogger(noisy).setLevel(floor)
