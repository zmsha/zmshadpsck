"""telegram-group-guardian: multi-group Telegram protection bot (working name)."""

__version__ = "0.8.4-phase8-complete"
