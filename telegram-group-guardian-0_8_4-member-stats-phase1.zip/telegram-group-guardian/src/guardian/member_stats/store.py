"""Persistence contract of the member statistics. EVERY method takes `group_id`; none ever touches another group's rows."""
from __future__ import annotations

from datetime import date, datetime
from typing import Protocol

from .models import GroupTotals, MemberEvent, MemberStats


class MemberStatsStore(Protocol):
    async def record(self, group_id: int, user_id: int, event: MemberEvent, day: date, now: datetime,
                     amount: int = 1) -> None:
        """Add `amount` (>= 1) to the member's counter, creating the record on first use (one atomic upsert).
        `MESSAGE` also adds to today's count (restarting it when `day` is a new day) and sets the last activity."""
        ...

    async def get(self, group_id: int, user_id: int, day: date) -> MemberStats | None:
        """The member's record in THIS group (None: never seen here). `today_messages` is 0 unless it was counted on `day`."""
        ...

    async def top(self, group_id: int, limit: int, day: date) -> list[MemberStats]:
        """The most active members of this group by total messages (ties: lower user id first), at most `limit`."""
        ...

    async def totals(self, group_id: int, day: date) -> GroupTotals:
        """Sums over the members of this group."""
        ...
