"""Value types of the permanent member statistics (one record per group and member)."""
from __future__ import annotations

import enum
from dataclasses import dataclass
from datetime import datetime


class MemberEvent(str, enum.Enum):
    """Closed vocabulary of what is counted. Each value maps to ONE column of `member_activity_stats` (never user text)."""
    MESSAGE = "message"
    DELETED = "deleted"
    VIOLATION = "violation"
    WARNING = "warning"
    MUTE = "mute"
    BAN = "ban"


EVENT_COLUMN: dict[MemberEvent, str] = {
    MemberEvent.MESSAGE: "total_messages",
    MemberEvent.DELETED: "deleted_messages",
    MemberEvent.VIOLATION: "violations",
    MemberEvent.WARNING: "warnings",
    MemberEvent.MUTE: "mutes",
    MemberEvent.BAN: "bans",
}

DEFAULT_TOP = 10
MAX_TOP = 20


@dataclass(frozen=True, slots=True)
class MemberStats:
    """One member's numbers inside ONE group. `today_messages` is already resolved against the day it was read for."""
    group_id: int
    user_id: int
    total_messages: int = 0
    today_messages: int = 0
    deleted_messages: int = 0
    violations: int = 0
    warnings: int = 0
    mutes: int = 0
    bans: int = 0
    last_activity_at: datetime | None = None
    first_seen_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class GroupTotals:
    """The sum over the members of ONE group."""
    group_id: int
    members: int = 0
    total_messages: int = 0
    today_messages: int = 0
    deleted_messages: int = 0
    violations: int = 0
    warnings: int = 0
    mutes: int = 0
    bans: int = 0
    last_activity_at: datetime | None = None
