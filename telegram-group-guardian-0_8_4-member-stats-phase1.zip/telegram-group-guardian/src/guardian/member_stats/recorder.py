"""Best-effort writer of the member statistics. It is called from hot paths (the update middleware, the protection engine,
the content filter and the warning/sanction stores), so it NEVER raises and never changes a decision: a failed write only
costs one tick of a statistic.

Counted exactly once:
 * a message is claimed per (group, message id) in the durable idempotency store, so a Telegram redelivery, a second pass
   over the same update or an edit (edits never reach `message()`) cannot add a second tick; when the claim store is down the
   tick is skipped (a lost tick is better than a double one);
 * a violation and a deletion are claimed separately per (group, message id): the content filter and the engine may both look
   at one message, and the message still counts as ONE violation and ONE deletion;
 * warnings / mutes / bans are counted by `tracking.py` only when the underlying store reports that a NEW row was created
   (those stores are idempotent per key), so a repeated command or key never counts twice.
"""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Callable

from ..idempotency import operation_key
from ..moderation.models import check_group_id
from ..stats.models import day_bucket
from ..time_utils import utcnow
from .models import MemberEvent
from .store import MemberStatsStore

log = logging.getLogger(__name__)


def _pos_int(value: object) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value > 0


class MemberStatsRecorder:
    def __init__(self, store: MemberStatsStore, claims=None, display_timezone: str = "Asia/Riyadh",
                 clock: Callable[[], datetime] = utcnow) -> None:
        self._store, self._claims, self._tz, self._clock = store, claims, display_timezone, clock

    async def _first(self, kind: str, group_id: int, message_id: int, at: datetime) -> bool:
        if self._claims is None:
            return True
        try:
            return bool(await self._claims.claim(operation_key(kind, group_id, message_id), at))
        except Exception:
            log.warning("member stats claim unavailable; tick skipped", extra={"group_id": group_id})
            return False

    async def _write(self, group_id: int, user_id: int, event: MemberEvent, at: datetime) -> bool:
        try:
            await self._store.record(group_id, user_id, event, day_bucket(at, self._tz), at, 1)
            return True
        except Exception:
            log.warning("member stats write failed event=%s", event.value, extra={"group_id": group_id}, exc_info=True)
            return False

    async def message(self, group_id: int, user_id: int, message_id: int, now: datetime | None = None) -> bool:
        """One NEW message of `user_id` in `group_id`. True when it was counted."""
        try:
            check_group_id(group_id)
            if not _pos_int(user_id) or not _pos_int(message_id):
                return False
            at = now or self._clock()
            if not await self._first("ustat-msg", group_id, message_id, at):
                return False
            return await self._write(group_id, user_id, MemberEvent.MESSAGE, at)
        except Exception:
            log.warning("member stats message tick failed", extra={"group_id": group_id}, exc_info=True)
            return False

    async def message_acted_on(self, group_id: int, user_id: int, message_id: int, deleted: bool,
                               now: datetime | None = None) -> None:
        """The bot acted on this message (a violation); `deleted` when it also removed it."""
        try:
            check_group_id(group_id)
            if not _pos_int(user_id) or not _pos_int(message_id):
                return
            at = now or self._clock()
            if await self._first("ustat-viol", group_id, message_id, at):
                await self._write(group_id, user_id, MemberEvent.VIOLATION, at)
            if deleted and await self._first("ustat-del", group_id, message_id, at):
                await self._write(group_id, user_id, MemberEvent.DELETED, at)
        except Exception:
            log.warning("member stats violation tick failed", extra={"group_id": group_id}, exc_info=True)

    async def event(self, group_id: int, user_id: int, event: MemberEvent, now: datetime | None = None) -> bool:
        """A warning / mute / ban that was REALLY created (the caller already knows it is new)."""
        try:
            check_group_id(group_id)
            if not _pos_int(user_id):
                return False
            return await self._write(group_id, user_id, MemberEvent(event), now or self._clock())
        except Exception:
            log.warning("member stats event tick failed", extra={"group_id": group_id}, exc_info=True)
            return False
