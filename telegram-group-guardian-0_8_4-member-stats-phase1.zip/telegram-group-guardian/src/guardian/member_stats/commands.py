"""Parser of the three member-statistics commands (text recognition only; WHO may use them is decided by the service).

    /userstats [<id>|@user]    /احصائيات_عضو      per-member record in this group (reply to the member, or an id / @username)
    /topmembers [N]            /اكثر_الاعضاء      the N (1..20, default 10) most active members of this group
    /groupstats                /احصائيات_القروب   the sums over the members of this group

Slash forms accept the English name or the Arabic name written with underscores or with spaces; the bare Arabic forms
(`احصائيات عضو`, `اكثر الاعضاء`, `احصائيات القروب`) need no slash. Alef/hamza, ta marbuta/ha and ya/alef maqsura are interchangeable
(`fold_arabic`). In the owner's PRIVATE chat the group is named by a leading group id (`/groupstats -1001234567890`); inside a group
it is always that group.

A bare Arabic phrase is a command only when everything after it is the command's own vocabulary, so ordinary talk that merely
starts with the words is not swallowed.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from ..moderation.arabic import fold_arabic

MAX_TEXT_LEN = 120
MAX_ARGS = 3
USER, TOP, GROUP = "user", "top", "group"

_GROUP_ID = re.compile(r"^-\d{3,19}$")
_NUMBER = re.compile(r"^\d{1,19}$")
_USERNAME = re.compile(r"^@[A-Za-z][A-Za-z0-9_]{4,31}$")


def _fold(*words: str) -> frozenset[str]:
    return frozenset(fold_arabic(w) for w in words)


_STATS_WORDS = _fold("احصائيات", "إحصائيات", "احصاءات", "إحصاءات", "احصائية", "إحصائية")
_USER_WORDS = _fold("عضو", "العضو", "مستخدم", "المستخدم")
_GROUP_WORDS = _fold("القروب", "قروب", "الجروب", "جروب", "المجموعة", "مجموعة", "المجموعه", "الكروب", "كروب")
_TOP_FIRST = _fold("اكثر", "أكثر", "الاكثر", "الأكثر")
_TOP_SECOND = _fold("الاعضاء", "الأعضاء", "اعضاء", "أعضاء")
_ACTIVE = fold_arabic("نشاطا")

_SLASH = {
    "userstats": USER, "user_stats": USER, "memberstats": USER,
    "topmembers": TOP, "top_members": TOP,
    "groupstats": GROUP, "group_stats": GROUP,
}
_SLASH_AR = {
    **{fold_arabic(name): USER for name in ("احصائيات_عضو", "احصائيات_العضو", "احصاءات_عضو", "احصاءات_العضو",
                                           "إحصائيات_عضو", "إحصائيات_العضو")},
    **{fold_arabic(name): TOP for name in ("اكثر_الاعضاء", "أكثر_الأعضاء", "اكثر_اعضاء", "أكثر_أعضاء",
                                          "اكثر_الاعضاء_نشاطا", "أكثر_الأعضاء_نشاطًا")},
    **{fold_arabic(name): GROUP for name in ("احصائيات_القروب", "إحصائيات_القروب", "احصائيات_الجروب", "إحصائيات_الجروب",
                                            "احصائيات_المجموعة", "إحصائيات_المجموعة", "احصاءات_القروب", "احصاءات_المجموعة")},
}


@dataclass(frozen=True, slots=True)
class ParsedMemberStats:
    kind: str                 # user | top | group
    args: tuple[str, ...]     # the words after the command, as typed
    slash: bool               # typed as /command (a malformed slash command gets a usage message; bare Arabic talk is ignored)


def _args_ok(kind: str, args: tuple[str, ...]) -> bool:
    """Is `args` made only of this command's own vocabulary? (group id, then a target / a number.)"""
    rest = list(args)
    if rest and _GROUP_ID.match(rest[0]):
        rest = rest[1:]
    if kind == GROUP:
        return not rest
    if kind == TOP:
        return not rest or (len(rest) == 1 and bool(_NUMBER.match(rest[0])))
    return len(rest) <= 1 and (not rest or bool(_NUMBER.match(rest[0]) or _USERNAME.match(rest[0])))


def parse_member_stats_command(text: object, bot_username: str | None = None) -> ParsedMemberStats | None:
    if not isinstance(text, str):
        return None
    stripped = text.strip()
    if not stripped or len(stripped) > MAX_TEXT_LEN:
        return None
    words = stripped.split()
    slash = stripped.startswith("/")
    if slash:
        head, at, target = words[0][1:].partition("@")
        if at and (not bot_username or target.lower() != bot_username.lower()):
            return None  # addressed to another bot (or we do not know our own name)
        words = [head, *words[1:]]
        kind = _SLASH.get(head.lower()) or _SLASH_AR.get(fold_arabic(head))
        if kind is not None:  # `/userstats ...`, `/احصائيات_عضو ...`
            return ParsedMemberStats(kind, tuple(words[1:MAX_ARGS + 2]), True)
    return _spoken(words, slash)


def _spoken(words: list[str], slash: bool) -> ParsedMemberStats | None:
    """The Arabic phrases written with spaces (`احصائيات عضو`, `/اكثر الاعضاء`, ...); `words[0]` is the first phrase word."""
    folded = [fold_arabic(w) for w in words]
    if len(folded) < 2:
        return None
    first, second = folded[0], folded[1]
    kind, used = None, 2
    if first in _TOP_FIRST and second in _TOP_SECOND:
        kind = TOP
        if len(folded) > 2 and folded[2] == _ACTIVE:
            used = 3
    elif first in _STATS_WORDS and second in _USER_WORDS:
        kind = USER
    elif first in _STATS_WORDS and second in _GROUP_WORDS:
        kind = GROUP
    if kind is None:
        return None
    tail = tuple(words[used:MAX_ARGS + used + 1])
    if not slash and not _args_ok(kind, tail):
        return None  # ordinary talk that merely starts with the words
    return ParsedMemberStats(kind, tail, slash)
