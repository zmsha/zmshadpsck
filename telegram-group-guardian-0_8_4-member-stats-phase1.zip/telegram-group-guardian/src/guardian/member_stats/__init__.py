"""Permanent per-member statistics (statistics phase 1).

One record per (group, member) in `member_activity_stats` (migration 0013): messages, today's messages, messages the bot deleted,
violations, warnings, mutes, bans and the last activity. Records are never merged across groups and are kept when the member
leaves and comes back. `recorder.py` writes (best effort, exactly once per message / created row), `tracking.py` feeds warnings,
mutes and bans from the stores that really record them, and `service.py` answers the three owner-only commands.
"""
from .models import DEFAULT_TOP, MAX_TOP, GroupTotals, MemberEvent, MemberStats  # noqa: F401
from .recorder import MemberStatsRecorder  # noqa: F401
