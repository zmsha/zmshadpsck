"""In-memory member statistics (tests / local experiments only; state is lost on restart)."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime

from .models import EVENT_COLUMN, GroupTotals, MemberEvent, MemberStats


@dataclass
class _Row:
    total_messages: int = 0
    today_date: date | None = None
    today_messages: int = 0
    deleted_messages: int = 0
    violations: int = 0
    warnings: int = 0
    mutes: int = 0
    bans: int = 0
    last_activity_at: datetime | None = None
    first_seen_at: datetime | None = None


class InMemoryMemberStatsStore:
    def __init__(self) -> None:
        self._rows: dict[tuple[int, int], _Row] = {}

    async def record(self, group_id, user_id, event, day, now, amount=1) -> None:
        event = MemberEvent(event)
        amount = int(amount)
        if amount < 1:
            raise ValueError("amount must be >= 1")
        row = self._rows.setdefault((group_id, user_id), _Row(first_seen_at=now))
        column = EVENT_COLUMN[event]
        setattr(row, column, getattr(row, column) + amount)
        if event is MemberEvent.MESSAGE:
            row.today_messages = row.today_messages + amount if row.today_date == day else amount
            row.today_date = day
            if row.last_activity_at is None or now > row.last_activity_at:
                row.last_activity_at = now

    @staticmethod
    def _view(group_id: int, user_id: int, row: _Row, day: date) -> MemberStats:
        return MemberStats(group_id, user_id, row.total_messages, row.today_messages if row.today_date == day else 0,
                           row.deleted_messages, row.violations, row.warnings, row.mutes, row.bans,
                           row.last_activity_at, row.first_seen_at)

    async def get(self, group_id, user_id, day) -> MemberStats | None:
        row = self._rows.get((group_id, user_id))
        return None if row is None else self._view(group_id, user_id, row, day)

    async def top(self, group_id, limit, day) -> list[MemberStats]:
        mine = [self._view(g, u, r, day) for (g, u), r in self._rows.items() if g == group_id]
        mine.sort(key=lambda m: (-m.total_messages, m.user_id))
        return mine[:max(0, int(limit))]

    async def totals(self, group_id, day) -> GroupTotals:
        rows = [self._view(g, u, r, day) for (g, u), r in self._rows.items() if g == group_id]
        last = [m.last_activity_at for m in rows if m.last_activity_at is not None]
        return GroupTotals(group_id, len(rows), sum(m.total_messages for m in rows), sum(m.today_messages for m in rows),
                           sum(m.deleted_messages for m in rows), sum(m.violations for m in rows),
                           sum(m.warnings for m in rows), sum(m.mutes for m in rows), sum(m.bans for m in rows),
                           max(last) if last else None)
