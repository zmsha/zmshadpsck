"""Store decorators that feed the member statistics from the places where warnings, mutes and bans are REALLY recorded.

Wrapping the stores (instead of every caller) covers the automatic engine, the content filter and the manual commands with one
rule: a tick happens only when the inner store says a NEW row was created. The stores are idempotent per key, so a redelivered
command or a repeated key reports `created=False` and is not counted. Everything else is delegated unchanged; a recorder
failure never changes the result the caller gets.
"""
from __future__ import annotations

import logging
from typing import Any

from ..moderation.models import SanctionKind
from .models import MemberEvent

log = logging.getLogger(__name__)

_SANCTION_EVENT = {SanctionKind.MUTE: MemberEvent.MUTE, SanctionKind.BAN: MemberEvent.BAN}  # a kick is not counted
_LEDGER_EVENT = {"ban": MemberEvent.BAN, "mute": MemberEvent.MUTE, "warn": MemberEvent.WARNING}


class _Delegating:
    def __init__(self, inner: Any, recorder: Any) -> None:
        self._inner, self._recorder = inner, recorder

    def __getattr__(self, name: str):
        return getattr(self._inner, name)

    async def _tick(self, group_id: int, user_id: int, event: MemberEvent, now) -> None:
        """Statistics only: whatever happens here, the caller still gets the inner store's result."""
        try:
            await self._recorder.event(group_id, user_id, event, now)
        except Exception:
            log.warning("member stats tick failed", extra={"group_id": group_id}, exc_info=True)


class TrackingWarningStore(_Delegating):
    async def add(self, group_id, user_id, issued_by, reason, now, expires_at=None, idempotency_key=None):
        warning, created = await self._inner.add(group_id, user_id, issued_by, reason, now, expires_at, idempotency_key)
        if created:
            await self._tick(group_id, user_id, MemberEvent.WARNING, now)
        return warning, created


class TrackingSanctionStore(_Delegating):
    async def record(self, group_id, user_id, kind, issued_by, reason, now, expires_at=None, violation=None,
                     idempotency_key=None):
        sanction, created = await self._inner.record(group_id, user_id, kind, issued_by, reason, now, expires_at, violation,
                                                     idempotency_key)
        event = _SANCTION_EVENT.get(kind)
        if created and event is not None:
            await self._tick(group_id, user_id, event, now)
        return sanction, created


class TrackingContentLedger(_Delegating):
    """The content filter keeps its own ledger of what it did; its `ban` rows are bans, its `mute` rows are mutes and its `warn` rows (a first offense) are warnings."""

    async def record(self, group_id, user_id, source, category, action, now, idempotency_key=None):
        created = await self._inner.record(group_id, user_id, source, category, action, now, idempotency_key)
        event = _LEDGER_EVENT.get(action)
        if created and event is not None:
            await self._tick(group_id, user_id, event, now)
        return created
