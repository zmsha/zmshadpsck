"""PostgreSQL member statistics (NOT executed against a real PostgreSQL in the build sandbox). Every statement filters by
`group_id` (or inserts it as $1); column names come only from the closed `EVENT_COLUMN` table, never from input."""
from __future__ import annotations

from datetime import date, datetime

from .models import EVENT_COLUMN, GroupTotals, MemberEvent, MemberStats

_T = "member_activity_stats"

_MESSAGE_SQL = (
    f"INSERT INTO {_T} (group_id, user_id, total_messages, today_date, today_messages, last_activity_at, "
    "first_seen_at, updated_at) VALUES ($1, $2, $3, $4, $3, $5, $5, $5) "
    "ON CONFLICT (group_id, user_id) DO UPDATE SET "
    f"total_messages = {_T}.total_messages + EXCLUDED.total_messages, "
    f"today_messages = CASE WHEN {_T}.today_date = EXCLUDED.today_date "
    f"THEN {_T}.today_messages + EXCLUDED.today_messages ELSE EXCLUDED.today_messages END, "
    "today_date = EXCLUDED.today_date, "
    f"last_activity_at = GREATEST(COALESCE({_T}.last_activity_at, EXCLUDED.last_activity_at), EXCLUDED.last_activity_at), "
    "updated_at = EXCLUDED.updated_at"
)


def _counter_sql(column: str) -> str:
    return (f"INSERT INTO {_T} (group_id, user_id, {column}, first_seen_at, updated_at) VALUES ($1, $2, $3, $4, $4) "
            f"ON CONFLICT (group_id, user_id) DO UPDATE SET {column} = {_T}.{column} + EXCLUDED.{column}, "
            "updated_at = EXCLUDED.updated_at")


COUNTER_SQL = {event: _counter_sql(column) for event, column in EVENT_COLUMN.items() if event is not MemberEvent.MESSAGE}

_COLUMNS = ("user_id, total_messages, CASE WHEN today_date = $2 THEN today_messages ELSE 0 END AS today_messages, "
            "deleted_messages, violations, warnings, mutes, bans, last_activity_at, first_seen_at")
_GET_SQL = f"SELECT {_COLUMNS} FROM {_T} WHERE group_id = $1 AND user_id = $3"
_TOP_SQL = f"SELECT {_COLUMNS} FROM {_T} WHERE group_id = $1 ORDER BY total_messages DESC, user_id ASC LIMIT $3"
_TOTALS_SQL = (
    "SELECT count(*) AS members, COALESCE(sum(total_messages), 0) AS total_messages, "
    "COALESCE(sum(CASE WHEN today_date = $2 THEN today_messages ELSE 0 END), 0) AS today_messages, "
    "COALESCE(sum(deleted_messages), 0) AS deleted_messages, COALESCE(sum(violations), 0) AS violations, "
    "COALESCE(sum(warnings), 0) AS warnings, COALESCE(sum(mutes), 0) AS mutes, COALESCE(sum(bans), 0) AS bans, "
    f"max(last_activity_at) AS last_activity_at FROM {_T} WHERE group_id = $1"
)


def _member(group_id: int, r) -> MemberStats:
    return MemberStats(group_id, int(r["user_id"]), int(r["total_messages"]), int(r["today_messages"]),
                       int(r["deleted_messages"]), int(r["violations"]), int(r["warnings"]), int(r["mutes"]),
                       int(r["bans"]), r["last_activity_at"], r["first_seen_at"])


class PostgresMemberStatsStore:
    def __init__(self, database) -> None:
        self._db = database

    async def record(self, group_id, user_id, event, day: date, now: datetime, amount=1) -> None:
        event, amount = MemberEvent(event), int(amount)
        if amount < 1:
            raise ValueError("amount must be >= 1")
        async with self._db.acquire() as conn:
            if event is MemberEvent.MESSAGE:
                await conn.execute(_MESSAGE_SQL, group_id, user_id, amount, day, now)
            else:
                await conn.execute(COUNTER_SQL[event], group_id, user_id, amount, now)

    async def get(self, group_id, user_id, day) -> MemberStats | None:
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(_GET_SQL, group_id, day, user_id)
        return None if row is None else _member(group_id, row)

    async def top(self, group_id, limit, day) -> list[MemberStats]:
        async with self._db.acquire() as conn:
            rows = await conn.fetch(_TOP_SQL, group_id, day, max(0, int(limit)))
        return [_member(group_id, r) for r in rows]

    async def totals(self, group_id, day) -> GroupTotals:
        async with self._db.acquire() as conn:
            r = await conn.fetchrow(_TOTALS_SQL, group_id, day)
        if r is None:
            return GroupTotals(group_id)
        return GroupTotals(group_id, int(r["members"]), int(r["total_messages"]), int(r["today_messages"]),
                           int(r["deleted_messages"]), int(r["violations"]), int(r["warnings"]), int(r["mutes"]),
                           int(r["bans"]), r["last_activity_at"])
