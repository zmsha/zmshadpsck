"""`/userstats` · `/topmembers` · `/groupstats` (and their Arabic names) for the PRIMARY OWNER only.

Fail closed, and a refusal is SILENCE (like `/owner`): nobody else, not even a group administrator, gets a reply, a hint or a
mention in the help texts.
 1. private chat (with `chat_id == user_id`) or a group/supergroup                    -> else None
 2. `Permission.OWNER_PANEL` through `check_global` (exactly OWNER_TELEGRAM_ID; the permission service audits a refusal) -> else None
 3. the group: the chat itself inside a group; in private a leading group id is required -> usage message
 4. strict argument parsing -> usage message; nothing is guessed
 5. the read, ALWAYS keyed by (group id, member id): one group's numbers never include another group's

Reads only: nothing is written and no licence is needed (the owner works even when a group's licence ended; the numbers are the
stored data of that group). A member who left, was kicked or banned keeps the record, so it can still be read.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Callable

from ..i18n import Raw, t
from ..moderation.targets import ReplyInfo, TargetError, TargetInput, extract_target_id
from ..permissions import Permission
from ..stats.models import day_bucket
from ..time_utils import format_display, utcnow
from .commands import GROUP, TOP, USER, ParsedMemberStats, _GROUP_ID
from .models import DEFAULT_TOP, MAX_TOP, GroupTotals, MemberStats
from .store import MemberStatsStore

log = logging.getLogger(__name__)

GROUP_CHAT_TYPES = ("group", "supergroup")


@dataclass(frozen=True, slots=True)
class MemberStatsReply:
    status: str  # ok | usage | empty | unavailable
    text: str


def _mention(user_id: int) -> Raw:
    return Raw(f'<a href="tg://user?id={user_id}">{user_id}</a>')


def _last(value, tz: str, lang: str) -> str:
    return format_display(value, tz) if value is not None else t("ms_never", lang)


def render_member(m: MemberStats, tz: str, lang: str) -> str:
    return t("ms_user", lang, user=_mention(m.user_id), group=str(m.group_id), total=m.total_messages, today=m.today_messages,
             deleted=m.deleted_messages, violations=m.violations, warnings=m.warnings, mutes=m.mutes, bans=m.bans,
             last=_last(m.last_activity_at, tz, lang))


def render_group(g: GroupTotals, tz: str, lang: str) -> str:
    return t("ms_group", lang, group=str(g.group_id), members=g.members, total=g.total_messages, today=g.today_messages,
             deleted=g.deleted_messages, violations=g.violations, warnings=g.warnings, mutes=g.mutes, bans=g.bans,
             last=_last(g.last_activity_at, tz, lang))


def render_top(group_id: int, rows: list[MemberStats], lang: str) -> str:
    lines = [t("ms_top_title", lang, group=str(group_id), n=len(rows))]
    for rank, m in enumerate(rows, 1):
        lines.append(t("ms_top_row", lang, rank=rank, user=_mention(m.user_id), total=m.total_messages, today=m.today_messages,
                       violations=m.violations, warnings=m.warnings))
    return "\n".join(lines)


class MemberStatsCommandService:
    def __init__(self, *, store: MemberStatsStore, permissions: Any, usernames: Any = None, language: str = "ar",
                 display_timezone: str = "Asia/Riyadh", clock: Callable[[], Any] = utcnow):
        self._store, self._perm, self._usernames = store, permissions, usernames
        self._language, self._tz, self._clock = language, display_timezone, clock

    async def _is_owner(self, user_id: object) -> bool:
        try:
            return bool((await self._perm.check_global(user_id, Permission.OWNER_PANEL)).allowed)
        except Exception:
            log.error("member stats permission check failed", exc_info=True)
            return False

    @staticmethod
    def _valid_id(value: object) -> bool:
        return isinstance(value, int) and not isinstance(value, bool)

    async def run(self, parsed: ParsedMemberStats, *, chat_id: object, chat_type: object, user_id: object,
                  reply: ReplyInfo | None = None, lang: str | None = None) -> MemberStatsReply | None:
        lang = lang or self._language
        if not self._valid_id(chat_id) or not self._valid_id(user_id) or user_id <= 0:
            return None
        if chat_type == "private":
            if chat_id != user_id:
                return None
        elif chat_type not in GROUP_CHAT_TYPES:
            return None
        if not await self._is_owner(user_id):
            return None  # silence for everybody else, administrators included
        if self._store is None:
            return MemberStatsReply("unavailable", t("action_failed_safe", lang))
        args = list(parsed.args)
        if chat_type == "private":
            if not args or not _GROUP_ID.match(args[0]):
                return MemberStatsReply("usage", t("ms_need_group", lang, usage=Raw(self._usage_line(parsed.kind, lang))))
            group_id, args = int(args[0]), args[1:]
        else:
            if args and _GROUP_ID.match(args[0]):
                return MemberStatsReply("usage", t("ms_usage_in_group", lang, usage=Raw(self._usage_line(parsed.kind, lang))))
            group_id = chat_id  # always the chat the command was typed in
        today = day_bucket(self._clock(), self._tz)
        try:
            if parsed.kind == USER:
                return await self._user(group_id, args, reply, today, lang)
            if parsed.kind == TOP:
                return await self._top(group_id, args, today, lang)
            if parsed.kind == GROUP:
                return await self._group(group_id, args, today, lang)
        except Exception:
            log.error("member stats command failed", extra={"group_id": group_id}, exc_info=True)
            return MemberStatsReply("unavailable", t("action_failed_safe", lang))
        return None

    @staticmethod
    def _usage_line(kind: str, lang: str) -> str:
        return t({USER: "ms_usage_user", TOP: "ms_usage_top", GROUP: "ms_usage_group"}[kind], lang)

    async def _user(self, group_id: int, args: list[str], reply: ReplyInfo | None, today, lang: str) -> MemberStatsReply:
        usage = MemberStatsReply("usage", t("ms_usage_replying", lang, usage=Raw(self._usage_line(USER, lang))))
        if len(args) > 1 or (reply is not None and args) or (reply is None and not args):
            return usage
        try:
            user_id, _via = await extract_target_id(TargetInput(reply=reply, token=args[0] if args else None),
                                                    group_id, self._usernames)
        except TargetError as exc:
            key = "ms_username_unknown" if exc.code == "username_unresolved" else "ms_target_invalid"
            return MemberStatsReply("usage", t(key, lang))
        if not 0 < user_id < 2**63:
            return MemberStatsReply("usage", t("ms_target_invalid", lang))
        found = await self._store.get(group_id, user_id, today)
        if found is None:
            return MemberStatsReply("empty", t("ms_no_record", lang, user=_mention(user_id), group=str(group_id)))
        return MemberStatsReply("ok", render_member(found, self._tz, lang))

    async def _top(self, group_id: int, args: list[str], today, lang: str) -> MemberStatsReply:
        limit = DEFAULT_TOP
        if len(args) > 1:
            return MemberStatsReply("usage", self._usage_line(TOP, lang))
        if args:
            if not args[0].isdecimal() or not 1 <= int(args[0]) <= MAX_TOP:
                return MemberStatsReply("usage", t("ms_top_range", lang, max=MAX_TOP))
            limit = int(args[0])
        rows = await self._store.top(group_id, limit, today)
        if not rows:
            return MemberStatsReply("empty", t("ms_no_data", lang, group=str(group_id)))
        return MemberStatsReply("ok", render_top(group_id, rows, lang))

    async def _group(self, group_id: int, args: list[str], today, lang: str) -> MemberStatsReply:
        if args:
            return MemberStatsReply("usage", self._usage_line(GROUP, lang))
        totals = await self._store.totals(group_id, today)
        if totals.members == 0:
            return MemberStatsReply("empty", t("ms_no_data", lang, group=str(group_id)))
        return MemberStatsReply("ok", render_group(totals, self._tz, lang))


__all__ = ["MemberStatsCommandService", "MemberStatsReply", "render_member", "render_group", "render_top"]
