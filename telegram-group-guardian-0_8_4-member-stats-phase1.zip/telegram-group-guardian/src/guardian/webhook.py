"""Webhook helpers: secret verification and update de-duplication."""
from __future__ import annotations

import hmac
from collections import OrderedDict

SECRET_HEADER = "X-Telegram-Bot-Api-Secret-Token"


def verify_secret_token(provided: str | None, expected: str) -> bool:
    """Constant-time comparison of Telegram's secret header with WEBHOOK_SECRET."""
    if not provided or not expected:
        return False
    return hmac.compare_digest(provided.encode("utf-8"), expected.encode("utf-8"))


class UpdateDeduplicator:
    """Bounded in-memory memory of recently seen update_ids (at-most-once processing).

    LIMITATION (documented in HANDOFF.md): state is lost on restart/sleep. Phases
    that apply penalties must additionally make the penalty itself idempotent.
    """

    def __init__(self, capacity: int = 10_000):
        if capacity < 1:
            raise ValueError("capacity must be >= 1")
        self._capacity = capacity
        self._seen: OrderedDict[int, None] = OrderedDict()

    def seen_before(self, update_id: int) -> bool:
        """Return True if `update_id` was already seen; otherwise record it and return False."""
        if update_id in self._seen:
            self._seen.move_to_end(update_id)
            return True
        self._seen[update_id] = None
        if len(self._seen) > self._capacity:
            self._seen.popitem(last=False)
        return False
