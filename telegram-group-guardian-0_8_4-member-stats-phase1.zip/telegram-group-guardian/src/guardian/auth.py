"""Server-side identity checks. The owner is defined ONLY by trusted server config."""
from __future__ import annotations

import enum

# Every id is stored in a PostgreSQL BIGINT: anything outside the range would crash the driver
# (an unhandled DataError) instead of being rejected cleanly, so it is rejected up front.
MAX_BIGINT = 2**63 - 1
MIN_BIGINT = -(2**63)

# Telegram "service" identities that appear as `from_user` but are not an individual person:
#   777000      Telegram (service notifications, messages forwarded from a linked channel)
#   1087968824  GroupAnonymousBot (an admin posting anonymously: the real person is hidden)
#   136817688   Channel_Bot (a channel posting into a group)
# They can never be authorized as a person and must never receive automatic sanctions.
TELEGRAM_SERVICE_ACCOUNT_IDS = frozenset({777000, 1087968824, 136817688})


class Role(enum.Enum):
    OWNER = "owner"
    BACKUP_OWNER = "backup_owner"
    USER = "user"


class Authority:
    """Resolves roles from OWNER_TELEGRAM_ID / BACKUP_OWNER_TELEGRAM_ID.

    Never uses usernames, display names or membership of any group. Group-level
    roles (admins, delegates) arrive in later phases and live elsewhere.
    """

    def __init__(self, owner_id: int, backup_owner_id: int | None = None):
        if not _is_user_id(owner_id):
            raise ValueError("owner_id must be a positive int")
        if backup_owner_id is not None and not _is_user_id(backup_owner_id):
            raise ValueError("backup_owner_id must be a positive int")
        self._owner_id = owner_id
        self._backup_id = backup_owner_id

    def role_of(self, user_id: object) -> Role:
        if not _is_user_id(user_id):
            return Role.USER
        if user_id == self._owner_id:
            return Role.OWNER
        if self._backup_id is not None and user_id == self._backup_id:
            return Role.BACKUP_OWNER
        return Role.USER

    def is_owner(self, user_id: object) -> bool:
        return self.role_of(user_id) is Role.OWNER

    def can_change_license(self, user_id: object) -> bool:
        """Only the primary owner. BACKUP_OWNER gets no license rights (spec)."""
        return self.is_owner(user_id)


def _is_user_id(value: object) -> bool:
    # bool is a subclass of int; strings like "123" must NOT be accepted.
    return isinstance(value, int) and not isinstance(value, bool) and 0 < value <= MAX_BIGINT
