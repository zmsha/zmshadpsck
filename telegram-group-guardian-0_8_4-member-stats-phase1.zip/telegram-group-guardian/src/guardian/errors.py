"""Central exception types. Messages must never contain secret values."""
from __future__ import annotations


class GuardianError(Exception):
    """Base class for all application errors."""


class ConfigError(GuardianError):
    """Invalid or missing configuration. Carries variable NAMES only, never values."""

    def __init__(self, problems: list[tuple[str, str]]):
        self.problems = list(problems)
        details = "; ".join(f"{name}: {why}" for name, why in self.problems)
        super().__init__(f"Invalid configuration -> {details}")


class StoreUnavailable(GuardianError):
    """The persistent store cannot be reached. Callers must fail closed."""


class MigrationError(GuardianError):
    """Migration problem (bad file name, checksum drift, ...)."""


class PermissionDenied(GuardianError):
    """The actor lacks the permission. The message is safe to show (no internals)."""

    def __init__(self, permission: str, reason: str):
        self.permission = permission
        self.reason = reason  # short machine reason: not_owner, not_authorized, chat_mismatch, ...
        super().__init__(f"permission denied: {permission} ({reason})")


class GroupNotRegistered(GuardianError):
    """The target group is unknown to the bot (it never registered as pending)."""


class InvalidTransition(GuardianError):
    """The requested license action is not allowed from the group's current status."""


class ConcurrentModification(GuardianError):
    """A compare-and-set lost a race; the caller may re-read and retry."""


class InvalidInput(GuardianError):
    """Rejected input (bad duration, oversized settings patch, malformed callback...)."""


class TelegramLookupFailed(GuardianError):
    """Telegram could not be queried (network/rate limit). Callers must fail closed."""
