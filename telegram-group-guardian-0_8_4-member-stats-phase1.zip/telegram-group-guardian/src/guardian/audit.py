"""Security audit trail: denied attempts, forged callbacks, delegation changes.

License state changes have their own table (`license_audit_log`, written atomically with
the change). This log covers everything else that is security-relevant. Entries never
contain message content; free text is sanitized (control characters, length, secrets).
Writing an audit entry is best-effort and can never turn a denial into an approval.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from datetime import datetime
from typing import Protocol

from .logging_setup import redact
from .time_utils import ensure_utc, utcnow
from .trace import current_trace_id, is_valid_trace_id

log = logging.getLogger(__name__)

MAX_DETAIL_LEN = 300
_known_secrets: tuple[str, ...] = ()


def register_secrets(secrets: tuple[str, ...] | list[str]) -> None:
    """Exact secret values (bot token, webhook secret, DB URL/password) that sanitize_text must
    always redact, in addition to token/URL-password patterns. Called once by create_app."""
    global _known_secrets
    _known_secrets = tuple(sorted({s for s in secrets if s}, key=len, reverse=True))

_CONTROL_RE = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")

# Event type names (stable strings; used by tests and by later phases).
PERMISSION_DENIED = "permission_denied"
FORGED_CALLBACK = "forged_callback"
LICENSE_ACTION_REJECTED = "license_action_rejected"
DELEGATION_GRANTED = "delegation_granted"
DELEGATION_REVOKED = "delegation_revoked"
TRUST_ADDED = "trust_added"
TRUST_REMOVED = "trust_removed"
TRUST_BOT_ADDED = "trust_bot_added"        # part 4.2: bot ids only
TRUST_BOT_REMOVED = "trust_bot_removed"
SETTINGS_CHANGED = "settings_changed"
WARNING_ISSUED = "warning_issued"
WARNING_REVOKED = "warning_revoked"
WARNINGS_CLEARED = "warnings_cleared"
SANCTION_RECORDED = "sanction_recorded"
SANCTION_LIFTED = "sanction_lifted"
REPORT_FILED = "report_filed"
MESSAGE_PINNED = "message_pinned"          # part 3.5-2: ids only (message id, silent flag)
MESSAGE_UNPINNED = "message_unpinned"
MESSAGES_PURGED = "messages_purged"        # part 3.5-2: id range + count only, never message content
CHAT_LOCKED = "chat_locked"                # part 3.5-3: group default permissions changed (lock types only)
CHAT_UNLOCKED = "chat_unlocked"
TEMPLATE_SAVED = "template_saved"          # part 5.6: template id + name only (never the settings values)
TEMPLATE_DELETED = "template_deleted"
TEMPLATE_APPLIED = "template_applied"      # part 5.7: per group; template id + number/names of keys, never values
SANDBOX_STARTED = "sandbox_started"        # part 5.8: source kind/id only (never experiment contents)
SANDBOX_ENDED = "sandbox_ended"            # part 5.8: counts only
COMMAND_REJECTED = "command_rejected"      # part 6.2: command name only (never arguments) + reason
REGISTRATION_FAILED = "registration_failed"  # part 6.2: a group could not be registered (store error)
REPORT_TAKEN = "report_taken"              # part 6.3: report id + new status only (never the reason)
REPORT_RESOLVED = "report_resolved"
REPORT_DISMISSED = "report_dismissed"
REPORT_UPDATED = "report_updated"          # part 6.4a: type/priority changed (report id + closed vocabulary only)
REPORT_DESTINATION_SET = "report_destination_set"  # part 6.4a: owner approved/cleared a report destination (chat ids only)
REPORT_SCHEDULE_SET = "report_schedule_set"  # part 6.6a: a periodic report was switched on/off for a group (period word only)
PERIODIC_REPORT_SENT = "periodic_report_sent"  # part 6.6b: a periodic report reached its chat (period word + calendar key only, never the content)
EXPORT_DELIVERED = "export_delivered"  # part 6.7a: an export file reached the requester's private chat (kind, sizes, code only; never the content)
EXPORT_FAILED = "export_failed"  # part 6.7a: an export was refused/failed (closed code only)
EXPORT_REQUESTED = "export_requested"  # part 6.7b: an export command passed every gate and was claimed (which export: settings|license; never the content)
BACKUP_REQUESTED = "backup_requested"  # part 6.8b: the owner asked for a backup (a confirmation code was issued; nothing else)
BACKUP_DELIVERED = "backup_delivered"  # part 6.8b: a backup file reached the owner's private chat (sizes, row count, code only; never the content)
BACKUP_FAILED = "backup_failed"        # part 6.8b: a backup was not built or not delivered (closed code only)
RESTORE_PREVIEWED = "restore_previewed"  # part 6.9a: a backup file passed validation and a dry preview was shown (counts, fingerprint only; nothing was written)
RESTORE_REJECTED = "restore_rejected"    # part 6.9a: a backup file was refused or could not be previewed (closed code + table/rule name only)
RESTORE_STARTED = "restore_started"      # part 6.9b: the restore transaction is about to run (fingerprint, with_license) - leaves a trace even if the process dies
RESTORE_APPLIED = "restore_applied"      # part 6.9b: committed (counts only)
RESTORE_FAILED = "restore_failed"        # part 6.9b: rolled back (closed code + table name only); the database is unchanged
AUDIT_PURGED = "audit_purged"              # part 6.2: retention purge ran: row count + cutoff date only
DEFAULTS_CHANGED = "defaults_changed"      # part 5.7: global defaults for NEW groups (version + number of keys)

DEFAULT_WORDS_CHANGED = "default_words_changed"  # part 9.5: the owner added/removed default filter words (counts only, never the words)

# Results (stable vocabulary for the `result` column; free text is never accepted there).
RESULT_ALLOWED = "allowed"
RESULT_DENIED = "denied"
RESULT_FAILED = "failed"
RESULT_APPLIED = "applied"
RESULTS = frozenset({RESULT_ALLOWED, RESULT_DENIED, RESULT_FAILED, RESULT_APPLIED})
MAX_TARGET_LEN = 64
# Events whose outcome is implied by their type; make_event fills `result` from here when the caller gives none.
# Everything else stays None until a later part records a real outcome (never a guessed one).
DEFAULT_RESULTS = {PERMISSION_DENIED: RESULT_DENIED, FORGED_CALLBACK: RESULT_DENIED,
                   LICENSE_ACTION_REJECTED: RESULT_DENIED}


def sanitize_target(value: object) -> str | None:
    """`target_id`: what the event acted on (user id, message id, template id, ...). Opaque identifier only: never
    message content. Ints are stored as decimal text; strings are sanitized and cut at MAX_TARGET_LEN."""
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, int):
        return str(value)
    return sanitize_text(str(value), limit=MAX_TARGET_LEN)


def sanitize_text(value: str | None, limit: int = MAX_DETAIL_LEN, secrets: tuple[str, ...] = ()) -> str | None:
    """Strip control characters, redact secrets/tokens/DSN passwords, collapse whitespace, truncate."""
    if value is None:
        return None
    text = _CONTROL_RE.sub(" ", str(value))
    text = redact(text, (*secrets, *_known_secrets))
    text = " ".join(text.split())
    if len(text) > limit:
        text = text[: limit - 1] + "…"
    return text or None


@dataclass(frozen=True, slots=True)
class SecurityEvent:
    event_type: str
    occurred_at: datetime
    actor_telegram_id: int | None = None
    group_id: int | None = None
    permission: str | None = None
    detail: str | None = None
    target_id: str | None = None   # part 6.1: what the event acted on (opaque id, never content)
    result: str | None = None      # part 6.1: one of RESULTS, or None when not applicable / unknown
    trace_id: str | None = None    # part 6.1: the update that produced it (see trace.py); None outside an update

    def __post_init__(self) -> None:
        object.__setattr__(self, "occurred_at", ensure_utc(self.occurred_at))
        object.__setattr__(self, "detail", sanitize_text(self.detail))
        object.__setattr__(self, "target_id", sanitize_target(self.target_id))
        result = self.result if self.result in RESULTS else None
        object.__setattr__(self, "result", result)
        trace = self.trace_id if is_valid_trace_id(self.trace_id) else None
        object.__setattr__(self, "trace_id", trace)


class SecurityAudit(Protocol):
    async def record(self, event: SecurityEvent) -> None: ...

    async def for_group(self, group_id: int, limit: int = 50) -> list[SecurityEvent]: ...

    async def purge_before(self, cutoff: datetime, limit: int) -> int: ...

    async def count_by_type(self, group_id: int, start: datetime, end: datetime) -> dict[str, int]:
        """Statistics (6.5a): number of events per `event_type` of ONE group with `start <= occurred_at < end`."""
        ...


class InMemorySecurityAudit:
    """Test/local implementation. State is lost on restart: never use as the production audit."""

    def __init__(self) -> None:
        self.events: list[SecurityEvent] = []

    async def record(self, event: SecurityEvent) -> None:
        self.events.append(event)

    async def for_group(self, group_id: int, limit: int = 50) -> list[SecurityEvent]:
        rows = [e for e in self.events if e.group_id == group_id]
        return rows[-limit:]

    async def count_by_type(self, group_id: int, start: datetime, end: datetime) -> dict[str, int]:
        out: dict[str, int] = {}
        for e in self.events:
            if e.group_id == group_id and start <= e.occurred_at < end:
                out[e.event_type] = out.get(e.event_type, 0) + 1
        return out

    async def purge_before(self, cutoff: datetime, limit: int) -> int:
        """Retention (part 6.2): drop up to `limit` of the oldest events older than `cutoff`; returns how many."""
        cutoff = ensure_utc(cutoff)
        doomed = [i for i, e in enumerate(self.events) if e.occurred_at < cutoff][: max(0, int(limit))]
        for i in reversed(doomed):
            del self.events[i]
        return len(doomed)


class PostgresSecurityAudit:
    def __init__(self, database) -> None:
        self._db = database

    async def record(self, event: SecurityEvent) -> None:
        async with self._db.acquire() as conn:
            await conn.execute(
                "INSERT INTO security_audit_log "
                "(event_type, actor_telegram_id, group_id, permission, detail, occurred_at, "
                "target_id, result, trace_id) "
                "VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)",
                event.event_type,
                event.actor_telegram_id,
                event.group_id,
                event.permission,
                event.detail,
                event.occurred_at,
                event.target_id,
                event.result,
                event.trace_id,
            )

    async def purge_before(self, cutoff: datetime, limit: int) -> int:
        """The ONLY delete path of the append-only log: the SQL function created by migration 0007 (it enforces a
        30-day floor itself and is the only code that lifts the trigger's guard, for one transaction)."""
        async with self._db.acquire() as conn:
            deleted = await conn.fetchval("SELECT guardian_purge_security_audit($1, $2)", ensure_utc(cutoff), int(limit))
        return int(deleted or 0)

    async def count_by_type(self, group_id: int, start: datetime, end: datetime) -> dict[str, int]:
        async with self._db.acquire() as conn:
            rows = await conn.fetch(
                "SELECT event_type, count(*) AS n FROM security_audit_log "
                "WHERE group_id = $1 AND occurred_at >= $2 AND occurred_at < $3 GROUP BY event_type",
                group_id, ensure_utc(start), ensure_utc(end))
        return {r["event_type"]: int(r["n"] or 0) for r in rows}

    async def for_group(self, group_id: int, limit: int = 50) -> list[SecurityEvent]:
        limit = max(1, min(int(limit), 500))
        async with self._db.acquire() as conn:
            rows = await conn.fetch(
                "SELECT event_type, actor_telegram_id, group_id, permission, detail, occurred_at, "
                "target_id, result, trace_id "
                "FROM security_audit_log WHERE group_id = $1 ORDER BY id DESC LIMIT $2",
                group_id,
                limit,
            )
        return [
            SecurityEvent(
                event_type=r["event_type"],
                occurred_at=r["occurred_at"],
                actor_telegram_id=r["actor_telegram_id"],
                group_id=r["group_id"],
                permission=r["permission"],
                detail=r["detail"],
                target_id=r["target_id"],
                result=r["result"],
                trace_id=r["trace_id"],
            )
            for r in reversed(rows)
        ]


async def record_safely(audit: SecurityAudit | None, event: SecurityEvent) -> None:
    """Best-effort write: a failing audit store must never break (or approve) the caller."""
    if audit is None:
        return
    try:
        await audit.record(event)
    except Exception:
        log.warning("security audit write failed event=%s", event.event_type, exc_info=True)


def make_event(event_type: str, *, actor: int | None = None, group_id: int | None = None,
               permission: str | None = None, detail: str | None = None,
               now: datetime | None = None, target: object = None, result: str | None = None,
               trace_id: str | None = None) -> SecurityEvent:
    """Build an event. `trace_id` defaults to the current update's trace (None outside an update)."""
    return SecurityEvent(event_type, now or utcnow(), actor, group_id, permission, detail,
                         sanitize_target(target), result if result is not None else DEFAULT_RESULTS.get(event_type), trace_id if trace_id is not None else current_trace_id())
