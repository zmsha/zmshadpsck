"""Phase 3 / Part 1: the single gate that decides whether protection may run for an update.

Framework independent (no aiogram import). The aiogram adapter is `bot/middlewares.py`.

Rules (spec):
* The gate NEVER drops an update. Owner license commands, the owner panel and /status keep working
  in every license state; only PROTECTION handlers consult the resulting `ProtectionContext`.
* Protection runs only when the group's license is active (permanent, or temporary and not past
  `expires_at` at this very moment). pending / expired / stopped / rejected / banned / unregistered
  and ANY failure (DB down, lookup error, bug) => not allowed (fail closed).
* Expiry is evaluated from the clock on every call (LicenseService.check), so a service that slept
  past `expires_at` never protects on its first update after waking.
* An unknown group seen for the first time is registered as PENDING (never activated); the bot being
  removed and re-added never changes a license.
* A sender that cannot be identified, a Telegram service account, an anonymous admin / channel
  (`sender_chat`), the owner, delegates and Telegram admins of THIS group are exempt from automatic sanctions
  (`can_sanction` False). The trust list is NOT a blanket exemption (part 4.2): a trusted sender stays sanctionable and
  is flagged `sender_trusted`; the engine skips only the rules listed in `members/trust.py`.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Callable

from .licensing.models import DenyReason
from .licensing.service import LicenseService
from .membership import Notifier, handle_bot_added
from .permissions import PermissionService
from .time_utils import utcnow

log = logging.getLogger(__name__)

GROUP_CHAT_TYPES = frozenset({"group", "supergroup"})

REASON_NOT_A_GROUP = "not_a_group"
REASON_GATE_ERROR = "gate_error"


@dataclass(frozen=True, slots=True)
class ProtectionContext:
    chat_id: int | None
    chat_type: str
    allowed: bool            # license permits protection in this chat right now
    reason: str              # DenyReason value, or not_a_group / gate_error; "none" when allowed
    sender_id: int | None    # None when the sender cannot be identified as a person
    sender_exempt: bool      # never sanction automatically (also True whenever not allowed)
    sender_trusted: bool = False  # on this group's trust list: skips only the rules of members/trust.USER_BYPASS

    @property
    def can_sanction(self) -> bool:
        """Automatic protection (delete/mute/ban) may be applied to this sender in this chat."""
        return self.allowed and not self.sender_exempt and self.sender_id is not None

    @property
    def can_moderate_content(self) -> bool:
        """Protection may run at all (e.g. inspect the message). Not enough to sanction."""
        return self.allowed


def denied(chat_id: int | None, chat_type: str, reason: str, sender_id: int | None = None) -> ProtectionContext:
    return ProtectionContext(chat_id, chat_type, False, reason, sender_id, True)


class ProtectionGate:
    def __init__(
        self,
        license_service: LicenseService,
        permissions: PermissionService,
        notifier: Notifier,
        *,
        language: str = "ar",
        clock: Callable[[], datetime] = utcnow,
        audit: Any = None,
    ):
        self._licenses = license_service
        self._perm = permissions
        self._notifier = notifier
        self._language = language
        self._clock = clock
        self._audit = audit  # part 6.2: registration failures (best effort)

    async def evaluate(
        self,
        chat_id: int | None,
        chat_type: str | None,
        sender_id: int | None,
        *,
        title: str | None = None,
        anonymous_sender: bool = False,
    ) -> ProtectionContext:
        chat_type = chat_type or ""
        if chat_type not in GROUP_CHAT_TYPES or not isinstance(chat_id, int) or isinstance(chat_id, bool):
            return denied(chat_id if isinstance(chat_id, int) else None, chat_type, REASON_NOT_A_GROUP, sender_id)
        try:
            return await self._evaluate_group(chat_id, chat_type, sender_id, title, anonymous_sender)
        except Exception:
            log.error("protection gate failed; denying protection", extra={"group_id": chat_id}, exc_info=True)
            return denied(chat_id, chat_type, REASON_GATE_ERROR, sender_id)

    async def _evaluate_group(
        self, chat_id: int, chat_type: str, sender_id: int | None, title: str | None, anonymous_sender: bool
    ) -> ProtectionContext:
        decision = await self._licenses.check(chat_id, self._clock())
        if decision.reason is DenyReason.NOT_REGISTERED:
            # First sight of this group: register as PENDING (idempotent; never activates/unbans),
            # then re-check. A registration failure stays denied.
            outcome = await handle_bot_added(
                self._licenses, self._notifier, group_id=chat_id, title=title, language=self._language,
                audit=self._audit,
            )
            if outcome.store_error:
                return denied(chat_id, chat_type, DenyReason.STORE_UNAVAILABLE.value, sender_id)
            decision = await self._licenses.check(chat_id, self._clock())
        if not decision.allowed:
            return denied(chat_id, chat_type, decision.reason.value, sender_id)

        identified = None if anonymous_sender else sender_id
        exempt = await self._perm.is_exempt_from_automation(identified, chat_id)
        trusted = False
        if not exempt:
            try:
                trusted = await self._perm.is_trusted(identified, chat_id)
            except Exception:
                log.warning("trust lookup failed; not sanctioning", extra={"group_id": chat_id})
                exempt = True  # uncertain => no automatic action
        return ProtectionContext(chat_id, chat_type, True, DenyReason.NONE.value, identified, exempt, trusted)
