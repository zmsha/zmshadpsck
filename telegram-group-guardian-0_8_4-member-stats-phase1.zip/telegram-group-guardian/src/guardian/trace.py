"""Per-update trace id (phase 6, part 6.1).

One id per Telegram update, set by `TraceMiddleware` before anything else runs and read by the audit layer so every
record written while handling that update carries the same `trace_id`. It lives in a `ContextVar`, so concurrent
updates never share it. It is opaque (random hex): it carries no user, chat or message data. Outside an update
(startup, tests, background work) there is no trace and `current_trace_id()` returns None.
"""
from __future__ import annotations

import re
import secrets
from contextvars import ContextVar, Token
from typing import Any, Awaitable, Callable

TRACE_LEN = 16
_TRACE_RE = re.compile(r"^[0-9a-f]{%d}$" % TRACE_LEN)
_current: ContextVar[str | None] = ContextVar("guardian_trace_id", default=None)


def new_trace_id() -> str:
    return secrets.token_hex(TRACE_LEN // 2)


def is_valid_trace_id(value: object) -> bool:
    return isinstance(value, str) and _TRACE_RE.match(value) is not None


def current_trace_id() -> str | None:
    return _current.get()


def set_trace_id(value: str | None = None) -> Token:
    """Set (or generate) the current trace id; returns the token for `reset_trace_id`."""
    if value is not None and not is_valid_trace_id(value):
        raise ValueError("invalid trace id")
    return _current.set(value or new_trace_id())


def reset_trace_id(token: Token) -> None:
    _current.reset(token)


class TraceMiddleware:
    """aiogram OUTER middleware on `dp.update`: gives every update its own trace id. Plain callable (no aiogram import)."""

    async def __call__(self, handler: Callable[[Any, dict], Awaitable[Any]], event: Any, data: dict) -> Any:
        token = set_trace_id()
        try:
            return await handler(event, data)
        finally:
            reset_trace_id(token)
