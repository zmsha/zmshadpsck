"""Per-group access entities (pure, no I/O). Every entity carries its group_id."""
from __future__ import annotations

import enum
from dataclasses import dataclass, field
from datetime import datetime

from ..time_utils import ensure_utc


class GroupRole(str, enum.Enum):
    """Custom roles the PRIMARY OWNER may delegate inside ONE group (never global)."""

    GROUP_MANAGER = "group_manager"  # settings + trust list + moderation
    MODERATOR = "moderator"          # moderation only


@dataclass(frozen=True, slots=True)
class Delegation:
    group_id: int
    user_id: int
    role: GroupRole
    granted_by: int
    granted_at: datetime
    revoked_at: datetime | None = None
    revoked_by: int | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "granted_at", ensure_utc(self.granted_at))
        if self.revoked_at is not None:
            object.__setattr__(self, "revoked_at", ensure_utc(self.revoked_at))

    @property
    def is_live(self) -> bool:
        return self.revoked_at is None


@dataclass(frozen=True, slots=True)
class TrustedUser:
    group_id: int
    user_id: int
    added_by: int
    added_at: datetime
    note: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "added_at", ensure_utc(self.added_at))


@dataclass(frozen=True, slots=True)
class GroupSettings:
    group_id: int
    updated_at: datetime
    settings: dict = field(default_factory=dict)
    language: str | None = None
    updated_by: int | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "updated_at", ensure_utc(self.updated_at))
