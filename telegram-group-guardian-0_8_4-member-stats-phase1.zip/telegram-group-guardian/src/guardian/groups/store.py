"""Persistence contracts for per-group access data. ALL methods take group_id and never
return rows of another group."""
from __future__ import annotations

from datetime import datetime
from typing import Protocol

from .models import Delegation, GroupRole, GroupSettings, TrustedUser


class DelegationStore(Protocol):
    async def get_live(self, group_id: int, user_id: int) -> Delegation | None: ...

    async def grant(
        self, group_id: int, user_id: int, role: GroupRole, granted_by: int, now: datetime
    ) -> tuple[Delegation, bool]:
        """Idempotent: same live role -> (existing, False). Different role -> old revoked, new created (True)."""
        ...

    async def revoke(self, group_id: int, user_id: int, revoked_by: int, now: datetime) -> bool: ...

    async def list_live(self, group_id: int) -> list[Delegation]: ...


class TrustStore(Protocol):
    async def add(self, group_id: int, user_id: int, added_by: int, note: str | None, now: datetime) -> bool: ...

    async def remove(self, group_id: int, user_id: int) -> bool: ...

    async def is_trusted(self, group_id: int, user_id: int) -> bool: ...

    async def list(self, group_id: int) -> list[TrustedUser]: ...


class SettingsStore(Protocol):
    async def get(self, group_id: int) -> GroupSettings | None: ...

    async def merge(self, group_id: int, patch: dict, updated_by: int, now: datetime) -> GroupSettings: ...

    async def set_language(self, group_id: int, language: str | None, updated_by: int, now: datetime) -> GroupSettings: ...
