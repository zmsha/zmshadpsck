"""Group-scoped services. Each method authorizes through PermissionService FIRST and only
touches rows of the single `group_id` it is given."""
from __future__ import annotations

import json
import math
import re
from datetime import datetime
from typing import Callable

from ..audit import (
    DELEGATION_GRANTED,
    DELEGATION_REVOKED,
    SETTINGS_CHANGED,
    TRUST_ADDED,
    TRUST_REMOVED,
    SecurityAudit,
    make_event,
    record_safely,
    sanitize_text,
)
from ..errors import GroupNotRegistered, InvalidInput
from ..licensing.store import LicenseStore
from ..permissions import Permission, PermissionService
from ..time_utils import utcnow
from .models import Delegation, GroupRole, GroupSettings, TrustedUser
from .store import DelegationStore, SettingsStore, TrustStore

MAX_SETTINGS_KEYS = 50
MAX_SETTINGS_BYTES = 4096
MAX_STRING_VALUE = 500
MAX_DEPTH = 3
MAX_ABS_INT = 2**53  # beyond this JSON consumers lose precision; settings never need it
_KEY_RE = re.compile(r"^[a-z][a-z0-9_]{0,49}$")
_LANGS = ("ar", "en")


def _user(value: object) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise InvalidInput("user id must be a positive integer")
    return value


async def _require_registered(licenses: LicenseStore, group_id: int) -> None:
    if await licenses.get(group_id) is None:
        raise GroupNotRegistered("group is not registered")


class DelegationService:
    """Only the primary owner grants/revokes delegated roles (Permission.MANAGE_DELEGATES)."""

    def __init__(self, store: DelegationStore, licenses: LicenseStore, permissions: PermissionService,
                 audit: SecurityAudit | None = None, *, clock: Callable[[], datetime] = utcnow):
        self._store, self._licenses, self._perm, self._audit, self._clock = store, licenses, permissions, audit, clock

    async def grant(self, actor_id, group_id, user_id, role: GroupRole, *, context_chat_id=None) -> tuple[Delegation, bool]:
        await self._perm.require(actor_id, group_id, Permission.MANAGE_DELEGATES, context_chat_id=context_chat_id)
        user_id = _user(user_id)
        if not isinstance(role, GroupRole):
            raise InvalidInput("unknown role")
        await _require_registered(self._licenses, group_id)
        now = self._clock()
        delegation, changed = await self._store.grant(group_id, user_id, role, actor_id, now)
        if changed:
            await record_safely(self._audit, make_event(DELEGATION_GRANTED, actor=actor_id, group_id=group_id,
                                                        detail=f"user={user_id} role={role.value}", now=now))
        return delegation, changed

    async def revoke(self, actor_id, group_id, user_id, *, context_chat_id=None) -> bool:
        await self._perm.require(actor_id, group_id, Permission.MANAGE_DELEGATES, context_chat_id=context_chat_id)
        user_id = _user(user_id)
        now = self._clock()
        revoked = await self._store.revoke(group_id, user_id, actor_id, now)
        if revoked:
            await record_safely(self._audit, make_event(DELEGATION_REVOKED, actor=actor_id, group_id=group_id,
                                                        detail=f"user={user_id}", now=now))
        return revoked

    async def list(self, actor_id, group_id, *, context_chat_id=None) -> list[Delegation]:
        await self._perm.require(actor_id, group_id, Permission.MANAGE_DELEGATES, context_chat_id=context_chat_id)
        return await self._store.list_live(group_id)


class TrustService:
    def __init__(self, store: TrustStore, licenses: LicenseStore, permissions: PermissionService,
                 audit: SecurityAudit | None = None, *, clock: Callable[[], datetime] = utcnow):
        self._store, self._licenses, self._perm, self._audit, self._clock = store, licenses, permissions, audit, clock

    async def add(self, actor_id, group_id, user_id, note: str | None = None, *, context_chat_id=None) -> bool:
        await self._perm.require(actor_id, group_id, Permission.MANAGE_TRUST, context_chat_id=context_chat_id)
        user_id = _user(user_id)
        await _require_registered(self._licenses, group_id)
        now = self._clock()
        created = await self._store.add(group_id, user_id, actor_id, sanitize_text(note, 200), now)
        if created:
            await record_safely(self._audit, make_event(TRUST_ADDED, actor=actor_id, group_id=group_id,
                                                        detail=f"user={user_id}", now=now))
        return created

    async def remove(self, actor_id, group_id, user_id, *, context_chat_id=None) -> bool:
        await self._perm.require(actor_id, group_id, Permission.MANAGE_TRUST, context_chat_id=context_chat_id)
        user_id = _user(user_id)
        removed = await self._store.remove(group_id, user_id)
        if removed:
            await record_safely(self._audit, make_event(TRUST_REMOVED, actor=actor_id, group_id=group_id,
                                                        detail=f"user={user_id}", now=self._clock()))
        return removed

    async def list(self, actor_id, group_id, *, context_chat_id=None) -> list[TrustedUser]:
        await self._perm.require(actor_id, group_id, Permission.MANAGE_TRUST, context_chat_id=context_chat_id)
        return await self._store.list(group_id)


def validate_settings_patch(patch: object) -> dict:
    """Reject anything that is not a small JSON object with simple snake_case keys."""
    if not isinstance(patch, dict) or not patch:
        raise InvalidInput("settings patch must be a non-empty object")
    if len(patch) > MAX_SETTINGS_KEYS:
        raise InvalidInput("too many settings keys")
    _check_value(patch, 0)
    try:
        # allow_nan=False: NaN/Infinity are not valid JSON and PostgreSQL JSONB rejects them.
        encoded = json.dumps(patch, ensure_ascii=False, allow_nan=False)
        size = len(encoded.encode("utf-8"))
    except (TypeError, ValueError, UnicodeEncodeError) as exc:
        raise InvalidInput("settings must be JSON serializable") from exc
    if size > MAX_SETTINGS_BYTES:
        raise InvalidInput("settings patch too large")
    return patch


def _check_value(value: object, depth: int) -> None:
    if depth > MAX_DEPTH:
        raise InvalidInput("settings nested too deeply")
    if value is None or isinstance(value, bool):
        return
    if isinstance(value, int):
        if abs(value) > MAX_ABS_INT:
            raise InvalidInput("settings number out of range")
        return
    if isinstance(value, float):
        if not math.isfinite(value) or abs(value) > MAX_ABS_INT:
            raise InvalidInput("settings number out of range")
        return
    if isinstance(value, str):
        if len(value) > MAX_STRING_VALUE:
            raise InvalidInput("settings string too long")
        if "\x00" in value:  # PostgreSQL JSONB cannot store \u0000
            raise InvalidInput("settings string contains a NUL character")
        try:
            value.encode("utf-8")  # lone surrogates cannot be sent to PostgreSQL
        except UnicodeEncodeError:
            raise InvalidInput("settings string is not valid text") from None
        return
    if isinstance(value, list):
        if len(value) > 100:
            raise InvalidInput("settings list too long")
        for item in value:
            _check_value(item, depth + 1)
        return
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str) or not _KEY_RE.match(key):
                raise InvalidInput("invalid settings key")
            _check_value(item, depth + 1)
        return
    raise InvalidInput("unsupported settings value")


class GroupSettingsService:
    def __init__(self, store: SettingsStore, licenses: LicenseStore, permissions: PermissionService,
                 audit: SecurityAudit | None = None, *, clock: Callable[[], datetime] = utcnow):
        self._store, self._licenses, self._perm, self._audit, self._clock = store, licenses, permissions, audit, clock

    async def get(self, actor_id, group_id, *, context_chat_id=None) -> GroupSettings | None:
        await self._perm.require(actor_id, group_id, Permission.MANAGE_SETTINGS, context_chat_id=context_chat_id)
        return await self._store.get(group_id)

    async def update(self, actor_id, group_id, patch: dict, *, context_chat_id=None) -> GroupSettings:
        await self._perm.require(actor_id, group_id, Permission.MANAGE_SETTINGS, context_chat_id=context_chat_id)
        validate_settings_patch(patch)
        await _require_registered(self._licenses, group_id)
        now = self._clock()
        result = await self._store.merge(group_id, patch, actor_id, now)
        await record_safely(self._audit, make_event(SETTINGS_CHANGED, actor=actor_id, group_id=group_id,
                                                    detail="keys=" + ",".join(sorted(patch)[:10]), now=now))
        return result

    async def set_language(self, actor_id, group_id, language: str | None, *, context_chat_id=None) -> GroupSettings:
        await self._perm.require(actor_id, group_id, Permission.MANAGE_SETTINGS, context_chat_id=context_chat_id)
        if language is not None and language not in _LANGS:
            raise InvalidInput("unsupported language")
        await _require_registered(self._licenses, group_id)
        now = self._clock()
        result = await self._store.set_language(group_id, language, actor_id, now)
        await record_safely(self._audit, make_event(SETTINGS_CHANGED, actor=actor_id, group_id=group_id,
                                                    detail=f"language={language}", now=now))
        return result
