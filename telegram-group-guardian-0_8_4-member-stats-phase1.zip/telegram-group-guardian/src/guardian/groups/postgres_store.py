"""PostgreSQL implementations (NOT executed against a real PostgreSQL in the build sandbox).

Every statement filters by group_id; group-scoped tables reference telegram_groups so rows
for unknown groups are impossible (foreign-key violation -> the service reports it).
"""
from __future__ import annotations

import json
from datetime import datetime

from .models import Delegation, GroupRole, GroupSettings, TrustedUser


def _delegation(row) -> Delegation:
    return Delegation(
        group_id=row["group_id"],
        user_id=row["user_id"],
        role=GroupRole(row["role"]),
        granted_by=row["granted_by"],
        granted_at=row["granted_at"],
        revoked_at=row["revoked_at"],
        revoked_by=row["revoked_by"],
    )


_DELEG_COLS = "group_id, user_id, role, granted_by, granted_at, revoked_at, revoked_by"
_UNIQUE_VIOLATION = "23505"  # asyncpg exceptions expose the SQLSTATE as `.sqlstate`


class PostgresDelegationStore:
    def __init__(self, database) -> None:
        self._db = database

    async def get_live(self, group_id: int, user_id: int) -> Delegation | None:
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                f"SELECT {_DELEG_COLS} FROM group_delegations "
                "WHERE group_id = $1 AND user_id = $2 AND revoked_at IS NULL",
                group_id,
                user_id,
            )
        return _delegation(row) if row else None

    async def grant(self, group_id, user_id, role, granted_by, now):
        # `FOR UPDATE` locks nothing when no live row exists, so two concurrent first grants can both
        # reach the INSERT; the partial unique index then rejects the loser (SQLSTATE 23505).
        # Retry once: the second attempt sees the winner's row and answers idempotently.
        for attempt in (1, 2):
            try:
                return await self._grant_once(group_id, user_id, role, granted_by, now)
            except Exception as exc:
                if attempt == 1 and getattr(exc, "sqlstate", None) == _UNIQUE_VIOLATION:
                    continue
                raise
        raise AssertionError("unreachable")  # pragma: no cover

    async def _grant_once(self, group_id, user_id, role, granted_by, now):
        async with self._db.acquire() as conn:
            async with conn.transaction():
                current = await conn.fetchrow(
                    f"SELECT {_DELEG_COLS} FROM group_delegations "
                    "WHERE group_id = $1 AND user_id = $2 AND revoked_at IS NULL FOR UPDATE",
                    group_id,
                    user_id,
                )
                if current is not None and current["role"] == role.value:
                    return _delegation(current), False
                if current is not None:
                    await conn.execute(
                        "UPDATE group_delegations SET revoked_at = $3, revoked_by = $4 "
                        "WHERE group_id = $1 AND user_id = $2 AND revoked_at IS NULL",
                        group_id,
                        user_id,
                        now,
                        granted_by,
                    )
                row = await conn.fetchrow(
                    "INSERT INTO group_delegations (group_id, user_id, role, granted_by, granted_at) "
                    f"VALUES ($1, $2, $3, $4, $5) RETURNING {_DELEG_COLS}",
                    group_id,
                    user_id,
                    role.value,
                    granted_by,
                    now,
                )
        return _delegation(row), True

    async def revoke(self, group_id, user_id, revoked_by, now) -> bool:
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "UPDATE group_delegations SET revoked_at = $3, revoked_by = $4 "
                "WHERE group_id = $1 AND user_id = $2 AND revoked_at IS NULL RETURNING id",
                group_id,
                user_id,
                now,
                revoked_by,
            )
        return row is not None

    async def list_live(self, group_id: int) -> list[Delegation]:
        async with self._db.acquire() as conn:
            rows = await conn.fetch(
                f"SELECT {_DELEG_COLS} FROM group_delegations WHERE group_id = $1 AND revoked_at IS NULL "
                "ORDER BY granted_at",
                group_id,
            )
        return [_delegation(r) for r in rows]


class PostgresTrustStore:
    def __init__(self, database) -> None:
        self._db = database

    async def add(self, group_id, user_id, added_by, note, now) -> bool:
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "INSERT INTO group_trusted_users (group_id, user_id, added_by, added_at, note) "
                "VALUES ($1, $2, $3, $4, $5) ON CONFLICT (group_id, user_id) DO NOTHING RETURNING user_id",
                group_id,
                user_id,
                added_by,
                now,
                note,
            )
        return row is not None

    async def remove(self, group_id, user_id) -> bool:
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "DELETE FROM group_trusted_users WHERE group_id = $1 AND user_id = $2 RETURNING user_id",
                group_id,
                user_id,
            )
        return row is not None

    async def is_trusted(self, group_id, user_id) -> bool:
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT 1 AS ok FROM group_trusted_users WHERE group_id = $1 AND user_id = $2", group_id, user_id
            )
        return row is not None

    async def list(self, group_id) -> list[TrustedUser]:
        async with self._db.acquire() as conn:
            rows = await conn.fetch(
                "SELECT group_id, user_id, added_by, added_at, note FROM group_trusted_users "
                "WHERE group_id = $1 ORDER BY added_at",
                group_id,
            )
        return [TrustedUser(r["group_id"], r["user_id"], r["added_by"], r["added_at"], r["note"]) for r in rows]


def _settings(row) -> GroupSettings:
    raw = row["settings"]
    data = json.loads(raw) if isinstance(raw, (str, bytes)) else dict(raw or {})
    return GroupSettings(
        group_id=row["group_id"],
        updated_at=row["updated_at"],
        settings=data,
        language=row["language"],
        updated_by=row["updated_by"],
    )


_SET_COLS = "group_id, language, settings, updated_at, updated_by"


class PostgresSettingsStore:
    def __init__(self, database) -> None:
        self._db = database

    async def get(self, group_id: int) -> GroupSettings | None:
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(f"SELECT {_SET_COLS} FROM group_settings WHERE group_id = $1", group_id)
        return _settings(row) if row else None

    async def merge(self, group_id, patch, updated_by, now) -> GroupSettings:
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "INSERT INTO group_settings (group_id, settings, updated_at, updated_by) "
                "VALUES ($1, $2::jsonb, $3, $4) "
                "ON CONFLICT (group_id) DO UPDATE SET settings = group_settings.settings || EXCLUDED.settings, "
                "updated_at = EXCLUDED.updated_at, updated_by = EXCLUDED.updated_by "
                f"RETURNING {_SET_COLS}",
                group_id,
                json.dumps(patch, ensure_ascii=False),
                now,
                updated_by,
            )
        return _settings(row)

    async def set_language(self, group_id, language, updated_by, now) -> GroupSettings:
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "INSERT INTO group_settings (group_id, language, updated_at, updated_by) VALUES ($1, $2, $3, $4) "
                "ON CONFLICT (group_id) DO UPDATE SET language = EXCLUDED.language, "
                "updated_at = EXCLUDED.updated_at, updated_by = EXCLUDED.updated_by "
                f"RETURNING {_SET_COLS}",
                group_id,
                language,
                now,
                updated_by,
            )
        return _settings(row)
