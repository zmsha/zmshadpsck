"""In-memory implementations (tests / local experiments only; state is lost on restart)."""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime

from .models import Delegation, GroupRole, GroupSettings, TrustedUser


class InMemoryDelegationStore:
    def __init__(self) -> None:
        self._rows: list[Delegation] = []  # history incl. revoked

    async def get_live(self, group_id: int, user_id: int) -> Delegation | None:
        for row in self._rows:
            if row.group_id == group_id and row.user_id == user_id and row.is_live:
                return row
        return None

    async def grant(self, group_id, user_id, role, granted_by, now):
        current = await self.get_live(group_id, user_id)
        if current is not None and current.role is role:
            return current, False
        if current is not None:
            await self.revoke(group_id, user_id, granted_by, now)
        row = Delegation(group_id, user_id, role, granted_by, now)
        self._rows.append(row)
        return row, True

    async def revoke(self, group_id, user_id, revoked_by, now) -> bool:
        for i, row in enumerate(self._rows):
            if row.group_id == group_id and row.user_id == user_id and row.is_live:
                self._rows[i] = replace(row, revoked_at=now, revoked_by=revoked_by)
                return True
        return False

    async def list_live(self, group_id: int) -> list[Delegation]:
        return [r for r in self._rows if r.group_id == group_id and r.is_live]


class InMemoryTrustStore:
    def __init__(self) -> None:
        self._rows: dict[tuple[int, int], TrustedUser] = {}

    async def add(self, group_id, user_id, added_by, note, now) -> bool:
        key = (group_id, user_id)
        if key in self._rows:
            return False
        self._rows[key] = TrustedUser(group_id, user_id, added_by, now, note)
        return True

    async def remove(self, group_id, user_id) -> bool:
        return self._rows.pop((group_id, user_id), None) is not None

    async def is_trusted(self, group_id, user_id) -> bool:
        return (group_id, user_id) in self._rows

    async def list(self, group_id) -> list[TrustedUser]:
        return [r for (g, _), r in self._rows.items() if g == group_id]


class InMemorySettingsStore:
    def __init__(self) -> None:
        self._rows: dict[int, GroupSettings] = {}

    async def get(self, group_id: int) -> GroupSettings | None:
        row = self._rows.get(group_id)
        return None if row is None else replace(row, settings=dict(row.settings))

    async def merge(self, group_id, patch, updated_by, now) -> GroupSettings:
        current = self._rows.get(group_id) or GroupSettings(group_id, now)
        merged = {**current.settings, **patch}
        row = replace(current, settings=merged, updated_at=now, updated_by=updated_by)
        self._rows[group_id] = row
        return replace(row, settings=dict(merged))

    async def set_language(self, group_id, language, updated_by, now) -> GroupSettings:
        current = self._rows.get(group_id) or GroupSettings(group_id, now)
        row = replace(current, language=language, updated_at=now, updated_by=updated_by)
        self._rows[group_id] = row
        return replace(row, settings=dict(row.settings))
