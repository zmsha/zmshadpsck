"""The ONE trusted, server-side authorization point for every sensitive action.

Rules (spec):
* The primary owner is exactly OWNER_TELEGRAM_ID (see `auth.Authority`). Usernames, display
  names and membership of OWNER_GROUP_ID prove nothing.
* License change / delegations / global audit are OWNER-ONLY. Telegram admins and delegates
  can never get them, whatever buttons they can see.
* Group-level rights come from (a) a live Telegram admin lookup for THAT group, or (b) a
  delegation stored for THAT group. Nothing is global except the owner.
* Anything uncertain (DB down, Telegram lookup failed, bad ids) => DENY.
* Every denial is written to the security audit log (throttled per actor/group/permission).
"""
from __future__ import annotations

import enum
import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Callable

from .audit import PERMISSION_DENIED, SecurityAudit, make_event, record_safely
from .auth import MAX_BIGINT, MIN_BIGINT, TELEGRAM_SERVICE_ACCOUNT_IDS, Authority, Role
from .errors import PermissionDenied
from .groups.models import GroupRole
from .groups.store import DelegationStore, TrustStore
from .telegram_rights import ChatInfoProvider
from .time_utils import utcnow

log = logging.getLogger(__name__)


class Permission(str, enum.Enum):
    CHANGE_LICENSE = "change_license"        # owner only
    MANAGE_DELEGATES = "manage_delegates"    # owner only
    VIEW_AUDIT = "view_audit"                # owner only
    OWNER_PANEL = "owner_panel"              # owner only: the private multi-group owner panel (phase 5.3)
    OWNER_TEMPLATES = "owner_templates"      # owner only: settings templates + diff preview (phase 5.6)
    REPORT_DESTINATION = "report_destination"  # owner only: approve where a group's report management output goes (6.4a)
    BACKUP = "backup"                        # owner only: build a backup of the bot's data and send it to the owner's private chat (6.8b)
    RESTORE = "restore"                      # owner only: check a backup file and PREVIEW a restore, in the owner's private chat (6.9a; no writes)
    VIEW_GROUP_STATUS = "view_group_status"  # management view (public /status needs no permission)
    MODERATE = "moderate"
    MANAGE_TRUST = "manage_trust"
    MANAGE_SETTINGS = "manage_settings"


OWNER_ONLY = frozenset({Permission.CHANGE_LICENSE, Permission.MANAGE_DELEGATES, Permission.VIEW_AUDIT, Permission.OWNER_PANEL,
                        Permission.OWNER_TEMPLATES, Permission.REPORT_DESTINATION, Permission.BACKUP,
                        Permission.RESTORE})

_GROUP_LEVEL_ALL = frozenset(
    {Permission.VIEW_GROUP_STATUS, Permission.MODERATE, Permission.MANAGE_TRUST, Permission.MANAGE_SETTINGS}
)

# Single place to read/edit the role matrix. No role contains an OWNER_ONLY permission.
TELEGRAM_ADMIN_PERMISSIONS = _GROUP_LEVEL_ALL
ROLE_PERMISSIONS: dict[GroupRole, frozenset[Permission]] = {
    GroupRole.GROUP_MANAGER: _GROUP_LEVEL_ALL,
    GroupRole.MODERATOR: frozenset({Permission.VIEW_GROUP_STATUS, Permission.MODERATE}),
}
assert not any(p in OWNER_ONLY for perms in ROLE_PERMISSIONS.values() for p in perms)
assert not (TELEGRAM_ADMIN_PERMISSIONS & OWNER_ONLY)


class ActorLevel(str, enum.Enum):
    OWNER = "owner"
    BACKUP_OWNER = "backup_owner"
    DELEGATE = "delegate"
    TELEGRAM_ADMIN = "telegram_admin"
    USER = "user"


@dataclass(frozen=True, slots=True)
class PermissionDecision:
    allowed: bool
    permission: Permission
    reason: str  # ok | owner_only | not_authorized | chat_mismatch | invalid_actor | service_account | store_unavailable | lookup_failed
    level: ActorLevel = ActorLevel.USER


def _valid_id(value: object) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and 0 < value <= MAX_BIGINT


def _valid_group(value: object) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and MIN_BIGINT <= value < 0


class PermissionService:
    def __init__(
        self,
        authority: Authority,
        delegations: DelegationStore,
        chat_info: ChatInfoProvider | None = None,
        audit: SecurityAudit | None = None,
        trust: TrustStore | None = None,
        *,
        clock: Callable[[], datetime] = utcnow,
        denial_audit_interval: float = 60.0,
    ):
        self._authority = authority
        self._delegations = delegations
        self._chat_info = chat_info
        self._audit = audit
        self._trust = trust
        self._clock = clock
        self._interval = denial_audit_interval
        self._last_denial: dict[tuple, datetime] = {}

    # ------------------------------------------------------------------ authorization
    async def check(
        self,
        user_id: object,
        group_id: object,
        permission: Permission,
        *,
        context_chat_id: int | None = None,
        audit_denial: bool = True,
    ) -> PermissionDecision:
        """Decide; never raises for a denial. `user_id` MUST come from the Telegram update
        (message.from_user / callback.from_user), never from message text or callback data.

        `context_chat_id`: the chat where the command/callback happened. When given it must
        equal `group_id` (a command typed in group A cannot act on group B).
        """
        decision = await self._decide(user_id, group_id, permission, context_chat_id)
        if not decision.allowed and audit_denial:
            await self._audit_denial(user_id, group_id, decision)
        return decision

    async def require(
        self, user_id: object, group_id: object, permission: Permission, *, context_chat_id: int | None = None
    ) -> PermissionDecision:
        decision = await self.check(user_id, group_id, permission, context_chat_id=context_chat_id)
        if not decision.allowed:
            raise PermissionDenied(permission.value, decision.reason)
        return decision

    async def check_global(self, user_id: object, permission: Permission, *, audit_denial: bool = True) -> PermissionDecision:
        """Owner-only decision that is NOT tied to one group (the owner panel lists every group). Only OWNER_ONLY permissions
        qualify (anything else is refused outright); the actor must be exactly OWNER_TELEGRAM_ID: not the backup owner, not a
        service account, not an admin or delegate anywhere. Never raises for a denial; denials are audited (throttled)."""
        if permission not in OWNER_ONLY:
            decision = PermissionDecision(False, permission, "not_authorized")
        elif not _valid_id(user_id):
            decision = PermissionDecision(False, permission, "invalid_actor")
        elif user_id in TELEGRAM_SERVICE_ACCOUNT_IDS:
            decision = PermissionDecision(False, permission, "service_account")
        else:
            role = self._authority.role_of(user_id)
            if role is Role.OWNER:
                return PermissionDecision(True, permission, "ok", ActorLevel.OWNER)
            level = ActorLevel.BACKUP_OWNER if role is Role.BACKUP_OWNER else ActorLevel.USER
            decision = PermissionDecision(False, permission, "owner_only", level)
        if audit_denial:
            await self._audit_denial(user_id, None, decision)
        return decision

    async def _decide(
        self, user_id: object, group_id: object, permission: Permission, context_chat_id: int | None
    ) -> PermissionDecision:
        def deny(reason: str, level: ActorLevel = ActorLevel.USER) -> PermissionDecision:
            return PermissionDecision(False, permission, reason, level)

        if not _valid_id(user_id):
            return deny("invalid_actor")
        if user_id in TELEGRAM_SERVICE_ACCOUNT_IDS:
            # Anonymous admins / channel posts / Telegram itself hide the real person: never authorize.
            return deny("service_account")
        if not _valid_group(group_id):
            return deny("not_authorized")
        if context_chat_id is not None and context_chat_id != group_id:
            return deny("chat_mismatch")

        role = self._authority.role_of(user_id)
        if role is Role.OWNER:
            return PermissionDecision(True, permission, "ok", ActorLevel.OWNER)
        level = ActorLevel.BACKUP_OWNER if role is Role.BACKUP_OWNER else ActorLevel.USER
        if permission in OWNER_ONLY:
            return deny("owner_only", level)

        # (a) delegation scoped to THIS group only
        try:
            delegation = await self._delegations.get_live(group_id, user_id)  # type: ignore[arg-type]
        except Exception:
            log.error("delegation lookup failed; denying", exc_info=True)
            return deny("store_unavailable", level)
        if delegation is not None and permission in ROLE_PERMISSIONS[delegation.role]:
            return PermissionDecision(True, permission, "ok", ActorLevel.DELEGATE)

        # (b) live Telegram admin status in THIS group (never cached for authorization)
        if permission in TELEGRAM_ADMIN_PERMISSIONS and self._chat_info is not None:
            try:
                info = await self._chat_info.get_member(group_id, user_id, fresh=True)  # type: ignore[arg-type]
            except Exception:
                return deny("lookup_failed", level)
            if info.is_admin and (permission is not Permission.MODERATE or info.can_restrict()):
                return PermissionDecision(True, permission, "ok", ActorLevel.TELEGRAM_ADMIN)
        return deny("not_authorized", level)

    async def _audit_denial(self, user_id: object, group_id: object, decision: PermissionDecision) -> None:
        now = self._clock()
        key = (repr(user_id)[:40], repr(group_id)[:40], decision.permission, decision.reason)  # ids may be unhashable junk
        last = self._last_denial.get(key)
        if last is not None and (now - last).total_seconds() < self._interval:
            return
        if len(self._last_denial) > 10_000:
            self._last_denial.clear()
        self._last_denial[key] = now
        await record_safely(
            self._audit,
            make_event(
                PERMISSION_DENIED,
                actor=user_id if _valid_id(user_id) else None,
                group_id=group_id if isinstance(group_id, int) and not isinstance(group_id, bool) else None,
                permission=decision.permission.value,
                detail=decision.reason,
                now=now,
            ),
        )

    # ------------------------------------------------------------------ protection from automation
    async def is_protected(self, user_id: object, group_id: int) -> bool:
        """Owner, backup owner, delegates and Telegram admins of THIS group must never receive
        automatic sanctions. Uncertain => True (fail safe: do not punish)."""
        if not _valid_id(user_id):
            return False
        if user_id in TELEGRAM_SERVICE_ACCOUNT_IDS:
            return True  # anonymous admin / channel / Telegram: never sanction
        if self._authority.role_of(user_id) is not Role.USER:
            return True
        try:
            if await self._delegations.get_live(group_id, user_id) is not None:  # type: ignore[arg-type]
                return True
        except Exception:
            return True
        if self._chat_info is not None:
            try:
                info = await self._chat_info.get_member(group_id, user_id)  # type: ignore[arg-type]
            except Exception:
                return True
            if info.is_admin:
                return True
        return False

    async def is_exempt_from_automation(self, user_id: object, group_id: int) -> bool:
        """FULL exemption from every automatic sanction: protected users (owner, backup, delegates, Telegram admins of
        this group, service accounts). Uncertain => True, including an actor that cannot be identified at all (no/invalid
        user id): there is nobody to sanction. The trust list is NOT part of this (part 4.2: no blanket exemption):
        see `is_trusted` and `members/trust.py` for the exact rules a trusted user skips."""
        if not _valid_id(user_id):
            return True
        return await self.is_protected(user_id, group_id)

    async def is_trusted(self, user_id: object, group_id: int) -> bool:
        """Is the user on THIS group's trust list? Raises when the lookup fails (the caller decides what uncertain
        means; the protection gate then does not sanction)."""
        if self._trust is None or not _valid_id(user_id):
            return False
        return bool(await self._trust.is_trusted(group_id, user_id))  # type: ignore[arg-type]
