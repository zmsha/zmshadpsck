"""Typed settings loaded from environment variables with strict validation.

Secrets come ONLY from the environment (see .env.example). Error messages list
variable names and the kind of problem, never the offending values.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Mapping
from urllib.parse import urlsplit
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from .auth import TELEGRAM_SERVICE_ACCOUNT_IDS
from .errors import ConfigError

WEBHOOK_PATH = "/telegram/webhook"

_TOKEN_RE = re.compile(r"^\d{5,}:[A-Za-z0-9_-]{20,}$")
# Telegram secret_token: 1-256 chars of A-Z a-z 0-9 _ - ; we require >= 16 for strength.
_SECRET_RE = re.compile(r"^[A-Za-z0-9_-]{16,256}$")
_GEMINI_KEY_RE = re.compile(r"^[A-Za-z0-9._-]{20,256}$")
_GEMINI_MODEL_RE = re.compile(r"^[A-Za-z0-9._-]{3,80}$")
_LANGS = ("ar", "en")
_ENVS = ("production", "development", "test")
_LOG_LEVELS = ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL")
_TRUE = {"1", "true", "yes", "on"}
_FALSE = {"0", "false", "no", "off", ""}


RETENTION_MIN_DAYS = 30
RETENTION_MAX_DAYS = 730
RETENTION_DEFAULT_DAYS = 180


@dataclass(frozen=True, slots=True, repr=False)
class Settings:
    bot_token: str
    database_url: str
    owner_telegram_id: int
    webhook_secret: str
    backup_owner_telegram_id: int | None = None
    owner_group_id: int | None = None
    webhook_base_url: str | None = None
    webhook_register_on_startup: bool = False
    default_language: str = "ar"
    display_timezone: str = "Asia/Riyadh"
    environment: str = "production"
    log_level: str = "INFO"
    port: int = 10000
    run_migrations_on_startup: bool = True
    db_pool_min: int = 1
    db_pool_max: int = 5
    audit_retention_days: int = 180  # part 6.2: security audit log retention (the license log is never purged)
    gemini_api_keys: tuple[str, ...] = ()  # part 9.2: up to 5 keys from 5 independent Google projects (secrets; env only)
    gemini_model: str = ""                 # part 9.2: optional model override ("" = the built-in default)

    @property
    def webhook_url(self) -> str | None:
        if not self.webhook_base_url:
            return None
        return self.webhook_base_url + WEBHOOK_PATH

    def secret_values(self) -> tuple[str, ...]:
        """Exact strings that must never appear in logs or messages."""
        values = [self.bot_token, self.webhook_secret, self.database_url, *self.gemini_api_keys]
        password = urlsplit(self.database_url).password
        if password:
            values.append(password)
        return tuple(v for v in values if v)

    def __repr__(self) -> str:  # never print secrets
        return (
            f"Settings(environment={self.environment!r}, owner_telegram_id={self.owner_telegram_id}, "
            f"default_language={self.default_language!r}, display_timezone={self.display_timezone!r}, "
            f"webhook_registration={self.webhook_register_on_startup}, secrets=<hidden>)"
        )

    __str__ = __repr__


def _parse_int(raw: str) -> int:
    if not re.fullmatch(r"-?\d+", raw.strip()):
        raise ValueError("not an integer")
    return int(raw.strip())


def load_settings(env: Mapping[str, str] | None = None) -> Settings:
    """Build Settings from `env` (defaults to the process environment, plus .env if present)."""
    if env is None:
        try:  # optional convenience for local development
            from dotenv import load_dotenv

            load_dotenv(override=False)
        except ImportError:  # pragma: no cover
            pass
        env = os.environ

    problems: list[tuple[str, str]] = []

    def get(name: str) -> str | None:
        value = env.get(name)
        if value is None:
            return None
        value = value.strip()
        return value or None

    def required(name: str) -> str | None:
        value = get(name)
        if value is None:
            problems.append((name, "missing"))
        return value

    def as_int(name: str, raw: str | None, *, positive: bool = False, nonzero: bool = False) -> int | None:
        if raw is None:
            return None
        try:
            number = _parse_int(raw)
        except ValueError:
            problems.append((name, "must be an integer"))
            return None
        if positive and number <= 0:
            problems.append((name, "must be a positive integer"))
            return None
        if nonzero and number == 0:
            problems.append((name, "must not be zero"))
            return None
        if not -(2**63) <= number <= 2**63 - 1:
            problems.append((name, "out of range"))
            return None
        return number

    bot_token = required("BOT_TOKEN")
    if bot_token and not _TOKEN_RE.match(bot_token):
        problems.append(("BOT_TOKEN", "invalid format"))
        bot_token = None

    database_url = required("DATABASE_URL")
    if database_url:
        scheme = urlsplit(database_url).scheme
        if scheme not in ("postgresql", "postgres"):
            problems.append(("DATABASE_URL", "must start with postgresql:// or postgres://"))
            database_url = None

    owner_id = as_int("OWNER_TELEGRAM_ID", required("OWNER_TELEGRAM_ID"), positive=True)

    if owner_id in TELEGRAM_SERVICE_ACCOUNT_IDS:
        problems.append(("OWNER_TELEGRAM_ID", "must be a real user id, not a Telegram service account"))
        owner_id = None

    webhook_secret = required("WEBHOOK_SECRET")
    if webhook_secret and not _SECRET_RE.match(webhook_secret):
        problems.append(("WEBHOOK_SECRET", "must be 16-256 chars of A-Z a-z 0-9 _ -"))
        webhook_secret = None

    backup_owner = as_int("BACKUP_OWNER_TELEGRAM_ID", get("BACKUP_OWNER_TELEGRAM_ID"), positive=True)
    if backup_owner in TELEGRAM_SERVICE_ACCOUNT_IDS:
        problems.append(("BACKUP_OWNER_TELEGRAM_ID", "must be a real user id, not a Telegram service account"))
        backup_owner = None
    if backup_owner is not None and owner_id is not None and backup_owner == owner_id:
        problems.append(("BACKUP_OWNER_TELEGRAM_ID", "must differ from OWNER_TELEGRAM_ID"))
        backup_owner = None

    owner_group_id = as_int("OWNER_GROUP_ID", get("OWNER_GROUP_ID"), nonzero=True)

    base_url = get("WEBHOOK_BASE_URL") or get("RENDER_EXTERNAL_URL")
    if base_url:
        base_url = base_url.rstrip("/")
        parts = urlsplit(base_url)
        if parts.scheme != "https" or not parts.netloc or parts.path not in ("", "/") or parts.query:
            problems.append(("WEBHOOK_BASE_URL", "must be a bare https:// origin"))
            base_url = None

    register_raw = (get("WEBHOOK_REGISTER_ON_STARTUP") or "false").lower()
    if register_raw not in _TRUE | _FALSE:
        problems.append(("WEBHOOK_REGISTER_ON_STARTUP", "must be true or false"))
        register = False
    else:
        register = register_raw in _TRUE
    if register and not base_url:
        problems.append(("WEBHOOK_BASE_URL", "required when WEBHOOK_REGISTER_ON_STARTUP is true"))

    language = (get("DEFAULT_LANGUAGE") or "ar").lower()
    if language not in _LANGS:
        problems.append(("DEFAULT_LANGUAGE", "must be ar or en"))
        language = "ar"

    timezone = get("DISPLAY_TIMEZONE") or "Asia/Riyadh"
    try:
        ZoneInfo(timezone)
    except (ZoneInfoNotFoundError, ValueError, OSError):
        problems.append(("DISPLAY_TIMEZONE", "unknown IANA timezone"))
        timezone = "Asia/Riyadh"

    environment = (get("ENVIRONMENT") or "production").lower()
    if environment not in _ENVS:
        problems.append(("ENVIRONMENT", "must be production, development or test"))
        environment = "production"

    log_level = (get("LOG_LEVEL") or "INFO").upper()
    if log_level not in _LOG_LEVELS:
        problems.append(("LOG_LEVEL", "invalid log level"))
        log_level = "INFO"

    port = as_int("PORT", get("PORT") or "10000", positive=True)
    if port is not None and port > 65535:
        problems.append(("PORT", "must be 1-65535"))
        port = None

    migrate_raw = (get("RUN_MIGRATIONS_ON_STARTUP") or "true").lower()
    if migrate_raw not in _TRUE | _FALSE:
        problems.append(("RUN_MIGRATIONS_ON_STARTUP", "must be true or false"))
        migrate_raw = "true"

    pool_min = as_int("DB_POOL_MIN", get("DB_POOL_MIN") or "1", positive=True)
    pool_max = as_int("DB_POOL_MAX", get("DB_POOL_MAX") or "5", positive=True)
    if pool_min is not None and pool_max is not None and pool_min > pool_max:
        problems.append(("DB_POOL_MIN", "must not exceed DB_POOL_MAX"))

    retention = as_int("AUDIT_RETENTION_DAYS", get("AUDIT_RETENTION_DAYS") or str(RETENTION_DEFAULT_DAYS), positive=True)
    if retention is not None and not RETENTION_MIN_DAYS <= retention <= RETENTION_MAX_DAYS:
        problems.append(("AUDIT_RETENTION_DAYS", f"must be between {RETENTION_MIN_DAYS} and {RETENTION_MAX_DAYS}"))
        retention = None

    if problems:
        raise ConfigError(problems)

    gemini_keys: list[str] = []
    for name, raw in (("GEMINI_API_KEY_1", get("GEMINI_API_KEY_1")), ("GEMINI_API_KEY_2", get("GEMINI_API_KEY_2")),
                      ("GEMINI_API_KEY_3", get("GEMINI_API_KEY_3")), ("GEMINI_API_KEY_4", get("GEMINI_API_KEY_4")),
                      ("GEMINI_API_KEY_5", get("GEMINI_API_KEY_5"))):
        if raw is None:
            continue
        if not _GEMINI_KEY_RE.match(raw):
            problems.append((name, "invalid format"))
        elif raw not in gemini_keys:
            gemini_keys.append(raw)
    gemini_model = get("GEMINI_MODEL") or ""
    if gemini_model and not _GEMINI_MODEL_RE.match(gemini_model):
        problems.append(("GEMINI_MODEL", "invalid format"))
        gemini_model = ""

    assert bot_token and database_url and owner_id and webhook_secret and port
    assert pool_min is not None and pool_max is not None
    return Settings(
        bot_token=bot_token,
        database_url=database_url,
        owner_telegram_id=owner_id,
        webhook_secret=webhook_secret,
        backup_owner_telegram_id=backup_owner,
        owner_group_id=owner_group_id,
        webhook_base_url=base_url,
        webhook_register_on_startup=register,
        default_language=language,
        display_timezone=timezone,
        environment=environment,
        log_level=log_level,
        port=port,
        run_migrations_on_startup=migrate_raw in _TRUE,
        db_pool_min=pool_min,
        db_pool_max=pool_max,
        audit_retention_days=retention if retention is not None else RETENTION_DEFAULT_DAYS,
        gemini_api_keys=tuple(gemini_keys),
        gemini_model=gemini_model,
    )
