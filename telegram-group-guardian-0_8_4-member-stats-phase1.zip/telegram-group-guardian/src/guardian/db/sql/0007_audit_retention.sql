-- 0007_audit_retention (Phase 6, part 6.2): the ONE explicit way to delete old rows from security_audit_log.
-- Why not edit 0006: 0006 may already be applied (the runner rejects edited files), so this is a new migration.
--
-- * The append-only trigger on security_audit_log is replaced by a guard that still forbids every UPDATE and every
--   DELETE, except a DELETE of rows older than 30 days made while the transaction-local setting
--   guardian.audit_purge = 'on'. Only guardian_purge_security_audit() sets it, and only for its own transaction.
-- * The TRUNCATE trigger is untouched. license_audit_log and its triggers are untouched: license history is never purged.
-- * Honest limit: anyone with direct SQL access could set the setting themselves; this protects against application
--   bugs and accidental statements, not against a database administrator.
-- 0001-0006 are NOT edited. NOT executed against a real PostgreSQL in the build sandbox.

CREATE OR REPLACE FUNCTION guardian_security_audit_guard() RETURNS trigger AS $$
BEGIN
    IF TG_OP = 'DELETE'
       AND current_setting('guardian.audit_purge', true) = 'on'
       AND OLD.occurred_at < now() - interval '30 days' THEN
        RETURN OLD;
    END IF;
    RAISE EXCEPTION 'table % is append-only', TG_TABLE_NAME USING ERRCODE = 'insufficient_privilege';
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS security_audit_no_update_delete ON security_audit_log;
CREATE TRIGGER security_audit_no_update_delete
    BEFORE UPDATE OR DELETE ON security_audit_log
    FOR EACH ROW EXECUTE FUNCTION guardian_security_audit_guard();

CREATE OR REPLACE FUNCTION guardian_purge_security_audit(p_cutoff timestamptz, p_max_rows integer DEFAULT 1000)
RETURNS bigint AS $$
DECLARE
    deleted bigint;
BEGIN
    IF p_cutoff IS NULL OR p_cutoff > now() - interval '30 days' THEN
        RAISE EXCEPTION 'audit retention cutoff must be at least 30 days old' USING ERRCODE = 'invalid_parameter_value';
    END IF;
    IF p_max_rows IS NULL OR p_max_rows < 1 OR p_max_rows > 10000 THEN
        RAISE EXCEPTION 'audit purge batch must be between 1 and 10000' USING ERRCODE = 'invalid_parameter_value';
    END IF;
    PERFORM set_config('guardian.audit_purge', 'on', true);      -- transaction-local
    DELETE FROM security_audit_log
     WHERE id IN (SELECT id FROM security_audit_log WHERE occurred_at < p_cutoff ORDER BY id LIMIT p_max_rows);
    GET DIAGNOSTICS deleted = ROW_COUNT;
    PERFORM set_config('guardian.audit_purge', 'off', true);
    RETURN deleted;
END;
$$ LANGUAGE plpgsql;
