-- 0011_content_filter (part 9.2): the durable state of the content filter. Three small tables, none holds message text,
-- names or photos (privacy): only ids, closed-vocabulary words and timestamps.
--   content_violations  one row per ACTION the filter took against a member (the escalation ladder counts them:
--                       warning -> 1 h mute -> 24 h mute -> ban). `idempotency_key` makes a redelivered update count once.
--   content_reviews     a suspected (WARNING) case waiting for a human decision: the member was muted 24 h and the admins were
--                       sent two buttons (confirm + ban / reject + unmute). `status` moves pending -> confirmed|rejected ONCE
--                       (the first valid decision wins); who decided and when is stored.
--   gemini_key_state    quota/validity state per Gemini key SLOT (1..5). Only a short SHA-256 fingerprint of the key is kept so a
--                       replaced key starts clean; the key itself is never stored.
-- Per-group tables reference telegram_groups with ON DELETE RESTRICT like every other one. 0001-0010 are NOT edited.
-- NOT executed against a real PostgreSQL in the build sandbox.

CREATE TABLE IF NOT EXISTS content_violations (
    id              BIGSERIAL   PRIMARY KEY,
    group_id        BIGINT      NOT NULL REFERENCES telegram_groups (group_id) ON DELETE RESTRICT,
    user_id         BIGINT      NOT NULL CHECK (user_id > 0),
    source          TEXT        NOT NULL,
    category        TEXT        NOT NULL,
    action          TEXT        NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL,
    idempotency_key TEXT        UNIQUE
);
CREATE INDEX IF NOT EXISTS content_violations_member_idx ON content_violations (group_id, user_id, created_at);

CREATE TABLE IF NOT EXISTS content_reviews (
    id          BIGSERIAL   PRIMARY KEY,
    group_id    BIGINT      NOT NULL REFERENCES telegram_groups (group_id) ON DELETE RESTRICT,
    user_id     BIGINT      NOT NULL CHECK (user_id > 0),
    source      TEXT        NOT NULL,
    category    TEXT        NOT NULL,
    reason      TEXT        NOT NULL DEFAULT '',
    confidence  REAL        NOT NULL DEFAULT 0 CHECK (confidence >= 0 AND confidence <= 1),
    status      TEXT        NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'rejected')),
    created_at  TIMESTAMPTZ NOT NULL,
    decided_by  BIGINT      CHECK (decided_by IS NULL OR decided_by > 0),
    decided_at  TIMESTAMPTZ,
    notified    INTEGER     NOT NULL DEFAULT 0,
    failed      INTEGER     NOT NULL DEFAULT 0,
    CONSTRAINT content_reviews_decision_complete CHECK (
        (status = 'pending' AND decided_by IS NULL AND decided_at IS NULL)
        OR (status <> 'pending' AND decided_by IS NOT NULL AND decided_at IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS content_reviews_group_idx ON content_reviews (group_id, status, created_at);

CREATE TABLE IF NOT EXISTS gemini_key_state (
    slot        SMALLINT    PRIMARY KEY CHECK (slot BETWEEN 1 AND 5),
    fingerprint TEXT        NOT NULL,
    status      TEXT        NOT NULL CHECK (status IN ('ok', 'exhausted', 'invalid')),
    until       TIMESTAMPTZ,
    updated_at  TIMESTAMPTZ NOT NULL
);
