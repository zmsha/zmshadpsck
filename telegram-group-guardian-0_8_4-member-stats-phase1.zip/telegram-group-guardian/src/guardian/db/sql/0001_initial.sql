-- 0001_initial: global settings, registered groups (with license state) and the license audit log.
-- Phase 1 = initial schema. Phase 2 adds: append-only enforcement on license_audit_log,
-- extra indexes/constraints, and the full repository. Timestamps are UTC (timestamptz).

CREATE TABLE IF NOT EXISTS global_settings (
    key         TEXT PRIMARY KEY,
    value       JSONB NOT NULL,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by  BIGINT
);

CREATE TABLE IF NOT EXISTS telegram_groups (
    group_id        BIGINT PRIMARY KEY,
    title           TEXT,
    license_status  TEXT NOT NULL DEFAULT 'pending'
        CHECK (license_status IN
            ('pending','active_permanent','active_temporary','expired','stopped','rejected','banned')),
    activated_at    TIMESTAMPTZ,
    expires_at      TIMESTAMPTZ,
    activated_by    BIGINT,
    status_note     TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT telegram_groups_permanent_no_expiry
        CHECK (license_status <> 'active_permanent' OR expires_at IS NULL),
    CONSTRAINT telegram_groups_temporary_has_expiry
        CHECK (license_status <> 'active_temporary' OR expires_at IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS idx_telegram_groups_license_status ON telegram_groups (license_status);
CREATE INDEX IF NOT EXISTS idx_telegram_groups_expires_at ON telegram_groups (expires_at)
    WHERE expires_at IS NOT NULL;

CREATE TABLE IF NOT EXISTS license_audit_log (
    id                 BIGSERIAL PRIMARY KEY,
    group_id           BIGINT NOT NULL,
    actor_telegram_id  BIGINT,            -- NULL = system action
    action             TEXT NOT NULL,
    previous_status    TEXT,
    new_status         TEXT NOT NULL,
    expires_at         TIMESTAMPTZ,
    reason             TEXT,
    occurred_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_license_audit_group_time ON license_audit_log (group_id, occurred_at);
