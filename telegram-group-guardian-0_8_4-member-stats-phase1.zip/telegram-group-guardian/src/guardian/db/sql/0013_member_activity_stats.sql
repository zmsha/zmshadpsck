-- 0013_member_activity_stats (statistics phase 1): PERMANENT per-member statistics, one row per (group, user).
-- A member's numbers are independent in every group: the key is (group_id, user_id) and no statement ever reads or
-- writes across groups. A row is never deleted when the member leaves, is kicked or banned: if the member comes back
-- the counters simply continue. Rows are tiny (one per member per group that ever spoke or was sanctioned).
--
--   total_messages    every message the member sent in the group (a deleted message counts here too; an EDIT never does)
--   today_messages    messages sent on `today_date`, the calendar date in the bot's DISPLAY_TIMEZONE; readers treat the
--                     value as 0 when `today_date` is not the current local day, writers reset it on the first message
--                     of a new day (one atomic upsert, so the rollover needs no job)
--   deleted_messages  messages the bot deleted because of a violation
--   violations        messages the protection engine / content filter acted on
--   warnings          warnings issued (automatic or manual); revoking or clearing a warning does NOT lower it
--   mutes, bans       mutes / bans recorded (automatic or manual); lifting one does NOT lower it
--   last_activity_at  time of the member's last message (NULL while the member only has sanctions on record)
--
-- group_id references telegram_groups with ON DELETE RESTRICT like every other per-group table. 0001-0012 are NOT edited.
-- NOT executed against a real PostgreSQL in the build sandbox.

CREATE TABLE IF NOT EXISTS member_activity_stats (
    group_id         BIGINT      NOT NULL REFERENCES telegram_groups (group_id) ON DELETE RESTRICT,
    user_id          BIGINT      NOT NULL CHECK (user_id > 0),
    total_messages   BIGINT      NOT NULL DEFAULT 0 CHECK (total_messages >= 0),
    today_date       DATE,
    today_messages   BIGINT      NOT NULL DEFAULT 0 CHECK (today_messages >= 0),
    deleted_messages BIGINT      NOT NULL DEFAULT 0 CHECK (deleted_messages >= 0),
    violations       BIGINT      NOT NULL DEFAULT 0 CHECK (violations >= 0),
    warnings         BIGINT      NOT NULL DEFAULT 0 CHECK (warnings >= 0),
    mutes            BIGINT      NOT NULL DEFAULT 0 CHECK (mutes >= 0),
    bans             BIGINT      NOT NULL DEFAULT 0 CHECK (bans >= 0),
    last_activity_at TIMESTAMPTZ,
    first_seen_at    TIMESTAMPTZ NOT NULL,
    updated_at       TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (group_id, user_id),
    CHECK (today_messages <= total_messages)
);

-- "Top members" of one group: the most active first.
CREATE INDEX IF NOT EXISTS idx_member_activity_stats_top
    ON member_activity_stats (group_id, total_messages DESC, user_id);
