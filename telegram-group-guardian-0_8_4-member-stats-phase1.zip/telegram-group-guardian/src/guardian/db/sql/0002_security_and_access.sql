-- 0002_security_and_access (Phase 2): append-only audit, delegations, trust lists, per-group
-- settings, security audit, idempotency keys, moderation tables (schema only), extra constraints.
-- All timestamps are UTC (timestamptz). Every per-group table is keyed/filtered by group_id.
-- NOT executed against a real PostgreSQL in the build sandbox (see TEST_REPORT.md).

-- ---------------------------------------------------------------------------------------------
-- 1) Tighten telegram_groups (Telegram group / supergroup chat ids are always negative).
-- ---------------------------------------------------------------------------------------------
ALTER TABLE telegram_groups
    ADD CONSTRAINT telegram_groups_negative_id CHECK (group_id < 0);

-- An active license must record who activated it and when.
ALTER TABLE telegram_groups
    ADD CONSTRAINT telegram_groups_active_has_activation
    CHECK (license_status NOT IN ('active_permanent', 'active_temporary')
           OR (activated_at IS NOT NULL AND activated_by IS NOT NULL));

-- ---------------------------------------------------------------------------------------------
-- 2) license_audit_log: valid statuses + APPEND-ONLY (no UPDATE / DELETE / TRUNCATE).
-- ---------------------------------------------------------------------------------------------
ALTER TABLE license_audit_log
    ADD CONSTRAINT license_audit_new_status_valid CHECK (new_status IN
        ('pending','active_permanent','active_temporary','expired','stopped','rejected','banned')),
    ADD CONSTRAINT license_audit_prev_status_valid CHECK (previous_status IS NULL OR previous_status IN
        ('pending','active_permanent','active_temporary','expired','stopped','rejected','banned')),
    ADD CONSTRAINT license_audit_action_not_blank CHECK (length(btrim(action)) > 0),
    ADD CONSTRAINT license_audit_reason_len CHECK (reason IS NULL OR length(reason) <= 500);

-- Audit rows must survive anything: group rows can never be deleted while they have audit history.
ALTER TABLE license_audit_log
    ADD CONSTRAINT license_audit_group_fk
    FOREIGN KEY (group_id) REFERENCES telegram_groups (group_id) ON DELETE RESTRICT;

CREATE INDEX IF NOT EXISTS idx_license_audit_actor ON license_audit_log (actor_telegram_id, occurred_at)
    WHERE actor_telegram_id IS NOT NULL;

CREATE OR REPLACE FUNCTION guardian_forbid_modification() RETURNS trigger AS $$
BEGIN
    RAISE EXCEPTION 'table % is append-only', TG_TABLE_NAME USING ERRCODE = 'insufficient_privilege';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER license_audit_no_update_delete
    BEFORE UPDATE OR DELETE ON license_audit_log
    FOR EACH ROW EXECUTE FUNCTION guardian_forbid_modification();

CREATE TRIGGER license_audit_no_truncate
    BEFORE TRUNCATE ON license_audit_log
    FOR EACH STATEMENT EXECUTE FUNCTION guardian_forbid_modification();

-- ---------------------------------------------------------------------------------------------
-- 3) security_audit_log: denied attempts, forged callbacks, role changes (append-only).
--    group_id has NO foreign key on purpose: attacks may target unregistered groups.
-- ---------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS security_audit_log (
    id                 BIGSERIAL PRIMARY KEY,
    event_type         TEXT NOT NULL CHECK (length(btrim(event_type)) > 0),
    actor_telegram_id  BIGINT,
    group_id           BIGINT,
    permission         TEXT,
    detail             TEXT CHECK (detail IS NULL OR length(detail) <= 500),   -- sanitized, no message content
    occurred_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_security_audit_time ON security_audit_log (occurred_at);
CREATE INDEX IF NOT EXISTS idx_security_audit_group ON security_audit_log (group_id, occurred_at)
    WHERE group_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_security_audit_actor ON security_audit_log (actor_telegram_id, occurred_at)
    WHERE actor_telegram_id IS NOT NULL;

CREATE TRIGGER security_audit_no_update_delete
    BEFORE UPDATE OR DELETE ON security_audit_log
    FOR EACH ROW EXECUTE FUNCTION guardian_forbid_modification();

CREATE TRIGGER security_audit_no_truncate
    BEFORE TRUNCATE ON security_audit_log
    FOR EACH STATEMENT EXECUTE FUNCTION guardian_forbid_modification();

-- ---------------------------------------------------------------------------------------------
-- 4) Per-group settings (one row per group; content defined by later phases).
-- ---------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS group_settings (
    group_id    BIGINT PRIMARY KEY REFERENCES telegram_groups (group_id) ON DELETE CASCADE,
    language    TEXT CHECK (language IS NULL OR language IN ('ar', 'en')),
    settings    JSONB NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(settings) = 'object'),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by  BIGINT
);

-- ---------------------------------------------------------------------------------------------
-- 5) Delegated custom roles, scoped to ONE group. Granted only by the primary owner.
--    Revocation keeps history (revoked_at); at most one live row per (group, user).
-- ---------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS group_delegations (
    id          BIGSERIAL PRIMARY KEY,
    group_id    BIGINT NOT NULL REFERENCES telegram_groups (group_id) ON DELETE CASCADE,
    user_id     BIGINT NOT NULL CHECK (user_id > 0),
    role        TEXT NOT NULL CHECK (role IN ('group_manager', 'moderator')),
    granted_by  BIGINT NOT NULL,
    granted_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    revoked_at  TIMESTAMPTZ,
    revoked_by  BIGINT,
    CONSTRAINT group_delegations_revoked_pair CHECK ((revoked_at IS NULL) = (revoked_by IS NULL))
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_group_delegations_live
    ON group_delegations (group_id, user_id) WHERE revoked_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_group_delegations_user ON group_delegations (user_id) WHERE revoked_at IS NULL;

-- ---------------------------------------------------------------------------------------------
-- 6) Trust lists (users exempt from automatic sanctions in ONE group).
-- ---------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS group_trusted_users (
    group_id   BIGINT NOT NULL REFERENCES telegram_groups (group_id) ON DELETE CASCADE,
    user_id    BIGINT NOT NULL CHECK (user_id > 0),
    added_by   BIGINT NOT NULL,
    added_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    note       TEXT CHECK (note IS NULL OR length(note) <= 200),
    PRIMARY KEY (group_id, user_id)
);

-- ---------------------------------------------------------------------------------------------
-- 7) Idempotency / processed updates. key examples: 'update:123456', 'op:<scope>:<id>'.
-- ---------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS idempotency_keys (
    key         TEXT PRIMARY KEY CHECK (length(key) BETWEEN 1 AND 200),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_idempotency_created ON idempotency_keys (created_at);

-- ---------------------------------------------------------------------------------------------
-- 8) Moderation records: SCHEMA ONLY in Phase 2 (repositories + commands arrive in Phase 3).
-- ---------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS moderation_warnings (
    id          BIGSERIAL PRIMARY KEY,
    group_id    BIGINT NOT NULL REFERENCES telegram_groups (group_id) ON DELETE CASCADE,
    user_id     BIGINT NOT NULL CHECK (user_id > 0),
    issued_by   BIGINT,                      -- NULL = automatic (system)
    reason      TEXT CHECK (reason IS NULL OR length(reason) <= 500),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at  TIMESTAMPTZ,
    revoked_at  TIMESTAMPTZ,
    revoked_by  BIGINT
);

CREATE INDEX IF NOT EXISTS idx_moderation_warnings_user
    ON moderation_warnings (group_id, user_id) WHERE revoked_at IS NULL;

CREATE TABLE IF NOT EXISTS moderation_sanctions (
    id               BIGSERIAL PRIMARY KEY,
    group_id         BIGINT NOT NULL REFERENCES telegram_groups (group_id) ON DELETE CASCADE,
    user_id          BIGINT NOT NULL CHECK (user_id > 0),
    kind             TEXT NOT NULL CHECK (kind IN ('mute', 'ban', 'kick')),
    issued_by        BIGINT,                 -- NULL = automatic (system)
    reason           TEXT CHECK (reason IS NULL OR length(reason) <= 500),
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at       TIMESTAMPTZ,
    lifted_at        TIMESTAMPTZ,
    lifted_by        BIGINT,
    idempotency_key  TEXT UNIQUE            -- repeated webhook delivery must not repeat a sanction
);

CREATE INDEX IF NOT EXISTS idx_moderation_sanctions_user
    ON moderation_sanctions (group_id, user_id) WHERE lifted_at IS NULL;
