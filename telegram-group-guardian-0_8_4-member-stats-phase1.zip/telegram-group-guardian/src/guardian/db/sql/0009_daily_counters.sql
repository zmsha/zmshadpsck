-- 0009_daily_counters (Phase 6, part 6.5a): the only NEW table of the statistics module.
-- One row per (group, local day, counter): a running total of things that leave no row anywhere else
-- ('violation' = a message the protection engine acted on; 'command' = a moderation command handled for a
-- permitted actor; 'command_rejected' = a command refused for permission/licence). Everything else /stats shows is
-- read from tables that already exist (warnings, sanctions, reports, security audit): nothing is invented.
-- `day` is the calendar date in the bot's DISPLAY_TIMEZONE (Asia/Riyadh by default) at the moment of the event, so
-- "today" in a report matches one row set. Rows are tiny (<= 3 per group per day) and are not purged.
-- Per-group data: group_id references telegram_groups with ON DELETE RESTRICT, like every other per-group table.
-- 0001-0008 are NOT edited. NOT executed against a real PostgreSQL in the build sandbox.

CREATE TABLE IF NOT EXISTS daily_group_counters (
    group_id   BIGINT      NOT NULL REFERENCES telegram_groups (group_id) ON DELETE RESTRICT,
    day        DATE        NOT NULL,
    counter    TEXT        NOT NULL CHECK (counter IN ('violation', 'command', 'command_rejected')),
    value      BIGINT      NOT NULL CHECK (value >= 0),
    updated_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (group_id, day, counter)
);
