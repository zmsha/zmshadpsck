-- 0006_audit_trace (Phase 6, part 6.1): what the event acted on (target_id), its outcome (result) and the update that
-- produced it (trace_id) in security_audit_log. All columns are nullable: existing rows and events without the data
-- stay valid. ADD COLUMN is DDL, so the append-only row/truncate triggers are untouched and keep forbidding
-- UPDATE/DELETE/TRUNCATE (old rows are NOT back-filled). 0001-0005 are NOT edited.
-- NOT executed against a real PostgreSQL in the build sandbox.

ALTER TABLE security_audit_log ADD COLUMN IF NOT EXISTS target_id TEXT
    CHECK (target_id IS NULL OR length(target_id) <= 64);
ALTER TABLE security_audit_log ADD COLUMN IF NOT EXISTS result TEXT
    CHECK (result IS NULL OR result IN ('allowed', 'denied', 'failed', 'applied'));
ALTER TABLE security_audit_log ADD COLUMN IF NOT EXISTS trace_id TEXT
    CHECK (trace_id IS NULL OR trace_id ~ '^[0-9a-f]{16}$');

CREATE INDEX IF NOT EXISTS idx_security_audit_trace ON security_audit_log (trace_id) WHERE trace_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_security_audit_target ON security_audit_log (group_id, target_id, occurred_at)
    WHERE target_id IS NOT NULL;
