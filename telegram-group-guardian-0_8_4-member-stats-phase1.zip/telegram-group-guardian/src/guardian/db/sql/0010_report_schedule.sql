-- 0010_report_schedule (Phase 6, part 6.6a): which periodic reports each group has switched on, and how far they got.
-- One row per (group, period) that was ever touched; NO row means "off" (the default: periodic reports are opt-in).
--   enabled         the switch. Starts FALSE; nothing in this part sends anything.
--   enabled_from    the UTC instant of the latest off -> on switch. Calendar periods that ENDED before it are never owed
--                   (switching on today must not replay last year). The period that contains it IS owed once it ends.
--   last_period_key the newest period already handled (6.6b advances it only after a successful send; it never moves
--                   backwards): day = local date 'YYYY-MM-DD', week = local date of its first day (Sunday) 'YYYY-MM-DD',
--                   month = 'YYYY-MM'. Calendar periods use DISPLAY_TIMEZONE (Asia/Riyadh = Makkah time by default).
--   changed_by      the Telegram user id of who flipped the switch last (NULL until the first change is recorded).
-- Per-group data: group_id references telegram_groups with ON DELETE RESTRICT, like every other per-group table.
-- 0001-0009 are NOT edited and no audit trigger is touched. NOT executed against a real PostgreSQL in the build sandbox.

CREATE TABLE IF NOT EXISTS report_schedule (
    group_id        BIGINT      NOT NULL REFERENCES telegram_groups (group_id) ON DELETE RESTRICT,
    period          TEXT        NOT NULL CHECK (period IN ('day', 'week', 'month')),
    enabled         BOOLEAN     NOT NULL DEFAULT FALSE,
    enabled_from    TIMESTAMPTZ,
    last_period_key TEXT,
    changed_by      BIGINT      CHECK (changed_by IS NULL OR changed_by > 0),
    updated_at      TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (group_id, period),
    CONSTRAINT report_schedule_enabled_has_start CHECK (NOT enabled OR enabled_from IS NOT NULL),
    CONSTRAINT report_schedule_key_matches_period CHECK (
        last_period_key IS NULL
        OR (period = 'month' AND last_period_key ~ '^[0-9]{4}-[0-9]{2}$')
        OR (period IN ('day', 'week') AND last_period_key ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$')
    )
);
