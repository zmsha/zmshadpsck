-- 0008_group_reports (Phase 6, part 6.3): the report store behind `/report`.
-- One row per filed report. Closed vocabularies are enforced by CHECK constraints (repeated in reports/models.py; a test
-- keeps both lists in sync). The status columns must agree with each other (see group_reports_state_consistent).
-- Per-group data: group_id references telegram_groups with ON DELETE RESTRICT, like every other per-group table.
-- Reports are NOT purged by the audit retention (6.2) and the append-only audit triggers are untouched.
-- 0001-0007 are NOT edited. NOT executed against a real PostgreSQL in the build sandbox.

CREATE TABLE IF NOT EXISTS group_reports (
    id              BIGSERIAL PRIMARY KEY,
    group_id        BIGINT      NOT NULL REFERENCES telegram_groups (group_id) ON DELETE RESTRICT,
    reporter_id     BIGINT      NOT NULL CHECK (reporter_id > 0),
    target_user_id  BIGINT      NOT NULL CHECK (target_user_id > 0),
    message_id      BIGINT      CHECK (message_id IS NULL OR message_id > 0),
    reason          TEXT        CHECK (reason IS NULL OR length(reason) <= 200),
    report_type     TEXT        NOT NULL DEFAULT 'other' CHECK (report_type IN ('spam', 'abuse', 'scam', 'other')),
    priority        TEXT        NOT NULL DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high')),
    status          TEXT        NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'taken', 'resolved', 'dismissed')),
    assigned_to     BIGINT      CHECK (assigned_to IS NULL OR assigned_to > 0),
    outcome         TEXT        CHECK (outcome IS NULL OR outcome IN ('action_taken', 'no_action', 'false_report')),
    handled_by      BIGINT      CHECK (handled_by IS NULL OR handled_by > 0),
    handled_at      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL,
    updated_at      TIMESTAMPTZ NOT NULL,
    trace_id        TEXT        CHECK (trace_id IS NULL OR trace_id ~ '^[0-9a-f]{16}$'),
    idempotency_key TEXT        CHECK (idempotency_key IS NULL OR length(idempotency_key) BETWEEN 1 AND 200),
    CONSTRAINT group_reports_state_consistent CHECK (
        (status = 'open'      AND assigned_to IS NULL     AND handled_by IS NULL     AND handled_at IS NULL     AND outcome IS NULL)
     OR (status = 'taken'     AND assigned_to IS NOT NULL AND handled_by IS NULL     AND handled_at IS NULL     AND outcome IS NULL)
     OR (status IN ('resolved', 'dismissed') AND handled_by IS NOT NULL AND handled_at IS NOT NULL AND outcome IS NOT NULL)
    )
);

-- A redelivered /report (same key) in the same group must not store a second report.
CREATE UNIQUE INDEX IF NOT EXISTS uq_group_reports_idem
    ON group_reports (group_id, idempotency_key) WHERE idempotency_key IS NOT NULL;

-- Listing: one group, optionally one status, newest first.
CREATE INDEX IF NOT EXISTS idx_group_reports_group_status
    ON group_reports (group_id, status, id DESC);
