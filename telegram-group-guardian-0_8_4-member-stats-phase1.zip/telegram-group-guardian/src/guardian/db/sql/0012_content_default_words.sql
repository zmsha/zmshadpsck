-- 0012_content_default_words (part 9.5): the owner's changes to the DEFAULT word list of the content filter.
-- The bundled lists (content_filter/data/*.txt) are part of the code and are reset by every deploy, so the owner's additions and
-- removals live here and are merged over them when the bot starts and after each owner command.
--   word    the FOLDED word (same normalisation the classifier uses; a single token)
--   action  'add'    = a word the owner added (treated as explicit: block)
--           'remove' = a bundled word the owner switched off (never an owner-added word: those rows are simply deleted)
-- Global (owner-level), not per group; reachable only through the owner-only command service. Holds only closed-vocabulary words
-- and ids, never message text. 0001-0011 are NOT edited. NOT executed against a real PostgreSQL in the build sandbox.

CREATE TABLE IF NOT EXISTS content_default_words (
    word        TEXT        PRIMARY KEY CHECK (char_length(word) BETWEEN 2 AND 64),
    action      TEXT        NOT NULL CHECK (action IN ('add', 'remove')),
    changed_by  BIGINT      NOT NULL CHECK (changed_by > 0),
    changed_at  TIMESTAMPTZ NOT NULL
);
