-- 0004_members_welcome_verification (Phase 4, part 1): storage for member verification challenges and the
-- per-group trusted-bots list. Welcome/verification SETTINGS live in group_settings.settings (flat JSON, see
-- members/settings.py), and trusted USERS/DOMAINS reuse group_trusted_users / settings key links_allow_domains:
-- no parallel system. 0001-0003 are NOT edited. NOT executed against a real PostgreSQL in the build sandbox.

-- ---------------------------------------------------------------------------------------------
-- 1) Trusted bots: one list per group. A trusted bot is only exempt from the "unknown bot added" policy and
--    from automatic sanctions; it never bypasses licensing (see members/settings.py and PHASE4_PLAN.md).
-- ---------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS group_trusted_bots (
    group_id   BIGINT NOT NULL REFERENCES telegram_groups (group_id) ON DELETE CASCADE,
    bot_id     BIGINT NOT NULL CHECK (bot_id > 0),
    added_by   BIGINT NOT NULL CHECK (added_by > 0),
    added_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    note       TEXT CHECK (note IS NULL OR length(note) <= 200),
    PRIMARY KEY (group_id, bot_id)
);

-- ---------------------------------------------------------------------------------------------
-- 2) Member verification challenges (one row per challenge; resolved rows are kept for audit/anti-rejoin
--    until purged). status moves ONLY away from 'pending' (compare-and-set in the store).
-- ---------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS member_verifications (
    id                BIGSERIAL PRIMARY KEY,
    group_id          BIGINT NOT NULL REFERENCES telegram_groups (group_id) ON DELETE CASCADE,
    user_id           BIGINT NOT NULL CHECK (user_id > 0),
    kind              TEXT NOT NULL CHECK (kind IN ('button', 'math', 'choice', 'admin')),
    status            TEXT NOT NULL DEFAULT 'pending'
                      CHECK (status IN ('pending', 'passed', 'failed', 'expired', 'approved', 'rejected', 'cancelled')),
    answer            TEXT CHECK (answer IS NULL OR length(answer) <= 20),
    attempts          INTEGER NOT NULL DEFAULT 0 CHECK (attempts BETWEEN 0 AND 20),
    failure_action    TEXT NOT NULL CHECK (failure_action IN ('restrict', 'kick', 'ban')),
    ban_seconds       INTEGER CHECK (ban_seconds IS NULL OR ban_seconds > 0),
    prompt_message_id BIGINT CHECK (prompt_message_id IS NULL OR prompt_message_id > 0),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at        TIMESTAMPTZ NOT NULL,
    resolved_at       TIMESTAMPTZ,
    resolved_by       BIGINT CHECK (resolved_by IS NULL OR resolved_by > 0),
    idempotency_key   TEXT NOT NULL CHECK (length(idempotency_key) BETWEEN 1 AND 200),
    CONSTRAINT member_verifications_expiry_after_create CHECK (expires_at > created_at),
    CONSTRAINT member_verifications_resolved_consistent CHECK ((status = 'pending') = (resolved_at IS NULL)),
    CONSTRAINT member_verifications_resolver_needs_resolution CHECK (resolved_by IS NULL OR resolved_at IS NOT NULL),
    CONSTRAINT member_verifications_ban_seconds_only_ban CHECK (failure_action = 'ban' OR ban_seconds IS NULL)
);

-- At most one PENDING challenge per (group, user): a re-join while pending reuses it.
CREATE UNIQUE INDEX IF NOT EXISTS uq_member_verifications_pending
    ON member_verifications (group_id, user_id) WHERE status = 'pending';
-- A redelivered join update (same key) in the same group never creates a second challenge.
CREATE UNIQUE INDEX IF NOT EXISTS uq_member_verifications_idem
    ON member_verifications (group_id, idempotency_key);
-- Sweeper: pending challenges whose deadline passed.
CREATE INDEX IF NOT EXISTS idx_member_verifications_due
    ON member_verifications (expires_at) WHERE status = 'pending';
-- Anti-rejoin / history per member.
CREATE INDEX IF NOT EXISTS idx_member_verifications_user
    ON member_verifications (group_id, user_id, created_at);
