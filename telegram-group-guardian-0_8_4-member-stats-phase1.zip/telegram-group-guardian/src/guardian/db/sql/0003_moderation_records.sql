-- 0003_moderation_records (Phase 3, part 3): constraints/columns/indexes for the warnings and sanctions
-- repositories. The tables themselves come from 0002 (schema only there); 0001/0002 are NOT edited.
-- Both tables are empty when this runs (nothing wrote to them before Phase 3 part 3), so the new
-- CHECK constraints cannot fail on legacy rows. NOT executed against a real PostgreSQL in the build
-- sandbox (see TEST_REPORT.md).

-- ---------------------------------------------------------------------------------------------
-- 1) moderation_warnings: per-group idempotency key + sanity constraints.
--    issued_by NULL = automatic (system); revoked_* are always set together (a human revokes).
-- ---------------------------------------------------------------------------------------------
ALTER TABLE moderation_warnings
    ADD COLUMN idempotency_key TEXT,
    ADD CONSTRAINT moderation_warnings_idem_len
        CHECK (idempotency_key IS NULL OR length(idempotency_key) BETWEEN 1 AND 200),
    ADD CONSTRAINT moderation_warnings_expiry_after_create
        CHECK (expires_at IS NULL OR expires_at > created_at),
    ADD CONSTRAINT moderation_warnings_revoked_pair
        CHECK ((revoked_at IS NULL) = (revoked_by IS NULL)),
    ADD CONSTRAINT moderation_warnings_actor_positive
        CHECK ((issued_by IS NULL OR issued_by > 0) AND (revoked_by IS NULL OR revoked_by > 0));

-- A redelivered /warn (same key) in the same group must not add a second warning.
CREATE UNIQUE INDEX IF NOT EXISTS uq_moderation_warnings_idem
    ON moderation_warnings (group_id, idempotency_key) WHERE idempotency_key IS NOT NULL;

-- Active-warning reads: by (group, user), newest last; the 0002 partial index already filters revoked rows.
CREATE INDEX IF NOT EXISTS idx_moderation_warnings_user_time
    ON moderation_warnings (group_id, user_id, created_at) WHERE revoked_at IS NULL;

-- ---------------------------------------------------------------------------------------------
-- 2) moderation_sanctions: which rule fired (automatic sanctions), constraints, escalation index.
--    issued_by NULL = automatic. A kick is instantaneous: it never carries an expiry and is never
--    "active". The global UNIQUE(idempotency_key) from 0002 stays (keys embed the group id).
-- ---------------------------------------------------------------------------------------------
ALTER TABLE moderation_sanctions
    ADD COLUMN violation TEXT,
    ADD CONSTRAINT moderation_sanctions_violation_len
        CHECK (violation IS NULL OR length(violation) BETWEEN 1 AND 40),
    ADD CONSTRAINT moderation_sanctions_idem_len
        CHECK (idempotency_key IS NULL OR length(idempotency_key) BETWEEN 1 AND 200),
    ADD CONSTRAINT moderation_sanctions_expiry_after_create
        CHECK (expires_at IS NULL OR expires_at > created_at),
    ADD CONSTRAINT moderation_sanctions_kick_no_expiry
        CHECK (kind <> 'kick' OR expires_at IS NULL),
    ADD CONSTRAINT moderation_sanctions_lift_consistent
        CHECK (lifted_by IS NULL OR lifted_at IS NOT NULL),
    ADD CONSTRAINT moderation_sanctions_actor_positive
        CHECK ((issued_by IS NULL OR issued_by > 0) AND (lifted_by IS NULL OR lifted_by > 0));

-- Escalation window: count of AUTOMATIC mutes for one user in one group since a cut-off.
CREATE INDEX IF NOT EXISTS idx_moderation_sanctions_auto_mutes
    ON moderation_sanctions (group_id, user_id, created_at)
    WHERE issued_by IS NULL AND kind = 'mute';
