-- 0005_settings_templates (Phase 5, part 5.6): owner-level settings templates and the (future) global defaults.
-- These tables are NOT per-group data: they belong to the primary owner and are reachable only through owner-only
-- services (Permission.OWNER_TEMPLATES). A template never references a group (it outlives the group it was copied
-- from; `source_group_id` is informational). Nothing here is applied to a group in 5.6 (applying = part 5.7).
-- 0001-0004 are NOT edited. NOT executed against a real PostgreSQL in the build sandbox.

CREATE TABLE IF NOT EXISTS settings_templates (
    id              BIGSERIAL PRIMARY KEY,
    name            TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 40),
    name_key        TEXT NOT NULL CHECK (length(name_key) BETWEEN 1 AND 40),
    settings        JSONB NOT NULL CHECK (jsonb_typeof(settings) = 'object'),
    created_by      BIGINT NOT NULL CHECK (created_by > 0),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    source_group_id BIGINT CHECK (source_group_id IS NULL OR source_group_id < 0)
);
-- One template per (case/alef-folded) name: saving the same name again updates it.
CREATE UNIQUE INDEX IF NOT EXISTS uq_settings_templates_name ON settings_templates (name_key);

-- Global default settings for NEW groups (single row). Created now so the schema is complete; nothing reads or writes
-- it before part 5.7 (preview + approval + "new groups only").
CREATE TABLE IF NOT EXISTS global_default_settings (
    singleton   BOOLEAN PRIMARY KEY DEFAULT TRUE CHECK (singleton),
    settings    JSONB NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(settings) = 'object'),
    version     INTEGER NOT NULL DEFAULT 1 CHECK (version >= 1),
    updated_by  BIGINT CHECK (updated_by IS NULL OR updated_by > 0),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
