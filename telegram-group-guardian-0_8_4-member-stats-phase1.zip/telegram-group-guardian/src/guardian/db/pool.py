"""Lazy, failure-tolerant PostgreSQL pool wrapper.

* The pool is created on first use (or at startup) and retried with a cooldown.
* Every failure surfaces as StoreUnavailable so callers can fail closed.
* `last_known_status` feeds /health without touching the database.
"""
from __future__ import annotations

import asyncio
import logging
import time
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator, Awaitable, Callable

from ..errors import StoreUnavailable
from ..health import DB_OK, DB_UNAVAILABLE, DB_UNKNOWN

log = logging.getLogger(__name__)

PoolFactory = Callable[[str, int, int], Awaitable[Any]]


async def asyncpg_pool_factory(dsn: str, min_size: int, max_size: int) -> Any:
    import asyncpg  # imported lazily so unit tests run without the driver

    return await asyncpg.create_pool(dsn=dsn, min_size=min_size, max_size=max_size, command_timeout=15, timeout=15)


_CONNECTIVITY_NAMES = frozenset(
    {
        "PostgresConnectionError",
        "ConnectionDoesNotExistError",
        "ConnectionFailureError",
        "CannotConnectNowError",
        "TooManyConnectionsError",
        "InterfaceError",
    }
)


def is_connectivity_error(exc: BaseException) -> bool:
    """True for network/timeouts/driver connection errors (not for SQL/constraint errors)."""
    return isinstance(exc, (OSError, asyncio.TimeoutError)) or type(exc).__name__ in _CONNECTIVITY_NAMES


class Database:
    def __init__(
        self,
        dsn: str,
        *,
        min_size: int = 1,
        max_size: int = 5,
        pool_factory: PoolFactory = asyncpg_pool_factory,
        retry_cooldown: float = 30.0,
        clock: Callable[[], float] = time.monotonic,
    ):
        self._dsn = dsn
        self._min = min_size
        self._max = max_size
        self._factory = pool_factory
        self._cooldown = retry_cooldown
        self._clock = clock
        self._pool: Any = None
        self._lock = asyncio.Lock()
        self._last_failure: float | None = None
        self._status = DB_UNKNOWN

    @property
    def last_known_status(self) -> str:
        return self._status

    async def ensure_pool(self) -> Any:
        if self._pool is not None:
            return self._pool
        async with self._lock:
            if self._pool is not None:
                return self._pool
            if self._last_failure is not None and self._clock() - self._last_failure < self._cooldown:
                raise StoreUnavailable("database unavailable (recent connection failure)")
            try:
                self._pool = await self._factory(self._dsn, self._min, self._max)
            except Exception as exc:
                self._last_failure = self._clock()
                self._status = DB_UNAVAILABLE
                # Do not include str(exc): drivers may echo the DSN. The log redactor is a second guard.
                log.error("database connection failed (%s)", type(exc).__name__)
                raise StoreUnavailable("database unavailable") from None
            self._status = DB_OK
            self._last_failure = None
            return self._pool

    @asynccontextmanager
    async def acquire(self) -> AsyncIterator[Any]:
        pool = await self.ensure_pool()
        try:
            async with pool.acquire() as conn:
                yield conn
        except StoreUnavailable:
            raise
        except Exception as exc:
            if is_connectivity_error(exc):
                self._status = DB_UNAVAILABLE
                raise StoreUnavailable("database unavailable") from exc
            raise

    async def close(self) -> None:
        pool, self._pool = self._pool, None
        if pool is not None:
            await pool.close()
