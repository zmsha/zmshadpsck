"""Tiny forward-only SQL migration runner (no ORM, minimal dependencies).

* Files: `sql/NNNN_name.sql`, applied in lexical order, each in its own transaction.
* Applied versions + SHA-256 checksums are stored in `schema_migrations`; editing an
  already-applied file raises MigrationError (add a NEW migration instead).
* A PostgreSQL advisory lock serialises concurrent starts (e.g. Render deploy overlap).
"""
from __future__ import annotations

import hashlib
import logging
import re
from pathlib import Path

from ..errors import MigrationError

log = logging.getLogger(__name__)

SQL_DIR = Path(__file__).parent / "sql"
_NAME_RE = re.compile(r"^(\d{4})_[a-z0-9_]+\.sql$")
_LOCK_KEY = 726_104_001  # arbitrary constant namespace for pg_advisory_lock

_CREATE_TABLE = (
    "CREATE TABLE IF NOT EXISTS schema_migrations ("
    "version TEXT PRIMARY KEY, checksum TEXT NOT NULL, applied_at TIMESTAMPTZ NOT NULL DEFAULT now())"
)


def discover(directory: Path = SQL_DIR) -> list[tuple[str, Path]]:
    found: list[tuple[str, Path]] = []
    for path in sorted(directory.glob("*.sql")):
        match = _NAME_RE.match(path.name)
        if not match:
            raise MigrationError(f"invalid migration file name: {path.name}")
        found.append((path.stem, path))
    versions = [v for v, _ in found]
    numbers = [v[:4] for v in versions]
    if len(set(numbers)) != len(numbers):
        raise MigrationError("duplicate migration number")
    return found


def checksum(sql: str) -> str:
    return hashlib.sha256(sql.encode("utf-8")).hexdigest()


async def run_migrations(conn, directory: Path = SQL_DIR) -> list[str]:
    """Apply pending migrations on `conn`; returns the versions applied now."""
    migrations = discover(directory)
    applied_now: list[str] = []
    await conn.execute("SELECT pg_advisory_lock($1)", _LOCK_KEY)
    try:
        await conn.execute(_CREATE_TABLE)
        rows = await conn.fetch("SELECT version, checksum FROM schema_migrations")
        applied = {r["version"]: r["checksum"] for r in rows}
        for version, path in migrations:
            sql = path.read_text(encoding="utf-8")
            digest = checksum(sql)
            if version in applied:
                if applied[version] != digest:
                    raise MigrationError(f"migration {version} was modified after being applied")
                continue
            async with conn.transaction():
                await conn.execute(sql)
                await conn.execute(
                    "INSERT INTO schema_migrations (version, checksum) VALUES ($1, $2)", version, digest
                )
            applied_now.append(version)
            log.info("applied migration %s", version)
    finally:
        await conn.execute("SELECT pg_advisory_unlock($1)", _LOCK_KEY)
    return applied_now
