"""CLI helpers:  python -m guardian check-config | migrate | serve"""
from __future__ import annotations

import argparse
import asyncio
import sys

from .errors import ConfigError


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="guardian")
    parser.add_argument("command", choices=["check-config", "migrate", "serve"])
    args = parser.parse_args(argv)

    from .config import load_settings

    try:
        settings = load_settings()
    except ConfigError as exc:
        print(f"CONFIG ERROR: {exc}", file=sys.stderr)  # names + problem kinds only, never values
        return 2

    if args.command == "check-config":
        print(f"OK: {settings!r}")
        return 0

    if args.command == "migrate":
        from .db.migrations import run_migrations
        from .db.pool import Database
        from .logging_setup import configure_logging

        configure_logging(settings.log_level, settings.secret_values())

        async def _run() -> None:
            db = Database(settings.database_url, min_size=1, max_size=1)
            try:
                async with db.acquire() as conn:
                    applied = await run_migrations(conn)
                print(f"applied: {applied or 'nothing (already up to date)'}")
            finally:
                await db.close()

        asyncio.run(_run())
        return 0

    import uvicorn  # serve (local use)

    uvicorn.run("guardian.app:create_app", factory=True, host="0.0.0.0", port=settings.port)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
