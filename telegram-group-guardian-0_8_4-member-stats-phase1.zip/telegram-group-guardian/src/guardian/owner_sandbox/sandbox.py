"""One sandbox session: the REAL `ProtectionEngine` (so the verdicts are the real rules) wired to fakes only."""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Callable

from ..audit import InMemorySecurityAudit
from ..groups.memory_store import InMemorySettingsStore
from ..idempotency import InMemoryIdempotency
from ..members.newcomers import NewcomerTracker
from ..moderation.memory_store import InMemorySanctionStore
from ..owner_templates.templates import DiffEntry, diff_settings, validate_template_settings
from ..protection.engine import ActionResult, MessageView, Outcome, OutcomeKind, ProtectionEngine
from ..protection.offenses import SanctionOffenseLedger
from ..protection_gate import ProtectionContext
from ..telegram_rights import ChatMemberInfo
from ..time_utils import utcnow

SANDBOX_GROUP_ID = -999_000_000_001      # exists only inside the session's private stores
USER_BASE = 7_000_000_000                # simulated users u1..u9 -> USER_BASE + n (never a real account the bot knows)
MAX_USERS = 9
MAX_LOG = 50
MAX_TEXT = 1000
MAX_WAIT = 7 * 24 * 3600
SAY_STEP = 1                             # every simulated message happens this many virtual seconds after the previous event


class FakeActions:
    """Records what the real bot WOULD have done. There is no Telegram client here: nothing can be sent."""

    def __init__(self) -> None:
        self.calls: list[tuple] = []
        self.muted_until: dict[int, datetime] = {}   # a muted member cannot post, in the simulation as in Telegram

    async def delete_message(self, chat_id: int, message_id: int) -> ActionResult:
        self.calls.append(("delete", message_id))
        return ActionResult(True)

    async def mute_member(self, chat_id: int, user_id: int, until: datetime) -> ActionResult:
        self.calls.append(("mute", user_id, until))
        self.muted_until[user_id] = until
        return ActionResult(True)


class FakeChatInfo:
    """The simulated bot is an administrator with every right the engine asks for."""

    async def get_bot_member(self, chat_id: int) -> ChatMemberInfo:
        return ChatMemberInfo("administrator", True, True, True)

    async def get_member(self, chat_id: int, user_id: int, *, fresh: bool = False) -> ChatMemberInfo:
        return ChatMemberInfo("member")

    async def list_admins(self, chat_id: int) -> list:
        return []


class FakeNotifier:
    def __init__(self) -> None:
        self.sent: list[str] = []

    async def notify_group(self, group_id: int, text: str) -> None:
        self.sent.append(text)

    async def notify_owner(self, text: str) -> None:
        self.sent.append(text)


class VirtualClock:
    def __init__(self, start: datetime) -> None:
        self.now = start

    def __call__(self) -> datetime:
        return self.now

    def advance(self, seconds: float) -> None:
        self.now += timedelta(seconds=seconds)


@dataclass(frozen=True, slots=True)
class SandboxEntry:
    n: int
    at: datetime                   # virtual time
    kind: str                      # message | join | wait | set
    user: int | None               # 1..9
    text: str | None               # clipped message text / "key=value" / seconds
    verdict: str                   # ok | acted | muted | unsafe | applied | waited | joined
    violation: str | None = None
    deleted: bool = False
    muted_seconds: int | None = None


def user_id(n: int) -> int:
    return USER_BASE + n


def valid_user(n: object) -> bool:
    return isinstance(n, int) and not isinstance(n, bool) and 1 <= n <= MAX_USERS


class SandboxSession:
    def __init__(self, owner_id: int, source: str, settings: dict, *, clock_start: datetime | None = None,
                 idle_clock: Callable[[], datetime] = utcnow):
        self.owner_id, self.source, self.origin = owner_id, source, dict(settings)
        self.settings = dict(settings)
        self.source_name: str | None = None   # display name of the source (template name / group id), set by the service
        self.clock = VirtualClock(clock_start or idle_clock())
        self.started_at = idle_clock()
        self.actions, self.notifier = FakeActions(), FakeNotifier()
        self._store = InMemorySettingsStore()
        self._audit = InMemorySecurityAudit()           # the engine's own events stay in the session
        self._newcomers = NewcomerTracker()
        self.engine = ProtectionEngine(
            self._store, self.actions, FakeChatInfo(), InMemoryIdempotency(), self._audit, self.notifier,
            clock=self.clock, ledger=SanctionOffenseLedger(InMemorySanctionStore()), newcomers=self._newcomers)
        self.log: deque[SandboxEntry] = deque(maxlen=MAX_LOG)
        self._n = 0
        self._msg_id = 0
        self.violations = 0

    async def prepare(self) -> "SandboxSession":
        await self._store.merge(SANDBOX_GROUP_ID, dict(self.settings), self.owner_id, self.clock())
        return self

    def _entry(self, **kw) -> SandboxEntry:
        self._n += 1
        entry = SandboxEntry(self._n, self.clock(), **kw)
        self.log.append(entry)
        return entry

    async def say(self, n: int, text: str, *, media: bool = False, edit: bool = False) -> SandboxEntry:
        if not valid_user(n):
            raise ValueError("user must be 1..9")
        text = text[:MAX_TEXT]
        self.clock.advance(SAY_STEP)
        self._msg_id += 1
        uid = user_id(n)
        until = self.actions.muted_until.get(uid)
        if until is not None and self.clock() < until:        # a muted member cannot post: the message never reaches the rules
            return self._entry(kind="message", user=n, text=text[:60], verdict="muted", muted_seconds=int((until - self.clock()).total_seconds()))
        ctx = ProtectionContext(SANDBOX_GROUP_ID, "supergroup", True, "none", uid, False)
        msg = MessageView(SANDBOX_GROUP_ID, uid, self._msg_id, text, is_edit=edit, has_media=media)
        outcome: Outcome = await self.engine.handle(ctx, msg, self.clock())
        clipped = text[:60]
        if outcome.kind is OutcomeKind.ACTED:
            self.violations += 1
            return self._entry(kind="message", user=n, text=clipped, verdict="acted", violation=outcome.violation,
                               deleted=outcome.deleted, muted_seconds=outcome.muted_seconds)
        if outcome.kind is OutcomeKind.NONE:
            return self._entry(kind="message", user=n, text=clipped, verdict="ok")
        return self._entry(kind="message", user=n, text=clipped, verdict="unsafe", violation=outcome.violation)

    def join(self, n: int) -> SandboxEntry:
        if not valid_user(n):
            raise ValueError("user must be 1..9")
        self.clock.advance(SAY_STEP)
        self._newcomers.record(SANDBOX_GROUP_ID, user_id(n), self.clock())
        return self._entry(kind="join", user=n, text=None, verdict="joined")

    def wait(self, seconds: int) -> SandboxEntry:
        if not isinstance(seconds, int) or isinstance(seconds, bool) or not 1 <= seconds <= MAX_WAIT:
            raise ValueError("seconds out of range")
        self.clock.advance(seconds)
        return self._entry(kind="wait", user=None, text=str(seconds), verdict="waited")

    async def set(self, key: str, value: Any) -> SandboxEntry:
        patch = validate_template_settings({key: value})        # same whitelist and value rules as templates (no dry_run)
        self.settings.update(patch)
        await self._store.merge(SANDBOX_GROUP_ID, patch, self.owner_id, self.clock())
        return self._entry(kind="set", user=None, text=f"{key}={value!r}"[:80], verdict="applied")

    def diff_against(self, effective: dict) -> tuple[tuple[DiffEntry, ...], int]:
        """Sandbox settings vs a real group's effective settings: (entries: group ➜ sandbox, number equal). Read only."""
        return diff_settings(self.settings, effective)
