"""Owner-only sandbox service (phase 5.8): at most ONE session, in memory, idle-expiring.

Permission: `Permission.OWNER_TEMPLATES` (exactly the primary owner). Every operation re-checks it. A session is a copy of
settings (a template, a group's EFFECTIVE settings, or the built-in defaults): changing the sandbox never changes the source.
The way out of the sandbox is explicit and goes through the existing, confirmed path: `save` stores the sandbox settings as
a template, then `/template apply NAME GROUP` previews the differences and asks for a confirmation code (part 5.7).
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any, Callable

from ..audit import SANDBOX_ENDED, SANDBOX_STARTED, SecurityAudit, make_event, record_safely
from ..errors import InvalidInput
from ..owner_templates.templates import SettingsTemplate, TemplateService, effective_settings, normalize_name
from ..time_utils import utcnow
from .sandbox import SandboxEntry, SandboxSession

log = logging.getLogger(__name__)
IDLE_SECONDS = 2 * 3600


class NoSession(Exception):
    """There is no (or no longer a) sandbox session."""


class SandboxService:
    def __init__(self, templates: TemplateService, audit: SecurityAudit | None = None, *,
                 clock: Callable[[], datetime] = utcnow, idle_seconds: int = IDLE_SECONDS):
        self._templates, self._audit, self._clock, self._idle = templates, audit, clock, idle_seconds
        self._session: SandboxSession | None = None
        self._touched: datetime | None = None

    async def _owner(self, actor_id) -> None:
        await self._templates.require_owner(actor_id)

    def _live(self, actor_id) -> SandboxSession:
        sess = self._session
        if sess is None or sess.owner_id != actor_id:
            raise NoSession()
        now = self._clock()
        if self._touched is not None and (now - self._touched).total_seconds() > self._idle:
            self._session = None
            raise NoSession()
        self._touched = now
        return sess

    async def start(self, actor_id, source) -> SandboxSession:
        """`source`: a template name, a registered group id (negative int) or None/"default" = the built-in values."""
        await self._owner(actor_id)
        if source is None or source == "default":
            label, shown, settings = "default", None, effective_settings({})
        elif isinstance(source, int) and not isinstance(source, bool):
            label, shown, settings = f"group:{source}", str(source), await self._templates.group_effective(actor_id, source)
        else:
            template = await self._templates.find(actor_id, source)
            if template is None:
                raise InvalidInput("unknown template")
            label, shown, settings = f"template:{template.id}", template.name, dict(effective_settings(template.settings))
        if self._session is not None:       # only AFTER the new source resolved: a failed start keeps the running session
            await self._finish(actor_id)
        now = self._clock()
        self._session = await SandboxSession(actor_id, label, settings, clock_start=now, idle_clock=self._clock).prepare()
        self._session.source_name = shown
        self._touched = now
        await record_safely(self._audit, make_event(SANDBOX_STARTED, actor=actor_id, detail=f"source={label}", now=now))
        return self._session

    async def status(self, actor_id) -> SandboxSession:
        await self._owner(actor_id)
        return self._live(actor_id)

    async def say(self, actor_id, n, text, **kw) -> SandboxEntry:
        await self._owner(actor_id)
        return await self._live(actor_id).say(n, text, **kw)

    async def join(self, actor_id, n) -> SandboxEntry:
        await self._owner(actor_id)
        return self._live(actor_id).join(n)

    async def wait(self, actor_id, seconds) -> SandboxEntry:
        await self._owner(actor_id)
        return self._live(actor_id).wait(seconds)

    async def set(self, actor_id, key, value) -> SandboxEntry:
        await self._owner(actor_id)
        return await self._live(actor_id).set(key, value)

    async def log(self, actor_id, limit: int = 15) -> list[SandboxEntry]:
        await self._owner(actor_id)
        return list(self._live(actor_id).log)[-limit:]

    async def diff(self, actor_id, group_id):
        """Sandbox settings vs a registered group (read only). -> (entries, same)."""
        await self._owner(actor_id)
        sess = self._live(actor_id)
        return sess.diff_against(await self._templates.group_effective(actor_id, group_id))

    async def save(self, actor_id, name) -> tuple[SettingsTemplate, bool]:
        """The only way a sandbox result leaves the sandbox: a template (never a direct write to a group)."""
        await self._owner(actor_id)
        sess = self._live(actor_id)
        normalize_name(name)
        return await self._templates.save_from_settings(actor_id, name, dict(sess.settings))

    async def end(self, actor_id) -> tuple[int, int]:
        await self._owner(actor_id)
        self._live(actor_id)
        return await self._finish(actor_id)

    async def _finish(self, actor_id) -> tuple[int, int]:
        sess, self._session, self._touched = self._session, None, None
        events, violations = (sess._n, sess.violations) if sess is not None else (0, 0)
        await record_safely(self._audit, make_event(SANDBOX_ENDED, actor=actor_id, detail=f"events={events} violations={violations}",
                                                    now=self._clock()))
        return events, violations
