"""Sandbox for the owner (phase 5.8): try links, floods, escalation, newcomer limits and settings changes WITHOUT any call to
Telegram and without touching any production data. Everything it reports is labelled «🧪 وهمي».

Isolation by construction: a session owns private in-memory stores, a private audit, a recording fake action executor and a
virtual clock; it receives no Bot, no production store, no license/settings/sanction/idempotency object. The ONLY things the
service gets from the outside are the owner's `TemplateService` (to read a template / a group's effective settings, and to
save the result as a template) and the production audit (to record that a session started/ended, counts only).
"""
