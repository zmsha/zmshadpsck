"""ASGI application: /health, secret-protected Telegram webhook, startup/shutdown wiring.

Run (Render):  uvicorn --app-dir src guardian.app:create_app --factory --host 0.0.0.0 --port $PORT
"""
from __future__ import annotations

import os

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from .audit import PostgresSecurityAudit, register_secrets
from .audit_retention import AuditRetentionService
from .reports.postgres_store import PostgresReportStore
from .reports.service import ReportService
from .member_stats import MemberStatsRecorder
from .member_stats.postgres_store import PostgresMemberStatsStore
from .member_stats.service import MemberStatsCommandService
from .member_stats.tracking import TrackingContentLedger, TrackingSanctionStore, TrackingWarningStore
from .stats import CounterRecorder, StatsService
from .stats.owner_command import OwnerStatsService
from .stats.periodic import ReportScheduleService
from .stats.periodic_delivery import PeriodicDelivery
from .stats.postgres_store import PostgresCounterStore
from .stats.schedule_postgres_store import PostgresScheduleStore
from .audit_service import AuditQueryService
from .auth import Authority
from .bot.chat_info import AiogramChatInfo
from .bot.factory import create_bot, create_dispatcher
from .bot.export_transport import AiogramExportTransport
from .bot.restore_transport import AiogramFileDownloader
from .bot.hub_transport import AiogramHubTransport
from .backup.collector import BackupCollector
from .backup.command import BackupCommandService
from .backup.delivery import BackupDelivery
from .backup.postgres_reader import PostgresBackupReader
from .backup.postgres_state import PostgresRestoreStateReader
from .backup.postgres_restore import PostgresRestoreWriter
from .backup.restore import RestoreExecutor
from .backup.restore_command import RestoreCommandService
from .backup.restore_service import RestorePreviewService
from .backup.service import BackupService
from .export.delivery import ExportDelivery
from .bot.notifier import TelegramNotifier
from .config import WEBHOOK_PATH, Settings, load_settings
from .db.migrations import run_migrations
from .db.pool import Database
from .groups.postgres_store import PostgresDelegationStore, PostgresSettingsStore, PostgresTrustStore
from .groups.service import DelegationService, GroupSettingsService, TrustService
from .members.postgres_store import PostgresBotTrustStore, PostgresChallengeStore
from .members.newcomers import NewcomerService, NewcomerTracker
from .members.verification import VerificationService
from .members.service import BotTrustService
from .members.welcome import WelcomeService
from .health import build_health
from .idempotency import PostgresIdempotency, PurgingClaims, update_key
from .licensing.admin import LicenseAdminService
from .licensing.postgres_store import PostgresLicenseStore
from .licensing.service import LicenseService
from .logging_setup import configure_logging
from .moderation.postgres_store import PostgresSanctionStore, PostgresWarningStore
from .moderation.service import SanctionService, WarningService
from .bot.actions import AiogramModerationActions
from .content_filter import gemini as _gemini
from .content_filter.classifier import ContentClassifier
from .content_filter.default_words import DefaultWordsService
from .content_filter.postgres_store import (PostgresContentLedger, PostgresDefaultWordStore, PostgresKeyStateStore,
                                            PostgresReviewStore)
from .content_filter.service import ContentGuard
from .bot.commands_menu import register_commands
from .moderation.executor import ModerationCommandService
from .moderation.provider import LazyModerationCommands
from .licensing.commands import LicenseCommandService
from .owner_hub.mirror import HubMirroringNotifier
from .owner_hub.reports import HubReporter
from .owner_hub.sender import DisabledHub, OwnerHubSender
from .owner_panel.actions import OwnerActions
from .owner_panel.sandbox_commands import SandboxCommandService
from .owner_panel.api_check import ApiChecker
from .owner_panel.api_check_commands import ApiCheckCommandService
from .owner_panel.default_words_commands import DefaultWordsCommandService
from .bot.telegram_probe import AiogramTelegramProbe
from .owner_panel.template_commands import TemplateCommandService
from .owner_sandbox.service import SandboxService
from .owner_templates.apply import TemplateApplyService
from .owner_templates.defaults import DefaultsSeeder, GlobalDefaultsService, PostgresDefaultsStore
from .owner_templates.overview import GroupOverviewService
from .owner_templates.pending import PendingActions
from .owner_templates.store_pg import PostgresTemplateStore
from .owner_templates.templates import TemplateService
from .owner_panel.service import OwnerPanelService
from .panel.service import PanelService
from .moderation.usernames import VisibleUsers
from .permissions import PermissionService
from .protection.engine import ProtectionEngine
from .protection.offenses import SanctionOffenseLedger
from .services import Services
from . import __version__
from .time_utils import utcnow
from .webhook import SECRET_HEADER, UpdateDeduplicator, verify_secret_token

log = logging.getLogger(__name__)


def create_app(settings: Settings | None = None, *, bot=None, dispatcher=None, database: Database | None = None) -> FastAPI:
    settings = settings or load_settings()
    configure_logging(settings.log_level, settings.secret_values())
    register_secrets(settings.secret_values())  # audit text must never contain them either

    database = database or Database(settings.database_url, min_size=settings.db_pool_min, max_size=settings.db_pool_max)
    bot = bot or create_bot(settings.bot_token)
    authority = Authority(settings.owner_telegram_id, settings.backup_owner_telegram_id)
    license_store = PostgresLicenseStore(database)
    delegation_store = PostgresDelegationStore(database)
    trust_store = PostgresTrustStore(database)
    bot_trust_store = PostgresBotTrustStore(database)
    security_audit = PostgresSecurityAudit(database)
    chat_info = AiogramChatInfo(bot)
    settings_store = PostgresSettingsStore(database)
    claims = PurgingClaims(PostgresIdempotency(database))
    warning_store = PostgresWarningStore(database)
    sanction_store = PostgresSanctionStore(database)
    report_service = ReportService(PostgresReportStore(database), security_audit)
    counter_store = PostgresCounterStore(database)
    counters = CounterRecorder(counter_store, settings.display_timezone)
    # Permanent per-member statistics (migration 0013). Warnings / mutes / bans are counted by the stores that REALLY record them
    # (a tick only when a NEW row was created); messages and violations are counted once per message through the idempotency claims.
    member_stats_store = PostgresMemberStatsStore(database)
    member_stats = MemberStatsRecorder(member_stats_store, claims, settings.display_timezone)
    tracked_warning_store = TrackingWarningStore(warning_store, member_stats)
    tracked_sanction_store = TrackingSanctionStore(sanction_store, member_stats)
    stats_service = StatsService(
        warnings=warning_store, sanctions=sanction_store, reports=PostgresReportStore(database), audit=security_audit,
        counters=counter_store, display_timezone=settings.display_timezone)

    async def _load_raw_settings(chat_id: int) -> dict:
        """The group's raw settings JSON ({} when none); a read failure RAISES (the panel's reports screen then refuses)."""
        row = await settings_store.get(chat_id)
        return dict(row.settings) if row is not None and isinstance(row.settings, dict) else {}
    # Owner hub (OWNER_GROUP_ID): redacted, fixed destination, never raises. Without the setting it is simply disabled.
    owner_hub = (OwnerHubSender(AiogramHubTransport(bot), settings.owner_group_id, secrets=settings.secret_values())
                 if settings.owner_group_id is not None else DisabledHub())
    hub_reporter = HubReporter(owner_hub, license_store, display_timezone=settings.display_timezone,
                               language=settings.default_language, version=__version__, environment=settings.environment)
    notifier = HubMirroringNotifier(TelegramNotifier(bot, settings.owner_telegram_id), owner_hub)
    permissions = PermissionService(authority, delegation_store, chat_info, security_audit, trust_store)
    member_actions = AiogramModerationActions(bot)  # ONE adapter serves the automatic engine and the commands
    # Part 9.2: content filter. Gemini keys come ONLY from the environment (GEMINI_API_KEY_1..5, optional GEMINI_MODEL); without
    # any key the local filter still works and anything suspicious goes to the admins for review (never assumed safe).
    gemini_keys = list(settings.gemini_api_keys)  # from GEMINI_API_KEY_1..5 (config.py); never logged, audited or stored
    register_secrets(tuple(gemini_keys))  # a key must never appear in audit text either
    gemini_client = (_gemini.GeminiClient(_gemini.KeyPool(gemini_keys, PostgresKeyStateStore(database)),
                                          model=settings.gemini_model or _gemini.DEFAULT_MODEL)
                     if gemini_keys else None)
    content_classifier = ContentClassifier()  # ONE classifier: the guard uses it and the owner's default-word commands change it
    default_words = DefaultWordsService(PostgresDefaultWordStore(database), content_classifier)
    content_guard = ContentGuard(
        settings_store, member_actions, chat_info, claims, security_audit, TrackingContentLedger(PostgresContentLedger(database), member_stats),
        PostgresReviewStore(database), ai=gemini_client, photos=member_actions, permissions=permissions, notifier=notifier,
        owner_ids=tuple(i for i in (settings.owner_telegram_id, settings.backup_owner_telegram_id) if i),
        counters=counters, language=settings.default_language, classifier=content_classifier, member_stats=member_stats)
    usernames = VisibleUsers()
    newcomer_tracker = NewcomerTracker()
    warnings = WarningService(tracked_warning_store, license_store, permissions, security_audit)
    sanctions = SanctionService(tracked_sanction_store, license_store, permissions, security_audit)
    group_settings = GroupSettingsService(settings_store, license_store, permissions, security_audit)
    trust_service = TrustService(trust_store, license_store, permissions, security_audit)
    bot_trust_service = BotTrustService(bot_trust_store, license_store, permissions, security_audit)
    defaults_store = PostgresDefaultsStore(database)
    # New groups (and only new ones) receive the owner-approved global defaults when they are first registered (5.7).
    license_service_obj = LicenseService(license_store, on_new_group=DefaultsSeeder(defaults_store, settings_store, settings.owner_telegram_id).seed)
    audit_query = AuditQueryService(license_store, security_audit, permissions)
    # Private delivery path of every export (6.7a); `/export settings|license` (6.7b) is its only caller so far.
    export_delivery = ExportDelivery(AiogramExportTransport(bot), claims=claims, audit=security_audit,
                                     secrets=settings.secret_values())
    report_schedule_service = ReportScheduleService(PostgresScheduleStore(database), security_audit,
                                                    display_timezone=settings.display_timezone)
    moderation_commands = LazyModerationCommands(
        bot,
        lambda bot_id: ModerationCommandService(
            permissions=permissions, warnings=warnings, sanctions=sanctions, settings_store=settings_store,
            actions=member_actions, chat_info=chat_info, claims=claims, audit=security_audit, bot_id=bot_id,
            usernames=usernames, language=settings.default_language, group_settings=group_settings,
            trust=trust_service, bot_trust=bot_trust_service, trust_store=trust_store, bot_trust_store=bot_trust_store,
            reports=report_service, display_timezone=settings.display_timezone, counters=counters,
            stats=stats_service, report_schedule=report_schedule_service, export_delivery=export_delivery, licenses=license_store, audit_query=audit_query),
        language=settings.default_language)
    license_admin_obj = LicenseAdminService(license_store, permissions, security_audit)
    template_service = TemplateService(PostgresTemplateStore(database), license_store, settings_store, permissions, security_audit)
    group_overview = GroupOverviewService(license_store, settings_store, audit_query, permissions)
    pending_actions = PendingActions()
    sandbox_service = SandboxService(template_service, security_audit)
    template_applier = TemplateApplyService(template_service, license_store, group_settings, claims, security_audit)
    global_defaults = GlobalDefaultsService(defaults_store, template_service, permissions, pending_actions, security_audit)
    # Backup (6.8b): own delivery path (private chat of the owner only, 10 MB, verify-only screening); the owner group is forbidden.
    backup_service = BackupService(
        collector=BackupCollector(PostgresBackupReader(database), app_version=__version__, secrets=settings.secret_values()),
        delivery=BackupDelivery(AiogramExportTransport(bot), claims=claims, audit=security_audit, secrets=settings.secret_values(),
                                forbidden_chat_ids=(settings.owner_group_id,)),
        pending=pending_actions, permissions=permissions, claims=claims, audit=security_audit)
    # Restore (6.9a preview + 6.9b execution): download the owner's file, validate it, preview; `confirm` (single-use codes bound to the
    # file's fingerprint) applies it in ONE PostgreSQL transaction (`PostgresRestoreWriter` is the only writer of the backup package).
    restore_service = RestorePreviewService(
        downloader=AiogramFileDownloader(bot), state_reader=PostgresRestoreStateReader(database), permissions=permissions,
        claims=claims, audit=security_audit, secrets=settings.secret_values(), pending=pending_actions,
        executor=RestoreExecutor(PostgresRestoreWriter(database)))
    owner_panel_service = OwnerPanelService(
        permissions=permissions, licenses=license_store, audit=security_audit, secret=settings.webhook_secret,
        display_timezone=settings.display_timezone, language=settings.default_language,
        actions=OwnerActions(license_admin=license_admin_obj, licenses=license_store, claims=claims), hub=hub_reporter,
        templates=template_service, overview=group_overview, applier=template_applier)
    periodic_delivery = PeriodicDelivery(
        schedule=report_schedule_service, stats=stats_service, claims=claims, load_raw=_load_raw_settings,
        audit=security_audit, language=settings.default_language)
    services = Services(
        settings=settings,
        authority=authority,
        license_service=license_service_obj,
        database=database,
        notifier=notifier,
        started_at=utcnow(),
        permissions=permissions,
        license_admin=license_admin_obj,
        delegations=DelegationService(delegation_store, license_store, permissions, security_audit),
        trust=trust_service,
        bot_trust=bot_trust_service,
        welcome=WelcomeService(settings_store, member_actions, claims, license_service_obj, language=settings.default_language),
        verification=VerificationService(
            settings_store, member_actions, PostgresChallengeStore(database), license_service_obj, permissions,
            claims=claims, language=settings.default_language),
        newcomers=NewcomerService(settings_store, permissions, newcomer_tracker),
        group_settings=group_settings,
        security_audit=security_audit,
        claims=claims,
        chat_info=chat_info,
        audit_query=audit_query,
        protection_engine=ProtectionEngine(
            settings_store, member_actions, chat_info, claims, security_audit, notifier,
            language=settings.default_language, ledger=SanctionOffenseLedger(tracked_sanction_store), bot_trust=bot_trust_store,
            newcomers=newcomer_tracker, counters=counters, member_stats=member_stats,
        ),
        warnings=warnings,
        sanctions=sanctions,
        usernames=usernames,
        moderation_commands=moderation_commands,
        panel=PanelService(
            permissions=permissions, licenses=license_service_obj, commands=moderation_commands,
            audit=security_audit, secret=settings.webhook_secret, language=settings.default_language,
            reports=report_service, claims=claims, load_raw=_load_raw_settings,
            display_timezone=settings.display_timezone),
        license_commands=LicenseCommandService(
            license_admin=license_admin_obj, license_service=license_service_obj, permissions=permissions, claims=claims,
            display_timezone=settings.display_timezone, language=settings.default_language, hub=hub_reporter),
        owner_panel=owner_panel_service,
        owner_sandbox=SandboxCommandService(sandbox_service, template_service, license_store,
                                            display_timezone=settings.display_timezone, language=settings.default_language),
        owner_templates=TemplateCommandService(template_service, license_store, display_timezone=settings.display_timezone,
                                               language=settings.default_language, applier=template_applier,
                                               defaults=global_defaults, pending=pending_actions),
        owner_hub=owner_hub,
        hub_reporter=hub_reporter,
        audit_retention=AuditRetentionService(security_audit, settings.audit_retention_days),
        reports=report_service,
        stats=stats_service,
        counters=counters,
        report_schedule=report_schedule_service,
        periodic_delivery=periodic_delivery,
        export_delivery=export_delivery,
        owner_backup=BackupCommandService(backup_service, language=settings.default_language),
        owner_restore=RestoreCommandService(restore_service, language=settings.default_language),
        content_guard=content_guard,
        owner_api_check=ApiCheckCommandService(
            ApiChecker(settings=settings, database=database, telegram=AiogramTelegramProbe(bot), gemini=gemini_client,
                       max_keys=_gemini.MAX_KEYS),
            permissions, display_timezone=settings.display_timezone, language=settings.default_language),
        owner_default_words=DefaultWordsCommandService(default_words, permissions, security_audit,
                                                       language=settings.default_language),
        owner_stats=OwnerStatsService(stats=stats_service, owner_panel=owner_panel_service, permissions=permissions,
                                      language=settings.default_language),
        member_stats=member_stats,
        owner_member_stats=MemberStatsCommandService(
            store=member_stats_store, permissions=permissions, usernames=usernames, language=settings.default_language,
            display_timezone=settings.display_timezone),
    )
    dispatcher = dispatcher or create_dispatcher(services)
    dedup = UpdateDeduplicator()

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        await _startup(settings, database, bot, dispatcher, hub_reporter, default_words)
        try:
            yield
        finally:
            await services.welcome.aclose()  # cancel pending timed welcome deletes
            await periodic_delivery.aclose()  # cancel periodic-report runs in flight (what was not marked done is owed again)
            await services.verification.aclose()  # cancel pending verification timers (the sweeper resolves them later)
            await hub_reporter.drain()  # let a scheduled owner-hub notice finish (bounded by the hub's own timeout)
            await _shutdown(bot, database)

    app = FastAPI(title="telegram-group-guardian", docs_url=None, redoc_url=None, openapi_url=None, lifespan=lifespan)
    app.state.services = services

    @app.api_route("/health", methods=["GET", "HEAD"])
    async def health() -> dict[str, str]:
        return build_health(database.last_known_status)

    @app.post(WEBHOOK_PATH)
    async def telegram_webhook(request: Request) -> JSONResponse:
        if not verify_secret_token(request.headers.get(SECRET_HEADER), settings.webhook_secret):
            return JSONResponse({"ok": False}, status_code=403)
        try:
            payload = await request.json()
        except Exception:
            return JSONResponse({"ok": False}, status_code=400)
        update_id = payload.get("update_id") if isinstance(payload, dict) else None
        if not isinstance(update_id, int) or isinstance(update_id, bool):
            return JSONResponse({"ok": False}, status_code=400)
        if dedup.seen_before(update_id):
            return JSONResponse({"ok": True})  # retry of an update we already handled (this process)
        try:
            if not await services.claims.claim(update_key(update_id)):
                return JSONResponse({"ok": True})  # durable dedup: handled before a restart/sleep
        except Exception:
            # DB down: the in-memory guard above still applies and every handler fails closed
            # on the license check, so continuing cannot enable protection.
            log.warning("durable update dedup unavailable update_id=%s", update_id)
        try:
            from aiogram.types import Update

            update = Update.model_validate(payload, context={"bot": bot})
            await dispatcher.feed_update(bot, update)
        except Exception:
            # Return 200 anyway: a non-2xx makes Telegram redeliver, risking duplicate actions.
            log.error("update processing failed update_id=%s", update_id, exc_info=True)
        return JSONResponse({"ok": True})

    @app.exception_handler(Exception)
    async def unhandled(_: Request, exc: Exception) -> JSONResponse:
        log.error("unhandled HTTP error", exc_info=exc)
        return JSONResponse({"error": "internal"}, status_code=500)

    return app


async def _startup(settings: Settings, database: Database, bot, dispatcher, hub_reporter=None, default_words=None) -> None:
    if settings.run_migrations_on_startup:
        try:
            async with database.acquire() as conn:
                applied = await run_migrations(conn)
            log.info("migrations up to date (applied now: %d)", len(applied))
        except Exception:
            # Stay up (degraded): license checks fail closed while the DB/schema is unusable.
            log.error("startup migrations failed", exc_info=True)
    else:
        try:
            await database.ensure_pool()
        except Exception:
            log.error("database not reachable at startup")

    if default_words is not None:
        await default_words.refresh()  # the owner's default-word changes (part 9.5); a failure keeps the bundled list

    if settings.webhook_register_on_startup and settings.webhook_url:
        try:
            await bot.set_webhook(
                url=settings.webhook_url,
                secret_token=settings.webhook_secret,
                allowed_updates=dispatcher.resolve_used_update_types(),
                drop_pending_updates=False,
            )
            log.info("webhook registered")
        except Exception:
            log.error("webhook registration failed", exc_info=True)
        try:
            log.info("command menus registered: %d", await register_commands(bot))
        except Exception:
            log.error("command menu registration failed", exc_info=True)
    if hub_reporter is not None:
        hub_reporter.post_startup(database.last_known_status)  # scheduled: a broken hub never delays readiness


async def _shutdown(bot, database: Database) -> None:
    try:
        await bot.session.close()
    finally:
        await database.close()
