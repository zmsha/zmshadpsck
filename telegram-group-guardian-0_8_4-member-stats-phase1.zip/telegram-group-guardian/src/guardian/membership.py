"""Bot added/removed handling as framework-independent logic (adapters live in bot/routers)."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Protocol

from .audit import REGISTRATION_FAILED, RESULT_FAILED, make_event, record_safely
from .i18n import t
from .licensing.models import LicenseStatus
from .licensing.service import LicenseService

log = logging.getLogger(__name__)

_PRESENT = frozenset({"member", "administrator"})


class Notifier(Protocol):
    async def notify_group(self, group_id: int, text: str) -> None: ...

    async def notify_owner(self, text: str) -> None: ...


def was_bot_added(old_status: str | None, new_status: str) -> bool:
    """True when the bot went from absent (left/kicked/unknown) to present in the chat."""
    return new_status in _PRESENT and (old_status or "") not in _PRESENT


@dataclass(frozen=True, slots=True)
class RegistrationOutcome:
    created: bool
    status: LicenseStatus | None
    store_error: bool = False


async def handle_bot_added(
    service: LicenseService,
    notifier: Notifier,
    *,
    group_id: int,
    title: str | None,
    language: str = "ar",
    audit: Any = None,
) -> RegistrationOutcome:
    """Register the group as PENDING (never reactivates). Notify only on first registration.

    Notification failures never raise: registration must not depend on Telegram delivery.
    """
    try:
        license_, created = await service.on_bot_added(group_id, title)
    except Exception:
        log.error("could not register group", extra={"group_id": group_id}, exc_info=True)
        await record_safely(audit, make_event(REGISTRATION_FAILED, group_id=group_id, target=group_id, result=RESULT_FAILED,
                                              detail="store_error"))
        await _safe(notifier.notify_owner(t("owner_register_failed", language, group_id=str(group_id))))
        return RegistrationOutcome(created=False, status=None, store_error=True)

    if created:
        shown = title or t("title_unknown", language)
        await _safe(notifier.notify_group(group_id, t("group_pending_notice", language)))
        await _safe(notifier.notify_owner(t("owner_new_group", language, title=shown, group_id=str(group_id))))
    return RegistrationOutcome(created=created, status=license_.status)


async def _safe(awaitable) -> None:
    try:
        await awaitable
    except Exception:
        log.warning("notification failed", exc_info=True)
