"""Applying a settings template to groups (phase 5.7). The ONLY owner-templates code that writes a group's settings.

Flow: `preview` (read only: per group, the exact keys that would change + a digest of what the owner saw) -> explicit
confirmation by the owner (panel button or `/template confirm CODE`) -> `execute`, per group and independent of the others:
claim (at most once per confirmation) -> re-read template and group -> the digest must still match (else `stale`, nothing
written) -> write ONLY the keys that differ through `GroupSettingsService.update` (owner check, validation, `settings_changed`
audit) -> a `template_applied` audit event (template id + key names, never values).
"""
from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import dataclass
from typing import Any

from ..audit import TEMPLATE_APPLIED, SecurityAudit, make_event, record_safely
from ..errors import GroupNotRegistered, InvalidInput
from ..idempotency import operation_key
from .templates import DiffEntry, SettingsTemplate, TemplateService

log = logging.getLogger(__name__)

MAX_GROUPS = 20
DIGEST_LEN = 6   # hex chars carried by a panel button (the button is HMAC-signed; this only detects a changed state)


def plan_digest(template: SettingsTemplate, entries: tuple[DiffEntry, ...]) -> str:
    body = json.dumps([template.id, template.updated_at.isoformat(), [[e.key, e.template, e.group] for e in entries]],
                      ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(body.encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class ApplyItem:
    group_id: int
    title: str | None
    entries: tuple[DiffEntry, ...]
    same: int
    digest: str


@dataclass(frozen=True, slots=True)
class ApplyPreview:
    template: SettingsTemplate
    items: tuple[ApplyItem, ...]
    skipped: tuple[int, ...]       # ids that are not registered groups


@dataclass(frozen=True, slots=True)
class ApplyOutcome:
    group_id: int
    status: str      # applied | no_change | stale | missing | duplicate | failed
    keys: int = 0


class TemplateApplyService:
    def __init__(self, templates: TemplateService, licenses: Any, group_settings: Any, claims: Any,
                 audit: SecurityAudit | None = None):
        self._templates, self._licenses, self._gs, self._claims, self._audit = templates, licenses, group_settings, claims, audit

    async def preview(self, actor_id, template_id, group_ids) -> ApplyPreview | None:
        """Read only. None = the template does not exist. Duplicates are dropped; more than MAX_GROUPS is refused."""
        ids = list(dict.fromkeys(group_ids))
        if not ids or len(ids) > MAX_GROUPS:
            raise InvalidInput("between 1 and %d groups" % MAX_GROUPS)
        items: list[ApplyItem] = []
        skipped: list[int] = []
        template = None
        for gid in ids:
            try:
                diff = await self._templates.diff(actor_id, template_id, gid)
            except GroupNotRegistered:
                skipped.append(gid)
                continue
            if diff is None:
                return None
            template = diff.template
            lic = await self._licenses.get(gid)
            items.append(ApplyItem(gid, getattr(lic, "title", None), diff.entries, diff.same, plan_digest(diff.template, diff.entries)))
        if template is None:
            template = await self._templates.get(actor_id, template_id)
            if template is None:
                return None
        return ApplyPreview(template, tuple(items), tuple(skipped))

    async def execute(self, actor_id, template_id, items, batch_id) -> list[ApplyOutcome]:
        """`items` = [(group_id, digest the owner saw)]. `batch_id` = one confirmation (callback id / pending code)."""
        await self._templates.require_owner(actor_id)
        out: list[ApplyOutcome] = []
        for gid, seen in items:
            try:
                out.append(await self._one(actor_id, template_id, gid, seen, batch_id))
            except Exception:
                log.error("template apply failed", extra={"group_id": gid}, exc_info=True)
                out.append(ApplyOutcome(gid, "failed"))
        return out

    async def _one(self, actor_id, template_id, gid, seen, batch_id) -> ApplyOutcome:
        if not await self._claims.claim(operation_key("tplapply", batch_id, template_id, gid)):
            return ApplyOutcome(gid, "duplicate")
        try:
            diff = await self._templates.diff(actor_id, template_id, gid)
        except GroupNotRegistered:
            return ApplyOutcome(gid, "missing")
        if diff is None:
            return ApplyOutcome(gid, "missing")
        digest = plan_digest(diff.template, diff.entries)
        if not isinstance(seen, str) or not digest.startswith(seen) or not seen:
            return ApplyOutcome(gid, "stale")
        if not diff.entries:
            return ApplyOutcome(gid, "no_change")
        patch = {e.key: e.template for e in diff.entries}
        await self._gs.update(actor_id, gid, patch)
        await record_safely(self._audit, make_event(
            TEMPLATE_APPLIED, actor=actor_id, group_id=gid,
            detail=f"template={template_id} keys={len(patch)}: " + ",".join(sorted(patch)[:12])))
        return ApplyOutcome(gid, "applied", len(patch))
