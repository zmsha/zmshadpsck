"""Settings templates of the OWNER (phase 5.6): the effective-settings view, validation, naming, the diff preview, the
in-memory store and `TemplateService`. READ/PREVIEW ONLY: nothing here writes to any group (applying = part 5.7).

A template is a flat dict of settings keys (the same keys a group's settings JSON uses: protection, welcome,
verification, new-member policy). It stores VALUES THE RUNTIME WOULD READ BACK UNCHANGED: a value that the typed settings
classes would clamp or drop is rejected, so a template can never smuggle in a value the bot would interpret differently.
`dry_run` is never part of a template (it is a per-group owner switch, not a configuration to copy).

Who: only the primary owner (`Permission.OWNER_TEMPLATES`, exactly OWNER_TELEGRAM_ID). Group admins, delegates, the backup
owner and members are refused (and audited by the permission service).
"""
from __future__ import annotations

import dataclasses
import re
from dataclasses import dataclass, replace
from datetime import datetime
from typing import Any, Callable, Protocol

from ..audit import TEMPLATE_DELETED, TEMPLATE_SAVED, SecurityAudit, make_event, record_safely, sanitize_text
from ..errors import GroupNotRegistered, InvalidInput, PermissionDenied
from ..groups.service import validate_settings_patch
from ..members.settings import NewMemberPolicy, VerificationSettings, WelcomeSettings
from ..moderation.arabic import fold_arabic
from ..permissions import Permission
from ..protection.settings import ProtectionSettings
from ..time_utils import ensure_utc, utcnow

MAX_TEMPLATES = 50
NAME_MAX = 40
MAX_ID = 999_999_999
EXCLUDED_KEYS = frozenset({"dry_run"})
_CONTROL = re.compile(r"[\x00-\x1f\x7f​-‏‪-‮⁦-⁩]")
_HAS_LETTER = re.compile(r"[^\W_]", re.UNICODE)


def _fields(cls: type) -> tuple[str, ...]:
    return tuple(f.name for f in dataclasses.fields(cls) if f.name not in EXCLUDED_KEYS)


# Stable order = the order of the typed settings classes (protection, welcome, verification, new members).
TEMPLATE_KEYS: tuple[str, ...] = (*_fields(ProtectionSettings), *_fields(WelcomeSettings), *_fields(VerificationSettings),
                                  *_fields(NewMemberPolicy))
assert len(set(TEMPLATE_KEYS)) == len(TEMPLATE_KEYS)  # the four classes must not share a key


def _plain(value: Any) -> Any:
    return list(value) if isinstance(value, tuple) else value


def effective_settings(raw: Any) -> dict[str, Any]:
    """What the bot would ACTUALLY use for a group whose stored settings JSON is `raw` (defaults for anything missing or
    invalid), as a flat JSON-able dict over exactly `TEMPLATE_KEYS`."""
    raw = raw if isinstance(raw, dict) else {}
    out: dict[str, Any] = {}
    for cls in (ProtectionSettings, WelcomeSettings, VerificationSettings, NewMemberPolicy):
        obj = cls.from_raw(raw)
        for key in _fields(cls):
            out[key] = _plain(getattr(obj, key))
    return out


def validate_template_settings(settings: object) -> dict[str, Any]:
    """Whitelisted keys only, JSON-safe, and every value equal to what the runtime reads back (else InvalidInput)."""
    if not isinstance(settings, dict) or not settings:
        raise InvalidInput("a template needs a non-empty settings object")
    unknown = sorted(str(k) for k in settings if k not in TEMPLATE_KEYS)
    if unknown:
        raise InvalidInput("unknown or forbidden template key: " + ", ".join(unknown[:5]))
    validate_settings_patch(settings)  # size/depth/NaN/NUL checks shared with group settings
    effective = effective_settings(settings)
    for key, value in settings.items():
        if effective[key] != value or type(effective[key]) is not type(value):
            raise InvalidInput(f"invalid value for {key}")
    return {key: settings[key] for key in TEMPLATE_KEYS if key in settings}


def normalize_name(name: object) -> tuple[str, str]:
    """-> (display name, unique key). Control/bidi characters removed, whitespace collapsed, 1..NAME_MAX chars, at least one
    letter or digit; the key folds case and Arabic alef/ta-marbuta so 'قالب' and 'قالب ' are one name."""
    if not isinstance(name, str):
        raise InvalidInput("template name must be text")
    shown = " ".join(_CONTROL.sub(" ", name).split())
    if not shown or len(shown) > NAME_MAX or not _HAS_LETTER.search(shown):
        raise InvalidInput("template name must be 1-%d characters with a letter or digit" % NAME_MAX)
    return shown, fold_arabic(shown).casefold()


@dataclass(frozen=True, slots=True)
class SettingsTemplate:
    id: int
    name: str
    name_key: str
    settings: dict
    created_by: int
    created_at: datetime
    updated_at: datetime
    source_group_id: int | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "created_at", ensure_utc(self.created_at))
        object.__setattr__(self, "updated_at", ensure_utc(self.updated_at))


@dataclass(frozen=True, slots=True)
class DiffEntry:
    key: str
    template: Any
    group: Any


@dataclass(frozen=True, slots=True)
class TemplateDiff:
    template: SettingsTemplate
    group_id: int
    entries: tuple[DiffEntry, ...]   # only keys the template sets and whose value differs from the group's EFFECTIVE value
    same: int                        # keys the template sets that the group already has


def diff_settings(template_settings: dict, group_effective: dict) -> tuple[tuple[DiffEntry, ...], int]:
    """Pure: the template's keys against the group's effective settings. Nothing is applied."""
    entries: list[DiffEntry] = []
    same = 0
    for key in TEMPLATE_KEYS:
        if key not in template_settings:
            continue
        if template_settings[key] == group_effective.get(key):
            same += 1
        else:
            entries.append(DiffEntry(key, template_settings[key], group_effective.get(key)))
    return tuple(entries), same


class TemplateStore(Protocol):
    async def upsert(self, name: str, name_key: str, settings: dict, created_by: int, source_group_id: int | None,
                     now: datetime) -> tuple[SettingsTemplate, bool]: ...   # (row, created?)

    async def get(self, template_id: int) -> SettingsTemplate | None: ...

    async def get_by_key(self, name_key: str) -> SettingsTemplate | None: ...

    async def list(self, limit: int = MAX_TEMPLATES) -> list[SettingsTemplate]: ...

    async def delete(self, template_id: int) -> bool: ...

    async def count(self) -> int: ...


class InMemoryTemplateStore:
    """Tests / local experiments only (state is lost on restart)."""

    def __init__(self) -> None:
        self._rows: dict[int, SettingsTemplate] = {}
        self._next = 1

    async def upsert(self, name, name_key, settings, created_by, source_group_id, now):
        for row in self._rows.values():
            if row.name_key == name_key:
                updated = replace(row, name=name, settings=dict(settings), updated_at=now, source_group_id=source_group_id)
                self._rows[row.id] = updated
                return replace(updated, settings=dict(updated.settings)), False
        row = SettingsTemplate(self._next, name, name_key, dict(settings), created_by, now, now, source_group_id)
        self._rows[row.id] = row
        self._next += 1
        return replace(row, settings=dict(row.settings)), True

    async def get(self, template_id):
        row = self._rows.get(template_id)
        return None if row is None else replace(row, settings=dict(row.settings))

    async def get_by_key(self, name_key):
        for row in self._rows.values():
            if row.name_key == name_key:
                return replace(row, settings=dict(row.settings))
        return None

    async def list(self, limit=MAX_TEMPLATES):
        rows = sorted(self._rows.values(), key=lambda r: (r.name_key, r.id))
        return [replace(r, settings=dict(r.settings)) for r in rows[:limit]]

    async def delete(self, template_id) -> bool:
        return self._rows.pop(template_id, None) is not None

    async def count(self) -> int:
        return len(self._rows)


class TemplateLimitReached(InvalidInput):
    """MAX_TEMPLATES templates exist and the name is new."""


def _template_id(value: object) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or not 1 <= value <= MAX_ID:
        raise InvalidInput("invalid template id")
    return value


class TemplateService:
    """Owner-only templates: save (from a group's effective settings), list, read, delete, and the read-only diff."""

    def __init__(self, store: TemplateStore, licenses: Any, settings_store: Any, permissions: Any,
                 audit: SecurityAudit | None = None, *, clock: Callable[[], datetime] = utcnow):
        self._store, self._licenses, self._settings = store, licenses, settings_store
        self._perm, self._audit, self._clock = permissions, audit, clock

    async def require_owner(self, actor_id: object) -> None:
        decision = await self._perm.check_global(actor_id, Permission.OWNER_TEMPLATES)
        if not decision.allowed:
            raise PermissionDenied(Permission.OWNER_TEMPLATES.value, decision.reason)

    async def _group_effective(self, group_id: object) -> dict:
        if not isinstance(group_id, int) or isinstance(group_id, bool) or group_id >= 0:
            raise InvalidInput("invalid group id")
        if await self._licenses.get(group_id) is None:
            raise GroupNotRegistered("group is not registered")
        row = await self._settings.get(group_id)
        return effective_settings(row.settings if row is not None else {})

    async def save_from_group(self, actor_id, name, group_id) -> tuple[SettingsTemplate, bool]:
        """Copy the group's EFFECTIVE settings (minus `dry_run`) into the named template; the same name updates it."""
        await self.require_owner(actor_id)
        shown, key = normalize_name(name)
        effective = await self._group_effective(group_id)
        settings = validate_template_settings(effective)
        if await self._store.get_by_key(key) is None and await self._store.count() >= MAX_TEMPLATES:
            raise TemplateLimitReached("too many templates")
        now = self._clock()
        template, created = await self._store.upsert(shown, key, settings, actor_id, group_id, now)
        await record_safely(self._audit, make_event(
            TEMPLATE_SAVED, actor=actor_id, group_id=group_id,
            detail=f"template={template.id} {'created' if created else 'updated'} name={sanitize_text(shown, NAME_MAX)}", now=now))
        return template, created

    async def save_from_settings(self, actor_id, name, settings, source_group_id=None) -> tuple[SettingsTemplate, bool]:
        """Save validated settings (e.g. from a sandbox session) as a named template; the same name updates it (5.8)."""
        await self.require_owner(actor_id)
        shown, key = normalize_name(name)
        clean = validate_template_settings(settings)
        if await self._store.get_by_key(key) is None and await self._store.count() >= MAX_TEMPLATES:
            raise TemplateLimitReached("too many templates")
        now = self._clock()
        template, created = await self._store.upsert(shown, key, clean, actor_id, source_group_id, now)
        await record_safely(self._audit, make_event(
            TEMPLATE_SAVED, actor=actor_id, group_id=source_group_id,
            detail=f"template={template.id} {'created' if created else 'updated'} name={sanitize_text(shown, NAME_MAX)} source=sandbox", now=now))
        return template, created

    async def group_effective(self, actor_id, group_id) -> dict:
        """The EFFECTIVE settings of a registered group (owner only, read only)."""
        await self.require_owner(actor_id)
        return await self._group_effective(group_id)

    async def list(self, actor_id) -> list[SettingsTemplate]:
        await self.require_owner(actor_id)
        return await self._store.list(MAX_TEMPLATES)

    async def get(self, actor_id, template_id) -> SettingsTemplate | None:
        await self.require_owner(actor_id)
        return await self._store.get(_template_id(template_id))

    async def find(self, actor_id, name) -> SettingsTemplate | None:
        await self.require_owner(actor_id)
        return await self._store.get_by_key(normalize_name(name)[1])

    async def delete(self, actor_id, template_id) -> bool:
        await self.require_owner(actor_id)
        template = await self._store.get(_template_id(template_id))
        if template is None or not await self._store.delete(template.id):
            return False
        await record_safely(self._audit, make_event(
            TEMPLATE_DELETED, actor=actor_id, detail=f"template={template.id} name={sanitize_text(template.name, NAME_MAX)}",
            now=self._clock()))
        return True

    async def diff(self, actor_id, template_id, group_id) -> TemplateDiff | None:
        """Preview only: None when the template no longer exists. Reads the group; writes NOTHING anywhere."""
        await self.require_owner(actor_id)
        template = await self._store.get(_template_id(template_id))
        if template is None:
            return None
        entries, same = diff_settings(template.settings, await self._group_effective(group_id))
        return TemplateDiff(template, group_id, entries, same)
