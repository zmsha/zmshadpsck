"""Owner's settings templates and per-group look (phase 5.6).

Separate from `owner_hub` on purpose: the hub only OBSERVES (a static guard forbids any write there), while templates are the
owner's own configuration (their own table). 5.6 is preview only: nothing in this package writes to a group, a license or a
sanction; applying a template to a group arrives in part 5.7 (explicit confirmation + audit per group).
"""
