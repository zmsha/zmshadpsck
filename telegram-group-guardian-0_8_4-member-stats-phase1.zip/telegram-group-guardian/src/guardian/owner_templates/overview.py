"""Owner's read-only look at ONE group (phase 5.6): its license, its EFFECTIVE settings and its latest events.

Events = the group's license history (`license_audit_log`) merged with its security events (`security_audit_log`), newest
first, capped. Both come through `AuditQueryService` (`Permission.VIEW_AUDIT`, owner only, scoped to this group id), so no other
group's rows can appear. Nothing here writes.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

from ..errors import GroupNotRegistered, InvalidInput, PermissionDenied
from ..permissions import Permission
from .templates import effective_settings

MAX_EVENTS = 8
_FETCH = 30


@dataclass(frozen=True, slots=True)
class GroupEvent:
    when: datetime
    kind: str            # "license" | "security"
    what: str            # action / event type (stable codes)
    actor: int | None
    detail: str | None


@dataclass(frozen=True, slots=True)
class GroupOverview:
    license: Any
    settings: dict
    events: tuple[GroupEvent, ...]


class GroupOverviewService:
    def __init__(self, licenses: Any, settings_store: Any, audit_query: Any, permissions: Any, *, max_events: int = MAX_EVENTS):
        self._licenses, self._settings, self._audit, self._perm, self._max = licenses, settings_store, audit_query, permissions, max_events

    async def overview(self, actor_id: object, group_id: object) -> GroupOverview:
        decision = await self._perm.check_global(actor_id, Permission.OWNER_PANEL)
        if not decision.allowed:
            raise PermissionDenied(Permission.OWNER_PANEL.value, decision.reason)
        if not isinstance(group_id, int) or isinstance(group_id, bool) or group_id >= 0:
            raise InvalidInput("invalid group id")
        lic = await self._licenses.get(group_id)
        if lic is None:
            raise GroupNotRegistered("group is not registered")
        row = await self._settings.get(group_id)
        history = await self._audit.license_history(actor_id, group_id, _FETCH)
        security = await self._audit.security_events(actor_id, group_id, _FETCH)
        events = [GroupEvent(e.occurred_at, "license", e.action, e.actor_telegram_id,
                             f"{e.previous_status.value if e.previous_status else '-'}>{e.new_status.value}") for e in history]
        events += [GroupEvent(e.occurred_at, "security", e.event_type, e.actor_telegram_id, e.detail) for e in security]
        events.sort(key=lambda e: e.when, reverse=True)
        return GroupOverview(lic, effective_settings(row.settings if row is not None else {}), tuple(events[: self._max]))
