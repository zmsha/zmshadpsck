"""Short-lived, single-use confirmation codes for the owner's multi-step changes (phase 5.7).

A staged change (apply a template to groups, change the global defaults) is stored here with the owner id; nothing happens
until the owner sends the code back. Memory only, on purpose: after a restart or the free host's sleep every pending code is
gone and the owner simply previews again (fail closed). A code is bound to its owner and its kind, expires after `ttl`
seconds, works once, and the table is bounded.
"""
from __future__ import annotations

import secrets
from datetime import datetime, timedelta
from typing import Any, Callable

from ..time_utils import utcnow

ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"   # no 0/O/1/I/L: easy to read and type on a phone
CODE_LEN = 6
DEFAULT_TTL = 600
MAX_PENDING = 20


class PendingActions:
    def __init__(self, *, clock: Callable[[], datetime] = utcnow, ttl: int = DEFAULT_TTL, max_items: int = MAX_PENDING):
        self._clock, self._ttl, self._max = clock, ttl, max_items
        self._items: dict[str, tuple[int, str, Any, datetime]] = {}

    @property
    def ttl_minutes(self) -> int:
        return max(1, self._ttl // 60)

    def _purge(self) -> None:
        now = self._clock()
        for code in [c for c, (_, _, _, exp) in self._items.items() if exp <= now]:
            del self._items[code]

    def create(self, owner_id: int, kind: str, payload: Any) -> str:
        self._purge()
        while len(self._items) >= self._max:
            del self._items[min(self._items, key=lambda c: self._items[c][3])]   # drop the oldest
        while True:
            code = "".join(secrets.choice(ALPHABET) for _ in range(CODE_LEN))
            if code not in self._items:
                break
        self._items[code] = (owner_id, kind, payload, self._clock() + timedelta(seconds=self._ttl))
        return code

    def peek(self, owner_id: int, kind: str, code: object) -> Any | None:
        """The payload WITHOUT consuming it (same ownership/kind/expiry rules as `take`; used to check two codes before using either)."""
        self._purge()
        if not isinstance(code, str):
            return None
        item = self._items.get(code.strip().upper())
        if item is None or item[0] != owner_id or item[1] != kind:
            return None
        return item[2]

    def take(self, owner_id: int, kind: str, code: object) -> Any | None:
        """The payload, once. Wrong owner, wrong kind, expired or unknown => None (a wrong attempt consumes nothing)."""
        self._purge()
        if not isinstance(code, str):
            return None
        code = code.strip().upper()
        item = self._items.get(code)
        if item is None or item[0] != owner_id or item[1] != kind:
            return None
        del self._items[code]
        return item[2]

    def __len__(self) -> int:
        self._purge()
        return len(self._items)
