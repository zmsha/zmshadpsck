"""Global default settings for NEW groups (phase 5.7).

* Storage: one row (`global_default_settings`) with a `version`; changes are compare-and-set on that version.
* Change flow: STAGE (read only; shows the differences against the current defaults and returns a confirmation code) ->
  the owner sends the code -> CONFIRM writes. Nothing else ever writes the defaults; nothing is copied from a test/sandbox.
* Effect: ONLY groups registered AFTER the approval receive them (`DefaultsSeeder`, called by the license service when a
  group is registered for the first time and has no stored settings). Existing groups are never touched here.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Callable, Protocol

from ..audit import DEFAULTS_CHANGED, SecurityAudit, make_event, record_safely
from ..errors import InvalidInput
from ..time_utils import utcnow
from .pending import PendingActions
from .templates import (DiffEntry, SettingsTemplate, TemplateService, diff_settings, effective_settings,
                        validate_template_settings)

log = logging.getLogger(__name__)
KIND = "defaults"


@dataclass(frozen=True, slots=True)
class GlobalDefaults:
    settings: dict
    version: int = 0                 # 0 = never set (the bot's built-in values apply)
    updated_by: int | None = None
    updated_at: datetime | None = None


class DefaultsStore(Protocol):
    async def get(self) -> GlobalDefaults: ...

    async def replace(self, settings: dict, expected_version: int, updated_by: int, now: datetime) -> GlobalDefaults | None: ...


class InMemoryDefaultsStore:
    def __init__(self) -> None:
        self._row = GlobalDefaults({})

    async def get(self) -> GlobalDefaults:
        return GlobalDefaults(dict(self._row.settings), self._row.version, self._row.updated_by, self._row.updated_at)

    async def replace(self, settings, expected_version, updated_by, now):
        if self._row.version != expected_version:
            return None
        self._row = GlobalDefaults(dict(settings), expected_version + 1, updated_by, now)
        return await self.get()


class PostgresDefaultsStore:
    """NOT executed against a real PostgreSQL in the build sandbox. Single-row table, compare-and-set on `version`."""

    def __init__(self, database) -> None:
        self._db = database

    @staticmethod
    def _row(row) -> GlobalDefaults:
        raw = row["settings"]
        raw = json.loads(raw) if isinstance(raw, str) else raw
        return GlobalDefaults(dict(raw) if isinstance(raw, dict) else {}, row["version"], row["updated_by"], row["updated_at"])

    async def get(self) -> GlobalDefaults:
        async with self._db.acquire() as conn:
            row = await conn.fetchrow("SELECT settings, version, updated_by, updated_at FROM global_default_settings WHERE singleton")
        return GlobalDefaults({}) if row is None else self._row(row)

    async def replace(self, settings, expected_version, updated_by, now):
        payload = json.dumps(settings, ensure_ascii=False, allow_nan=False)
        async with self._db.acquire() as conn:
            if expected_version == 0:
                row = await conn.fetchrow(
                    "INSERT INTO global_default_settings (singleton, settings, version, updated_by, updated_at) "
                    "VALUES (TRUE, $1::jsonb, 1, $2, $3) ON CONFLICT (singleton) DO NOTHING "
                    "RETURNING settings, version, updated_by, updated_at", payload, updated_by, now)
            else:
                row = await conn.fetchrow(
                    "UPDATE global_default_settings SET settings = $1::jsonb, version = version + 1, updated_by = $2, "
                    "updated_at = $3 WHERE singleton AND version = $4 RETURNING settings, version, updated_by, updated_at",
                    payload, updated_by, now, expected_version)
        return None if row is None else self._row(row)


@dataclass(frozen=True, slots=True)
class DefaultsView:
    current: GlobalDefaults
    entries: tuple[DiffEntry, ...]   # current defaults vs the bot's built-in values (group = built-in, template = default)


@dataclass(frozen=True, slots=True)
class DefaultsStage:
    source: str | None               # template name; None = reset to the built-in values
    version: int                     # the version the owner saw
    entries: tuple[DiffEntry, ...]   # current defaults ➜ proposed (group = current, template = proposed)
    code: str


class GlobalDefaultsService:
    def __init__(self, store: DefaultsStore, templates: TemplateService, permissions: Any, pending: PendingActions,
                 audit: SecurityAudit | None = None, *, clock: Callable[[], datetime] = utcnow):
        self._store, self._templates, self._pending, self._audit, self._clock = store, templates, pending, audit, clock

    async def show(self, actor_id) -> DefaultsView:
        await self._templates.require_owner(actor_id)
        cur = await self._store.get()
        entries, _ = diff_settings(effective_settings(cur.settings), effective_settings({}))
        # `diff_settings(template, group)` -> entries.template = default value, entries.group = built-in value
        return DefaultsView(cur, entries)

    async def stage(self, actor_id, template_id: int | None) -> DefaultsStage | None:
        """None = the template does not exist. Read only: returns a code; nothing changes until `confirm`."""
        await self._templates.require_owner(actor_id)
        source = None
        proposed: dict = {}
        if template_id is not None:
            template = await self._templates.get(actor_id, template_id)
            if template is None:
                return None
            source, proposed = template.name, validate_template_settings(template.settings)
        cur = await self._store.get()
        entries, _ = diff_settings(effective_settings(proposed), effective_settings(cur.settings))
        code = self._pending.create(actor_id, KIND, (source, proposed, cur.version))
        return DefaultsStage(source, cur.version, entries, code)

    async def confirm(self, actor_id, code) -> tuple[str, GlobalDefaults | None]:
        """-> ("approved", row) | ("unknown", None) | ("conflict", None) (the defaults changed since the preview)."""
        await self._templates.require_owner(actor_id)
        staged = self._pending.take(actor_id, KIND, code)
        if staged is None:
            return "unknown", None
        _source, proposed, version = staged
        now = self._clock()
        row = await self._store.replace(validate_template_settings(proposed) if proposed else {}, version, actor_id, now)
        if row is None:
            return "conflict", None
        await record_safely(self._audit, make_event(
            DEFAULTS_CHANGED, actor=actor_id, detail=f"version={row.version} keys={len(row.settings)}", now=now))
        return "approved", row


class DefaultsSeeder:
    """Called when a group is registered for the first time: copies the approved defaults into its (still empty) settings."""

    def __init__(self, store: DefaultsStore, settings_store: Any, owner_id: int, *, clock: Callable[[], datetime] = utcnow):
        self._store, self._settings, self._owner, self._clock = store, settings_store, owner_id, clock

    async def seed(self, group_id: int) -> bool:
        defaults = await self._store.get()
        if not defaults.settings:
            return False
        if await self._settings.get(group_id) is not None:    # a group with stored settings is never overwritten
            return False
        await self._settings.merge(group_id, validate_template_settings(defaults.settings), self._owner, self._clock())
        return True
