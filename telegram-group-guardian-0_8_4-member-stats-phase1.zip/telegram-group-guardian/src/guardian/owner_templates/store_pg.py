"""PostgreSQL store of the owner's settings templates (phase 5.6; NOT executed against a real PostgreSQL in the build
sandbox). The table is owner-level, not per-group (see `0005_settings_templates.sql`): it is reachable only through
`TemplateService`, which checks `Permission.OWNER_TEMPLATES` first. Every statement is parameterised."""
from __future__ import annotations

import json

from .templates import MAX_TEMPLATES, SettingsTemplate

_COLS = "id, name, name_key, settings, created_by, created_at, updated_at, source_group_id"


def _settings(value) -> dict:
    if isinstance(value, str):  # asyncpg returns JSONB as text unless a codec is registered
        value = json.loads(value)
    return dict(value) if isinstance(value, dict) else {}


def _row(row) -> SettingsTemplate:
    return SettingsTemplate(id=row["id"], name=row["name"], name_key=row["name_key"], settings=_settings(row["settings"]),
                            created_by=row["created_by"], created_at=row["created_at"], updated_at=row["updated_at"],
                            source_group_id=row["source_group_id"])


class PostgresTemplateStore:
    def __init__(self, database) -> None:
        self._db = database

    async def upsert(self, name, name_key, settings, created_by, source_group_id, now):
        payload = json.dumps(settings, ensure_ascii=False, allow_nan=False)
        async with self._db.acquire() as conn:
            row = await conn.fetchrow(
                "INSERT INTO settings_templates (name, name_key, settings, created_by, created_at, updated_at, source_group_id) "
                "VALUES ($1, $2, $3::jsonb, $4, $5, $5, $6) "
                "ON CONFLICT (name_key) DO UPDATE SET name = EXCLUDED.name, settings = EXCLUDED.settings, "
                "updated_at = EXCLUDED.updated_at, source_group_id = EXCLUDED.source_group_id "
                "RETURNING " + _COLS + ", (xmax = 0) AS created",
                name, name_key, payload, created_by, now, source_group_id)
        return _row(row), bool(row["created"])

    async def get(self, template_id):
        async with self._db.acquire() as conn:
            row = await conn.fetchrow("SELECT " + _COLS + " FROM settings_templates WHERE id = $1", template_id)
        return None if row is None else _row(row)

    async def get_by_key(self, name_key):
        async with self._db.acquire() as conn:
            row = await conn.fetchrow("SELECT " + _COLS + " FROM settings_templates WHERE name_key = $1", name_key)
        return None if row is None else _row(row)

    async def list(self, limit=MAX_TEMPLATES):
        limit = max(1, min(int(limit), 200))
        async with self._db.acquire() as conn:
            rows = await conn.fetch("SELECT " + _COLS + " FROM settings_templates ORDER BY name_key, id LIMIT $1", limit)
        return [_row(r) for r in rows]

    async def delete(self, template_id) -> bool:
        async with self._db.acquire() as conn:
            deleted = await conn.fetchval("DELETE FROM settings_templates WHERE id = $1 RETURNING id", template_id)
        return deleted is not None

    async def count(self) -> int:
        async with self._db.acquire() as conn:
            return int(await conn.fetchval("SELECT count(*) FROM settings_templates") or 0)
