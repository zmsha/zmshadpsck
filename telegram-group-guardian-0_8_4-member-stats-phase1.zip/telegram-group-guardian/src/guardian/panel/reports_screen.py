"""The reports screen of the admin panel (part 6.4b): read the list, open one report, take / resolve / dismiss it.

Framework independent (no aiogram). It is reached ONLY from `PanelService.press`, which has already run (for THIS press):
signature -> owner binding -> `MODERATE` for THIS group -> live license -> panel expiry. So a demoted admin loses the
reports screen on the very next press, exactly like every other screen. What is decided here:

* Scope. Every read/write goes through `ReportService` with the group of the PRESSED message; another group's report number
  is simply "not found". The report id comes from the signed button argument, never from free text.
* Destination (6.4a). The panel message lives in the group, where every member can read it. When the PRIMARY OWNER approved
  another chat for report listings/details, those (reporter ids, the reporters' words) are NOT shown here at all: the screen
  shows only a notice and the number of open reports, and every report button is refused. An unreadable destination
  setting = refusal (fail closed).
* Moves. Only take / resolve / dismiss with a FIXED outcome per button (`panel.report_actions.MOVES`); type, priority and
  the destination stay with the commands. One press = one claim `op:panelrep:<group>:<callback id>` (a redelivered press never
  moves twice); the move itself is the service's compare-and-set, which also writes the audit row. A stale button (already
  taken / closed) answers a toast and re-renders the fresh report; closing a report never sanctions anyone.
"""
from __future__ import annotations

import logging
import re
from typing import Any, Callable

from ..errors import InvalidInput
from ..i18n import t
from ..idempotency import operation_key
from ..reports import render
from ..reports.destination import destination_of
from ..reports.models import CLOSED_STATUSES, OPEN_STATUSES, Report, ReportStatus
from ..reports.service import TransitionCode, TransitionResult
from . import codec
from .outcome import PanelOutcome
from .report_actions import (LIST_SCREENS, MOVES, RP_ALL, RP_CLOSED, RP_OPEN, RP_SHOW, RP_TAKE, RP_TAKEN, RP_RES_ACT,
                             RP_RES_NONE, RP_DIS_NONE, RP_DIS_FALSE)

log = logging.getLogger(__name__)

PAGE_SIZE = 5
# list screen -> (statuses filter, i18n key of its label). `open` means open AND taken, as `/reports` does.
FILTERS: dict[str, tuple[tuple[ReportStatus, ...] | None, str]] = {
    RP_OPEN: (OPEN_STATUSES, "report_filter_open"), RP_TAKEN: ((ReportStatus.TAKEN,), "report_filter_taken"),
    RP_CLOSED: (CLOSED_STATUSES, "report_filter_closed"), RP_ALL: (None, "report_filter_all"),
}
_QUERY_ID = re.compile(r"[A-Za-z0-9_\-]{1,64}", re.ASCII)  # Telegram's callback query id (the idempotency anchor)
_TOAST_OK = {"take": "pn_rp_ok_taken", "resolve": "pn_rp_ok_resolved", "dismiss": "pn_rp_ok_dismissed"}


class ReportsScreen:
    def __init__(self, *, reports: Any, claims: Any, load_raw: Callable[[int], Any],
                 build: Callable[..., str], display_timezone: str = "Asia/Riyadh"):
        self._reports, self._claims, self._load_raw, self._b, self._tz = reports, claims, load_raw, build, display_timezone

    # ------------------------------------------------------------------ entry
    async def handle(self, group: int, actor: int, screen: str, arg: int | None, query_id: object, lang: str) -> PanelOutcome:
        try:
            routed = destination_of(await self._load_raw(group), group) != group
        except Exception:
            log.error("panel reports: destination unreadable", extra={"group_id": group}, exc_info=True)
            return self._unavailable(lang)
        if routed:
            return await self._routed(group, actor, lang)
        try:
            if screen in LIST_SCREENS:
                return await self._list(group, actor, screen, arg, lang)
            if arg is None:                      # the codec already refuses this; defence in depth
                return self._unavailable(lang)
            if screen == RP_SHOW:
                report = await self._reports.get(group, arg)
                if report is None:
                    return self._gone(lang)
                return self._detail(group, actor, report, lang, "rp_detail")
            if screen in MOVES:
                return await self._move(group, actor, screen, arg, query_id, lang)
        except InvalidInput:
            return self._unavailable(lang)
        except Exception:
            log.error("panel reports failed", extra={"group_id": group, "screen": screen}, exc_info=True)
            return self._unavailable(lang)
        return self._unavailable(lang)

    # ------------------------------------------------------------------ pieces
    def _unavailable(self, lang: str) -> PanelOutcome:
        return PanelOutcome("unavailable", t("pn_unavailable", lang), True)

    def _gone(self, lang: str) -> PanelOutcome:
        return PanelOutcome("rp_gone", t("pn_rp_gone", lang), True)

    def _nav(self, group: int, owner: int, lang: str, *, back: tuple[str, str] | None = None) -> tuple[tuple[str, str], ...]:
        first = back or (t("pn_btn_back", lang), self._b(group, owner, codec.SCREEN_HOME))
        return (first, (t("pn_btn_close", lang), self._b(group, owner, codec.SCREEN_CLOSE)))

    async def _routed(self, group: int, owner: int, lang: str) -> PanelOutcome:
        """The approved destination is another chat: show NOTHING of the reports here, only how many are open."""
        try:
            open_now = await self._reports.count(group, OPEN_STATUSES)
        except Exception:
            log.error("panel reports: count failed", extra={"group_id": group}, exc_info=True)
            return self._unavailable(lang)
        return PanelOutcome("rp_routed", "", False, t("pn_rp_routed", lang, open=open_now),
                            (self._nav(group, owner, lang),))

    async def _list(self, group: int, owner: int, screen: str, before: int | None, lang: str) -> PanelOutcome:
        statuses, label_key = FILTERS[screen]
        rows = await self._reports.list_reports(group, statuses, PAGE_SIZE + 1, before)
        total = await self._reports.count(group, statuses)
        shown = rows[:PAGE_SIZE]
        label = t(label_key, lang)
        if shown:
            text = t("report_list_title", lang, filter=label, count=total) + "\n" + "\n".join(
                render.line(r, lang, self._tz) for r in shown)
        else:
            text = t("report_list_empty", lang, filter=label)
        buttons: list[tuple[tuple[str, str], ...]] = [
            ((f"#{r.id} {render.PRIORITY_ICON[r.priority.value]} {t('report_type_' + r.report_type.value, lang)}",
              self._b(group, owner, RP_SHOW, r.id)),) for r in shown]
        filters = [(("✅ " if name == screen else "") + t(key, lang), self._b(group, owner, name))
                   for name, (_, key) in FILTERS.items()]
        buttons += [tuple(filters[:2]), tuple(filters[2:])]
        if len(rows) > PAGE_SIZE:
            buttons.append(((t("pn_rp_next", lang), self._b(group, owner, screen, shown[-1].id)),))
        buttons.append(self._nav(group, owner, lang))
        return PanelOutcome("rp_list", "", False, text, tuple(buttons))

    def _detail(self, group: int, owner: int, r: Report, lang: str, status: str, toast: str = "",
                alert: bool = False) -> PanelOutcome:
        rows: list[tuple[tuple[str, str], ...]] = []
        if r.is_open:
            b = lambda screen: self._b(group, owner, screen, r.id)  # noqa: E731
            if r.status is ReportStatus.OPEN:
                rows.append(((t("pn_rp_take", lang), b(RP_TAKE)),))
            rows.append(((t("pn_rp_res_act", lang), b(RP_RES_ACT)), (t("pn_rp_res_none", lang), b(RP_RES_NONE))))
            rows.append(((t("pn_rp_dis_none", lang), b(RP_DIS_NONE)), (t("pn_rp_dis_false", lang), b(RP_DIS_FALSE))))
        back_screen = RP_OPEN if r.is_open else RP_CLOSED
        rows.append(((t("pn_rp_list", lang), self._b(group, owner, back_screen)),
                     (t("pn_btn_refresh", lang), self._b(group, owner, RP_SHOW, r.id))))
        rows.append(((t("pn_btn_close", lang), self._b(group, owner, codec.SCREEN_CLOSE)),))
        return PanelOutcome(status, toast, alert, render.details(r, group, lang, self._tz), tuple(rows))

    async def _move(self, group: int, actor: int, screen: str, report_id: int, query_id: object, lang: str) -> PanelOutcome:
        if not isinstance(query_id, str) or not _QUERY_ID.fullmatch(query_id):
            return self._unavailable(lang)          # no idempotency anchor => no write
        try:
            claimed = await self._claims.claim(operation_key("panelrep", group, query_id))
        except Exception:
            log.error("panel reports: claim failed; nothing changed", extra={"group_id": group}, exc_info=True)
            return self._unavailable(lang)
        if not claimed:
            return PanelOutcome("duplicate")        # a redelivered press: nothing changes, nothing shown
        action, outcome = MOVES[screen]
        if action == "take":
            moved: TransitionResult = await self._reports.take(group, report_id, actor)
        elif action == "resolve":
            moved = await self._reports.resolve(group, report_id, actor, outcome)
        else:
            moved = await self._reports.dismiss(group, report_id, actor, outcome)
        code, rid = moved.code, report_id
        if code is TransitionCode.NOT_FOUND or moved.report is None:
            return self._gone(lang)
        if code is TransitionCode.OK:
            return self._detail(group, actor, moved.report, lang, "rp_moved", t(_TOAST_OK[action], lang, id=rid))
        if code is TransitionCode.UNCHANGED:
            return self._detail(group, actor, moved.report, lang, "rp_noop", t("pn_rp_unchanged", lang, id=rid))
        key = "pn_rp_already_taken" if code is TransitionCode.ALREADY_TAKEN else "pn_rp_closed"
        return self._detail(group, actor, moved.report, lang, "rp_conflict", t(key, lang, id=rid), True)
