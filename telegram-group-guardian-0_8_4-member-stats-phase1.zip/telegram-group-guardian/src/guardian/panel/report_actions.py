"""Fixed names of the report screens/buttons of the panel (part 6.4b).

Like `panel.actions`, a button carries only a signed NAME. Unlike them, a report button must also say WHICH report, so
these screens (and only these) may carry one numeric argument: the report id (detail and move screens) or the "older than
this id" page cursor (list screens). The argument is covered by the HMAC (`panel.codec`), so a button for report 5 cannot be
turned into one for report 6, and it can never name a group (the group is always the chat of the pressed message).

Names are `[a-z]{1,8}` (codec limit). The MOVES are value-free too: the outcome of each is fixed here, never read from data.
"""
from __future__ import annotations

from types import MappingProxyType

from ..reports.models import ReportOutcome

# list screens (argument optional: the page cursor `before_id`; none = newest page)
RP_OPEN, RP_TAKEN, RP_CLOSED, RP_ALL = "rpopen", "rptaken", "rpclosed", "rpall"
LIST_SCREENS = (RP_OPEN, RP_TAKEN, RP_CLOSED, RP_ALL)
# detail screen (argument required: the report id)
RP_SHOW = "rpshow"
# moves (argument required: the report id). The service decides what is legal; the outcome below is fixed.
RP_TAKE, RP_RES_ACT, RP_RES_NONE, RP_DIS_NONE, RP_DIS_FALSE = "rptake", "rpresact", "rpresnon", "rpdisnon", "rpdisfal"
MOVES = MappingProxyType({
    RP_TAKE: ("take", None),
    RP_RES_ACT: ("resolve", ReportOutcome.ACTION_TAKEN),
    RP_RES_NONE: ("resolve", ReportOutcome.NO_ACTION),
    RP_DIS_NONE: ("dismiss", ReportOutcome.NO_ACTION),
    RP_DIS_FALSE: ("dismiss", ReportOutcome.FALSE_REPORT),
})
REPORT_SCREENS = (*LIST_SCREENS, RP_SHOW, *MOVES)
ARG_REQUIRED = (RP_SHOW, *MOVES)       # these are refused without an id
