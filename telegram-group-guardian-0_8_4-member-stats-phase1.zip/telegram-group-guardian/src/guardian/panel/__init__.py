"""Inline admin panel (phase 4.7). `codec` = strict signed callback data, `service` = the server-side press handler."""
