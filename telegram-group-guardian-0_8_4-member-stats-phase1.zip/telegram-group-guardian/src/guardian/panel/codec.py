"""Signed callback data of the admin panel (phase 4.7a).

Callback data is attacker-controlled: any user can craft any string and press it. So:
* parsing is a strict whitelist (`pn:<owner>:<screen>:<tag>`, ASCII only, known screens only, <= 64 bytes);
* (6.4b) only the report screens (`panel.report_actions`) may carry ONE numeric argument, `pn:<owner>:<screen>:<arg>:<tag>`
  (a report id or a page cursor). It is covered by the HMAC; any other screen with an argument is not a panel callback;
* `<tag>` is an HMAC (key derived from the webhook secret, domain-separated) over `group | owner | screen`, where `group`
  is the chat of the PRESSED message (never read from the data). A hand-made string, a changed owner/screen, or a panel
  that is somehow shown in another group therefore fails verification;
* the owner inside the data is only the panel's binding; the ACTOR is always Telegram's `from_user` (checked equal to the
  owner by the service, then authorized on the server on every press).
"""
from __future__ import annotations

import hashlib
import hmac
import re
from dataclasses import dataclass

from ..auth import MAX_BIGINT
from .actions import ACTIONS, TOPICS
from .report_actions import ARG_REQUIRED, REPORT_SCREENS

PREFIX = "pn"
MAX_CALLBACK_BYTES = 64          # Telegram limit
TAG_LEN = 12                     # hex chars of the HMAC kept (48 bits; forging needs an online guess per press)
SCREEN_HOME, SCREEN_CLOSE = "home", "close"
# Screens a panel callback may name: home/close, the read-only topic screens, and (4.7b) the write actions, whose
# values live server-side in `panel.actions.ACTIONS`. Part 4.7c adds its screens HERE and in `PanelService`.
SCREENS = (SCREEN_HOME, SCREEN_CLOSE, *TOPICS, *ACTIONS)
_RE = re.compile(r"^pn:([1-9][0-9]{0,17}):([a-z]{1,8}):(?:([1-9][0-9]{0,18}):)?([0-9a-f]{12})$", re.ASCII)
_MAX_ID = 10**18 - 1          # 18 digits: what the pattern accepts (Telegram user ids are far below this)


@dataclass(frozen=True, slots=True)
class PanelCallback:
    owner_id: int
    screen: str
    tag: str
    arg: int | None = None   # report screens only (6.4b)


def derive_key(secret: str | bytes) -> bytes:
    raw = secret.encode("utf-8") if isinstance(secret, str) else bytes(secret)
    if not raw:
        raise ValueError("panel secret must not be empty")
    return hmac.new(raw, b"guardian-panel-callback-v1", hashlib.sha256).digest()


def _tag(key: bytes, group_id: int, owner_id: int, screen: str, arg: int | None = None) -> str:
    # without an argument the message is exactly the pre-6.4b one, so every older button keeps verifying
    msg = (f"pn|{group_id}|{owner_id}|{screen}" + ("" if arg is None else f"|{arg}")).encode("ascii")
    return hmac.new(key, msg, hashlib.sha256).hexdigest()[:TAG_LEN]


def build(key: bytes, group_id: int, owner_id: int, screen: str, arg: int | None = None) -> str:
    if screen not in SCREENS and screen not in REPORT_SCREENS:
        raise ValueError("unsupported panel screen")
    if arg is not None and (screen not in REPORT_SCREENS or not isinstance(arg, int) or isinstance(arg, bool)
                            or not 0 < arg <= MAX_BIGINT):
        raise ValueError("invalid panel argument")
    if arg is None and screen in ARG_REQUIRED:
        raise ValueError("this screen needs a report id")
    if not isinstance(group_id, int) or isinstance(group_id, bool) or group_id >= 0:
        raise ValueError("group_id must be a negative integer")
    if not isinstance(owner_id, int) or isinstance(owner_id, bool) or not 0 < owner_id <= _MAX_ID:
        raise ValueError("owner_id must be a positive integer")
    mid = "" if arg is None else f"{arg}:"
    data = f"{PREFIX}:{owner_id}:{screen}:{mid}{_tag(key, group_id, owner_id, screen, arg)}"
    if len(data.encode("ascii")) > MAX_CALLBACK_BYTES:
        raise ValueError("callback data too long")
    return data


def parse(data: object) -> PanelCallback | None:
    """Structure only (no signature check: that needs the group). None = not a well-formed panel callback."""
    if not isinstance(data, str) or len(data) > MAX_CALLBACK_BYTES:
        return None
    m = _RE.fullmatch(data)
    if m is None:
        return None
    screen, raw_arg = m.group(2), m.group(3)
    owner = int(m.group(1))
    if owner > _MAX_ID:
        return None
    if raw_arg is None:
        if screen in ARG_REQUIRED or (screen not in SCREENS and screen not in REPORT_SCREENS):
            return None
        return PanelCallback(owner, screen, m.group(4))
    arg = int(raw_arg)
    if screen not in REPORT_SCREENS or arg > MAX_BIGINT:
        return None   # an argument on any other screen is not ours
    return PanelCallback(owner, screen, m.group(4), arg)


def verify(key: bytes, group_id: int, cb: PanelCallback) -> bool:
    if not isinstance(group_id, int) or isinstance(group_id, bool) or group_id >= 0:
        return False
    return hmac.compare_digest(cb.tag, _tag(key, group_id, cb.owner_id, cb.screen, cb.arg))
