"""Fixed whitelist of the settings changes a panel button may request (phase 4.7b).

A button never carries a value: it carries the NAME of one of these actions (signed like any screen). The value lives
here, on the server, so nobody can craft "set the timeout to 5 seconds" or "set key X": an unknown name is not a
screen and is rejected by `codec.parse`. Every patch uses the same keys and bounds as the `/welcome /verify /newbie`
commands (`members/settings.py`), and the write goes through the same code path (`MemberSettingsCommands`).

Names are `[a-z]{1,8}` (codec limit; keeps `callback_data` <= 64 bytes).
"""
from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType

TOPIC_WELCOME, TOPIC_VERIFY, TOPIC_NEWBIE = "welcome", "verify", "newbie"
TOPIC_PROTECT, TOPIC_TRUST = "protect", "trust"  # 4.7c: protection settings (buttons write) and trust lists (read only)
TOPICS = (TOPIC_WELCOME, TOPIC_VERIFY, TOPIC_NEWBIE, TOPIC_PROTECT, TOPIC_TRUST)  # screens: their name is the screen name
# Topics whose buttons write (the trust screen has none: a trust entry needs an identity/domain that a fixed,
# value-free button cannot carry, so changing the lists stays with `/trust`, `/untrust`).
WRITABLE_TOPICS = (TOPIC_WELCOME, TOPIC_VERIFY, TOPIC_NEWBIE, TOPIC_PROTECT)
# The ONLY protection keys a panel button may touch. Deliberately absent: `dry_run` (primary-owner-only switch that
# silences every automatic sanction), the domain list, the escalation steps/window and the flood/duplicate windows
# (they need exact custom values: commands only).
PROTECT_KEYS = frozenset({
    "links_enabled", "links_allow_invites", "flood_enabled", "flood_max_messages", "duplicate_enabled",
    "slowmode_seconds", "warn_limit", "warn_action", "warn_action_seconds"})


@dataclass(frozen=True, slots=True)
class PanelAction:
    topic: str
    patch: "MappingProxyType[str, object]"


def _a(topic: str, **patch: object) -> PanelAction:
    return PanelAction(topic, MappingProxyType(dict(patch)))


_W, _V, _N, _P = TOPIC_WELCOME, TOPIC_VERIFY, TOPIC_NEWBIE, TOPIC_PROTECT
ACTIONS: "MappingProxyType[str, PanelAction]" = MappingProxyType({
    # welcome
    "welon": _a(_W, welcome_enabled=True), "weloff": _a(_W, welcome_enabled=False),
    "welpon": _a(_W, welcome_delete_previous=True), "welpoff": _a(_W, welcome_delete_previous=False),
    "welreset": _a(_W, welcome_text=None),
    "weldoff": _a(_W, welcome_delete_after_seconds=0), "weldmin": _a(_W, welcome_delete_after_seconds=60),
    "weldhour": _a(_W, welcome_delete_after_seconds=3600),
    "weljkeep": _a(_W, join_service="keep"), "weljdel": _a(_W, join_service="delete"),
    "wellkeep": _a(_W, leave_service="keep"), "welldel": _a(_W, leave_service="delete"),
    # verification
    "veron": _a(_V, verify_enabled=True), "veroff": _a(_V, verify_enabled=False),
    "verall": _a(_V, verify_scope="all"), "versusp": _a(_V, verify_scope="suspicious"),
    "vmbutton": _a(_V, verify_method="button"), "vmmath": _a(_V, verify_method="math"),
    "vmchoice": _a(_V, verify_method="choice"), "vmadmin": _a(_V, verify_method="admin"),
    "vtone": _a(_V, verify_timeout_seconds=60), "vtfive": _a(_V, verify_timeout_seconds=300),
    "vthour": _a(_V, verify_timeout_seconds=3600),
    "vfrestr": _a(_V, verify_failure="restrict"), "vfkick": _a(_V, verify_failure="kick"),
    "vfban": _a(_V, verify_failure="ban"),
    "vbhour": _a(_V, verify_ban_seconds=3600), "vbday": _a(_V, verify_ban_seconds=86400),
    "vaone": _a(_V, verify_max_attempts=1), "vathree": _a(_V, verify_max_attempts=3),
    "vafive": _a(_V, verify_max_attempts=5),
    # new members
    "nwoff": _a(_N, newbie_seconds=0), "nwhour": _a(_N, newbie_seconds=3600),
    "nwday": _a(_N, newbie_seconds=86400), "nwweek": _a(_N, newbie_seconds=7 * 86400),
    "nlon": _a(_N, newbie_block_links=True), "nloff": _a(_N, newbie_block_links=False),
    "nmon": _a(_N, newbie_block_media=True), "nmoff": _a(_N, newbie_block_media=False),
    "nson": _a(_N, newbie_block_messages=True), "nsoff": _a(_N, newbie_block_messages=False),
    # protection (4.7c)
    "lkon": _a(_P, links_enabled=True), "lkoff": _a(_P, links_enabled=False),
    "invon": _a(_P, links_allow_invites=True), "invoff": _a(_P, links_allow_invites=False),
    "floon": _a(_P, flood_enabled=True), "flooff": _a(_P, flood_enabled=False),
    "fmfour": _a(_P, flood_max_messages=4), "fmsix": _a(_P, flood_max_messages=6),
    "fmten": _a(_P, flood_max_messages=10),
    "dupon": _a(_P, duplicate_enabled=True), "dupoff": _a(_P, duplicate_enabled=False),
    "slwoff": _a(_P, slowmode_seconds=0), "slwten": _a(_P, slowmode_seconds=10),
    "slwhalf": _a(_P, slowmode_seconds=30), "slwmin": _a(_P, slowmode_seconds=60),
    "wltwo": _a(_P, warn_limit=2), "wlthree": _a(_P, warn_limit=3), "wlfive": _a(_P, warn_limit=5),
    "wamute": _a(_P, warn_action="mute"), "wakick": _a(_P, warn_action="kick"), "waban": _a(_P, warn_action="ban"),
    "wsforev": _a(_P, warn_action_seconds=0), "wshour": _a(_P, warn_action_seconds=3600),
    "wsday": _a(_P, warn_action_seconds=86400), "wsweek": _a(_P, warn_action_seconds=7 * 86400),
})
