"""Server-side logic of the admin panel (phase 4.7a): opening buttons and handling every press.

Framework independent (no aiogram import). A press runs this fixed sequence, and ANY failure answers a refusal toast and
changes nothing (fail closed):
 1. structure   : `pn:<owner>:<screen>:<tag>` strictly parsed, else ignored (+ `forged_callback` audit when it claims our prefix)
 2. context     : the chat of the PRESSED message must be a group (never taken from the data), the presser a real person
 3. signature   : HMAC over (that group, owner, screen) must verify, else `forged_callback` audit
 4. owner       : the presser must be the panel's owner (another admin gets a toast, not a refresh: panels are personal)
 5. permission  : `MODERATE` for THAT group, evaluated now (a demoted admin loses the panel on the very next press)
 6. license     : the group's license must allow protection RIGHT NOW (expired/stopped/banned/unregistered/DB error => refuse)
 7. close       : `close` deletes the panel message (also when it has expired: it only cleans up)
 8. expiry      : the PRESSED message must be younger than `PANEL_TTL_SECONDS` (30 min). Older, from the future beyond
                  the clock-skew allowance, or with an unknown / naive date => the panel is replaced by an "expired" notice
                  without buttons and NOTHING else happens (4.7c, fail closed)
 9. action      : (6.4b) a REPORT screen (`panel.reports_screen`: list / one report / take / resolve / dismiss) is served by
                  `ReportsScreen` after every check above; only these screens carry a signed numeric argument;
                  otherwise `home` re-renders the read-only overview in place; a topic screen (welcome / verify / newbie, 4.7b;
                  protect, 4.7c) re-renders that topic from the stored values; the `trust` screen (4.7c) is READ ONLY
                  (the same lists as `/trusted`; entries need identities a fixed button cannot carry, so `/trust` stays the
                  only way to change them); an ACTION name changes one setting.
Reading needs no write, no claim and works in dry-run. A WRITE re-checks `MANAGE_SETTINGS` for that group (a MODERATOR
delegate may read but not change), claims `op:panel:<group>:<callback id>` (one press = one claim: a redelivered press never writes
twice), and goes through `MemberSettingsCommands` (welcome/verify/newbie) or `SettingsCommands` (protect) ->
`GroupSettingsService.update`: the SAME path as the commands, with the
SAME compare-with-effective-values, validation and audit (key names only). The value comes from `panel.actions.ACTIONS`
(server side), never from the button. Hiding buttons from a read-only admin is cosmetic: the server decides.
"""
from __future__ import annotations

import logging
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Callable

from ..audit import FORGED_CALLBACK, SecurityAudit, make_event, record_safely
from ..errors import PermissionDenied
from ..i18n import t
from ..idempotency import operation_key
from ..moderation.duration import format_duration
from ..permissions import Permission
from ..time_utils import utcnow
from . import codec
from .outcome import Buttons, PanelOutcome  # noqa: F401  (re-exported: tests and the handler import them from here)
from .actions import ACTIONS, TOPICS, TOPIC_NEWBIE, TOPIC_PROTECT, TOPIC_TRUST, TOPIC_VERIFY, TOPIC_WELCOME
from .report_actions import REPORT_SCREENS, RP_OPEN
from .reports_screen import ReportsScreen

log = logging.getLogger(__name__)

GROUP_CHAT_TYPES = ("group", "supergroup")
PANEL_TTL_SECONDS = 1800   # a panel works for 30 minutes after its message was SENT; then it must be reopened (4.7c)
_CLOCK_SKEW = timedelta(minutes=5)  # a message "from the future" beyond this is not trusted (fail closed)
_QUERY_ID = re.compile(r"[A-Za-z0-9_\-]{1,64}", re.ASCII)  # Telegram's callback query id (the idempotency anchor)


class PanelService:
    def __init__(self, *, permissions: Any, licenses: Any, commands: Any, audit: SecurityAudit | None, secret: str | bytes,
                 language: str = "ar", clock: Callable[[], datetime] = utcnow,
                 ttl_seconds: int | None = PANEL_TTL_SECONDS, reports: Any = None, claims: Any = None,
                 load_raw: Callable[[int], Any] | None = None, display_timezone: str = "Asia/Riyadh"):
        """`ttl_seconds=None` turns expiry off (tests of other behaviour only); production keeps the default.
        `reports` + `claims` + `load_raw` (the group's raw settings, for the approved report destination) switch the reports
        screen on (part 6.4b); without all three the screen does not exist: no button, and a pressed one is refused."""
        if ttl_seconds is not None and (isinstance(ttl_seconds, bool) or not isinstance(ttl_seconds, int) or ttl_seconds <= 0):
            raise ValueError("ttl_seconds must be a positive integer or None")
        self._ttl = None if ttl_seconds is None else timedelta(seconds=ttl_seconds)
        self._perm, self._licenses, self._commands, self._audit = permissions, licenses, commands, audit
        self._key = codec.derive_key(secret)
        self._language, self._clock = language, clock
        self._rp = (ReportsScreen(reports=reports, claims=claims, load_raw=load_raw, build=self._b,
                                  display_timezone=display_timezone)
                    if reports is not None and claims is not None and load_raw is not None else None)

    # ------------------------------------------------------------------ opening
    def _b(self, group_id: int, owner_id: int, screen: str, arg: int | None = None) -> str:
        return codec.build(self._key, group_id, owner_id, screen, arg)

    def home_buttons(self, group_id: int, owner_id: int, lang: str | None = None) -> Buttons:
        """Keyboard of the home screen, bound to `owner_id` in `group_id`. Raises ValueError for invalid ids."""
        lang = lang or self._language
        b = lambda screen: self._b(group_id, owner_id, screen)  # noqa: E731
        return (
            ((t("pn_btn_welcome", lang), b(TOPIC_WELCOME)), (t("pn_btn_verify", lang), b(TOPIC_VERIFY))),
            ((t("pn_btn_newbie", lang), b(TOPIC_NEWBIE)), (t("pn_btn_protect", lang), b(TOPIC_PROTECT))),
            ((t("pn_btn_trust", lang), b(TOPIC_TRUST)),
             *(((t("pn_btn_reports", lang), b(RP_OPEN)),) if self._rp is not None else ())),
            ((t("pn_btn_refresh", lang), b(codec.SCREEN_HOME)), (t("pn_btn_close", lang), b(codec.SCREEN_CLOSE))),
        )

    # ------------------------------------------------------------------ press
    async def press(self, group_id: object, chat_type: object, presser_id: object, data: object,
                    lang: str | None = None, query_id: object = None,
                    message_date: object = None) -> PanelOutcome | None:
        """None = not ours / not a well-formed panel callback (answer silently). `query_id` is Telegram's callback query
        id: only a WRITE needs it (idempotency); without a valid one a write is refused. `message_date` is when the
        PRESSED panel message was sent (Telegram's `message.date`): older than the TTL, from the future, or unknown =>
        the panel is expired (fail closed)."""
        lang = lang or self._language
        cb = codec.parse(data)
        actor = presser_id if isinstance(presser_id, int) and not isinstance(presser_id, bool) and presser_id > 0 else None
        group = group_id if isinstance(group_id, int) and not isinstance(group_id, bool) and group_id < 0 else None
        if cb is None:
            if isinstance(data, str) and data.startswith(codec.PREFIX + ":"):
                await record_safely(self._audit, make_event(FORGED_CALLBACK, actor=actor, group_id=group,
                                                            detail="malformed panel callback", now=self._clock()))
            return None
        if chat_type not in GROUP_CHAT_TYPES or group is None or actor is None:
            return None
        if not codec.verify(self._key, group, cb):
            await record_safely(self._audit, make_event(FORGED_CALLBACK, actor=actor, group_id=group,
                                                        detail="invalid panel signature", now=self._clock()))
            return PanelOutcome("forged", t("pn_invalid", lang), True)
        if actor != cb.owner_id:
            return PanelOutcome("not_owner", t("pn_not_owner", lang), True)
        try:
            decision = await self._perm.check(actor, group, Permission.MODERATE, context_chat_id=group, audit_denial=False)
        except Exception:
            log.error("panel permission check failed", extra={"group_id": group}, exc_info=True)
            return PanelOutcome("unavailable", t("pn_unavailable", lang), True)
        if not decision.allowed:
            return PanelOutcome("not_admin", t("pn_not_admin", lang), True)
        try:
            licensed = bool((await self._licenses.check(group, self._clock())).allowed)
        except Exception:
            log.error("panel license check failed", extra={"group_id": group}, exc_info=True)
            return PanelOutcome("unavailable", t("pn_unavailable", lang), True)
        if not licensed:
            return PanelOutcome("license_off", t("mod_license_off", lang), True)
        if cb.screen == codec.SCREEN_CLOSE:
            return PanelOutcome("closed", delete=True)  # closing works even on an expired panel (it only cleans up)
        if self._expired(message_date):
            return PanelOutcome("expired", t("pn_expired", lang), True, t("pn_expired", lang), None)
        if cb.screen in REPORT_SCREENS:
            if self._rp is None:
                return PanelOutcome("unavailable", t("pn_unavailable", lang), True)
            return await self._rp.handle(group, actor, cb.screen, cb.arg, query_id, lang)
        if cb.screen == TOPIC_TRUST:
            return await self._trust_screen(group, actor, lang)
        if cb.screen in TOPICS:
            return await self._topic(group, actor, cb.screen, lang)
        if cb.screen in ACTIONS:
            return await self._write(group, actor, cb.screen, query_id, lang)
        return await self._home(group, actor, lang)

    def _expired(self, sent_at: object) -> bool:
        """True when the panel message is too old / not trustworthy. Needs a timezone-aware datetime; anything else is
        treated as expired (never as fresh). Disabled only when the service was built with `ttl_seconds=None`."""
        if self._ttl is None:
            return False
        if not isinstance(sent_at, datetime) or sent_at.tzinfo is None or sent_at.utcoffset() is None:
            return True
        try:
            age = self._clock().astimezone(timezone.utc) - sent_at.astimezone(timezone.utc)
        except Exception:
            return True
        return age > self._ttl or age < -_CLOCK_SKEW

    async def _home(self, group: int, owner: int, lang: str) -> PanelOutcome:
        try:
            result = await self._commands.overview(group, lang)
        except Exception:
            log.error("panel overview failed", extra={"group_id": group}, exc_info=True)
            return PanelOutcome("unavailable", t("pn_unavailable", lang), True)
        if getattr(getattr(result, "kind", None), "value", None) != "info" or not getattr(result, "text", ""):
            return PanelOutcome("unavailable", t("pn_unavailable", lang), True)
        return PanelOutcome("home", t("pn_refreshed", lang), False, result.text, self.home_buttons(group, owner, lang))

    # ------------------------------------------------------------------ 4.7b: topic screens and writes
    async def _can_manage(self, group: int, actor: int) -> bool:
        try:
            return bool((await self._perm.check(actor, group, Permission.MANAGE_SETTINGS, context_chat_id=group,
                                                audit_denial=False)).allowed)
        except Exception:
            log.error("panel manage check failed", extra={"group_id": group}, exc_info=True)
            return False  # cosmetic only (read-only view); a write re-checks on the server

    async def _topic(self, group: int, owner: int, topic: str, lang: str, *, can_manage: bool | None = None,
                     status: str = "topic", toast: str = "", notes: str = "") -> PanelOutcome:
        try:
            text, cfg = await self._commands.panel_topic(topic, group, lang)
        except Exception:
            log.error("panel topic unreadable", extra={"group_id": group, "topic": topic}, exc_info=True)
            return PanelOutcome("unavailable", t("pn_unavailable", lang), True)
        if can_manage is None:
            can_manage = await self._can_manage(group, owner)
        parts = [f"<b>{t('pn_btn_' + topic, lang)}</b>", text]
        if topic == TOPIC_WELCOME and getattr(cfg, "welcome_text", None):
            parts.append(t("ms_welcome_text_show", lang, text=cfg.welcome_text))
        if topic == TOPIC_PROTECT:
            parts.append(t("pn_protect_hint", lang))
        if notes:
            parts.append(notes)
        if not can_manage:
            parts.append(t("pn_readonly", lang))
        rows = list(self._topic_rows(group, owner, topic, cfg, lang)) if can_manage else []
        nav = ((t("pn_btn_back", lang), self._b(group, owner, codec.SCREEN_HOME)),
               (t("pn_btn_close", lang), self._b(group, owner, codec.SCREEN_CLOSE)))
        return PanelOutcome(status, toast, False, "\n".join(parts), (*rows, nav))

    async def _trust_screen(self, group: int, owner: int, lang: str) -> PanelOutcome:
        """Read-only: the same lists as `/trusted`. No write button exists (see `panel.actions`); needs only MODERATE."""
        try:
            text, _ = await self._commands.panel_topic(TOPIC_TRUST, group, lang)
        except Exception:
            log.error("panel trust lists unreadable", extra={"group_id": group}, exc_info=True)
            return PanelOutcome("unavailable", t("pn_unavailable", lang), True)
        nav = ((t("pn_btn_back", lang), self._b(group, owner, codec.SCREEN_HOME)),
               (t("pn_btn_close", lang), self._b(group, owner, codec.SCREEN_CLOSE)))
        return PanelOutcome("topic", "", False, "\n".join([f"<b>{t('pn_btn_trust', lang)}</b>", text, t("pn_trust_hint", lang)]),
                            (nav,))

    async def _write(self, group: int, actor: int, action: str, query_id: object, lang: str) -> PanelOutcome:
        spec = ACTIONS[action]
        if not isinstance(query_id, str) or not _QUERY_ID.fullmatch(query_id):
            return PanelOutcome("unavailable", t("pn_unavailable", lang), True)  # no idempotency anchor => no write
        try:
            allowed = bool((await self._perm.check(actor, group, Permission.MANAGE_SETTINGS, context_chat_id=group,
                                                   audit_denial=False)).allowed)
        except Exception:
            log.error("panel manage check failed", extra={"group_id": group}, exc_info=True)
            return PanelOutcome("unavailable", t("pn_unavailable", lang), True)
        if not allowed:
            return PanelOutcome("not_manager", t("pn_not_manager", lang), True)
        try:
            result = await self._commands.panel_write(spec.topic, dict(spec.patch), group, actor,
                                                      operation_key("panel", group, query_id), lang)
        except PermissionDenied:
            return PanelOutcome("not_manager", t("pn_not_manager", lang), True)
        except Exception:
            log.error("panel write failed", extra={"group_id": group, "action": action}, exc_info=True)
            return PanelOutcome("unavailable", t("pn_unavailable", lang), True)
        kind = getattr(getattr(result, "kind", None), "value", None)
        if kind == "duplicate":
            return PanelOutcome("duplicate")  # a redelivered press: nothing changes, nothing shown
        if kind == "done":
            return await self._topic(group, actor, spec.topic, lang, can_manage=True, status="saved",
                                     toast=t("pn_saved", lang), notes=getattr(result, "text", "") or "")
        if kind == "noop":  # stale button: show the fresh values
            return await self._topic(group, actor, spec.topic, lang, can_manage=True, status="noop",
                                     toast=t("pn_nochange", lang))
        return PanelOutcome("unavailable", t("pn_unavailable", lang), True)

    def _topic_rows(self, group: int, owner: int, topic: str, cfg, lang: str) -> Buttons:
        b = lambda action: self._b(group, owner, action)  # noqa: E731

        def pick(label_key: str, action: str, on: bool) -> tuple[str, str]:
            return (("✅ " if on else "") + t(label_key, lang), b(action))

        def dur(prefix: str, seconds: int, action: str, on: bool) -> tuple[str, str]:
            return (("✅ " if on else "") + f"{prefix} {format_duration(seconds, lang)}", b(action))

        def toggle(label_key: str, on: bool, on_action: str, off_action: str) -> tuple[tuple[str, str], ...]:
            state = t("cfg_on" if on else "cfg_off", lang)
            return ((t(label_key, lang, state=state), b(off_action if on else on_action)),)

        if topic == TOPIC_WELCOME:
            after = cfg.welcome_delete_after_seconds
            rows = [toggle("pn_b_welcome", cfg.welcome_enabled, "welon", "weloff"),
                    toggle("pn_b_wprev", cfg.welcome_delete_previous, "welpon", "welpoff"),
                    (pick("pn_b_wkeep", "weldoff", after == 0), dur("🕒", 60, "weldmin", after == 60),
                     dur("🕒", 3600, "weldhour", after == 3600)),
                    (pick("pn_b_jkeep", "weljkeep", cfg.join_service == "keep"),
                     pick("pn_b_jdel", "weljdel", cfg.join_service == "delete")),
                    (pick("pn_b_lkeep", "wellkeep", cfg.leave_service == "keep"),
                     pick("pn_b_ldel", "welldel", cfg.leave_service == "delete"))]
            if cfg.welcome_text is not None:
                rows.append(((t("pn_b_wreset", lang), b("welreset")),))
            return tuple(rows)
        if topic == TOPIC_VERIFY:
            m, f = cfg.verify_method, cfg.verify_failure
            rows = [toggle("pn_b_verify", cfg.verify_enabled, "veron", "veroff"),
                    (pick("pn_b_sall", "verall", cfg.verify_scope == "all"),
                     pick("pn_b_ssusp", "versusp", cfg.verify_scope == "suspicious")),
                    (pick("pn_b_mbutton", "vmbutton", m == "button"), pick("pn_b_mmath", "vmmath", m == "math")),
                    (pick("pn_b_mchoice", "vmchoice", m == "choice"), pick("pn_b_madmin", "vmadmin", m == "admin")),
                    tuple(dur("⏱", sec, act, cfg.verify_timeout_seconds == sec)
                          for sec, act in ((60, "vtone"), (300, "vtfive"), (3600, "vthour"))),
                    (pick("pn_b_frestr", "vfrestr", f == "restrict"), pick("pn_b_fkick", "vfkick", f == "kick"),
                     pick("pn_b_fban", "vfban", f == "ban")),
                    tuple((("✅ " if cfg.verify_max_attempts == n else "") + f"🔁 {n}", b(act))
                          for n, act in ((1, "vaone"), (3, "vathree"), (5, "vafive")))]
            if f == "ban":
                rows.append(tuple(dur("⛔", sec, act, cfg.verify_ban_seconds == sec)
                                  for sec, act in ((3600, "vbhour"), (86400, "vbday"))))
            return tuple(rows)
        if topic == TOPIC_PROTECT:
            a = cfg.warn_action
            num = lambda icon, n, action, on: (("✅ " if on else "") + f"{icon} {n}", b(action))  # noqa: E731
            rows = [toggle("pn_b_links", cfg.links_enabled, "lkon", "lkoff"),
                    toggle("pn_b_invites", cfg.links_allow_invites, "invon", "invoff"),
                    toggle("pn_b_flood", cfg.flood_enabled, "floon", "flooff"),
                    tuple(num("💬", n, act, cfg.flood_max_messages == n)
                          for n, act in ((4, "fmfour"), (6, "fmsix"), (10, "fmten"))),
                    toggle("pn_b_dup", cfg.duplicate_enabled, "dupon", "dupoff"),
                    (pick("pn_b_slwoff", "slwoff", cfg.slowmode_seconds == 0),
                     *(dur("🐢", sec, act, cfg.slowmode_seconds == sec)
                       for sec, act in ((10, "slwten"), (30, "slwhalf"), (60, "slwmin")))),
                    tuple(num("⚠", n, act, cfg.warn_limit == n) for n, act in ((2, "wltwo"), (3, "wlthree"), (5, "wlfive"))),
                    (pick("pn_b_wamute", "wamute", a == "mute"), pick("pn_b_wakick", "wakick", a == "kick"),
                     pick("pn_b_waban", "waban", a == "ban"))]
            if a != "kick":   # the length only matters for mute / ban
                rows.append((pick("pn_b_wsforev", "wsforev", cfg.warn_action_seconds == 0),
                             *(dur("⏳", sec, act, cfg.warn_action_seconds == sec)
                               for sec, act in ((3600, "wshour"), (86400, "wsday"), (7 * 86400, "wsweek")))))
            return tuple(rows)
        w = cfg.newbie_seconds  # TOPIC_NEWBIE
        return (
            (pick("pn_b_nwoff", "nwoff", w == 0), dur("🆕", 3600, "nwhour", w == 3600)),
            (dur("🆕", 86400, "nwday", w == 86400), dur("🆕", 7 * 86400, "nwweek", w == 7 * 86400)),
            toggle("pn_b_nlinks", cfg.newbie_block_links, "nlon", "nloff"),
            toggle("pn_b_nmedia", cfg.newbie_block_media, "nmon", "nmoff"),
            toggle("pn_b_nmsgs", cfg.newbie_block_messages, "nson", "nsoff"),
        )
