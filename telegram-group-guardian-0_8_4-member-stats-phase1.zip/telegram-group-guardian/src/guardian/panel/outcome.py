"""The value a panel press returns to the aiogram layer (kept apart so screens can build it without importing the service)."""
from __future__ import annotations

from dataclasses import dataclass

Buttons = tuple[tuple[tuple[str, str], ...], ...]  # rows of (label, callback_data)


@dataclass(frozen=True, slots=True)
class PanelOutcome:
    """What the aiogram layer must do. `toast` is shown with `callback.answer`; `text`+`buttons` replace the panel message
    in place; `delete` removes it. `status` is a stable code (tests, logs)."""
    status: str
    toast: str = ""
    alert: bool = False
    text: str | None = None
    buttons: Buttons | None = None
    delete: bool = False
