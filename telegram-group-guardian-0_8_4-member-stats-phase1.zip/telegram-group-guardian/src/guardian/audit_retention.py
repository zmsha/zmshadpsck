"""Security audit retention (phase 6, part 6.2).

* Only `security_audit_log` is ever purged. `license_audit_log` (the proof of every license change) is NEVER deleted: this
  module does not reference it and migration 0007 does not touch its trigger.
* The delete goes through ONE explicit path: the SQL function `guardian_purge_security_audit` (migration 0007), which
  enforces a 30-day floor itself and lifts the append-only guard for a single transaction. UPDATE stays forbidden.
* No scheduler (Render sleeps): `tick()` rides on incoming updates (like the verification sweeper), is throttled, never
  raises and never runs two purges at once. After a sleep the first update catches up, in bounded batches.
* A purge that removed rows leaves one `audit_purged` event (count + cutoff date only).
"""
from __future__ import annotations

import logging
import time
from datetime import datetime, timedelta
from typing import Any, Callable

from .audit import AUDIT_PURGED, RESULT_APPLIED, make_event, record_safely
from .config import RETENTION_DEFAULT_DAYS, RETENTION_MAX_DAYS, RETENTION_MIN_DAYS
from .time_utils import utcnow

log = logging.getLogger(__name__)

PURGE_INTERVAL = 6 * 3600   # seconds between throttled runs (monotonic clock)
BATCH_SIZE = 1000           # rows per SQL call (the SQL function caps it at 10000)
MAX_BATCHES = 5             # per run: a huge backlog is worked off over several runs, never in one long block


class AuditRetentionService:
    def __init__(self, audit: Any, retention_days: int = RETENTION_DEFAULT_DAYS, *,
                 clock: Callable[[], datetime] = utcnow, mono: Callable[[], float] = time.monotonic):
        if isinstance(retention_days, bool) or not isinstance(retention_days, int) \
                or not RETENTION_MIN_DAYS <= retention_days <= RETENTION_MAX_DAYS:
            raise ValueError(f"retention_days must be an integer between {RETENTION_MIN_DAYS} and {RETENTION_MAX_DAYS}")
        self._audit, self._days, self._clock, self._mono = audit, retention_days, clock, mono
        self._last_run: float | None = None
        self._running = False

    @property
    def retention_days(self) -> int:
        return self._days

    def cutoff(self) -> datetime:
        return self._clock() - timedelta(days=self._days)

    async def purge(self) -> int:
        """Delete expired security-audit rows (bounded). Returns the number deleted. May raise on a store error."""
        cutoff = self.cutoff()
        total = 0
        for _ in range(MAX_BATCHES):
            deleted = await self._audit.purge_before(cutoff, BATCH_SIZE)
            total += deleted
            if deleted < BATCH_SIZE:
                break
        if total:
            await record_safely(self._audit, make_event(
                AUDIT_PURGED, now=self._clock(), result=RESULT_APPLIED,
                detail=f"count={total} before={cutoff.date().isoformat()} days={self._days}"))
        return total

    async def tick(self) -> int:
        """Throttled, never raises; the first call after startup (or a long sleep) runs immediately."""
        now = self._mono()
        if self._running or (self._last_run is not None and now - self._last_run < PURGE_INTERVAL):
            return 0
        self._last_run = now
        self._running = True
        try:
            return await self.purge()
        except Exception:
            log.error("audit retention purge failed", exc_info=True)
            return 0
        finally:
            self._running = False
