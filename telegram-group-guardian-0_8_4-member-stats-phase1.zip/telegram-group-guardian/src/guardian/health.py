"""Health payload. Deliberately tiny: no secrets, no hostnames, no versions of deps."""
from __future__ import annotations

DB_OK = "ok"
DB_UNAVAILABLE = "unavailable"
DB_UNKNOWN = "unknown"


def build_health(db_status: str) -> dict[str, str]:
    """`status` is 'ok' while the process is alive; `database` is the LAST KNOWN state.

    The endpoint never queries the database itself (a health probe must be cheap
    and must not depend on a slow/sleeping external DB).
    """
    if db_status not in (DB_OK, DB_UNAVAILABLE, DB_UNKNOWN):
        db_status = DB_UNKNOWN
    return {"status": "ok", "database": db_status}
