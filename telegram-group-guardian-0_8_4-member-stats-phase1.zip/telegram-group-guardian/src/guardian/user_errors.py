"""Map internal exceptions to SAFE, localized user messages (never exposes internals/secrets)."""
from __future__ import annotations

from .errors import (ConcurrentModification, GroupNotRegistered, InvalidInput, InvalidTransition,
                     PermissionDenied, StoreUnavailable, TelegramLookupFailed)
from .i18n import t

_KEYS: tuple[tuple[type[BaseException], str], ...] = (
    (PermissionDenied, "permission_denied"),
    (GroupNotRegistered, "group_not_registered"),
    (InvalidTransition, "invalid_transition"),
    (InvalidInput, "invalid_input"),
    (ConcurrentModification, "conflict_retry"),
    (StoreUnavailable, "action_failed_safe"),
    (TelegramLookupFailed, "bot_check_failed"),
)


def message_for(exc: BaseException, lang: str = "ar") -> str:
    for cls, key in _KEYS:
        if isinstance(exc, cls):
            return t(key, lang)
    return t("action_failed_safe", lang)  # unknown errors: generic, details only in logs
