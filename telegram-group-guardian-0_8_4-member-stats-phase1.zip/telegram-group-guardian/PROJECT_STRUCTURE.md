# بنية المشروع

```
.env.example            قيم وهمية فقط
render.yaml             Blueprint لخدمة Render Free (الأسرار sync:false)
pyproject.toml          إعداد pytest (pythonpath=src,tests)
requirements*.txt       الاعتماديات المثبّتة (غير متحقق منها بعد: انظر TEST_REPORT.md)
src/guardian/
  config.py             Settings + load_settings (تحقق صارم، لا قيم في الأخطاء)
  errors.py             استثناءات مركزية (+ المرحلة 2: PermissionDenied, GroupNotRegistered,
                        InvalidTransition, ConcurrentModification, InvalidInput, TelegramLookupFailed)
  logging_setup.py      تنقيح الأسرار من السجلات (redact / RedactingFormatter)
  time_utils.py         UTC دائمًا + عرض بالمنطقة المحلية
  auth.py               Authority: الأدوار العالمية من OWNER_TELEGRAM_ID فقط + حدود BIGINT + حسابات تيليجرام الخدمية
  protection/           [م3-ج2] links.py settings.py tracking.py engine.py: كشف المخالفات + حذف/كتم تصاعدي
                        [م3-ج3] offenses.py: OffenseLedger (التصعيد من moderation_sanctions) + KeyedLocks في tracking.py
  moderation/           [م3-ج3] models.py store.py memory_store.py postgres_store.py service.py: تحذيرات/عقوبات (WarningService, SanctionService)
  moderation/duration.py  [م3-ج4] محلل المدد   targets.py: محلل الهدف والتحقق   commands.py: الأوامر الثمانية + البدائل العربية   messages.py: رسائل الأخطاء
  moderation/executor.py  [م3-ج5] ModerationCommandService + MemberActions (Protocol) + CommandResult: تنفيذ الأوامر الثمانية (المحوّل الفعلي: bot/actions.py)
  moderation/message_commands.py [م3-امتداد2] MessageCommands: /pin /unpin /purge (نطاق معرّفات، تأكيد للكبير، حق المنفّذ في Telegram، dry-run، idempotency، تدقيق ids فقط)
  members/trust.py      [م4-ج2] مصفوفة ما يتجاوزه كل استثناء ثقة (المرجع الوحيد) + حدود القوائم
  members/service.py    [م4-ج2] BotTrustService (MANAGE_TRUST + تدقيق)
  members/newcomers.py   [م4-ج5] NewcomerTracker/Service: أوقات الانضمام لنافذة قيود الأعضاء الجدد (يفرضها المحرك)
  members/verification.py [م4-ج4] VerificationService: تحدّي الأعضاء الجدد (زر/حساب/رموز) + الانتهاء + الفشل (ترخيص + idempotency + callback محمي)
  members/welcome.py    [م4-ج3] WelcomeService: ترحيب بقالب موثّق + التحكم برسائل الانضمام/المغادرة (ترخيص + idempotency + حد معدل)
  bot/members_handler.py + bot/routers/members.py  [م4-ج3] محوّل رسائل الخدمة new_chat_members / left_chat_member
  panel/codec.py + panel/service.py                [م4-ج7أ/7ج] لوحة Inline: بيانات callback موقّعة + معالج الضغط (مالك/صلاحية/ترخيص/انتهاء 30 دقيقة)
  owner_panel/codec.py views.py service.py command.py [م5-ج3] لوحة المالك (قراءة): callback موقّع `ow:`، قائمة/تصفية/تفاصيل، فحص المالك في كل ضغطة، أمر `/owner`
  owner_panel/actions.py [م5-ج4] إجراءات الترخيص من اللوحة: جدول الإجراءات، الأزرار حسب الحالة، `OwnerActions` (حارس الحالة القديمة + مطالبة + `LicenseAdminService`)؛ الملف الوحيد في الحزمة الذي يغيّر شيئًا
  bot/owner_panel_handler.py + bot/routers/owner_panel.py [م5-ج3] محوّل رسائل الخاص و`callback_query` ببادئة ow:
  owner_hub/redactor.py sender.py reports.py mirror.py [م5-ج5] مركز `OWNER_GROUP_ID`: تنقيح الأسرار (نص/ملف)، مرسِل آمن بوجهة ثابتة، تقارير البدء والإحصائيات وتغيير الترخيص، نسخ رسائل المالك؛ يراقب فقط ولا يغيّر شيئًا
  owner_templates/templates.py store_pg.py overview.py apply.py defaults.py pending.py [م5-ج6/ج7]
  audit_retention.py [م6-ج2] الاحتفاظ بالسجل الأمني (تنظيف كسول مخنوق)؛ db/sql/0007_audit_retention.sql حارس + دالة حذف وحيدة
  reports/ [م6-ج3] مخزن البلاغات: models, store, memory_store, postgres_store, service؛ db/sql/0008_group_reports.sql
  reports/ [م6-ج4أ] أوامر الإدارة: args (محلل صارم)، commands (ReportCommands)، destination (الوجهة المعتمدة)
  panel/reports_screen.py report_actions.py outcome.py + reports/render.py [م6-ج4ب] شاشة البلاغات في `/panel`: وسيط callback موقَّع (رقم البلاغ/المؤشر)، قوائم وتفاصيل واستلام/حسم/رفض بنتيجة ثابتة، حجب المحتوى عند وجهة أخرى
  stats/ [م6-ج5أ] الإحصائيات: models (الفترات، المفردات، GroupStats)، store/memory_store/postgres_store (العدّادات)، counters (CounterRecorder)، service (StatsService)؛ db/sql/0009_daily_counters.sql
  export/ [م6-ج7أ+ب+ج] التصدير — مسار التسليم الخاص: models (ExportFile، DeliveryResult، الرموز)، delivery (ExportDelivery: خاص الطالب فقط، سقوف، screen_file، تأجير لكل عملية، تدقيق بلا محتوى)؛  مصدّر بعد (6.7ب و6.7ج) + (6.7ب) args، settings_export، license_export، command (`/export settings|license|reports|audit`) + (6.7ج) tabular (CSV/TXT، حقن الصيغ، ميزانية الحجم)، reports_export، audit_export
  backup/ [م6-ج8أ+ب+9أ+ب] النسخ الاحتياطي (9ب: restore — تنفيذ بمعاملة واحدة، postgres_restore — الكاتب الوحيد؛ 9أ: validate — تحقق نقي من الملف؛ preview — معاينة جافة وسياسة الاستعادة؛ postgres_state — قراءة SELECT فقط؛ restore_service/restore_command — `/restore` للمالك بلا كتابة؛ 8ب: delivery — تسليم لخاص المالك فقط بفحص تحقّق فقط وسقف 10MB؛ service — معاينة ورمز لمرة واحدة وتأكيد وتهدئة وتدقيق؛ command — `/backup`) — الصيغة والجامع: format (الصيغة v1، سجل `TABLES` بأعمدة صريحة و`EXCLUDED_TABLES`، JSON قانوني، المجاميع، `verify_integrity`)، collector (`BackupCollector`: صفحات، سقف 10MB بلا اقتطاع، فحص الأسرار، `BackupResult`)، postgres_reader (لقطة REPEATABLE READ للقراءة فقط)
  trace.py [م6-ج1] معرّف تتبع لكل تحديث (ContextVar) و`TraceMiddleware`؛ db/sql/0006_audit_trace.sql أعمدة target_id/result/trace_id
  owner_sandbox/sandbox.py service.py [م5-ج8] محاكاة معزولة: المحرّك الحقيقي بمُنفِّذ وهمي وساعة افتراضية؛ `owner_panel/sandbox_commands.py` (`/sandbox`) قوالب إعدادات المالك: الإعدادات الفعلية والتحقق والفروق والخدمة (معاينة فقط)، مخزن PostgreSQL، نظرة على مجموعة؛ `owner_panel/insight_views.py` و`template_commands.py`؛ هجرة `0005`
  bot/hub_transport.py [م5-ج5] محوّل aiogram رفيع للمرسِل
  bot/export_transport.py [م6-ج7أ] محوّل aiogram رفيع لمسار التصدير (الهدف دائمًا معرّف الطالب؛ يحوّل تعذّر الخاص إلى PrivateChatUnavailable)
  panel/actions.py                                 [م4-ج7ب/7ج] جدول الإجراءات الثابت (زر = إعداد واحد؛ القيمة على الخادم) + شاشات الترحيب/التحقق/الأعضاء الجدد/الحماية (والثقة للقراءة فقط)
  bot/panel_handler.py + bot/routers/panel.py      [م4-ج7أ] محوّل callback_query ببادئة pn: (تعديل في المكان/حذف/toast)
  moderation/trust_args.py trust_commands.py [م4-ج2] /trust /untrust /trusted
  moderation/member_args.py member_commands.py [م4-ج6] /welcome /verify /newbie /settings
  members/              [م4-ج1] models.py settings.py (ترحيب/تحقق/أعضاء جدد) store.py memory_store.py postgres_store.py: الأساس (النماذج والإعدادات والمخازن)؛ الخدمات في الأسطر أعلاه
  db/sql/0004_members_welcome_verification.sql [م4-ج1] group_trusted_bots, member_verifications
  moderation/info_commands.py [م3-امتداد1] InfoCommands: /id /info /admins /report (عام/مشرفون، تحديد معدل صامت، تدقيق ids فقط)
  moderation/lock_commands.py [م3-امتداد3] LockCommands: /lock /unlock (get-modify-set لصلاحيات المجموعة، dry-run، idempotency، تدقيق chat_locked/chat_unlocked)
  moderation/settings_commands.py [م3-امتداد3] SettingsCommands: /slowmode /antiflood /protect (قراءة INFO، كتابة MANAGE_SETTINGS، قفل لكل مجموعة للقائمة المسموحة)
  moderation/config_args.py [م3-امتداد3] محللات وسائط أوامر الإعداد + alias_args_ok   command_error.py: CommandError   arabic.py: fold_arabic
  db/sql/0003_...       [م3-ج3] moderation_records: قيود/فهارس/أعمدة مستودعات الإشراف
  bot/moderation_handler.py [م3-ج7] منطق رسائل الإشراف بلا aiogram (مطابقة، رد، text_mention، تنفيذ، مراقبة)  routers/moderation.py: طبقة aiogram  commands_menu.py: قوائم الأوامر الرسمية
  moderation/usernames.py [م3-ج7] VisibleUsers (UsernameResolver في الذاكرة)  provider.py: LazyModerationCommands
  bot/actions.py        [م3-ج2/ج6/امتداد2] AiogramModerationActions: delete/mute للمحرك + MemberActions كاملًا (ban/unban/mute/unmute/kick) + pin/unpin/delete_messages بلا استثناءات
  protection_gate.py    [م3-ج1] ProtectionGate/ProtectionContext: قرار تشغيل الحماية (ترخيص + إعفاءات)
  bot/middlewares.py    [م3-ج1] ProtectionGateMiddleware (يحقن protection ولا يحجب)
  permissions.py        [م2] PermissionService: نقطة التفويض الوحيدة (Permission, ActorLevel, مصفوفة الأدوار)
  telegram_rights.py    [م2] ChatMemberInfo, BotCapability, check_bot_capabilities (صلاحيات البوت نفسه)
  audit.py              [م2] التدقيق الأمني: SecurityEvent, sanitize_text, register_secrets, مخزنا الذاكرة/Postgres
  audit_service.py      [م2] AuditQueryService: قراءة التدقيق للمالك فقط (VIEW_AUDIT) لمجموعة واحدة
  idempotency.py        [م2] claim(key) مرة واحدة (update:<id> / op:<scope>:...) + purge
  user_errors.py        [م2] استثناء داخلي -> رسالة آمنة ar/en
  i18n.py               رسائل عربي/إنجليزي، اختيار اللغة، تهريب HTML
  health.py             حمولة /health (لا تلمس قاعدة البيانات)
  webhook.py            فحص السر + منع تكرار update_id (في الذاكرة)
  membership.py         منطق إضافة البوت لمجموعة (مستقل عن aiogram)
  services.py           حاوية الاعتماديات المحقونة في المعالجات (+ خدمات المرحلة 2)
  app.py                FastAPI: /health, /telegram/webhook (+ dedup دائم), startup/shutdown
  __main__.py           python -m guardian check-config | migrate | serve
  licensing/
    models.py           LicenseStatus (7 حالات), GroupLicense, evaluate(), AuditEvent
    store.py            عقد LicenseStore (+ audit_for_group)
    memory_store.py     تنفيذ مرجعي للاختبارات فقط
    postgres_store.py   get + register_pending + transition (CAS + تدقيق في معاملة واحدة) + audit_for_group
    service.py          LicenseService: check/status_report (fail-closed), on_bot_added, انتهاء تلقائي
    admin.py            [م2] LicenseAdminService: أفعال المالك (مصفوفة الانتقالات، idempotent)
    callbacks.py        [م2] ترميز callback صارم + handle_license_callback (تحقق خادم)
  groups/               [م2] بيانات المجموعة المعزولة بـ group_id
    models.py           GroupRole, Delegation, TrustedUser, GroupSettings
    store.py            عقود DelegationStore / TrustStore / SettingsStore
    memory_store.py     تنفيذ للاختبارات فقط
    postgres_store.py   تنفيذ PostgreSQL (كل استعلام مقيّد بـ group_id)
    service.py          DelegationService, TrustService, GroupSettingsService (كلها تفوّض عبر PermissionService)
  db/
    pool.py             Database: pool كسول، cooldown، حالة آخر اتصال معروفة
    migrations.py       مشغّل migrations (checksum + advisory lock)
    sql/0001_initial.sql        المخطط الأولي (لا يُعدَّل)
    sql/0002_security_and_access.sql   [م2] قيود، تدقيق append-only (triggers)، جداول المرحلة 2
  bot/
    factory.py          create_bot / create_dispatcher (webhook فقط)
    notifier.py         TelegramNotifier (إشعارات best-effort)
    chat_info.py        [م2] AiogramChatInfo: getChatMember + cache قصير + إعادة محاولة محدودة
    routers/basic.py    /start /help /status
    routers/membership.py   my_chat_member -> تسجيل pending
    routers/errors.py   معالج أخطاء مركزي برمز تتبع
tests/                  535 اختبارًا (stdlib unittest، متوافقة مع pytest؛ 530 نجح و5 متخطاة) + stack.py (تركيب الخدمات في الذاكرة)
                        test_phase2_hardening.py (25): عيوب وُجدت أثناء مراجعة المرحلة 2 وأُصلحت
                        test_phase3_final_handoff.py (13) [م3-ج8]: اختبار التسليم الخاص عبر السلسلة الحقيقية (بوابة ← middleware+محرك ← معالج ← خدمة الأوامر) لكل حالات الترخيص
                        test_phase3_complete_handoff.py (11) [م3-إغلاق]: الأوامر الـ20 عربي/إنجليزي عبر السلسلة الحقيقية لكل حالات الترخيص المحجوبة
                        test_phase4_final_handoff.py (15) [م4-ج8]: اختبار التسليم الخاص للمرحلة 4 (ترحيب/تحقق/أعضاء جدد/لوحة) عبر السلسلة الحقيقية لكل حالات الترخيص المحجوبة، وفقدان الترخيص بعد إنشاء تحدٍّ، وإعادة إضافة البوت، وبوابة الخدمات
                        test_audit_retention.py (29) [م6-ج2]: الاحتفاظ، الهجرة 0007، تدقيق الأوامر المرفوضة/فك العقوبة/فشل التسجيل
                        test_stats.py (33) [م6-ج5أ]: الفترات والعدّادات والخدمة والخطّافات وPostgreSQL والهجرة 0009
                        test_reports.py (39) [م6-ج3]: مخزن البلاغات والخدمة وآلة الحالات والهجرة 0008 وربط /report
                        test_audit_trace.py (22) [م6-ج1]: معرّف التتبع، target_id/result، المخزنان، هجرة 0006
                        test_phase5_final_handoff.py (34) [م5-ج9]: اختبار التسليم الخاص للمرحلة 5: لا صلاحية مالك لغير المالك (لوحة/قوالب/افتراضيات/sandbox/أوامر التفعيل)، فحص طفرات آلي لـcallbacks `ow:*`، لا إرسال حقيقي من dry-run/sandbox، فشل `OWNER_GROUP_ID` لا يوقف الحماية، حراس ثابتة واتساق الوثائق
                        test_config_args.py (24) test_lock_commands.py (21) test_settings_commands.py (19) test_slowmode_engine.py (20) test_phase3_ext3_gate.py (3) [م3-امتداد3]
                         test_panel_reports.py (41) [م6-ج4ب]: ترميز الوسيط الموقَّع وشاشة البلاغات وبوابات اللوحة والوجهة المعتمدة
```
قاعدة التصميم: المنطق في وحدات نقية قابلة للاختبار دون إطار عمل؛ ملفات `bot/` و`app.py` رقيقة.
قاعدة الأمان: كل إجراء حساس يمرّ عبر `PermissionService.require(...)` (المستخدم من تحديث تيليجرام لا من نص/callback).
- `tests/test_phase6_security.py` — 6.10أ: اختبارات أمان المرحلة 6

## المرحلة 7.3
- `docs/DEPLOY_RENDER.md` — دليل النشر على Render خطوة بخطوة (مقارنة PostgreSQL، المتغيرات، webhook، حدود Render Free).
- `docs/LOCAL_VERIFY.md` — أوامر التحقق المحلي التي يشغّلها المالك.
- `tests/test_phase7_docs.py` — اختبار نصي يطابق الوثائق مع `.env.example` و`render.yaml` و`config.py`.
- `tests/test_phase8_gaps.py` — حراس مصدرية (AST) لمسارات أخطاء الـwebhook والمعالج المركزي للأخطاء، وحارس يمنع `docs/TEST_MATRIX.md` من تسمية اختبار غير موجود.
- `tests/test_phase8_security.py` — حراس 8.2 الآلية (أسرار، مالك، callbacks، SQL/`group_id`، ترتيب claim، اعتماديات، هجرات، شيفرة وهمية) + حق المنفّذ في أوامر العقوبات.
- `tests/test_phase8_welcome_after_verify.py` — الترحيب بعد نجاح التحقق فقط (8.2).
- `tests/test_phase8_final.py` — اتساق التسليم النهائي (8.4): `FINAL_REPORT.md` (الأقسام، الصدق، تطابق الأرقام مع الاختبارات الفعلية، الملفات المسمّاة، ترتيب خطوات المالك)، إيجاز `HANDOFF.md` وبقاء الأرشيف، اكتمال الملفات المطلوبة وتتابع الهجرات، وعدد المتخطاة في `docs/LOCAL_VERIFY.md`.
- `docs/TEST_MATRIX.md` — فهرس الاختبارات الإلزامية للترخيص وفئات التغطية، وما تعذّر تشغيله وسببه.
- `docs/HANDOFF_HISTORY.md` — أرشيف `HANDOFF.md` الطويل كما كان حتى 0.8.3 (محفوظ دون حذف)؛ و`FINAL_REPORT.md` (في الجذر) هو التقرير الختامي.

```
src/guardian/member_stats/  إحصائيات الأعضاء الدائمة: models, store, memory_store, postgres_store, recorder, tracking, commands, service
src/guardian/db/sql/0013_member_activity_stats.sql
```
