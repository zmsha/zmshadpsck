"""Part 6.10a: the SECURITY CLOSURE of phase 6. TESTS ONLY: no production code was changed for this part.

It looks at the whole phase from the outside (the way an attacker or a failure would) rather than one unit at a time:

 1. LICENCE GATE   every group surface of phase 6 (`/stats`, `/export ...`, `/reports ...`, the periodic reports) is refused while
                   the licence is not active, and nothing is read, claimed or sent on the way.
 2. WHO            `/backup` and `/restore` (and the owner's all-groups `/stats`) answer ONLY the primary owner, ONLY in his private
                   chat; everybody else gets silence and nothing is collected, downloaded, written or consumed. Every file
                   leaves to the requester's own private chat, never to a group.
 3. SECRET SCAN    every output (exports, backup file, restore preview, stats and periodic reports, command replies, audit rows)
                   is scanned for the configured secrets (plain, URL-quoted, JSON-escaped) and for token / URL-password shapes.
 4. CORRUPT FILES  truncated / flipped / re-signed / hostile backup files never reach a preview or a write; a backup tampered
                   with after it was built is never sent; a hostile export file is never sent.
 5. SEND FAILURE   every delivery path with a transport that fails (with the bot token inside the exception text), times out,
                   is cancelled or is a store that is down: closed codes, no leak, no fallback to another chat, at-most-once.

PostgreSQL / aiogram / Telegram are NOT exercised (fakes only), exactly like the parts it closes.
"""
from __future__ import annotations

import asyncio
import copy
import dataclasses
import inspect
import io
import json
import logging
import re
import unittest
from datetime import timedelta
from urllib.parse import quote

import helpers  # noqa: F401  (disables logging for expected-failure tests)
import restore_helpers as H
import test_backup_command as BK
import test_export_reports_audit as XR
import test_periodic_delivery as PD
import test_restore_apply as RA
import test_restore_preview as RP
from backup_helpers import FakeReader, sample_rows
from executor_stack import A, B, USER, gate
from guardian.audit import (BACKUP_DELIVERED, BACKUP_FAILED, EXPORT_DELIVERED, EXPORT_FAILED, RESTORE_APPLIED,
                            RESTORE_STARTED, InMemorySecurityAudit, SecurityEvent)
from guardian.backup import delivery as bd
from guardian.backup import format as F
from guardian.backup import restore_service as rsvc
from guardian.backup import service as bsvc
from guardian.backup import validate as V
from guardian.backup.collector import BackupCollector, BackupResult
from guardian.backup.format import TABLES, BackupError
from guardian.backup.restore_command import RestoreCommandService, parse_restore_command
from guardian.export import models as xm
from guardian.export.delivery import ExportDelivery
from guardian.export.models import ExportFile, PrivateChatUnavailable
from guardian.idempotency import InMemoryIdempotency
from guardian.licensing.models import AuditEvent, LicenseStatus
from guardian.logging_setup import RedactingFormatter, redact
from guardian.moderation.commands import Command
from guardian.moderation.executor import ResultKind as R
from guardian.permissions import OWNER_ONLY, Permission
from guardian.reports import ReportService
from guardian.reports.memory_store import InMemoryReportStore
from guardian.reports.models import ReportPriority, ReportType
from guardian.stats import Counter, CounterRecorder, ReportScheduleService, StatsPeriod, StatsService
from guardian.stats.memory_store import InMemoryCounterStore
from guardian.stats.owner_command import OwnerStatsService, match as stats_match
from guardian.stats.render import render, render_periodic
from guardian.stats.schedule_memory_store import InMemoryScheduleStore
from guardian.moderation.memory_store import InMemorySanctionStore, InMemoryWarningStore
from guardian.moderation.models import SanctionKind
from stack import BACKUP, NOW, OWNER, OWNER_GROUP, STRANGER, TG_ADMIN, TG_CREATOR, TG_LIMITED_ADMIN, Stack
from test_export_delivery import FakeTransport

TZ = "Asia/Riyadh"

# The secrets of a deployment (the same shapes as `helpers.VALID_ENV`; `Settings.secret_values()` yields exactly these).
SECRET_BOT = "123456789:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
SECRET_WEBHOOK = "unit-test-webhook-secret-123456"
DB_PASSWORD = "s3cretPW"
SECRET_DB = f"postgresql://dbuser:{DB_PASSWORD}@db.example.com:5432/guardian?sslmode=require"
SECRETS = (SECRET_BOT, SECRET_WEBHOOK, SECRET_DB, DB_PASSWORD)
PEM = "-----BEGIN PRIVATE KEY-----\nMIIBVQIBADANBgkqhkiG9w0BAQEFAASCAT8wggE7AgEAAkEA\n-----END PRIVATE KEY-----"
_FORMS = sorted({f for s in SECRETS for f in (s, quote(s, safe=""), json.dumps(s)[1:-1])}, key=len, reverse=True)


def leaks(blob: object) -> list[str]:
    """What of the deployment's secrets (any form) or a secret SHAPE (bot token, URL password, PEM) is inside `blob`."""
    text = bytes(blob).decode("utf-8", "replace") if isinstance(blob, (bytes, bytearray)) else str(blob)
    found = [f for f in _FORMS if f in text]
    if redact(text, ()) != text:
        found.append("<token-or-url-password shape>")
    if "BEGIN PRIVATE KEY" in text or "BEGIN RSA PRIVATE KEY" in text:
        found.append("<pem>")
    return found


def audit_leaks(audit: InMemorySecurityAudit) -> list[tuple[str, list[str]]]:
    return [(e.event_type, hit) for e in audit.events if (hit := leaks(repr(e)))]


class Spy:
    """Records every call (sync or async) made on the wrapped object; used to prove that NOTHING was touched."""

    def __init__(self, inner):
        object.__setattr__(self, "_inner", inner)
        object.__setattr__(self, "calls", [])

    def __getattr__(self, name):
        attr = getattr(self._inner, name)
        if not callable(attr):
            return attr
        if inspect.iscoroutinefunction(attr):
            async def acall(*a, **k):
                self.calls.append(name)
                return await attr(*a, **k)
            return acall

        def call(*a, **k):
            self.calls.append(name)
            return attr(*a, **k)
        return call


def run(coro):
    return asyncio.run(coro)


# =================================================================================================================
# 1. LICENCE GATE (group surfaces)
# =================================================================================================================
GROUP_COMMANDS = ("/stats", "/stats week", "/export settings", "/export license", "/export reports", "/export audit",
                  "/export audit txt", "/reports", "/reports schedule", "/reports schedule day on")


class GateBase(XR.Base):
    """The 6.7c stack (reports + real private delivery over a fake transport) plus stats and the schedule, every collaborator spied."""

    async def asyncSetUp(self):
        self.stats_spy = Spy(StatsService(display_timezone=TZ, clock=lambda: NOW))
        self.schedule_spy = Spy(ReportScheduleService(InMemoryScheduleStore(), InMemorySecurityAudit(), display_timezone=TZ,
                                                      clock=lambda: NOW))
        await super().asyncSetUp()

    def make_service(self, claims):
        self.claim_spy = Spy(claims)
        svc = super().make_service(self.claim_spy)
        self.reports_spy, self.licenses_spy, self.query_spy = Spy(self.reports), Spy(self.s.licenses), Spy(self.s.audit_query)
        svc._stats_cmds._stats = self.stats_spy
        svc._report_cmds._schedule = self.schedule_spy
        svc._export_cmds._reports, svc._export_cmds._licenses, svc._export_cmds._audit_query = (
            self.reports_spy, self.licenses_spy, self.query_spy)
        return svc

    def spies(self):
        return {"stats": self.stats_spy, "schedule": self.schedule_spy, "reports": self.reports_spy,
                "licenses": self.licenses_spy, "audit_query": self.query_spy, "claims": self.claim_spy}

    def assert_untouched(self, where=""):
        for name, spy in self.spies().items():
            self.assertEqual(spy.calls, [], f"{where}: {name} was touched")
        self.assertEqual(self.transport.sent, [], f"{where}: something was sent")


class LicenceGateTests(GateBase):
    async def test_every_group_surface_is_refused_while_the_licence_is_not_active(self):
        await self.file_reports(2)
        for text in GROUP_COMMANDS:
            for label, prot in (("inactive", gate(A, TG_ADMIN, allowed=False)), ("no context", None),
                                ("other chat's context", gate(B, TG_ADMIN, allowed=True))):
                with self.subTest(text=text, ctx=label):
                    res = await self.ex(text, protection=prot)
                    self.assertIs(res.kind, R.LICENSE_OFF)
                    self.assertEqual(leaks(res.text), [])
        self.assert_untouched("licence off")          # nothing read, nothing claimed, nothing sent

    async def test_the_same_commands_work_with_an_active_licence(self):
        """The control of the test above: the refusals are the licence's doing, not a broken fixture."""
        await self.file_reports(1)
        for text in ("/stats", "/export settings", "/export reports", "/export audit"):
            self.s.clock.advance(seconds=31)
            res = await self.ex(text)
            self.assertIs(res.kind, R.INFO if text == "/stats" else R.DONE, text)
        self.assertEqual(len(self.transport.sent), 3)
        self.assertTrue(self.stats_spy.calls)

    async def test_a_non_moderator_is_denied_before_anything_is_read_even_with_an_active_licence(self):
        for who in (STRANGER, USER):
            for text in GROUP_COMMANDS:
                with self.subTest(who=who, text=text):
                    res = await self.ex(text, actor=who, protection=gate(A, who, allowed=True))
                    self.assertIs(res.kind, R.DENIED)
                    self.assertEqual(leaks(res.text), [])
        self.assert_untouched("not a moderator")

    async def test_the_licence_log_is_for_the_primary_owner_only(self):
        for who in (TG_ADMIN, TG_CREATOR, BACKUP):
            self.s.clock.advance(seconds=31)
            res = await self.ex("/export license", actor=who, protection=gate(A, who, allowed=True))
            self.assertIs(res.kind, R.DENIED, who)
        self.assertEqual(self.transport.sent, [])
        self.assertEqual(self.licenses_spy.calls, [])
        self.assertEqual(self.query_spy.calls, [])
        self.s.clock.advance(seconds=31)
        res = await self.ex("/export license", actor=OWNER, protection=gate(A, OWNER, allowed=True))
        self.assertIs(res.kind, R.DONE)
        self.assertEqual([d[0] for d in self.transport.sent], [OWNER])

    async def test_every_file_goes_to_the_requesters_private_chat_and_never_to_a_group(self):
        await self.file_reports(1)
        sent_to = set()
        for who in (TG_ADMIN, TG_CREATOR):
            for text in ("/export settings", "/export reports", "/export reports txt", "/export audit", "/export audit txt"):
                self.s.clock.advance(seconds=31)
                res = await self.ex(text, actor=who, protection=gate(A, who, allowed=True))
                self.assertIs(res.kind, R.DONE, (who, text))
                self.assertEqual(self.transport.sent[-1][0], who)
                self.assertNotIn("@", res.text)
                sent_to.add(self.transport.sent[-1][0])
        self.assertEqual(sent_to, {TG_ADMIN, TG_CREATOR})
        self.assertFalse(sent_to & {A, B, OWNER_GROUP})
        self.assertTrue(all(d[0] > 0 for d in self.transport.sent))


class PeriodicLicenceGateTests(PD.Base):
    async def test_a_group_whose_licence_is_not_active_receives_no_periodic_report(self):
        await self.enable()
        for _ in range(6):
            self.assertFalse(self.delivery.on_update(self.bot, PD.GA, False))
            self.mono[0] += 10_000
        await asyncio.sleep(0)
        self.assertEqual((self.bot.sent, self.delivery._tasks), ([], set()))
        self.assertIsNone((await self.schedule.entries(PD.GA))[PD.DAY].last_period_key)   # still owed, nothing swallowed
        self.assertEqual(self.stats.ranges, [])                                           # not even read

    async def test_the_same_group_is_served_the_moment_the_licence_is_active(self):
        await self.enable()
        self.assertFalse(self.delivery.on_update(self.bot, PD.GA, False))
        self.assertTrue(self.delivery.on_update(self.bot, PD.GA, True))                   # the refusals did not use up the throttle
        await asyncio.gather(*list(self.delivery._tasks))
        self.assertEqual({c for c, _ in self.bot.sent}, {PD.GA})
        self.assertEqual(len(self.bot.sent), 3)

    async def test_the_hook_ignores_private_chats_and_a_missing_bot(self):
        await self.enable()
        for chat in (OWNER, 0, 12345, True, None, "-1001"):
            self.assertFalse(self.delivery.on_update(self.bot, chat, True), chat)
        self.assertFalse(self.delivery.on_update(None, PD.GA, True))
        self.assertEqual(self.bot.sent, [])


# =================================================================================================================
# 2. WHO MAY: the owner's private commands
# =================================================================================================================
INTRUDERS = (BACKUP, STRANGER, TG_ADMIN, TG_CREATOR, TG_LIMITED_ADMIN, 5, 1, 999_999_999)


class BackupOwnerOnlyTests(BK.Base):
    async def test_nobody_but_the_primary_owner_gets_an_answer_and_nothing_happens(self):
        reader = FakeReader()
        self.build(reader=reader, secrets=SECRETS)
        code = await self.preview_code()                          # a valid code, issued to the owner
        n = 100
        for who in INTRUDERS:
            for text in ("/backup", f"/backup confirm {code}", "/backup confirm ZZZZZZ", "/backup nonsense", "نسخة احتياطية",
                         f"تأكيد نسخة {code}"):
                n += 1
                self.assertIsNone(await self.go(text, user=who, mid=n), (who, text))
        self.assertEqual((self.transport.sent, reader.opened, reader.log), ([], 0, []))
        self.assertEqual(self.kinds().count("backup_requested"), 1)                 # only the owner's own preview
        self.assertNotIn(BACKUP_DELIVERED, self.kinds())
        out = await self.go(f"/backup confirm {code}", mid=999)                     # the code was NOT consumed by the intruders
        self.assertEqual(out.status, "sent")

    async def test_the_owner_himself_gets_nothing_outside_his_private_chat(self):
        reader = FakeReader()
        self.build(reader=reader)
        code = await self.preview_code()
        for chat, kind in ((-100500, "supergroup"), (-100500, "group"), (OWNER_GROUP, "supergroup"), (OWNER + 1, "private"),
                           (0, "private"), (OWNER, "channel"), (OWNER, "supergroup")):
            for text in ("/backup", f"/backup confirm {code}", "/backup nonsense"):
                self.assertIsNone(await self.go(text, chat=chat, chat_type=kind, mid=hash((chat, kind, text)) % 10_000 + 1), (chat, kind, text))
        self.assertEqual((self.transport.sent, reader.opened), ([], 0))

    async def test_the_file_goes_to_the_owners_private_chat_even_when_no_group_has_a_licence(self):
        self.build(secrets=SECRETS)
        code = await self.preview_code()
        out = await self.go(f"/backup confirm {code}")
        self.assertEqual(out.status, "sent")
        self.assertEqual([d[0] for d in self.transport.sent], [OWNER])
        self.assertFalse({d[0] for d in self.transport.sent} & {OWNER_GROUP, A, B})
        self.assertEqual(leaks(out.text), [])
        self.assertEqual(audit_leaks(self.audit), [])

    async def test_a_forbidden_or_invalid_destination_is_never_sent_to(self):
        self.build()
        delivery = bd.BackupDelivery(self.transport, claims=self.claims, audit=self.audit, forbidden_chat_ids=(OWNER_GROUP, OWNER))
        result = await self.collector.collect()
        for dest in (OWNER_GROUP, OWNER, -1, 0, True, "123", None, 1.5, 10 ** 30 * -1):
            with self.subTest(dest=dest):
                self.assertEqual((await delivery.deliver(dest, result, key=1)).code, bd.INVALID)
        self.assertEqual(self.transport.sent, [])


class RestoreOwnerOnlyTests(RA.ConfirmBase):
    def texts(self, a, b):
        return ("/restore", "/restore nonsense", f"/restore confirm {a}", f"/restore confirm {a} with_license {b}",
                "استعادة نسخة", f"استعادة نسخة تأكيد {a}")

    async def test_nobody_but_the_primary_owner_gets_an_answer_and_nothing_is_touched(self):
        self.setup_confirm()
        _, (a, b) = await self.preview()
        calls_before, state_before = len(self.downloader.calls), self.reader.calls
        committed, pending_before, kinds_before = self.db.committed, len(self.pending), list(self.kinds())
        n = 100
        for who in INTRUDERS:
            for text in self.texts(a, b):
                n += 1
                self.assertIsNone(await self.go(text, user=who, mid=n), (who, text))
        self.assertEqual(len(self.downloader.calls), calls_before)          # no file was downloaded for them
        self.assertEqual(self.reader.calls, state_before)                   # the database was not even read
        self.assertEqual((self.db.committed, self.db.rolled_back), (committed, 0))
        self.assertEqual(len(self.pending), pending_before)                 # their guesses consumed nothing
        self.assertEqual([k for k in self.kinds() if k != "permission_denied"], kinds_before)   # refusals are audited, nothing else is
        self.assertTrue(all(a not in repr(e) and b not in repr(e) for e in self.audit.events))  # ...and never with a guessed/real code
        out = await self.confirm(f"/restore confirm {a}", mid=999)          # the owner's code still works
        self.assertEqual(out.status, "applied")

    async def test_the_owner_himself_gets_nothing_outside_his_private_chat(self):
        self.setup_confirm()
        _, (a, b) = await self.preview()
        calls_before = len(self.downloader.calls)
        n = 200
        for chat, kind in ((-100500, "supergroup"), (OWNER_GROUP, "supergroup"), (OWNER + 1, "private"), (OWNER, "channel")):
            for text in self.texts(a, b):
                n += 1
                self.assertIsNone(await self.go(text, chat=chat, chat_type=kind, mid=n), (chat, kind, text))
        self.assertEqual((len(self.downloader.calls), self.db.committed, len(self.pending)), (calls_before, 0, 2))


class OwnerStatsOnlyTests(unittest.IsolatedAsyncioTestCase):
    class Panel:
        def __init__(self):
            self.calls = 0

        async def group_ids(self, user_id, limit):
            self.calls += 1
            return [A, B], False

    async def asyncSetUp(self):
        self.stack = Stack()
        self.panel = self.Panel()
        self.stats = Spy(StatsService(display_timezone=TZ, clock=lambda: NOW))
        self.svc = OwnerStatsService(stats=self.stats, owner_panel=self.panel, permissions=self.stack.perm)

    async def go(self, who, text="/stats", chat=None, kind="private"):
        parsed = stats_match(text, "GuardBot")
        self.assertIsNotNone(parsed, text)
        return await self.svc.run(parsed, chat_id=who if chat is None else chat, chat_type=kind, user_id=who)

    async def test_only_the_primary_owner_in_private_gets_the_all_groups_numbers(self):
        for who in INTRUDERS:
            for text in ("/stats", "/stats week", "/stats junk"):
                self.assertIsNone(await self.go(who, text), (who, text))
        for chat, kind in ((-100500, "supergroup"), (OWNER + 1, "private"), (OWNER, "group")):
            self.assertIsNone(await self.go(OWNER, chat=chat, kind=kind))
        self.assertEqual((self.panel.calls, self.stats.calls), (0, []))        # the group list was never even read
        reply = await self.go(OWNER)
        self.assertEqual(reply.status, "ok")
        self.assertEqual(self.panel.calls, 1)
        self.assertEqual(leaks(reply.text), [])


class PermissionRegistryTests(unittest.IsolatedAsyncioTestCase):
    def test_the_owner_permissions_are_owner_only(self):
        for perm in (Permission.BACKUP, Permission.RESTORE, Permission.OWNER_PANEL, Permission.VIEW_AUDIT):
            self.assertIn(perm, OWNER_ONLY, perm)

    async def test_the_backup_owner_and_every_group_role_are_refused_for_each_of_them(self):
        s = Stack()
        await s.register(A)
        for who in (BACKUP, STRANGER, TG_ADMIN, TG_CREATOR):
            for perm in (Permission.BACKUP, Permission.RESTORE, Permission.OWNER_PANEL):
                self.assertFalse((await s.perm.check_global(who, perm)).allowed, (who, perm))
        for perm in (Permission.BACKUP, Permission.RESTORE, Permission.OWNER_PANEL):
            self.assertTrue((await s.perm.check_global(OWNER, perm)).allowed, perm)

    def test_a_group_can_not_type_backup_or_restore(self):
        self.assertEqual([c for c in Command if re.search(r"backup|restore", c.value)], [])


# =================================================================================================================
# 3. SECRET SCAN of every output
# =================================================================================================================
class SecretAwareDelivery:
    """Mixin for `XR.Base`: the export delivery is built with the deployment's secrets, as `app.py` does with `settings.secret_values()`."""

    def make_service(self, claims):
        svc = super().make_service(claims)
        self.delivery = ExportDelivery(self.transport, claims=claims, audit=self.s.audit, secrets=SECRETS, clock=self.s.clock)
        svc._export_cmds._delivery = self.delivery
        return svc


class ExportSecretScanTests(SecretAwareDelivery, XR.Base):
    """Hostile data in every place an export reads from; whatever leaves (file, name, caption, reply, audit rows) is scanned."""

    async def seed(self, *, pem: bool = False):
        hostile = f"{SECRET_BOT} {SECRET_DB} {SECRET_WEBHOOK}" + (f" {PEM}" if pem else "")
        await self.settings(welcome_enabled=True, welcome_text=f"hello {SECRET_BOT} {SECRET_DB} {SECRET_WEBHOOK}")
        # straight into the store: bypasses the service's own cleaning, so the EXPORT layer's screening is what is tested
        await self.reports_store.add(A, USER, 6001, 70, hostile, ReportType.SPAM, ReportPriority.NORMAL, NOW)
        await self.reports_store.add(A, USER, 6002, 71, f"=HYPERLINK(\"{SECRET_DB}\")", ReportType.OTHER, ReportPriority.HIGH, NOW)
        self.s.licenses.audit_log.append(AuditEvent(
            group_id=A, action="manual", previous_status=LicenseStatus.ACTIVE_PERMANENT, new_status=LicenseStatus.ACTIVE_PERMANENT,
            occurred_at=NOW, actor_telegram_id=OWNER, reason=f"paid {SECRET_WEBHOOK} {SECRET_BOT} {SECRET_DB}"))
        from guardian.audit import make_event
        await self.s.audit.record(make_event("settings_changed", actor=OWNER, group_id=A, target=SECRET_BOT,
                                             detail=f"{SECRET_BOT} {SECRET_DB}", now=NOW))

    async def test_nothing_that_leaves_any_export_carries_a_secret(self):
        await self.seed()
        delivered = []
        for text, who in (("/export settings", TG_ADMIN), ("/export license", OWNER), ("/export reports", TG_ADMIN),
                          ("/export reports txt", TG_ADMIN), ("/export reports csv all", TG_CREATOR), ("/export audit", TG_ADMIN),
                          ("/export audit txt", TG_CREATOR)):
            self.s.clock.advance(seconds=31)
            before = len(self.transport.sent)
            res = await self.ex(text, actor=who, protection=gate(A, who, allowed=True))
            self.assertIn(res.kind, (R.DONE, R.ERROR), (text, res.kind))
            self.assertEqual(leaks(res.text), [], text)
            for user_id, name, data, caption in self.transport.sent[before:]:
                delivered.append(text)
                self.assertEqual(leaks(data), [], text)
                self.assertEqual(leaks(name), [], text)
                self.assertEqual(leaks(caption or ""), [], text)
        self.assertEqual(len(delivered), 7)                         # not vacuous: every export really went out, screened
        self.assertEqual(audit_leaks(self.s.audit), [])

    async def test_a_report_holding_a_private_key_makes_the_export_refuse_instead_of_clean(self):
        """Fail closed. (Only data that bypassed `ReportService`'s own cleaning can hold a PEM block; the side effect is that
        such a row blocks `/export reports` until it is dealt with: noted in PHASE6_PROGRESS as an availability trade-off.)"""
        await self.seed(pem=True)
        for text in ("/export reports", "/export reports txt"):
            self.s.clock.advance(seconds=31)
            res = await self.ex(text)
            self.assertIs(res.kind, R.ERROR, text)
            self.assertEqual(leaks(res.text), [])
        self.assertEqual(self.transport.sent, [])
        failed = [e for e in self.s.audit.events if e.event_type == EXPORT_FAILED]
        self.assertEqual(len(failed), 2)
        self.assertTrue(all("code=rejected" in e.detail for e in failed))
        self.assertEqual(audit_leaks(self.s.audit), [])

    async def test_a_refused_screening_sends_nothing_and_says_so_without_the_secret(self):
        """A file that LOOKS like a secret store (a PEM block as the whole content) is refused, not cleaned."""
        d = ExportDelivery(self.transport, claims=InMemoryIdempotency(), audit=self.s.audit, secrets=SECRETS, clock=self.s.clock)
        for content in (PEM, f"BOT_TOKEN={SECRET_BOT}\nDATABASE_URL={SECRET_DB}\n", f"{SECRET_BOT}"):
            res = await d.deliver(TG_ADMIN, ExportFile("x", "txt", content, 1), key=content[:5] + str(len(content)))
            if res.ok:                                              # cleaned and sent: then what was sent must be clean
                self.assertEqual(leaks(self.transport.sent[-1][2]), [])
            else:
                self.assertIn(res.code, (xm.REJECTED, xm.INVALID))
        self.assertTrue(all(leaks(x[2]) == [] for x in self.transport.sent))
        self.assertEqual(audit_leaks(self.s.audit), [])


TEXTUAL = [(spec.name, col.name, col.kind) for spec in TABLES for col in spec.columns if col.kind in ("text", "json")]
SECRET_KINDS = {"bot token": SECRET_BOT, "webhook secret": SECRET_WEBHOOK, "database url": SECRET_DB, "database password": DB_PASSWORD,
                "pem key": PEM, "url-quoted token": quote(SECRET_BOT, safe=""), "json-escaped db url": json.dumps(SECRET_DB)[1:-1]}


def inject(rows: dict, table: str, col: str, kind: str, secret: str) -> dict:
    rows = copy.deepcopy(rows)
    rows[table][0][col] = f"note {secret} end" if kind == "text" else {"k": [f"v {secret}"]}
    return rows


def collector_for(rows) -> BackupCollector:
    return BackupCollector(FakeReader(rows), app_version="t", schema_version=10, schema_name="0010_report_schedule", secrets=SECRETS,
                           clock=lambda: BK.FIXED_NOW)


class BackupSecretSweepTests(BK.Base):
    def test_there_are_textual_columns_to_sweep(self):
        self.assertGreater(len(TEXTUAL), 25)
        self.assertEqual({k for _, _, k in TEXTUAL}, {"text", "json"})

    async def test_a_clean_database_builds_a_file_with_no_secret_in_it(self):
        result = await collector_for(sample_rows()).collect()
        self.assertEqual(leaks(result.data), [])

    async def test_a_secret_in_ANY_text_or_json_column_refuses_the_whole_backup(self):
        base = sample_rows()
        for table, col, kind in TEXTUAL:
            for label, secret in SECRET_KINDS.items():
                with self.subTest(table=table, column=col, secret=label):
                    with self.assertRaises(BackupError) as ctx:
                        await collector_for(inject(base, table, col, kind, secret)).collect()
                    self.assertEqual(ctx.exception.code, "secret_found")
                    self.assertEqual(leaks(f"{ctx.exception} | {ctx.exception.detail}"), [])      # it names a table, never a value

    async def test_through_the_owners_command_nothing_is_sent_and_nothing_leaks(self):
        for label, secret in SECRET_KINDS.items():
            with self.subTest(secret=label):
                reader = FakeReader(inject(sample_rows(), "group_reports", "reason", "text", secret))
                self.build(reader=reader, secrets=SECRETS)
                out = await self.go(f"/backup confirm {await self.preview_code()}")
                self.assertEqual(out.status, "secret_found")
                self.assertEqual(self.transport.sent, [])
                self.assertEqual(leaks(out.text), [])
                self.assertIn(BACKUP_FAILED, self.kinds())
                self.assertEqual(audit_leaks(self.audit), [])


class RestoreSecretSweepTests(RP.Base):
    def file_with(self, table, col, kind, secret):
        def mutate(doc):
            doc["tables"][table][0][col] = f"note {secret} end" if kind == "text" else {"k": [f"v {secret}"]}
        return RP.edited(mutate)

    def test_a_backup_file_carrying_a_secret_is_never_accepted(self):
        accepted, codes = [], {}
        for table, col, kind in TEXTUAL:
            for label, secret in SECRET_KINDS.items():
                data = self.file_with(table, col, kind, secret)
                try:
                    RP.validate(data, secrets=SECRETS)
                    accepted.append((table, col, label))
                except V.RestoreValidationError as exc:
                    codes.setdefault((table, col), set()).add(exc.code)
                    self.assertEqual(leaks(f"{exc} | {exc.code} | {exc.detail}"), [], (table, col, label))
        self.assertEqual(accepted, [], "a file with a secret passed validation")
        # the dedicated check is what stops it wherever the row itself stays valid
        self.assertGreater(sum(1 for c in codes.values() if "secret_found" in c), len(codes) // 2)

    async def test_through_the_owners_command_a_hostile_file_never_reaches_a_preview(self):
        for label, secret in SECRET_KINDS.items():
            with self.subTest(secret=label):
                self.build(data=self.file_with("group_reports", "reason", "text", secret), secrets=SECRETS)
                reply = await self.go()
                self.assertEqual(reply.status, "invalid")
                self.assertEqual(leaks(reply.text), [])
                self.assertEqual(self.reader.calls, 0)                         # the database was never read for it
                self.assertEqual(audit_leaks(self.audit), [])

    async def test_a_good_files_preview_carries_no_secret_and_no_row_content(self):
        self.build(secrets=SECRETS)
        reply = await self.go()
        self.assertEqual(reply.status, "previewed")
        self.assertEqual(leaks(reply.text), [])
        for content in ("إعلان مزعج", "spam", "مجموعة الاختبار", "S3cr3t"):
            self.assertNotIn(content, reply.text)
        self.assertEqual(audit_leaks(self.audit), [])


class StatsOutputScanTests(unittest.IsolatedAsyncioTestCase):
    async def test_stats_and_periodic_reports_are_numbers_only(self):
        hostile = f"{SECRET_BOT} {SECRET_DB} {SECRET_WEBHOOK}"
        warns, sancs, reports, audit, counters = (InMemoryWarningStore(), InMemorySanctionStore(), InMemoryReportStore(),
                                                  InMemorySecurityAudit(), InMemoryCounterStore())
        await warns.add(A, 5001, TG_ADMIN, hostile, NOW)
        await sancs.record(A, 5001, SanctionKind.MUTE, TG_ADMIN, hostile, NOW)
        await reports.add(A, 5001, 6002, 1, hostile, ReportType.SPAM, ReportPriority.NORMAL, NOW)
        await audit.record(SecurityEvent("permission_denied", NOW, 5001, A, detail=hostile))
        await CounterRecorder(counters, TZ, lambda: NOW).bump(A, Counter.VIOLATION, NOW, 3)
        stats = StatsService(warnings=warns, sanctions=sancs, reports=reports, audit=audit, counters=counters, display_timezone=TZ,
                             clock=lambda: NOW)
        texts = 0
        for period in StatsPeriod:
            group, overall = await stats.group_stats(A, period), await stats.overall([A, B], period)
            for lang in ("ar", "en"):
                for text in (render(group, lang), render(overall, lang, overall=True), render_periodic(group, lang)):
                    texts += 1
                    self.assertEqual(leaks(text), [], (period, lang))
                    for identity in ("5001", "6002", "unit-test", "postgresql", "BEGIN"):
                        self.assertNotIn(identity, text)
        self.assertEqual(texts, 18)


# =================================================================================================================
# 4. CORRUPT FILES
# =================================================================================================================
def corrupt_variants() -> dict[str, bytes]:
    """Damaged or hostile versions of one real backup. NONE of them may reach a preview, a code or a write."""
    good = RP.good()
    text = good.decode("utf-8")
    out: dict[str, bytes] = {}
    for frac in (0.0, 0.01, 0.1, 0.33, 0.5, 0.75, 0.99):
        out[f"truncated to {frac}"] = good[: int(len(good) * frac)]
    start = len(text[: text.rindex('"tables":{') + 12].encode("utf-8"))        # inside the document's own tables section
    for i in range(10):
        pos = start + (len(good) - start) * i // 10
        flipped = bytearray(good)
        flipped[pos] ^= 0x01
        out[f"bit flipped at {pos}"] = bytes(flipped)
    out.update({
        "blank": b" \n ", "null": b"null", "array": b"[]", "empty object": b"{}", "string": b'"x"', "number": b"123", "true": b"true",
        "all byte values": bytes(range(256)) * 4, "zip": b"PK\x03\x04" + b"\x00" * 200, "gzip": b"\x1f\x8b\x08" + b"\x00" * 200,
        "html": b"<html><body>login</body></html>", "reversed": good[::-1], "trailing NUL": good + b"\x00", "trailing text": good + b" garbage",
        "two documents": good + good, "invalid utf-8": b'{"manifest":"\xff\xfe","tables":{}}',
        "deep arrays": b"[" * 100_000 + b"]" * 100_000, "deep objects": b'{"a":' * 30_000 + b"1" + b"}" * 30_000,
        "duplicate keys": b'{"manifest":{},"manifest":{},"tables":{}}', "NaN": b'{"manifest":NaN,"tables":{}}',
        "huge integer": b'{"manifest":{"total_rows":' + b"9" * 6000 + b"},\"tables\":{}}", "oversized": b" " * (F.MAX_BACKUP_BYTES + 1),
    })

    def unsigned(mutate):                                                    # edited WITHOUT re-signing: the checksums must catch it
        doc = json.loads(text)
        mutate(doc)
        return F.canonical(doc).encode("utf-8")

    first = next(iter(json.loads(text)["tables"]))
    out.update({
        "unsigned: total rows": unsigned(lambda d: d["manifest"].__setitem__("total_rows", d["manifest"]["total_rows"] + 1)),
        "unsigned: digest": unsigned(lambda d: d["manifest"].__setitem__("tables_digest", "0" * 64)),
        "unsigned: one checksum": unsigned(lambda d: d["manifest"]["tables"][first].__setitem__("sha256", "f" * 64)),
        "unsigned: one row count": unsigned(lambda d: d["manifest"]["tables"][first].__setitem__("rows", 99)),
        "unsigned: a table dropped from the file": unsigned(lambda d: d["tables"].pop(first)),
        "unsigned: a table dropped from the manifest": unsigned(lambda d: d["manifest"]["tables"].pop(first)),
        "unsigned: an extra table": unsigned(lambda d: d["tables"].__setitem__("pg_shadow", [])),
        "unsigned: a row changed": unsigned(lambda d: d["tables"]["group_reports"][0].__setitem__("status", "resolved")),
        "format name": unsigned(lambda d: d["manifest"].__setitem__("format", "other-backup")),
        "format version 2": unsigned(lambda d: d["manifest"].__setitem__("format_version", 2)),
        "schema from the future": unsigned(lambda d: d["manifest"].__setitem__("schema_version", 999)),
        "schema as text": unsigned(lambda d: d["manifest"].__setitem__("schema_version", "10")),
    })
    out.update({                                                             # re-signed (an attacker can): the CONTENT rules must catch it
        "signed: table removed": RP.edited(lambda d: d["tables"].pop("group_settings")),
        "signed: unknown table": RP.edited(lambda d: d["tables"].__setitem__("pg_shadow", [])),
        "signed: duplicate primary key": RP.edited(lambda d: d["tables"]["moderation_warnings"].append(dict(d["tables"]["moderation_warnings"][0]))),
        "signed: unknown column": RP.edited(lambda d: d["tables"]["group_reports"][0].__setitem__("evil", 1)),
        "signed: missing column": RP.edited(lambda d: d["tables"]["group_reports"][0].pop("reason")),
        "signed: text in an integer column": RP.edited(lambda d: d["tables"]["group_reports"][0].__setitem__("target_user_id", "444")),
        "signed: bool in an integer column": RP.edited(lambda d: d["tables"]["group_reports"][0].__setitem__("target_user_id", True)),
        "signed: bad status word": RP.edited(lambda d: d["tables"]["group_reports"][0].__setitem__("status", "owned")),
        "signed: bad timestamp": RP.edited(lambda d: d["tables"]["group_reports"][0].__setitem__("created_at", "yesterday")),
        "signed: row of a group that is not in the file": RP.edited(lambda d: d["tables"]["group_reports"][0].__setitem__("group_id", -999)),
        "signed: positive group id": RP.edited(lambda d: d["tables"]["telegram_groups"][0].__setitem__("group_id", 7)),
    })
    return out


class CorruptRestoreFileTests(RA.ConfirmBase):
    def test_the_set_of_corruptions_is_wide_enough_to_mean_something(self):
        self.assertGreater(len(corrupt_variants()), 60)

    async def test_no_damaged_file_ever_reaches_a_preview_a_code_or_the_database(self):
        for name, blob in corrupt_variants().items():
            with self.subTest(name):
                self.setup_confirm(data=blob)
                reply = await self.go("/restore")
                self.assertIn(reply.status, ("invalid", "failed", "too_large"), reply.status)
                self.assertEqual(self.reader.calls, 0)                       # the live database was never read for it
                self.assertEqual(len(self.pending), 0)                       # no confirmation code exists for it
                self.assertEqual((self.db.committed, self.db.rolled_back), (0, 0))
                self.assertEqual(self.kinds(), ["restore_rejected"])
                self.assertEqual(leaks(reply.text), [])
                self.assertEqual(audit_leaks(self.audit), [])

    async def test_a_file_that_goes_bad_between_preview_and_confirm_is_refused_and_consumes_nothing(self):
        picked = [n for n in corrupt_variants() if n.startswith(("truncated to 0.5", "bit flipped at", "unsigned:", "signed:", "reversed", "zip"))]
        self.assertGreater(len(picked), 20)
        variants = corrupt_variants()
        for name in picked:
            with self.subTest(name):
                self.setup_confirm()
                _, (a, b) = await self.preview()
                self.downloader.data = variants[name]                        # what the owner sends back is not what he previewed
                out = await self.confirm(f"/restore confirm {a}", mid=2)
                self.assertIn(out.status, ("invalid", "failed", "wrong_file"), out.status)
                self.assertNotEqual(out.status, "applied")
                self.assertEqual((self.db.committed, self.db.rolled_back), (0, 0))      # no transaction was even opened
                self.assertEqual(len(self.pending), 2)                       # both codes survive (a typo costs nothing)
                self.assertNotIn(RESTORE_STARTED, self.kinds())
                self.assertEqual(leaks(out.text), [])


class TamperedBackupDeliveryTests(unittest.IsolatedAsyncioTestCase):
    """The file the collector built is damaged or swapped BEFORE it is sent: it must not leave."""

    async def asyncSetUp(self):
        self.good = await collector_for(sample_rows()).collect()
        self.transport, self.claims, self.audit = FakeTransport(), InMemoryIdempotency(), InMemorySecurityAudit()
        self.delivery = bd.BackupDelivery(self.transport, claims=self.claims, audit=self.audit, secrets=SECRETS,
                                          forbidden_chat_ids=(OWNER_GROUP,), clock=lambda: NOW)

    def variants(self) -> dict[str, tuple[BackupResult, set[str]]]:
        g, data = self.good, self.good.data
        text = data.decode("utf-8")
        start = len(text[: text.rindex('"tables":{') + 12].encode("utf-8"))
        flip = bytearray(data)
        flip[start + 40] ^= 0x01
        with_secret = text.replace("spam", SECRET_BOT, 1).encode("utf-8")
        with_pem = text.replace("spam", PEM.replace("\n", "\\n"), 1).encode("utf-8")
        R_ = lambda **kw: dataclasses.replace(g, **kw)     # noqa: E731
        bad, corrupt, big = {bd.REJECTED}, {bd.CORRUPT}, {bd.TOO_LARGE}
        return {
            "truncated": (R_(data=data[: len(data) // 2]), corrupt), "bit flipped": (R_(data=bytes(flip)), corrupt),
            "not text": (R_(data=b"\xff\xfe" + data), corrupt), "empty": (R_(data=b""), corrupt),
            "a secret swapped in": (R_(data=with_secret), bad), "a private key swapped in": (R_(data=with_pem), bad),
            "oversized": (R_(data=data + b" " * (F.MAX_BACKUP_BYTES + 1)), big),
            "path in the name": (R_(name="../guardian-backup-20261101-120000-utc.json"), bad),
            "newline in the name": (R_(name="guardian-backup-20261101-120000-utc.json\n"), bad),
            "wrong extension": (R_(name="guardian-backup-20261101-120000-utc.json.exe"), bad),
            "env-looking name": (R_(name=".env"), bad), "no name": (R_(name=""), bad),
            "data is text": (R_(data=text), {bd.INVALID}), "data is None": (R_(data=None), {bd.INVALID}),
            "not a BackupResult": (NS_(data), {bd.INVALID}),
        }

    async def test_a_damaged_or_swapped_backup_never_leaves_and_never_burns_the_claim(self):
        for name, (backup, expected) in self.variants().items():
            with self.subTest(name):
                res = await self.delivery.deliver(OWNER, backup, key=1)
                self.assertIn(res.code, expected, res.code)
        self.assertEqual(self.transport.sent, [])
        self.assertEqual(audit_leaks(self.audit), [])
        self.assertFalse(any(e.event_type == BACKUP_DELIVERED for e in self.audit.events))
        res = await self.delivery.deliver(OWNER, self.good, key=1)                  # the SAME key: no refusal above consumed it
        self.assertEqual(res.code, bd.SENT)
        self.assertEqual(self.transport.sent[0][2], self.good.data)                 # byte for byte
        self.assertEqual([d[0] for d in self.transport.sent], [OWNER])


def NS_(data):
    from types import SimpleNamespace
    return SimpleNamespace(name="guardian-backup-20261101-120000-utc.json", data=data, total_rows=3)


class HostileExportFileTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.transport, self.audit = FakeTransport(), InMemorySecurityAudit()
        self.delivery = ExportDelivery(self.transport, claims=InMemoryIdempotency(), audit=self.audit, secrets=SECRETS,
                                       clock=lambda: NOW)

    async def test_a_malformed_or_hostile_export_is_never_sent(self):
        from types import SimpleNamespace
        files = {
            "not a file": None, "a string": "name,kind", "namespace": SimpleNamespace(name="x", kind="txt", content="a", rows=1),
            "too many rows": ExportFile("x", "csv", "a\n", rows=xm.MAX_ROWS + 1),
            "too large": ExportFile("x", "txt", "a" * (xm.MAX_BYTES + 1), rows=1),
            "too large in bytes, not characters": ExportFile("x", "txt", "ع" * (xm.MAX_BYTES // 2 + 1), rows=1),
            "empty": ExportFile("x", "txt", "", rows=0), "only blanks": ExportFile("x", "txt", " \n\t ", rows=0),
            "env shape": ExportFile("x", "txt", f"BOT_TOKEN={SECRET_BOT}\nDATABASE_URL={SECRET_DB}\nWEBHOOK_SECRET={SECRET_WEBHOOK}\n", rows=3),
            "pem": ExportFile("x", "txt", PEM, rows=1), "secret-like name": ExportFile("credentials", "txt", "a,b\n", rows=1),
            "dotenv name": ExportFile("env", "txt", "a=b\n", rows=1),
        }
        for name, file in files.items():
            with self.subTest(name):
                res = await self.delivery.deliver(TG_ADMIN, file, key=name)
                self.assertFalse(res.ok, res.code)
                self.assertIn(res.code, {xm.INVALID, xm.TOO_MANY_ROWS, xm.TOO_LARGE, xm.REJECTED})
        self.assertEqual(self.transport.sent, [])
        self.assertEqual(audit_leaks(self.audit), [])
        # The constructor itself refuses what must never exist:
        for bad in (dict(name="../x", kind="txt", content="a"), dict(name="a\x00b", kind="txt", content="a"), dict(name="x", kind="exe", content="a"),
                    dict(name="x", kind="txt", content=b"bytes"), dict(name="x", kind="txt", content="a", rows=-1),
                    dict(name="x", kind="txt", content="a", rows=True), dict(name="x" * 61, kind="txt", content="a")):
            with self.assertRaises(xm.ExportError):
                ExportFile(**bad)


# =================================================================================================================
# LOGS: what the process writes while all of the above fails
# =================================================================================================================
class LogCapture:
    """Logging is switched off for the whole suite (`helpers`); here it is switched on to look at what really gets written."""

    def __init__(self, strict_loggers: tuple[str, ...] = ()):
        self.redacted, self.raw, self.strict = io.StringIO(), io.StringIO(), strict_loggers

    def __enter__(self):
        self.h1 = logging.StreamHandler(self.redacted)
        self.h1.setFormatter(RedactingFormatter(SECRETS))                     # exactly what `configure_logging` installs
        self.h2 = logging.StreamHandler(self.raw)
        self.h2.addFilter(lambda r: r.name in self.strict)                    # the modules that promise never to log a message
        root = logging.getLogger()
        self.level = root.level
        root.setLevel(logging.DEBUG)
        root.addHandler(self.h1)
        root.addHandler(self.h2)
        logging.disable(logging.NOTSET)
        return self

    def __exit__(self, *exc):
        logging.disable(logging.CRITICAL)
        root = logging.getLogger()
        root.removeHandler(self.h1)
        root.removeHandler(self.h2)
        root.setLevel(self.level)
        return False


STRICT = ("guardian.export.delivery", "guardian.backup.delivery", "guardian.backup.restore_service")


class LogsWatched:
    """Mixin for the failure tests above: logging is switched ON for each test and, afterwards, everything the process wrote is
    scanned. Through the redacting formatter (what `configure_logging` installs) NOTHING may show; and the modules that promise to
    log the exception TYPE only (`STRICT`) must be clean even WITHOUT the formatter."""

    LOGGING_TESTS: frozenset[str] = frozenset()      # tests that must really have produced log lines (so the scan is not vacuous)

    def setUp(self):
        super().setUp()
        self._cap = LogCapture(STRICT)
        self._cap.__enter__()
        self.addCleanup(self._scan_logs)

    def _scan_logs(self):
        self._cap.__exit__(None, None, None)
        redacted, raw = self._cap.redacted.getvalue(), self._cap.raw.getvalue()
        if self._testMethodName in self.LOGGING_TESTS:
            self.assertGreater(len(redacted.splitlines()), 0, "nothing was logged: the scan proved nothing")
        self.assertEqual(leaks(redacted), [], "a secret reached the log THROUGH the redacting formatter")
        self.assertEqual(leaks(raw), [], "a delivery module logged an exception MESSAGE (it must log the type only)")


# =================================================================================================================
# 5. SEND FAILURE (and a store that is down)
# =================================================================================================================
class LeakyError(Exception):
    """Like an HTTP client's error: the text carries the request URL, i.e. the bot token, and a connection string."""


def leaky(prefix: str = "send failed") -> LeakyError:
    return LeakyError(f"{prefix}: POST https://api.telegram.org/bot{SECRET_BOT}/sendDocument via {SECRET_DB} key {SECRET_WEBHOOK}")


class Recording:
    """Wraps a transport and remembers EVERY destination it was asked to send to, including the attempts that failed."""

    def __init__(self, inner):
        self.inner, self.attempts = inner, []

    async def send_document(self, user_id, filename, data, caption=None):
        self.attempts.append(user_id)
        return await self.inner.send_document(user_id, filename, data, caption)

    def __getattr__(self, name):
        return getattr(self.inner, name)


class ExportSendFailureTests(LogsWatched, SecretAwareDelivery, XR.Base):
    LOGGING_TESTS = frozenset({"test_a_failing_send_answers_one_safe_line_and_leaks_nothing", "test_a_read_that_fails_exports_nothing", "test_a_store_that_is_down_is_a_safe_error_not_a_leak_or_a_send"})

    async def asyncSetUp(self):
        await super().asyncSetUp()
        await self.file_reports(1)
        self.rec = Recording(self.transport)
        self.delivery._transport = self.rec

    async def go(self, text="/export settings", actor=TG_ADMIN, same_message=False):
        self.s.clock.advance(seconds=31)
        if same_message:
            self.msg -= 1
        return await self.ex(text, actor=actor, protection=gate(A, actor, allowed=True))

    async def test_a_failing_send_answers_one_safe_line_and_leaks_nothing(self):
        for exc, kind in ((leaky(), R.TELEGRAM_FAILED), (OSError(SECRET_BOT), R.TELEGRAM_FAILED), (ValueError(SECRET_DB), R.TELEGRAM_FAILED),
                          (asyncio.TimeoutError(), R.TELEGRAM_FAILED), (RuntimeError(), R.TELEGRAM_FAILED),
                          (PrivateChatUnavailable(SECRET_BOT), R.INVALID)):
            with self.subTest(type(exc).__name__):
                self.transport.error = exc
                res = await self.go()
                self.assertIs(res.kind, kind)
                self.assertEqual(leaks(res.text), [])
                self.assertLess(len(res.text), 300)
        self.assertEqual(self.transport.sent, [])
        self.assertEqual(set(self.rec.attempts), {TG_ADMIN})                       # only ever tried the requester's private chat
        self.assertNotIn(A, self.rec.attempts)
        self.assertEqual(audit_leaks(self.s.audit), [])
        failed = [e for e in self.s.audit.events if e.event_type == EXPORT_FAILED]
        self.assertEqual(len(failed), 6)
        self.assertTrue(all(re.fullmatch(r"kind=\w+ bytes=\d+ rows=\d+ code=[a-z_]+( why=\w+)?", e.detail) for e in failed))

    async def test_a_failure_is_final_for_that_message_and_a_new_command_works_again(self):
        self.transport.error = leaky()
        self.assertIs((await self.go()).kind, R.TELEGRAM_FAILED)
        self.transport.error = None
        self.assertIs((await self.go(same_message=True)).kind, R.DUPLICATE)         # at-most-once: the redelivered update is silent
        self.assertEqual(self.transport.sent, [])
        res = await self.go()                                                       # a NEW command message
        self.assertIs(res.kind, R.DONE)
        self.assertEqual([d[0] for d in self.transport.sent], [TG_ADMIN])

    async def test_a_hung_send_times_out_and_a_cancelled_one_is_not_swallowed(self):
        self.delivery._timeout = 0.05
        self.transport.delay = 1.0
        res = await self.go()
        self.assertIs(res.kind, R.TELEGRAM_FAILED)
        self.assertTrue(any("why=timeout" in (e.detail or "") for e in self.s.audit.events))
        self.delivery._timeout = 5.0
        self.transport.delay = 5.0
        task = asyncio.ensure_future(self.go())
        await asyncio.sleep(0.05)
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await task
        self.assertEqual(self.transport.sent, [])

    async def test_a_store_that_is_down_is_a_safe_error_not_a_leak_or_a_send(self):
        for where, make in (("command claims", lambda: setattr(self.svc._export_cmds, "_claims", XR.BrokenClaims())),
                            ("delivery claims", lambda: setattr(self.delivery, "_claims", XR.BrokenClaims()))):
            with self.subTest(where):
                make()
                res = await self.go()
                self.assertIn(res.kind, (R.ERROR, R.TELEGRAM_FAILED))
                self.assertEqual(leaks(res.text), [])
        self.assertEqual(self.transport.sent, [])
        self.assertEqual(audit_leaks(self.s.audit), [])

    async def test_a_read_that_fails_exports_nothing(self):
        async def boom(*a, **k):
            raise leaky("read failed")
        self.svc._export_cmds._audit.for_group = boom
        res = await self.go("/export audit")
        self.assertIs(res.kind, R.ERROR)
        self.assertEqual(leaks(res.text), [])
        self.assertEqual((self.transport.sent, self.rec.attempts), ([], []))


class BackupSendFailureTests(LogsWatched, BK.Base):
    LOGGING_TESTS = frozenset({"test_a_failing_send_answers_one_safe_line_and_leaks_nothing", "test_a_store_that_is_down_is_a_safe_answer"})

    class Attempts(BK.Transport):
        def __init__(self, exc=None, delay=0.0):
            super().__init__(exc, delay)
            self.attempts = []

        async def send_document(self, chat_id, name, data, caption=None):
            self.attempts.append(chat_id)
            return await super().send_document(chat_id, name, data, caption)

    async def confirm(self, mid=2):
        return await self.go(f"/backup confirm {await self.preview_code()}", mid=mid)

    async def test_a_failing_send_answers_one_safe_line_and_leaks_nothing(self):
        for exc, status in ((leaky(), "failed"), (OSError(SECRET_BOT), "failed"), (asyncio.TimeoutError(), "failed"),
                            (PrivateChatUnavailable(SECRET_BOT), "private_not_started")):
            with self.subTest(type(exc).__name__):
                transport = self.Attempts(exc)
                self.build(transport=transport, secrets=SECRETS)
                out = await self.confirm()
                self.assertEqual(out.status, status)
                self.assertEqual(leaks(out.text), [])
                self.assertEqual((transport.sent, set(transport.attempts)), ([], {OWNER}))
                self.assertEqual(audit_leaks(self.audit), [])
                self.assertIn(BACKUP_FAILED, self.kinds())
                self.assertNotIn(BACKUP_DELIVERED, self.kinds())

    async def test_after_a_failure_the_code_is_gone_and_the_cooldown_applies_then_a_new_backup_works(self):
        transport = self.Attempts(leaky())
        self.build(transport=transport, secrets=SECRETS)
        code = await self.preview_code()
        self.assertEqual((await self.go(f"/backup confirm {code}", mid=2)).status, "failed")
        transport.exc = None
        self.assertEqual((await self.go(f"/backup confirm {await self.preview_code()}", mid=3)).status, "cooldown")
        self.clock.now += timedelta(seconds=svc_cooldown() + 1)
        self.assertEqual((await self.go(f"/backup confirm {code}", mid=4)).status, "unknown_code")      # the old code was single-use
        out = await self.go(f"/backup confirm {await self.preview_code()}", mid=5)
        self.assertEqual(out.status, "sent")
        self.assertEqual([d[0] for d in transport.sent], [OWNER])

    async def test_a_hung_send_times_out_and_a_cancelled_one_releases_the_lock(self):
        transport = self.Attempts(delay=1.0)
        self.build(transport=transport)
        self.delivery._timeout = 0.05
        out = await self.confirm()
        self.assertEqual(out.status, "failed")
        self.assertTrue(any("why=timeout" in (e.detail or "") for e in self.audit.events))
        self.delivery._timeout = 5.0
        transport.delay = 5.0
        self.clock.now += timedelta(seconds=svc_cooldown() + 1)
        task = asyncio.ensure_future(self.confirm(mid=9))
        await asyncio.sleep(0.05)
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await task
        self.assertFalse(self.service._lock.locked())                                # not stuck "busy" forever
        self.assertEqual(transport.sent, [])

    async def test_a_crashing_or_failing_read_is_a_safe_failure(self):
        class Crashing:
            async def collect(self):
                raise leaky("collect crashed")

        self.build(collector=Crashing(), secrets=SECRETS)
        out = await self.confirm()
        self.assertEqual(out.status, "failed")
        self.assertEqual(leaks(out.text), [])
        self.assertEqual(audit_leaks(self.audit), [])
        self.build(reader=FakeReader(boom=leaky("db read failed")), secrets=SECRETS)
        out = await self.confirm()
        self.assertEqual(out.status, "failed")
        self.assertEqual(leaks(out.text), [])
        self.assertEqual((self.transport.sent, audit_leaks(self.audit)), ([], []))

    async def test_a_store_that_is_down_is_a_safe_answer(self):
        self.build(delivery_claims=BK.BrokenClaims())
        self.assertEqual((await self.confirm()).status, "failed")
        self.assertEqual(self.transport.sent, [])
        self.build()
        self.service._claims = BK.BrokenClaims()
        self.assertEqual((await self.confirm()).status, "unavailable")
        self.assertEqual(self.transport.sent, [])


def svc_cooldown() -> int:
    return bsvc.COOLDOWN_SECONDS


class RestoreFailureTests(LogsWatched, RA.ConfirmBase):
    LOGGING_TESTS = frozenset({"test_a_failing_download_or_state_read_is_refused_safely_and_consumes_nothing", "test_an_executor_that_dies_rolls_back_reports_a_closed_code_and_leaks_nothing"})

    async def test_a_failing_download_or_state_read_is_refused_safely_and_consumes_nothing(self):
        self.setup_confirm()
        _, (a, b) = await self.preview()
        self.downloader.exc = leaky("download failed")
        out = await self.confirm(f"/restore confirm {a}", mid=2)
        self.assertEqual(out.status, "download_failed")
        self.assertEqual(leaks(out.text), [])
        self.assertEqual((self.db.committed, len(self.pending)), (0, 2))
        self.assertEqual(audit_leaks(self.audit), [])
        self.downloader.exc = None
        self.reader.exc = leaky("state read failed")                  # MemReader has no `exc`: the preview path reads through StateReader
        self.setup_confirm()
        self.reader = RP.StateReader(exc=leaky("state read failed"))
        self.service._reader = self.reader
        reply = await self.go("/restore", mid=3)
        self.assertEqual(reply.status, "failed")
        self.assertEqual(leaks(reply.text), [])
        self.assertEqual((len(self.pending), audit_leaks(self.audit)), (0, []))

    async def test_a_hung_download_times_out_and_a_cancelled_one_releases_the_lock(self):
        from unittest import mock
        self.setup_confirm()
        self.downloader.delay = 1.0
        with mock.patch.object(rsvc, "DOWNLOAD_TIMEOUT", 0.05):
            reply = await self.go("/restore", mid=1)
        self.assertEqual(reply.status, "download_failed")
        self.assertEqual(len(self.pending), 0)
        self.downloader.delay = 5.0
        self.clock.now += timedelta(seconds=60)
        task = asyncio.ensure_future(self.go("/restore", mid=2))
        await asyncio.sleep(0.05)
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await task
        self.assertFalse(self.service._lock.locked())
        self.assertEqual((self.db.committed, len(self.pending)), (0, 0))

    async def test_an_executor_that_dies_rolls_back_reports_a_closed_code_and_leaks_nothing(self):
        class Dying:
            async def execute(self, *a, **k):
                raise leaky("executor died")

        self.setup_confirm(executor=Dying())
        _, (a, b) = await self.preview()
        before = copy.deepcopy(self.db.t)
        out = await self.confirm(f"/restore confirm {a}", mid=2)
        self.assertEqual(out.status, "rolled_back")
        self.assertEqual(leaks(out.text), [])
        self.assertEqual(self.db.t, before)
        self.assertEqual(self.db.committed, 0)
        failed = [e for e in self.audit.events if e.event_type == "restore_failed"]
        self.assertEqual(len(failed), 1)
        self.assertIn("rolled_back=1", failed[0].detail)
        self.assertEqual(audit_leaks(self.audit), [])
        self.assertEqual(self.pending.peek(OWNER, "restore", a), None)               # single-use: spent even though it failed

    async def test_a_store_that_is_down_is_a_safe_answer(self):
        self.setup_confirm()
        self.service._claims = RP.BrokenClaims()
        self.assertEqual((await self.go("/restore", mid=1)).status, "unavailable")
        self.assertEqual((self.downloader.calls, self.reader.calls, self.db.committed), ([], 0, 0))


class PeriodicSendFailureTests(LogsWatched, PD.Base):
    LOGGING_TESTS = frozenset({"test_a_failed_report_is_retried_later_never_sent_elsewhere_and_leaks_nothing", "test_an_unreadable_destination_setting_sends_nothing_anywhere", "test_the_background_hook_swallows_a_failing_run_and_logs_without_the_secret"})

    class LeakyBot(PD.FakeBot):
        def __init__(self):
            super().__init__()
            self.attempts, self.broken = [], True

        async def send_message(self, chat_id, text):
            self.attempts.append(chat_id)
            if self.broken:
                raise leaky("periodic send failed")
            self.sent.append((chat_id, text))

    async def test_a_failed_report_is_retried_later_never_sent_elsewhere_and_leaks_nothing(self):
        bot = self.LeakyBot()
        await self.enable()
        run = await self.delivery.deliver_group(bot, PD.GA)
        self.assertEqual((run.sent, run.failed), (0, True))
        self.assertIsNone((await self.schedule.entries(PD.GA))[PD.DAY].last_period_key)
        bot.broken = False
        self.now += timedelta(seconds=PD.pd.LEASE_SECONDS + 1)
        later = await self.delivery.deliver_group(bot, PD.GA)
        self.assertEqual(later.sent, 3)
        self.assertEqual(set(bot.attempts), {PD.GA})                                  # no fallback to the owner, the hub or another group
        self.assertTrue(all(leaks(text) == [] for _, text in bot.sent))
        self.assertEqual(audit_leaks(self.audit), [])

    async def test_an_unreadable_destination_setting_sends_nothing_anywhere(self):
        bot = self.LeakyBot()
        bot.broken = False
        await self.enable()
        self.raw = leaky("settings unreadable")
        run = await self.delivery.deliver_group(bot, PD.GA)
        self.assertEqual((run.sent, run.failed, bot.attempts, bot.sent), (0, True, [], []))
        self.assertEqual(audit_leaks(self.audit), [])

    async def test_the_background_hook_swallows_a_failing_run_and_logs_without_the_secret(self):
        bot = self.LeakyBot()
        await self.enable()
        self.assertTrue(self.delivery.on_update(bot, PD.GA, True))
        await asyncio.gather(*list(self.delivery._tasks))                     # nothing is raised into the update
        self.assertEqual((bot.sent, set(bot.attempts)), ([], {PD.GA}))
