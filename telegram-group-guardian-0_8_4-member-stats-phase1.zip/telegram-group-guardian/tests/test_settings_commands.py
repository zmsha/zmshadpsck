"""Closing part 3: /slowmode /antiflood /protect (settings_commands.py)."""
from __future__ import annotations

import asyncio
import unittest

from executor_stack import A, B, BrokenClaims, ExecBase, gate
from guardian.groups.memory_store import InMemorySettingsStore
from guardian.moderation.executor import ResultKind as R
from guardian.permissions import GroupRole
from guardian.protection.settings import ProtectionSettings
from stack import BACKUP, DELEGATE, OWNER, STRANGER, TG_ADMIN, TG_LIMITED_ADMIN

ANON = 1_087_968_824


class SettingsBase(ExecBase):
    async def raw(self, group=A):
        row = await self.s.settings_store.get(group)
        return {} if row is None else row.settings

    async def eff(self, group=A):
        return ProtectionSettings.from_raw(await self.raw(group))


class ReadTests(SettingsBase):
    async def test_show_everything_and_single_topics(self):
        r = await self.run_cmd("/protect")
        self.assertEqual(r.kind, R.INFO)
        for marker in ("🔗", "🌊", "♻️", "🐢", "📈", "⚠️", "🧪"):
            self.assertIn(marker, r.text)
        r = await self.run_cmd("/slowmode")
        self.assertEqual(r.kind, R.INFO)
        self.assertIn("🐢", r.text)
        self.assertNotIn("🌊", r.text)
        self.assertIn("🌊", (await self.run_cmd("/antiflood")).text)
        self.assertEqual((await self.run_cmd("/protect allow")).text[:2], "ℹ️")
        self.assertEqual(await self.raw(), {})            # reading never writes
        self.assertEqual(self.claims._keys, {})           # ... and never consumes a claim

    async def test_a_moderator_delegate_may_read_but_not_write(self):
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.MODERATOR)
        self.assertEqual((await self.run_cmd("/protect", actor=DELEGATE)).kind, R.INFO)
        for text in ("/slowmode 30", "/antiflood off", "/protect links off", "/protect allow add a.com"):
            self.assertEqual((await self.run_cmd(text, actor=DELEGATE)).kind, R.DENIED, text)
        self.assertEqual(await self.raw(), {})

    async def test_reading_follows_the_two_shared_gates(self):
        for actor in (STRANGER, TG_LIMITED_ADMIN, BACKUP, ANON):
            self.assertEqual((await self.run_cmd("/protect", actor=actor)).kind, R.DENIED, actor)
        for ctx in (None, gate(A, allowed=False), gate(B)):
            self.assertEqual((await self.run_cmd("/protect", protection=ctx)).kind, R.LICENSE_OFF)


class WriteTests(SettingsBase):
    async def test_slowmode_set_off_and_effective_reply(self):
        r = await self.run_cmd("/slowmode 30")
        self.assertEqual(r.kind, R.DONE)
        self.assertIn("30", r.text)
        self.assertEqual((await self.eff()).slowmode_seconds, 30)
        self.assertEqual((await self.run_cmd("الوضع البطيء ٥د", msg=2)).kind, R.DONE)
        self.assertEqual((await self.eff()).slowmode_seconds, 300)
        self.assertEqual((await self.run_cmd("/slowmode off", msg=3)).kind, R.DONE)
        self.assertEqual((await self.eff()).slowmode_seconds, 0)
        self.assertEqual(self.audit_types().count("settings_changed"), 3)

    async def test_antiflood_forms(self):
        await self.run_cmd("/antiflood 8 20")
        e = await self.eff()
        self.assertEqual((e.flood_enabled, e.flood_max_messages, e.flood_window_seconds), (True, 8, 20))
        await self.run_cmd("/antiflood off", msg=2)
        self.assertFalse((await self.eff()).flood_enabled)
        await self.run_cmd("مكافحة الفيضان تشغيل", msg=3)
        self.assertTrue((await self.eff()).flood_enabled)
        self.assertEqual((await self.eff()).flood_max_messages, 8)  # on/off keeps the numbers

    async def test_protect_each_setting_round_trips(self):
        for i, (text, check) in enumerate((
            ("/protect links off", lambda e: e.links_enabled is False),
            ("/protect invites allow", lambda e: e.links_allow_invites is True),
            ("/protect duplicates 5 2m", lambda e: (e.duplicate_max_repeats, e.duplicate_window_seconds) == (5, 120)),
            ("/protect escalation 10m 2h", lambda e: e.escalation_mutes_seconds == (600, 7200)),
            ("/protect window 3d", lambda e: e.escalation_window_seconds == 3 * 86400),
            ("/protect warnlimit 5", lambda e: e.warn_limit == 5),
            ("/protect warnaction ban perm", lambda e: (e.warn_action, e.warn_action_seconds) == ("ban", 0)),
            ("/protect slowmode 45", lambda e: e.slowmode_seconds == 45),
        ), start=1):
            r = await self.run_cmd(text, msg=i)
            self.assertEqual(r.kind, R.DONE, text)
            self.assertTrue(check(await self.eff()), text)

    async def test_a_write_keeps_unrelated_settings(self):
        await self.settings(language_note="keep", warn_limit=7)
        await self.run_cmd("/slowmode 30")
        raw = await self.raw()
        self.assertEqual((raw["language_note"], raw["warn_limit"], raw["slowmode_seconds"]), ("keep", 7, 30))

    async def test_roles(self):
        self.assertEqual((await self.run_cmd("/slowmode 30", actor=TG_ADMIN, msg=1)).kind, R.DONE)
        self.assertEqual((await self.run_cmd("/slowmode 31", actor=OWNER, msg=2)).kind, R.DONE)
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.GROUP_MANAGER)
        self.assertEqual((await self.run_cmd("/slowmode 32", actor=DELEGATE, msg=3)).kind, R.DONE)

    async def test_isolated_per_group(self):
        await self.run_cmd("/protect allow add a.com")
        await self.run_cmd("/slowmode 30")
        self.assertEqual(await self.raw(B), {})
        r = await self.run_cmd("/slowmode 30", chat=B, actor=TG_ADMIN)  # TG_ADMIN is admin of A only
        self.assertEqual(r.kind, R.DENIED)
        self.assertEqual(await self.raw(B), {})

    async def test_license_off_and_dry_run(self):
        for ctx in (None, gate(A, allowed=False)):
            self.assertEqual((await self.run_cmd("/slowmode 30", protection=ctx)).kind, R.LICENSE_OFF)
        self.assertEqual(await self.raw(), {})
        await self.settings(dry_run=True)
        # configuration is not punitive: it must still work in dry-run (an admin needs it, the owner switches it off)
        self.assertEqual((await self.run_cmd("/slowmode 30")).kind, R.DONE)
        self.assertEqual(self.actions.calls, [])

    async def test_redelivery_writes_and_audits_once(self):
        a = await self.run_cmd("/slowmode 30", msg=7)
        b = await self.run_cmd("/slowmode 30", msg=7)
        self.assertEqual((a.kind, b.kind, b.text), (R.DONE, R.DUPLICATE, ""))
        self.assertEqual(self.audit_types().count("settings_changed"), 1)

    async def test_invalid_input_writes_nothing_and_keeps_the_claim_free(self):
        for text in ("/slowmode 3", "/slowmode abc", "/antiflood 1", "/protect links maybe", "/protect nope",
                     "/protect allow add bad..com", "/protect warnaction ban", "/protect escalation 99d"):
            self.assertEqual((await self.run_cmd(text)).kind, R.INVALID, text)
        self.assertEqual(await self.raw(), {})
        self.assertEqual(self.claims._keys, {})

    async def test_claim_failure_and_missing_service_fail_closed(self):
        self.svc = self.make_service(BrokenClaims())
        self.assertEqual((await self.run_cmd("/slowmode 30")).kind, R.ERROR)
        self.assertEqual(await self.raw(), {})
        from guardian.moderation.executor import ModerationCommandService
        from executor_stack import BOT
        self.svc = ModerationCommandService(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions,
            settings_store=self.s.settings_store, actions=self.actions, chat_info=self.s.chat, claims=self.claims,
            audit=self.s.audit, bot_id=BOT, clock=self.s.clock)  # no group_settings
        self.assertEqual((await self.run_cmd("/slowmode 30", msg=2)).kind, R.ERROR)
        self.assertEqual(self.claims._keys, {})  # refused before anything was claimed
        self.assertEqual((await self.run_cmd("/protect", msg=3)).kind, R.INFO)  # reads still work

    async def test_dryrun_switch_is_primary_owner_only(self):
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.GROUP_MANAGER)
        for actor in (TG_ADMIN, DELEGATE):
            r = await self.run_cmd("/protect dryrun on", actor=actor)
            self.assertEqual(r.kind, R.DENIED, actor)
        self.assertEqual(await self.raw(), {})
        self.assertEqual(self.claims._keys, {})
        self.assertEqual((await self.run_cmd("/protect dryrun on", actor=OWNER, msg=5)).kind, R.DONE)
        self.assertTrue((await self.eff()).dry_run)
        self.assertEqual((await self.run_cmd("/protect dryrun off", actor=OWNER, msg=6)).kind, R.DONE)
        self.assertFalse((await self.eff()).dry_run)

    async def test_audit_names_keys_never_values(self):
        await self.run_cmd("/protect allow add secret-partner.example")
        details = [e.detail for e in self.s.audit.events if e.event_type == "settings_changed"]
        self.assertEqual(details, ["keys=links_allow_domains"])


class AllowListTests(SettingsBase):
    async def test_add_list_remove_clear(self):
        r = await self.run_cmd("/protect allow add https://WWW.Example.com/x docs.python.org", msg=1)
        self.assertEqual(r.kind, R.DONE)
        self.assertEqual((await self.eff()).links_allow_domains, ("example.com", "docs.python.org"))
        r = await self.run_cmd("/protect allow list", msg=2)
        self.assertIn("example.com", r.text)
        self.assertIn("(2)", r.text)
        self.assertEqual((await self.run_cmd("/protect allow add example.com", msg=3)).kind, R.NOOP)
        self.assertEqual((await self.run_cmd("/protect allow remove nothere.com", msg=4)).kind, R.NOOP)
        self.assertEqual((await self.run_cmd("/protect allow remove example.com", msg=5)).kind, R.DONE)
        self.assertEqual((await self.eff()).links_allow_domains, ("docs.python.org",))
        self.assertEqual((await self.run_cmd("/protect allow clear", msg=6)).kind, R.DONE)
        self.assertEqual((await self.run_cmd("/protect allow clear", msg=7)).kind, R.NOOP)
        self.assertEqual((await self.eff()).links_allow_domains, ())

    async def test_list_limit(self):
        await self.settings(links_allow_domains=[f"d{i}.example.com" for i in range(100)])
        self.assertEqual((await self.run_cmd("/protect allow add one-more.com")).kind, R.INVALID)
        self.assertEqual(len((await self.eff()).links_allow_domains), 100)

    async def test_the_allow_list_really_changes_link_protection(self):
        from guardian.protection.links import find_links, violating_links
        await self.run_cmd("/protect allow add good.example")
        allow = (await self.eff()).links_allow_domains
        self.assertEqual(violating_links(find_links("see https://good.example/a", ()), allow, allow_invites=False), [])
        self.assertTrue(violating_links(find_links("see https://evil.example/a", ()), allow, allow_invites=False))

    async def test_two_concurrent_adds_both_survive(self):
        class Slow(InMemorySettingsStore):
            async def merge(self, *a, **k):
                await asyncio.sleep(0)  # let the other command run between its read and its write
                return await super().merge(*a, **k)

        self.s.settings_store._rows  # same store object is used by the services; swap its class behaviour
        self.s.settings_store.__class__ = Slow
        await asyncio.gather(self.run_cmd("/protect allow add one.com", msg=1), self.run_cmd("/protect allow add two.com", msg=2))
        self.assertEqual(set((await self.eff()).links_allow_domains), {"one.com", "two.com"})


if __name__ == "__main__":
    unittest.main()
