import unittest

from guardian.moderation.commands import (Command as C, CommandError, fold_arabic, interpret_args, parse_command)
from guardian.moderation.targets import ReplyInfo, split_target_args

BOT = "GuardianBot"


class SlashTests(unittest.TestCase):
    def test_all_eight_commands(self):
        for c in C:
            p = parse_command(f"/{c.value} @ali_user", BOT)
            self.assertEqual((p.command, p.args, p.arabic), (c, ("@ali_user",), False))

    def test_case_suffix_and_foreign_bot(self):
        self.assertEqual(parse_command("/BAN 5001", BOT).command, C.BAN)
        self.assertEqual(parse_command("/ban@guardianbot 5001", BOT).command, C.BAN)
        self.assertEqual(parse_command("/ban@@GuardianBot", BOT), None)
        self.assertIsNone(parse_command("/ban@OtherBot 5001", BOT))
        self.assertIsNone(parse_command("/ban@GuardianBot 5001", None))  # unknown own name: do not act

    def test_not_ours_or_malformed(self):
        for t in ("/lockdown 5", "/ban_all", "/", "//ban", "hello", "", "   ", None, 5, "x" * 5000, "/ban\u0000"):
            self.assertIsNone(parse_command(t, BOT), repr(t)[:30])

    def test_args_whitespace_and_cap(self):
        p = parse_command("  /mute   5001\t30m   spam  ", BOT)
        self.assertEqual(p.args, ("5001", "30m", "spam"))
        self.assertEqual(len(parse_command("/warn " + " ".join("w" * 30), BOT).args), 20)


class ArabicTests(unittest.TestCase):
    def test_aliases_with_reply(self):
        table = {"حظر": C.BAN, "بان": C.BAN, "الغاء الحظر": C.UNBAN, "إلغاء الحظر": C.UNBAN, "فك الحظر": C.UNBAN,
                 "كتم": C.MUTE, "الغاء الكتم": C.UNMUTE, "رفع الكتم": C.UNMUTE, "طرد": C.KICK, "تحذير": C.WARN,
                 "التحذيرات": C.WARNINGS, "مسح التحذيرات": C.CLEARWARNS, "تصفير التحذيرات": C.CLEARWARNS}
        for text, want in table.items():
            p = parse_command(text, BOT, has_reply=True)
            self.assertEqual((p.command, p.arabic, p.args), (want, True, ()), text)

    def test_longest_alias_wins_and_args(self):
        p = parse_command("الغاء الحظر @ali_user سامحناه", BOT)
        self.assertEqual((p.command, p.args), (C.UNBAN, ("@ali_user", "سامحناه")))
        p = parse_command("مسح التحذيرات 5001", BOT)
        self.assertEqual(p.command, C.CLEARWARNS)

    def test_diacritics_and_tatweel_and_digits(self):
        self.assertEqual(parse_command("حَظْر ٥٠٠١", BOT).command, C.BAN)
        self.assertEqual(parse_command("كـتـم @ali_user ٣٠د", BOT).command, C.MUTE)
        self.assertEqual(fold_arabic("إلغاء"), "الغاء")

    def test_plain_sentences_are_not_commands(self):
        for text in ("حذر من الكلاب", "كتم الصوت لو سمحت", "طرد المشاكل", "حظر التجول", "تحذير مهم للجميع", "بان علينا"):
            self.assertIsNone(parse_command(text, BOT), text)

    def test_arabic_must_start_the_message(self):
        self.assertIsNone(parse_command("من فضلك حظر 5001", BOT, has_reply=True))
        self.assertIsNone(parse_command("حظرنا 5001", BOT, has_reply=True))  # not an exact alias word


class InterpretTests(unittest.TestCase):
    def test_timed(self):
        a = interpret_args(C.MUTE, ["30m", "spam", "links"])
        self.assertEqual((a.duration_seconds, a.permanent, a.reason), (1800, False, "spam links"))
        a = interpret_args(C.BAN, ["٧d"])
        self.assertEqual((a.duration_seconds, a.reason), (604800, None))

    def test_permanent_default_and_word(self):
        a = interpret_args(C.BAN, [])
        self.assertEqual((a.duration_seconds, a.permanent, a.reason), (None, True, None))
        a = interpret_args(C.MUTE, ["دائم", "إزعاج"])
        self.assertEqual((a.duration_seconds, a.permanent, a.reason), (None, True, "إزعاج"))
        a = interpret_args(C.MUTE, ["flooding", "again"])  # first word not a duration => whole reason
        self.assertEqual((a.permanent, a.reason), (True, "flooding again"))

    def test_bad_duration_is_an_error_not_a_reason(self):
        for bad, code in (("30x", "unit"), ("0m", "zero"), ("-5m", "negative"), ("30s", "too_short"), ("999d", "too_long"), ("12", "format")):
            with self.assertRaises(CommandError) as cm:
                interpret_args(C.MUTE, [bad, "reason"])
            self.assertEqual((cm.exception.code, cm.exception.detail), ("duration", code), bad)

    def test_untimed_commands_keep_digits_in_reason(self):
        for c in (C.KICK, C.WARN, C.UNBAN, C.UNMUTE, C.CLEARWARNS, C.WARNINGS):
            a = interpret_args(c, ["3", "times", "30m"])
            self.assertEqual((a.duration_seconds, a.permanent, a.reason), (None, False, "3 times 30m"), c)

    def test_reason_sanitized_and_empty(self):
        a = interpret_args(C.WARN, ["bad\u0007", "word\u202e"])
        self.assertEqual(a.reason, "bad word")
        self.assertIsNone(interpret_args(C.WARN, ["\u0007"]).reason)
        with self.assertRaises(CommandError) as cm:
            interpret_args(C.WARN, ["w"] * 21)
        self.assertEqual(cm.exception.code, "too_many_args")


class EndToEndParsing(unittest.TestCase):
    def test_reply_mute_with_duration_and_reason(self):
        p = parse_command("/mute 30m spam", BOT)
        token, rest = split_target_args(list(p.args), ReplyInfo(5001))
        self.assertIsNone(token)
        self.assertEqual(interpret_args(p.command, rest).duration_seconds, 1800)

    def test_id_target_then_duration(self):
        p = parse_command("كتم @ali_user 2س تكرار", BOT)
        token, rest = split_target_args(list(p.args), None)
        a = interpret_args(p.command, rest)
        self.assertEqual((token, a.duration_seconds, a.reason), ("@ali_user", 7200, "تكرار"))


if __name__ == "__main__":
    unittest.main()
