"""Warnings / sanctions: models, in-memory stores, services (permissions, isolation, audit, idempotency)."""
import unittest
from datetime import timedelta

from guardian.audit import (SANCTION_LIFTED, SANCTION_RECORDED, WARNING_ISSUED, WARNING_REVOKED,
                            WARNINGS_CLEARED)
from guardian.errors import GroupNotRegistered, InvalidInput, PermissionDenied
from guardian.groups.models import GroupRole
from guardian.moderation.memory_store import InMemorySanctionStore, InMemoryWarningStore
from guardian.moderation.models import (MAX_TEMP_SECONDS, MIN_TEMP_SECONDS, ModerationWarning, Sanction,
                                        SanctionKind as K, check_expiry, check_group_id, check_user_id)
from stack import A, B, DELEGATE, NOW, OWNER, STRANGER, TG_ADMIN, TG_CREATOR, Stack

U1, U2 = 5001, 5002


def types(stack, group=A):
    return [e.event_type for e in stack.audit.events if e.group_id == group]


class ModelTests(unittest.TestCase):
    def test_warning_activity(self):
        w = ModerationWarning(1, A, U1, OWNER, None, NOW, NOW + timedelta(days=1))
        self.assertTrue(w.is_active(NOW))
        self.assertFalse(w.is_active(NOW + timedelta(days=1)))  # expiry instant is inactive
        self.assertFalse(ModerationWarning(1, A, U1, OWNER, None, NOW, revoked_at=NOW, revoked_by=OWNER).is_active(NOW))
        self.assertTrue(ModerationWarning(1, A, U1, None, None, NOW).is_active(NOW + timedelta(days=9999)))

    def test_sanction_activity(self):
        s = Sanction(1, A, U1, K.MUTE, None, None, NOW, NOW + timedelta(seconds=60))
        self.assertTrue(s.automatic and s.is_active(NOW) and not s.is_active(NOW + timedelta(seconds=60)))
        self.assertTrue(Sanction(1, A, U1, K.BAN, OWNER, None, NOW).is_active(NOW + timedelta(days=9999)))
        self.assertFalse(Sanction(1, A, U1, K.BAN, OWNER, None, NOW, lifted_at=NOW, lifted_by=OWNER).is_active(NOW))
        self.assertFalse(Sanction(1, A, U1, K.KICK, OWNER, None, NOW).is_active(NOW))  # a kick is never "in force"

    def test_expiry_bounds(self):
        ok = lambda sec: check_expiry(K.MUTE, NOW, NOW + timedelta(seconds=sec))
        self.assertIsNone(check_expiry(K.BAN, NOW, None))
        ok(MIN_TEMP_SECONDS), ok(MAX_TEMP_SECONDS)
        for bad in (MIN_TEMP_SECONDS - 1, 0, -5, MAX_TEMP_SECONDS + 1):
            with self.assertRaises(InvalidInput):
                ok(bad)
        with self.assertRaises(InvalidInput):
            check_expiry(K.KICK, NOW, NOW + timedelta(hours=1))
        with self.assertRaises(InvalidInput):
            check_expiry(K.MUTE, NOW, NOW.replace(tzinfo=None) + timedelta(hours=1))

    def test_id_validation(self):
        for bad in (0, -1, True, "5", None, 2**63):
            with self.assertRaises(InvalidInput):
                check_user_id(bad)
        for bad in (0, 5, True, "-1", None):
            with self.assertRaises(InvalidInput):
                check_group_id(bad)
        self.assertEqual((check_user_id(7), check_group_id(-7)), (7, -7))


class WarningStoreTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.st = InMemoryWarningStore()

    async def test_add_list_count_and_expiry(self):
        await self.st.add(A, U1, OWNER, "r1", NOW)
        await self.st.add(A, U1, OWNER, "r2", NOW + timedelta(minutes=1), NOW + timedelta(days=1))
        self.assertEqual(await self.st.count_active(A, U1, NOW + timedelta(hours=1)), 2)
        self.assertEqual(await self.st.count_active(A, U1, NOW + timedelta(days=2)), 1)  # second expired
        self.assertEqual([w.reason for w in await self.st.list_active(A, U1, NOW + timedelta(hours=1))], ["r1", "r2"])

    async def test_idempotency_key_is_per_group(self):
        w1, c1 = await self.st.add(A, U1, OWNER, None, NOW, idempotency_key="k1")
        w2, c2 = await self.st.add(A, U1, OWNER, None, NOW, idempotency_key="k1")
        w3, c3 = await self.st.add(B, U1, OWNER, None, NOW, idempotency_key="k1")
        self.assertEqual((c1, c2, c3, w1.id == w2.id, w3.id != w1.id), (True, False, True, True, True))
        self.assertEqual(await self.st.count_active(A, U1, NOW), 1)

    async def test_revoke_all_scoped_to_group_and_user(self):
        for g, u in ((A, U1), (A, U1), (A, U2), (B, U1)):
            await self.st.add(g, u, OWNER, None, NOW)
        self.assertEqual(await self.st.revoke_all(A, U1, OWNER, NOW), 2)
        self.assertEqual(await self.st.revoke_all(A, U1, OWNER, NOW), 0)  # idempotent
        self.assertEqual((await self.st.count_active(A, U2, NOW), await self.st.count_active(B, U1, NOW)), (1, 1))

    async def test_revoke_one_cannot_cross_groups(self):
        w, _ = await self.st.add(A, U1, OWNER, None, NOW)
        self.assertFalse(await self.st.revoke_one(B, w.id, OWNER, NOW))
        self.assertTrue(await self.st.revoke_one(A, w.id, OWNER, NOW))
        self.assertFalse(await self.st.revoke_one(A, w.id, OWNER, NOW))
        self.assertEqual(await self.st.count_active(A, U1, NOW), 0)


class SanctionStoreTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.st = InMemorySanctionStore()

    async def test_record_idempotent_and_foreign_key_rejected(self):
        s1, c1 = await self.st.record(A, U1, K.MUTE, None, None, NOW, NOW + timedelta(minutes=10), "links", "op:x")
        s2, c2 = await self.st.record(A, U1, K.MUTE, None, None, NOW, NOW + timedelta(minutes=10), "links", "op:x")
        self.assertEqual((c1, c2, s1.id), (True, False, s2.id))
        with self.assertRaises(InvalidInput):  # same key from another group: never reuse/leak that row
            await self.st.record(B, U1, K.MUTE, None, None, NOW, None, None, "op:x")

    async def test_active_excludes_expired_lifted_and_kicks(self):
        await self.st.record(A, U1, K.MUTE, OWNER, None, NOW, NOW + timedelta(minutes=5))
        await self.st.record(A, U1, K.BAN, OWNER, None, NOW)
        await self.st.record(A, U1, K.KICK, OWNER, None, NOW)
        self.assertEqual({s.kind for s in await self.st.get_active(A, U1, NOW)}, {K.MUTE, K.BAN})
        later = NOW + timedelta(minutes=6)
        self.assertEqual([s.kind for s in await self.st.get_active(A, U1, later)], [K.BAN])
        self.assertEqual(await self.st.get_active(A, U1, NOW, (K.KICK,)), [])
        self.assertEqual(await self.st.lift(A, U1, K.BAN, OWNER, later), 1)
        self.assertEqual(await self.st.get_active(A, U1, later), [])
        self.assertEqual(await self.st.lift(A, U1, K.BAN, OWNER, later), 0)  # idempotent

    async def test_lift_is_scoped(self):
        await self.st.record(A, U1, K.MUTE, OWNER, None, NOW)
        await self.st.record(B, U1, K.MUTE, OWNER, None, NOW)
        await self.st.record(A, U2, K.MUTE, OWNER, None, NOW)
        self.assertEqual(await self.st.lift(A, U1, K.MUTE, OWNER, NOW), 1)
        self.assertEqual((len(await self.st.get_active(B, U1, NOW)), len(await self.st.get_active(A, U2, NOW))), (1, 1))

    async def test_count_auto_mutes_only_automatic_mutes_in_window(self):
        await self.st.record(A, U1, K.MUTE, None, None, NOW)                          # counts
        await self.st.record(A, U1, K.MUTE, None, None, NOW - timedelta(days=2))      # outside window
        await self.st.record(A, U1, K.MUTE, OWNER, None, NOW)                         # manual: never escalates
        await self.st.record(A, U1, K.BAN, None, None, NOW)                           # not a mute
        await self.st.record(B, U1, K.MUTE, None, None, NOW)                          # other group
        await self.st.record(A, U2, K.MUTE, None, None, NOW)                          # other user
        self.assertEqual(await self.st.count_auto_mutes(A, U1, NOW - timedelta(days=1)), 1)
        self.assertEqual(await self.st.count_auto_mutes(A, U1, NOW), 0)  # strictly after the cut-off


class ModerationServiceBase(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A, B)


class WarningServiceTests(ModerationServiceBase):
    async def test_admin_warns_counts_and_audits(self):
        w, n, created = await self.s.warnings.warn(TG_ADMIN, A, U1, "spam\x00 now", context_chat_id=A)
        self.assertEqual((n, created, w.issued_by, w.reason), (1, True, TG_ADMIN, "spam now"))
        _, n2, _ = await self.s.warnings.warn(TG_ADMIN, A, U1, None, context_chat_id=A)
        self.assertEqual(n2, 2)
        self.assertEqual(types(self.s).count(WARNING_ISSUED), 2)

    async def test_non_moderators_denied_and_nothing_written(self):
        for actor in (STRANGER, 0, None, True):
            with self.assertRaises(PermissionDenied):
                await self.s.warnings.warn(actor, A, U1, context_chat_id=A)
        self.assertEqual(await self.s.warning_store.count_active(A, U1, NOW), 0)

    async def test_admin_of_one_group_cannot_act_on_another(self):
        with self.assertRaises(PermissionDenied):  # TG_ADMIN is admin of A only
            await self.s.warnings.warn(TG_ADMIN, B, U1, context_chat_id=B)
        with self.assertRaises(PermissionDenied):  # typed in A but aimed at B
            await self.s.warnings.warn(TG_CREATOR, B, U1, context_chat_id=A)

    async def test_delegated_moderator_and_owner_allowed(self):
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.MODERATOR, context_chat_id=A)
        await self.s.warnings.warn(DELEGATE, A, U1, context_chat_id=A)
        await self.s.warnings.warn(OWNER, A, U1, context_chat_id=A)
        self.assertEqual(await self.s.warnings.count_active(OWNER, A, U1, context_chat_id=A), 2)

    async def test_unregistered_group_and_bad_ids(self):
        with self.assertRaises(GroupNotRegistered):
            await self.s.warnings.warn(OWNER, -5555, U1)
        for bad in (0, -3, True, "9"):
            with self.assertRaises(InvalidInput):
                await self.s.warnings.warn(OWNER, A, bad)
        with self.assertRaises(InvalidInput):
            await self.s.warnings.warn(OWNER, 5, U1)  # group ids are negative

    async def test_idempotent_redelivery_adds_one_warning_and_one_audit(self):
        r1 = await self.s.warnings.warn(OWNER, A, U1, idempotency_key="op:warn:A:1")
        r2 = await self.s.warnings.warn(OWNER, A, U1, idempotency_key="op:warn:A:1")
        self.assertEqual((r1[2], r2[2], r2[1]), (True, False, 1))
        self.assertEqual(types(self.s).count(WARNING_ISSUED), 1)

    async def test_clear_revokes_only_that_user_and_group(self):
        for g, u in ((A, U1), (A, U1), (A, U2), (B, U1)):
            await self.s.warnings.warn(OWNER, g, u)
        self.assertEqual(await self.s.warnings.clear(OWNER, A, U1), 2)
        self.assertEqual(await self.s.warnings.clear(OWNER, A, U1), 0)
        self.assertEqual(types(self.s).count(WARNINGS_CLEARED), 1)
        self.assertEqual(await self.s.warnings.count_active(OWNER, B, U1), 1)
        self.assertEqual(await self.s.warnings.count_active(OWNER, A, U2), 1)

    async def test_expiry_and_revoke_one(self):
        w, _, _ = await self.s.warnings.warn(OWNER, A, U1, expires_at=NOW + timedelta(days=1))
        await self.s.warnings.warn(OWNER, A, U1)
        self.s.clock.advance(days=2)
        self.assertEqual(await self.s.warnings.count_active(OWNER, A, U1), 1)
        with self.assertRaises(InvalidInput):
            await self.s.warnings.warn(OWNER, A, U1, expires_at=self.s.clock() - timedelta(seconds=1))
        w2 = (await self.s.warnings.list_active(OWNER, A, U1))[0]
        self.assertFalse(await self.s.warnings.revoke(OWNER, B, w2.id))   # other group: nothing
        self.assertTrue(await self.s.warnings.revoke(OWNER, A, w2.id))
        self.assertEqual(types(self.s).count(WARNING_REVOKED), 1)

    async def test_reason_is_sanitized_and_bounded(self):
        w, _, _ = await self.s.warnings.warn(OWNER, A, U1, "x" * 900)
        self.assertLessEqual(len(w.reason), 500)
        w, _, _ = await self.s.warnings.warn(OWNER, A, U1, "   ")
        self.assertIsNone(w.reason)
        with self.assertRaises(InvalidInput):
            await self.s.warnings.warn(OWNER, A, U1, 123)


class SanctionServiceTests(ModerationServiceBase):
    async def test_record_temp_permanent_and_audit(self):
        m, c = await self.s.sanctions.record(TG_ADMIN, A, U1, K.MUTE, reason="spam",
                                             expires_at=NOW + timedelta(hours=1), context_chat_id=A)
        b, _ = await self.s.sanctions.record(TG_ADMIN, A, U2, K.BAN, context_chat_id=A)
        self.assertEqual((c, m.issued_by, m.expires_at, b.expires_at), (True, TG_ADMIN, NOW + timedelta(hours=1), None))
        self.assertEqual(types(self.s).count(SANCTION_RECORDED), 2)
        detail = [e.detail for e in self.s.audit.events if e.event_type == SANCTION_RECORDED][0]
        self.assertIn("kind=mute", detail)
        self.assertIn("reason=spam", detail)

    async def test_validation(self):
        bad = [dict(kind=K.KICK, expires_at=NOW + timedelta(hours=1)),
               dict(kind=K.MUTE, expires_at=NOW + timedelta(seconds=5)),
               dict(kind=K.MUTE, expires_at=NOW - timedelta(hours=1)),
               dict(kind=K.MUTE, expires_at=NOW + timedelta(days=400)),
               dict(kind="mute")]
        for kw in bad:
            with self.assertRaises(InvalidInput, msg=str(kw)):
                await self.s.sanctions.record(OWNER, A, U1, **kw)
        self.assertEqual(await self.s.sanction_store.get_active(A, U1, NOW), [])

    async def test_permissions_and_isolation(self):
        with self.assertRaises(PermissionDenied):
            await self.s.sanctions.record(STRANGER, A, U1, K.MUTE, context_chat_id=A)
        with self.assertRaises(PermissionDenied):
            await self.s.sanctions.record(TG_ADMIN, B, U1, K.MUTE, context_chat_id=B)
        with self.assertRaises(PermissionDenied):
            await self.s.sanctions.lift(STRANGER, A, U1, K.MUTE, context_chat_id=A)
        with self.assertRaises(GroupNotRegistered):
            await self.s.sanctions.record(OWNER, -777, U1, K.MUTE)
        await self.s.sanctions.record(OWNER, A, U1, K.MUTE)
        self.assertEqual(await self.s.sanctions.active(OWNER, B, U1), [])

    async def test_lift_and_idempotent_record(self):
        r1 = await self.s.sanctions.record(OWNER, A, U1, K.BAN, idempotency_key="op:ban:A:1")
        r2 = await self.s.sanctions.record(OWNER, A, U1, K.BAN, idempotency_key="op:ban:A:1")
        self.assertEqual((r1[1], r2[1]), (True, False))
        self.assertEqual(types(self.s).count(SANCTION_RECORDED), 1)
        self.assertEqual(await self.s.sanctions.lift(OWNER, A, U1, K.BAN), 1)
        self.assertEqual(await self.s.sanctions.lift(OWNER, A, U1, K.BAN), 0)
        self.assertEqual(types(self.s).count(SANCTION_LIFTED), 1)
        with self.assertRaises(InvalidInput):
            await self.s.sanctions.lift(OWNER, A, U1, K.KICK)

    async def test_kick_is_recorded_but_never_active(self):
        await self.s.sanctions.record(OWNER, A, U1, K.KICK, reason="rude")
        self.assertEqual(await self.s.sanctions.active(OWNER, A, U1), [])


if __name__ == "__main__":
    unittest.main()
