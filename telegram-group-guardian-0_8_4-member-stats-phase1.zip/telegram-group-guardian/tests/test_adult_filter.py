"""Part 9.1: adult / explicit WORD filter (detection, settings, `/protect adult`, engine behaviour).

Self-contained on purpose: it does not import `guardian.bot` (aiogram), so it runs wherever the core package runs.
"""
import unittest
from datetime import timedelta

from guardian.groups.models import GroupRole  # noqa: F401  (keeps the import graph identical to the engine tests)
from guardian.idempotency import InMemoryIdempotency
from guardian.moderation.command_error import CommandError
from guardian.moderation.config_args import parse_protect_args
from guardian.protection.adult_words import MAX_CUSTOM_WORDS, find_adult, normalize_word
from guardian.protection.engine import ActionResult, MessageView, OutcomeKind, ProtectionEngine
from guardian.protection.settings import ProtectionSettings
from guardian.protection_gate import ProtectionGate
from guardian.telegram_rights import ChatMemberInfo
from helpers import FakeNotifier
from stack import A, OWNER, STRANGER, Stack

BOT = 777


class DetectionTests(unittest.TestCase):
    def test_plain_and_evasions_are_found(self):
        for text in ("سكس", "شاهد سكسسسس الان", "س ك س", "والسكس", "بالسكس", "نـيـك", "سَكْس", "p0rn", "p o r n", "p.o.r.n",
                     "PORN", "XXX videos", "افلام اباحية", "مقاطع  اباحيه", "Sex Video here", "pornhub.com/view",
                     "o n l y f a n s", "كسمك"):
            self.assertIsNotNone(find_adult(text), text)

    def test_harmless_words_are_not_found(self):
        for text in ("مرحبا بكم", "Bob's pizza", "scunthorpe", "analysis", "class", "كسر", "سكسونيا", "نيكولا", "زبدة",
                     "hello world", "x", "عاري عن الصحة", "the sextant", "الجنس البشري", "assess", "cocktail", "", None, 5):
            self.assertIsNone(find_adult(text), text)

    def test_custom_words(self):
        self.assertIsNone(find_adult("this is badword here"))
        self.assertEqual(find_adult("this is BADWORD here", ("badword",)), "badword")
        stored = normalize_word("الكلمةالسيئة")  # custom words are stored folded (see `/protect adult add`)
        self.assertEqual(find_adult("والكلمةالسيئة", (stored,)), stored)

    def test_normalize_word(self):
        self.assertEqual(normalize_word("كلمة"), "كلمه")
        for bad in ("a b", "x", "", "a" * 31, 7, None, "word!"):
            self.assertIsNone(normalize_word(bad), bad)


class SettingsAndParserTests(unittest.TestCase):
    def test_defaults_and_clamping(self):
        s = ProtectionSettings.from_raw({})
        self.assertTrue(s.adult_enabled)
        self.assertEqual(s.adult_custom_words, ())
        s = ProtectionSettings.from_raw({"adult_enabled": "no", "adult_custom_words": ["كلمة", "x", "a b", "كلمه", 5, "ok"]})
        self.assertTrue(s.adult_enabled)  # a non-bool falls back to the default
        self.assertEqual(s.adult_custom_words, ("كلمه", "ok"))
        s = ProtectionSettings.from_raw({"adult_custom_words": [f"{chr(97 + i % 26)}9{chr(97 + i // 26)}9" for i in range(MAX_CUSTOM_WORDS + 20)]})
        self.assertEqual(len(s.adult_custom_words), MAX_CUSTOM_WORDS)

    def test_parser(self):
        self.assertEqual(parse_protect_args(["adult", "off"]).patch, {"adult_enabled": False})
        self.assertEqual(parse_protect_args(["الاباحي", "on"]).patch, {"adult_enabled": True})
        self.assertEqual(parse_protect_args(["adult", "list"]).op, "adult_list")
        self.assertEqual(parse_protect_args(["adult", "clear"]).op, "adult_clear")
        p = parse_protect_args(["adult", "add", "كلمة", "other", "other"])
        self.assertEqual((p.op, p.words), ("adult_add", ("كلمه", "other")))
        self.assertEqual(parse_protect_args(["adult", "remove", "other"]).op, "adult_remove")
        for bad in (["adult"], ["adult", "add"], ["adult", "add", "a b"], ["adult", "maybe"], ["adult", "on", "off"]):
            with self.assertRaises(CommandError, msg=str(bad)):
                parse_protect_args(bad)


class FakeActions:
    def __init__(self):
        self.deleted, self.muted = [], []

    async def delete_message(self, chat_id, message_id):
        self.deleted.append((chat_id, message_id))
        return ActionResult(True)

    async def mute_member(self, chat_id, user_id, until):
        self.muted.append((chat_id, user_id, until))
        return ActionResult(True)


class EngineTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A)
        await self.s.admin.activate_permanent(OWNER, A)
        self.s.chat.set(A, BOT, ChatMemberInfo("administrator", True, True, True))
        self.actions = FakeActions()
        self.engine = ProtectionEngine(self.s.settings_store, self.actions, self.s.chat, InMemoryIdempotency(),
                                       self.s.audit, FakeNotifier(), clock=self.s.clock)
        self.gate = ProtectionGate(self.s.license_service, self.s.perm, FakeNotifier(), clock=self.s.clock)
        self.mid = 0

    async def cfg(self, **patch):
        await self.s.settings_store.merge(A, patch, OWNER, self.s.clock())

    async def send(self, text, user=STRANGER, edit=False):
        self.mid += 1
        ctx = await self.gate.evaluate(A, "supergroup", user)
        return await self.engine.handle(ctx, MessageView(A, user, self.mid, text, (), edit), self.s.clock())

    async def test_adult_word_deleted_and_muted_with_escalation(self):
        o = await self.send("شاهد سكس مجاني")
        self.assertEqual((o.kind, o.violation, o.deleted, o.muted_seconds), (OutcomeKind.ACTED, "adult", True, 600))
        self.assertEqual(self.actions.deleted, [(A, 1)])
        self.s.clock.advance(seconds=700)
        self.assertEqual((await self.send("p0rn")).muted_seconds, 3600)

    async def test_harmless_message_untouched(self):
        self.assertEqual((await self.send("مرحبا بالجميع")).kind, OutcomeKind.NONE)
        self.assertEqual(self.actions.deleted, [])

    async def test_edit_is_checked(self):
        o = await self.send("porn", edit=True)
        self.assertEqual((o.kind, o.violation), (OutcomeKind.ACTED, "adult"))

    async def test_filter_off(self):
        await self.cfg(adult_enabled=False)
        self.assertEqual((await self.send("porn")).kind, OutcomeKind.NONE)

    async def test_custom_word(self):
        await self.cfg(adult_custom_words=["badword"])
        self.assertEqual((await self.send("a BADWORD b")).violation, "adult")

    async def test_owner_and_admins_are_exempt(self):
        self.assertEqual((await self.send("porn", user=OWNER)).kind, OutcomeKind.NONE)

    async def test_dry_run_does_nothing(self):
        await self.cfg(dry_run=True)
        o = await self.send("porn")
        self.assertEqual((o.kind, o.violation), (OutcomeKind.DRY_RUN, "adult"))
        self.assertEqual((self.actions.deleted, self.actions.muted), ([], []))


if __name__ == "__main__":
    unittest.main()
