import tempfile
import unittest
from pathlib import Path

from guardian.db.migrations import SQL_DIR, checksum, discover, run_migrations
from guardian.errors import MigrationError
from helpers import FakeConn


def make_dir(files: dict[str, str]) -> tempfile.TemporaryDirectory:
    tmp = tempfile.TemporaryDirectory()
    for name, sql in files.items():
        (Path(tmp.name) / name).write_text(sql, encoding="utf-8")
    return tmp


class DiscoveryTests(unittest.TestCase):
    def test_shipped_migrations_are_valid(self):
        found = discover(SQL_DIR)
        self.assertTrue(found)
        self.assertEqual(found[0][0], "0001_initial")

    def test_bad_name_rejected(self):
        with make_dir({"init.sql": "SELECT 1;"}) as d, self.assertRaises(MigrationError):
            discover(Path(d))

    def test_duplicate_number_rejected(self):
        with make_dir({"0001_a.sql": "SELECT 1;", "0001_b.sql": "SELECT 2;"}) as d, self.assertRaises(MigrationError):
            discover(Path(d))


class RunnerTests(unittest.IsolatedAsyncioTestCase):
    async def test_applies_in_order_then_is_idempotent(self):
        with make_dir({"0002_b.sql": "SELECT 2;", "0001_a.sql": "SELECT 1;"}) as d:
            conn = FakeConn()
            applied = await run_migrations(conn, Path(d))
            self.assertEqual(applied, ["0001_a", "0002_b"])
            self.assertEqual(set(conn.applied), {"0001_a", "0002_b"})
            self.assertEqual(await run_migrations(conn, Path(d)), [])

    async def test_lock_taken_first_and_released_last(self):
        with make_dir({"0001_a.sql": "SELECT 1;"}) as d:
            conn = FakeConn()
            await run_migrations(conn, Path(d))
            self.assertIn("pg_advisory_lock", conn.log[0])
            self.assertIn("pg_advisory_unlock", conn.log[-1])

    async def test_modified_applied_migration_is_rejected_and_lock_released(self):
        with make_dir({"0001_a.sql": "SELECT 1;"}) as d:
            conn = FakeConn(applied={"0001_a": checksum("SELECT 'old';")})
            with self.assertRaises(MigrationError):
                await run_migrations(conn, Path(d))
            self.assertIn("pg_advisory_unlock", conn.log[-1])

    async def test_failing_migration_rolls_back_and_is_not_recorded(self):
        with make_dir({"0001_a.sql": "SELECT 1;", "0002_b.sql": "BOOM statement;"}) as d:
            conn = FakeConn(fail_on="BOOM")
            with self.assertRaises(RuntimeError):
                await run_migrations(conn, Path(d))
            self.assertEqual(set(conn.applied), {"0001_a"})
            self.assertEqual(conn.rollbacks, 1)
            self.assertIn("pg_advisory_unlock", conn.log[-1])


if __name__ == "__main__":
    unittest.main()
