import unittest
from datetime import datetime, timedelta, timezone

from guardian.licensing.models import AuditEvent, DenyReason, GroupLicense, LicenseStatus, evaluate

NOW = datetime(2026, 10, 29, 12, 0, tzinfo=timezone.utc)


def lic(status, expires_at=None, **kw):
    return GroupLicense(group_id=-1001, title="g", status=status, updated_at=NOW, expires_at=expires_at, **kw)


class ModelTests(unittest.TestCase):
    def test_permanent_requires_null_expiry(self):
        with self.assertRaises(ValueError):
            lic(LicenseStatus.ACTIVE_PERMANENT, expires_at=NOW + timedelta(days=1))
        self.assertIsNone(lic(LicenseStatus.ACTIVE_PERMANENT).expires_at)

    def test_temporary_requires_expiry(self):
        with self.assertRaises(ValueError):
            lic(LicenseStatus.ACTIVE_TEMPORARY)

    def test_naive_datetimes_rejected(self):
        with self.assertRaises(ValueError):
            GroupLicense(group_id=1, title=None, status=LicenseStatus.PENDING, updated_at=datetime(2026, 1, 1))
        with self.assertRaises(ValueError):
            AuditEvent(1, "x", None, LicenseStatus.PENDING, datetime(2026, 1, 1))

    def test_seven_statuses_exist_with_stable_names(self):
        self.assertEqual(
            {s.value for s in LicenseStatus},
            {"pending", "active_permanent", "active_temporary", "expired", "stopped", "rejected", "banned"},
        )


class EvaluateTests(unittest.TestCase):
    def test_unknown_group_denied(self):
        d = evaluate(None, NOW)
        self.assertFalse(d.allowed)
        self.assertIs(d.reason, DenyReason.NOT_REGISTERED)

    def test_permanent_allowed(self):
        self.assertTrue(evaluate(lic(LicenseStatus.ACTIVE_PERMANENT), NOW).allowed)

    def test_temporary_before_at_after_expiry(self):
        expiry = NOW + timedelta(hours=1)
        l = lic(LicenseStatus.ACTIVE_TEMPORARY, expires_at=expiry)
        self.assertTrue(evaluate(l, expiry - timedelta(seconds=1)).allowed)
        at = evaluate(l, expiry)  # boundary: expired exactly at expires_at
        self.assertFalse(at.allowed)
        self.assertTrue(at.expired_by_time)
        self.assertIs(at.status, LicenseStatus.EXPIRED)
        self.assertFalse(evaluate(l, expiry + timedelta(days=30)).allowed)

    def test_every_non_active_status_denied(self):
        for status in (LicenseStatus.PENDING, LicenseStatus.EXPIRED, LicenseStatus.STOPPED, LicenseStatus.REJECTED, LicenseStatus.BANNED):
            with self.subTest(status=status):
                d = evaluate(lic(status), NOW)
                self.assertFalse(d.allowed)
                self.assertIsNot(d.reason, DenyReason.NONE)

    def test_naive_now_rejected(self):
        with self.assertRaises(ValueError):
            evaluate(lic(LicenseStatus.PENDING), datetime(2026, 1, 1))


if __name__ == "__main__":
    unittest.main()
