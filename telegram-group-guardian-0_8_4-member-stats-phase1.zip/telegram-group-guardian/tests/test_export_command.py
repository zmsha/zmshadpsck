"""Part 6.7b: `/export settings|license` (the command, its strict arguments, the two exporters, the gates and the private
delivery). PostgreSQL / aiogram / Telegram are NOT exercised (fakes only)."""
from __future__ import annotations

import ast
import json
import re
import string
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace as NS

from executor_stack import A, B, BOT, BOT_NAME, USER, BrokenClaims, ExecBase, gate
from guardian.audit import (COMMAND_REJECTED, EXPORT_DELIVERED, EXPORT_FAILED, EXPORT_REQUESTED, PERMISSION_DENIED,
                            InMemorySecurityAudit)
from guardian.bot import commands_menu
from guardian.bot import moderation_handler as mh
from guardian.export import args as ea
from guardian.export import models as m
from guardian.export.delivery import ExportDelivery
from guardian.export.license_export import HISTORY_LIMIT, build_license_export
from guardian.export.models import DeliveryResult, ExportFile, PrivateChatUnavailable
from guardian.export.settings_export import build_settings_export
from guardian.i18n import MESSAGES, t
from guardian.licensing.models import AuditEvent, GroupLicense, LicenseStatus
from guardian.moderation.commands import EXPORT_COMMANDS, PUBLIC, Command, CommandError, parse_command
from guardian.moderation.executor import ModerationCommandService, ResultKind as R
from guardian.owner_hub.redactor import _looks_secret_name
from guardian.owner_templates.templates import TEMPLATE_KEYS
from guardian.permissions import GroupRole
from stack import BACKUP, DELEGATE, NOW, OWNER, STRANGER, TG_ADMIN, TG_LIMITED_ADMIN
from test_export_delivery import FakeTransport

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src" / "guardian"
TZ = "Asia/Riyadh"


def p(text: str, reply: bool = False):
    return parse_command(text, BOT_NAME, has_reply=reply)


def read(rel: str) -> str:
    return (SRC / rel).read_text(encoding="utf-8")


# ------------------------------------------------------------------------------------------------ arguments
class ArgsTests(unittest.TestCase):
    def test_words_in_both_languages_after_folding(self):
        for words, what in ((("settings", "SETTINGS", "setting", "الاعدادات", "الإعدادات", "إعدادات", "اعدادات"), ea.SETTINGS),
                            (("license", "licence", "الترخيص", "ترخيص", "الرخصة"), ea.LICENSE)):
            for w in words:
                with self.subTest(w):
                    self.assertEqual(ea.parse_export((w,)).what, what)

    def test_exactly_one_known_word(self):
        for bad in ((), ("settings", "license"), ("settings", "x"), ("everything",), ("-1002",), ("all",), ("",)):
            with self.subTest(bad):
                with self.assertRaises(CommandError) as ctx:
                    ea.parse_export(bad)
                self.assertEqual(ctx.exception.code, "export_usage")

    def test_reports_and_audit_are_available_since_6_7c_with_csv_as_the_default(self):
        for w, what in (("reports", ea.REPORTS), ("البلاغات", ea.REPORTS), ("audit", ea.AUDIT), ("التدقيق", ea.AUDIT), ("log", ea.AUDIT)):
            with self.subTest(w):
                req = ea.parse_export((w,))
                self.assertEqual((req.what, req.fmt), (what, "csv"))

    def test_the_slash_command_and_the_arabic_alias_parse(self):
        self.assertIs(p("/export settings").command, Command.EXPORT)
        self.assertIs(p("/EXPORT@GuardianBot license").command, Command.EXPORT)
        self.assertIsNone(p("/export@OtherBot settings"))
        for text in ("تصدير الاعدادات", "تصدير الإعدادات", "تصدير الترخيص", "تصدير ترخيص"):
            with self.subTest(text):
                parsed = p(text)
                self.assertIs(parsed.command, Command.EXPORT)
                self.assertTrue(parsed.arabic)

    def test_ordinary_chat_with_the_word_is_not_a_command(self):
        for text in ("تصدير", "تصدير البضائع الى الخارج", "تصدير الاعدادات الى الخارج", "تصدير الترخيص الان", "تصدير الاعدادات والترخيص"):
            with self.subTest(text):
                self.assertIsNone(p(text))
                self.assertIsNone(p(text, reply=True))

    def test_it_is_a_moderator_command_not_a_public_one(self):
        self.assertNotIn(Command.EXPORT, PUBLIC)
        self.assertEqual(EXPORT_COMMANDS, {Command.EXPORT})
        self.assertRegex(Command.EXPORT.value, r"^[a-z0-9_]{1,32}$")


# ------------------------------------------------------------------------------------------------ settings exporter
class SettingsExportTests(unittest.TestCase):
    def test_defaults_file_shape(self):
        f = build_settings_export(A, {}, NOW)
        self.assertEqual((f.kind, f.name, f.rows), ("json", "settings_1001_20261029", len(TEMPLATE_KEYS)))
        body = json.loads(f.content)
        self.assertEqual(body["format"], "guardian-settings-export")
        self.assertEqual((body["version"], body["group_id"], body["exported_at"]), (1, A, "2026-10-29T12:00:00Z"))
        self.assertEqual(list(body["settings"]), list(TEMPLATE_KEYS))           # exactly the template keys, in order
        self.assertEqual(body["customized"], [])
        self.assertNotIn("dry_run", body["settings"])
        self.assertIsInstance(body["settings"]["escalation_mutes_seconds"], list)   # tuples became JSON lists

    def test_customized_lists_only_what_differs_and_unknown_keys_never_appear(self):
        raw = {"warn_limit": 5, "welcome_enabled": True, "welcome_text": "أهلاً {name}", "unknown_key": "x", "dry_run": True,
               "reports_destination": -100123}
        body = json.loads(build_settings_export(A, raw, NOW).content)
        self.assertEqual(body["customized"], ["warn_limit", "welcome_enabled", "welcome_text"])
        self.assertEqual(body["settings"]["warn_limit"], 5)
        self.assertEqual(body["settings"]["welcome_text"], "أهلاً {name}")
        text = json.dumps(body, ensure_ascii=False)
        for forbidden in ("unknown_key", "dry_run", "reports_destination", "-100123"):
            self.assertNotIn(forbidden, text)

    def test_junk_and_invalid_stored_values_fall_back_to_what_the_bot_really_uses(self):
        defaults = json.loads(build_settings_export(A, {}, NOW).content)["settings"]
        for raw in (None, "x", [], 5, {"warn_limit": "abc"}, {"warn_limit": -4}, {"flood_max_messages": {"a": 1}}):
            with self.subTest(raw):
                body = json.loads(build_settings_export(A, raw, NOW).content)
                self.assertEqual(set(body["settings"]), set(TEMPLATE_KEYS))
                if not isinstance(raw, dict):
                    self.assertEqual(body["settings"], defaults)
                    self.assertEqual(body["customized"], [])
                else:
                    self.assertEqual(body["settings"]["flood_max_messages"] > 0, True)

    def test_a_valid_name_for_any_group_id(self):
        for gid in (A, -1009876543210, -100):
            f = build_settings_export(gid, {}, NOW)
            self.assertTrue(re.fullmatch(r"settings_\d+_\d{8}", f.name), f.name)
            self.assertNotIn("-", f.name)

    def test_no_template_key_looks_like_a_secret_name(self):
        for key in TEMPLATE_KEYS:
            self.assertFalse(_looks_secret_name(key), key)


class RealisticSettingsSurviveTheScreen(unittest.IsolatedAsyncioTestCase):
    """The delivery's redactor masks long alphanumeric runs and `secret: value` pairs. A real settings file must not be hit."""

    async def test_defaults_and_a_heavily_customised_file_are_not_masked(self):
        raw = {"links_allow_domains": ["example.com", "sub.very-long-domain-name-for-testing.example.org", "t.me"],
               "welcome_enabled": True, "welcome_text": "مرحبًا {name} في {group} 👋\nالقواعد: https://example.com/rules?lang=ar\n" * 3,
               "verify_enabled": True, "verify_method": "button", "newbie_seconds": 3600, "warn_limit": 7, "slowmode_seconds": 30}
        transport = FakeTransport()
        delivery = ExportDelivery(transport, claims=_Claims(), audit=InMemorySecurityAudit(), secrets=("S3cret-Value-XYZ",), clock=lambda: NOW)
        for index, source in enumerate(({}, raw)):
            file = build_settings_export(A, source, NOW)
            result = await delivery.deliver(USER, file, key=f"k{index}")
            self.assertEqual((result.code, result.redactions), ("sent", 0), source)
            self.assertEqual(transport.sent[-1][2], file.data())               # the bytes are untouched
            self.assertNotIn("REDACTED", file.content)
        self.assertIn("very-long-domain-name-for-testing", transport.sent[-1][2].decode())


class _Claims:
    def __init__(self):
        self.keys = set()

    async def claim(self, key, now=None):
        if key in self.keys:
            return False
        self.keys.add(key)
        return True


# ------------------------------------------------------------------------------------------------ licence exporter
def lic(status, expires=None, **kw):
    return GroupLicense(A, "Secret Group Title", status, NOW, activated_at=NOW - timedelta(days=30), expires_at=expires,
                        activated_by=OWNER, note=kw.get("note"))


def ev(i, action="activate", to=LicenseStatus.ACTIVE_PERMANENT, frm=LicenseStatus.PENDING, by=OWNER, expires=None, reason=None):
    return AuditEvent(A, action, frm, to, NOW - timedelta(days=100 - i), by, expires, reason)


class LicenseExportTests(unittest.TestCase):
    def body(self, license_, history=(), now=NOW):
        f = build_license_export(A, license_, history, now, TZ)
        return f, json.loads(f.content)

    def test_permanent_is_marked_permanent_with_no_expiry(self):
        f, b = self.body(lic(LicenseStatus.ACTIVE_PERMANENT))
        self.assertEqual((f.kind, f.name), ("json", "license_1001_20261029"))
        self.assertEqual(b["format"], "guardian-license-export")
        lc = b["license"]
        self.assertEqual((lc["status"], lc["permanent"], lc["expires_at"], lc["expires_at_local"]), ("active_permanent", True, None, None))
        self.assertNotIn("stored_status", lc)

    def test_temporary_shows_utc_and_local_expiry(self):
        _, b = self.body(lic(LicenseStatus.ACTIVE_TEMPORARY, NOW + timedelta(days=10)))
        lc = b["license"]
        self.assertEqual((lc["status"], lc["permanent"]), ("active_temporary", False))
        self.assertEqual(lc["expires_at"], "2026-11-08T12:00:00Z")
        self.assertEqual(lc["expires_at_local"], "2026-11-08 15:00")           # Riyadh = UTC+3
        self.assertEqual(b["timezone"], TZ)

    def test_a_temporary_licence_past_its_time_reads_expired_with_the_stored_status_beside_it(self):
        _, b = self.body(lic(LicenseStatus.ACTIVE_TEMPORARY, NOW - timedelta(hours=1)))
        self.assertEqual((b["license"]["status"], b["license"]["stored_status"]), ("expired", "active_temporary"))
        self.assertFalse(b["license"]["permanent"])

    def test_other_states_and_an_unregistered_group(self):
        for status in (LicenseStatus.PENDING, LicenseStatus.STOPPED, LicenseStatus.REJECTED, LicenseStatus.BANNED, LicenseStatus.EXPIRED):
            with self.subTest(status):
                _, b = self.body(lic(status))
                self.assertEqual((b["license"]["status"], b["license"]["permanent"], b["license"]["expires_at"]), (status.value, False, None))
        _, b = self.body(None)
        self.assertEqual(b["license"], {"registered": False, "status": None})

    def test_history_is_oldest_first_with_the_fields_and_a_permanent_flag(self):
        history = [ev(1, "register_pending", LicenseStatus.PENDING, None, None),
                   ev(2, "activate_temporary", LicenseStatus.ACTIVE_TEMPORARY, expires=NOW + timedelta(days=5), reason="تجربة"),
                   ev(3, "activate_permanent", reason="دائم")]
        f, b = self.body(lic(LicenseStatus.ACTIVE_PERMANENT), history)
        self.assertEqual(f.rows, 3)
        rows = b["history"]
        self.assertEqual([r["action"] for r in rows], ["register_pending", "activate_temporary", "activate_permanent"])
        self.assertEqual([r["at"] for r in rows], sorted(r["at"] for r in rows))
        self.assertEqual((rows[0]["from"], rows[0]["by"], rows[0]["permanent"]), (None, None, False))
        self.assertEqual((rows[1]["to"], rows[1]["by"], rows[1]["expires_at"], rows[1]["permanent"]), ("active_temporary", OWNER, "2026-11-03T12:00:00Z", False))
        self.assertEqual((rows[2]["permanent"], rows[2]["expires_at"], rows[2]["reason"]), (True, None, "دائم"))
        self.assertTrue(all(r["at_local"] for r in rows))
        self.assertFalse(b["history_may_be_truncated"])

    def test_a_full_page_is_flagged_as_possibly_truncated(self):
        _, b = self.body(lic(LicenseStatus.ACTIVE_PERMANENT), [ev(i % 90) for i in range(HISTORY_LIMIT)])
        self.assertTrue(b["history_may_be_truncated"])
        self.assertEqual(b["history_limit"], HISTORY_LIMIT)
        _, b = self.body(lic(LicenseStatus.ACTIVE_PERMANENT), [ev(1) for _ in range(HISTORY_LIMIT - 1)])
        self.assertFalse(b["history_may_be_truncated"])

    def test_notes_and_reasons_are_cleaned_and_cut_and_the_title_never_appears(self):
        long = "x " * 400
        _, b = self.body(lic(LicenseStatus.ACTIVE_PERMANENT, note="line1\nline2\x00\u202e end"), [ev(1, reason=long), ev(2, reason=None), ev(3, reason="  ")])
        self.assertEqual(b["license"]["note"], "line1 line2 end")
        self.assertLessEqual(len(b["history"][0]["reason"]), 200)
        self.assertIsNone(b["history"][1]["reason"])
        self.assertIsNone(b["history"][2]["reason"])
        self.assertNotIn("Secret Group Title", json.dumps(b))

    def test_naive_now_is_rejected_not_guessed(self):
        with self.assertRaises(ValueError):
            build_license_export(A, None, [], datetime(2026, 1, 1), TZ)


# ------------------------------------------------------------------------------------------------ the command
class FakeDelivery:
    """Returns a fixed result; records what it was asked to send."""

    enabled = True

    def __init__(self, result):
        self.result, self.calls = result, []

    async def deliver(self, requester_id, file, *, key, caption=None, group_id=None):
        self.calls.append((requester_id, file, key, caption, group_id))
        return self.result


class SpyLicenses:
    def __init__(self, inner):
        self.inner, self.reads = inner, 0

    async def get(self, group_id):
        self.reads += 1
        return await self.inner.get(group_id)


class SpyQuery:
    def __init__(self, inner):
        self.inner, self.reads = inner, 0

    async def license_history(self, *a, **kw):
        self.reads += 1
        return await self.inner.license_history(*a, **kw)


class ExportBase(ExecBase):
    delivery_mode = "real"      # real | none | <DeliveryResult>

    async def asyncSetUp(self):
        self.transport = FakeTransport()
        await super().asyncSetUp()
        await self.s.admin.activate_permanent(OWNER, A, reason="initial")

    def make_service(self, claims):
        self.licenses = SpyLicenses(self.s.licenses)
        self.query = SpyQuery(self.s.audit_query)
        if self.delivery_mode == "none":
            self.delivery = None
        elif self.delivery_mode == "real":
            self.delivery = ExportDelivery(self.transport, claims=claims, audit=self.s.audit, secrets=("S3cret-Value-XYZ",), clock=self.s.clock)
        else:
            self.delivery = FakeDelivery(self.delivery_mode)
        return ModerationCommandService(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions,
            settings_store=self.s.settings_store, actions=self.actions, chat_info=self.s.chat, claims=claims,
            audit=self.s.audit, bot_id=BOT, clock=self.s.clock, group_settings=self.s.settings,
            export_delivery=self.delivery, licenses=self.licenses, audit_query=self.query, display_timezone=TZ)

    def events(self, kind):
        return [e for e in self.s.audit.events if e.event_type == kind]


class SettingsCommandTests(ExportBase):
    async def test_a_moderator_gets_the_file_in_private_and_the_group_a_one_liner(self):
        await self.settings(warn_limit=5, welcome_text="أهلًا {name}")
        r = await self.run_cmd("/export settings", msg=11)
        self.assertIs(r.kind, R.DONE)
        self.assertTrue(r.ok)
        self.assertIs(r.command, Command.EXPORT)
        self.assertIsNone(r.redirect_chat_id)
        self.assertEqual(len(self.transport.sent), 1)
        user_id, filename, data, caption = self.transport.sent[0]
        self.assertEqual((user_id, filename), (TG_ADMIN, "settings_1001_20261029.json"))
        body = json.loads(data)
        self.assertEqual((body["group_id"], body["settings"]["warn_limit"], body["customized"]), (A, 5, ["warn_limit", "welcome_text"]))
        self.assertIn(str(A), caption)
        # the group sees ONE short line: no content, no file, no setting names or values
        self.assertEqual(r.text, t("export_sent", "ar", what=t("export_what_settings", "ar")))
        for leak in ("warn_limit", "أهلًا", "{", "json", "5"):
            self.assertNotIn(leak, r.text)

    async def test_arabic_form_and_english_text(self):
        r = await self.run_cmd("تصدير الاعدادات", msg=12)
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(len(self.transport.sent), 1)

    async def test_the_destination_is_the_actor_never_the_group(self):
        for actor, msg in ((TG_ADMIN, 1), (OWNER, 2)):
            await self.run_cmd("/export settings", actor=actor, protection=gate(A, actor), msg=msg)
        self.assertEqual([s[0] for s in self.transport.sent], [TG_ADMIN, OWNER])
        self.assertTrue(all(s[0] > 0 for s in self.transport.sent))
        self.assertNotIn(A, [s[0] for s in self.transport.sent])

    async def test_the_group_is_the_chat_it_was_typed_in_never_the_text(self):
        for text in (f"/export settings {B}", f"/export {B}", "/export settings all"):
            r = await self.run_cmd(text)
            self.assertIs(r.kind, R.INVALID, text)
        self.assertEqual(self.transport.sent, [])
        await self.run_cmd("/export settings", msg=5)
        self.assertEqual(json.loads(self.transport.sent[0][2])["group_id"], A)

    async def test_it_works_during_dry_run_and_never_writes_settings(self):
        await self.settings(dry_run=True)
        before = (await self.s.settings_store.get(A)).settings
        r = await self.run_cmd("/export settings")
        self.assertIs(r.kind, R.DONE)
        self.assertEqual((await self.s.settings_store.get(A)).settings, before)
        self.assertNotIn("dry_run", json.loads(self.transport.sent[0][2])["settings"])

    async def test_audit_names_the_export_and_never_its_content(self):
        await self.settings(welcome_text="سري جدًا")
        await self.run_cmd("/export settings", msg=7)
        req = self.events(EXPORT_REQUESTED)
        self.assertEqual([(e.actor_telegram_id, e.group_id, e.target_id, e.result) for e in req], [(TG_ADMIN, A, "settings", "applied")])
        self.assertEqual(len(self.events(EXPORT_DELIVERED)), 1)
        blob = " ".join(f"{e.detail} {e.target_id}" for e in self.s.audit.events)
        for leak in ("سري جدًا", "warn_limit", "welcome_text", "settings_1001"):
            self.assertNotIn(leak, blob)

    async def test_a_read_failure_answers_a_safe_error_and_never_defaults(self):
        async def boom(group_id):
            raise RuntimeError("settings store down")
        self.s.settings_store.get = boom
        r = await self.run_cmd("/export settings")
        self.assertIs(r.kind, R.ERROR)
        self.assertEqual(r.text, t("action_failed_safe", "ar"))
        self.assertEqual(self.transport.sent, [])

    async def test_a_redelivered_update_sends_nothing_twice(self):
        first = await self.run_cmd("/export settings", msg=21)
        again = await self.run_cmd("/export settings", msg=21)           # Telegram retry inside the cooldown: silent
        self.assertIs(first.kind, R.DONE)
        self.assertEqual((again.kind, again.text), (R.THROTTLED, ""))
        self.s.clock.advance(seconds=31)
        late = await self.run_cmd("/export settings", msg=21)             # a retry after the cooldown: the durable claim stops it
        self.assertEqual((late.kind, late.text), (R.DUPLICATE, ""))
        self.assertEqual(len(self.transport.sent), 1)

    async def test_a_second_export_inside_the_cooldown_is_silent_and_a_later_one_works(self):
        await self.run_cmd("/export settings", msg=31)
        r = await self.run_cmd("/export settings", msg=32)
        self.assertIs(r.kind, R.THROTTLED)
        self.assertEqual(r.text, "")
        self.assertEqual(len(self.transport.sent), 1)
        self.s.clock.advance(seconds=31)
        r = await self.run_cmd("/export settings", msg=33)
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(len(self.transport.sent), 2)

    async def test_the_cooldown_is_per_actor_and_per_chat(self):
        await self.run_cmd("/export settings", msg=41)
        r = await self.run_cmd("/export settings", actor=OWNER, protection=gate(A, OWNER), msg=42)
        self.assertIs(r.kind, R.DONE)

    async def test_a_duplicate_does_not_start_the_cooldown(self):
        await self.run_cmd("/export settings", msg=51)
        self.s.clock.advance(seconds=31)
        dup = await self.run_cmd("/export settings", msg=51)       # redelivery after the cooldown: DUPLICATE
        self.assertIs(dup.kind, R.DUPLICATE)
        r = await self.run_cmd("/export settings", msg=52)          # the duplicate did not start a new cooldown
        self.assertIs(r.kind, R.DONE)


class GatesTests(ExportBase):
    def nothing_happened(self):
        self.assertEqual(self.transport.sent, [])
        self.assertEqual(self.events(EXPORT_REQUESTED), [])
        self.assertEqual(self.licenses.reads, 0)
        self.assertEqual(self.query.reads, 0)

    async def test_a_plain_member_a_limited_admin_and_strangers_are_denied_before_anything(self):
        for who in (USER, STRANGER, TG_LIMITED_ADMIN, BACKUP):
            for what in ("settings", "license"):
                r = await self.run_cmd(f"/export {what}", actor=who, protection=gate(A, who), msg=who % 1000)
                with self.subTest(who=who, what=what):
                    self.assertIs(r.kind, R.DENIED)
                    self.assertNotIn("{", r.text)
        self.nothing_happened()
        self.assertGreaterEqual(len(self.events(PERMISSION_DENIED)), 1)

    async def test_a_moderator_of_another_group_cannot_export_this_one(self):
        r = await self.run_cmd("/export settings", actor=TG_ADMIN, chat=B, protection=gate(B, TG_ADMIN))   # TG_ADMIN administers only A
        self.assertIs(r.kind, R.DENIED)
        self.nothing_happened()

    async def test_a_blocked_licence_stops_everyone_including_the_owner_before_anything(self):
        for who in (TG_ADMIN, OWNER):
            for what in ("settings", "license"):
                r = await self.run_cmd(f"/export {what}", actor=who, protection=gate(A, who, allowed=False), msg=9)
                with self.subTest(who=who, what=what):
                    self.assertIs(r.kind, R.LICENSE_OFF)
        for prot in (None, gate(B, TG_ADMIN)):                 # no gate / a gate that belongs to ANOTHER chat
            r = await self.run_cmd("/export settings", protection=prot)
            self.assertIs(r.kind, R.LICENSE_OFF)
        self.nothing_happened()
        self.assertEqual([k for k in self.claims._keys if "export" in k], [])           # no claim was consumed

    async def test_the_licence_log_is_for_the_primary_owner_only(self):
        r = await self.run_cmd("/export license", actor=TG_ADMIN)           # a real moderator of A
        self.assertIs(r.kind, R.DENIED)
        self.nothing_happened()
        rejected = [e for e in self.events(COMMAND_REJECTED)]
        self.assertTrue(rejected)
        self.assertNotIn("license", " ".join(e.detail or "" for e in rejected))   # the audit names the command, never arguments
        denial = self.events(PERMISSION_DENIED)[-1]
        self.assertEqual((denial.actor_telegram_id, denial.group_id, denial.permission), (TG_ADMIN, A, "view_audit"))

    async def test_a_delegate_manager_may_export_settings_but_never_the_licence_log(self):
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.GROUP_MANAGER)
        ok = await self.run_cmd("/export settings", actor=DELEGATE, protection=gate(A, DELEGATE), msg=1)
        self.assertIs(ok.kind, R.DONE)                                          # a real moderator of this group
        r = await self.run_cmd("/export license", actor=DELEGATE, protection=gate(A, DELEGATE), msg=2)
        self.assertIs(r.kind, R.DENIED)
        self.assertEqual([s_[0] for s_ in self.transport.sent], [DELEGATE])     # only the settings file was ever sent
        self.assertEqual((self.licenses.reads, self.query.reads), (0, 0))

    async def test_invalid_arguments_are_reported_before_the_owner_check_and_without_a_read(self):
        for text, key in (("/export", "mod_err_export_usage"), ("/export bogus", "mod_err_export_usage"),
                          ("/export settings license", "mod_err_export_usage"), ("/export settings csv", "mod_err_export_usage"),
                          ("/export license txt", "mod_err_export_usage"), ("/export reports bogus", "mod_err_export_usage"),
                          ("/export reports csv txt", "mod_err_export_usage"), ("/export audit open", "mod_err_export_usage"),
                          ("تصدير البلاغات الكل المفتوحة", "mod_err_export_usage")):
            r = await self.run_cmd(text) if p(text) else None
            if r is None:
                continue
            with self.subTest(text):
                self.assertIs(r.kind, R.INVALID)
                self.assertEqual(r.text, t(key, "ar"))
        self.nothing_happened()

    async def test_the_gate_order_in_the_executor_is_pinned(self):
        src = read("moderation/executor.py")
        body = src[src.index("async def _handle"):]
        order = [body.index("Permission.MODERATE"), body.index("protection is None or not protection.allowed"), body.index("if cmd in EXPORT_COMMANDS")]
        self.assertEqual(order, sorted(order))
        self.assertLess(body.index("if cmd in EXPORT_COMMANDS"), body.index("if cmd in MESSAGE_COMMANDS"))


class LicenseCommandTests(ExportBase):
    async def test_the_owner_gets_state_and_history_in_private(self):
        await self.s.admin.activate_temporary(OWNER, A, NOW + timedelta(days=20), reason="تجديد")
        r = await self.run_cmd("/export license", actor=OWNER, protection=gate(A, OWNER), msg=3)
        self.assertIs(r.kind, R.DONE)
        user_id, filename, data, caption = self.transport.sent[0]
        self.assertEqual((user_id, filename), (OWNER, "license_1001_20261029.json"))
        body = json.loads(data)
        self.assertEqual(body["group_id"], A)
        self.assertEqual(body["license"]["status"], "active_temporary")
        self.assertEqual(body["license"]["expires_at"], "2026-11-18T12:00:00Z")
        actions = [h["action"] for h in body["history"]]
        self.assertGreaterEqual(len(actions), 2)
        self.assertEqual(body["history"][-1]["reason"], "تجديد")
        self.assertEqual(body["history"][-1]["by"], OWNER)
        self.assertIn(str(A), caption)
        self.assertEqual(r.text, t("export_sent", "ar", what=t("export_what_license", "ar")))
        self.assertNotIn("active_temporary", r.text)

    async def test_permanent_licence(self):
        r = await self.run_cmd("تصدير الترخيص", actor=OWNER, protection=gate(A, OWNER))
        self.assertIs(r.kind, R.DONE)
        lc = json.loads(self.transport.sent[0][2])["license"]
        self.assertEqual((lc["status"], lc["permanent"], lc["expires_at"]), ("active_permanent", True, None))

    async def test_the_history_is_only_this_groups(self):
        await self.s.admin.activate_permanent(OWNER, B, reason="group B only")
        await self.run_cmd("/export license", actor=OWNER, protection=gate(A, OWNER))
        body = json.loads(self.transport.sent[0][2])
        self.assertNotIn("group B only", json.dumps(body, ensure_ascii=False))
        self.assertEqual({h.get("group") for h in body["history"]}, {None})

    async def test_a_licence_read_failure_is_a_safe_error(self):
        async def boom(group_id):
            raise RuntimeError("licence store down")
        self.licenses.inner.get = boom
        r = await self.run_cmd("/export license", actor=OWNER, protection=gate(A, OWNER))
        self.assertIs(r.kind, R.ERROR)
        self.assertEqual(self.transport.sent, [])

    async def test_audit_names_the_export_not_the_content(self):
        await self.run_cmd("/export license", actor=OWNER, protection=gate(A, OWNER), msg=8)
        self.assertEqual([e.target_id for e in self.events(EXPORT_REQUESTED)], ["license"])
        blob = " ".join(f"{e.detail} {e.target_id}" for e in self.events(EXPORT_REQUESTED) + self.events(EXPORT_DELIVERED))
        self.assertNotIn("initial", blob)


class DeliveryOutcomeTests(ExportBase):
    async def test_private_chat_not_started_tells_the_user_what_to_do_and_audits_a_failure(self):
        self.transport.error = PrivateChatUnavailable()
        r = await self.run_cmd("/export settings", msg=61)
        self.assertIs(r.kind, R.INVALID)
        self.assertEqual(r.text, t("export_private_not_started", "ar"))
        self.assertIn("/start", r.text)
        self.assertEqual([e.event_type for e in self.s.audit.events if e.event_type in (EXPORT_DELIVERED, EXPORT_FAILED)], [EXPORT_FAILED])
        self.transport.error = None                                         # started it, then runs the command again
        self.s.clock.advance(seconds=31)
        r = await self.run_cmd("/export settings", msg=62)
        self.assertIs(r.kind, R.DONE)

    async def test_a_telegram_failure_is_reported_without_its_text(self):
        self.transport.error = RuntimeError("https://api.telegram.org/bot123456:SECRET-TOKEN/sendDocument failed")
        r = await self.run_cmd("/export settings")
        self.assertIs(r.kind, R.TELEGRAM_FAILED)
        self.assertEqual(r.text, t("export_failed", "ar"))
        self.assertNotIn("SECRET", r.text)
        self.assertNotIn("SECRET", " ".join(str(e.detail) for e in self.s.audit.events))

    async def test_a_claim_failure_exports_nothing(self):
        self.svc = self.make_service(BrokenClaims())
        r = await self.run_cmd("/export settings")
        self.assertIs(r.kind, R.ERROR)
        self.assertEqual(self.transport.sent, [])


class OutcomeMappingTests(ExportBase):
    delivery_mode = DeliveryResult("sent")

    async def run_with(self, result, text="/export settings"):
        self.delivery.result = result
        self.s.clock.advance(seconds=31)
        self.mid = getattr(self, "mid", 100) + 1
        return await self.run_cmd(text, msg=self.mid)

    async def test_every_code_has_a_closed_answer(self):
        expected = {
            m.SENT: (R.DONE, "export_sent"), m.PRIVATE_NOT_STARTED: (R.INVALID, "export_private_not_started"),
            m.TOO_LARGE: (R.ERROR, "export_too_large"), m.TOO_MANY_ROWS: (R.ERROR, "export_too_large"),
            m.REJECTED: (R.ERROR, "export_rejected"), m.FAILED: (R.TELEGRAM_FAILED, "export_failed"),
            m.INVALID: (R.ERROR, "action_failed_safe"), "something-new": (R.ERROR, "action_failed_safe"),
        }
        for code, (kind, key) in expected.items():
            r = await self.run_with(DeliveryResult(code))
            with self.subTest(code):
                self.assertIs(r.kind, kind)
                self.assertTrue(r.text.startswith(t(key, "ar", what=t("export_what_settings", "ar"))[:12]))
        r = await self.run_with(DeliveryResult(m.DUPLICATE))
        self.assertEqual((r.kind, r.text), (R.DUPLICATE, ""))

    async def test_masked_values_are_reported_by_count_only(self):
        r = await self.run_with(DeliveryResult(m.SENT, 3))
        self.assertIn(t("export_redacted", "ar", count="3"), r.text)
        r = await self.run_with(DeliveryResult(m.SENT, 0))
        self.assertNotIn("⚠️", r.text)

    async def test_the_delivery_is_asked_for_the_actor_with_a_chat_scoped_key_and_the_group_for_audit(self):
        await self.run_with(DeliveryResult(m.SENT), "/export settings")
        requester, file, key, caption, group_id = self.delivery.calls[-1]
        self.assertEqual((requester, group_id), (TG_ADMIN, A))
        self.assertIsInstance(file, ExportFile)
        self.assertEqual(key, f"{A}:{self.mid}:settings")           # chat id inside the key: two groups never collide
        self.assertTrue(re.fullmatch(r"[A-Za-z0-9:_\-.]{1,120}", f"op:exportsend:{requester}:{file.kind}:{key}"))


class UnavailableTests(ExportBase):
    delivery_mode = "none"

    async def test_without_a_delivery_path_it_says_so_and_builds_nothing(self):
        for what in ("settings", "license"):
            r = await self.run_cmd(f"/export {what}", actor=OWNER, protection=gate(A, OWNER), msg=71)
            self.assertIs(r.kind, R.ERROR)
            self.assertEqual(r.text, t("export_unavailable", "ar"))
        self.assertEqual(self.licenses.reads, 0)
        self.assertEqual(self.events(EXPORT_REQUESTED), [])

    async def test_a_disabled_delivery_is_the_same(self):
        self.svc = self.make_service(self.claims)
        self.svc._export_cmds._delivery = ExportDelivery(None, claims=self.claims)
        r = await self.run_cmd("/export settings")
        self.assertEqual(r.text, t("export_unavailable", "ar"))


class _Bot:
    async def me(self):
        return NS(id=BOT, username=BOT_NAME)


class HandlerTests(ExportBase):
    """The framework glue: the group gets ONE text reply, the file goes elsewhere, a private chat never reaches the command."""

    def services(self):
        return NS(settings=NS(default_language="ar"), moderation_commands=self.svc, panel=None)

    async def test_the_group_gets_one_text_reply_and_no_document(self):
        from test_moderation_integration import Msg
        msg = Msg("/export settings", chat=A, sender=TG_ADMIN, mid=91)
        parsed = await mh.match_command(msg, _Bot())
        self.assertIs(parsed.command, Command.EXPORT)
        result = await mh.execute(msg, parsed, protection=gate(A, TG_ADMIN), services=self.services())
        self.assertIs(result.kind, R.DONE)
        self.assertEqual(msg.replies, [t("export_sent", "ar", what=t("export_what_settings", "ar"))])
        self.assertEqual([s_[0] for s_ in self.transport.sent], [TG_ADMIN])

    async def test_the_arabic_alias_and_the_english_reply(self):
        from test_moderation_integration import Msg
        msg = Msg("تصدير الترخيص", chat=A, sender=OWNER, mid=92, lang="en")
        parsed = await mh.match_command(msg, _Bot())
        await mh.execute(msg, parsed, protection=gate(A, OWNER), services=self.services())
        self.assertEqual(msg.replies, [t("export_sent", "en", what=t("export_what_license", "en"))])
        self.assertEqual(self.transport.sent[0][0], OWNER)

    async def test_a_private_chat_never_reaches_the_command(self):
        from test_moderation_integration import Msg
        for text in ("/export settings", "تصدير الاعدادات"):
            msg = Msg(text, chat=TG_ADMIN, ctype="private", sender=TG_ADMIN)
            self.assertIsNone(await mh.match_command(msg, _Bot()))
        self.assertEqual(self.transport.sent, [])

    async def test_a_failed_group_reply_never_undoes_or_repeats_the_export(self):
        from test_moderation_integration import Msg
        msg = Msg("/export settings", chat=A, sender=TG_ADMIN, mid=93)
        msg.fail_reply = True
        parsed = await mh.match_command(msg, _Bot())
        result = await mh.execute(msg, parsed, protection=gate(A, TG_ADMIN), services=self.services())
        self.assertIs(result.kind, R.DONE)
        self.assertEqual(len(self.transport.sent), 1)


# ------------------------------------------------------------------------------------------------ texts, menu, wiring, structure
class RegistrationTests(unittest.TestCase):
    def test_i18n_keys_and_placeholders_match_between_languages(self):
        fmt = string.Formatter()
        keys = [k for k in MESSAGES["ar"] if k.startswith("export_") or k.startswith("mod_err_export_")]
        self.assertEqual(len(keys), 18)
        for key in keys:
            self.assertIn(key, MESSAGES["en"], key)
            names = lambda lang: {f for _, f, _, _ in fmt.parse(MESSAGES[lang][key]) if f}
            self.assertEqual(names("ar"), names("en"), key)
        self.assertEqual({k for k in MESSAGES["en"] if k.startswith(("export_", "mod_err_export_"))}, set(keys))

    def test_every_text_formats_in_both_languages(self):
        for lang in ("ar", "en"):
            for what in ("settings", "license", "reports", "audit"):
                self.assertTrue(t("export_sent", lang, what=t(f"export_what_{what}", lang)))
                self.assertTrue(t(f"export_caption_{what}", lang, group="-1001"))
            self.assertIn("3", t("export_redacted", lang, count="3"))
            self.assertIn("7", t("export_cut", lang, count="7"))
            self.assertIn("7", t("export_caption_cut", lang, count="7"))
            for key in ("export_private_not_started", "export_too_large", "export_rejected", "export_failed", "export_unavailable",
                        "mod_err_export_usage"):
                self.assertTrue(t(key, lang))
        self.assertIn("/start", t("export_private_not_started", "en"))

    def test_captions_carry_no_markup(self):
        for lang in ("ar", "en"):
            for what in ("settings", "license", "reports", "audit"):
                self.assertNotRegex(t(f"export_caption_{what}", lang, group="-1001"), r"[<>&]")
            self.assertNotRegex(t("export_caption_cut", lang, count="7"), r"[<>&]")

    def test_help_mentions_the_command_in_both_languages(self):
        for lang in ("ar", "en"):
            help_text = t("help", lang)
            self.assertIn("/export settings", help_text)
            self.assertIn("/export license", help_text)
            self.assertIn("/export reports", help_text)
            self.assertIn("/export audit", help_text)
            self.assertIn("تصدير الاعدادات", help_text)

    def test_the_menu_lists_it_for_admins_only_in_both_languages(self):
        self.assertIn("export", commands_menu.MODERATION)
        self.assertNotIn("export", commands_menu.BASIC + commands_menu.PUBLIC)
        for lang in ("en", "ar"):
            self.assertTrue(commands_menu.DESCRIPTIONS[lang]["export"])
            self.assertLessEqual(len(commands_menu.DESCRIPTIONS[lang]["export"]), 256)
        for spec in commands_menu.build_menus():
            names = [n for n, _ in spec.commands]
            self.assertEqual("export" in names, spec.scope == "all_chat_administrators")
            self.assertTrue(all(len(d) <= 256 for _, d in spec.commands))

    def test_wiring_in_app_and_services(self):
        app = read("app.py")
        self.assertIn("export_delivery=export_delivery, licenses=license_store, audit_query=audit_query", app)
        self.assertIn("        export_delivery=export_delivery,\n", app)
        self.assertLess(app.index("audit_query = AuditQueryService("), app.index("moderation_commands = LazyModerationCommands("))
        self.assertLess(app.index("export_delivery = ExportDelivery("), app.index("moderation_commands = LazyModerationCommands("))
        self.assertEqual(app.count("ExportDelivery("), 1)

    def test_no_new_migration(self):
        self.assertEqual(sorted(p_.name[:4] for p_ in (SRC / "db" / "sql").glob("0*.sql"))[-1], "0013")


class StructureTests(unittest.TestCase):
    def imports(self, rel):
        out = []
        for node in ast.walk(ast.parse(read(rel))):
            if isinstance(node, ast.Import):
                out += [a.name for a in node.names]
            elif isinstance(node, ast.ImportFrom):
                out.append(("." * node.level) + (node.module or "") + ":" + ",".join(a.name for a in node.names))
        return out

    def test_the_command_never_sends_and_delivers_only_to_the_actor(self):
        tree = ast.parse(read("export/command.py"))
        sends = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr.startswith("send")]
        self.assertEqual(sends, [])
        delivers = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "deliver"]
        self.assertEqual(len(delivers), 1)
        self.assertEqual(delivers[0].args[0].id, "actor_id")           # the requester is the typed-by user, never the chat
        self.assertEqual([k.arg for k in delivers[0].keywords if k.arg == "group_id"], ["group_id"])
        self.assertNotIn("redirect_chat_id", read("export/command.py"))

    def test_the_package_stays_independent_of_the_framework_and_the_hub(self):
        for rel in ("export/args.py", "export/command.py", "export/settings_export.py", "export/license_export.py"):
            for imp in self.imports(rel):
                with self.subTest(rel=rel, imp=imp):
                    self.assertNotIn("aiogram", imp)
                    for banned in ("owner_hub", "hub_transport", "asyncpg"):
                        self.assertNotIn(banned, imp)

    def test_the_exporters_are_pure_functions(self):
        for rel in ("export/settings_export.py", "export/license_export.py", "export/args.py"):
            tree = ast.parse(read(rel))
            self.assertEqual([n for n in ast.walk(tree) if isinstance(n, (ast.AsyncFunctionDef, ast.Await))], [], rel)
            self.assertFalse([i for i in self.imports(rel) if "permissions" in i or "idempotency" in i or "audit:" in i.replace("..audit_service", "")], rel)

    def test_the_command_order_is_parse_then_owner_check_then_claim_then_audit_then_build_then_deliver(self):
        body = read("export/command.py")
        body = body[body.index("async def handle"):body.index("async def _build")]
        marks = ["parse_export(", "Permission.VIEW_AUDIT", "delivery is None", "self._ready(", ".claim(", "record_safely(", "self._build(", ".deliver("]
        positions = [body.index(x) for x in marks]
        self.assertEqual(positions, sorted(positions))

    def test_the_licence_history_goes_through_the_owner_only_query_service(self):
        body = read("export/command.py")
        self.assertIn("audit_query.license_history(", body)
        self.assertIn("Permission.VIEW_AUDIT", body)
        self.assertNotIn("audit_for_group", body)                      # never the raw repository

    def test_view_audit_is_owner_only(self):
        from guardian.permissions import OWNER_ONLY, Permission
        self.assertIn(Permission.VIEW_AUDIT, OWNER_ONLY)

    def test_the_audit_event_exists(self):
        self.assertEqual(EXPORT_REQUESTED, "export_requested")


if __name__ == "__main__":
    unittest.main()
