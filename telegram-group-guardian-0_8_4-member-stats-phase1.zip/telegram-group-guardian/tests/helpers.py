"""Shared fakes for stdlib-only tests (no aiogram / FastAPI / asyncpg required)."""
from __future__ import annotations

import logging

logging.disable(logging.CRITICAL)  # expected-failure tests would otherwise print tracebacks

VALID_ENV = {
    "BOT_TOKEN": "123456789:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
    "DATABASE_URL": "postgresql://dbuser:s3cretPW@db.example.com:5432/guardian?sslmode=require",
    "OWNER_TELEGRAM_ID": "111111111",
    "WEBHOOK_SECRET": "unit-test-webhook-secret-123456",
}


class FakeNotifier:
    def __init__(self, fail: bool = False):
        self.fail = fail
        self.group_messages: list[tuple[int, str]] = []
        self.owner_messages: list[str] = []

    async def notify_group(self, group_id: int, text: str) -> None:
        if self.fail:
            raise RuntimeError("telegram down")
        self.group_messages.append((group_id, text))

    async def notify_owner(self, text: str) -> None:
        if self.fail:
            raise RuntimeError("telegram down")
        self.owner_messages.append(text)


class FakeTx:
    def __init__(self, conn: "FakeConn"):
        self.conn = conn

    async def __aenter__(self):
        self.conn._pending = {}
        return self

    async def __aexit__(self, exc_type, exc, tb):
        if exc_type is None:
            self.conn.applied.update(self.conn._pending)
        else:
            self.conn.rollbacks += 1
        self.conn._pending = {}
        return False


class FakeConn:
    """Minimal asyncpg-connection stand-in for the migration runner."""

    def __init__(self, applied: dict[str, str] | None = None, fail_on: str | None = None):
        self.applied = dict(applied or {})
        self.fail_on = fail_on
        self.log: list[str] = []
        self.rollbacks = 0
        self._pending: dict[str, str] = {}

    async def execute(self, sql: str, *args):
        self.log.append(sql.strip().split("\n")[0][:60])
        if self.fail_on and self.fail_on in sql:
            raise RuntimeError("boom")
        if sql.startswith("INSERT INTO schema_migrations"):
            self._pending[args[0]] = args[1]

    async def fetch(self, sql: str, *args):
        return [{"version": v, "checksum": c} for v, c in self.applied.items()]

    def transaction(self):
        return FakeTx(self)
