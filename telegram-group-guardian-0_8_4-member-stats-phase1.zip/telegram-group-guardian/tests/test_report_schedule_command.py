"""Part 6.7 (decision): `/reports schedule [day|week|month on|off]` — who switches the periodic reports on. Fakes only."""
from __future__ import annotations

import unittest
from pathlib import Path

from executor_stack import A, B, BOT, USER, BrokenClaims, ExecBase, gate
from guardian.audit import REPORT_SCHEDULE_SET
from guardian.errors import InvalidInput
from guardian.i18n import MESSAGES, t
from guardian.moderation.commands import Command, CommandError, parse_command
from guardian.moderation.executor import ModerationCommandService, ResultKind as R
from guardian.reports import ReportService
from guardian.reports import args as ra
from guardian.reports.memory_store import InMemoryReportStore
from guardian.stats.models import StatsPeriod
from guardian.stats.periodic import ReportScheduleService
from guardian.stats.schedule_memory_store import InMemoryScheduleStore
from stack import BACKUP, OWNER, TG_ADMIN, TG_LIMITED_ADMIN, DELEGATE

SRC = Path(__file__).resolve().parent.parent / "src" / "guardian"


class ArgsTests(unittest.TestCase):
    def test_show_and_change_in_both_languages(self):
        self.assertEqual(ra.parse_schedule(("schedule",)), ra.ScheduleArgs())
        for words, period, on in ((("schedule", "day", "on"), StatsPeriod.DAY, True), (("schedule", "WEEK", "off"), StatsPeriod.WEEK, False),
                                  (("جدولة", "الأسبوع", "تفعيل"), StatsPeriod.WEEK, True), (("الجدولة", "شهري", "إيقاف"), StatsPeriod.MONTH, False),
                                  (("schedule", "month", "تعطيل"), StatsPeriod.MONTH, False)):
            with self.subTest(words):
                self.assertEqual(ra.parse_schedule(words), ra.ScheduleArgs(period, on))

    def test_anything_else_is_an_error_never_a_switch(self):
        for bad in (("schedule", "day"), ("schedule", "on"), ("schedule", "year", "on"), ("schedule", "day", "maybe"),
                    ("schedule", "day", "on", "x"), ("schedule", "all", "on")):
            with self.subTest(bad), self.assertRaises(CommandError) as cm:
                ra.parse_schedule(bad)
            self.assertEqual(cm.exception.code, "report_schedule")

    def test_the_arabic_alias_needs_the_whole_vocabulary(self):
        self.assertIs(parse_command("البلاغات جدولة الاسبوع تفعيل").command, Command.REPORTS)
        self.assertIs(parse_command("البلاغات جدولة").command, Command.REPORTS)
        self.assertIsNone(parse_command("البلاغات جدولة الاسبوع"))
        self.assertIsNone(parse_command("البلاغات جدولة كل شيء تفعيل"))


class Base(ExecBase):
    async def asyncSetUp(self):
        self.store = InMemoryScheduleStore()
        await super().asyncSetUp()

    def make_service(self, claims):
        self.schedule = ReportScheduleService(self.store, self.s.audit, clock=self.s.clock)
        return ModerationCommandService(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions, settings_store=self.s.settings_store,
            actions=self.actions, chat_info=self.s.chat, claims=claims, audit=self.s.audit, bot_id=BOT, clock=self.s.clock,
            group_settings=self.s.settings, reports=ReportService(InMemoryReportStore(), self.s.audit, self.s.clock),
            report_schedule=self.schedule)

    def events(self):
        return [e for e in self.s.audit.events if e.event_type == REPORT_SCHEDULE_SET]


class CommandTests(Base):
    async def test_a_moderator_sees_all_three_off_by_default(self):
        r = await self.run_cmd("/reports schedule")
        self.assertIs(r.kind, R.INFO)
        self.assertEqual(r.text.count("مطفأ"), 3)
        self.assertIsNone(r.redirect_chat_id)

    async def test_a_group_manager_switches_a_period_on_and_off_with_audit(self):
        r = await self.run_cmd("/reports schedule week on", msg=1)
        self.assertIs(r.kind, R.DONE)
        self.assertTrue(await self.schedule.is_enabled(A, StatsPeriod.WEEK))
        self.assertFalse(await self.schedule.is_enabled(A, StatsPeriod.DAY))
        self.assertIn("أسبوعي", (await self.run_cmd("/reports schedule", msg=2)).text)
        r = await self.run_cmd("البلاغات جدولة الاسبوع ايقاف", msg=3)
        self.assertIs(r.kind, R.DONE)
        self.assertFalse(await self.schedule.is_enabled(A, StatsPeriod.WEEK))
        self.assertEqual([e.detail for e in self.events()], ["period=week enabled=on", "period=week enabled=off"])

    async def test_repeating_the_same_switch_is_a_noop_without_audit(self):
        await self.run_cmd("/reports schedule day on", msg=1)
        r = await self.run_cmd("/reports schedule day on", msg=2)
        self.assertIs(r.kind, R.NOOP)
        self.assertEqual(len(self.events()), 1)

    async def test_only_manage_settings_changes_it_a_plain_moderator_may_read(self):
        await self.s.delegations.grant(OWNER, A, DELEGATE, __import__("guardian.permissions", fromlist=["GroupRole"]).GroupRole.MODERATOR)
        mod = await self.run_cmd("/reports schedule", actor=DELEGATE, protection=gate(A, DELEGATE), msg=1)
        self.assertIs(mod.kind, R.INFO)                                            # MODERATE is enough to look
        r = await self.run_cmd("/reports schedule day on", actor=DELEGATE, protection=gate(A, DELEGATE), msg=2)
        self.assertIs(r.kind, R.DENIED)
        self.assertFalse(await self.schedule.is_enabled(A, StatsPeriod.DAY))
        self.assertEqual(self.events(), [])

    async def test_members_strangers_and_other_groups_are_denied(self):
        for who, chat in ((USER, A), (BACKUP, A), (TG_ADMIN, B), (TG_LIMITED_ADMIN, A)):
            r = await self.run_cmd("/reports schedule day on", actor=who, chat=chat, protection=gate(chat, who))
            with self.subTest(who=who, chat=chat):
                self.assertIs(r.kind, R.DENIED)
        self.assertEqual(self.events(), [])

    async def test_a_blocked_licence_stops_even_the_owner(self):
        for who in (TG_ADMIN, OWNER):
            r = await self.run_cmd("/reports schedule day on", actor=who, protection=gate(A, who, allowed=False))
            self.assertIs(r.kind, R.LICENSE_OFF)
        self.assertFalse(await self.schedule.is_enabled(A, StatsPeriod.DAY))

    async def test_invalid_input_changes_nothing(self):
        for text in ("/reports schedule day", "/reports schedule year on", "/reports schedule day on now"):
            r = await self.run_cmd(text)
            with self.subTest(text):
                self.assertIs(r.kind, R.INVALID)
                self.assertEqual(r.text, t("mod_err_report_schedule", "ar"))
        self.assertEqual(self.events(), [])

    async def test_redelivery_and_claim_failure(self):
        await self.run_cmd("/reports schedule day on", msg=7)
        self.assertIs((await self.run_cmd("/reports schedule day on", msg=7)).kind, R.DUPLICATE)
        self.svc = self.make_service(BrokenClaims())
        r = await self.run_cmd("/reports schedule week on", msg=8)
        self.assertIs(r.kind, R.ERROR)
        self.assertFalse(await self.schedule.is_enabled(A, StatsPeriod.WEEK))

    async def test_a_store_failure_is_a_safe_error(self):
        async def boom(*a, **k):
            raise RuntimeError("fk violation")
        self.store.set_enabled = boom
        r = await self.run_cmd("/reports schedule day on")
        self.assertIs(r.kind, R.ERROR)
        self.assertEqual(r.text, t("action_failed_safe", "ar"))

    async def test_without_the_service_it_says_so(self):
        self.schedule = None
        self.svc._report_cmds._schedule = None
        self.assertIs((await self.run_cmd("/reports schedule")).kind, R.ERROR)

    async def test_the_switch_really_drives_the_owed_periods(self):
        await self.run_cmd("/reports schedule day on")
        self.assertTrue((await self.schedule.entries(A))[StatsPeriod.DAY].enabled)


class Registration(unittest.TestCase):
    def test_i18n_matches_between_languages(self):
        keys = [k for k in MESSAGES["ar"] if k.startswith("report_sched_") or k == "mod_err_report_schedule"]
        self.assertEqual(len(keys), 12)
        for k in keys:
            self.assertIn(k, MESSAGES["en"], k)
        self.assertEqual({k for k in MESSAGES["en"] if k.startswith("report_sched_") or k == "mod_err_report_schedule"}, set(keys))

    def test_the_write_needs_manage_settings_and_the_service_is_wired(self):
        src = (SRC / "reports" / "commands.py").read_text(encoding="utf-8")
        self.assertLess(src.index("Permission.MANAGE_SETTINGS"), src.index("set_enabled("))
        self.assertLess(src.index("Permission.MANAGE_SETTINGS"), src.index('operation_key("repsched"'))
        app = (SRC / "app.py").read_text(encoding="utf-8")
        self.assertIn("report_schedule=report_schedule_service", app)
        self.assertLess(app.index("report_schedule_service = ReportScheduleService("), app.index("moderation_commands = LazyModerationCommands("))


if __name__ == "__main__":
    unittest.main()
