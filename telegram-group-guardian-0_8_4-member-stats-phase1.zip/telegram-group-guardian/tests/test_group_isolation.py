import unittest

from guardian.audit import DELEGATION_GRANTED, SETTINGS_CHANGED, TRUST_ADDED
from guardian.errors import GroupNotRegistered, InvalidInput, PermissionDenied
from guardian.groups.models import GroupRole
from guardian.groups.service import validate_settings_patch
from stack import A, B, BACKUP, DELEGATE, OWNER, STRANGER, TG_ADMIN, TG_CREATOR, Stack


class IsolationTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A, B)

    async def test_settings_are_per_group(self):
        await self.s.settings.update(TG_CREATOR, A, {"links": "delete", "warn_limit": 3})
        await self.s.settings.update(OWNER, B, {"links": "off"})
        a = await self.s.settings.get(TG_CREATOR, A)
        b = await self.s.settings.get(TG_CREATOR, B)
        self.assertEqual(a.settings, {"links": "delete", "warn_limit": 3})
        self.assertEqual(b.settings, {"links": "off"})
        self.assertEqual((a.group_id, b.group_id), (A, B))

    async def test_admin_of_one_group_cannot_read_or_change_another_groups_settings(self):
        # TG_ADMIN is an admin in A only.
        await self.s.settings.update(TG_ADMIN, A, {"links": "delete"})
        with self.assertRaises(PermissionDenied):
            await self.s.settings.update(TG_ADMIN, B, {"links": "off"})
        with self.assertRaises(PermissionDenied):
            await self.s.settings.get(TG_ADMIN, B)
        with self.assertRaises(PermissionDenied):
            await self.s.settings.set_language(TG_ADMIN, B, "en")
        self.assertIsNone(await self.s.settings_store.get(B))

    async def test_command_context_chat_prevents_cross_group_writes(self):
        with self.assertRaises(PermissionDenied):
            await self.s.settings.update(OWNER, A, {"x": 1}, context_chat_id=B)
        self.assertIsNone(await self.s.settings_store.get(A))

    async def test_trust_list_is_per_group_and_needs_permission(self):
        await self.s.trust.add(TG_CREATOR, A, 4242, "friend")
        self.assertTrue(await self.s.trust_store.is_trusted(A, 4242))
        self.assertFalse(await self.s.trust_store.is_trusted(B, 4242))
        self.assertEqual([t.user_id for t in await self.s.trust.list(OWNER, A)], [4242])
        self.assertEqual(await self.s.trust.list(OWNER, B), [])
        with self.assertRaises(PermissionDenied):
            await self.s.trust.add(STRANGER, A, 1)
        with self.assertRaises(PermissionDenied):
            await self.s.trust.add(TG_ADMIN, B, 1)  # admin of A only
        with self.assertRaises(PermissionDenied):
            await self.s.trust.remove(TG_ADMIN, B, 4242)
        self.assertFalse(await self.s.trust.add(TG_CREATOR, A, 4242))  # idempotent
        self.assertTrue(await self.s.trust.remove(TG_CREATOR, A, 4242))

    async def test_only_owner_manages_delegates(self):
        for actor in (TG_CREATOR, TG_ADMIN, BACKUP, STRANGER):
            with self.assertRaises(PermissionDenied):
                await self.s.delegations.grant(actor, A, DELEGATE, GroupRole.GROUP_MANAGER)
        self.assertEqual(await self.s.deleg_store.list_live(A), [])
        d, changed = await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.MODERATOR)
        self.assertTrue(changed)
        _, again = await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.MODERATOR)
        self.assertFalse(again)  # idempotent
        self.assertEqual(await self.s.deleg_store.list_live(B), [])  # not visible in B
        with self.assertRaises(PermissionDenied):  # a delegate cannot escalate or delegate onward
            await self.s.delegations.grant(DELEGATE, A, 5555, GroupRole.GROUP_MANAGER)
        self.assertTrue(await self.s.delegations.revoke(OWNER, A, DELEGATE))
        self.assertFalse(await self.s.delegations.revoke(OWNER, A, DELEGATE))

    async def test_role_change_keeps_a_single_live_delegation(self):
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.MODERATOR)
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.GROUP_MANAGER)
        live = await self.s.deleg_store.list_live(A)
        self.assertEqual([(d.user_id, d.role) for d in live], [(DELEGATE, GroupRole.GROUP_MANAGER)])

    async def test_unregistered_group_rejected_by_services(self):
        with self.assertRaises(GroupNotRegistered):
            await self.s.settings.update(OWNER, -555, {"a": 1})
        with self.assertRaises(GroupNotRegistered):
            await self.s.trust.add(OWNER, -555, 5)
        with self.assertRaises(GroupNotRegistered):
            await self.s.delegations.grant(OWNER, -555, 5, GroupRole.MODERATOR)

    async def test_security_audit_is_recorded_and_isolated(self):
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.MODERATOR)
        await self.s.trust.add(OWNER, A, 77)
        await self.s.settings.update(OWNER, B, {"k": 1})
        kinds_a = {e.event_type for e in await self.s.audit.for_group(A)}
        kinds_b = {e.event_type for e in await self.s.audit.for_group(B)}
        self.assertEqual(kinds_a, {DELEGATION_GRANTED, TRUST_ADDED})
        self.assertEqual(kinds_b, {SETTINGS_CHANGED})

    async def test_license_audit_queries_are_per_group(self):
        await self.s.admin.activate_permanent(OWNER, A)
        self.assertEqual({e.group_id for e in await self.s.licenses.audit_for_group(A)}, {A})
        self.assertEqual([e.action for e in await self.s.licenses.audit_for_group(B)], ["register_pending"])


class SettingsValidationTests(unittest.TestCase):
    def test_valid(self):
        self.assertEqual(validate_settings_patch({"a_b": [1, "x", None, True], "n": {"k": 1.5}}), {"a_b": [1, "x", None, True], "n": {"k": 1.5}})

    def test_invalid(self):
        bad = [None, {}, [], "x", {"Bad": 1}, {"1a": 1}, {"a b": 1}, {"a": object()}, {"a": "x" * 501},
               {f"k{i}": 1 for i in range(51)}, {"a": {"b": {"c": {"d": {"e": 1}}}}}, {"a": list(range(101))},
               {"a": "x" * 500, "b": "y" * 500, "c": "z" * 500, "d": "w" * 500, "e": "v" * 500,
                "f": "u" * 500, "g": "t" * 500, "h": "s" * 500, "i": "r" * 500},
               {1: "x"}, {"a": float("inf")} if False else {"a": {1: 2}}]
        for patch in bad:
            with self.assertRaises(InvalidInput, msg=repr(patch)[:60]):
                validate_settings_patch(patch)

    async def _noop(self):  # pragma: no cover
        pass


class LanguageTests(unittest.IsolatedAsyncioTestCase):
    async def test_language_whitelist(self):
        s = Stack()
        await s.register(A)
        await s.settings.set_language(OWNER, A, "en")
        with self.assertRaises(InvalidInput):
            await s.settings.set_language(OWNER, A, "xx")
        self.assertEqual((await s.settings_store.get(A)).language, "en")


if __name__ == "__main__":
    unittest.main()
