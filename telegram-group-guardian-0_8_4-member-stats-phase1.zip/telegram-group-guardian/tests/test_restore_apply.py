"""Part 6.9b: restore EXECUTION (one transaction, all or nothing). PostgreSQL / Telegram are NOT exercised:
the executor runs over an in-memory writer (rollback included) and the SQL writer over a recording fake connection."""
from __future__ import annotations

import asyncio
import copy
import re
import unittest
from datetime import timedelta
from pathlib import Path

import helpers  # noqa: F401
import restore_helpers as H
import test_restore_preview as T
from backup_helpers import FIXED_NOW
from stack import BACKUP, OWNER, STRANGER

from guardian import i18n
from guardian.audit import RESTORE_APPLIED, RESTORE_FAILED, RESTORE_REJECTED, RESTORE_STARTED, RESTORE_PREVIEWED
from guardian.backup import format as F
from guardian.backup import postgres_restore as PR
from guardian.backup import postgres_state as PS
from guardian.backup import preview as P
from guardian.backup import restore as R
from guardian.backup import restore_service as svc
from guardian.backup.restore_command import (RestoreCommandService, _ROLLBACK_KEYS, parse_restore_command, render_applied, render_preview)
from guardian.owner_templates.pending import PendingActions

SRC = Path(__file__).resolve().parent.parent / "src" / "guardian"
G1, G2, G3 = -1001, -1002, -1003
NOW = FIXED_NOW + timedelta(hours=1)


def backup_tables():
    return copy.deepcopy(T.validate(T.good()).tables)


def backup():
    return T.validate(T.good())


EMPTY = T.validate(T.collect({}).data)          # built at import: the collector is async and no loop is running here


def drift_tables():
    """A database that moved on since the backup: G1 changed, G2 unknown, G3 exists only here, other templates/defaults/log rows."""
    b = backup_tables()
    t = copy.deepcopy(b)
    g1 = next(r for r in t["telegram_groups"] if r["group_id"] == G1)
    g1.update(license_status="expired", expires_at=None, activated_at="2026-10-01T00:00:00.000000Z", activated_by=111)
    t["telegram_groups"] = [g1, dict(group_id=G3, title="Third", license_status="pending", activated_at=None, expires_at=None,
                                      activated_by=None, status_note=None, created_at="2026-10-02T00:00:00.000000Z",
                                      updated_at="2026-10-02T00:00:00.000000Z")]
    w = copy.deepcopy(b["moderation_warnings"][0])
    t["moderation_warnings"] = [dict(w, reason="changed"), dict(w, id=50, idempotency_key="w50", reason="newer"),
                                dict(w, id=60, group_id=G3, idempotency_key="w60")]
    s1 = next(r for r in b["group_settings"] if r["group_id"] == G1)
    t["group_settings"] = [dict(s1, settings={"flood": 99}), dict(s1, group_id=G3)]
    tpl = b["settings_templates"][0]
    t["settings_templates"] = [tpl, dict(tpl, id=5, name="other", name_key="other")]
    t["global_default_settings"] = [dict(b["global_default_settings"][0], version=5)]
    log1 = next(r for r in b["license_audit_log"] if r["group_id"] == G1)
    t["license_audit_log"] = [dict(log1), dict(log1, id=9, action="manual", reason="later"),
                              dict(log1, id=10, group_id=G3, action="auto")]
    t["group_delegations"] = [r for r in b["group_delegations"]]
    return t


def signature(db: H.MemDB, bk=None, now=NOW) -> str:
    state = H.mem_state(db)
    return R.preview_signature(P.build_preview(bk or backup(), state, now))


def sort_rows(rows, table):
    return sorted(rows, key=lambda r: tuple(str(r[k]) for k in F.BY_NAME[table].key))


class ExecutorBase(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.clock = lambda: NOW

    def executor(self, db):
        return R.RestoreExecutor(db, clock=self.clock)

    async def run_restore(self, db, *, with_license=False, sig=None, bk=None):
        bk = bk or backup()
        sig = sig if sig is not None else R.preview_signature(P.build_preview(bk, await H.MemTx(db).read_state(), NOW))
        return await self.executor(db).execute(bk, expected_signature=sig, owner_id=OWNER, with_license=with_license)


class DataRestoreTests(ExecutorBase):
    async def test_replaces_only_the_groups_of_the_file(self):
        db = H.MemDB(drift_tables(), seq_extra=100)
        before = copy.deepcopy(db.t)
        result = await self.run_restore(db)
        b = backup_tables()
        for table in P.REPLACED_PER_GROUP:
            mine = sort_rows([r for r in db.t[table] if r["group_id"] in (G1, G2)], table)
            self.assertEqual(mine, sort_rows(b[table], table), table)
        # G3 is not in the file: all its rows are untouched
        for table in P.REPLACED_PER_GROUP:
            self.assertEqual([r for r in db.t[table] if r["group_id"] == G3], [r for r in before[table] if r["group_id"] == G3], table)
        self.assertEqual(db.t["settings_templates"], b["settings_templates"])
        self.assertEqual(db.t["global_default_settings"], b["global_default_settings"])
        self.assertEqual((result.groups_replaced, result.groups_added), (1, 1))
        self.assertEqual((db.committed, db.rolled_back), (1, 0))

    async def test_without_license_existing_groups_are_untouched_and_missing_ones_are_created_unlicensed(self):
        db = H.MemDB(drift_tables())
        before = {r["group_id"]: dict(r) for r in db.t["telegram_groups"]}
        await self.run_restore(db)
        after = {r["group_id"]: r for r in db.t["telegram_groups"]}
        self.assertEqual(after[G1], before[G1])                           # not even its title or timestamps
        self.assertEqual(after[G3], before[G3])
        g2 = after[G2]
        self.assertEqual((g2["license_status"], g2["activated_at"], g2["expires_at"], g2["activated_by"], g2["status_note"]),
                         ("pending", None, None, None, None))             # the file says active_permanent: NOT applied
        self.assertEqual(g2["title"], "Second group")

    async def test_without_license_the_licence_log_is_not_touched_at_all(self):
        db = H.MemDB(drift_tables())
        before = copy.deepcopy(db.t["license_audit_log"])
        result = await self.run_restore(db)
        self.assertEqual(db.t["license_audit_log"], before)
        self.assertEqual((result.log_appended, result.license_updated, result.with_license), (0, 0, False))
        self.assertNotIn("append_license_log", [op for op, _ in db.ops])

    async def test_result_matches_the_preview(self):
        for make in (drift_tables, backup_tables, lambda: {}):
            db = H.MemDB(make())
            bk = backup()
            preview = P.build_preview(bk, await H.MemTx(db).read_state(), NOW)
            result = await self.run_restore(db, bk=bk)
            self.assertEqual(result.rows_removed, preview.removed_total)
            self.assertEqual(result.rows_inserted + result.groups_added, preview.added_total)
            self.assertEqual(result.groups_added, preview.groups_new)
            self.assertEqual(result.groups_replaced, preview.groups_replaced)
            self.assertEqual({t: (r, i) for t, r, i in result.per_table},
                             {l.table: (l.removed, l.added) for l in preview.tables if l.table in dict((t, 1) for t, _, _ in result.per_table)})

    async def test_restoring_into_an_identical_database_is_a_no_op_in_effect(self):
        db = H.MemDB(backup_tables())
        before = copy.deepcopy(db.t)
        await self.run_restore(db)
        for table in F.TABLE_NAMES:
            self.assertEqual(sort_rows(db.t[table], table), sort_rows(before[table], table), table)

    async def test_an_empty_backup_replaces_the_globals_and_touches_no_group(self):
        db = H.MemDB(drift_tables())
        empty = EMPTY
        before = copy.deepcopy(db.t)
        result = await self.run_restore(db, bk=empty)
        self.assertEqual(db.t["settings_templates"], [])
        self.assertEqual(db.t["global_default_settings"], [])
        for table in P.REPLACED_PER_GROUP + (P.GROUPS_TABLE, P.LOG_TABLE):
            self.assertEqual(db.t[table], before[table], table)
        self.assertEqual((result.groups_replaced, result.groups_added), (0, 0))

    async def test_sequences_move_past_the_restored_ids_and_never_backwards(self):
        db = H.MemDB(drift_tables(), seq_extra=100)             # sequences far ahead of every id
        top = dict(db.seq)
        await self.run_restore(db)
        for table in R.ID_TABLES:
            self.assertGreaterEqual(db.seq[table], top[table], table)
        db = H.MemDB(drift_tables())
        await self.run_restore(db)
        self.assertGreaterEqual(db.seq["moderation_warnings"], 60)    # the untouched group's row (id 60) keeps its id reserved

    async def test_the_order_of_the_operations(self):
        db = H.MemDB(drift_tables())
        await self.run_restore(db)
        ops = [op for op, _ in db.ops]
        self.assertEqual(ops[0], "lock")
        self.assertLess(max(i for i, o in enumerate(ops) if o == "id_conflicts"), ops.index("create_groups"))
        self.assertLess(ops.index("create_groups"), min(i for i, o in enumerate(ops) if o == "insert_rows"))
        self.assertEqual(ops[-1], "reset_sequences")
        for table in P.REPLACED_PER_GROUP:                       # delete before insert, per table
            self.assertLess(db.ops.index(("delete_for_groups", table)), db.ops.index(("insert_rows", table)))


class LicenseOptionTests(ExecutorBase):
    async def test_with_license_applies_the_files_state_and_appends_the_log(self):
        db = H.MemDB(drift_tables())
        before_log = copy.deepcopy(db.t["license_audit_log"])
        result = await self.run_restore(db, with_license=True)
        groups = {r["group_id"]: r for r in db.t["telegram_groups"]}
        b = {r["group_id"]: r for r in backup_tables()["telegram_groups"]}
        for g in (G1, G2):
            for col in H.PR_LICENSE:
                self.assertEqual(groups[g][col], b[g][col], (g, col))
        self.assertEqual(groups[G3]["license_status"], "pending")                    # not in the file
        self.assertEqual((result.license_updated, result.groups_added), (1, 1))
        # nothing already in the log was changed or removed
        for row in before_log:
            self.assertIn(row, db.t["license_audit_log"])
        new = [r for r in db.t["license_audit_log"] if r not in before_log]
        fp = backup().fingerprint
        mine = [r for r in new if r["action"] == "restore"]
        self.assertEqual(sorted((r["group_id"], r["previous_status"], r["new_status"]) for r in mine),
                         [(G2, None, "active_permanent"), (G1, "expired", "active_temporary")][::-1] if False else
                         sorted([(G2, None, "active_permanent"), (G1, "expired", "active_temporary")]))
        for r in mine:
            self.assertEqual((r["actor_telegram_id"], r["reason"]), (OWNER, f"restore:{fp}"))
        copied = [r for r in new if r["action"] != "restore"]
        self.assertEqual([(r["group_id"], r["action"]) for r in copied], [(G2, "auto")])   # G1's identical row was NOT duplicated
        self.assertEqual(result.log_appended, len(new))
        self.assertGreater(min(r["id"] for r in new), 10)                              # new ids, never an old one reused

    async def test_a_new_pending_group_writes_no_licence_row(self):
        def make_pending(d):
            row = next(r for r in d["tables"]["telegram_groups"] if r["group_id"] == G2)
            row.update(license_status="pending", activated_at=None, expires_at=None, activated_by=None)
        bk = T.validate(T.edited(make_pending))
        db = H.MemDB(drift_tables())
        await self.run_restore(db, with_license=True, bk=bk)
        self.assertFalse([r for r in db.t["license_audit_log"] if r["action"] == "restore" and r["group_id"] == G2])
        self.assertEqual(next(r for r in db.t["telegram_groups"] if r["group_id"] == G2)["license_status"], "pending")

    async def test_a_licence_change_without_the_option_leaves_no_trace_in_the_log(self):
        db = H.MemDB(drift_tables())
        await self.run_restore(db)
        self.assertFalse([r for r in db.t["license_audit_log"] if r["action"] == "restore"])

    async def test_with_license_and_an_unchanged_state_writes_no_restore_row(self):
        db = H.MemDB(backup_tables())
        result = await self.run_restore(db, with_license=True)
        self.assertEqual((result.license_updated, result.log_appended), (0, 0))
        self.assertFalse([r for r in db.t["license_audit_log"] if r["action"] == "restore"])

    async def test_the_licence_log_is_never_shrunk_or_rewritten(self):
        for with_license in (False, True):
            db = H.MemDB(drift_tables())
            before = copy.deepcopy(db.t["license_audit_log"])
            await self.run_restore(db, with_license=with_license)
            for row in before:
                self.assertIn(row, db.t["license_audit_log"])
            self.assertGreaterEqual(len(db.t["license_audit_log"]), len(before))
        ops = [op for op, _ in db.ops]
        self.assertFalse([o for o in ops if o in ("delete_all", "delete_for_groups") and (o, P.LOG_TABLE) in db.ops])


class AllOrNothingTests(ExecutorBase):
    async def assert_unchanged(self, db, before):
        self.assertEqual(db.t, before)
        self.assertEqual((db.committed, db.rolled_back), (0, 1))

    async def test_a_failure_at_any_step_rolls_everything_back(self):
        steps = [("create_groups", "telegram_groups"), ("append_license_log", "license_audit_log"), ("update_license", "telegram_groups")]
        steps += [("delete_for_groups", t) for t in P.REPLACED_PER_GROUP] + [("insert_rows", t) for t in P.REPLACED_PER_GROUP]
        steps += [("delete_all", t) for t in P.GLOBAL_REPLACED] + [("insert_rows", t) for t in P.GLOBAL_REPLACED]
        for step in steps:
            db = H.MemDB(drift_tables())
            before = copy.deepcopy(db.t)
            db.fail_at = step
            sig = signature(db)
            with self.assertRaises(R.RestoreError) as ctx:
                await self.executor(db).execute(backup(), expected_signature=sig, owner_id=OWNER, with_license=True)
            self.assertEqual(ctx.exception.code, "constraint_failed", step)
            await self.assert_unchanged(db, before)

    async def test_any_other_exception_also_rolls_back_and_propagates(self):
        db = H.MemDB(drift_tables())
        before = copy.deepcopy(db.t)
        tx = H.MemTx

        async def boom(self, table, rows):
            if table == "moderation_sanctions":
                raise RuntimeError("driver exploded")
            return await original(self, table, rows)

        original = tx.insert_rows
        tx.insert_rows = boom
        try:
            with self.assertRaises(RuntimeError):
                await self.run_restore(db)
        finally:
            tx.insert_rows = original
        await self.assert_unchanged(db, before)

    async def test_the_approved_preview_must_still_be_true(self):
        db = H.MemDB(drift_tables())
        sig = signature(db)
        w = dict(db.t["moderation_warnings"][0], id=70, idempotency_key="w70")
        db.t["moderation_warnings"].append(w)                           # something changed after the preview
        before = copy.deepcopy(db.t)
        with self.assertRaises(R.RestoreError) as ctx:
            await self.run_restore(db, sig=sig)
        self.assertEqual(ctx.exception.code, "state_changed")
        await self.assert_unchanged(db, before)
        self.assertEqual([op for op, _ in db.ops], ["lock"])             # nothing was even attempted

    async def test_a_new_group_after_the_preview_also_invalidates_it(self):
        db = H.MemDB(drift_tables())
        sig = signature(db)
        db.t["telegram_groups"].append(dict(db.t["telegram_groups"][1], group_id=-1999))
        with self.assertRaises(R.RestoreError) as ctx:
            await self.run_restore(db, sig=sig)
        self.assertEqual(ctx.exception.code, "state_changed")

    async def test_ids_that_collide_with_other_groups_are_refused(self):
        for table in R.ID_CONFLICT_TABLES:
            t = drift_tables()
            b = backup_tables()
            if not b[table]:
                continue
            first = b[table][0]
            alien = dict(first, group_id=G3)
            if "idempotency_key" in alien:
                alien["idempotency_key"] = "alien-key"
            t[table] = [r for r in t[table] if r["id"] != first["id"]] + [alien]
            db = H.MemDB(t)
            before = copy.deepcopy(db.t)
            with self.assertRaises(R.RestoreError) as ctx:
                await self.run_restore(db)
            self.assertEqual((ctx.exception.code, ctx.exception.detail), ("id_conflict", table))
            await self.assert_unchanged(db, before)

    async def test_a_sanction_key_used_by_another_group_is_refused(self):
        t = drift_tables()
        s = backup_tables()["moderation_sanctions"][0]
        t["moderation_sanctions"] = [dict(s, id=77, group_id=G3)]       # same key, other id, other group
        db = H.MemDB(t)
        before = copy.deepcopy(db.t)
        with self.assertRaises(R.RestoreError) as ctx:
            await self.run_restore(db)
        self.assertEqual((ctx.exception.code, ctx.exception.detail), ("key_conflict", "moderation_sanctions"))
        await self.assert_unchanged(db, before)

    async def test_a_lost_row_is_caught_by_the_final_check(self):
        db = H.MemDB(drift_tables())
        before = copy.deepcopy(db.t)
        db.drop_one_on_insert = "group_trusted_users"
        with self.assertRaises(R.RestoreError) as ctx:
            await self.run_restore(db)
        self.assertEqual((ctx.exception.code, ctx.exception.detail), ("verify_failed", "group_trusted_users"))
        await self.assert_unchanged(db, before)

    async def test_a_writer_that_miscounts_deletions_or_creations_is_caught(self):
        for name, wrong in (("delete_for_groups", lambda n: n + 1), ("insert_rows", lambda n: n + 1), ("create_groups", lambda n: n + 1)):
            db = H.MemDB(drift_tables())
            before = copy.deepcopy(db.t)
            original = getattr(H.MemTx, name)

            async def lying(self, *a, __orig=original, __wrong=wrong, **k):
                return __wrong(await __orig(self, *a, **k))

            setattr(H.MemTx, name, lying)
            try:
                with self.assertRaises(R.RestoreError) as ctx:
                    await self.run_restore(db)
            finally:
                setattr(H.MemTx, name, original)
            self.assertEqual(ctx.exception.code, "verify_failed", name)
            await self.assert_unchanged(db, before)

    async def test_error_codes_are_closed(self):
        with self.assertRaises(ValueError):
            R.RestoreError("nope")
        self.assertEqual(len(set(R.ERROR_CODES)), len(R.ERROR_CODES))


class SignatureTests(ExecutorBase):
    def sig(self, db, now=NOW):
        return signature(db, now=now)

    def test_stable_over_time_and_sensitive_to_state(self):
        db = H.MemDB(drift_tables())
        a = self.sig(db)
        self.assertEqual(a, self.sig(db, NOW + timedelta(days=30)))     # the backup's age is not part of what was approved
        self.assertEqual(len(a), 12)
        db.t["group_trusted_bots"].append(dict(db.t["group_trusted_bots"][0], bot_id=1, group_id=G1))
        self.assertNotEqual(a, self.sig(db))

    def test_sensitive_to_the_file(self):
        db = H.MemDB(drift_tables())
        other = EMPTY
        self.assertNotEqual(self.sig(db), signature(db, other))

    def test_sensitive_to_licence_differences_and_defaults(self):
        db = H.MemDB(drift_tables())
        a = self.sig(db)
        db.t["telegram_groups"][0].update(license_status="stopped")
        self.assertNotEqual(a, self.sig(db))
        db2 = H.MemDB(drift_tables())
        db2.t["global_default_settings"][0]["version"] = 9
        self.assertNotEqual(a, self.sig(db2))


# ------------------------------------------------------------------------------------------------ service
class MemReader:
    def __init__(self, db):
        self.db = db
        self.calls = 0

    async def read(self):
        self.calls += 1
        return await H.MemTx(self.db).read_state()


class ConfirmBase(T.Base):
    def setup_confirm(self, db=None, *, data=None, executor=None, cooldown=20, confirm_cooldown=120, pending="default"):
        self.db = db if db is not None else H.MemDB(drift_tables())
        self.pending = PendingActions(clock=lambda: self.clock.now) if pending == "default" else pending
        self.build(data=data, reader=MemReader(self.db), cooldown=cooldown)
        self.service._pending = self.pending
        self.service._executor = executor if executor is not None else R.RestoreExecutor(self.db, clock=self.clock)
        self.service._confirm_cooldown = confirm_cooldown
        return self

    async def preview(self, mid=1):
        reply = await self.go("/restore", mid=mid)
        assert reply.status == "previewed", reply
        a = re.search(r"/restore confirm ([A-Z2-9]{6})\n", reply.text).group(1)
        b = re.search(r"with_license ([A-Z2-9]{6})", reply.text).group(1)
        return reply, (a, b)

    async def confirm(self, text, mid=2, **kw):
        return await self.go(text, mid=mid, **kw)

    def kinds(self):
        return [e.event_type for e in self.audit.events]


class ConfirmFlowTests(ConfirmBase):
    async def test_preview_issues_two_codes_and_confirm_applies(self):
        self.setup_confirm()
        reply, found = await self.preview()
        code, lcode = found
        self.assertNotEqual(code, lcode)
        self.assertIn(f"/restore confirm {code}", reply.text)
        self.assertIn(f"with_license {lcode}", reply.text)
        before = copy.deepcopy(self.db.t["telegram_groups"])
        out = await self.confirm(f"/restore confirm {code}")
        self.assertEqual(out.status, "applied")
        self.assertIn("✅", out.text)
        self.assertEqual(self.kinds(), [RESTORE_PREVIEWED, RESTORE_STARTED, RESTORE_APPLIED])
        self.assertEqual(next(r for r in self.db.t["telegram_groups"] if r["group_id"] == G1), next(r for r in before if r["group_id"] == G1))
        self.assertEqual(self.pending.peek(OWNER, "restore_license", lcode)["fingerprint"], backup().fingerprint)   # B was NOT consumed

    async def test_with_license_needs_the_second_code_and_applies_it(self):
        self.setup_confirm()
        _, (code, lcode, *_rest) = await self.preview()
        out = await self.confirm(f"/restore confirm {code} with_license {lcode}")
        self.assertEqual(out.status, "applied")
        g1 = next(r for r in self.db.t["telegram_groups"] if r["group_id"] == G1)
        self.assertEqual(g1["license_status"], "active_temporary")
        self.assertIn("طُبّقت", out.text)
        self.assertEqual(len(self.pending), 0)                           # both consumed

    async def test_code_a_cannot_stand_in_for_code_b_and_vice_versa(self):
        self.setup_confirm()
        _, (code, lcode, *_r) = await self.preview()
        for text in (f"/restore confirm {code} with_license {code}", f"/restore confirm {lcode}", f"/restore confirm {lcode} with_license {code}"):
            out = await self.confirm(text, mid=self.next_mid())
            self.assertEqual(out.status, "unknown_code", text)
        self.assertEqual(len(self.pending), 2)                           # nothing consumed by the wrong attempts
        self.assertEqual(self.db.committed, 0)

    _mid = 100

    def next_mid(self):
        ConfirmFlowTests._mid += 1
        return ConfirmFlowTests._mid

    async def test_a_wrong_code_consumes_nothing(self):
        self.setup_confirm()
        _, (code, lcode, *_r) = await self.preview()
        self.assertEqual((await self.confirm("/restore confirm ZZZZZZ", mid=3)).status, "unknown_code")
        self.assertEqual((await self.confirm(f"/restore confirm {code} with_license ZZZZZZ", mid=4)).status, "unknown_code")
        self.assertEqual(len(self.pending), 2)
        self.assertEqual(self.db.committed, 0)

    async def test_codes_are_single_use(self):
        self.setup_confirm(confirm_cooldown=0)
        _, (code, *_r) = await self.preview()
        self.assertEqual((await self.confirm(f"/restore confirm {code}", mid=3)).status, "applied")
        self.assertEqual((await self.confirm(f"/restore confirm {code}", mid=4)).status, "unknown_code")

    async def test_codes_expire(self):
        self.setup_confirm()
        _, (code, *_r) = await self.preview()
        self.clock.now += timedelta(minutes=11)
        self.assertEqual((await self.confirm(f"/restore confirm {code}", mid=3)).status, "unknown_code")
        self.assertEqual(self.db.committed, 0)

    async def test_a_different_file_is_refused_and_the_code_survives(self):
        self.setup_confirm()
        _, (code, *_r) = await self.preview()
        other = T.edited(lambda d: d["tables"]["group_settings"][0].update(language="en"))
        self.downloader.data = other
        out = await self.confirm(f"/restore confirm {code}", mid=3)
        self.assertEqual(out.status, "wrong_file")
        self.assertEqual(self.db.committed, 0)
        self.assertIn("code=wrong_file", [e.detail for e in self.audit.events if e.event_type == RESTORE_REJECTED][0])
        self.downloader.data = T.good()                                  # the right file still works with the same code
        self.assertEqual((await self.confirm(f"/restore confirm {code}", mid=4)).status, "applied")

    async def test_an_invalid_file_on_confirm_is_refused_without_consuming(self):
        self.setup_confirm()
        _, (code, *_r) = await self.preview()
        self.downloader.data = b"not json"
        self.assertEqual((await self.confirm(f"/restore confirm {code}", mid=3)).status, "invalid")
        self.assertEqual(len(self.pending), 2)

    async def test_the_preview_the_owner_approved_must_still_be_true(self):
        self.setup_confirm()
        _, (code, *_r) = await self.preview()
        self.db.t["moderation_warnings"].append(dict(self.db.t["moderation_warnings"][0], id=70, idempotency_key="w70"))
        before = copy.deepcopy(self.db.t)
        out = await self.confirm(f"/restore confirm {code}", mid=3)
        self.assertEqual(out.status, "rolled_back")
        self.assertIn("تغيّرت", out.text)
        self.assertEqual(self.db.t, before)
        self.assertEqual(self.kinds(), [RESTORE_PREVIEWED, RESTORE_STARTED, RESTORE_FAILED])
        self.assertIn("code=state_changed", self.audit.events[-1].detail)
        self.assertEqual(len(self.pending), 1)                           # A consumed (single use); B was never used and still lives

    async def test_the_two_codes_must_belong_to_the_same_file_and_preview(self):
        self.setup_confirm()
        fp = backup().fingerprint
        good_sig = signature(self.db)
        cases = [({"fingerprint": fp, "signature": good_sig}, {"fingerprint": "0" * 12, "signature": good_sig}),
                 ({"fingerprint": fp, "signature": good_sig}, {"fingerprint": fp, "signature": "0" * 12}),
                 ({"fingerprint": "0" * 12, "signature": good_sig}, {"fingerprint": fp, "signature": good_sig})]
        for i, (a, b) in enumerate(cases):
            code = self.pending.create(OWNER, "restore", a)
            lcode = self.pending.create(OWNER, "restore_license", b)
            out = await self.confirm(f"/restore confirm {code} with_license {lcode}", mid=50 + i)
            self.assertEqual(out.status, "wrong_file", i)
            self.assertIsNotNone(self.pending.peek(OWNER, "restore", code))              # nothing consumed
        self.assertEqual(self.db.committed, 0)
        # the same wrong payload on code A alone (no licence option) is refused too
        code = self.pending.create(OWNER, "restore", {"fingerprint": "0" * 12, "signature": good_sig})
        self.assertEqual((await self.confirm(f"/restore confirm {code}", mid=70)).status, "wrong_file")

    async def test_a_code_taken_by_someone_else_in_between_is_unknown(self):
        self.setup_confirm()
        _, (code, *_r) = await self.preview()
        real_take = self.pending.take
        self.pending.take = lambda *a, **k: None
        try:
            self.assertEqual((await self.confirm(f"/restore confirm {code}", mid=3)).status, "unknown_code")
        finally:
            self.pending.take = real_take
        self.assertEqual(self.db.committed, 0)

    async def test_every_rollback_code_has_a_message(self):
        for code in R.ERROR_CODES:
            self.assertIn(code, _ROLLBACK_KEYS)
            for lang in ("ar", "en"):
                self.assertIn(_ROLLBACK_KEYS[code], i18n.MESSAGES[lang])

    async def test_the_executor_crashing_is_reported_as_a_rollback(self):
        class Boom:
            async def execute(self, *a, **k):
                raise RuntimeError("secret-looking /etc/passwd 123456:ABCDEF")

        self.setup_confirm(executor=Boom())
        _, (code, *_r) = await self.preview()
        out = await self.confirm(f"/restore confirm {code}", mid=3)
        self.assertEqual(out.status, "rolled_back")
        self.assertNotIn("passwd", out.text + repr(self.audit.events))
        self.assertIn("code=crashed", self.audit.events[-1].detail)

    async def test_restore_error_codes_pass_through_to_the_message(self):
        class Fail:
            async def execute(self, *a, **k):
                raise R.RestoreError("id_conflict", "moderation_warnings")

        self.setup_confirm(executor=Fail())
        _, (code, *_r) = await self.preview()
        out = await self.confirm(f"/restore confirm {code}", mid=3)
        self.assertEqual(out.status, "rolled_back")
        self.assertIn("moderation_warnings", out.text)
        self.assertIn("where=moderation_warnings", self.audit.events[-1].detail)


class ConfirmGateTests(ConfirmBase):
    async def test_only_the_owner_and_silence_for_everybody_else(self):
        self.setup_confirm()
        _, (code, *_r) = await self.preview()
        for who in (BACKUP, STRANGER, 5):
            self.assertIsNone(await self.confirm(f"/restore confirm {code}", user=who, mid=who + 10))
        self.assertEqual(self.db.committed, 0)
        self.assertEqual(len(self.pending), 2)

    async def test_private_chat_only(self):
        self.setup_confirm()
        _, (code, *_r) = await self.preview()
        self.assertIsNone(await self.confirm(f"/restore confirm {code}", chat=-100500, chat_type="supergroup", mid=5))
        self.assertEqual(self.db.committed, 0)

    async def test_no_file(self):
        self.setup_confirm()
        _, (code, *_r) = await self.preview()
        out = await self.confirm(f"/restore confirm {code}", doc=None, mid=5)
        self.assertEqual(out.status, "no_file")
        self.assertEqual(len(self.pending), 2)

    async def test_a_redelivered_confirm_is_silent_and_runs_once(self):
        self.setup_confirm(confirm_cooldown=0)
        _, (code, *_r) = await self.preview()
        self.assertEqual((await self.confirm(f"/restore confirm {code}", mid=9)).status, "applied")
        self.assertIsNone(await self.confirm(f"/restore confirm {code}", mid=9))
        self.assertEqual(self.db.committed, 1)

    async def test_cooldown_after_a_restore_and_one_at_a_time(self):
        self.setup_confirm()
        _, (code, *_r) = await self.preview()
        self.assertEqual((await self.confirm(f"/restore confirm {code}", mid=3)).status, "applied")
        again = await self.confirm("/restore confirm ABCDEF", mid=4)
        self.assertEqual(again.status, "cooldown")
        self.clock.now += timedelta(seconds=121)
        self.assertEqual((await self.confirm("/restore confirm ABCDEF", mid=5)).status, "unknown_code")

    async def test_one_restore_at_a_time(self):
        self.setup_confirm(confirm_cooldown=0)
        gate = asyncio.Event()

        class Slow:
            async def execute(inner, *a, **k):
                await gate.wait()
                return await R.RestoreExecutor(self.db, clock=self.clock).execute(*a, **k)

        self.service._executor = Slow()
        _, (code, *_r) = await self.preview()
        first = asyncio.create_task(self.confirm(f"/restore confirm {code}", mid=3))
        await asyncio.sleep(0.02)
        self.assertEqual((await self.confirm("/restore confirm ABCDEF", mid=4)).status, "busy")
        gate.set()
        self.assertEqual((await first).status, "applied")

    async def test_confirm_is_unavailable_without_codes_or_an_executor(self):
        self.setup_confirm(pending=None)
        self.assertEqual((await self.confirm("/restore confirm ABCDEF", mid=3)).status, "unavailable")
        reply = await self.go("/restore", mid=4)                            # the preview still works, without codes
        self.assertEqual(reply.status, "previewed")
        self.assertNotIn("confirm", reply.text)
        self.assertIn(i18n.t("rs_footer", "ar"), reply.text)
        self.setup_confirm()
        self.service._executor = None
        self.assertEqual((await self.confirm("/restore confirm ABCDEF", mid=3)).status, "unavailable")

    async def test_the_audit_never_carries_content(self):
        self.setup_confirm()
        _, (code, lcode, *_r) = await self.preview()
        await self.confirm(f"/restore confirm {code} with_license {lcode}", mid=3)
        text = repr(self.audit.events)
        for leaked in ("مجموعة", "Second", "spam", "444", code, lcode):
            self.assertNotIn(leaked, text)
        applied = next(e for e in self.audit.events if e.event_type == RESTORE_APPLIED)
        self.assertIn("with_license=1", applied.detail)
        self.assertIn(backup().fingerprint, applied.detail)


class PreviewCodesTests(ConfirmBase):
    async def test_the_codes_bind_the_file_and_the_signature(self):
        self.setup_confirm()
        reply, (code, lcode, *_r) = await self.preview()
        a, b = self.pending.peek(OWNER, "restore", code), self.pending.peek(OWNER, "restore_license", lcode)
        self.assertEqual(a, b)
        self.assertEqual(set(a), {"fingerprint", "signature"})
        self.assertEqual(a["fingerprint"], backup().fingerprint)
        self.assertEqual(a["signature"], signature(self.db))

    async def test_an_invalid_file_gets_no_codes(self):
        self.setup_confirm(data=b"nope")
        self.assertEqual((await self.go("/restore", mid=3)).status, "invalid")
        self.assertEqual(len(self.pending), 0)

    async def test_a_second_preview_does_not_invalidate_the_first_codes(self):
        self.setup_confirm()
        _, (code, *_r) = await self.preview(mid=1)
        self.clock.now += timedelta(seconds=25)
        await self.preview(mid=2)
        self.assertIsNotNone(self.pending.peek(OWNER, "restore", code))


# ------------------------------------------------------------------------------------------------ command layer
class CommandTests(unittest.TestCase):
    def test_confirm_forms(self):
        p = lambda s: parse_restore_command(s, "GuardBot")  # noqa: E731
        self.assertEqual((p("/restore confirm abc234").action, p("/restore confirm abc234").code), ("confirm", "ABC234"))
        both = p("/restore@GuardBot confirm ABC234 with_license XYZ789")
        self.assertEqual((both.action, both.code, both.license_code), ("confirm", "ABC234", "XYZ789"))
        self.assertEqual(p("/restore CONFIRM ABC234 WITH_LICENSE XYZ789").license_code, "XYZ789")
        ar = p("استعادة نسخة تأكيد ABC234 ترخيص XYZ789")
        self.assertEqual((ar.action, ar.code, ar.license_code), ("confirm", "ABC234", "XYZ789"))
        self.assertEqual(p("استعادة تأكيد ABC234").code, "ABC234")
        for bad in ("/restore confirm", "/restore confirm ABC", "/restore confirm ABC234 XYZ789", "/restore confirm ABC234 with_license",
                    "/restore confirm ABC234 with_license XYZ78", "/restore confirm 0OIL01", "/restore confirm ABC234 extra",
                    "/restore confirm ABC234 with_license XYZ789 more"):
            self.assertEqual(p(bad).action, "usage", bad)
        self.assertIsNone(p("/restore@Other confirm ABC234"))
        self.assertIsNone(p("استعادة شيء"))

    def test_preview_text_with_and_without_codes(self):
        p = P.build_preview(backup(), P.CurrentState({}, {}, {}, None), NOW)
        with_codes = render_preview(p, "ar", code="ABC234", license_code="XYZ789", minutes=10)
        self.assertIn("/restore confirm ABC234\n", with_codes)
        self.assertIn("/restore confirm ABC234 with_license XYZ789", with_codes)
        self.assertIn("10", with_codes)
        self.assertLess(len(with_codes), 3800)
        self.assertNotIn("confirm", render_preview(p, "ar"))

    def test_applied_text(self):
        r = R.RestoreResult("abcdef123456", True, 2, 1, 10, 12, 3, 2, ())
        text = render_applied(r, "ar")
        for needle in ("ABCDEF123456", "2", "10", "12", "3"):
            self.assertIn(needle, text)
        self.assertIn("طُبّقت", text)
        off = render_applied(R.RestoreResult("abcdef123456", False, 0, 0, 0, 0, 0, 0, ()), "en")
        self.assertIn("NOT applied", off)

    def test_messages_in_both_languages(self):
        ar = {k for k in i18n.MESSAGES["ar"] if k.startswith("rs_")}
        self.assertEqual(ar, {k for k in i18n.MESSAGES["en"] if k.startswith("rs_")})
        for lang in ("ar", "en"):
            for key, text in i18n.MESSAGES[lang].items():
                if key.startswith("rs_"):
                    i18n.t(key, lang, **{n: "1" for n in re.findall(r"{(\w+)}", text)})


# ------------------------------------------------------------------------------------------------ the SQL writer over a fake connection
class PgWriterTests(unittest.IsolatedAsyncioTestCase):
    def conn(self, **kw):
        b = backup()
        groups = {G1: ("expired", None), G3: ("pending", None)}
        counts = {"moderation_warnings": {G1: 3, G3: 1}, "group_settings": {G1: 1, G3: 1}, "license_audit_log": {G1: 2}}
        return H.FakeConn(groups=groups, counts=counts, global_counts={"settings_templates": 2, "global_default_settings": 1}, **kw)

    async def run_writer(self, conn, *, with_license=False, sig=None):
        db = H.FakeDatabase(conn)
        bk = backup()
        state = await PS.PostgresRestoreStateReader(db).read()
        sig = sig or R.preview_signature(P.build_preview(bk, state, NOW))
        conn.sql.clear()
        conn.events.clear()
        return await R.RestoreExecutor(PR.PostgresRestoreWriter(db), clock=lambda: NOW).execute(
            bk, expected_signature=sig, owner_id=OWNER, with_license=with_license)

    def statements(self, conn):
        return [s for s, _ in conn.sql]

    async def test_one_transaction_with_locks_first(self):
        conn = self.conn()
        result = await self.run_writer(conn)
        self.assertEqual([e[0] for e in conn.events], ["begin", "begin", "commit", "commit"] if False else [e[0] for e in conn.events])
        self.assertEqual(conn.events[0][0], "begin")
        self.assertEqual(conn.events[-1][0], "commit")
        self.assertNotIn("rollback", [e[0] for e in conn.events])
        sql = self.statements(conn)
        self.assertTrue(sql[0].startswith("SET LOCAL lock_timeout"))
        self.assertTrue(sql[1].startswith("SET LOCAL statement_timeout"))
        self.assertTrue(sql[2].startswith("SELECT pg_advisory_xact_lock"))
        locks = [s for s in sql if s.startswith("LOCK TABLE")]
        self.assertEqual(locks, [f"LOCK TABLE {t} IN SHARE ROW EXCLUSIVE MODE" for t in PR.LOCK_ORDER])
        self.assertEqual(sql[3:3 + len(locks)], locks)
        self.assertEqual(len(PR.LOCK_ORDER), len(F.TABLE_NAMES))
        self.assertEqual((result.groups_added, result.groups_replaced), (1, 1))

    async def test_statements_follow_the_policy(self):
        conn = self.conn()
        await self.run_writer(conn)
        sql = self.statements(conn)
        idx = lambda prefix: next(i for i, s in enumerate(sql) if s.startswith(prefix))  # noqa: E731
        self.assertLess(idx("INSERT INTO telegram_groups"), idx("DELETE FROM group_settings WHERE group_id = ANY"))
        for table in P.REPLACED_PER_GROUP:
            self.assertLess(idx(f"DELETE FROM {table} WHERE group_id = ANY"), idx(f"INSERT INTO {table} "))
        for table in P.GLOBAL_REPLACED:
            self.assertLess(sql.index(f"DELETE FROM {table}"), idx(f"INSERT INTO {table} "))
        self.assertEqual([s for s in sql if "license_audit_log" in s and (s.startswith("DELETE") or s.startswith("UPDATE") or "TRUNCATE" in s)], [])
        self.assertFalse([s for s in sql if s.startswith("INSERT INTO license_audit_log")])       # without with_license
        self.assertFalse([s for s in sql if s.startswith("UPDATE telegram_groups")])
        self.assertTrue(any("setval" in s for s in sql))
        self.assertTrue(sql[-1].startswith("SELECT") or sql[-1].startswith("SELECT"))            # the final verification reads

    async def test_the_new_group_is_created_unlicensed(self):
        conn = self.conn()
        await self.run_writer(conn)
        _, rows = next((s, a) for s, a in conn.sql if s.startswith("INSERT INTO telegram_groups"))
        (row,) = rows
        names = [c.name for c in F.BY_NAME["telegram_groups"].columns]
        d = dict(zip(names, row))
        self.assertEqual((d["group_id"], d["license_status"], d["activated_at"], d["expires_at"], d["activated_by"], d["status_note"]),
                         (G2, "pending", None, None, None, None))

    async def test_with_license_updates_and_appends_with_typed_parameters(self):
        conn = self.conn()
        result = await self.run_writer(conn, with_license=True)
        updates = [(s, a) for s, a in conn.sql if s.startswith("UPDATE telegram_groups")]
        self.assertEqual(len(updates), 1)
        self.assertEqual(updates[0][1][0:2], (G1, "active_temporary"))
        inserts = [(s, a) for s, a in conn.sql if s.startswith("INSERT INTO license_audit_log")]
        self.assertTrue(inserts)
        for sql, args in inserts:
            self.assertEqual(len(args), 8)
            self.assertIn("$8::timestamptz", sql)
        self.assertTrue(any("NOT EXISTS" in s for s, _ in inserts))        # the file's own rows: skip identical ones
        self.assertTrue(any("NOT EXISTS" not in s for s, _ in inserts))    # this restore's own rows: always appended
        self.assertEqual(result.license_updated, 1)

    async def test_json_columns_are_sent_as_text_and_timestamps_as_datetimes(self):
        conn = self.conn()
        await self.run_writer(conn)
        sql, rows = next((s, a) for s, a in conn.sql if s.startswith("INSERT INTO group_settings"))
        self.assertIn("$3::jsonb", sql)
        for row in rows:
            self.assertIsInstance(row[2], str)
            self.assertIn("{", row[2])
            self.assertEqual(row[3].tzinfo is not None, True)
        self.assertIn("قيمة", "".join(r[2] for r in rows))                  # not ASCII-escaped

    async def test_sequences_never_go_backwards(self):
        conn = self.conn()
        await self.run_writer(conn)
        self.assertEqual(len(conn.setvals), len(R.ID_TABLES))
        for seq, value in conn.setvals:
            self.assertEqual(value, 11)            # last_value 10 (is_called) -> next 11 > max(id)+1 = 8

    async def test_the_final_check_and_state_change_use_the_same_connection(self):
        conn = self.conn()
        db = H.FakeDatabase(conn)
        with self.assertRaises(R.RestoreError) as ctx:
            await R.RestoreExecutor(PR.PostgresRestoreWriter(db), clock=lambda: NOW).execute(
                backup(), expected_signature="000000000000", owner_id=OWNER, with_license=False)
        self.assertEqual(ctx.exception.code, "state_changed")
        self.assertEqual(conn.events[-1][0], "rollback")
        self.assertFalse([s for s, _ in conn.sql if s.startswith(("DELETE", "INSERT", "UPDATE"))])

    async def test_id_and_key_conflicts_are_refused_before_any_write(self):
        for kw, code in (({"id_conflict": True}, "id_conflict"), ({"key_conflict": True}, "key_conflict")):
            conn = self.conn(**kw)
            if code == "key_conflict":
                conn.id_conflict = False
            with self.assertRaises(R.RestoreError) as ctx:
                await self.run_writer(conn)
            self.assertEqual(ctx.exception.code, "id_conflict" if code == "id_conflict" else ctx.exception.code)
            self.assertEqual(conn.events[-1][0], "rollback")
            self.assertFalse([s for s, _ in conn.sql if s.startswith(("DELETE", "INSERT", "UPDATE"))], code)

    async def test_driver_errors_become_closed_codes_without_their_message(self):
        cases = [(H.UniqueViolationError("duplicate key value (secret-token-123)"), "constraint_failed"),
                 (H.LockNotAvailableError("could not obtain lock"), "lock_timeout"), (RuntimeError("password=hunter2"), "db_failed"),
                 (OSError("connection reset"), "db_failed")]
        for exc, code in cases:
            conn = self.conn()
            db = H.FakeDatabase(conn)
            bk = backup()
            state = await PS.PostgresRestoreStateReader(db).read()
            sig = R.preview_signature(P.build_preview(bk, state, NOW))
            conn.fail_on = ("DELETE FROM moderation_sanctions", exc)
            with self.assertRaises(R.RestoreError) as ctx:
                await R.RestoreExecutor(PR.PostgresRestoreWriter(db), clock=lambda: NOW).execute(bk, expected_signature=sig, owner_id=OWNER, with_license=False)
            self.assertEqual(ctx.exception.code, code)
            self.assertNotIn("secret-token", str(ctx.exception) + repr(ctx.exception.__cause__))
            self.assertEqual(conn.events[-1][0], "rollback")

    def test_the_exact_guard_statements(self):
        self.assertEqual(PR.ID_CONFLICT_SQL, "SELECT count(*) FROM {table} WHERE id = ANY($1::bigint[]) AND NOT (group_id = ANY($2::bigint[]))")
        self.assertEqual(PR.KEY_CONFLICT_SQL, "SELECT count(*) FROM moderation_sanctions WHERE idempotency_key = ANY($1::text[]) "
                                              "AND NOT (group_id = ANY($2::bigint[]))")
        self.assertEqual((PR.LOCK_TIMEOUT, PR.STATEMENT_TIMEOUT), ("10s", "120s"))

    async def test_the_session_limits_are_set_with_their_values(self):
        conn = self.conn()
        await self.run_writer(conn)
        sql = self.statements(conn)
        self.assertEqual(sql[0], "SET LOCAL lock_timeout = '10s'")
        self.assertEqual(sql[1], "SET LOCAL statement_timeout = '120s'")

    def test_helpers_and_whitelists(self):
        self.assertEqual((PR.affected("DELETE 3"), PR.affected("INSERT 0 1"), PR.affected("x"), PR.affected(None)), (3, 1, 0, 0))
        self.assertEqual(PR.insert_sql("global_default_settings"),
                         "INSERT INTO global_default_settings (singleton, settings, version, updated_by, updated_at) VALUES ($1, $2::jsonb, $3, $4, $5)")
        for bad in ("security_audit_log", "users; DROP TABLE x", "daily_group_counters"):
            with self.assertRaises(ValueError):
                PR._table(bad)
        self.assertEqual(PR.map_error(R.RestoreError("verify_failed", "x")).code, "verify_failed")


class PgWriterGuardTests(unittest.IsolatedAsyncioTestCase):
    async def test_the_licence_log_has_no_delete_or_update_path(self):
        tx = PR._Tx(H.FakeConn())
        for call in (tx.delete_for_groups(P.LOG_TABLE, [G1]), tx.delete_all(P.LOG_TABLE), tx.insert_rows(P.LOG_TABLE, [])):
            with self.assertRaises(ValueError):
                await call
        with self.assertRaises(ValueError):
            await tx.delete_all("settings_templates_x")
        with self.assertRaises(ValueError):
            await tx.delete_for_groups("global_default_settings", [G1])
        with self.assertRaises(ValueError):
            await tx.id_conflicts("group_settings", [1], [G1])
        with self.assertRaises(ValueError):
            await tx.reset_sequences(("telegram_groups",))


class ScopeGuards(unittest.TestCase):
    def text(self, name):
        return (SRC / "backup" / name).read_text(encoding="utf-8")

    def test_only_postgres_restore_writes(self):
        pattern = re.compile(r"\b(INSERT\s+INTO|UPDATE\s+\w+\s+SET|DELETE\s+FROM|TRUNCATE|DROP\s+TABLE|ALTER\s+TABLE|CREATE\s+TABLE|LOCK\s+TABLE)\b", re.I)
        for path in sorted((SRC / "backup").glob("*.py")):
            found = pattern.search(path.read_text(encoding="utf-8"))
            if path.name == "postgres_restore.py":
                self.assertIsNotNone(found)
            else:
                self.assertIsNone(found, path.name)

    def test_the_writer_never_touches_the_audit_tables_or_other_tables(self):
        text = self.text("postgres_restore.py")
        self.assertNotIn("security_audit_log", text)
        self.assertNotRegex(text, r"(DELETE FROM|UPDATE|TRUNCATE)\s+license_audit_log")
        self.assertNotRegex(text, r"(DELETE FROM|UPDATE|INSERT INTO)\s+(daily_group_counters|report_schedule|group_members|schema_migrations)")
        self.assertIn("pg_advisory_xact_lock", text)
        self.assertIn("SHARE ROW EXCLUSIVE", text)
        self.assertEqual(text.count("conn.transaction()"), 1)

    def test_executor_is_driver_free(self):
        imports = "\n".join(l for l in self.text("restore.py").splitlines() if re.match(r"\s*(from|import)\s", l))
        for forbidden in ("asyncpg", "aiogram", "postgres", "bot."):
            self.assertNotIn(forbidden, imports)

    def test_new_audit_events_exist_and_the_command_is_still_owner_private(self):
        from guardian import audit
        for name in ("RESTORE_STARTED", "RESTORE_APPLIED", "RESTORE_FAILED"):
            self.assertTrue(hasattr(audit, name))
        self.assertIn("PostgresRestoreWriter(database)", (SRC / "app.py").read_text(encoding="utf-8"))
        self.assertNotIn("restore", (SRC / "bot" / "commands_menu.py").read_text(encoding="utf-8").lower())

    def test_pending_peek_consumes_nothing(self):
        p = PendingActions()
        code = p.create(1, "k", {"a": 1})
        self.assertEqual(p.peek(1, "k", code.lower()), {"a": 1})
        self.assertEqual(p.peek(1, "k", code), {"a": 1})
        self.assertIsNone(p.peek(2, "k", code))
        self.assertIsNone(p.peek(1, "other", code))
        self.assertIsNone(p.peek(1, "k", None))
        self.assertEqual(p.take(1, "k", code), {"a": 1})
        self.assertIsNone(p.peek(1, "k", code))


if __name__ == "__main__":
    unittest.main()
