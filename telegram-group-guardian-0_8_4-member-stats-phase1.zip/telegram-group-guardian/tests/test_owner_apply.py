"""Phase 5 / part 5.7: applying templates (confirmation + stale guard + per-group audit) and the global defaults for NEW groups.
aiogram/PostgreSQL are NOT exercised: the Postgres defaults store runs against a recording fake connection."""
from __future__ import annotations

import re
import unittest
from contextlib import asynccontextmanager
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace as NS

import helpers  # noqa: F401
from guardian.audit import DEFAULTS_CHANGED, FORGED_CALLBACK, SETTINGS_CHANGED, TEMPLATE_APPLIED
from guardian.errors import InvalidInput, PermissionDenied
from guardian.i18n import MESSAGES
from guardian.idempotency import InMemoryIdempotency
from guardian.licensing.models import LicenseStatus
from guardian.licensing.service import LicenseService
from guardian.owner_panel import codec
from guardian.owner_panel.service import OwnerPanelService
from guardian.owner_panel.template_commands import (
    ParsedTemplateCommand as P, TemplateCommandService, parse_template_command)
from guardian.owner_templates.apply import MAX_GROUPS, TemplateApplyService, plan_digest
from guardian.owner_templates.defaults import (
    DefaultsSeeder, GlobalDefaultsService, InMemoryDefaultsStore, PostgresDefaultsStore)
from guardian.owner_templates.overview import GroupOverviewService
from guardian.owner_templates.pending import ALPHABET, CODE_LEN, MAX_PENDING, PendingActions
from guardian.owner_templates.templates import InMemoryTemplateStore, TemplateService, effective_settings
from stack import A, B, BACKUP, DELEGATE, NOW, OWNER, STRANGER, TG_CREATOR, Stack

SRC = Path(__file__).resolve().parents[1] / "src" / "guardian"
SECRET = "owner-panel-test-secret-0123456789"
KEY = codec.derive_key(SECRET)
C = -1003


def cb(screen, chat=OWNER, **kw):
    return codec.build(KEY, chat, screen, **kw)


def flat(outcome):
    return [b for row in (outcome.buttons or ()) for b in row]


def find(outcome, needle):
    for label, data in flat(outcome):
        if needle in label:
            return data
    raise AssertionError(f"no button containing {needle!r} in {[l for l, _ in flat(outcome)]}")


class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        self.store = InMemoryTemplateStore()
        self.claims = InMemoryIdempotency()
        self.tpl = TemplateService(self.store, self.s.licenses, self.s.settings_store, self.s.perm, self.s.audit, clock=self.s.clock)
        self.apply = TemplateApplyService(self.tpl, self.s.licenses, self.s.settings, self.claims, self.s.audit)
        self.pending = PendingActions(clock=self.s.clock)
        self.dstore = InMemoryDefaultsStore()
        self.defaults = GlobalDefaultsService(self.dstore, self.tpl, self.s.perm, self.pending, self.s.audit, clock=self.s.clock)
        await self.s.register(A, B, C)
        for g in (A, B, C):
            await self.s.admin.activate_permanent(OWNER, g, context_chat_id=g)
        await self.s.settings_store.merge(A, {"warn_limit": 7, "flood_max_messages": 9}, OWNER, NOW)
        self.t, _ = await self.tpl.save_from_group(OWNER, "Strict", A)         # id 1: warn 7 / flood 9 (+ defaults elsewhere)

    def settings_of(self, gid):
        row = self.s.settings_store._rows.get(gid)
        return dict(row.settings) if row else {}

    def snapshot(self):
        return ({g: self.settings_of(g) for g in (A, B, C)}, dict(self.s.licenses._rows), list(self.s.licenses.audit_log))

    def events(self, kind):
        return [e for e in self.s.audit.events if e.event_type == kind]


# ----------------------------------------------------------------------------- confirmation codes
class PendingTests(unittest.TestCase):
    def setUp(self):
        from stack import Clock
        self.clock = Clock()
        self.p = PendingActions(clock=self.clock, ttl=600)

    def test_code_shape_and_single_use(self):
        code = self.p.create(OWNER, "apply", {"x": 1})
        self.assertEqual(len(code), CODE_LEN)
        self.assertTrue(set(code) <= set(ALPHABET))
        self.assertEqual(self.p.take(OWNER, "apply", code), {"x": 1})
        self.assertIsNone(self.p.take(OWNER, "apply", code))

    def test_wrong_owner_or_kind_fails_and_consumes_nothing(self):
        code = self.p.create(OWNER, "apply", 1)
        self.assertIsNone(self.p.take(STRANGER, "apply", code))
        self.assertIsNone(self.p.take(OWNER, "defaults", code))
        self.assertEqual(self.p.take(OWNER, "apply", code), 1)

    def test_case_space_and_junk_input(self):
        code = self.p.create(OWNER, "apply", 1)
        for bad in (None, 5, b"x", "", "ZZZZZZ", code[:-1]):
            self.assertIsNone(self.p.take(OWNER, "apply", bad))
        self.assertEqual(self.p.take(OWNER, "apply", f" {code.lower()} "), 1)

    def test_expiry(self):
        code = self.p.create(OWNER, "apply", 1)
        self.clock.advance(seconds=599)
        self.assertEqual(len(self.p), 1)
        self.clock.advance(seconds=1)
        self.assertIsNone(self.p.take(OWNER, "apply", code))
        self.assertEqual(len(self.p), 0)

    def test_bounded_and_oldest_dropped(self):
        first = self.p.create(OWNER, "apply", 0)
        for i in range(MAX_PENDING):
            self.clock.advance(seconds=1)
            self.p.create(OWNER, "apply", i + 1)
        self.assertEqual(len(self.p), MAX_PENDING)
        self.assertIsNone(self.p.take(OWNER, "apply", first))
        self.assertEqual(self.p.ttl_minutes, 10)


# ----------------------------------------------------------------------------- codec
class CodecTests(unittest.TestCase):
    def test_apply_screens_round_trip(self):
        ask = codec.parse(cb(codec.APPLY_ASK, template_id=5, group_id=-9, filter="b", page=2))
        run = codec.parse(cb(codec.APPLY_DO, template_id=5, group_id=-9, digest="0a1b2c", filter="b", page=2))
        self.assertEqual((ask.screen, ask.template_id, ask.group_id, ask.digest), ("k", 5, -9, None))
        self.assertEqual((run.screen, run.template_id, run.group_id, run.digest, run.filter, run.page), ("z", 5, -9, "0a1b2c", "b", 2))
        for c in (ask, run):
            self.assertTrue(codec.verify(KEY, OWNER, c))
            self.assertFalse(codec.verify(KEY, OWNER + 1, c))

    def test_the_digest_is_signed_and_validated(self):
        data = cb(codec.APPLY_DO, template_id=5, group_id=-9, digest="0a1b2c")
        self.assertFalse(codec.verify(KEY, OWNER, codec.parse(data.replace("0a1b2c", "0a1b2d"))))
        for bad in (None, "", "12345", "1234567", "ABCDEF", "12345g"):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                cb(codec.APPLY_DO, template_id=5, group_id=-9, digest=bad)
        tag = "0" * 12
        for data in (f"ow:z:5:-9:ABCDEF:a:0:{tag}", f"ow:z:5:-9:a:0:{tag}", f"ow:z:0:-9:abcdef:a:0:{tag}", f"ow:k:5:-9:abcdef:a:0:{tag}"):
            self.assertIsNone(codec.parse(data))

    def test_worst_case_fits_64_bytes(self):
        data = cb(codec.APPLY_DO, template_id=codec.MAX_TEMPLATE_ID, group_id=-(10**18), digest="abcdef", filter="b", page=codec.MAX_PAGE)
        self.assertLessEqual(len(data.encode()), 64)


# ----------------------------------------------------------------------------- applying
class ApplyServiceTests(Base):
    async def test_preview_is_read_only_and_lists_exact_changes(self):
        before = self.snapshot()
        pv = await self.apply.preview(OWNER, self.t.id, [B, C, -4242, B])
        self.assertEqual(self.snapshot(), before)
        self.assertEqual([i.group_id for i in pv.items], [B, C])
        self.assertEqual(pv.skipped, (-4242,))
        self.assertEqual({e.key for e in pv.items[0].entries}, {"warn_limit", "flood_max_messages"})
        self.assertEqual(pv.items[0].digest, plan_digest(pv.template, pv.items[0].entries))
        self.assertIsNone(await self.apply.preview(OWNER, 999, [B]))

    async def test_preview_limits(self):
        for ids in ([], list(range(-1, -(MAX_GROUPS + 2), -1))):
            with self.assertRaises(InvalidInput):
                await self.apply.preview(OWNER, self.t.id, ids)
        self.assertEqual((await self.apply.preview(OWNER, self.t.id, [-4242])).items, ())

    async def test_execute_writes_only_the_differing_keys(self):
        await self.store.upsert("Mini", "mini", {"warn_limit": 5, "links_enabled": False}, OWNER, None, NOW)
        await self.s.settings_store.merge(B, {"links_enabled": False, "slowmode_seconds": 30, "dry_run": True}, OWNER, NOW)
        pv = await self.apply.preview(OWNER, 2, [B])
        out = await self.apply.execute(OWNER, 2, [(B, pv.items[0].digest)], "b1")
        self.assertEqual([(o.status, o.keys) for o in out], [("applied", 1)])
        self.assertEqual(self.settings_of(B), {"links_enabled": False, "slowmode_seconds": 30, "dry_run": True, "warn_limit": 5})

    async def test_full_template_never_touches_dry_run_or_unknown_keys(self):
        await self.s.settings_store.merge(B, {"dry_run": True, "custom_thing": [1]}, OWNER, NOW)
        pv = await self.apply.preview(OWNER, self.t.id, [B])
        await self.apply.execute(OWNER, self.t.id, [(B, pv.items[0].digest)], "b1")
        self.assertIs(self.settings_of(B)["dry_run"], True)
        self.assertEqual(self.settings_of(B)["custom_thing"], [1])
        self.assertEqual((self.settings_of(B)["warn_limit"], self.settings_of(B)["flood_max_messages"]), (7, 9))
        self.assertEqual(effective_settings(self.settings_of(B)), self.t.settings)

    async def test_audit_per_group_names_keys_but_never_values(self):
        pv = await self.apply.preview(OWNER, self.t.id, [B, C])
        await self.apply.execute(OWNER, self.t.id, [(i.group_id, i.digest) for i in pv.items], "b1")
        applied = self.events(TEMPLATE_APPLIED)
        self.assertEqual(sorted(e.group_id for e in applied), [C, B])
        for e in applied:
            self.assertEqual(e.actor_telegram_id, OWNER)
            self.assertIn("template=1", e.detail)
            self.assertIn("warn_limit", e.detail)
            self.assertNotIn("=7", e.detail)
        self.assertGreaterEqual(len([e for e in self.events(SETTINGS_CHANGED) if e.group_id in (B, C)]), 2)

    async def test_a_stale_group_is_refused_and_nothing_is_written(self):
        pv = await self.apply.preview(OWNER, self.t.id, [B])
        await self.s.settings_store.merge(B, {"warn_limit": 4}, OWNER, NOW)           # somebody changed it after the preview
        before = self.snapshot()
        out = await self.apply.execute(OWNER, self.t.id, [(B, pv.items[0].digest)], "b1")
        self.assertEqual(out[0].status, "stale")
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(self.events(TEMPLATE_APPLIED), [])

    async def test_a_template_edited_after_the_preview_is_stale(self):
        pv = await self.apply.preview(OWNER, self.t.id, [B])
        await self.s.settings_store.merge(A, {"warn_limit": 2}, OWNER, NOW)
        self.s.clock.advance(minutes=1)
        await self.tpl.save_from_group(OWNER, "Strict", A)                            # same id, new content
        out = await self.apply.execute(OWNER, self.t.id, [(B, pv.items[0].digest)], "b1")
        self.assertEqual(out[0].status, "stale")
        self.assertEqual(self.settings_of(B), {})

    async def test_bad_digests_are_stale(self):
        for seen in ("", None, "zzzzzz", "000000", 5):
            with self.subTest(seen=seen):
                out = await self.apply.execute(OWNER, self.t.id, [(B, seen)], f"b-{seen}")
                self.assertEqual(out[0].status, "stale")
        self.assertEqual(self.settings_of(B), {})

    async def test_at_most_once_per_confirmation(self):
        pv = await self.apply.preview(OWNER, self.t.id, [B])
        item = [(B, pv.items[0].digest)]
        self.assertEqual((await self.apply.execute(OWNER, self.t.id, item, "same"))[0].status, "applied")
        n = len(self.events(TEMPLATE_APPLIED))
        self.assertEqual((await self.apply.execute(OWNER, self.t.id, item, "same"))[0].status, "duplicate")
        self.assertEqual(len(self.events(TEMPLATE_APPLIED)), n)

    async def test_a_second_confirmation_after_applying_is_a_no_change(self):
        pv = await self.apply.preview(OWNER, self.t.id, [B])
        await self.apply.execute(OWNER, self.t.id, [(B, pv.items[0].digest)], "one")
        again = await self.apply.preview(OWNER, self.t.id, [B])
        self.assertEqual(again.items[0].entries, ())
        out = await self.apply.execute(OWNER, self.t.id, [(B, again.items[0].digest)], "two")
        self.assertEqual(out[0].status, "no_change")
        self.assertEqual(len(self.events(TEMPLATE_APPLIED)), 1)

    async def test_missing_group_or_template(self):
        self.assertEqual((await self.apply.execute(OWNER, self.t.id, [(-4242, "abc")], "x"))[0].status, "missing")
        self.assertEqual((await self.apply.execute(OWNER, 999, [(B, "abc")], "y"))[0].status, "missing")

    async def test_groups_are_independent(self):
        pv = await self.apply.preview(OWNER, self.t.id, [B, C])
        await self.s.settings_store.merge(B, {"warn_limit": 4}, OWNER, NOW)           # B goes stale
        real = self.s.settings_store.merge

        async def broken(gid, *a, **kw):
            if gid == C:
                raise RuntimeError("db down")
            return await real(gid, *a, **kw)

        self.s.settings_store.merge = broken
        out = await self.apply.execute(OWNER, self.t.id, [(i.group_id, i.digest) for i in pv.items], "b1")
        self.assertEqual([(o.group_id, o.status) for o in out], [(B, "stale"), (C, "failed")])
        self.assertEqual(self.settings_of(C), {})

    async def test_only_the_owner_executes_and_nothing_is_claimed_for_others(self):
        pv = await self.apply.preview(OWNER, self.t.id, [B])
        item = [(B, pv.items[0].digest)]
        for who in (BACKUP, STRANGER, TG_CREATOR, DELEGATE, None):
            with self.subTest(who=who), self.assertRaises(PermissionDenied):
                await self.apply.execute(who, self.t.id, item, "x")
            with self.assertRaises(PermissionDenied):
                await self.apply.preview(who, self.t.id, [B])
        self.assertEqual(self.settings_of(B), {})
        self.assertEqual((await self.apply.execute(OWNER, self.t.id, item, "x"))[0].status, "applied")   # the claim was not burnt

    async def test_other_groups_and_licenses_are_untouched(self):
        pv = await self.apply.preview(OWNER, self.t.id, [B])
        before = self.snapshot()
        await self.apply.execute(OWNER, self.t.id, [(B, pv.items[0].digest)], "b1")
        after = self.snapshot()
        self.assertEqual((before[0][A], before[0][C]), (after[0][A], after[0][C]))
        self.assertEqual(before[1:], after[1:])                                         # licenses and license audit unchanged
        self.assertIs((await self.s.licenses.get(B)).status, LicenseStatus.ACTIVE_PERMANENT)


# ----------------------------------------------------------------------------- global defaults
class DefaultsTests(Base):
    async def test_show_empty_then_stage_is_read_only(self):
        self.assertEqual((await self.defaults.show(OWNER)).current.version, 0)
        stage = await self.defaults.stage(OWNER, self.t.id)
        self.assertEqual((stage.source, stage.version, len(self.pending)), ("Strict", 0, 1))
        self.assertEqual({e.key for e in stage.entries}, {"warn_limit", "flood_max_messages"})
        self.assertEqual((await self.dstore.get()).version, 0)                           # nothing written yet
        self.assertEqual(self.events(DEFAULTS_CHANGED), [])
        self.assertIsNone(await self.defaults.stage(OWNER, 999))

    async def test_confirm_approves_once_and_audits(self):
        stage = await self.defaults.stage(OWNER, self.t.id)
        status, row = await self.defaults.confirm(OWNER, stage.code)
        self.assertEqual((status, row.version, row.updated_by), ("approved", 1, OWNER))
        self.assertEqual(effective_settings(row.settings), self.t.settings)
        self.assertEqual(len(self.events(DEFAULTS_CHANGED)), 1)
        self.assertNotIn("7", self.events(DEFAULTS_CHANGED)[0].detail.replace("version=1", ""))
        self.assertEqual((await self.defaults.confirm(OWNER, stage.code))[0], "unknown")

    async def test_existing_groups_are_never_touched_by_approval(self):
        before = self.snapshot()
        stage = await self.defaults.stage(OWNER, self.t.id)
        await self.defaults.confirm(OWNER, stage.code)
        self.assertEqual(self.snapshot(), before)

    async def test_conflict_when_the_defaults_changed_since_the_preview(self):
        first = await self.defaults.stage(OWNER, self.t.id)
        second = await self.defaults.stage(OWNER, None)
        self.assertEqual((await self.defaults.confirm(OWNER, second.code))[0], "approved")
        status, row = await self.defaults.confirm(OWNER, first.code)
        self.assertEqual((status, row), ("conflict", None))
        self.assertEqual((await self.dstore.get()).version, 1)

    async def test_reset_returns_to_built_in_values(self):
        await self.defaults.confirm(OWNER, (await self.defaults.stage(OWNER, self.t.id)).code)
        stage = await self.defaults.stage(OWNER, None)
        self.assertEqual((stage.source, len(stage.entries)), (None, 2))
        _, row = await self.defaults.confirm(OWNER, stage.code)
        self.assertEqual((row.settings, row.version), ({}, 2))

    async def test_only_the_owner(self):
        for who in (BACKUP, STRANGER, TG_CREATOR, DELEGATE, None):
            with self.subTest(who=who):
                for op in (self.defaults.show(who), self.defaults.stage(who, 1), self.defaults.confirm(who, "ABCDEF")):
                    with self.assertRaises(PermissionDenied):
                        await op
        code = self.pending.create(OWNER, "defaults", ("x", {}, 0))
        with self.assertRaises(PermissionDenied):
            await self.defaults.confirm(STRANGER, code)
        self.assertEqual(len(self.pending), 1)

    async def test_an_apply_code_cannot_approve_defaults(self):
        code = self.pending.create(OWNER, "apply", (1, []))
        self.assertEqual((await self.defaults.confirm(OWNER, code))[0], "unknown")

    async def test_show_lists_differences_from_the_built_in_values(self):
        await self.defaults.confirm(OWNER, (await self.defaults.stage(OWNER, self.t.id)).code)
        view = await self.defaults.show(OWNER)
        self.assertEqual({(e.key, e.template, e.group) for e in view.entries},
                         {("warn_limit", 7, 3), ("flood_max_messages", 9, 6)})


class SeederTests(Base):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.seeder = DefaultsSeeder(self.dstore, self.s.settings_store, OWNER, clock=self.s.clock)
        self.svc = LicenseService(self.s.licenses, on_new_group=self.seeder.seed)

    async def approve(self):
        await self.defaults.confirm(OWNER, (await self.defaults.stage(OWNER, self.t.id)).code)

    async def test_a_new_group_gets_the_defaults_and_stays_pending(self):
        await self.approve()
        lic, created = await self.svc.on_bot_added(-2001, "New", NOW)
        self.assertTrue(created)
        self.assertEqual(effective_settings(self.settings_of(-2001)), self.t.settings)
        self.assertIs(lic.status, LicenseStatus.PENDING)                                # defaults never activate anything

    async def test_no_defaults_means_no_settings_row(self):
        self.assertFalse(await self.seeder.seed(-2001))                                  # a clean "nothing to do", not an error
        await self.svc.on_bot_added(-2001, "New", NOW)
        self.assertIsNone(self.s.settings_store._rows.get(-2001))

    async def test_re_adding_the_bot_changes_nothing(self):
        await self.svc.on_bot_added(-2001, "New", NOW)
        await self.approve()
        _, created = await self.svc.on_bot_added(-2001, "New", NOW)
        self.assertFalse(created)
        self.assertIsNone(self.s.settings_store._rows.get(-2001))
        self.assertEqual(self.settings_of(B), {})

    async def test_stored_settings_are_never_overwritten(self):
        await self.approve()
        await self.s.settings_store.merge(-2002, {"warn_limit": 2}, OWNER, NOW)
        self.assertFalse(await self.seeder.seed(-2002))
        self.assertEqual(self.settings_of(-2002), {"warn_limit": 2})

    async def test_a_failing_hook_never_breaks_registration(self):
        async def boom(gid):
            raise RuntimeError("db down")

        lic, created = await LicenseService(self.s.licenses, on_new_group=boom).on_bot_added(-2003, "N", NOW)
        self.assertTrue(created)
        self.assertIsNotNone(await self.s.licenses.get(-2003))

    async def test_existing_groups_registered_before_approval_stay_as_they_are(self):
        await self.approve()
        self.assertEqual(self.settings_of(B), {})
        self.assertEqual(self.settings_of(A)["warn_limit"], 7)


class PgDefaultsTests(unittest.IsolatedAsyncioTestCase):
    def db(self, row):
        calls = []

        class Conn:
            async def fetchrow(self, sql, *a):
                calls.append((" ".join(sql.split()), a))
                return row

        class Db:
            @asynccontextmanager
            async def acquire(self):
                yield Conn()

        return Db(), calls

    def row(self, **kw):
        return {**dict(settings='{"warn_limit": 7}', version=1, updated_by=OWNER, updated_at=NOW), **kw}

    async def test_first_write_inserts_without_overwriting(self):
        db, calls = self.db(self.row())
        out = await PostgresDefaultsStore(db).replace({"warn_limit": 7}, 0, OWNER, NOW)
        sql, args = calls[0]
        self.assertEqual((out.version, out.settings), (1, {"warn_limit": 7}))
        self.assertIn("INSERT INTO global_default_settings", sql)
        self.assertIn("ON CONFLICT (singleton) DO NOTHING", sql)
        self.assertNotIn("warn_limit", sql)

    async def test_later_writes_are_compare_and_set_on_the_version(self):
        db, calls = self.db(self.row(version=3))
        out = await PostgresDefaultsStore(db).replace({"warn_limit": 7}, 2, OWNER, NOW)
        sql, args = calls[0]
        self.assertEqual(out.version, 3)
        self.assertIn("WHERE singleton AND version = $4", sql)
        self.assertIn("version = version + 1", sql)
        self.assertEqual(args[3], 2)

    async def test_a_lost_race_returns_none_and_get_handles_no_row(self):
        db, _ = self.db(None)
        st = PostgresDefaultsStore(db)
        self.assertIsNone(await st.replace({}, 4, OWNER, NOW))
        self.assertEqual((await st.get()).version, 0)


# ----------------------------------------------------------------------------- panel
class PanelTests(Base):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.ov = GroupOverviewService(self.s.licenses, self.s.settings_store, self.s.audit_query, self.s.perm)
        self.panel = self.make()

    def make(self, **kw):
        kw.setdefault("templates", self.tpl)
        kw.setdefault("overview", self.ov)
        kw.setdefault("applier", self.apply)
        return OwnerPanelService(permissions=self.s.perm, audit=self.s.audit, licenses=self.s.licenses, secret=SECRET,
                                 clock=self.s.clock, **kw)

    async def press(self, data, *, chat=OWNER, presser=OWNER, cbid="900001", svc=None):
        return await (svc or self.panel).press(chat, "private", presser, data, "ar", cbid)

    async def ask(self, gid=B):
        return await self.press(cb(codec.DIFF, template_id=self.t.id, group_id=gid))

    async def test_the_apply_button_appears_only_with_the_service_and_differences(self):
        self.assertIn("طبّق", "".join(l for l, _ in flat(await self.ask())))
        self.assertNotIn("طبّق", "".join(l for l, _ in flat(await self.press(cb(codec.DIFF, template_id=1, group_id=B), svc=self.make(applier=None)))))
        self.assertNotIn("طبّق", "".join(l for l, _ in flat(await self.ask(A))))     # A already matches: nothing to apply

    async def test_confirm_screen_lists_the_exact_changes_and_writes_nothing(self):
        before = self.snapshot()
        out = await self.press(find(await self.ask(), "طبّق"))
        self.assertEqual(out.status, "apply_confirm")
        self.assertIn("warn_limit", out.text)
        self.assertIn("3 ➜ 7", out.text)
        self.assertEqual(self.snapshot(), before)
        run = codec.parse(find(out, "تأكيد"))
        self.assertEqual((run.screen, run.template_id, run.group_id, len(run.digest)), ("z", 1, B, 6))
        self.assertEqual(codec.parse(find(out, "إلغاء")).screen, codec.DIFF)

    async def test_confirming_applies_and_shows_the_fresh_diff(self):
        out = await self.press(find(await self.press(find(await self.ask(), "طبّق")), "تأكيد"))
        self.assertEqual((out.status, out.alert), ("applied", False))
        self.assertIn("2", out.toast)
        self.assertEqual((self.settings_of(B)["warn_limit"], self.settings_of(B)["flood_max_messages"]), (7, 9))
        self.assertIn("لا فروق", out.text)
        self.assertEqual(len(self.events(TEMPLATE_APPLIED)), 1)

    async def test_an_old_button_after_the_group_changed_is_refused(self):
        confirm = find(await self.press(find(await self.ask(), "طبّق")), "تأكيد")
        await self.s.settings_store.merge(B, {"warn_limit": 4}, OWNER, NOW)
        before = self.snapshot()
        out = await self.press(confirm)
        self.assertEqual((out.status, out.alert), ("stale", True))
        self.assertEqual(self.snapshot(), before)

    async def test_the_same_press_twice_applies_once(self):
        confirm = find(await self.press(find(await self.ask(), "طبّق")), "تأكيد")
        self.assertEqual((await self.press(confirm, cbid="77")).status, "applied")
        self.assertEqual((await self.press(confirm, cbid="77")).status, "duplicate")
        self.assertEqual(len(self.events(TEMPLATE_APPLIED)), 1)

    async def test_every_press_has_its_own_claim(self):
        first = find(await self.press(find(await self.ask(), "طبّق")), "تأكيد")
        self.assertEqual((await self.press(first, cbid="1")).status, "applied")
        await self.s.settings_store.merge(B, {"warn_limit": 4}, OWNER, NOW)               # the group drifts, the owner decides again
        second = find(await self.press(find(await self.ask(), "طبّق")), "تأكيد")
        self.assertEqual((await self.press(second, cbid="2")).status, "applied")
        self.assertEqual(self.settings_of(B)["warn_limit"], 7)
        self.assertEqual(len(self.events(TEMPLATE_APPLIED)), 2)

    async def test_a_press_without_a_valid_callback_id_changes_nothing(self):
        confirm = find(await self.press(find(await self.ask(), "طبّق")), "تأكيد")
        for cbid in (None, "", "a b", "x" * 65, 5):
            with self.subTest(cbid=cbid):
                out = await self.press(confirm, cbid=cbid)
                self.assertEqual((out.status, out.alert), ("invalid", True))
        self.assertEqual(self.settings_of(B), {})

    async def test_non_owners_get_nothing(self):
        confirm = cb(codec.APPLY_DO, chat=STRANGER, template_id=1, group_id=B, digest="abcdef")
        for who in (STRANGER, BACKUP, TG_CREATOR, DELEGATE):
            for data in (cb(codec.APPLY_ASK, chat=who, template_id=1, group_id=B),
                         cb(codec.APPLY_DO, chat=who, template_id=1, group_id=B, digest="abcdef")):
                out = await self.press(data, chat=who, presser=who)
                self.assertEqual((out.status, out.text), ("not_owner", None))
        self.assertEqual(self.settings_of(B), {})
        self.assertGreaterEqual(len([e for e in self.s.audit.events if e.event_type == FORGED_CALLBACK]), 8)

    async def test_without_the_applier_the_apply_screens_are_unavailable(self):
        svc = self.make(applier=None)
        for screen, kw in ((codec.APPLY_ASK, {}), (codec.APPLY_DO, dict(digest="abcdef"))):
            out = await self.press(cb(screen, template_id=1, group_id=B, **kw), svc=svc)
            self.assertEqual((out.status, out.text), ("insight_unavailable", None))

    async def test_missing_group_template_and_no_difference(self):
        self.assertEqual((await self.press(cb(codec.APPLY_ASK, template_id=1, group_id=-4242))).status, "missing")
        self.assertEqual((await self.press(cb(codec.APPLY_ASK, template_id=99, group_id=B))).status, "template_missing")
        same = await self.press(cb(codec.APPLY_ASK, template_id=1, group_id=A))
        self.assertEqual(same.status, "diff")
        self.assertIn("لا فروق", same.text)

    async def test_a_service_failure_fails_closed(self):
        class Down:
            async def preview(self, *a): raise RuntimeError("db down")
            async def execute(self, *a): raise RuntimeError("db down")

        out = await self.press(cb(codec.APPLY_ASK, template_id=1, group_id=B), svc=self.make(applier=Down()))
        self.assertEqual((out.status, out.alert, out.text), ("unavailable", True, None))


# ----------------------------------------------------------------------------- commands
class ParserTests(unittest.TestCase):
    def test_apply_confirm_and_defaults(self):
        cases = {
            "/template apply Strict -1001 -1002": P("apply", "Strict", group_ids=(-1001, -1002)),
            "/template apply My Strict -5 -5": P("apply", "My Strict", group_ids=(-5,)),
            "تطبيق قالب صارم -1001": P("apply", "صارم", group_ids=(-1001,)),
            "/template apply Strict": P("usage"), "/template apply -5": P("usage"), "/template apply x -5 y": P("usage"),
            "/template confirm ab3k9z": P("confirm", code="AB3K9Z"), "تأكيد قالب ab3k9z": P("confirm", code="AB3K9Z"),
            "/template confirm": P("usage"), "/template confirm a b": P("usage"), "/template confirm ab-c": P("usage"),
            "/defaults": P("defaults_show"), "/defaults show": P("defaults_show"), "الافتراضيات": P("defaults_show"),
            "/defaults set Strict": P("defaults_set", "Strict"), "/defaults set": P("usage"),
            "/defaults reset": P("defaults_reset"), "/defaults reset now": P("usage"),
            "/defaults confirm ab3k9z": P("defaults_confirm", code="AB3K9Z"), "/defaults foo": P("usage"),
        }
        for text, want in cases.items():
            with self.subTest(text=text):
                self.assertEqual(parse_template_command(text), want)

    def test_group_limit(self):
        ids = " ".join(str(-i) for i in range(1, MAX_GROUPS + 1))
        self.assertEqual(len(parse_template_command(f"/template apply x {ids}").group_ids), MAX_GROUPS)
        self.assertEqual(parse_template_command(f"/template apply x {ids} -999"), P("usage"))

    def test_other_bots_and_unrelated_text(self):
        self.assertIsNone(parse_template_command("/defaults@OtherBot", "GBot"))
        self.assertEqual(parse_template_command("/defaults@GBot set x", "gbot"), P("defaults_set", "x"))
        self.assertIsNone(parse_template_command("الافتراضيات الكل"))


class CommandTests(Base):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.cmd = TemplateCommandService(self.tpl, self.s.licenses, applier=self.apply, defaults=self.defaults, pending=self.pending)

    async def run_(self, text, user=OWNER, chat=None):
        return await self.cmd.run(parse_template_command(text), chat_id=user if chat is None else chat, chat_type="private", user_id=user)

    def code(self, reply):
        return re.search(r"confirm ([A-Z0-9]{6})", reply.text).group(1)

    async def test_apply_needs_the_code_and_applies_exactly_the_preview(self):
        before = self.snapshot()
        pv = await self.run_(f"/template apply strict {B} {C} -4242")
        self.assertEqual(pv.status, "apply_preview")
        self.assertEqual(self.snapshot(), before)                                      # the preview writes nothing
        self.assertIn("غير مسجّلة", pv.text)
        done = await self.run_(f"/template confirm {self.code(pv)}")
        self.assertEqual(done.status, "applied")
        self.assertIn(str(B), done.text)
        for g in (B, C):
            self.assertEqual(self.settings_of(g)["warn_limit"], 7)
        self.assertEqual(len(self.events(TEMPLATE_APPLIED)), 2)

    async def test_groups_that_already_match_are_not_part_of_the_confirmation(self):
        pv = await self.run_(f"/template apply Strict {A} {B}")
        self.assertIn(f"{A}", pv.text)                                                     # shown in the preview (0 changes)
        done = await self.run_(f"/template confirm {self.code(pv)}")
        self.assertIn(str(B), done.text)
        self.assertNotIn(str(A), done.text)

    async def test_the_code_works_once(self):
        code = self.code(await self.run_(f"/template apply Strict {B}"))
        self.assertEqual((await self.run_(f"/template confirm {code}")).status, "applied")
        self.assertEqual((await self.run_(f"/template confirm {code}")).status, "confirm_unknown")

    async def test_a_group_changed_between_preview_and_confirm_is_reported_stale(self):
        code = self.code(await self.run_(f"/template apply Strict {B} {C}"))
        await self.s.settings_store.merge(C, {"warn_limit": 4}, OWNER, NOW)
        done = await self.run_(f"/template confirm {code}")
        self.assertIn("تغيّرت الإعدادات", done.text)
        self.assertEqual(self.settings_of(B)["warn_limit"], 7)
        self.assertEqual(self.settings_of(C), {"warn_limit": 4})

    async def test_nothing_to_apply_gives_no_code(self):
        reply = await self.run_(f"/template apply Strict {A}")
        self.assertEqual(reply.status, "apply_nothing")
        self.assertEqual(len(self.pending), 0)

    async def test_unknown_names_and_codes(self):
        self.assertEqual((await self.run_(f"/template apply nope {B}")).status, "not_found")
        self.assertEqual((await self.run_("/template confirm ABCDEF")).status, "confirm_unknown")
        self.assertEqual((await self.run_("/defaults set nope")).status, "not_found")
        self.assertEqual((await self.run_("/defaults confirm ABCDEF")).status, "confirm_unknown")

    async def test_defaults_flow(self):
        self.assertEqual((await self.run_("/defaults")).text, MESSAGES["ar"]["dfl_empty"])
        pv = await self.run_("/defaults set Strict")
        self.assertEqual(pv.status, "defaults_preview")
        self.assertEqual((await self.dstore.get()).version, 0)
        done = await self.run_(f"/defaults confirm {re.search(r'confirm ([A-Z0-9]{6})', pv.text).group(1)}")
        self.assertEqual(done.status, "defaults_approved")
        shown = await self.run_("/defaults")
        self.assertIn("warn_limit", shown.text)
        self.assertEqual(self.settings_of(B), {})                                      # existing groups untouched

    async def test_codes_are_not_interchangeable(self):
        code = self.code(await self.run_(f"/template apply Strict {B}"))
        self.assertEqual((await self.run_(f"/defaults confirm {code}")).status, "confirm_unknown")
        self.assertEqual((await self.run_(f"/template confirm {code}")).status, "applied")

    async def test_non_owners_get_silence_and_nothing_changes(self):
        code = self.code(await self.run_(f"/template apply Strict {B}"))
        for who in (BACKUP, STRANGER, TG_CREATOR, DELEGATE):
            for text in (f"/template confirm {code}", f"/template apply Strict {B}", "/defaults", "/defaults set Strict",
                         f"/defaults confirm {code}"):
                self.assertIsNone(await self.run_(text, user=who))
        self.assertEqual(self.settings_of(B), {})
        self.assertEqual((await self.run_(f"/template confirm {code}")).status, "applied")   # still valid for the owner

    async def test_unavailable_without_the_new_services(self):
        old = TemplateCommandService(self.tpl, self.s.licenses)
        reply = await old.run(parse_template_command("/defaults"), chat_id=OWNER, chat_type="private", user_id=OWNER)
        self.assertEqual(reply.status, "failed")


# ----------------------------------------------------------------------------- static guards
class StaticGuardTests(unittest.TestCase):
    def read(self, rel):
        return (SRC / rel).read_text(encoding="utf-8")

    def test_only_apply_and_the_seeder_write_group_settings(self):
        pattern = re.compile(r"\.(merge|update|set_language)\(")
        writers = sorted(str(p.relative_to(SRC)) for pkg in ("owner_templates", "owner_panel", "owner_hub")
                         for p in (SRC / pkg).glob("*.py") if pattern.search(p.read_text(encoding="utf-8")))
        self.assertEqual(writers, ["owner_templates/apply.py", "owner_templates/defaults.py"])
        self.assertEqual(sorted(set(re.findall(r"self\._gs\.(\w+)\(", self.read("owner_templates/apply.py")))), ["update"])
        self.assertEqual(sorted(set(re.findall(r"self\._settings\.(\w+)\(", self.read("owner_templates/defaults.py")))), ["get", "merge"])

    def test_the_panel_uses_only_preview_and_execute_of_the_applier(self):
        self.assertEqual(sorted(set(re.findall(r"self\._applier\.(\w+)\(", self.read("owner_panel/service.py")))), ["execute", "preview"])

    def test_defaults_are_written_only_by_confirm(self):
        src = self.read("owner_templates/defaults.py")
        self.assertEqual(len(re.findall(r"self\._store\.replace\(", src)), 1)
        self.assertIn("take(actor_id, KIND, code)", src)

    def test_wiring(self):
        app = self.read("app.py")
        for needle in ("on_new_group=DefaultsSeeder(", "TemplateApplyService(", "GlobalDefaultsService(", "applier=template_applier",
                       "defaults=global_defaults", "pending=pending_actions"):
            self.assertIn(needle, app)

    def test_i18n_keys_exist_in_both_languages_with_equal_placeholders(self):
        import string
        keys = set()
        for rel in ("owner_panel/insight_views.py", "owner_panel/template_commands.py", "owner_panel/service.py"):
            keys |= set(re.findall(r'"((?:tpl_|dfl_|ow_)[a-z_0-9]+)"', self.read(rel)))
        keys |= {f"tpl_out_{s}" for s in ("applied", "no_change", "stale", "missing", "duplicate", "failed")}
        for key in sorted(keys):
            fields = []
            for lang in ("ar", "en"):
                self.assertIn(key, MESSAGES[lang], key)
                fields.append({n for _, n, _, _ in string.Formatter().parse(MESSAGES[lang][key]) if n})
            self.assertEqual(fields[0], fields[1], key)
        for lang in ("ar", "en"):
            self.assertLessEqual(len(MESSAGES[lang]["ow_btn_apply"]), 24)


if __name__ == "__main__":
    unittest.main()
