"""Phase 4 / part 4.6: /welcome /verify /newbie /settings — permissions, license gate, isolation, idempotency, audit,
effective read-back, advice about bot rights, language."""
import unittest
from unittest import mock

from executor_stack import BOT, BOT_NAME, USER, BrokenClaims, ExecBase, gate
from guardian.groups.models import GroupRole
from guardian.members import settings as ms
from guardian.members.memory_store import InMemoryBotTrustStore
from guardian.members.service import BotTrustService
from guardian.moderation.commands import parse_command
from guardian.moderation.executor import ModerationCommandService, ResultKind as R
from guardian.telegram_rights import ChatMemberInfo
from stack import A, B, DELEGATE, OWNER, STRANGER, TG_ADMIN, TG_LIMITED_ADMIN


class MemberBase(ExecBase):
    async def asyncSetUp(self):
        self.bots = InMemoryBotTrustStore()
        await super().asyncSetUp()
        self.bot_trust = BotTrustService(self.bots, self.s.licenses, self.s.perm, self.s.audit, clock=self.s.clock)
        self.svc = self.make_service(self.claims)
        self.msg = 100

    def make_service(self, claims, **over):
        kw = dict(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions,
            settings_store=self.s.settings_store, actions=self.actions, chat_info=self.s.chat, claims=claims,
            audit=self.s.audit, bot_id=BOT, clock=self.s.clock, group_settings=self.s.settings,
            trust=self.s.trust, bot_trust=getattr(self, "bot_trust", None), trust_store=self.s.trust_store,
            bot_trust_store=self.bots)
        kw.update(over)
        return ModerationCommandService(**kw)

    async def cmd(self, text, *, actor=TG_ADMIN, chat=A, msg=None, protection="default", lang=None, svc=None):
        parsed = parse_command(text, BOT_NAME)
        assert parsed is not None, text
        if msg is None:
            self.msg += 1
            msg = self.msg
        prot = gate(chat, actor) if protection == "default" else protection
        return await (svc or self.svc).handle(parsed, chat_id=chat, actor_id=actor, message_id=msg, protection=prot,
                                              language=lang)

    async def raw(self, group=A):
        row = await self.s.settings_store.get(group)
        return {} if row is None else dict(row.settings)

    def changed(self, group=A):
        return [e for e in self.s.audit.events if e.group_id == group and e.event_type == "settings_changed"]


class ReadTests(MemberBase):
    async def test_defaults_everything_off(self):
        w = await self.cmd("/welcome")
        self.assertEqual(w.kind, R.INFO)
        self.assertIn("👋", w.text)
        self.assertIn("/welcome vars", w.text)          # default text + how to customize
        v = await self.cmd("/verify")
        self.assertEqual(v.kind, R.INFO)
        self.assertIn("🛂", v.text)
        n = await self.cmd("/newbie")
        self.assertEqual(n.kind, R.INFO)
        self.assertIn("🆕", n.text)
        self.assertEqual(await self.raw(), {})            # reading never writes
        self.assertEqual(self.claims._keys, {})           # ... and never consumes a claim
        self.assertEqual(self.changed(), [])

    async def test_vars_lists_the_documented_variables(self):
        r = await self.cmd("/welcome vars")
        self.assertEqual(r.kind, R.INFO)
        for var in ("{name}", "{group}", "{id}"):
            self.assertIn(var, r.text)
        self.assertIn(str(ms.TEMPLATE_MAX_CHARS), r.text)

    async def test_overview_has_every_section_and_trust_counts(self):
        await self.s.admin.activate_permanent(OWNER, A)
        await self.s.trust.add(OWNER, A, USER, None, context_chat_id=A)
        await self.bot_trust.add(OWNER, A, 880_001, None, context_chat_id=A)
        await self.settings(links_allow_domains=["a.com", "b.org"])
        r = await self.cmd("/settings")
        self.assertEqual(r.kind, R.INFO)
        for marker in ("⚙️", "🔗", "🌊", "♻️", "🐢", "📈", "⚠️", "🧪", "👋", "🚪", "🛂", "🆕", "🔐"):
            self.assertIn(marker, r.text)
        self.assertIn("1 عضو، 2 نطاق، 1 بوت", r.text)
        self.assertEqual(await self.raw(), {"links_allow_domains": ["a.com", "b.org"]})

    async def test_overview_without_trust_stores_still_answers(self):
        svc = self.make_service(self.claims, trust_store=None, bot_trust_store=None)
        r = await self.cmd("/settings", svc=svc)
        self.assertEqual(r.kind, R.INFO)
        self.assertNotIn("🔐", r.text)

    async def test_overview_unreadable_settings_is_a_safe_error(self):
        with mock.patch.object(self.s.settings_store, "get", side_effect=RuntimeError("db down")):
            for text in ("/settings", "/welcome", "/verify", "/newbie"):
                r = await self.cmd(text)
                self.assertEqual(r.kind, R.ERROR, text)
                self.assertNotIn("db down", r.text)

    async def test_a_moderator_delegate_may_read_but_not_write(self):
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.MODERATOR)
        for text in ("/welcome", "/verify", "/newbie", "/settings", "/welcome vars"):
            self.assertEqual((await self.cmd(text, actor=DELEGATE)).kind, R.INFO, text)
        for text in ("/welcome on", "/welcome set hi", "/verify on", "/newbie 1h"):
            self.assertEqual((await self.cmd(text, actor=DELEGATE)).kind, R.DENIED, text)
        self.assertEqual(await self.raw(), {})
        self.assertEqual(self.claims._keys, {})

    async def test_reading_follows_the_two_shared_gates(self):
        for text in ("/welcome", "/verify", "/newbie", "/settings", "/welcome vars"):
            for actor in (STRANGER, TG_LIMITED_ADMIN):
                self.assertEqual((await self.cmd(text, actor=actor)).kind, R.DENIED, (text, actor))
            for ctx in (None, gate(A, allowed=False), gate(B)):
                self.assertEqual((await self.cmd(text, protection=ctx)).kind, R.LICENSE_OFF, text)


class WriteTests(MemberBase):
    async def test_welcome_changes_read_back_effective_values(self):
        r = await self.cmd("/welcome on")
        self.assertEqual(r.kind, R.DONE)
        self.assertTrue(ms.WelcomeSettings.from_raw(await self.raw()).welcome_enabled)
        self.assertIn("مفعّل", r.text)
        await self.cmd("/welcome delete 5m")
        await self.cmd("/welcome previous off")
        await self.cmd("/welcome join delete")
        await self.cmd("/welcome leave delete")
        cfg = ms.WelcomeSettings.from_raw(await self.raw())
        self.assertEqual((cfg.welcome_delete_after_seconds, cfg.welcome_delete_previous, cfg.join_service, cfg.leave_service),
                         (300, False, "delete", "delete"))
        shown = (await self.cmd("/welcome")).text
        self.assertIn("🚪", shown)
        self.assertIn("تُحذف", shown)  # join/leave service messages now say "deleted"
        await self.cmd("/welcome reset")
        self.assertIsNone(ms.WelcomeSettings.from_raw(await self.raw()).welcome_text)

    async def test_join_and_leave_service_lines_are_not_swapped(self):
        await self.cmd("/welcome join delete")
        shown = (await self.cmd("/welcome")).text
        self.assertIn("«انضم» الخدمية: تُحذف", shown)
        self.assertIn("«غادر» الخدمية: تُترك", shown)
        await self.cmd("/welcome join keep")
        await self.cmd("/welcome leave delete")
        shown = (await self.cmd("/welcome", lang="en")).text
        self.assertIn('"Joined" service message: kept', shown)
        self.assertIn('"left" service message: deleted', shown)

    async def test_welcome_text_is_stored_exactly_shown_escaped_and_not_in_the_audit(self):
        text = "أهلًا {name} في <b>{group}</b>\nالقواعد: لا إعلانات"
        r = await self.cmd("/welcome set " + text)
        self.assertEqual(r.kind, R.DONE)
        self.assertEqual((await self.raw())["welcome_text"], text)
        shown = await self.cmd("/welcome")
        self.assertIn("&lt;b&gt;", shown.text)           # HTML typed by the admin is shown literally, never injected
        self.assertNotIn("<b>{group}", shown.text)
        self.assertIn("{name}", shown.text)
        for ev in self.changed():
            self.assertNotIn("أهلًا", ev.detail)
            self.assertEqual(ev.detail, "keys=welcome_text")

    async def test_set_while_disabled_adds_the_enable_hint(self):
        r = await self.cmd("/welcome set hello {name}")
        self.assertIn("/welcome on", r.text)
        await self.cmd("/welcome on")
        r = await self.cmd("/welcome set hello again {name}")
        self.assertNotIn("/welcome on", r.text)

    async def test_verify_changes(self):
        for text in ("/verify on", "/verify scope suspicious", "/verify method math", "/verify timeout 10m",
                     "/verify failure ban 2h", "/verify attempts 5"):
            self.assertEqual((await self.cmd(text)).kind, R.DONE, text)
        cfg = ms.VerificationSettings.from_raw(await self.raw())
        self.assertEqual((cfg.verify_enabled, cfg.verify_scope, cfg.verify_method, cfg.verify_timeout_seconds,
                          cfg.verify_failure, cfg.verify_ban_seconds, cfg.verify_max_attempts),
                         (True, "suspicious", "math", 600, "ban", 7200, 5))
        shown = (await self.cmd("/verify")).text
        self.assertIn("المشبوهون فقط", shown)
        self.assertIn("سؤال حسابي", shown)

    async def test_ban_without_duration_keeps_the_stored_ban_length(self):
        await self.cmd("/verify failure ban 2h")
        await self.cmd("/verify failure kick")
        await self.cmd("/verify failure ban")
        cfg = ms.VerificationSettings.from_raw(await self.raw())
        self.assertEqual((cfg.verify_failure, cfg.verify_ban_seconds), ("ban", 7200))

    async def test_newbie_changes_and_the_idle_note(self):
        r = await self.cmd("/newbie 1h")
        self.assertEqual(r.kind, R.DONE)
        cfg = ms.NewMemberPolicy.from_raw(await self.raw())
        self.assertTrue(cfg.active and cfg.newbie_seconds == 3600)
        await self.cmd("/newbie links off")
        r = await self.cmd("/newbie media off")
        self.assertIn("لا قيود فعلية", r.text)           # window set but nothing selected: said plainly
        await self.cmd("/newbie messages on")
        self.assertTrue(ms.NewMemberPolicy.from_raw(await self.raw()).newbie_block_messages)
        await self.cmd("/newbie off")
        self.assertEqual(ms.NewMemberPolicy.from_raw(await self.raw()).newbie_seconds, 0)

    async def test_a_patch_touches_only_its_own_keys(self):
        await self.settings(links_enabled=True, flood_max_messages=7, welcome_enabled=True, newbie_seconds=600)
        before = await self.raw()
        await self.cmd("/verify on")
        after = await self.raw()
        self.assertEqual({k: v for k, v in after.items() if k != "verify_enabled"}, before)
        self.assertEqual(self.changed()[-1].detail, "keys=verify_enabled")

    async def test_invalid_input_changes_nothing_and_says_how(self):
        for text in ("/welcome maybe", "/welcome set", "/welcome set {bogus}", "/welcome delete 1", "/verify timeout 5",
                     "/verify attempts 99", "/verify method captcha", "/newbie 5s", "/newbie links maybe"):
            r = await self.cmd(text)
            self.assertEqual(r.kind, R.INVALID, text)
            self.assertTrue(r.text)
        self.assertEqual(await self.raw(), {})
        self.assertEqual(self.claims._keys, {})
        self.assertEqual(self.changed(), [])

    async def test_english_replies(self):
        r = await self.cmd("/welcome maybe", lang="en")
        self.assertEqual(r.kind, R.INVALID)
        self.assertIn("Invalid form", r.text)
        r = await self.cmd("/verify on", lang="en")
        self.assertIn("New-member verification", r.text)
        self.assertIn("on", r.text)
        self.assertIn("Welcome", (await self.cmd("/welcome", lang="en")).text)
        self.assertIn("Settings of this group", (await self.cmd("/settings", lang="en")).text)

    async def test_arabic_commands_work_end_to_end(self):
        self.assertEqual((await self.cmd("الترحيب تفعيل")).kind, R.DONE)
        self.assertEqual((await self.cmd("التحقق تفعيل")).kind, R.DONE)
        self.assertEqual((await self.cmd("الاعضاء الجدد 1h")).kind, R.DONE)
        self.assertEqual((await self.cmd("اعدادات المجموعة")).kind, R.INFO)
        raw = await self.raw()
        self.assertTrue(raw["welcome_enabled"] and raw["verify_enabled"] and raw["newbie_seconds"] == 3600)

    async def test_settings_changes_work_in_dry_run(self):
        await self.settings(dry_run=True)
        self.assertEqual((await self.cmd("/verify off")).kind, R.NOOP)
        self.assertEqual((await self.cmd("/verify on")).kind, R.DONE)
        self.assertTrue((await self.raw())["verify_enabled"])


class PermissionAndGateTests(MemberBase):
    async def test_who_may_write(self):
        self.assertEqual((await self.cmd("/welcome on", actor=TG_ADMIN)).kind, R.DONE)
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.GROUP_MANAGER)
        self.assertEqual((await self.cmd("/verify on", actor=DELEGATE)).kind, R.DONE)
        self.assertEqual((await self.cmd("/newbie 1h", actor=OWNER)).kind, R.DONE)
        for actor in (STRANGER, TG_LIMITED_ADMIN):
            for text in ("/welcome off", "/verify off", "/newbie off"):
                self.assertEqual((await self.cmd(text, actor=actor)).kind, R.DENIED, (text, actor))

    async def test_no_write_without_a_licensed_group(self):
        for ctx in (None, gate(A, allowed=False), gate(B)):
            for text in ("/welcome on", "/welcome set hi", "/verify on", "/newbie 1h"):
                self.assertEqual((await self.cmd(text, protection=ctx)).kind, R.LICENSE_OFF, text)
        self.assertEqual(await self.raw(), {})
        self.assertEqual(self.claims._keys, {})
        self.assertEqual(self.changed(), [])

    async def test_an_admin_of_one_group_cannot_configure_another(self):
        self.s.chat.set(B, TG_ADMIN, ChatMemberInfo("member"))  # not an admin of B
        r = await self.cmd("/welcome on", chat=B)
        self.assertEqual(r.kind, R.DENIED)
        self.assertEqual(await self.raw(B), {})

    async def test_writes_are_isolated_per_group(self):
        self.s.chat.set(B, TG_ADMIN, ChatMemberInfo("administrator", True, True, True))
        await self.cmd("/verify on", chat=A)
        await self.cmd("/verify method math", chat=A)
        self.assertEqual(await self.raw(B), {})
        await self.cmd("/verify method admin", chat=B)
        self.assertEqual((await self.raw(A))["verify_method"], "math")
        self.assertEqual((await self.raw(B)), {"verify_method": "admin"})
        self.assertNotIn("سؤال حسابي", (await self.cmd("/verify", chat=B)).text)
        self.assertNotIn("سؤال حسابي", (await self.cmd("/settings", chat=B)).text)


class IdempotencyTests(MemberBase):
    async def test_redelivered_update_writes_and_audits_once(self):
        first = await self.cmd("/verify on", msg=900)
        again = await self.cmd("/verify on", msg=900)
        self.assertEqual(first.kind, R.DONE)
        self.assertEqual((again.kind, again.text), (R.DUPLICATE, ""))
        self.assertEqual(len(self.changed()), 1)

    async def test_same_value_is_a_noop_without_a_write_or_audit(self):
        await self.cmd("/verify on")
        r = await self.cmd("/verify on")
        self.assertEqual(r.kind, R.NOOP)
        self.assertEqual(len(self.changed()), 1)
        r = await self.cmd("/welcome reset")  # already the default text
        self.assertEqual(r.kind, R.NOOP)
        self.assertEqual(len(self.changed()), 1)

    async def test_claim_store_down_means_nothing_written(self):
        svc = self.make_service(BrokenClaims())
        r = await self.cmd("/verify on", svc=svc)
        self.assertEqual(r.kind, R.ERROR)
        self.assertEqual(await self.raw(), {})

    async def test_without_the_settings_service_reads_work_and_writes_are_a_safe_error(self):
        svc = self.make_service(self.claims, group_settings=None)
        self.assertEqual((await self.cmd("/verify", svc=svc)).kind, R.INFO)
        self.assertEqual((await self.cmd("/verify on", svc=svc)).kind, R.ERROR)

    async def test_store_failure_while_writing_is_a_safe_error(self):
        with mock.patch.object(self.s.settings_store, "get", side_effect=RuntimeError("secret-dsn")):
            r = await self.cmd("/verify on")
        self.assertEqual(r.kind, R.ERROR)
        self.assertNotIn("secret-dsn", r.text)
        self.assertEqual(await self.raw(), {})


class AdviceTests(MemberBase):
    def bot_rights(self, delete=True, restrict=True):
        self.s.chat.set(A, BOT, ChatMemberInfo("administrator", delete, restrict, True))

    async def test_verify_on_warns_when_the_bot_cannot_restrict_but_keeps_the_setting(self):
        self.bot_rights(restrict=False)
        r = await self.cmd("/verify on")
        self.assertEqual(r.kind, R.DONE)
        self.assertIn("⚠️", r.text)
        self.assertTrue((await self.raw())["verify_enabled"])
        self.bot_rights()
        await self.cmd("/verify off")
        self.assertNotIn("⚠️", (await self.cmd("/verify on")).text)

    async def test_failure_kick_or_ban_warns_only_while_verification_is_on(self):
        self.bot_rights(restrict=False)
        self.assertNotIn("⚠️", (await self.cmd("/verify failure kick")).text)
        await self.cmd("/verify on")
        self.assertIn("⚠️", (await self.cmd("/verify failure ban 1h")).text)

    async def test_newbie_warns_when_the_bot_cannot_delete(self):
        self.bot_rights(delete=False)
        self.assertIn("⚠️", (await self.cmd("/newbie 1h")).text)
        self.bot_rights()
        await self.cmd("/newbie off")
        self.assertNotIn("⚠️", (await self.cmd("/newbie 1h")).text)

    async def test_advice_failure_never_breaks_the_answer(self):
        with mock.patch("guardian.moderation.member_commands.check_bot_capabilities", side_effect=RuntimeError("tg down")):
            r = await self.cmd("/verify on")
        self.assertEqual(r.kind, R.DONE)
        self.assertNotIn("tg down", r.text)
        self.assertNotIn("⚠️", r.text)


class MenuAndHelp(unittest.TestCase):
    def test_new_commands_are_in_the_admin_menu_and_help(self):
        from guardian.bot import commands_menu
        from guardian.i18n import t
        for name in ("welcome", "verify", "newbie", "settings"):
            self.assertIn(name, commands_menu.MODERATION)
            for lang in ("ar", "en"):
                self.assertIn(name, commands_menu.DESCRIPTIONS[lang])
        for lang in ("ar", "en"):
            h = t("help", lang)
            for name in ("/welcome", "/verify", "/newbie", "/settings"):
                self.assertIn(name, h)


if __name__ == "__main__":
    unittest.main()
