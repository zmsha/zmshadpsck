"""Closing part 2: /pin /unpin /purge (message_commands.py), their parser, aiogram adapter methods and menus.

Nothing here proves behaviour against the real aiogram or Telegram (the Bot below is a signature-strict fake)."""
from __future__ import annotations

import unittest
from types import SimpleNamespace as NS

from executor_stack import A, B, BOT, BOT_NAME, OTHER, USER, BrokenClaims, ExecBase, FakeActions, gate
from guardian.bot import moderation_handler as h
from guardian.bot.actions import MAX_DELETE_BATCH, AiogramModerationActions
from guardian.bot.commands_menu import MODERATION, PUBLIC, build_menus
from guardian.i18n import MESSAGES
from guardian.moderation.commands import (
    MESSAGE_COMMANDS, PURGE_CONFIRM_ABOVE, PURGE_MAX, Command, CommandError, interpret_message_args, parse_command,
)
from guardian.moderation.executor import ResultKind as R
from guardian.moderation.targets import ReplyInfo
from guardian.permissions import GroupRole
from guardian.telegram_rights import ChatMemberInfo
from stack import DELEGATE, OWNER, STRANGER, TG_ADMIN, TG_CREATOR, TG_LIMITED_ADMIN


# ----------------------------------------------------------------------------- parser
class ParserTests(unittest.TestCase):
    def p(self, text, reply=False):
        return parse_command(text, BOT_NAME, has_reply=reply)

    def test_english_commands_and_bot_suffix(self):
        for text, cmd in (("/pin", Command.PIN), ("/PIN silent", Command.PIN), ("/unpin", Command.UNPIN),
                          ("/purge 20", Command.PURGE), (f"/purge@{BOT_NAME} 5", Command.PURGE)):
            self.assertIs(self.p(text).command, cmd, text)
        self.assertIsNone(self.p("/purge@OtherBot 5"))
        self.assertEqual(MESSAGE_COMMANDS, {Command.PIN, Command.UNPIN, Command.PURGE})

    def test_arabic_aliases_follow_the_intentional_command_rule(self):
        self.assertIs(self.p("تثبيت", reply=True).command, Command.PIN)
        self.assertIs(self.p("تثبيت صامت", reply=True).command, Command.PIN)
        self.assertIsNone(self.p("تثبيت"))  # plain chat without a reply
        self.assertIs(self.p("تنظيف 20").command, Command.PURGE)
        self.assertIs(self.p("تنظيف", reply=True).command, Command.PURGE)
        self.assertIs(self.p("حذف الرسائل ٢٠").command, Command.PURGE)
        self.assertIsNone(self.p("تنظيف البيت"))  # ordinary chat: no reply, first word is not a number/@user
        self.assertIs(self.p("تنظيف البيت", reply=True).command, Command.PURGE)  # accepted by the parser; the executor rejects the word

    def test_unpin_aliases_are_standalone(self):
        for text in ("الغاء التثبيت", "فك التثبيت", "الغاء تثبيت", "  إلغاء التثبيت  "):
            self.assertIs(self.p(text).command, Command.UNPIN, text)
        self.assertIsNone(self.p("الغاء التثبيت لو سمحتم"))

    def test_existing_aliases_are_not_shadowed(self):
        self.assertIs(self.p("مسح التحذيرات", reply=True).command, Command.CLEARWARNS)
        self.assertIs(self.p("الغاء الحظر @abcde").command, Command.UNBAN)
        self.assertIs(self.p("حظر @abcde").command, Command.BAN)

    def test_pin_args(self):
        self.assertFalse(interpret_message_args(Command.PIN, [], has_reply=True).silent)
        for w in ("silent", "quiet", "صامت", "بصمت"):
            self.assertTrue(interpret_message_args(Command.PIN, [w], has_reply=True).silent, w)
        for bad in (["loud"], ["silent", "now"], ["5"]):
            with self.assertRaises(CommandError) as cm:
                interpret_message_args(Command.PIN, bad, has_reply=True)
            self.assertEqual(cm.exception.code, "pin_args")
        with self.assertRaises(CommandError) as cm:
            interpret_message_args(Command.PIN, [], has_reply=False)
        self.assertEqual(cm.exception.code, "pin_need_reply")

    def test_unpin_args(self):
        self.assertEqual(interpret_message_args(Command.UNPIN, [], has_reply=False).count, None)
        with self.assertRaises(CommandError) as cm:
            interpret_message_args(Command.UNPIN, ["all"], has_reply=False)
        self.assertEqual(cm.exception.code, "unpin_args")

    def test_purge_args(self):
        ok = lambda a, r=False: interpret_message_args(Command.PURGE, a, has_reply=r)  # noqa: E731
        self.assertEqual(ok(["20"]).count, 20)
        self.assertEqual(ok(["٢٠"]).count, 20)
        self.assertTrue(ok(["50", "confirm"]).confirm)
        self.assertTrue(ok(["50", "تأكيد"]).confirm)
        self.assertTrue(ok(["confirm"], True).confirm)
        self.assertEqual(ok([], True).count, None)
        self.assertEqual(ok(["1"]).count, 1)
        self.assertEqual(ok([str(PURGE_MAX)]).count, PURGE_MAX)
        codes = {}
        for name, args, reply in (("zero", ["0"], False), ("over", [str(PURGE_MAX + 1)], False), ("huge", ["99999"], False),
                                  ("none", [], False), ("both", ["5"], True), ("two", ["5", "6"], False),
                                  ("word", ["spam"], False), ("neg", ["-5"], False), ("many", ["1"] * 25, False)):
            with self.assertRaises(CommandError) as cm:
                ok(args, reply)
            codes[name] = cm.exception.code
        self.assertEqual(codes, {"zero": "purge_range", "over": "purge_range", "huge": "purge_range",
                                 "none": "purge_need_arg", "both": "purge_ambiguous", "two": "purge_args",
                                 "word": "purge_args", "neg": "purge_args", "many": "too_many_args"})

    def test_every_error_code_has_a_localized_message(self):
        for code in ("pin_need_reply", "pin_args", "unpin_args", "purge_need_arg", "purge_ambiguous", "purge_range", "purge_args"):
            for lang in ("ar", "en"):
                self.assertIn(f"mod_err_{code}", MESSAGES[lang])


# ----------------------------------------------------------------------------- executor
class MsgBase(ExecBase):
    async def mc(self, text, *, actor=TG_ADMIN, chat=A, msg=100, reply_mid=None, protection="default", language=None):
        parsed = parse_command(text, BOT_NAME, has_reply=reply_mid is not None)
        assert parsed is not None, text
        prot = gate(chat, actor) if protection == "default" else protection
        reply = ReplyInfo(OTHER, message_id=reply_mid) if reply_mid is not None else None
        return await self.svc.handle(parsed, chat_id=chat, actor_id=actor, message_id=msg, protection=prot,
                                     reply=reply, language=language)

    def assertNoTelegram(self):
        self.assertEqual(self.actions.calls, [])


class PinTests(MsgBase):
    async def test_admin_pins_the_replied_message(self):
        r = await self.mc("/pin", reply_mid=42)
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(self.actions.calls, [("pin", A, 42, False)])
        self.assertIn("message_pinned", self.audit_types())
        ev = [e for e in self.s.audit.events if e.event_type == "message_pinned"][0]
        self.assertEqual((ev.actor_telegram_id, ev.group_id, ev.detail), (TG_ADMIN, A, "msg=42 silent=0"))

    async def test_silent_pin_and_arabic(self):
        r = await self.mc("تثبيت صامت", reply_mid=42)
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(self.actions.calls, [("pin", A, 42, True)])
        self.assertIn("بصمت", r.text)

    async def test_english_reply_text(self):
        r = await self.mc("/pin", reply_mid=42, language="en")
        self.assertIn("pinned", r.text)

    async def test_without_reply_or_bad_args_nothing_happens(self):
        for text, reply in (("/pin", None), ("/pin loud", 42), ("/pin silent extra", 42)):
            r = await self.mc(text, reply_mid=reply)
            self.assertIs(r.kind, R.INVALID, text)
        r = await self.mc("/pin", reply_mid=None)
        self.assertNoTelegram()
        self.assertNotIn("message_pinned", self.audit_types())

    async def test_reply_without_a_message_id_is_invalid(self):
        parsed = parse_command("/pin", BOT_NAME, has_reply=True)
        r = await self.svc.handle(parsed, chat_id=A, actor_id=TG_ADMIN, message_id=100, protection=gate(),
                                  reply=ReplyInfo(OTHER, message_id=None))
        self.assertIs(r.kind, R.INVALID)
        self.assertNoTelegram()

    async def test_non_moderator_is_denied_without_side_effects(self):
        for actor in (USER, STRANGER, TG_LIMITED_ADMIN):
            r = await self.mc("/pin", actor=actor, reply_mid=42, protection=gate(A, actor))
            self.assertIs(r.kind, R.DENIED, actor)
        self.assertNoTelegram()
        self.assertEqual(await self.claims.claim("mod:pin:%d:100" % A), True)  # nothing was claimed either

    async def test_license_off_blocks_everything(self):
        r = await self.mc("/pin", reply_mid=42, protection=gate(A, TG_ADMIN, allowed=False))
        self.assertIs(r.kind, R.LICENSE_OFF)
        self.assertNoTelegram()

    async def test_protection_of_another_chat_is_rejected(self):
        r = await self.mc("/pin", reply_mid=42, protection=gate(B, TG_ADMIN))
        self.assertIs(r.kind, R.LICENSE_OFF)
        self.assertNoTelegram()

    async def test_admin_without_telegram_pin_right_is_denied(self):
        self.s.chat.set(A, TG_ADMIN, ChatMemberInfo("administrator", True, True, False))
        r = await self.mc("/pin", reply_mid=42)
        self.assertIs(r.kind, R.DENIED)
        self.assertIn("تثبيت", r.text)
        self.assertNoTelegram()

    async def test_creator_owner_and_delegate_are_not_blocked_by_the_telegram_right_gate(self):
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.MODERATOR)
        for i, actor in enumerate((TG_CREATOR, OWNER, DELEGATE)):
            r = await self.mc("/pin", actor=actor, reply_mid=42, msg=200 + i, protection=gate(A, actor))
            self.assertIs(r.kind, R.DONE, actor)
        self.assertEqual(len(self.actions.calls), 3)

    async def test_actor_right_lookup_failure_denies(self):
        real = self.s.chat.get_member
        state = {"n": 0}

        async def flaky(chat_id, user_id, *, fresh=False):
            state["n"] += 1
            if user_id == TG_ADMIN and state["n"] > 1:  # 1st call = permission check, 2nd = the right gate
                raise RuntimeError("down")
            return await real(chat_id, user_id, fresh=fresh)

        self.s.chat.get_member = flaky
        r = await self.mc("/pin", reply_mid=42)
        self.assertIs(r.kind, R.ERROR)
        self.assertNoTelegram()

    async def test_dry_run_changes_nothing(self):
        await self.settings(dry_run=True)
        r = await self.mc("/pin", reply_mid=42)
        self.assertIs(r.kind, R.DRY_RUN)
        self.assertNoTelegram()
        self.assertIn("moderation_dry_run", self.audit_types())
        self.assertNotIn("message_pinned", self.audit_types())
        self.assertTrue(await self.claims.claim("mod:pin:%d:100" % A))  # not claimed

    async def test_bot_rights(self):
        for info in (ChatMemberInfo("administrator", True, True, False), ChatMemberInfo("member")):
            self.s.chat.set(A, BOT, info)
            r = await self.mc("/pin", reply_mid=42)
            self.assertIs(r.kind, R.BOT_RIGHTS)
        self.assertNoTelegram()
        # a bot that may delete but not pin: pin refused
        self.s.chat.set(A, BOT, ChatMemberInfo("administrator", True, True, False))
        self.assertIs((await self.mc("/pin", reply_mid=42, msg=101)).kind, R.BOT_RIGHTS)

    async def test_redelivered_update_pins_once(self):
        first = await self.mc("/pin", reply_mid=42, msg=300)
        second = await self.mc("/pin", reply_mid=42, msg=300)
        self.assertIs(first.kind, R.DONE)
        self.assertIs(second.kind, R.DUPLICATE)
        self.assertEqual(second.text, "")
        self.assertEqual(self.actions.names(), ["pin"])

    async def test_claim_store_down_means_no_action(self):
        self.svc = self.make_service(BrokenClaims())
        r = await self.mc("/pin", reply_mid=42)
        self.assertIs(r.kind, R.ERROR)
        self.assertNoTelegram()

    async def test_telegram_failures_are_reported_and_audited_not_recorded_as_success(self):
        for i, (err, needle) in enumerate((("forbidden", "الصلاحية"), ("rate_limited", "الانتظار"),
                                           ("not_found", "الرسالة"), ("other", ""))):
            self.actions.fail["pin"] = err
            r = await self.mc("/pin", reply_mid=42, msg=400 + i)
            self.assertIs(r.kind, R.TELEGRAM_FAILED, err)
            self.assertIn(needle, r.text)
        self.assertNotIn("message_pinned", self.audit_types())
        self.assertIn("moderation_action_failed", self.audit_types())

    async def test_other_group_cannot_be_reached_from_here(self):
        # TG_ADMIN is an admin of A only; the same actor typing in B is denied (isolation)
        r = await self.mc("/pin", chat=B, reply_mid=42)
        self.assertIs(r.kind, R.DENIED)
        self.assertNoTelegram()


class UnpinTests(MsgBase):
    async def test_unpin_replied_message(self):
        r = await self.mc("/unpin", reply_mid=42)
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(self.actions.calls, [("unpin", A, 42)])
        ev = [e for e in self.s.audit.events if e.event_type == "message_unpinned"][0]
        self.assertEqual(ev.detail, "msg=42")

    async def test_unpin_latest_when_no_reply(self):
        r = await self.mc("الغاء التثبيت")
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(self.actions.calls, [("unpin", A, None)])
        ev = [e for e in self.s.audit.events if e.event_type == "message_unpinned"][0]
        self.assertEqual(ev.detail, "msg=latest")

    async def test_nothing_pinned_is_a_harmless_noop(self):
        self.actions.fail["unpin"] = "not_found"
        r = await self.mc("/unpin")
        self.assertIs(r.kind, R.NOOP)
        self.assertNotIn("message_unpinned", self.audit_types())

    async def test_arguments_are_rejected(self):
        r = await self.mc("/unpin all")
        self.assertIs(r.kind, R.INVALID)
        self.assertNoTelegram()

    async def test_permissions_rights_dry_run_and_failures(self):
        self.assertIs((await self.mc("/unpin", actor=USER, protection=gate(A, USER))).kind, R.DENIED)
        self.s.chat.set(A, TG_ADMIN, ChatMemberInfo("administrator", True, True, False))
        self.assertIs((await self.mc("/unpin")).kind, R.DENIED)
        self.s.chat.set(A, TG_ADMIN, ChatMemberInfo("administrator", True, True, True))
        self.s.chat.set(A, BOT, ChatMemberInfo("administrator", True, True, False))
        self.assertIs((await self.mc("/unpin")).kind, R.BOT_RIGHTS)
        self.s.chat.set(A, BOT, ChatMemberInfo("administrator", True, True, True))
        await self.settings(dry_run=True)
        self.assertIs((await self.mc("/unpin")).kind, R.DRY_RUN)
        self.assertNoTelegram()
        await self.settings(dry_run=False)
        self.actions.fail["unpin"] = "forbidden"
        self.assertIs((await self.mc("/unpin", msg=101)).kind, R.TELEGRAM_FAILED)

    async def test_duplicate_delivery(self):
        await self.mc("/unpin", msg=500)
        self.assertIs((await self.mc("/unpin", msg=500)).kind, R.DUPLICATE)
        self.assertEqual(self.actions.names(), ["unpin"])


class PurgeTests(MsgBase):
    async def test_reply_range_is_replied_message_through_the_one_before_the_command(self):
        r = await self.mc("/purge", reply_mid=50, msg=55)
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(self.actions.calls, [("delete_messages", A, [50, 51, 52, 53, 54])])
        self.assertNotIn(55, self.actions.calls[0][2])  # the command message itself is kept
        ev = [e for e in self.s.audit.events if e.event_type == "messages_purged"][0]
        self.assertEqual((ev.actor_telegram_id, ev.group_id, ev.detail), (TG_ADMIN, A, "from=50 to=54 count=5"))

    async def test_count_form_deletes_the_n_ids_before_the_command(self):
        r = await self.mc("/purge 5", msg=100)
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(self.actions.calls, [("delete_messages", A, [95, 96, 97, 98, 99])])

    async def test_arabic_form_and_arabic_digits(self):
        r = await self.mc("تنظيف ٣", msg=100)
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(self.actions.calls[0][2], [97, 98, 99])

    async def test_reply_text_says_requested_not_deleted(self):
        r = await self.mc("/purge 3", msg=100)
        self.assertIn("3", r.text)
        self.assertIn("48", r.text)
        r = await self.mc("/purge 3", msg=101, language="en")
        self.assertIn("requested", r.text)

    async def test_big_purge_needs_the_confirm_word_and_a_refusal_consumes_nothing(self):
        n = PURGE_CONFIRM_ABOVE + 1
        r = await self.mc(f"/purge {n}", msg=300)
        self.assertIs(r.kind, R.INVALID)
        self.assertIn(str(n), r.text)
        self.assertNoTelegram()
        self.assertEqual(self.audit_types().count("messages_purged"), 0)
        # same command message id with the word now works: the refusal did not claim anything
        r = await self.mc(f"/purge {n} confirm", msg=300)
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(len(self.actions.calls[0][2]), n)

    async def test_threshold_is_inclusive_of_the_free_size(self):
        r = await self.mc(f"/purge {PURGE_CONFIRM_ABOVE}", msg=300)
        self.assertIs(r.kind, R.DONE)

    async def test_confirm_with_reply_range_and_arabic_word(self):
        r = await self.mc("/purge", reply_mid=100, msg=130)
        self.assertIs(r.kind, R.INVALID)
        r = await self.mc("تنظيف تأكيد", reply_mid=100, msg=130)
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(len(self.actions.calls[0][2]), 30)

    async def test_limits_and_bad_ranges(self):
        for text, kw in (("/purge 101", {}), ("/purge 0", {}), ("/purge", {}), ("/purge 5", {"reply_mid": 40}),
                         ("/purge confirm", {"reply_mid": 10, "msg": 500}),  # 489 ids > 100
                         ("/purge", {"reply_mid": 99, "msg": 99}),            # replied message is the command itself
                         ("/purge", {"reply_mid": 120, "msg": 100}),          # reply newer than the command (impossible)
                         ("/purge spam", {}), ("تنظيف البيت", {"reply_mid": 10, "msg": 20}),  # unknown word is never ignored
                         ("/purge 5", {"msg": 1})):                           # nothing before message 1
            kw.setdefault("msg", 200)
            r = await self.mc(text, **kw)
            self.assertIs(r.kind, R.INVALID, (text, kw))
        self.assertNoTelegram()

    async def test_reply_range_boundary_is_exactly_the_telegram_batch_limit(self):
        r = await self.mc("/purge confirm", reply_mid=900, msg=1000)  # ids 900..999 = exactly 100
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(len(self.actions.calls[0][2]), PURGE_MAX)
        r = await self.mc("/purge confirm", reply_mid=900, msg=1001)  # 900..1000 = 101 ids
        self.assertIs(r.kind, R.INVALID)
        self.assertEqual(len(self.actions.calls), 1)

    async def test_count_larger_than_available_ids_is_clamped_to_message_one(self):
        r = await self.mc("/purge 8", msg=4)
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(self.actions.calls[0][2], [1, 2, 3])

    async def test_max_batch_is_one_call(self):
        r = await self.mc(f"/purge {PURGE_MAX} confirm", msg=1000)
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(len(self.actions.calls), 1)
        self.assertEqual(len(self.actions.calls[0][2]), PURGE_MAX)

    async def test_non_moderator_license_and_group_isolation(self):
        self.assertIs((await self.mc("/purge 3", actor=USER, protection=gate(A, USER))).kind, R.DENIED)
        self.assertIs((await self.mc("/purge 3", protection=gate(A, TG_ADMIN, allowed=False))).kind, R.LICENSE_OFF)
        self.assertIs((await self.mc("/purge 3", chat=B)).kind, R.DENIED)
        self.assertNoTelegram()

    async def test_admin_without_telegram_delete_right_is_denied(self):
        self.s.chat.set(A, TG_ADMIN, ChatMemberInfo("administrator", False, True, True))
        r = await self.mc("/purge 3")
        self.assertIs(r.kind, R.DENIED)
        self.assertIn("حذف", r.text)
        self.assertNoTelegram()

    async def test_bot_without_delete_right(self):
        self.s.chat.set(A, BOT, ChatMemberInfo("administrator", False, True, True))
        self.assertIs((await self.mc("/purge 3")).kind, R.BOT_RIGHTS)
        self.assertNoTelegram()
        self.s.chat.fail = True  # lookup failure: permission check fails first => denied; still no action
        self.assertIs((await self.mc("/purge 3", msg=101)).kind, R.DENIED)
        self.assertNoTelegram()

    async def test_dry_run_deletes_nothing(self):
        await self.settings(dry_run=True)
        r = await self.mc("/purge 5")
        self.assertIs(r.kind, R.DRY_RUN)
        self.assertNoTelegram()
        self.assertNotIn("messages_purged", self.audit_types())

    async def test_redelivery_deletes_once(self):
        await self.mc("/purge 3", msg=600)
        self.assertIs((await self.mc("/purge 3", msg=600)).kind, R.DUPLICATE)
        self.assertEqual(self.actions.names(), ["delete_messages"])

    async def test_telegram_failure_is_not_a_success(self):
        for i, err in enumerate(("forbidden", "rate_limited", "other")):
            self.actions.fail["delete_messages"] = err
            r = await self.mc("/purge 3", msg=700 + i)
            self.assertIs(r.kind, R.TELEGRAM_FAILED, err)
        self.assertNotIn("messages_purged", self.audit_types())

    async def test_audit_never_contains_message_text_or_reason(self):
        await self.mc("/purge 3", msg=100)
        for e in self.s.audit.events:
            if e.event_type == "messages_purged":
                self.assertRegex(e.detail, r"^from=\d+ to=\d+ count=\d+$")

    async def test_existing_commands_still_work(self):
        self.member(USER)
        r = await self.run_cmd("/warn", reply_to=USER)
        self.assertIs(r.kind, R.DONE)
        r = await self.run_cmd("/kick", reply_to=USER, msg=2)
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(self.actions.names(), ["kick"])


# ----------------------------------------------------------------------------- aiogram adapter (signature-strict fake)
class StrictBot:
    def __init__(self):
        self.calls = []
        self.errors: dict[str, list] = {}

    async def _do(self, name, *a, **kw):
        self.calls.append((name, a, kw))
        q = self.errors.get(name)
        if q:
            step = q.pop(0)
            if step is not None:
                raise step
        return True

    async def pin_chat_message(self, chat_id, message_id, disable_notification=None):
        return await self._do("pin", chat_id, message_id, disable_notification=disable_notification)

    async def unpin_chat_message(self, chat_id, message_id=None):
        return await self._do("unpin", chat_id, message_id=message_id)

    async def delete_messages(self, chat_id, message_ids):
        return await self._do("delete_messages", chat_id, message_ids)


class TelegramBadRequest(Exception): ...


class AdapterTests(unittest.IsolatedAsyncioTestCase):
    def make(self, bot=None):
        bot = bot or StrictBot()

        async def nosleep(_):
            return None

        return bot, AiogramModerationActions(bot, sleep=nosleep)

    async def test_pin(self):
        bot, a = self.make()
        self.assertTrue((await a.pin_message(-100123, 7, True)).ok)
        self.assertTrue((await a.pin_message(-100123, 8)).ok)
        self.assertEqual(bot.calls, [("pin", (-100123, 7), {"disable_notification": True}),
                                     ("pin", (-100123, 8), {"disable_notification": False})])

    async def test_unpin(self):
        bot, a = self.make()
        self.assertTrue((await a.unpin_message(-100123, 7)).ok)
        self.assertTrue((await a.unpin_message(-100123)).ok)
        self.assertEqual(bot.calls, [("unpin", (-100123,), {"message_id": 7}), ("unpin", (-100123,), {"message_id": None})])

    async def test_delete_messages(self):
        bot, a = self.make()
        self.assertTrue((await a.delete_messages(-100123, [3, 4, 5])).ok)
        self.assertEqual(bot.calls, [("delete_messages", (-100123, [3, 4, 5]), {})])

    async def test_invalid_input_is_refused_before_telegram(self):
        bot, a = self.make()
        bad = [
            await a.pin_message(0, 7), await a.pin_message(-100123, 0), await a.pin_message(-100123, True),
            await a.pin_message(-100123, "7"), await a.unpin_message(-100123, -3), await a.unpin_message(0),
            await a.delete_messages(-100123, []), await a.delete_messages(-100123, [1, 1]),
            await a.delete_messages(-100123, [0, 1]), await a.delete_messages(-100123, list(range(1, MAX_DELETE_BATCH + 2))),
            await a.delete_messages(-100123, [True]), await a.delete_messages(0, [1]), await a.delete_messages(-100123, "123"),
        ]
        self.assertTrue(all(not r.ok for r in bad))
        self.assertEqual(bot.calls, [])

    async def test_old_aiogram_without_delete_messages_is_refused_not_looped(self):
        class Old:
            async def delete_message(self, *a):
                raise AssertionError("must not fall back to single deletes")

        _, a = self.make(Old())
        self.assertFalse((await a.delete_messages(-100123, [1, 2])).ok)

    async def test_error_classification_and_single_retry(self):
        bot, a = self.make()
        bot.errors["pin"] = [TelegramBadRequest("Bad Request: not enough rights to pin a message")]
        self.assertEqual((await a.pin_message(-100123, 7)).error, "forbidden")
        bot.errors["pin"] = [TelegramBadRequest("Bad Request: message to pin not found")]
        self.assertEqual((await a.pin_message(-100123, 7)).error, "not_found")
        bot.errors["unpin"] = [TelegramBadRequest("Bad Request: message to unpin not found")]
        self.assertEqual((await a.unpin_message(-100123, 7)).error, "not_found")

        class RA(Exception):
            retry_after = 1

        bot.calls.clear()
        bot.errors["delete_messages"] = [RA("slow down")]
        self.assertTrue((await a.delete_messages(-100123, [1])).ok)
        self.assertEqual(len(bot.calls), 2)


# ----------------------------------------------------------------------------- menus, help, handler plumbing
class MenuAndHandlerTests(unittest.IsolatedAsyncioTestCase):
    def test_menus_list_the_new_commands_for_admins_only(self):
        self.assertTrue({"pin", "unpin", "purge"} <= set(MODERATION))
        self.assertFalse({"pin", "unpin", "purge"} & set(PUBLIC))
        for spec in build_menus():
            names = {c for c, _ in spec.commands}
            self.assertEqual({"pin", "unpin", "purge"} <= names, spec.scope == "all_chat_administrators")
            for c, d in spec.commands:
                self.assertTrue(1 <= len(d) <= 256 and c.isascii() and c == c.lower())

    def test_help_mentions_the_new_commands(self):
        for lang in ("ar", "en"):
            self.assertIn("/purge", MESSAGES[lang]["help"])
            self.assertIn("/pin", MESSAGES[lang]["help"])

    async def test_handler_matches_and_passes_reply_message_id(self):
        def msg(text, reply_id=None):
            reply = NS(message_id=reply_id, from_user=NS(id=OTHER), sender_chat=None) if reply_id else None
            return NS(text=text, chat=NS(id=A, type="supergroup"), from_user=NS(id=TG_ADMIN, is_bot=False),
                      reply_to_message=reply, message_id=90, entities=None)

        async def me():
            return NS(username=BOT_NAME)

        bot = NS(me=me)
        parsed = await h.match_command(msg("/purge 5"), bot)
        self.assertIs(parsed.command, Command.PURGE)
        self.assertIs((await h.match_command(msg(f"/purge@{BOT_NAME} 5"), bot)).command, Command.PURGE)
        self.assertIsNone(await h.match_command(msg("/purge@OtherBot 5"), bot))  # addressed to another bot
        self.assertEqual(h.reply_info(msg("/pin", 33)).message_id, 33)
        pinned = await h.match_command(msg("تثبيت", 33), bot)
        self.assertIs(pinned.command, Command.PIN)


if __name__ == "__main__":
    unittest.main()
