"""Phase 3 closing part 4: the PRIVATE-HANDOFF acceptance test for ALL 20 commands, end to end with the REAL gate.

Same chain as `test_phase3_final_handoff` (real license state -> ProtectionGate -> middleware + engine -> handler ->
ModerationCommandService), but over every command of the phase, in Arabic and English, for the group admin AND the owner.
A coverage check fails if a command is added to `Command` without being listed here, so no command can silently skip the gate."""
from __future__ import annotations

from executor_stack import USER
from guardian.moderation.commands import Command
from guardian.moderation.executor import ResultKind as R
from stack import OWNER, STRANGER, TG_ADMIN
from test_moderation_integration import Msg
from test_phase3_ext3_gate import NewCommandsGate
from test_phase3_final_handoff import BLOCKED_STATES

# command -> a text that parses to it (replying to a member, which every target/message command accepts)
EVERY_COMMAND = {
    Command.BAN: ("/ban", "حظر"), Command.UNBAN: ("/unban", "الغاء الحظر"), Command.MUTE: ("/mute 1h", "كتم"),
    Command.UNMUTE: ("/unmute", "الغاء الكتم"), Command.KICK: ("/kick", "طرد"), Command.WARN: ("/warn spam", "تحذير"),
    Command.WARNINGS: ("/warnings", "التحذيرات"), Command.CLEARWARNS: ("/clearwarns", "مسح التحذيرات"),
    Command.ID: ("/id", "ايدي"), Command.INFO: ("/info", "معلومات"), Command.ADMINS: ("/admins", "المشرفين"),
    Command.REPORT: ("/report", "بلاغ"), Command.PIN: ("/pin", "تثبيت"), Command.UNPIN: ("/unpin", "الغاء التثبيت"),
    Command.PURGE: ("/purge", "تنظيف"), Command.LOCK: ("/lock all", "قفل الكل"), Command.UNLOCK: ("/unlock all", "فتح الكل"),
    Command.SLOWMODE: ("/slowmode 30", "الوضع البطيء ٣٠"), Command.ANTIFLOOD: ("/antiflood off", "مكافحة الفيضان ايقاف"),
    Command.PROTECT: ("/protect links off", "اعدادات الحماية"),
    Command.TRUST: ("/trust", "وثق"), Command.UNTRUST: ("/untrust", "الغاء التوثيق"), Command.TRUSTED: ("/trusted", "الموثوقين"),
    # part 4.6: welcome / verification / new-member settings and the overview (writes AND reads must be blocked)
    Command.WELCOME: ("/welcome on", "الترحيب تفعيل"), Command.VERIFY: ("/verify on", "التحقق تفعيل"),
    Command.NEWBIE: ("/newbie 1h", "الاعضاء الجدد 1h"), Command.SETTINGS: ("/settings", "اعدادات المجموعة"),
    # part 4.7a: the Inline panel opener (the overview it shows must be blocked like every other read)
    Command.PANEL: ("/panel", "لوحة التحكم"),
    # part 6.4a: report management (a moderator command: every blocked state must block it like the rest)
    Command.REPORTS: ("/reports", "البلاغات"),
    # part 6.5b: statistics (a moderator command: every blocked state must block it like the rest)
    Command.STATS: ("/stats", "الاحصائيات"),
    # part 6.7b: export (a moderator command: every blocked state must block it before anything is built or sent)
    Command.EXPORT: ("/export settings", "تصدير الاعدادات"),
}


def M(text, **kw):
    m = Msg(text, **kw)
    if m.reply_to_message is not None:
        m.reply_to_message.message_id = 1  # the shared fake has no id on the replied-to message (needed by /pin)
    return m


class CompleteHandoff(NewCommandsGate):
    def texts(self):
        return [t for pair in EVERY_COMMAND.values() for t in pair]

    async def assert_all_off(self, g, who, kinds=(R.LICENSE_OFF,)):
        calls, claims = len(self.actions.calls), dict(self.claims._keys)
        for text in self.texts():
            self.mid += 1
            ran, res = await self.deliver(M(text, chat=g, sender=who, mid=self.mid, reply_to=USER))
            self.assertTrue(ran, text)                       # the middleware never drops the update
            self.assertIsNotNone(res, f"not parsed as a command: {text}")
            self.assertIn(res.kind, kinds, text)
            if res.kind is R.LICENSE_OFF:  # public commands stay silent in a group without a license
                self.assertEqual(res.text == "", res.command in (Command.ID, Command.ADMINS, Command.REPORT), text)
        self.assertEqual(self.actions.calls[calls:], [])     # nothing reached Telegram
        self.assertEqual(self.claims._keys, claims)          # no claim consumed
        self.assertIsNone(await self.s.settings_store.get(g))
        self.assertEqual(await self.s.warning_store.count_active(g, USER, self.s.clock()), 0)
        self.assertEqual(await self.s.sanction_store.get_active(g, USER, self.s.clock()), [])

    def test_the_table_covers_every_command(self):
        self.assertEqual(set(EVERY_COMMAND), set(Command))
        self.assertEqual(len(Command), 31)  # the 20 of phase 3 + /trust /untrust /trusted (4.2) + /welcome /verify /newbie /settings (4.6) + /panel (4.7a) + /reports (6.4a) + /stats (6.5b) + /export (6.7b)

    async def test_every_blocked_state_blocks_all_twenty_commands(self):
        for state in BLOCKED_STATES:
            with self.subTest(state=state):
                g = await self.group_in(state)
                real = self.break_store() if state == "store_down" else self.s.licenses.get
                try:
                    await self.assert_all_off(g, TG_ADMIN)
                    if state != "store_down":
                        await self.assert_all_off(g, OWNER)
                finally:
                    self.s.licenses.get = real

    async def test_a_plain_member_gets_nothing_in_any_state_and_active_groups_deny_non_admins(self):
        g = await self.group_in("pending")
        await self.assert_all_off(g, STRANGER, kinds=(R.DENIED, R.LICENSE_OFF))
        g2 = await self.group_in("stopped")
        await self.owner_recovers(g2, "stopped")
        for text in self.texts():
            self.mid += 1
            self.s.clock.advance(seconds=30)  # the automatic flood rule is live too: do not look like a flood
            _, res = await self.deliver(M(text, chat=g2, sender=STRANGER, mid=self.mid, reply_to=USER))
            if res is None:
                continue
            if res.command in (Command.ID, Command.ADMINS, Command.REPORT):
                continue  # public commands (own policy, tested in test_info_commands)
            self.assertEqual(res.kind, R.DENIED, text)
        self.assertEqual([c for c in self.actions.calls if c[0] in ("ban", "kick", "mute", "set_perms", "delete_messages")], [])
        self.assertIsNone(await self.s.settings_store.get(g2))

    async def test_owner_recovers_every_state_then_licensed_commands_work_again(self):
        for state in BLOCKED_STATES:
            with self.subTest(state=state):
                g = await self.group_in(state)
                real = self.break_store() if state == "store_down" else self.s.licenses.get
                try:
                    await self.assert_all_off(g, TG_ADMIN)
                finally:
                    self.s.licenses.get = real
                await self.owner_recovers(g, state)
                for text, name in (("/ban", "ban"), ("/lock media", "set_perms"), ("/pin", "pin")):
                    self.mid += 1
                    _, res = await self.deliver(M(text, chat=g, sender=TG_ADMIN, mid=self.mid, reply_to=USER))
                    self.assertEqual(res.kind, R.DONE, text)
                    self.assertEqual(self.actions.calls[-1][0], name)

    async def test_a_licensed_group_does_not_license_another(self):
        good = await self.group_in("stopped")
        await self.owner_recovers(good, "stopped")
        bad = await self.group_in("pending")
        self.mid += 1
        _, res = await self.deliver(M("/lock all", chat=good, sender=TG_ADMIN, mid=self.mid))
        self.assertEqual(res.kind, R.DONE)
        await self.assert_all_off(bad, TG_ADMIN)
