"""Phase 4 / part 2: what each trust entry bypasses (members/trust.py) and nothing more.

No blanket exemption: a trusted USER skips links/duplicates/slow mode (and, in part 4.4, verification) but NOT flood; a trusted
DOMAIN skips only links to that domain and its sub-domains (never Telegram invites); a trusted BOT skips only the link check
on messages sent THROUGH it. Trust is per group, and an unreadable trust list never leads to a sanction."""
import unittest
from types import SimpleNamespace as NS

from guardian.bot.middlewares import ProtectionGateMiddleware
from guardian.members import trust as rules
from guardian.members.memory_store import InMemoryBotTrustStore
from guardian.protection import engine as eng
from guardian.protection.engine import MessageView, OutcomeKind, ProtectionEngine
from guardian.protection_gate import ProtectionGate
from guardian.telegram_rights import ChatMemberInfo
from stack import A, B, OWNER, STRANGER, Stack
from test_protection_engine import BOT, Base

TRUSTED = 910_001
INLINE_BOT = 880_001
BAD = "buy now https://evil.example/x"


class TrustBase(Base):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.bots = InMemoryBotTrustStore()
        self.engine = ProtectionEngine(self.s.settings_store, self.actions, self.s.chat, self.claims, self.s.audit,
                                       self.notifier, clock=self.s.clock, bot_trust=self.bots)
        await self.s.trust.add(OWNER, A, TRUSTED, context_chat_id=A)

    async def send_via(self, text, via, user=STRANGER, group=A, advance=0.0):
        if advance:
            self.s.clock.advance(seconds=advance)
        self.mid += 1
        ctx = await self.gate.evaluate(group, "supergroup", user)
        return await self.engine.handle(ctx, MessageView(group, user, self.mid, text, (), False, False, via),
                                        self.s.clock())


class MatrixTests(unittest.TestCase):
    def test_documented_matrix(self):
        self.assertEqual(rules.USER_BYPASS, {"links", "duplicate", "slowmode", "verification", "newbie"})
        self.assertNotIn(rules.RULE_FLOOD, rules.USER_BYPASS)   # a trusted account can still flood
        self.assertEqual(rules.DOMAIN_BYPASS, {"links"})
        self.assertEqual(rules.BOT_BYPASS, {"links", "verification"})
        self.assertEqual(rules.VIA_BOT_MESSAGE_BYPASS, {"links"})

    def test_rule_names_match_the_engine(self):
        self.assertEqual((eng.VIOLATION_LINKS, eng.VIOLATION_DUPLICATE, eng.VIOLATION_FLOOD, eng.VIOLATION_SLOWMODE),
                         (rules.RULE_LINKS, rules.RULE_DUPLICATE, rules.RULE_FLOOD, rules.RULE_SLOWMODE))


class TrustedUserTests(TrustBase):
    async def test_untrusted_link_is_sanctioned_trusted_is_not(self):
        self.assertEqual((await self.send(BAD, user=STRANGER)).violation, "links")
        o = await self.send(BAD, user=TRUSTED)
        self.assertEqual(o.kind, OutcomeKind.NONE)
        self.assertNotIn((A, self.mid), self.actions.deleted)

    async def test_trusted_user_skips_duplicates(self):
        for _ in range(5):
            self.assertEqual((await self.send("same text again", user=TRUSTED)).kind, OutcomeKind.NONE)
        o = None
        for _ in range(3):
            o = await self.send("same text again", user=STRANGER)
        self.assertEqual(o.violation, "duplicate")

    async def test_trusted_user_skips_slowmode(self):
        await self.cfg(slowmode_seconds=60)
        await self.send("one", user=TRUSTED)
        self.assertEqual((await self.send("two", user=TRUSTED, advance=1)).kind, OutcomeKind.NONE)
        await self.send("one", user=STRANGER)
        self.assertEqual((await self.send("two", user=STRANGER, advance=1)).violation, "slowmode")

    async def test_trusted_user_is_still_subject_to_flood(self):
        await self.cfg(flood_max_messages=3, flood_window_seconds=10)
        outcomes = [await self.send(f"msg number {i}", user=TRUSTED) for i in range(5)]
        self.assertTrue(any(o.violation == "flood" and o.kind == OutcomeKind.ACTED for o in outcomes))
        self.assertTrue(self.actions.muted)  # muted: trust is not a blanket exemption

    async def test_trust_is_per_group(self):
        await self.s.admin.activate_permanent(OWNER, B)
        self.s.chat.set(B, BOT, ChatMemberInfo("administrator", True, True, True))
        o = await self.send(BAD, user=TRUSTED, group=B)  # trusted in A only
        self.assertEqual(o.violation, "links")

    async def test_admins_stay_fully_exempt_and_trust_does_not_add_protection(self):
        self.assertTrue(await self.s.perm.is_exempt_from_automation(OWNER, A))
        self.assertFalse(await self.s.perm.is_exempt_from_automation(TRUSTED, A))
        self.assertFalse(await self.s.perm.is_protected(TRUSTED, A))  # an admin can still /ban or /mute a trusted user

    async def test_unreadable_trust_list_never_sanctions(self):
        async def boom(*a, **k):
            raise RuntimeError("db down")
        self.s.trust_store.is_trusted = boom
        o = await self.send(BAD, user=STRANGER)
        self.assertEqual(o.kind, OutcomeKind.NONE)
        self.assertEqual(self.actions.deleted, [])


class TrustedDomainTests(TrustBase):
    async def test_domain_and_subdomain_allowed_lookalike_blocked(self):
        await self.cfg(links_allow_domains=["example.com"])
        self.assertEqual((await self.send("see example.com/page")).kind, OutcomeKind.NONE)
        self.assertEqual((await self.send("see https://docs.example.com/a")).kind, OutcomeKind.NONE)
        self.assertEqual((await self.send("see https://evil-example.com/a")).violation, "links")
        self.assertEqual((await self.send("see https://example.com.evil.io/a")).violation, "links")

    async def test_trusting_a_domain_changes_nothing_else(self):
        await self.cfg(links_allow_domains=["example.com"])
        o = None
        for _ in range(3):
            o = await self.send("example.com/page again", user=STRANGER)
        self.assertEqual(o.violation, "duplicate")  # duplicates still apply to messages with trusted links

    async def test_trusted_tme_domain_never_allows_invites(self):
        await self.cfg(links_allow_domains=["t.me"])
        self.assertEqual((await self.send("join https://t.me/somechannel")).kind, OutcomeKind.NONE)
        self.assertEqual((await self.send("join https://t.me/+AbCdEf123")).violation, "links")
        self.assertEqual((await self.send("join https://t.me/joinchat/AbCdEf123")).violation, "links")


class TrustedBotTests(TrustBase):
    async def test_link_sent_through_trusted_bot_is_not_sanctioned(self):
        await self.bots.add(A, INLINE_BOT, OWNER, None, self.s.clock())
        self.assertEqual((await self.send_via(BAD, INLINE_BOT)).kind, OutcomeKind.NONE)

    async def test_untrusted_or_missing_via_bot_gets_no_bypass(self):
        self.assertEqual((await self.send_via(BAD, INLINE_BOT)).violation, "links")
        await self.bots.add(A, INLINE_BOT, OWNER, None, self.s.clock())
        self.assertEqual((await self.send_via(BAD, None)).violation, "links")
        self.assertEqual((await self.send_via(BAD, INLINE_BOT + 1)).violation, "links")

    async def test_bot_trust_is_per_group(self):
        await self.s.admin.activate_permanent(OWNER, B)
        self.s.chat.set(B, BOT, ChatMemberInfo("administrator", True, True, True))
        await self.bots.add(A, INLINE_BOT, OWNER, None, self.s.clock())
        self.assertEqual((await self.send_via(BAD, INLINE_BOT, group=B)).violation, "links")

    async def test_trusted_bot_does_not_exempt_its_user_from_flood(self):
        await self.bots.add(A, INLINE_BOT, OWNER, None, self.s.clock())
        await self.cfg(flood_max_messages=3, flood_window_seconds=10)
        outcomes = [await self.send_via(f"inline result {i}", INLINE_BOT) for i in range(5)]
        self.assertTrue(any(o.violation == "flood" for o in outcomes))

    async def test_bot_trust_lookup_failure_skips_the_link_rule(self):
        async def boom(*a, **k):
            raise RuntimeError("db down")
        self.bots.is_trusted = boom
        self.assertEqual((await self.send_via(BAD, INLINE_BOT)).kind, OutcomeKind.NONE)  # uncertain => no action
        self.assertEqual(self.actions.deleted, [])


class MiddlewareViewTests(unittest.TestCase):
    def view(self, via_bot):
        mw = ProtectionGateMiddleware(gate=None)
        ev = NS(text="hi", entities=None, message_id=5, content_type="text", via_bot=via_bot)
        return mw._view(ev, NS(chat_id=A, sender_id=STRANGER))

    def test_via_bot_id_is_carried_when_valid(self):
        self.assertEqual(self.view(NS(id=INLINE_BOT)).via_bot_id, INLINE_BOT)

    def test_invalid_via_bot_is_ignored(self):
        for bad in (None, NS(id=None), NS(id=True), NS(id=-5), NS(id="7")):
            self.assertIsNone(self.view(bad).via_bot_id, bad)


if __name__ == "__main__":
    unittest.main()
