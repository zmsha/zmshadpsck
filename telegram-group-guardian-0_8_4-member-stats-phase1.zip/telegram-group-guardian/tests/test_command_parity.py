"""English <-> Arabic parity guard (part 9.6). Every English command has an Arabic twin that parses to the SAME action, and the
only Arabic command that had no English slash form (`الاوامر`) now has one (`/commands`).

`test_arabic_commands.py` already checks that every `Command` member has an Arabic alias; this file covers what that one does not:
the owner-side commands and their sub-commands, side by side, so a new English sub-command with no Arabic form shows up here
as a named failure. Pure parsers; no aiogram, no Telegram."""
from __future__ import annotations

import pathlib
import unittest

from guardian.backup.command import parse_backup_command
from guardian.backup.restore_command import parse_restore_command
from guardian.licensing.commands import parse_license_command
from guardian.moderation.commands import Command, parse_command
from guardian.owner_panel.api_check_commands import parse_api_check_command
from guardian.owner_panel.command import parse_owner_command
from guardian.owner_panel.default_words_commands import parse_default_words_command
from guardian.owner_panel.sandbox_commands import parse_sandbox_command
from guardian.owner_panel.template_commands import parse_template_command

SRC = pathlib.Path(__file__).resolve().parents[1] / "src" / "guardian"
G = "-1001234567890"


def key(result):
    if result is None:
        return None
    return getattr(result, "action", None) or getattr(result, "command", None) or type(result).__name__


OWNER_PAIRS = {
    parse_owner_command: [("/owner", "لوحة المالك"), ("/owner بحث", "لوحة المالك بحث")],
    parse_template_command: [
        ("/templates", "القوالب"), (f"/template save A {G}", f"حفظ قالب A {G}"), (f"/template diff A {G}", f"قارن قالب A {G}"),
        ("/template delete A", "حذف قالب A"), (f"/template apply A {G}", f"تطبيق قالب A {G}"), ("/template confirm AB12CD", "تاكيد قالب AB12CD"),
        ("/defaults", "الافتراضيات"), ("/defaults show", "الافتراضيات عرض"), ("/defaults set A", "تعيين الافتراضيات A"),
        ("/defaults reset", "اعادة الافتراضيات"), ("/defaults confirm AB12CD", "تاكيد الافتراضيات AB12CD"),
    ],
    parse_sandbox_command: [
        ("/sandbox", "تجربة"), ("/sandbox start default", "تجربة بدء افتراضي"), (f"/sandbox start {G}", f"تجربة بدء {G}"),
        ("/sandbox say hello", "تجربة رسالة hello"), ("/sandbox media u2", "تجربة وسائط u2"), ("/sandbox join u3", "تجربة انضمام u3"),
        ("/sandbox wait 30", "تجربة انتظر 30"), ("/sandbox set key value", "تجربة اضبط key value"),
        ("/sandbox settings", "تجربة الاعدادات"), ("/sandbox log", "تجربة سجل"), (f"/sandbox diff {G}", f"تجربة قارن {G}"),
        ("/sandbox save A", "تجربة احفظ A"), ("/sandbox end", "تجربة انهاء"), ("/sandbox status", "تجربة حالة"),
    ],
    parse_default_words_command: [
        ("/defaultwords", "عرض الكلمات الافتراضية"), ("/defaultword add x", "اضافة كلمة افتراضية x"),
        ("/defaultword remove x", "حذف كلمة افتراضية x"),
    ],
    parse_backup_command: [("/backup", "نسخة احتياطية"), ("/backup confirm AB12CD", "تأكيد نسخة AB12CD")],
    parse_restore_command: [("/restore", "استعادة نسخة"), ("/restore confirm ABCDEFGH", "استعادة نسخة تأكيد ABCDEFGH")],
    parse_license_command: [("/activate", "تفعيل البوت"), ("/activate 3d", "تفعيل البوت 3 ايام"), ("/deactivate", "ايقاف البوت")],
    parse_api_check_command: [("/apicheck", "فحص API"), ("/apicheck deep", "فحص API عميق"), ("/apis", "فحص الواجهات"),
                              ("/apis deep", "فحص المفاتيح عميق")],
}

# moderation sub-commands: (English, Arabic, has_reply)
MODERATION_PAIRS = [
    ("/ban @ahmed123 7d spam", "حظر @ahmed123 7d spam", False), ("/ban 7d", "حظر 7d", True), ("/mute @ahmed123 30m", "كتم @ahmed123 30m", False),
    ("/pin silent", "تثبيت صامت", True), ("/purge 20 confirm", "تنظيف 20 تاكيد", True), ("/antiflood on", "مكافحة الفيضان تشغيل", False),
    ("/antiflood 5 10", "مكافحة الفيضان 5 10", False), ("/lock media", "قفل الوسائط", False), ("/unlock all", "فتح الكل", False),
    ("/trust domain x.com", "وثق نطاق x.com", False), ("/trust bot 123", "وثق بوت 123", False), ("/trusted", "الموثوقين", False),
    ("/welcome on", "الترحيب تفعيل", False), ("/welcome vars", "الترحيب المتغيرات", False), ("/verify method math", "التحقق الطريقة حساب", False),
    ("/newbie links on", "الاعضاء الجدد الروابط تفعيل", False), ("/report show 5", "بلاغ عرض 5", False),
    ("/reports schedule week on", "البلاغات جدولة الاسبوع تفعيل", False), ("/stats week", "الاحصائيات الاسبوع", False),
    ("/export audit csv", "تصدير التدقيق جدول", False), ("/settings", "اعدادات المجموعة", False), ("/panel", "لوحة التحكم", False),
    ("/protect show", "حماية عرض", False), ("/protect links on", "حماية الروابط تفعيل", False), ("/protect adult list", "حماية اباحي قائمة", False),
    ("/protect filter ai off", "حماية فلتر ai ايقاف", False), ("/protect slowmode 30", "حماية البطيء 30", False),
]


class OwnerCommandsHaveArabicTwins(unittest.TestCase):
    def test_every_pair_parses_to_the_same_action(self):
        for parser, pairs in OWNER_PAIRS.items():
            for english, arabic in pairs:
                with self.subTest(parser=parser.__name__, english=english, arabic=arabic):
                    en, ar = parser(english), parser(arabic)
                    self.assertIsNotNone(en, english)
                    self.assertIsNotNone(ar, arabic)
                    self.assertEqual(key(en), key(ar))


class ModerationSubcommandsHaveArabicTwins(unittest.TestCase):
    def test_pairs(self):
        for english, arabic, reply in MODERATION_PAIRS:
            with self.subTest(english=english):
                en, ar = parse_command(english, has_reply=reply), parse_command(arabic, has_reply=reply)
                self.assertIsNotNone(en, english)
                self.assertIsNotNone(ar, arabic)
                self.assertEqual((en.command, len(en.args)), (ar.command, len(ar.args)))

    def test_every_moderation_command_is_in_the_pairs_or_has_an_alias(self):
        from guardian.moderation import commands as mc
        self.assertEqual(set(Command), set(mc._ARABIC_ALIASES))


class CommandsListHasBothForms(unittest.TestCase):
    def test_arabic_form_and_english_form_exist(self):
        from guardian.bot.basic_commands import COMMANDS, parse_basic_command
        for text in ("الاوامر", "الأوامر", "كل الأوامر", "جميع الأوامر"):
            self.assertEqual(parse_basic_command(text, private=False), COMMANDS, text)
        basic = (SRC / "bot" / "routers" / "basic.py").read_text(encoding="utf-8")
        self.assertIn('Command("commands")', basic)

    def test_the_english_twin_answers_exactly_like_the_arabic_one(self):
        basic = (SRC / "bot" / "routers" / "basic.py").read_text(encoding="utf-8")
        start = basic.index('@router.message(Command("commands"))')
        body = basic[start:start + 400]
        self.assertIn("send_all_commands(message, services)", body)   # the same function the Arabic alias calls
        self.assertIn("send_all_commands(message, services)", basic[basic.index("COMMANDS:"):])


if __name__ == "__main__":
    unittest.main()
