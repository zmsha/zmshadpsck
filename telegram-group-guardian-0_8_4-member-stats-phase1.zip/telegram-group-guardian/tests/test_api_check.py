"""Part 9.6: the owner's API check (`فحص API` / `/apicheck`) and the English twin of `الاوامر` (`/commands`).

Everything runs on fakes: NO real Google, Telegram or PostgreSQL was contacted. What these tests prove is the LOGIC: each state
(works / daily quota used up / paused / invalid / expired / network / server / model) is told apart and shown as such, the
checks never raise, only the owner in a private chat gets an answer, and no secret (token, key, database URL, webhook address)
ever reaches the text."""
from __future__ import annotations

import asyncio
import json
import pathlib
import unittest
from datetime import datetime, timedelta, timezone

import helpers  # noqa: F401  (silences logging)
from guardian.content_filter import gemini as G
from guardian.errors import PermissionDenied
from guardian.i18n import MESSAGES, t
from guardian.owner_panel import api_check as A
from guardian.owner_panel.api_check_commands import (ApiCheckCommandService, ParsedApiCheck, parse_api_check_command, render)

SRC = pathlib.Path(__file__).resolve().parents[1] / "src" / "guardian"
NOW = datetime(2026, 11, 6, 12, 0, tzinfo=timezone.utc)
TOKEN = "123456789:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
DB_URL = "postgresql://dbuser:s3cretPW@db.example.com:5432/guardian"
WEBHOOK = "https://guardian-secret-host.onrender.com/telegram/webhook"
KEYS = ("AIzaKEY-ONE-0000000000000", "AIzaKEY-TWO-0000000000000", "AIzaKEY-THREE-00000000000")


def err_body(status, message="x", delay=None, code=429):
    err = {"code": code, "status": status, "message": message}
    if delay:
        err["details"] = [{"@type": "type.googleapis.com/google.rpc.RetryInfo", "retryDelay": delay}]
    return json.dumps({"error": err}).encode()


class Clock:
    def __init__(self):
        self.now = NOW

    def __call__(self):
        return self.now


class Probe:
    """GET transport: script[key] -> (status, body) or an Exception."""

    def __init__(self, script):
        self.script, self.calls = script, []

    async def __call__(self, url, headers, timeout):
        key = headers["x-goog-api-key"]
        self.calls.append((url, key))
        item = self.script[key]
        if isinstance(item, Exception):
            raise item
        return item


class Post:
    def __init__(self, script):
        self.script, self.calls, self.bodies = script, [], []

    async def __call__(self, url, headers, body, timeout):
        key = headers["x-goog-api-key"]
        self.calls.append((url, key))
        self.bodies.append(body)
        item = self.script[key]
        if isinstance(item, Exception):
            raise item
        return item


# ------------------------------------------------------------------------------------------------ parser
class ParserTests(unittest.TestCase):
    def test_english(self):
        for text, deep in (("/apicheck", False), ("/apicheck deep", True), ("/apicheck full", True), ("/apis", False),
                           ("/apis deep", True), ("/APICHECK", False), ("/apicheck@my_bot", False), ("/apicheck@my_bot deep", True)):
            parsed = parse_api_check_command(text, "my_bot")
            self.assertEqual(parsed, ParsedApiCheck("check", deep), text)

    def test_english_other_bot_unknown_name_and_bad_argument(self):
        self.assertIsNone(parse_api_check_command("/apicheck@other_bot", "my_bot"))
        self.assertIsNone(parse_api_check_command("/apicheck@my_bot", None))
        self.assertIsNone(parse_api_check_command("/apicheckx"))
        self.assertEqual(parse_api_check_command("/apicheck now").action, "usage")
        self.assertEqual(parse_api_check_command("/apicheck deep extra").action, "usage")

    def test_arabic_spellings(self):
        for text in ("فحص API", "فحص api", "فحص الapi", "فحص الAPI", "فحص ال API", "فحص الـ API", "فحص الـAPI", "افحص API",
                     "إفحص API", "اختبار API", "حالة API", "حاله api", "فحص الواجهات", "فحص واجهات", "فحص المفاتيح", "فحص مفاتيح",
                     "فحص الخدمات", "فحص APIs", "  فحص API  "):
            self.assertEqual(parse_api_check_command(text), ParsedApiCheck("check"), text)

    def test_arabic_deep(self):
        for text in ("فحص API عميق", "فحص API كامل", "فحص API شامل", "فحص الـ API عميق", "فحص المفاتيح عميق", "فحص ال API عميق",
                     "فحص API deep"):
            self.assertEqual(parse_api_check_command(text), ParsedApiCheck("check", True), text)

    def test_every_hamza_ta_and_ya_spelling_is_the_same_command(self):
        for text in ("فحص API", "إفحص API", "أفحص API", "حالة API", "حاله API", "فحص الواجهات", "فحص API كامله", "فحص API عميقا"):
            self.assertIsNotNone(parse_api_check_command(text), text)

    def test_ordinary_chat_is_never_a_command(self):
        for text in ("فحص", "فحص API الان", "فحص API عميق جدا", "فحص طبي", "فحص الدم", "هل تفحص API", "ابغى فحص API", "حالة الطقس",
                     "فحص API deep now", "api", "API", "فحصAPI", "", "   ", None, 5, "فحص " + "ا" * 80):
            self.assertIsNone(parse_api_check_command(text), text)

    def test_it_does_not_clash_with_other_parsers(self):
        from guardian.moderation.commands import parse_command
        from guardian.owner_panel.command import parse_owner_command
        from guardian.owner_panel.default_words_commands import parse_default_words_command
        from guardian.owner_panel.sandbox_commands import parse_sandbox_command
        from guardian.owner_panel.template_commands import parse_template_command
        for text in ("فحص API", "فحص API عميق", "/apicheck", "/apicheck deep", "/apis"):
            for other in (parse_command, parse_owner_command, parse_default_words_command, parse_sandbox_command,
                          parse_template_command):
                self.assertIsNone(other(text), (other.__name__, text))


# ------------------------------------------------------------------------------------------------ Gemini key check
class KeyCheckTests(unittest.IsolatedAsyncioTestCase):
    def client(self, keys, probe=None, post=None, store=None):
        self.clock = Clock()
        self.pool = G.KeyPool(list(keys), store, clock=self.clock)
        self.probe, self.post = probe, post or Post({})
        return G.GeminiClient(self.pool, self.post, clock=self.clock, probe=self.probe)

    async def test_light_check_classifies_every_state(self):
        probe = Probe({
            KEYS[0]: (200, b"{}"),
            KEYS[1]: (400, err_body("INVALID_ARGUMENT", "API key not valid. Please pass a valid API key.", code=400)),
            KEYS[2]: (400, err_body("INVALID_ARGUMENT", "API key expired. Please renew the API key.", code=400)),
            "k4": (403, err_body("PERMISSION_DENIED", "denied", code=403)),
            "k5": (404, err_body("NOT_FOUND", "model not found", code=404)),
        })
        c = self.client([*KEYS, "k4", "k5"], probe)
        reports = await c.check_keys()
        self.assertEqual([(r.slot, r.state) for r in reports],
                         [(1, G.R_WORKING), (2, G.R_INVALID), (3, G.R_EXPIRED), (4, G.R_INVALID), (5, G.R_MODEL)])
        self.assertTrue(all(url.endswith("/models/" + G.DEFAULT_MODEL) for url, _ in probe.calls))   # a GET of the model: no generation
        self.assertEqual(self.post.calls, [])                                                          # nothing was generated

    async def test_network_and_server_errors_are_not_key_problems_and_mark_nothing(self):
        probe = Probe({"a1": G.TransportError("URLError"), "a2": (503, err_body("UNAVAILABLE", "busy", code=503)),
                       "a3": (418, b"teapot")})
        c = self.client(["a1", "a2", "a3"], probe)
        reports = await c.check_keys()
        self.assertEqual([r.state for r in reports], [G.R_NETWORK, G.R_SERVER, G.R_UNKNOWN])
        self.assertEqual([s for _, s in self.pool.summary()], ["ok", "ok", "ok"])

    async def test_a_429_without_hint_is_the_daily_quota_and_is_remembered(self):
        c = self.client(["a1"], Probe({"a1": (429, err_body("RESOURCE_EXHAUSTED", "quota"))}))
        [r] = await c.check_keys()
        self.assertEqual(r.state, G.R_EXHAUSTED)
        self.assertGreater(r.until, NOW)
        self.assertEqual(self.pool.summary(), [(1, G.K_EXHAUSTED)])

    async def test_a_429_with_a_short_retry_delay_is_a_pause(self):
        c = self.client(["a1"], Probe({"a1": (429, err_body("RESOURCE_EXHAUSTED", "rate", delay="30s"))}))
        [r] = await c.check_keys()
        self.assertEqual(r.state, G.R_PAUSED)
        self.assertTrue(25 <= r.retry_after <= 40, r.retry_after)

    async def test_a_cooling_key_is_answered_from_memory_without_a_call(self):
        probe = Probe({"a1": (200, b"{}")})
        c = self.client(["a1"], probe)
        [slot] = await self.pool.snapshot()
        await self.pool.mark_exhausted(slot, NOW + timedelta(hours=5))
        [r] = await c.check_keys()
        self.assertEqual((r.state, r.from_saved), (G.R_EXHAUSTED, True))
        self.assertEqual(probe.calls, [])
        deep = self.client(["a1"], None, Post({"a1": (200, b"{}")}))
        [slot] = await self.pool.snapshot()
        await self.pool.mark_exhausted(slot, NOW + timedelta(seconds=40))
        deep._pool = self.pool
        [r] = await deep.check_keys(deep=True)
        self.assertEqual(r.state, G.R_PAUSED)           # a short cool-down is shown as a pause
        self.assertEqual(deep._transport.calls, [])

    async def test_a_renewed_quota_is_noticed_and_the_key_comes_back(self):
        probe = Probe({"a1": (200, b"{}")})
        c = self.client(["a1"], probe)
        [slot] = await self.pool.snapshot()
        await self.pool.mark_exhausted(slot, NOW - timedelta(minutes=1))     # the cool-down is over
        [r] = await c.check_keys()
        self.assertEqual(r.state, G.R_WORKING)
        self.assertEqual(self.pool.summary(), [(1, G.K_OK)])

    async def test_a_fixed_invalid_key_is_marked_ok_again(self):
        probe = Probe({"a1": (200, b"{}")})
        c = self.client(["a1"], probe)
        [slot] = await self.pool.snapshot()
        await self.pool.mark_invalid(slot)
        [r] = await c.check_keys()
        self.assertEqual(r.state, G.R_WORKING)
        self.assertEqual(self.pool.summary(), [(1, G.K_OK)])

    async def test_deep_check_makes_one_tiny_generation_per_key_and_sees_an_exhausted_quota(self):
        post = Post({"a1": (200, b"{}"), "a2": (429, err_body("RESOURCE_EXHAUSTED", "quota"))})
        c = self.client(["a1", "a2"], Probe({}), post)
        reports = await c.check_keys(deep=True)
        self.assertEqual([r.state for r in reports], [G.R_WORKING, G.R_EXHAUSTED])
        self.assertEqual(len(post.calls), 2)
        self.assertTrue(all(url.endswith(":generateContent") for url, _ in post.calls))
        for body in post.bodies:
            self.assertEqual(json.loads(body)["generationConfig"]["maxOutputTokens"], 1)
        self.assertEqual(self.pool.summary(), [(1, G.K_OK), (2, G.K_EXHAUSTED)])      # what it saw is remembered

    async def test_no_keys_means_no_reports_and_a_report_never_holds_a_key(self):
        self.assertEqual(await self.client([], Probe({})).check_keys(), [])
        c = self.client(KEYS, Probe({k: (200, b"{}") for k in KEYS}))
        for r in await c.check_keys():
            for secret in KEYS:
                self.assertNotIn(secret, repr(r))

    async def test_a_hanging_call_ends_as_a_network_report(self):
        async def hang(url, headers, timeout):
            await asyncio.sleep(30)
        c = self.client(["a1"], hang)
        [r] = await c.check_keys(timeout=0.05)
        self.assertEqual(r.state, G.R_NETWORK)


# ------------------------------------------------------------------------------------------------ the checker
class Settings:
    webhook_url = WEBHOOK
    owner_group_id = None
    gemini_api_keys = KEYS
    gemini_model = ""

    @staticmethod
    def secret_values():
        return (TOKEN, DB_URL, "s3cretPW", *KEYS)


class TgError(Exception):
    pass


class TelegramUnauthorizedError(Exception):
    pass


class TelegramRetryAfter(Exception):
    def __init__(self, retry_after):
        self.retry_after = retry_after


class TelegramNetworkError(Exception):
    pass


class FakeTelegram:
    def __init__(self, username="guardian_bot", webhook=None, chat=True, fail=None, fail_webhook=None, fail_chat=None):
        self._username, self._webhook, self._chat = username, webhook or A.WebhookState(WEBHOOK, 0), chat
        self._fail, self._fail_webhook, self._fail_chat = fail, fail_webhook, fail_chat
        self.chat_checked = []

    async def username(self):
        if self._fail:
            raise self._fail
        return self._username

    async def webhook(self):
        if self._fail_webhook:
            raise self._fail_webhook
        return self._webhook

    async def chat_reachable(self, chat_id):
        self.chat_checked.append(chat_id)
        if self._fail_chat:
            raise self._fail_chat
        return self._chat


class FakeConn:
    def __init__(self, delay=0.0, fail=None):
        self.delay, self.fail = delay, fail

    async def fetchval(self, sql):
        assert sql == "SELECT 1"
        if self.delay:
            await asyncio.sleep(self.delay)
        if self.fail:
            raise self.fail
        return 1


class FakeDb:
    def __init__(self, conn=None, fail=None):
        self.conn, self.fail = conn or FakeConn(), fail

    def acquire(self):
        db = self

        class Ctx:
            async def __aenter__(self_inner):
                if db.fail:
                    raise db.fail
                return db.conn

            async def __aexit__(self_inner, *a):
                return False
        return Ctx()


class FakeGemini:
    model = "gemini-2.5-flash-lite"

    def __init__(self, reports=(), fail=None):
        self.reports, self.fail, self.deep_seen = list(reports), fail, None

    async def check_keys(self, *, deep=False, timeout=10.0):
        self.deep_seen = deep
        if self.fail:
            raise self.fail
        return self.reports


def checker(*, telegram=None, db=None, gemini=None, settings=None, timeout=1.0):
    return A.ApiChecker(settings=settings or Settings(), database=db or FakeDb(), telegram=telegram or FakeTelegram(),
                        gemini=gemini, clock=lambda: NOW, timeout=timeout)


class CheckerTests(unittest.IsolatedAsyncioTestCase):
    async def test_everything_healthy(self):
        gem = FakeGemini([G.KeyReport(1, G.R_WORKING), G.KeyReport(2, G.R_WORKING), G.KeyReport(3, G.R_WORKING)])
        r = await checker(gemini=gem).run()
        self.assertEqual((r.telegram.token, r.telegram.username, r.telegram.webhook, r.telegram.hub),
                         (A.S_OK, "guardian_bot", A.W_OK, A.H_UNSET))
        self.assertEqual((r.database.state, r.ready_keys, r.configured_keys, r.empty_slots), (A.D_OK, 3, 3, (4, 5)))
        self.assertFalse(gem.deep_seen)
        self.assertTrue((await checker(gemini=gem).run(deep=True)).deep and gem.deep_seen)

    async def test_telegram_token_states(self):
        for exc, state, retry in ((TelegramUnauthorizedError("401"), A.S_INVALID, None), (TelegramRetryAfter(17), A.S_PAUSED, 17),
                                  (TelegramNetworkError("down"), A.S_NETWORK, None), (asyncio.TimeoutError(), A.S_NETWORK, None),
                                  (OSError("x"), A.S_NETWORK, None), (TgError("?"), A.S_ERROR, None)):
            r = await checker(telegram=FakeTelegram(fail=exc)).run()
            self.assertEqual((r.telegram.token, r.telegram.retry_after, r.telegram.username), (state, retry, ""), type(exc).__name__)

    async def test_a_refused_token_skips_the_other_telegram_questions(self):
        tg = FakeTelegram(fail=TelegramUnauthorizedError("401"))
        r = await checker(telegram=tg, settings=type("S", (Settings,), {"owner_group_id": -100123})()).run()
        self.assertEqual((r.telegram.webhook, r.telegram.hub), (A.W_UNKNOWN, A.H_UNKNOWN))
        self.assertEqual(tg.chat_checked, [])

    async def test_webhook_states(self):
        cases = ((A.WebhookState("", 0), A.W_MISSING), (A.WebhookState("https://other.example.com/x", 0), A.W_MISMATCH),
                 (A.WebhookState(WEBHOOK, 3), A.W_OK))
        for state, want in cases:
            r = await checker(telegram=FakeTelegram(webhook=state)).run()
            self.assertEqual(r.telegram.webhook, want)
        r = await checker(telegram=FakeTelegram(fail_webhook=TelegramNetworkError("x"))).run()
        self.assertEqual((r.telegram.token, r.telegram.webhook), (A.S_OK, A.W_UNKNOWN))

    async def test_without_an_expected_address_a_registered_webhook_is_fine(self):
        r = await checker(telegram=FakeTelegram(webhook=A.WebhookState("https://x.example.com/h", 0)),
                          settings=type("S", (Settings,), {"webhook_url": None})()).run()
        self.assertEqual(r.telegram.webhook, A.W_OK)

    async def test_a_large_backlog_is_flagged(self):
        r = await checker(telegram=FakeTelegram(webhook=A.WebhookState(WEBHOOK, 500))).run()
        self.assertTrue(r.telegram.backlog)
        self.assertFalse((await checker(telegram=FakeTelegram(webhook=A.WebhookState(WEBHOOK, 5))).run()).telegram.backlog)

    async def test_recent_delivery_error_is_kept_short_and_link_free_and_an_old_one_is_dropped(self):
        recent = A.WebhookState(WEBHOOK, 0, NOW - timedelta(hours=1),
                                "Wrong response from the webhook: 502 Bad Gateway https://guardian-secret-host.onrender.com/telegram/webhook " + "x" * 200)
        r = await checker(telegram=FakeTelegram(webhook=recent)).run()
        self.assertLessEqual(len(r.telegram.error_text), A.MAX_ERROR_TEXT)
        self.assertNotIn("secret-host", r.telegram.error_text)
        self.assertIn("502", r.telegram.error_text)
        old = A.WebhookState(WEBHOOK, 0, NOW - timedelta(days=3), "Connection timed out")
        self.assertIsNone((await checker(telegram=FakeTelegram(webhook=old)).run()).telegram.error_text)

    async def test_an_exact_secret_inside_a_delivery_error_is_removed_before_the_cut(self):
        long_tail = "y" * (A.MAX_ERROR_TEXT - 5)
        bad = A.WebhookState(WEBHOOK, 0, NOW - timedelta(minutes=1), f"{long_tail} {KEYS[0]} end")
        r = await checker(telegram=FakeTelegram(webhook=bad)).run()
        self.assertNotIn(KEYS[0][:8], r.telegram.error_text)
        self.assertEqual(A.clean_error_text(f"x {KEYS[1]}", (KEYS[1],)), "x ***")

    async def test_owner_group_states(self):
        s = type("S", (Settings,), {"owner_group_id": -1001234567890})()
        self.assertEqual((await checker(settings=s, telegram=FakeTelegram(chat=True)).run()).telegram.hub, A.H_OK)
        self.assertEqual((await checker(settings=s, telegram=FakeTelegram(chat=False)).run()).telegram.hub, A.H_UNREACHABLE)
        self.assertEqual((await checker(settings=s, telegram=FakeTelegram(fail_chat=TelegramNetworkError("x"))).run()).telegram.hub, A.H_UNKNOWN)
        tg = FakeTelegram()
        await checker(settings=s, telegram=tg).run()
        self.assertEqual(tg.chat_checked, [-1001234567890])

    async def test_database_states(self):
        self.assertEqual((await checker(db=FakeDb(FakeConn())).run()).database.state, A.D_OK)
        self.assertEqual((await checker(db=FakeDb(fail=RuntimeError("db down"))).run()).database.state, A.D_DOWN)
        self.assertEqual((await checker(db=FakeDb(FakeConn(fail=OSError("reset")))).run()).database.state, A.D_DOWN)
        slow = await checker(db=FakeDb(FakeConn(delay=5)), timeout=0.05).run()
        self.assertEqual(slow.database.state, A.D_DOWN)             # no answer in time = unavailable

    async def test_a_failing_gemini_check_or_missing_pieces_never_raise(self):
        r = await checker(gemini=FakeGemini(fail=RuntimeError("boom"))).run()
        self.assertEqual(r.keys, ())
        r = A.ApiChecker(settings=Settings(), database=FakeDb(), telegram=None, gemini=None, clock=lambda: NOW)
        r = await r.run()
        self.assertEqual((r.telegram.token, r.keys), (A.S_ERROR, ()))

    async def test_classify_error_by_class_name(self):
        class TelegramServerError(Exception):
            pass
        self.assertEqual(A.classify_error(TelegramServerError()), (A.S_NETWORK, None))
        self.assertEqual(A.classify_error(TelegramRetryAfter(0)), (A.S_PAUSED, None))
        self.assertEqual(A.classify_error(TelegramRetryAfter(True)), (A.S_PAUSED, None))
        self.assertEqual(A.clean_error_text(None), None)
        self.assertEqual(A.clean_error_text("  see   t.me/abc  now "), "see [link] now")


# ------------------------------------------------------------------------------------------------ the text
def full_report(**kw):
    base = dict(at=NOW, deep=False, telegram=A.TelegramReport(A.S_OK, "guardian_bot", None, A.W_OK, 0, False, None, None, A.H_UNSET),
                model="gemini-2.5-flash-lite", configured_keys=5, max_keys=5, database=A.DatabaseReport(A.D_OK, 42),
                keys=(G.KeyReport(1, G.R_WORKING), G.KeyReport(2, G.R_EXHAUSTED, NOW + timedelta(hours=9)),
                      G.KeyReport(3, G.R_PAUSED, NOW + timedelta(seconds=30), 30), G.KeyReport(4, G.R_INVALID),
                      G.KeyReport(5, G.R_EXPIRED)))
    base.update(kw)
    return A.ApiReport(**base)


class RenderTests(unittest.TestCase):
    def test_arabic_report_names_every_state(self):
        text = render(full_report(), "Asia/Riyadh", "ar")
        for needle in ("Telegram Bot API", "التوكن: يعمل (@guardian_bot)", "Webhook: مسجّل ومطابق", "Gemini", "gemini-2.5-flash-lite",
                       "مفتاح 1: يعمل", "مفتاح 2: انتهت الحصة اليومية — تتجدد", "مفتاح 3: متوقف مؤقتًا", "30 ثانية",
                       "مفتاح 4: غير صالح — استبدله في GEMINI_API_KEY_4", "مفتاح 5: منتهي الصلاحية", "الجاهز الآن: 1 من 5",
                       "قاعدة البيانات", "تعمل (42 ms)", "فحص API عميق"):
            self.assertIn(needle, text)

    def test_english_report(self):
        text = render(full_report(), "Asia/Riyadh", "en")
        for needle in ("API check", "Token: works (@guardian_bot)", "Key 2: daily quota used up", "Key 3: paused", "Key 4: invalid",
                       "Key 5: expired", "Ready now: 1 of 5", "Works (42 ms)", "/apicheck deep"):
            self.assertIn(needle, text)

    def test_every_other_state_has_text_in_both_languages(self):
        tg = lambda **k: A.TelegramReport(**{**dict(token=A.S_OK, username="b", webhook=A.W_OK, hub=A.H_UNSET), **k})  # noqa: E731
        variants = [
            full_report(telegram=tg(token=A.S_INVALID, webhook=A.W_UNKNOWN, hub=A.H_UNKNOWN)),
            full_report(telegram=tg(token=A.S_PAUSED, retry_after=9, webhook=A.W_UNKNOWN)),
            full_report(telegram=tg(token=A.S_PAUSED, webhook=A.W_UNKNOWN)),
            full_report(telegram=tg(token=A.S_NETWORK, webhook=A.W_UNKNOWN)),
            full_report(telegram=tg(token=A.S_ERROR, webhook=A.W_UNKNOWN)),
            full_report(telegram=tg(webhook=A.W_MISSING, hub=A.H_OK)),
            full_report(telegram=tg(webhook=A.W_MISMATCH, hub=A.H_UNREACHABLE)),
            full_report(telegram=tg(backlog=True, pending=900, error_text="Connection timed out", error_at=NOW - timedelta(hours=2))),
            full_report(keys=(G.KeyReport(1, G.R_NETWORK), G.KeyReport(2, G.R_SERVER), G.KeyReport(3, G.R_MODEL), G.KeyReport(4, G.R_UNKNOWN))),
            full_report(keys=(), configured_keys=0),
            full_report(keys=(G.KeyReport(1, G.R_INVALID),)),
            full_report(database=A.DatabaseReport(A.D_SLOW, 2500)), full_report(database=A.DatabaseReport(A.D_DOWN)),
            full_report(deep=True),
        ]
        for lang in ("ar", "en"):
            for report in variants:
                text = render(report, "Asia/Riyadh", lang)
                self.assertLessEqual(len(text), 4096)
                self.assertNotIn("{", text)
                self.assertNotIn("}", text)

    def test_no_key_and_no_ready_key_warnings(self):
        self.assertIn("لا مفاتيح مضبوطة", render(full_report(keys=(), configured_keys=0), "Asia/Riyadh", "ar"))
        self.assertIn("لا مفتاح جاهز الآن", render(full_report(keys=(G.KeyReport(1, G.R_INVALID),), configured_keys=1), "Asia/Riyadh", "ar"))
        self.assertIn("خانات فارغة: 2، 3، 4، 5", render(full_report(keys=(G.KeyReport(1, G.R_WORKING),), configured_keys=1), "Asia/Riyadh", "ar"))

    def test_the_deep_mode_is_labelled(self):
        self.assertIn("(عميق)", render(full_report(deep=True), "Asia/Riyadh", "ar"))
        self.assertNotIn("(عميق)", render(full_report(deep=False), "Asia/Riyadh", "ar"))

    def test_the_bot_name_is_escaped(self):
        report = full_report(telegram=A.TelegramReport(A.S_OK, "<b>evil</b>", None, A.W_OK))
        self.assertNotIn("<b>evil</b>", render(report, "Asia/Riyadh", "ar"))

    def test_both_languages_have_the_same_api_keys(self):
        ar = {k for k in MESSAGES["ar"] if k.startswith("api_")}
        self.assertEqual(ar, {k for k in MESSAGES["en"] if k.startswith("api_")})
        self.assertGreater(len(ar), 30)


# ------------------------------------------------------------------------------------------------ the command service
class Decision:
    def __init__(self, allowed):
        self.allowed = allowed


class Perm:
    OWNER = 111111111

    def __init__(self, raises=None):
        self.raises, self.asked = raises, []

    async def check_global(self, user_id, permission):
        self.asked.append((user_id, permission.value))
        if self.raises:
            raise self.raises
        return Decision(user_id == self.OWNER)


class CommandServiceTests(unittest.IsolatedAsyncioTestCase):
    def service(self, perm=None, gem=None, **kw):
        gem = gem or FakeGemini([G.KeyReport(1, G.R_WORKING)])
        self.gem = gem
        self.perm = perm or Perm()
        return ApiCheckCommandService(checker(gemini=gem, **kw), self.perm, language="ar")

    async def test_the_owner_in_private_gets_the_report(self):
        reply = await self.service().run(ParsedApiCheck("check"), chat_id=Perm.OWNER, chat_type="private", user_id=Perm.OWNER)
        self.assertEqual(reply.status, "ok")
        self.assertIn("فحص الـ API", reply.text)
        self.assertEqual(self.perm.asked, [(Perm.OWNER, "owner_panel")])

    async def test_deep_is_passed_on(self):
        s = self.service()
        await s.run(ParsedApiCheck("check", True), chat_id=Perm.OWNER, chat_type="private", user_id=Perm.OWNER)
        self.assertTrue(self.gem.deep_seen)

    async def test_english_for_an_english_client(self):
        reply = await self.service().run(ParsedApiCheck("check"), chat_id=Perm.OWNER, chat_type="private", user_id=Perm.OWNER, lang="en")
        self.assertIn("API check", reply.text)

    async def test_usage(self):
        reply = await self.service().run(ParsedApiCheck("usage"), chat_id=Perm.OWNER, chat_type="private", user_id=Perm.OWNER)
        self.assertEqual(reply.status, "usage")
        self.assertIn("/apicheck", reply.text)

    async def test_everybody_else_gets_silence(self):
        s = self.service()
        p = ParsedApiCheck("check")
        self.assertIsNone(await s.run(p, chat_id=-100123, chat_type="supergroup", user_id=Perm.OWNER))   # a group, even for the owner
        self.assertIsNone(await s.run(p, chat_id=Perm.OWNER, chat_type="group", user_id=Perm.OWNER))
        self.assertIsNone(await s.run(p, chat_id=222, chat_type="private", user_id=222))                    # not the owner
        self.assertIsNone(await s.run(p, chat_id=Perm.OWNER, chat_type="private", user_id=222))             # chat is not the sender's
        self.assertIsNone(await s.run(p, chat_id=True, chat_type="private", user_id=True))
        self.assertIsNone(await s.run(p, chat_id=None, chat_type="private", user_id=None))
        self.assertIsNone(await self.service(perm=Perm(PermissionDenied("owner_panel", "not_owner"))).run(p, chat_id=Perm.OWNER, chat_type="private", user_id=Perm.OWNER))
        self.assertIsNone(await self.service(perm=Perm(RuntimeError("db"))).run(p, chat_id=Perm.OWNER, chat_type="private", user_id=Perm.OWNER))
        self.assertEqual(self.gem.deep_seen, None)          # nothing was checked for any of them

    async def test_a_broken_checker_gives_a_short_failure_text(self):
        class Boom:
            async def run(self, *, deep=False):
                raise RuntimeError("boom with secret " + TOKEN)
        reply = await ApiCheckCommandService(Boom(), Perm()).run(ParsedApiCheck("check"), chat_id=Perm.OWNER, chat_type="private", user_id=Perm.OWNER)
        self.assertEqual(reply.status, "failed")
        self.assertNotIn(TOKEN, reply.text)


class NoSecretTests(unittest.IsolatedAsyncioTestCase):
    async def test_no_secret_reaches_the_text_in_any_state(self):
        gem = FakeGemini([G.KeyReport(i + 1, s) for i, s in enumerate((G.R_WORKING, G.R_INVALID, G.R_EXPIRED))])
        tg = FakeTelegram(webhook=A.WebhookState(WEBHOOK, 2, NOW - timedelta(minutes=5), f"failed {WEBHOOK} token {TOKEN}"[:300]))
        for lang in ("ar", "en"):
            service = ApiCheckCommandService(checker(telegram=tg, gemini=gem, db=FakeDb(fail=RuntimeError(DB_URL))), Perm(), language=lang)
            reply = await service.run(ParsedApiCheck("check", True), chat_id=Perm.OWNER, chat_type="private", user_id=Perm.OWNER)
            for secret in (*KEYS, TOKEN, DB_URL, "s3cretPW", "db.example.com", WEBHOOK, "guardian-secret-host", "onrender.com"):
                self.assertNotIn(secret, reply.text, (lang, secret))


# ------------------------------------------------------------------------------------------------ wiring (source level)
class WiringTests(unittest.TestCase):
    def read(self, *parts):
        return SRC.joinpath(*parts).read_text(encoding="utf-8")

    def test_the_command_is_wired_end_to_end(self):
        self.assertIn("match_api_check_command", self.read("bot", "routers", "owner_panel.py"))
        self.assertIn("execute_api_check", self.read("bot", "routers", "owner_panel.py"))
        self.assertIn("owner_api_check", self.read("services.py"))
        app = self.read("app.py")
        for needle in ("owner_api_check=ApiCheckCommandService(", "ApiChecker(", "AiogramTelegramProbe(bot)", "gemini=gemini_client"):
            self.assertIn(needle, app)
        handler = self.read("bot", "owner_panel_handler.py")
        self.assertIn('getattr(services, "owner_api_check"', handler)
        self.assertIn('_chat_type(message) != "private"', handler)

    def test_the_probe_only_reads(self):
        probe = self.read("bot", "telegram_probe.py")
        for call in ("get_me", "get_webhook_info", "get_chat"):
            self.assertIn(call, probe)
        for forbidden in ("send_message", "set_webhook", "delete_webhook", "ban_chat", "restrict_chat", "send_document"):
            self.assertNotIn(forbidden, probe)
            self.assertNotIn(forbidden, self.read("owner_panel", "api_check.py"))

    def test_the_owner_list_names_the_command_in_both_languages(self):
        for lang in ("ar", "en"):
            text = t("commands_owner", lang)
            self.assertIn("فحص API", text)
            self.assertIn("فحص API عميق", text)
        self.assertIn("/apicheck", t("commands_owner", "en"))

    def test_slash_commands_twin_of_the_arabic_list(self):
        basic = self.read("bot", "routers", "basic.py")
        self.assertIn('Command("commands")', basic)
        self.assertIn("send_all_commands(message, services)", basic)


if __name__ == "__main__":
    unittest.main()
