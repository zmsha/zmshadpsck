import string
import unittest

from guardian.i18n import MESSAGES, license_label, pick_language, t
from guardian.licensing.models import LicenseStatus


def fields(template: str) -> set[str]:
    return {name for _, name, _, _ in string.Formatter().parse(template) if name}


class I18nTests(unittest.TestCase):
    def test_same_keys_in_both_languages(self):
        self.assertEqual(set(MESSAGES["ar"]), set(MESSAGES["en"]))

    def test_same_placeholders_in_both_languages(self):
        for key in MESSAGES["ar"]:
            with self.subTest(key=key):
                self.assertEqual(fields(MESSAGES["ar"][key]), fields(MESSAGES["en"][key]))

    def test_pick_language(self):
        self.assertEqual(pick_language("ar", "en"), "ar")
        self.assertEqual(pick_language("en-US", "ar"), "en")
        self.assertEqual(pick_language("fr", "ar"), "ar")
        self.assertEqual(pick_language(None, "en"), "en")
        self.assertEqual(pick_language("de", "xx"), "ar")

    def test_values_are_html_escaped(self):
        text = t("owner_new_group", "ar", title="<b>x</b> & y", group_id="-100")
        self.assertIn("&lt;b&gt;x&lt;/b&gt; &amp; y", text)
        self.assertNotIn("<b>x</b>", text)

    def test_unknown_language_falls_back_to_arabic(self):
        self.assertEqual(t("help", "zz"), t("help", "ar"))

    def test_unknown_key_raises(self):
        with self.assertRaises(KeyError):
            t("no_such_key", "ar")

    def test_every_license_status_has_a_label(self):
        for status in LicenseStatus:
            for lang in ("ar", "en"):
                self.assertTrue(license_label(status, lang))


if __name__ == "__main__":
    unittest.main()
