"""Part 6.7a: the private export delivery path. No Telegram/aiogram: the transport is a fake that records sends."""
from __future__ import annotations

import ast
import asyncio
import inspect
import re
import unittest
from datetime import datetime, timezone
from pathlib import Path

from guardian import export as export_pkg
from guardian.audit import EXPORT_DELIVERED, EXPORT_FAILED, RESULT_APPLIED, RESULT_FAILED, InMemorySecurityAudit
from guardian.export import delivery as dv
from guardian.export import models as m
from guardian.export.delivery import ExportDelivery
from guardian.export.models import DeliveryResult, ExportError, ExportFile, PrivateChatUnavailable
from guardian.idempotency import InMemoryIdempotency

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src" / "guardian"
USER, OTHER, GROUP = 7001, 7002, -1001234
SECRET = "S3cretValue-XYZ-98765"
NOW = datetime(2026, 11, 1, 12, tzinfo=timezone.utc)


class FakeTransport:
    def __init__(self) -> None:
        self.sent: list[tuple[int, str, bytes, str | None]] = []
        self.error: BaseException | None = None
        self.delay = 0.0

    async def send_document(self, user_id, filename, data, caption):
        if self.delay:
            await asyncio.sleep(self.delay)
        if self.error is not None:
            raise self.error
        self.sent.append((user_id, filename, data, caption))


class FailingClaims:
    async def claim(self, key, now=None):
        raise RuntimeError("db down")


class FailingAudit:
    async def record(self, event):
        raise RuntimeError("audit down")


def csv_file(name="members", rows=2, content=None) -> ExportFile:
    return ExportFile(name, "csv", content if content is not None else "id,state\n1,ok\n2,ok\n", rows=rows)


class Base(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self.transport = FakeTransport()
        self.claims = InMemoryIdempotency()
        self.audit = InMemorySecurityAudit()
        self.d = ExportDelivery(self.transport, claims=self.claims, audit=self.audit, secrets=(SECRET,), clock=lambda: NOW)


# ======================================================================================== models
class ExportFileTests(unittest.TestCase):
    def test_a_well_formed_file(self):
        f = ExportFile("settings", "json", "{}", rows=1)
        self.assertEqual((f.filename, f.data()), ("settings.json", b"{}"))

    def test_bad_names_kinds_content_and_counts_are_refused(self):
        for name in ("", "  ", "a/b", "a\\b", "x" * 61, "a\x00b", None, 5):
            with self.subTest(name=name), self.assertRaises(ExportError):
                ExportFile(name, "csv", "x")
        for kind in ("exe", "log", "CSV", "", None, "zip", "env"):
            with self.subTest(kind=kind), self.assertRaises(ExportError):
                ExportFile("a", kind, "x")
        with self.assertRaises(ExportError):
            ExportFile("a", "csv", b"bytes")
        for rows in (-1, True, 1.5, "2"):
            with self.subTest(rows=rows), self.assertRaises(ExportError):
                ExportFile("a", "csv", "x", rows=rows)

    def test_the_codes_are_a_closed_set(self):
        self.assertEqual(m.CODES, {"sent", "private_not_started", "too_large", "too_many_rows", "rejected", "duplicate", "invalid", "failed"})
        self.assertTrue(DeliveryResult(m.SENT).ok)
        for code in m.CODES - {m.SENT}:
            self.assertFalse(DeliveryResult(code).ok)


# ======================================================================================== destination
class DestinationTests(Base):
    async def test_the_file_goes_to_the_requesters_private_chat_only(self):
        r = await self.d.deliver(USER, csv_file(), key=1)
        self.assertEqual(r.code, m.SENT)
        self.assertEqual(len(self.transport.sent), 1)
        user_id, filename, data, caption = self.transport.sent[0]
        self.assertEqual((user_id, filename), (USER, "members.csv"))
        self.assertEqual(data, b"id,state\n1,ok\n2,ok\n")
        self.assertIsNone(caption)

    async def test_a_group_channel_or_non_id_requester_is_refused_and_nothing_is_sent(self):
        for who in (GROUP, -100, 0, True, False, None, "7001", 7001.0, [7001]):
            with self.subTest(who=who):
                r = await self.d.deliver(who, csv_file(), key=1)
                self.assertEqual(r.code, m.INVALID)
        self.assertEqual(self.transport.sent, [])

    async def test_a_disabled_path_without_a_transport_sends_nothing(self):
        d = ExportDelivery(None, claims=self.claims, audit=self.audit)
        self.assertFalse(d.enabled)
        self.assertEqual((await d.deliver(USER, csv_file(), key=1)).code, m.INVALID)

    async def test_something_that_is_not_an_export_file_is_invalid_and_never_raises(self):
        for bad in (None, "text", b"bytes", {"name": "a"}, object()):
            with self.subTest(bad=bad):
                self.assertEqual((await self.d.deliver(USER, bad, key=1)).code, m.INVALID)
        self.assertEqual(self.transport.sent, [])

    async def test_there_is_no_way_to_name_a_chat(self):
        params = set(inspect.signature(ExportDelivery.deliver).parameters)
        self.assertEqual(params, {"self", "requester_id", "file", "key", "caption", "group_id"})
        # `group_id` is audit context only: passing a group never changes the destination
        await self.d.deliver(USER, csv_file(), key=1, group_id=GROUP)
        self.assertEqual([s[0] for s in self.transport.sent], [USER])


# ======================================================================================== limits and screening
class LimitTests(Base):
    async def test_too_many_rows(self):
        r = await self.d.deliver(USER, csv_file(rows=m.MAX_ROWS + 1), key=1)
        self.assertEqual(r.code, m.TOO_MANY_ROWS)
        self.assertEqual(self.transport.sent, [])

    async def test_exactly_the_row_cap_is_allowed(self):
        self.assertEqual((await self.d.deliver(USER, csv_file(rows=m.MAX_ROWS), key=1)).code, m.SENT)

    async def test_too_large_measured_in_bytes_not_characters(self):
        # 400k Arabic letters = 800k bytes (fits) ; 600k = 1.2M bytes (does not), although 600k < 1M characters
        fits = ExportFile("big", "txt", "ع" * 400_000)
        over = ExportFile("big", "txt", "ع" * 600_000)
        self.assertEqual((await self.d.deliver(USER, fits, key=1)).code, m.SENT)
        self.assertEqual((await self.d.deliver(USER, over, key=2)).code, m.TOO_LARGE)
        self.assertEqual(len(self.transport.sent), 1)

    async def test_the_limits_equal_the_hub_screens_ceiling(self):
        from guardian.owner_hub.redactor import MAX_FILE_BYTES
        self.assertEqual(m.MAX_BYTES, MAX_FILE_BYTES)


class ScreenTests(Base):
    async def test_a_secret_inside_the_content_is_masked_in_what_is_sent(self):
        f = csv_file(content=f"key,value\nnote,{SECRET}\nDATABASE_URL=postgresql://u:p4ssw0rd@h/db\n")
        r = await self.d.deliver(USER, f, key=1)
        self.assertEqual(r.code, m.SENT)
        self.assertGreaterEqual(r.redactions, 2)
        data = self.transport.sent[0][2].decode()
        self.assertNotIn(SECRET, data)
        self.assertNotIn("p4ssw0rd", data)

    async def test_the_caption_is_redacted_and_capped(self):
        await self.d.deliver(USER, csv_file(), key=1, caption=f"for you {SECRET}")
        caption = self.transport.sent[0][3]
        self.assertNotIn(SECRET, caption)
        await self.d.deliver(USER, csv_file(), key=2, caption="x" * 5000)
        self.assertLessEqual(len(self.transport.sent[1][3]), m.MAX_CAPTION)

    async def test_secret_shaped_files_are_refused_not_cleaned(self):
        pem = "-----BEGIN PRIVATE KEY-----\nabc\n-----END PRIVATE KEY-----\n"
        dotenv = "BOT_TOKEN=aaaa\nDATABASE_URL=bbbb\nWEBHOOK_SECRET=cccc\n"
        for label, f in (("pem", ExportFile("keys", "txt", pem)), ("dotenv", ExportFile("settings", "txt", dotenv)),
                         ("blank", ExportFile("empty", "txt", "   \n")), ("env name", ExportFile("env", "txt", "a=b"))):
            with self.subTest(label):
                self.assertEqual((await self.d.deliver(USER, f, key=label)).code, m.REJECTED)
        self.assertEqual(self.transport.sent, [])

    async def test_a_refused_file_does_not_use_up_the_operation_key(self):
        self.assertEqual((await self.d.deliver(USER, ExportFile("e", "txt", " "), key=5)).code, m.REJECTED)
        self.assertEqual((await self.d.deliver(USER, csv_file(), key=5)).code, m.SENT)

    async def test_the_sent_name_is_the_screened_one(self):
        await self.d.deliver(USER, ExportFile("Group Settings", "json", "{}"), key=1)
        self.assertEqual(self.transport.sent[0][1], "Group_Settings.json")


# ======================================================================================== idempotency
class OneDeliveryPerOperationTests(Base):
    async def test_the_same_operation_is_delivered_once(self):
        self.assertEqual((await self.d.deliver(USER, csv_file(), key=10)).code, m.SENT)
        self.assertEqual((await self.d.deliver(USER, csv_file(), key=10)).code, m.DUPLICATE)
        self.assertEqual(len(self.transport.sent), 1)

    async def test_a_duplicate_is_silent_in_the_audit(self):
        await self.d.deliver(USER, csv_file(), key=10)
        await self.d.deliver(USER, csv_file(), key=10)
        self.assertEqual(len(self.audit.events), 1)

    async def test_another_key_requester_or_kind_is_a_different_operation(self):
        await self.d.deliver(USER, csv_file(), key=10)
        self.assertEqual((await self.d.deliver(USER, csv_file(), key=11)).code, m.SENT)
        self.assertEqual((await self.d.deliver(OTHER, csv_file(), key=10)).code, m.SENT)
        self.assertEqual((await self.d.deliver(USER, ExportFile("a", "json", "{}"), key=10)).code, m.SENT)
        self.assertEqual(len(self.transport.sent), 4)

    async def test_two_concurrent_deliveries_of_one_operation_send_once(self):
        results = await asyncio.gather(*[self.d.deliver(USER, csv_file(), key=1) for _ in range(5)])
        self.assertEqual(sorted(r.code for r in results), [m.DUPLICATE] * 4 + [m.SENT])
        self.assertEqual(len(self.transport.sent), 1)

    async def test_a_claim_store_failure_sends_nothing(self):
        d = ExportDelivery(self.transport, claims=FailingClaims(), audit=self.audit)
        self.assertEqual((await d.deliver(USER, csv_file(), key=1)).code, m.FAILED)
        self.assertEqual(self.transport.sent, [])

    async def test_an_unusable_key_is_a_failure_not_a_crash(self):
        self.assertEqual((await self.d.deliver(USER, csv_file(), key="bad key with spaces")).code, m.FAILED)
        self.assertEqual(self.transport.sent, [])


# ======================================================================================== failures
class FailureTests(Base):
    async def test_a_user_who_never_started_the_bot_is_told_apart(self):
        self.transport.error = PrivateChatUnavailable()
        r = await self.d.deliver(USER, csv_file(), key=1)
        self.assertEqual(r.code, m.PRIVATE_NOT_STARTED)
        self.assertEqual(self.audit.events[-1].event_type, EXPORT_FAILED)

    async def test_a_telegram_error_is_a_failure_without_its_text_in_the_audit(self):
        self.transport.error = RuntimeError(f"HTTP 500 https://api.telegram.org/bot123456:ABCdefGHIjklMNOpqrsTUVwxyz0123456789/sendDocument {SECRET}")
        r = await self.d.deliver(USER, csv_file(), key=1)
        self.assertEqual(r.code, m.FAILED)
        event = self.audit.events[-1]
        self.assertIn("why=RuntimeError", event.detail)
        self.assertNotIn(SECRET, event.detail)
        self.assertNotIn("telegram.org", event.detail)

    async def test_a_hung_send_times_out(self):
        d = ExportDelivery(self.transport, claims=self.claims, audit=self.audit, timeout=0.05)
        self.transport.delay = 5
        r = await asyncio.wait_for(d.deliver(USER, csv_file(), key=1), 2)
        self.assertEqual(r.code, m.FAILED)
        self.assertIn("why=timeout", self.audit.events[-1].detail)

    async def test_cancellation_is_not_swallowed(self):
        self.transport.delay = 5
        task = asyncio.create_task(self.d.deliver(USER, csv_file(), key=1))
        await asyncio.sleep(0.05)
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await task

    async def test_a_failed_audit_never_changes_the_outcome(self):
        d = ExportDelivery(self.transport, claims=self.claims, audit=FailingAudit())
        self.assertEqual((await d.deliver(USER, csv_file(), key=1)).code, m.SENT)
        self.transport.error = RuntimeError("x")
        self.assertEqual((await d.deliver(USER, csv_file(), key=2)).code, m.FAILED)

    async def test_no_retry_inside_a_call(self):
        calls = []

        class Counting(FakeTransport):
            async def send_document(self, *a):
                calls.append(a)
                raise RuntimeError("down")
        d = ExportDelivery(Counting(), claims=self.claims, audit=self.audit)
        await d.deliver(USER, csv_file(), key=1)
        self.assertEqual(len(calls), 1)


# ======================================================================================== audit
class AuditTests(Base):
    async def test_a_delivery_is_audited_without_any_content(self):
        f = ExportFile("Secret Group Name", "csv", "id,reason\n1,private words here\n", rows=1)
        await self.d.deliver(USER, f, key=1, group_id=GROUP, caption="private caption")
        e = self.audit.events[-1]
        self.assertEqual((e.event_type, e.actor_telegram_id, e.group_id, e.target_id, e.result), (EXPORT_DELIVERED, USER, GROUP, "csv", RESULT_APPLIED))
        self.assertEqual(e.occurred_at, NOW)
        for forbidden in ("private words", "Secret Group", "private caption", "reason"):
            self.assertNotIn(forbidden, e.detail or "")
        self.assertIn("kind=csv", e.detail)
        self.assertIn("rows=1", e.detail)
        self.assertIn("code=sent", e.detail)

    async def test_every_refusal_is_audited_as_a_failure_with_its_code(self):
        for code, f, who in ((m.TOO_MANY_ROWS, csv_file(rows=m.MAX_ROWS + 1), USER), (m.INVALID, csv_file(), GROUP),
                             (m.REJECTED, ExportFile("e", "txt", " "), USER)):
            self.audit.events.clear()
            await self.d.deliver(who, f, key=1)
            e = self.audit.events[-1]
            self.assertEqual((e.event_type, e.result), (EXPORT_FAILED, RESULT_FAILED))
            self.assertIn(f"code={code}", e.detail)

    async def test_an_invalid_requester_is_not_recorded_as_the_actor(self):
        await self.d.deliver(GROUP, csv_file(), key=1)
        self.assertIsNone(self.audit.events[-1].actor_telegram_id)

    async def test_the_group_context_is_optional_and_checked(self):
        await self.d.deliver(USER, csv_file(), key=1)
        self.assertIsNone(self.audit.events[-1].group_id)
        await self.d.deliver(USER, csv_file(), key=2, group_id="not-an-int")
        self.assertIsNone(self.audit.events[-1].group_id)


# ======================================================================================== static guards
class StructureTests(unittest.TestCase):
    def read(self, rel: str) -> str:
        return (SRC / rel).read_text(encoding="utf-8")

    def imports(self, rel: str) -> list[str]:
        out = []
        for node in ast.walk(ast.parse(self.read(rel))):
            if isinstance(node, ast.ImportFrom):
                out.append(("." * node.level) + (node.module or "") + ":" + ",".join(a.name for a in node.names))
            elif isinstance(node, ast.Import):
                out.extend(a.name for a in node.names)
        return out

    def test_the_export_package_is_independent_of_the_owner_hub_sender_and_of_aiogram(self):
        for path in (SRC / "export").glob("*.py"):
            for imp in self.imports(f"export/{path.name}"):
                with self.subTest(path=path.name, imp=imp):
                    self.assertNotIn("aiogram", imp)
                    for banned in ("owner_hub.sender", "owner_hub.reports", "owner_hub.mirror", "hub_transport", "owner_hub:"):
                        self.assertNotIn(banned, imp)

    def test_the_only_owner_hub_pieces_it_uses_are_the_redactor_functions(self):
        used = [i for i in self.imports("export/delivery.py") if "owner_hub" in i]
        self.assertEqual(used, ["..owner_hub.redactor:redact_text,screen_file"])

    def test_delivery_has_one_send_and_it_targets_the_requester(self):
        tree = ast.parse(self.read("export/delivery.py"))
        calls = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                 and n.func.attr.startswith("send_")]
        self.assertEqual([c.func.attr for c in calls], ["send_document"])
        self.assertIsInstance(calls[0].args[0], ast.Name)
        self.assertEqual(calls[0].args[0].id, "requester_id")

    def test_no_public_function_of_the_package_accepts_a_chat_id(self):
        # `command.py` (6.7b) is the one exception: its `chat_id` is the group the command was TYPED in (the audit context and
        # the data to read), never a destination. It has no send call of its own; see `test_export_command.py`
        # (`test_the_command_never_sends_and_delivers_only_to_the_actor`) which pins exactly that.
        for path in (SRC / "export").glob("*.py"):
            if path.name == "command.py":
                continue
            for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"))):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    names = [a.arg for a in node.args.args + node.args.kwonlyargs]
                    with self.subTest(path=path.name, fn=node.name):
                        self.assertNotIn("chat_id", names)
                        self.assertNotIn("destination", names)

    def test_every_file_is_screened_before_the_claim_and_the_send(self):
        body = inspect.getsource(ExportDelivery._deliver)
        self.assertLess(body.index("screen_file("), body.index(".claim("))
        self.assertLess(body.index(".claim("), body.index("send_document("))
        self.assertLess(body.index("MAX_ROWS"), body.index("screen_file("))

    def test_the_aiogram_adapter_is_thin_and_targets_the_user_id(self):
        tree = ast.parse(self.read("bot/export_transport.py"))
        sends = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr.startswith("send_")]
        self.assertEqual([c.func.attr for c in sends], ["send_document"])
        self.assertEqual(sends[0].args[0].id, "user_id")
        self.assertEqual([k.arg for k in sends[0].keywords if k.arg == "parse_mode"], [])
        self.assertIn("PrivateChatUnavailable", self.read("bot/export_transport.py"))

    def test_the_hub_package_does_not_know_the_export_package(self):
        # the path is independent, not a wrapper around the hub (and the hub is not a wrapper around it)
        for path in (SRC / "owner_hub").glob("*.py"):
            for imp in self.imports(f"owner_hub/{path.name}"):
                self.assertNotIn("export", imp, path.name)

    def test_wiring_in_services_and_app(self):
        self.assertIn("export_delivery", self.read("services.py"))
        app = self.read("app.py")
        self.assertIn("ExportDelivery(AiogramExportTransport(bot), claims=claims", app)
        self.assertIn("secrets=settings.secret_values()", app[app.index("ExportDelivery(AiogramExportTransport"):])

    def test_the_command_arrived_in_6_7b_and_there_is_still_no_new_migration(self):
        # 6.7a added no command; 6.7b adds `/export` (31 commands) and its texts, still without a migration.
        from guardian.moderation.commands import Command
        self.assertIn("EXPORT", Command.__members__)
        self.assertEqual(len(Command), 31)
        self.assertIsNotNone(re.search(r"""["']export_sent["']""", self.read("i18n.py")))
        self.assertEqual(sorted(p.name[:4] for p in (SRC / "db" / "sql").glob("0*.sql"))[-1], "0013")
        self.assertIn('"export"', self.read("bot/commands_menu.py"))

    def test_the_audit_events_exist(self):
        self.assertEqual((EXPORT_DELIVERED, EXPORT_FAILED), ("export_delivered", "export_failed"))

    def test_the_package_exports_the_contract(self):
        self.assertEqual(set(export_pkg.__all__), {"DeliveryResult", "ExportDelivery", "ExportError", "ExportFile", "ExportTransport", "PrivateChatUnavailable"})
        self.assertIs(export_pkg.ExportDelivery, dv.ExportDelivery)


if __name__ == "__main__":
    unittest.main()
