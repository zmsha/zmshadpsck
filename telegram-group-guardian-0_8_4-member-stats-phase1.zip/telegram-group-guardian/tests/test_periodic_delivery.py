"""Part 6.6b: delivery of the owed periodic reports. Telegram, aiogram and PostgreSQL are NOT involved: the bot is a
fake that records sends, the stores are the in-memory ones."""
from __future__ import annotations

import asyncio
import re
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from guardian.audit import PERIODIC_REPORT_SENT, InMemorySecurityAudit
from guardian.bot.middlewares import ProtectionGateMiddleware
from guardian.errors import InvalidInput
from guardian.i18n import t
from guardian.idempotency import InMemoryIdempotency
from guardian.protection_gate import ProtectionContext
from guardian.stats import ReportScheduleService, StatsPeriod, StatsService
from guardian.stats import periodic_delivery as pd
from guardian.stats.models import PeriodRange
from guardian.stats.periodic_delivery import PeriodicDelivery, lease_key
from guardian.stats.schedule_memory_store import InMemoryScheduleStore

ROOT = Path(__file__).resolve().parent.parent
GA, GB = -1001, -1002
ADMIN = 7001
DAY, WEEK, MONTH = StatsPeriod.DAY, StatsPeriod.WEEK, StatsPeriod.MONTH
TZ = "Asia/Riyadh"


def utc(y, m, d, h=12, mi=0) -> datetime:
    return datetime(y, m, d, h, mi, tzinfo=timezone.utc)


class FakeBot:
    def __init__(self) -> None:
        self.sent: list[tuple[int, str]] = []
        self.fail_next = 0

    async def send_message(self, chat_id, text):
        if self.fail_next:
            self.fail_next -= 1
            raise RuntimeError("telegram down")
        self.sent.append((chat_id, text))


class RecordingStats(StatsService):
    def __init__(self) -> None:
        super().__init__(display_timezone=TZ)
        self.ranges: list[tuple[int, PeriodRange]] = []

    async def range_stats(self, group_id, rng):
        self.ranges.append((group_id, rng))
        return await super().range_stats(group_id, rng)


class Base(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self.now = utc(2026, 10, 28, 12)
        self.mono = [1000.0]
        self.audit = InMemorySecurityAudit()
        self.store = InMemoryScheduleStore()
        self.schedule = ReportScheduleService(self.store, self.audit, display_timezone=TZ, clock=lambda: self.now)
        self.stats = RecordingStats()
        self.claims = InMemoryIdempotency()
        self.raw: dict | Exception = {}
        self.bot = FakeBot()

        async def load_raw(chat_id):
            if isinstance(self.raw, Exception):
                raise self.raw
            return self.raw

        self.delivery = PeriodicDelivery(
            schedule=self.schedule, stats=self.stats, claims=self.claims, load_raw=load_raw, audit=self.audit,
            clock=lambda: self.now, mono=lambda: self.mono[0])

    async def enable(self, group=GA, period=DAY, when=None):
        await self.schedule.set_enabled(group, period, True, ADMIN, now=when or utc(2026, 10, 25, 12))


class DeliverTests(Base):
    async def test_sends_the_owed_days_oldest_first_and_marks_them_done(self):
        await self.enable()
        run = await self.delivery.deliver_group(self.bot, GA)
        self.assertEqual((run.sent, run.failed, run.pending), (3, False, False))
        self.assertEqual([c for c, _ in self.bot.sent], [GA, GA, GA])
        self.assertEqual([r.start_day.isoformat() for g, r in self.stats.ranges], ["2026-10-25", "2026-10-26", "2026-10-27"])
        self.assertTrue(all(r.period is DAY for _, r in self.stats.ranges))   # calendar ranges, not rolling ones
        self.assertIn(t("periodic_title_day", "ar"), self.bot.sent[0][1])
        self.assertEqual((await self.schedule.entries(GA))[DAY].last_period_key, "2026-10-27")
        again = await self.delivery.deliver_group(self.bot, GA)
        self.assertEqual(again.sent, 0)
        self.assertEqual(len(self.bot.sent), 3)

    async def test_a_group_that_switched_nothing_on_receives_nothing(self):
        run = await self.delivery.deliver_group(self.bot, GA)
        self.assertEqual((run.sent, self.bot.sent), (0, []))

    async def test_one_group_never_receives_another_groups_report(self):
        await self.enable(GA)
        await self.delivery.deliver_group(self.bot, GB)
        self.assertEqual(self.bot.sent, [])
        self.assertIsNone((await self.schedule.entries(GA))[DAY].last_period_key)

    async def test_a_week_and_a_month_are_calendar_periods(self):
        await self.schedule.set_enabled(GA, WEEK, True, ADMIN, now=utc(2026, 10, 14, 12))
        await self.schedule.set_enabled(GA, MONTH, True, ADMIN, now=utc(2026, 9, 10, 12))
        await self.delivery.deliver_group(self.bot, GA)
        got = [(r.period, r.start_day.isoformat(), r.end_day.isoformat()) for _, r in self.stats.ranges]
        self.assertIn((WEEK, "2026-10-18", "2026-10-24"), got)          # Sunday..Saturday
        self.assertIn((MONTH, "2026-09-01", "2026-09-30"), got)         # the calendar month, not 30 days

    async def test_skipped_older_periods_are_named_in_the_first_report_only(self):
        await self.enable(when=utc(2026, 10, 1, 12))
        await self.delivery.deliver_group(self.bot, GA)
        self.assertEqual(len(self.bot.sent), 3)
        skipped = t("periodic_skipped", "ar", n=24)
        self.assertIn(skipped, self.bot.sent[0][1])
        self.assertNotIn("لم تُرسَل", self.bot.sent[1][1])

    async def test_a_report_is_numbers_only_and_names_unreadable_sections(self):
        await self.enable()
        await self.delivery.deliver_group(self.bot, GA)
        text = self.bot.sent[0][1]
        self.assertIn(t("stats_section_missing", "ar", section=t("stats_section_warnings", "ar")), text)
        self.assertNotIn("<code>", text)   # no event names, ids or free text: sections only

    async def test_the_sent_report_is_audited_without_its_content(self):
        await self.enable()
        await self.delivery.deliver_group(self.bot, GA)
        events = [e for e in self.audit.events if e.event_type == PERIODIC_REPORT_SENT]
        self.assertEqual(len(events), 3)
        self.assertEqual({e.group_id for e in events}, {GA})
        self.assertEqual(events[0].detail, "period=day key=2026-10-25")
        self.assertEqual(events[0].result, "applied")


class DestinationTests(Base):
    async def test_the_approved_destination_receives_it_instead_of_the_group(self):
        await self.enable()
        self.raw = {"reports_destination": -100777}
        await self.delivery.deliver_group(self.bot, GA)
        self.assertEqual({c for c, _ in self.bot.sent}, {-100777})

    async def test_an_invalid_destination_means_the_group_itself(self):
        await self.enable()
        self.raw = {"reports_destination": 12345}
        await self.delivery.deliver_group(self.bot, GA)
        self.assertEqual({c for c, _ in self.bot.sent}, {GA})

    async def test_unreadable_settings_send_nothing_and_mark_nothing(self):
        await self.enable()
        self.raw = RuntimeError("db down")
        run = await self.delivery.deliver_group(self.bot, GA)
        self.assertEqual((run.sent, run.failed, self.bot.sent), (0, True, []))
        self.assertEqual(self.stats.ranges, [])                       # nothing was even built, no lease taken
        self.assertEqual(self.claims._keys, {})
        self.assertIsNone((await self.schedule.entries(GA))[DAY].last_period_key)

    async def test_a_failing_destination_never_falls_back_to_the_group(self):
        await self.enable()
        self.raw = {"reports_destination": -100777}
        self.bot.fail_next = 99
        run = await self.delivery.deliver_group(self.bot, GA)
        self.assertTrue(run.failed)
        self.assertEqual(self.bot.sent, [])


class FailureTests(Base):
    async def test_a_failed_send_is_not_marked_and_stops_newer_periods(self):
        await self.enable()
        self.bot.fail_next = 1
        run = await self.delivery.deliver_group(self.bot, GA)
        self.assertEqual((run.sent, run.failed), (0, True))
        self.assertEqual(self.bot.sent, [])
        self.assertIsNone((await self.schedule.entries(GA))[DAY].last_period_key)   # nothing swallowed
        self.assertEqual(len(self.stats.ranges), 1)                                  # the newer ones were not even built

    async def test_the_lease_blocks_a_second_attempt_in_the_same_window_only(self):
        await self.enable()
        self.bot.fail_next = 1
        await self.delivery.deliver_group(self.bot, GA)
        self.now += timedelta(seconds=30)
        again = await self.delivery.deliver_group(self.bot, GA)
        self.assertEqual((again.sent, again.pending), (0, True))     # same window: another run "holds" it
        self.now += timedelta(seconds=pd.LEASE_SECONDS + 1)
        later = await self.delivery.deliver_group(self.bot, GA)
        self.assertEqual(later.sent, 3)                              # the failed report is retried, oldest first
        self.assertEqual((await self.schedule.entries(GA))[DAY].last_period_key, "2026-10-27")

    async def test_two_runs_at_once_send_each_report_once(self):
        await self.enable()
        a, b = await asyncio.gather(self.delivery.deliver_group(self.bot, GA), self.delivery.deliver_group(self.bot, GA))
        self.assertEqual(len(self.bot.sent), 3)
        self.assertEqual(a.sent + b.sent, 3)

    async def test_a_failing_mark_done_never_causes_a_second_send(self):
        await self.enable()
        real = self.schedule.mark_done
        down = {"on": True}

        async def flaky(*args, **kw):
            if down["on"]:
                raise RuntimeError("db hiccup")
            return await real(*args, **kw)

        self.schedule.mark_done = flaky
        await self.delivery.deliver_group(self.bot, GA)
        self.assertEqual(len(self.bot.sent), 3)
        down["on"] = False
        self.now += timedelta(seconds=pd.LEASE_SECONDS + 1)
        await self.delivery.deliver_group(self.bot, GA)
        self.assertEqual(len(self.bot.sent), 3)                      # the unmarked one is NOT re-sent, only marked
        self.assertEqual((await self.schedule.entries(GA))[DAY].last_period_key, "2026-10-27")

    async def test_a_store_error_propagates_to_the_caller(self):
        await self.enable()

        async def broken(*a, **k):
            raise RuntimeError("db down")

        self.schedule.owed_all = broken
        with self.assertRaises(RuntimeError):
            await self.delivery.deliver_group(self.bot, GA)

    async def test_the_run_limit_leaves_the_rest_for_the_next_run(self):
        await self.enable(when=utc(2026, 10, 25, 12))
        await self.schedule.set_enabled(GA, WEEK, True, ADMIN, now=utc(2026, 10, 14, 12))
        first = await self.delivery.deliver_group(self.bot, GA)
        self.assertEqual((first.sent, first.pending), (pd.MAX_PER_TICK, True))
        self.now += timedelta(seconds=pd.LEASE_SECONDS + 1)
        second = await self.delivery.deliver_group(self.bot, GA)
        self.assertGreaterEqual(second.sent, 1)

    async def test_invalid_group_ids_are_refused(self):
        with self.assertRaises(InvalidInput):
            await self.delivery.deliver_group(self.bot, "x")


class LeaseKeyTests(unittest.TestCase):
    def test_same_report_same_window_same_key_next_window_new_key(self):
        a = lease_key(GA, DAY, "2026-10-27", utc(2026, 10, 28, 12, 0))
        self.assertEqual(a, lease_key(GA, DAY, "2026-10-27", utc(2026, 10, 28, 12, 5)))
        self.assertNotEqual(a, lease_key(GA, DAY, "2026-10-27", utc(2026, 10, 28, 12, 20)))
        self.assertNotEqual(a, lease_key(GB, DAY, "2026-10-27", utc(2026, 10, 28, 12, 0)))
        self.assertNotEqual(a, lease_key(GA, DAY, "2026-10-26", utc(2026, 10, 28, 12, 0)))


class HookTests(Base):
    async def test_an_inactive_licence_starts_nothing(self):
        await self.enable()
        self.assertFalse(self.delivery.on_update(self.bot, GA, False))
        await self.delivery.drain()
        self.assertEqual(self.bot.sent, [])
        self.assertIsNone((await self.schedule.entries(GA))[DAY].last_period_key)   # still owed

    async def test_private_chats_missing_bot_and_bad_ids_are_ignored(self):
        await self.enable()
        for bot, chat in ((self.bot, 555), (None, GA), (self.bot, None), (self.bot, True), (self.bot, "x")):
            self.assertFalse(self.delivery.on_update(bot, chat, True))

    async def test_the_first_update_after_a_sleep_catches_up_in_the_background(self):
        await self.enable()
        self.assertTrue(self.delivery.on_update(self.bot, GA, True))
        await self.delivery.drain()
        self.assertEqual(len(self.bot.sent), 3)

    async def test_a_group_is_looked_at_once_per_interval(self):
        self.assertTrue(self.delivery.on_update(self.bot, GA, True))
        await self.delivery.drain()
        self.assertFalse(self.delivery.on_update(self.bot, GA, True))
        self.mono[0] += pd.CHECK_INTERVAL + 1
        self.assertTrue(self.delivery.on_update(self.bot, GA, True))
        await self.delivery.drain()

    async def test_a_failure_backs_off_longer_and_never_raises(self):
        await self.enable()
        self.bot.fail_next = 99
        self.assertTrue(self.delivery.on_update(self.bot, GA, True))
        await self.delivery.drain()
        self.mono[0] += pd.CHECK_INTERVAL + 1
        self.assertFalse(self.delivery.on_update(self.bot, GA, True))   # back-off is longer than the normal interval
        self.mono[0] += pd.MAX_BACKOFF
        self.assertTrue(self.delivery.on_update(self.bot, GA, True))
        await self.delivery.drain()

    async def test_a_store_error_in_the_background_is_swallowed_and_backs_off(self):
        await self.enable()

        async def broken(*a, **k):
            raise RuntimeError("db down")

        self.schedule.owed_all = broken
        self.assertTrue(self.delivery.on_update(self.bot, GA, True))
        await self.delivery.drain()                                      # must not raise
        self.mono[0] += pd.CHECK_INTERVAL + 1
        self.assertFalse(self.delivery.on_update(self.bot, GA, True))

    async def test_the_update_is_never_delayed_by_the_report(self):
        await self.enable()
        gate = asyncio.Event()
        real = self.bot.send_message

        async def slow(chat_id, text):
            await gate.wait()
            await real(chat_id, text)

        self.bot.send_message = slow
        self.assertTrue(self.delivery.on_update(self.bot, GA, True))     # returns at once; the send is still waiting
        self.assertEqual(self.bot.sent, [])
        gate.set()
        await self.delivery.drain()
        self.assertEqual(len(self.bot.sent), 3)

    async def test_aclose_cancels_runs_in_flight_and_leaves_them_owed(self):
        await self.enable()
        gate = asyncio.Event()

        async def stuck(chat_id, text):
            await gate.wait()

        self.bot.send_message = stuck
        self.delivery.on_update(self.bot, GA, True)
        await asyncio.sleep(0)
        await self.delivery.aclose()
        self.assertIsNone((await self.schedule.entries(GA))[DAY].last_period_key)


class MiddlewareTests(unittest.IsolatedAsyncioTestCase):
    class Gate:
        def __init__(self, allowed):
            self.allowed = allowed

        async def evaluate(self, chat_id, chat_type, sender_id, title=None, anonymous_sender=False):
            return ProtectionContext(chat_id, chat_type, self.allowed, "none" if self.allowed else "inactive", sender_id,
                                     True)

    class Event:
        class chat:
            id = GA
            type = "supergroup"
            title = "g"

        class from_user:
            id = 42

        bot = object()

    async def test_the_hook_gets_the_bot_the_chat_and_the_gates_verdict(self):
        seen = []

        async def handler(event, data):
            return "handled"

        for allowed in (True, False):
            mw = ProtectionGateMiddleware(self.Gate(allowed), group_tick=lambda e, c: seen.append((e.bot, c.chat_id, c.allowed)))
            self.assertEqual(await mw(handler, self.Event(), {}), "handled")
        self.assertEqual([x[1:] for x in seen], [(GA, True), (GA, False)])

    async def test_a_failing_hook_never_blocks_the_update(self):
        async def handler(event, data):
            return "handled"

        def boom(e, c):
            raise RuntimeError("x")

        mw = ProtectionGateMiddleware(self.Gate(True), group_tick=boom)
        self.assertEqual(await mw(handler, self.Event(), {}), "handled")


class StaticGuardTests(unittest.TestCase):
    SRC = (ROOT / "src" / "guardian" / "stats" / "periodic_delivery.py").read_text(encoding="utf-8")

    def test_no_framework_imports_and_no_group_listing(self):
        self.assertIsNone(re.search(r"^\s*(import|from)\s+(aiogram|asyncpg|fastapi)", self.SRC, re.M))
        self.assertNotIn("list_all", self.SRC)

    def test_mark_done_only_after_the_send(self):
        body = self.SRC[self.SRC.index("async def deliver_group"):self.SRC.index("async def _build")]
        self.assertLess(body.index("send_message"), body.index("_finish(group_id, period, cal, at, resend=True)"))
        self.assertNotIn("mark_done", body)   # only `_finish` marks, and only on the resend=True path after a send

    def test_the_wiring_is_in_place(self):
        factory = (ROOT / "src" / "guardian" / "bot" / "factory.py").read_text(encoding="utf-8")
        app = (ROOT / "src" / "guardian" / "app.py").read_text(encoding="utf-8")
        self.assertIn("group_tick=group_tick", factory)
        self.assertIn("ctx.allowed", factory)
        self.assertIn("periodic_delivery=periodic_delivery", app)
        self.assertIn("periodic_delivery.aclose()", app)

    def test_no_new_migration(self):
        from guardian.db.migrations import discover
        self.assertEqual([v for v, _ in discover()][8:], ["0009_daily_counters", "0010_report_schedule", "0011_content_filter", "0012_content_default_words", "0013_member_activity_stats"])

    def test_the_report_text_exists_in_both_languages(self):
        for lang in ("ar", "en"):
            for key in ("periodic_title_day", "periodic_title_week", "periodic_title_month", "periodic_note"):
                self.assertTrue(t(key, lang))
            self.assertIn("5", t("periodic_skipped", lang, n=5))


if __name__ == "__main__":
    unittest.main()
