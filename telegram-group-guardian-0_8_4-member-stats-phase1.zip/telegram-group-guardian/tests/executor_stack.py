"""Shared fixture for moderation-command (part 5) tests: Stack + fake Telegram member actions."""
from __future__ import annotations

import unittest

from guardian.idempotency import InMemoryIdempotency
from guardian.moderation.commands import parse_command
from guardian.moderation.executor import ModerationCommandService
from guardian.moderation.lock_commands import PermissionChange
from guardian.moderation.targets import ReplyInfo
from guardian.protection.engine import ActionResult
from guardian.protection_gate import ProtectionContext
from guardian.telegram_rights import ChatMemberInfo
from stack import A, B, NOW, OWNER, TG_ADMIN, Stack

BOT, USER, OTHER = 777, 5001, 5002
BOT_NAME = "GuardianBot"


class FakeActions:
    """Records calls; `fail[method] = 'forbidden'|'rate_limited'|...` makes that method fail."""

    def __init__(self):
        self.calls: list[tuple] = []
        self.fail: dict[str, str] = {}
        self.perm_change = PermissionChange(True, None, True)  # what set_default_permissions reports

    async def set_default_permissions(self, chat_id, flags, allowed):
        self.calls.append(("set_perms", chat_id, tuple(flags), allowed))
        err = self.fail.get("set_perms")
        return PermissionChange(False, err) if err else self.perm_change

    async def _do(self, name, *args):
        self.calls.append((name, *args))
        err = self.fail.get(name)
        return ActionResult(err is None, err)

    async def ban_member(self, chat_id, user_id, until):
        return await self._do("ban", chat_id, user_id, until)

    async def unban_member(self, chat_id, user_id):
        return await self._do("unban", chat_id, user_id)

    async def mute_member(self, chat_id, user_id, until):
        return await self._do("mute", chat_id, user_id, until)

    async def unmute_member(self, chat_id, user_id):
        return await self._do("unmute", chat_id, user_id)

    async def kick_member(self, chat_id, user_id):
        return await self._do("kick", chat_id, user_id)

    async def pin_message(self, chat_id, message_id, silent=False):
        return await self._do("pin", chat_id, message_id, silent)

    async def unpin_message(self, chat_id, message_id=None):
        return await self._do("unpin", chat_id, message_id)

    async def delete_messages(self, chat_id, message_ids):
        return await self._do("delete_messages", chat_id, list(message_ids))

    def names(self):
        return [c[0] for c in self.calls]


class BrokenClaims:
    async def claim(self, key, now=None):
        raise RuntimeError("claim store down")

    async def purge_older_than(self, cutoff):
        return 0


def gate(chat_id=A, actor=TG_ADMIN, allowed=True):
    return ProtectionContext(chat_id, "supergroup", allowed, "none" if allowed else "pending", actor, False)


class ExecBase(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A, B)
        self.s.chat.set(A, BOT, ChatMemberInfo("administrator", True, True, True))
        self.s.chat.set(B, BOT, ChatMemberInfo("administrator", True, True, True))
        self.actions = FakeActions()
        self.claims = InMemoryIdempotency()
        self.svc = self.make_service(self.claims)

    def make_service(self, claims):
        return ModerationCommandService(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions,
            settings_store=self.s.settings_store, actions=self.actions, chat_info=self.s.chat, claims=claims,
            audit=self.s.audit, bot_id=BOT, clock=self.s.clock,
            group_settings=self.s.settings)

    async def settings(self, group=A, **patch):
        await self.s.settings_store.merge(group, patch, OWNER, NOW)

    def member(self, uid, status="member", group=A):
        self.s.chat.set(group, uid, ChatMemberInfo(status))

    async def run_cmd(self, text, *, actor=TG_ADMIN, chat=A, msg=1, reply_to=None, protection="default", mention=None):
        parsed = parse_command(text, BOT_NAME, has_reply=reply_to is not None)
        assert parsed is not None, text
        prot = gate(chat, actor) if protection == "default" else protection
        reply = ReplyInfo(reply_to) if reply_to is not None else None
        return await self.svc.handle(parsed, chat_id=chat, actor_id=actor, message_id=msg, protection=prot,
                                     reply=reply, mention_user_id=mention)

    def audit_types(self, group=A):
        return [e.event_type for e in self.s.audit.events if e.group_id == group]
