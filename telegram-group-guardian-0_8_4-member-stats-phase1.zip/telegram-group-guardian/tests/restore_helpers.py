"""Test doubles for the restore (6.9b): an in-memory writer with the contract of `restore.RestoreWriter` (rollback included) and a
fake asyncpg connection that records the SQL `PostgresRestoreWriter` sends. Neither is a real PostgreSQL."""
from __future__ import annotations

import copy
import re
from contextlib import asynccontextmanager
from datetime import datetime, timezone

from guardian.backup import format as F
from guardian.backup import postgres_restore as PR
from guardian.backup import postgres_state as PS
from guardian.backup.preview import (COUNTED_PER_GROUP, GLOBAL_REPLACED, CurrentGroup, CurrentState)
from guardian.backup.restore import ID_TABLES, RestoreError

LOG_KEY = ("group_id", "occurred_at", "action", "new_status", "previous_status", "actor_telegram_id", "expires_at", "reason")


class MemDB:
    """Tables hold the file's ENCODED rows. `transaction()` commits on success and restores the snapshot on any exception."""

    def __init__(self, tables: dict[str, list[dict]], *, seq_extra: int = 0) -> None:
        self.t = {name: [dict(r) for r in tables.get(name, [])] for name in F.TABLE_NAMES}
        self.seq = {name: max([r["id"] for r in self.t[name]] + [0]) + seq_extra for name in (*ID_TABLES, "license_audit_log")}
        self.fail_at: tuple[str, str] | None = None       # (operation, table): raise a constraint failure there
        self.drop_one_on_insert: str | None = None        # simulate a writer bug: silently lose a row on this table
        self.ops: list[tuple] = []
        self.committed = self.rolled_back = 0

    def snapshot(self):
        return copy.deepcopy((self.t, self.seq))

    def transaction(self):
        return self._tx()

    @asynccontextmanager
    async def _tx(self):
        saved = self.snapshot()
        try:
            yield MemTx(self)
        except BaseException:
            self.t, self.seq = saved
            self.rolled_back += 1
            raise
        self.committed += 1


def mem_state(db: "MemDB") -> CurrentState:
    """The current state of a MemDB (synchronous: usable from sync and async tests alike)."""
    t = db.t
    groups = {r["group_id"]: CurrentGroup(r["license_status"], r["expires_at"]) for r in t["telegram_groups"]}
    counts: dict[str, dict[int, int]] = {}
    for table in COUNTED_PER_GROUP:
        per: dict[int, int] = {}
        for r in t[table]:
            per[r["group_id"]] = per.get(r["group_id"], 0) + 1
        counts[table] = per
    g = {table: len(t[table]) for table in GLOBAL_REPLACED}
    versions = [r["version"] for r in t["global_default_settings"]]
    return CurrentState(groups, counts, g, max(versions) if versions else None)


class MemTx:
    def __init__(self, db: MemDB) -> None:
        self.db = db

    def _fail(self, op: str, table: str) -> None:
        self.db.ops.append((op, table))
        if self.db.fail_at == (op, table):
            raise RestoreError("constraint_failed")

    async def lock(self) -> None:
        self.db.ops.append(("lock", ""))

    async def read_state(self) -> CurrentState:
        return mem_state(self.db)

    async def id_conflicts(self, table, ids, group_ids) -> bool:
        self.db.ops.append(("id_conflicts", table))
        return any(r["id"] in set(ids) and r["group_id"] not in set(group_ids) for r in self.db.t[table])

    async def sanction_key_conflicts(self, keys, group_ids) -> bool:
        self.db.ops.append(("key_conflicts", "moderation_sanctions"))
        return any(r["idempotency_key"] in set(keys) and r["group_id"] not in set(group_ids) for r in self.db.t["moderation_sanctions"])

    async def create_groups(self, rows) -> int:
        self._fail("create_groups", "telegram_groups")
        known = {r["group_id"] for r in self.db.t["telegram_groups"]}
        for r in rows:
            if r["group_id"] in known:
                raise RestoreError("constraint_failed")
            self.db.t["telegram_groups"].append(dict(r))
        return len(rows)

    async def update_license(self, rows) -> int:
        self._fail("update_license", "telegram_groups")
        n = 0
        for new in rows:
            for r in self.db.t["telegram_groups"]:
                if r["group_id"] == new["group_id"]:
                    r.update({c: new[c] for c in PR_LICENSE})
                    n += 1
        return n

    async def delete_for_groups(self, table, group_ids) -> int:
        self._fail("delete_for_groups", table)
        keep = [r for r in self.db.t[table] if r["group_id"] not in set(group_ids)]
        n = len(self.db.t[table]) - len(keep)
        self.db.t[table] = keep
        return n

    async def delete_all(self, table) -> int:
        self._fail("delete_all", table)
        n = len(self.db.t[table])
        self.db.t[table] = []
        return n

    async def insert_rows(self, table, rows) -> int:
        self._fail("insert_rows", table)
        spec = F.BY_NAME[table]
        existing = {tuple(r[k] for k in spec.key) for r in self.db.t[table]}
        for r in rows:
            key = tuple(r[k] for k in spec.key)
            if key in existing:
                raise RestoreError("constraint_failed")
            existing.add(key)
        stored = list(rows)
        if self.db.drop_one_on_insert == table and stored:
            stored = stored[:-1]
        self.db.t[table].extend(dict(r) for r in stored)
        return len(rows)

    async def append_license_log(self, rows, *, skip_existing) -> int:
        self._fail("append_license_log", "license_audit_log")
        have = {tuple(r[k] for k in LOG_KEY) for r in self.db.t["license_audit_log"]}
        n = 0
        for r in rows:
            key = tuple(r[k] for k in LOG_KEY)
            if skip_existing and key in have:
                continue
            self.db.seq["license_audit_log"] += 1
            self.db.t["license_audit_log"].append({**{c: r[c] for c in LOG_KEY}, "id": self.db.seq["license_audit_log"]})
            have.add(key)
            n += 1
        return n

    async def reset_sequences(self, tables) -> None:
        self.db.ops.append(("reset_sequences", ",".join(tables)))
        for table in tables:
            top = max([r["id"] for r in self.db.t[table]] + [0])
            self.db.seq[table] = max(self.db.seq[table], top)      # never backwards


PR_LICENSE = ("license_status", "activated_at", "expires_at", "activated_by", "status_note")


# ------------------------------------------------------------------------------------------------ a fake asyncpg connection
class FakeTransaction:
    def __init__(self, conn, kwargs):
        self.conn, self.kwargs = conn, kwargs

    async def __aenter__(self):
        self.conn.events.append(("begin", tuple(sorted(self.kwargs.items()))))
        return self

    async def __aexit__(self, exc_type, exc, tb):
        self.conn.events.append(("rollback" if exc_type else "commit", ""))
        return False


class UniqueViolationError(Exception):
    pass


class LockNotAvailableError(Exception):
    pass


class FakeConn:
    """Counts rows per table and group so `read_state_on` sees the effect of the statements; records every statement."""

    def __init__(self, *, groups=None, counts=None, global_counts=None, version=2, id_conflict=False, key_conflict=False):
        self.groups = dict(groups or {})                     # gid -> (status, expires datetime | None)
        self.counts = {t: dict((counts or {}).get(t, {})) for t in COUNTED_PER_GROUP}
        self.globals = {t: (global_counts or {}).get(t, 0) for t in GLOBAL_REPLACED}
        self.version = version
        self.id_conflict, self.key_conflict = id_conflict, key_conflict
        self.sql: list[tuple[str, tuple]] = []
        self.events: list[tuple] = []
        self.fail_on: tuple[str, BaseException] | None = None
        self.setvals: list[tuple] = []

    def transaction(self, **kwargs):
        return FakeTransaction(self, kwargs)

    def _maybe_fail(self, sql):
        if self.fail_on and self.fail_on[0] in sql:
            raise self.fail_on[1]

    async def execute(self, sql, *args):
        self.sql.append((sql, args))
        self._maybe_fail(sql)
        m = re.match(r"DELETE FROM (\w+) WHERE group_id = ANY", sql)
        if m:
            table, n = m.group(1), 0
            for g in args[0]:
                n += self.counts[table].pop(g, 0)
            return f"DELETE {n}"
        m = re.match(r"DELETE FROM (\w+)$", sql)
        if m:
            n, self.globals[m.group(1)] = self.globals[m.group(1)], 0
            return f"DELETE {n}"
        if sql.startswith("UPDATE telegram_groups"):
            gid, status, _a, expires = args[0], args[1], args[2], args[3]
            self.groups[gid] = (status, expires)
            return "UPDATE 1"
        if sql.startswith("INSERT INTO license_audit_log"):
            exists = "NOT EXISTS" in sql and getattr(self, "log_exists", False)
            if not exists:
                self.counts["license_audit_log"][args[0]] = self.counts["license_audit_log"].get(args[0], 0) + 1
            return "INSERT 0 0" if exists else "INSERT 0 1"
        return "OK"

    async def executemany(self, sql, argslist):
        self.sql.append((sql, tuple(argslist)))
        self._maybe_fail(sql)
        table = re.match(r"INSERT INTO (\w+)", sql).group(1)
        names = [c.name for c in F.BY_NAME[table].columns]
        for args in argslist:
            if table == "telegram_groups":
                self.groups[args[0]] = (args[2], args[4])
            elif table in self.globals:
                self.globals[table] += 1
            else:
                gid = args[names.index("group_id")]
                self.counts[table][gid] = self.counts[table].get(gid, 0) + 1

    async def fetch(self, sql, *args):
        self.sql.append((sql, args))
        if sql == PS.GROUPS_SQL:
            return [{"group_id": g, "license_status": s, "expires_at": e} for g, (s, e) in sorted(self.groups.items())]
        for t in COUNTED_PER_GROUP:
            if sql == PS.count_sql(t):
                return [{"group_id": g, "n": n} for g, n in self.counts[t].items()]
        for t in GLOBAL_REPLACED:
            if sql == PS.global_count_sql(t):
                return [{"n": self.globals[t]}]
        if sql == PS.DEFAULTS_VERSION_SQL:
            return [{"v": self.version}]
        if sql.startswith("SELECT last_value, is_called FROM"):
            return [{"last_value": 10, "is_called": True}]
        raise AssertionError(f"unexpected fetch: {sql}")

    async def fetchval(self, sql, *args):
        self.sql.append((sql, args))
        self._maybe_fail(sql)
        if sql.startswith("SELECT pg_advisory_xact_lock"):
            return None
        if sql.startswith("SELECT pg_get_serial_sequence"):
            return f"public.{args[0]}_id_seq"
        if "FROM moderation_sanctions WHERE idempotency_key" in sql:
            return 1 if self.key_conflict else 0
        if sql.startswith("SELECT count(*) FROM"):
            return 1 if self.id_conflict else 0
        if sql.startswith("SELECT COALESCE(max(id)"):
            return 7
        if sql.startswith("SELECT setval"):
            self.setvals.append(args)
            return args[1]
        raise AssertionError(f"unexpected fetchval: {sql}")


class FakeDatabase:
    def __init__(self, conn: FakeConn) -> None:
        self.conn = conn

    @asynccontextmanager
    async def acquire(self):
        yield self.conn


def utc(y, m, d, h=0, mi=0, s=0):
    return datetime(y, m, d, h, mi, s, tzinfo=timezone.utc)
