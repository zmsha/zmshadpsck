import unittest

from guardian.auth import Authority, Role


class AuthorityTests(unittest.TestCase):
    def setUp(self):
        self.auth = Authority(100, 200)

    def test_roles(self):
        self.assertIs(self.auth.role_of(100), Role.OWNER)
        self.assertIs(self.auth.role_of(200), Role.BACKUP_OWNER)
        self.assertIs(self.auth.role_of(300), Role.USER)

    def test_only_primary_owner_changes_license(self):
        self.assertTrue(self.auth.can_change_license(100))
        self.assertFalse(self.auth.can_change_license(200))  # backup owner: no license rights
        self.assertFalse(self.auth.can_change_license(300))

    def test_forged_or_odd_identities_rejected(self):
        for bad in ("100", None, True, 100.0, -100, 0, b"100"):
            with self.subTest(bad=bad):
                self.assertFalse(self.auth.is_owner(bad))
                self.assertFalse(self.auth.can_change_license(bad))

    def test_invalid_construction(self):
        with self.assertRaises(ValueError):
            Authority(0)
        with self.assertRaises(ValueError):
            Authority(1, -1)

    def test_no_backup_configured(self):
        self.assertIs(Authority(100).role_of(200), Role.USER)


if __name__ == "__main__":
    unittest.main()
