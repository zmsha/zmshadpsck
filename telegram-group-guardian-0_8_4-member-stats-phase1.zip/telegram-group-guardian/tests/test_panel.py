"""Phase 4 / part 4.7a: the Inline admin panel skeleton -- signed callback data, the server-side press handler (every
press re-checks owner binding, MODERATE and the live license), `/panel`, and the framework-independent glue.
The aiogram router itself (`bot/routers/panel.py`) is not exercised (aiogram is not installable in the build sandbox)."""
from __future__ import annotations

import unittest
from datetime import timedelta
from types import SimpleNamespace as NS

from executor_stack import BOT, USER, gate
from guardian.audit import FORGED_CALLBACK
from guardian.bot import moderation_handler as mh
from guardian.bot import panel_handler as ph
from guardian.groups.models import GroupRole
from guardian.moderation.commands import Command, parse_command
from guardian.moderation.executor import ModerationCommandService, ResultKind as R
from guardian.moderation.provider import LazyModerationCommands
from guardian.panel import codec
from guardian.panel.service import PanelService
from guardian.telegram_rights import ChatMemberInfo
from stack import A, B, DELEGATE, OWNER, STRANGER, TG_ADMIN
from test_moderation_integration import FakeBot, Msg
from test_phase3_final_handoff import BLOCKED_STATES, Pipeline

SECRET = "unit-test-secret-0123456789"
KEY = codec.derive_key(SECRET)


# ----------------------------------------------------------------------------- codec
class CodecTests(unittest.TestCase):
    def test_round_trip_and_verification(self):
        data = codec.build(KEY, A, TG_ADMIN, codec.SCREEN_HOME)
        cb = codec.parse(data)
        self.assertEqual((cb.owner_id, cb.screen), (TG_ADMIN, "home"))
        self.assertTrue(codec.verify(KEY, A, cb))

    def test_the_group_is_part_of_the_signature(self):
        cb = codec.parse(codec.build(KEY, A, TG_ADMIN, codec.SCREEN_HOME))
        self.assertFalse(codec.verify(KEY, B, cb))          # a panel shown in another group is dead there
        self.assertFalse(codec.verify(KEY, 5, cb))          # non-group ids never verify
        self.assertFalse(codec.verify(KEY, True, cb))

    def test_changed_owner_screen_or_tag_fails(self):
        data = codec.build(KEY, A, TG_ADMIN, codec.SCREEN_HOME)
        _, owner, screen, tag = data.split(":")
        for forged in (f"pn:{STRANGER}:{screen}:{tag}", f"pn:{owner}:close:{tag}", f"pn:{owner}:{screen}:{'0' * 12}"):
            cb = codec.parse(forged)
            self.assertIsNotNone(cb, forged)
            self.assertFalse(codec.verify(KEY, A, cb), forged)

    def test_another_secret_gives_another_tag(self):
        other = codec.derive_key("a-different-secret-value-xyz")
        self.assertNotEqual(codec.build(KEY, A, TG_ADMIN, "home"), codec.build(other, A, TG_ADMIN, "home"))
        cb = codec.parse(codec.build(other, A, TG_ADMIN, "home"))
        self.assertFalse(codec.verify(KEY, A, cb))

    def test_empty_secret_is_refused(self):
        for bad in ("", b""):
            with self.assertRaises(ValueError):
                codec.derive_key(bad)

    def test_parse_is_a_strict_whitelist(self):
        good = codec.build(KEY, A, TG_ADMIN, "home")
        _, owner, screen, tag = good.split(":")
        bad = [
            None, 5, b"pn:1:home:" + b"a" * 12, "", "pn", good + "\n", " " + good, good + ":x", good.upper(),
            f"pn:{owner}:{screen}:{tag.upper()}", f"pn:{owner}:{screen}:{tag[:-1]}", f"pn:{owner}:{screen}:{tag}0",
            f"pn:0:{screen}:{tag}", f"pn:-5:{screen}:{tag}", f"pn:0{owner}:{screen}:{tag}",
            f"pn:{2**63}:{screen}:{tag}", f"pn:{'9' * 30}:{screen}:{tag}",
            f"pn:{owner}:unknown:{tag}", f"pn:{owner}:HOME:{tag}", f"pn:{owner}::{tag}",
            f"pn:١٢٣:{screen}:{tag}",                       # Arabic-Indic digits are not ASCII digits
            f"lic:{owner}:{screen}:{tag}", f"pn:{owner}:{screen}", "x" * 200,
        ]
        for data in bad:
            self.assertIsNone(codec.parse(data), repr(data))

    def test_build_refuses_bad_input(self):
        for args in ((A, TG_ADMIN, "nope"), (5, TG_ADMIN, "home"), (0, TG_ADMIN, "home"), (True, TG_ADMIN, "home"),
                     (A, 0, "home"), (A, -1, "home"), (A, True, "home"), (A, 10**18, "home"), (A, "5", "home")):
            with self.assertRaises(ValueError, msg=str(args)):
                codec.build(KEY, *args)

    def test_longest_data_fits_telegrams_limit(self):
        for screen in codec.SCREENS:
            data = codec.build(KEY, -(2**63), 10**18 - 1, screen)
            self.assertLessEqual(len(data.encode()), 64, screen)
            self.assertIsNotNone(codec.parse(data))


# ----------------------------------------------------------------------------- service
class PanelBase(Pipeline):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.panel = PanelService(permissions=self.s.perm, licenses=self.s.license_service, commands=self.svc,
                                  audit=self.s.audit, secret=SECRET, clock=self.s.clock, ttl_seconds=None)
        self.g = await self.active_group()

    async def active_group(self):
        g = await self.group_in("stopped")
        await self.owner_recovers(g, "stopped")
        return g

    def data(self, group, owner, screen=codec.SCREEN_HOME):
        return codec.build(KEY, group, owner, screen)

    async def press(self, owner=TG_ADMIN, presser=None, group=None, screen=codec.SCREEN_HOME, ctype="supergroup", data=None):
        group = self.g if group is None else group
        data = self.data(group, owner, screen) if data is None else data
        return await self.panel.press(group, ctype, owner if presser is None else presser, data, "ar")

    def forged(self, group=None):
        group = self.g if group is None else group
        return [e for e in self.s.audit.events if e.event_type == FORGED_CALLBACK and e.group_id == group]


class PressTests(PanelBase):
    async def test_home_refreshes_in_place_with_a_new_bound_keyboard(self):
        out = await self.press()
        self.assertEqual(out.status, "home")
        self.assertFalse(out.alert)
        self.assertIn("إعدادات", out.text)
        rows = out.buttons                                  # 4.7b/c: topic buttons (5 screens) + the refresh/close row
        self.assertEqual([len(r) for r in rows], [2, 2, 1, 2])
        for row in rows:
            for _, data in row:
                cb = codec.parse(data)
                self.assertEqual(cb.owner_id, TG_ADMIN)
                self.assertTrue(codec.verify(KEY, self.g, cb))
        self.assertEqual([codec.parse(d).screen for _, d in rows[3]], ["home", "close"])

    async def test_home_is_the_same_text_as_the_settings_command(self):
        parsed = parse_command("/settings", "GuardianBot")
        cmd = await self.svc.handle(parsed, chat_id=self.g, actor_id=TG_ADMIN, message_id=1, protection=gate(self.g))
        self.assertEqual((await self.press()).text, cmd.text)

    async def test_a_press_writes_nothing_claims_nothing_audits_nothing(self):
        claims, events = dict(self.claims._keys), len(self.s.audit.events)
        await self.press()
        await self.press(screen=codec.SCREEN_CLOSE)
        self.assertEqual(self.claims._keys, claims)
        self.assertEqual(len(self.s.audit.events), events)
        self.assertIsNone(await self.s.settings_store.get(self.g))
        self.assertEqual(self.actions.calls, [])

    async def test_close_deletes_the_panel(self):
        out = await self.press(screen=codec.SCREEN_CLOSE)
        self.assertEqual((out.status, out.delete, out.text), ("closed", True, None))

    async def test_the_owner_of_the_bot_can_use_a_panel_too(self):
        self.assertEqual((await self.press(owner=OWNER)).status, "home")

    async def test_a_moderator_delegate_can_read(self):
        await self.s.delegations.grant(OWNER, self.g, DELEGATE, GroupRole.MODERATOR)
        self.assertEqual((await self.press(owner=DELEGATE)).status, "home")

    async def test_another_admin_cannot_use_my_panel(self):
        other = 900_099
        self.s.chat.set(self.g, other, ChatMemberInfo("administrator", True, True, True))
        out = await self.press(owner=TG_ADMIN, presser=other)
        self.assertEqual((out.status, out.alert, out.text, out.delete), ("not_owner", True, None, False))
        self.assertEqual(self.forged(), [])                 # legitimate behaviour, not an attack

    async def test_crafting_my_own_owner_id_onto_someone_elses_panel_fails_the_signature(self):
        _, _, screen, tag = self.data(self.g, TG_ADMIN).split(":")
        out = await self.press(presser=STRANGER, data=f"pn:{STRANGER}:{screen}:{tag}")
        self.assertEqual((out.status, out.text, out.delete), ("forged", None, False))
        self.assertEqual([e.actor_telegram_id for e in self.forged()], [STRANGER])

    async def test_a_plain_member_cannot_use_a_panel_even_with_a_valid_signature(self):
        out = await self.press(owner=STRANGER)
        self.assertEqual((out.status, out.alert, out.text), ("not_admin", True, None))

    async def test_a_refused_press_is_not_audited_as_a_denial(self):
        events = len(self.s.audit.events)
        for owner in (STRANGER, 900_098):
            await self.press(owner=owner)                    # plain members: refused, but only forgeries are audited
        self.assertEqual(len(self.s.audit.events), events)

    async def test_a_demoted_admin_loses_the_panel_on_the_next_press(self):
        self.assertEqual((await self.press()).status, "home")
        self.s.chat.set(self.g, TG_ADMIN, ChatMemberInfo("member"))
        out = await self.press()
        self.assertEqual((out.status, out.text, out.delete), ("not_admin", None, False))
        out = await self.press(screen=codec.SCREEN_CLOSE)
        self.assertEqual((out.status, out.delete), ("not_admin", False))

    async def test_permission_lookup_failure_fails_closed(self):
        async def boom(*a, **k):
            raise RuntimeError("telegram down")
        real, self.panel._perm = self.panel._perm, NS(check=boom)
        out = await self.press()
        self.panel._perm = real
        self.assertEqual((out.status, out.alert, out.text), ("unavailable", True, None))

    async def test_a_group_panel_is_dead_in_another_group(self):
        other = await self.active_group()
        out = await self.panel.press(other, "supergroup", TG_ADMIN, self.data(self.g, TG_ADMIN), "ar")
        self.assertEqual((out.status, out.text), ("forged", None))
        self.assertEqual(len(self.forged(other)), 1)

    async def test_context_must_be_a_group_and_a_real_person(self):
        data = self.data(self.g, TG_ADMIN)
        for args in ((self.g, "private", TG_ADMIN), (self.g, "channel", TG_ADMIN), (self.g, "", TG_ADMIN),
                     (None, "supergroup", TG_ADMIN), (5, "supergroup", TG_ADMIN), (True, "supergroup", TG_ADMIN),
                     (self.g, "supergroup", None), (self.g, "supergroup", 0), (self.g, "supergroup", -7),
                     (self.g, "supergroup", True), (self.g, "supergroup", "900003")):
            self.assertIsNone(await self.panel.press(*args, data, "ar"), args)
        self.assertEqual(self.forged(), [])

    async def test_foreign_or_malformed_data_is_ignored_and_malformed_pn_is_audited(self):
        for data in (None, 7, "", "vf:1:2", "lic:ap:-5", "hello"):
            self.assertIsNone(await self.panel.press(self.g, "supergroup", TG_ADMIN, data, "ar"), data)
        self.assertEqual(self.forged(), [])
        self.assertIsNone(await self.panel.press(self.g, "supergroup", TG_ADMIN, "pn:abc", "ar"))
        self.assertEqual(len(self.forged()), 1)

    async def test_every_blocked_license_state_refuses_every_screen(self):
        for state in BLOCKED_STATES:
            with self.subTest(state=state):
                g = await self.group_in(state)
                real = self.break_store() if state == "store_down" else self.s.licenses.get
                try:
                    for presser in (TG_ADMIN, OWNER):
                        if state == "store_down" and presser == OWNER:
                            continue
                        for screen in codec.SCREENS:
                            out = await self.press(owner=presser, group=g, screen=screen)
                            self.assertIn(out.status, ("license_off", "unavailable"), (state, screen))
                            self.assertTrue(out.alert)
                            self.assertEqual((out.text, out.delete), (None, False))
                finally:
                    self.s.licenses.get = real
                self.assertIsNone(await self.s.settings_store.get(g))
                self.assertEqual(self.actions.calls, [])

    async def test_the_owner_recovering_a_state_revives_the_same_panel(self):
        g = await self.group_in("banned")
        self.assertEqual((await self.press(group=g)).status, "license_off")
        await self.owner_recovers(g, "banned")
        self.assertEqual((await self.press(group=g)).status, "home")

    async def test_an_expiring_license_stops_the_panel_at_the_moment_it_expires(self):
        g = await self.group_in("pending")
        await self.s.admin.activate_temporary(OWNER, g, self.s.clock() + timedelta(hours=1))
        self.assertEqual((await self.press(group=g)).status, "home")
        self.s.clock.advance(hours=2)                        # the host slept past expires_at
        self.assertEqual((await self.press(group=g)).status, "license_off")

    async def test_dry_run_does_not_stop_a_read_only_panel(self):
        await self.s.settings_store.merge(self.g, {"dry_run": True}, OWNER, self.s.clock())
        self.assertEqual((await self.press()).status, "home")

    async def test_an_unreadable_overview_never_shows_a_panel(self):
        async def boom(*a, **k):
            raise RuntimeError("settings store down")
        real = self.s.settings_store.get
        self.s.settings_store.get = boom
        out = await self.press()
        self.s.settings_store.get = real
        self.assertEqual((out.status, out.alert, out.text, out.buttons), ("unavailable", True, None, None))

    async def test_a_commands_service_that_raises_fails_closed(self):
        async def boom(*a, **k):
            raise RuntimeError("no bot id")
        real, self.panel._commands = self.panel._commands, NS(overview=boom)
        out = await self.press()
        self.panel._commands = real
        self.assertEqual((out.status, out.text), ("unavailable", None))

    async def test_english_toasts(self):
        out = await self.panel.press(self.g, "supergroup", STRANGER, self.data(self.g, STRANGER), "en")
        self.assertEqual(out.status, "not_admin")
        self.assertIn("not allowed", out.toast)


# ----------------------------------------------------------------------------- /panel command
class PanelCommandTests(PanelBase):
    async def run_cmd(self, text, sender=TG_ADMIN, group=None, **kw):
        group = self.g if group is None else group
        parsed = parse_command(text, "GuardianBot")
        prot = await self.gate.evaluate(group, "supergroup", sender)  # the REAL gate decides the license, as in production
        return await self.svc.handle(parsed, chat_id=group, actor_id=sender, message_id=1, protection=prot, **kw)

    async def test_an_admin_gets_the_overview_flagged_for_a_keyboard(self):
        r = await self.run_cmd("/panel")
        self.assertEqual((r.kind, r.panel, r.command), (R.INFO, True, Command.PANEL))
        self.assertEqual(r.text, (await self.run_cmd("/settings")).text)

    async def test_a_plain_member_is_denied_and_gets_no_keyboard(self):
        r = await self.run_cmd("/panel", sender=STRANGER)
        self.assertEqual((r.kind, r.panel), (R.DENIED, False))

    async def test_a_group_without_a_license_gets_nothing(self):
        g = await self.group_in("pending")
        r = await self.run_cmd("/panel", group=g)
        self.assertEqual((r.kind, r.panel), (R.LICENSE_OFF, False))

    async def test_a_broken_settings_store_gives_a_safe_error_without_keyboard(self):
        async def boom(*a, **k):
            raise RuntimeError("down")
        real, self.s.settings_store.get = self.s.settings_store.get, boom
        r = await self.run_cmd("/panel")
        self.s.settings_store.get = real
        self.assertEqual((r.kind, r.panel), (R.ERROR, False))

    def test_arabic_aliases_only_as_the_whole_message(self):
        self.assertIs(parse_command("لوحة التحكم").command, Command.PANEL)
        self.assertIs(parse_command("لوحة الإعدادات").command, Command.PANEL)
        for text in ("لوحة", "لوحة التحكم في السيارة", "افتح لوحة التحكم", "/panel@OtherBot"):
            self.assertIsNone(parse_command(text, "GuardianBot"), text)
        self.assertIs(parse_command("/PANEL").command, Command.PANEL)


# ----------------------------------------------------------------------------- aiogram-independent glue
class PMsg(Msg):
    async def reply(self, text, reply_markup=None):
        if self.fail_reply:
            raise RuntimeError("cannot send")
        self.replies.append(text)
        self.markups = getattr(self, "markups", []) + [reply_markup]


def fake_markup(rows):
    return ("MARKUP", tuple(tuple(r) for r in rows))


class OpenHandlerTests(PanelBase):
    def svcs(self, panel="default"):
        return NS(settings=NS(default_language="ar"), moderation_commands=self.svc,
                  panel=self.panel if panel == "default" else panel)

    async def open(self, *, sender=TG_ADMIN, panel="default", make_markup=fake_markup, text="/panel"):
        msg = PMsg(text, chat=self.g, sender=sender, mid=77)
        parsed = await mh.match_command(msg, self.bot)
        res = await mh.execute(msg, parsed, protection=gate(self.g, sender), services=self.svcs(panel),
                               make_markup=make_markup)
        return msg, res

    async def test_the_keyboard_is_bound_to_the_sender_and_the_group(self):
        msg, res = await self.open()
        self.assertEqual(res.kind, R.INFO)
        (tag, rows), = msg.markups
        self.assertEqual(tag, "MARKUP")
        for _, data in rows[0]:
            cb = codec.parse(data)
            self.assertEqual(cb.owner_id, TG_ADMIN)
            self.assertTrue(codec.verify(KEY, self.g, cb))

    async def test_arabic_alias_opens_the_same_panel(self):
        msg, _ = await self.open(text="لوحة التحكم")
        self.assertEqual(len(msg.markups), 1)

    async def test_without_a_panel_service_or_factory_it_is_plain_text(self):
        msg, res = await self.open(panel=None)
        self.assertEqual((res.kind, msg.markups), (R.INFO, [None]))
        msg, _ = await self.open(make_markup=None)
        self.assertEqual(msg.markups, [None])

    async def test_a_failing_keyboard_degrades_to_plain_text(self):
        def boom(rows):
            raise RuntimeError("bad markup")
        msg, res = await self.open(make_markup=boom)
        self.assertEqual((res.kind, msg.markups), (R.INFO, [None]))
        self.assertEqual(len(msg.replies), 1)

    async def test_a_denied_sender_gets_no_keyboard(self):
        msg, res = await self.open(sender=STRANGER)
        self.assertEqual((res.kind, msg.markups), (R.DENIED, [None]))


class CallbackHandlerTests(PanelBase):
    class Panelled:
        def __init__(self, chat, ctype="supergroup", fail_edit=False, fail_delete=False):
            self.chat = NS(id=chat, type=NS(value=ctype))
            self.fail_edit, self.fail_delete = fail_edit, fail_delete
            self.edits, self.deleted = [], 0

        async def edit_text(self, text, reply_markup=None):
            if self.fail_edit:
                raise RuntimeError("message is not modified")
            self.edits.append((text, reply_markup))

        async def delete(self):
            if self.fail_delete:
                raise RuntimeError("too old")
            self.deleted += 1

    def svcs(self, panel="default"):
        return NS(settings=NS(default_language="ar"), panel=self.panel if panel == "default" else panel)

    def query(self, message, owner=TG_ADMIN, presser=None, screen=codec.SCREEN_HOME, data=None, group=None):
        data = self.data(self.g if group is None else group, owner, screen) if data is None else data
        return NS(data=data, message=message, from_user=NS(id=owner if presser is None else presser, language_code="ar"))

    async def test_home_edits_the_message_in_place_and_answers(self):
        m = self.Panelled(self.g)
        toast = await ph.on_panel_callback(self.query(m), self.svcs(), fake_markup)
        self.assertEqual(toast, ("تم التحديث ✅", False))
        (text, markup), = m.edits
        self.assertIn("إعدادات", text)
        self.assertEqual(markup[0], "MARKUP")
        self.assertEqual(m.deleted, 0)

    async def test_close_deletes_the_message(self):
        m = self.Panelled(self.g)
        toast = await ph.on_panel_callback(self.query(m, screen=codec.SCREEN_CLOSE), self.svcs(), fake_markup)
        self.assertEqual((m.deleted, m.edits, toast), (1, [], ("", False)))

    async def test_a_refusal_neither_edits_nor_deletes(self):
        for kw in ({"owner": STRANGER}, {"owner": TG_ADMIN, "presser": 900_099}, {"data": "pn:1:home:" + "0" * 12}):
            for screen in codec.SCREENS:
                m = self.Panelled(self.g)
                toast = await ph.on_panel_callback(self.query(m, screen=screen, **kw), self.svcs(), fake_markup)
                self.assertTrue(toast[1], kw)
                self.assertEqual((m.edits, m.deleted), ([], 0), kw)

    async def test_the_group_comes_from_the_pressed_message_not_the_data(self):
        other = await self.active_group()
        m = self.Panelled(other)
        toast = await ph.on_panel_callback(self.query(m, group=self.g), self.svcs(), fake_markup)
        self.assertTrue(toast[1])
        self.assertEqual((m.edits, m.deleted), ([], 0))

    async def test_not_ours_or_not_a_group_answers_nothing(self):
        self.assertIsNone(await ph.on_panel_callback(self.query(self.Panelled(self.g), data="vf:1:2"), self.svcs(), fake_markup))
        self.assertIsNone(await ph.on_panel_callback(self.query(self.Panelled(self.g, ctype="private")), self.svcs(), fake_markup))
        self.assertIsNone(await ph.on_panel_callback(self.query(self.Panelled(self.g)), self.svcs(panel=None), fake_markup))
        self.assertIsNone(await ph.on_panel_callback(NS(data="pn:x", message=None, from_user=None), self.svcs(), fake_markup))

    async def test_failed_edit_or_delete_never_raises_and_still_answers(self):
        m = self.Panelled(self.g, fail_edit=True)
        self.assertEqual((await ph.on_panel_callback(self.query(m), self.svcs(), fake_markup))[1], False)
        m = self.Panelled(self.g, fail_delete=True)
        toast = await ph.on_panel_callback(self.query(m, screen=codec.SCREEN_CLOSE), self.svcs(), fake_markup)
        self.assertEqual(toast, ("", False))

    async def test_an_unexpected_service_error_answers_a_safe_alert(self):
        async def boom(*a, **k):
            raise RuntimeError("bug")
        m = self.Panelled(self.g)
        toast = await ph.on_panel_callback(self.query(m), self.svcs(panel=NS(press=boom)), fake_markup)
        self.assertEqual(toast[1], True)
        self.assertEqual((m.edits, m.deleted), ([], 0))

    async def test_the_presser_language_selects_the_toast(self):
        m = self.Panelled(self.g)
        q = self.query(m)
        q.from_user.language_code = "en"
        self.assertEqual((await ph.on_panel_callback(q, self.svcs(), fake_markup))[0], "Refreshed ✅")


class LazyProviderTests(PanelBase):
    """After a restart/sleep the first thing that happens may be a panel press, before any command built the service."""

    def lazy(self, bot):
        build = lambda bot_id: ModerationCommandService(  # noqa: E731
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions,
            settings_store=self.s.settings_store, actions=self.actions, chat_info=self.s.chat, claims=self.claims,
            audit=self.s.audit, bot_id=bot_id, clock=self.s.clock, group_settings=self.s.settings)
        return LazyModerationCommands(bot, build)

    async def test_a_press_works_before_any_command_ran(self):
        bot = FakeBot()
        panel = PanelService(permissions=self.s.perm, licenses=self.s.license_service, commands=self.lazy(bot),
                             audit=self.s.audit, secret=SECRET, clock=self.s.clock, ttl_seconds=None)
        out = await panel.press(self.g, "supergroup", TG_ADMIN, self.data(self.g, TG_ADMIN), "ar")
        self.assertEqual(out.status, "home")
        self.assertEqual(bot.me_calls, 1)

    async def test_overview_fails_closed_when_the_bot_identity_is_unavailable(self):
        lazy = self.lazy(FakeBot(fail=True))
        r = await lazy.overview(self.g, "ar")
        self.assertEqual((r.kind, r.panel), (R.ERROR, False))
        panel = PanelService(permissions=self.s.perm, licenses=self.s.license_service, commands=lazy,
                             audit=self.s.audit, secret=SECRET, clock=self.s.clock, ttl_seconds=None)
        out = await panel.press(self.g, "supergroup", TG_ADMIN, self.data(self.g, TG_ADMIN), "ar")
        self.assertEqual((out.status, out.text), ("unavailable", None))


if __name__ == "__main__":
    unittest.main()
