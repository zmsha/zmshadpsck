"""Phase 4 / part 4.8: the PRIVATE-HANDOFF acceptance test for everything phase 4 added, end to end with the REAL gate.

Same idea as the phase-3 handoff tests, applied to the member features: welcome, verification, the new-member restriction
window and the Inline panel. The chain is the real one (license state driven only through `LicenseAdminService` ->
ProtectionGate -> ProtectionGateMiddleware (+ real engine and verification `tick`) -> members_handler -> services).

Acceptance criteria:
* pending / unregistered / rejected / banned / stopped / expired / DB failure  =>  a join triggers NO welcome, NO
  verification (no mute, no prompt, no stored challenge), NO service-message deletion, NO newcomer tracking, NO claim,
  whoever joins (a member, a Telegram admin or the owner), and the middleware never drops the update;
* a license lost AFTER a challenge / welcome was created stops everything automatic: a button press, the timers, the
  sweep and the middleware tick do nothing and the pending row waits; when the owner recovers, the overdue member is
  handled (the host may have slept) and the newcomer window works again;
* re-adding the bot never changes a license nor wipes the settings; a licensed group stays licensed, a blocked one stays
  blocked, an unknown one becomes PENDING (not active);
* every panel screen and every panel button is refused in every blocked state and writes nothing;
* one licensed group never licenses another.
"""
from __future__ import annotations

import random
import unittest
from datetime import timedelta
from types import SimpleNamespace as NS

from executor_stack import BOT, USER
from guardian import membership
from guardian.bot import members_handler as mh
from guardian.bot.middlewares import DATA_KEY, ProtectionGateMiddleware
from guardian.licensing.models import LicenseStatus
from guardian.members.memory_store import InMemoryChallengeStore
from guardian.members.newcomers import NewcomerService, NewcomerTracker
from guardian.members.verification import VerificationService
from guardian.members.welcome import WelcomeService
from guardian.panel import actions as pa
from guardian.panel import codec
from guardian.protection.engine import ActionResult, ProtectionEngine, SendResult
from guardian.protection_gate import ProtectionContext, denied
from stack import OWNER, STRANGER, TG_ADMIN
from test_moderation_integration import Msg
from test_panel import KEY
import test_panel_screens as tps
from test_phase3_final_handoff import BLOCKED_STATES, Pipeline

# every feature of phase 4 switched on; the failure action is a kick so a handled overdue member is visible
FULL = {
    "welcome_enabled": True, "join_service": "delete", "welcome_delete_after_seconds": 60,
    "verify_enabled": True, "verify_failure": "kick", "verify_timeout_seconds": 120,
    "newbie_seconds": 86400, "newbie_block_links": True,
    "links_enabled": False,  # isolate the newcomer window: the ordinary link rule would otherwise fire first (and mute)
}
LOSSES = ("stopped", "banned", "expired", "store_down")


class MemberActions:
    """Records every Telegram call the member features can make (superset of the engine's and the services' needs)."""

    def __init__(self):
        self.calls: list[tuple] = []
        self.next_id = 100

    def _ok(self, name, *args):
        self.calls.append((name, *args))
        return ActionResult(True, None)

    async def mute_member(self, chat, user, until): return self._ok("mute", chat, user, until)
    async def unmute_member(self, chat, user): return self._ok("unmute", chat, user)
    async def kick_member(self, chat, user): return self._ok("kick", chat, user)
    async def ban_member(self, chat, user, until): return self._ok("ban", chat, user, until)
    async def unban_member(self, chat, user): return self._ok("unban", chat, user)
    async def delete_message(self, chat, mid): return self._ok("delete", chat, mid)

    async def send_message(self, chat, text, buttons=None):
        self.calls.append(("send", chat, text, buttons))
        self.next_id += 1
        return SendResult(True, None, self.next_id)

    async def has_profile_photo(self, user_id):
        return True

    def names(self, name):
        return [c for c in self.calls if c[0] == name]


class MemberBase(Pipeline):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.actions = MemberActions()
        self.tracker = NewcomerTracker()
        self.mono = [1000.0]
        self.vtimers: list = []
        self.wtimers: list = []
        self.challenges = InMemoryChallengeStore()

        def scheduler(bucket):
            def schedule(delay, job):
                bucket.append((delay, job))
                return True
            return schedule

        self.verification = VerificationService(
            self.s.settings_store, self.actions, self.challenges, self.s.license_service, self.s.perm,
            claims=self.claims, clock=self.s.clock, monotonic=lambda: self.mono[0], schedule=scheduler(self.vtimers),
            rng=random.Random(7))
        self.welcome = WelcomeService(
            self.s.settings_store, self.actions, self.claims, self.s.license_service, clock=self.s.clock,
            monotonic=lambda: self.mono[0], schedule=scheduler(self.wtimers))
        self.newcomers = NewcomerService(self.s.settings_store, self.s.perm, self.tracker, clock=self.s.clock)
        self.engine = ProtectionEngine(self.s.settings_store, self.actions, self.s.chat, self.claims, self.s.audit,
                                       self.notifier, clock=self.s.clock, newcomers=self.tracker)
        self.mw = ProtectionGateMiddleware(self.gate, self.engine, tick=self.verification.tick)
        self.services = NS(settings=NS(default_language="ar"), moderation_commands=self.svc,
                           verification=self.verification, welcome=self.welcome, newcomers=self.newcomers)

    # ------------------------------------------------------------------ helpers
    async def configure(self, g, patch=None):
        await self.s.settings_store.merge(g, dict(FULL if patch is None else patch), OWNER, self.s.clock())

    async def join(self, g, who=USER):
        """A 'X joined' service update through the REAL middleware (+ engine + tick). Returns (handler_ran, message_id)."""
        self.mid += 1
        member = NS(id=who, full_name="Sara", is_bot=False, username=None)
        msg = Msg(None, chat=g, sender=who, mid=self.mid, new_members=[member])
        out = {"ran": False}

        async def handler(event, data):
            out["ran"] = True
            await mh.on_new_members(event, data[DATA_KEY], self.services)

        await self.mw(handler, msg, {})
        return out["ran"], self.mid

    async def say(self, g, text, who=USER):
        self.mid += 1
        out = {"ran": False}

        async def handler(event, data):
            out["ran"] = True

        await self.mw(handler, Msg(text, chat=g, sender=who, mid=self.mid), {})
        return out["ran"], self.mid

    async def snap(self, g, who=USER):
        row = await self.s.settings_store.get(g)
        mine = [c for c in self.actions.calls if c[1] == g]   # per group: other groups' activity is not this group's business
        claims = {k: v for k, v in self.claims._keys.items() if f":{g}:" in k}
        return (len(mine), claims, None if row is None else dict(row.settings),
                await self.challenges.get_pending(g, who), self.tracker.joined_at(g, who))

    async def live_group(self, temporary=False):
        self._groups += 1
        g = -3_000 - self._groups
        self._prepare_chat(g)
        await self.s.register(g)
        if temporary:
            await self.s.admin.activate_temporary(OWNER, g, self.s.clock() + timedelta(hours=1))
        else:
            await self.s.admin.activate_permanent(OWNER, g)
        await self.configure(g)
        return g

    def lose(self, how, g):
        """Drive a LICENSED group into a blocked state. Returns an async `recover` callable."""
        async def stop():
            await self.s.admin.stop(OWNER, g)

        async def ban():
            await self.s.admin.ban(OWNER, g)

        async def expire():
            self.s.clock.advance(hours=2)  # the host slept past expires_at; no scheduler ever ran

        async def down():
            self.real_get = self.break_store()

        async def back_active():
            await self.s.admin.activate_permanent(OWNER, g)

        async def back_banned():
            await self.s.admin.unban(OWNER, g)
            await self.s.admin.activate_permanent(OWNER, g)

        async def back_store():
            self.s.licenses.get = self.real_get

        return {"stopped": (stop, back_active), "banned": (ban, back_banned),
                "expired": (expire, back_active), "store_down": (down, back_store)}[how]


# --------------------------------------------------------------------------- a join in a blocked group
class BlockedJoinTests(MemberBase):
    async def test_every_blocked_state_blocks_welcome_verification_and_tracking_for_every_joiner(self):
        for state in BLOCKED_STATES:
            for who in (USER, TG_ADMIN, OWNER):
                with self.subTest(state=state, who=who):
                    g = await self.group_in(state)
                    await self.configure(g)
                    real = self.break_store() if state == "store_down" else self.s.licenses.get
                    try:
                        before = await self.snap(g, who)
                        ran, _ = await self.join(g, who)
                        self.assertTrue(ran)  # the middleware never drops the update
                        self.assertEqual(await self.snap(g, who), before)
                    finally:
                        self.s.licenses.get = real
        self.assertEqual([c for c in self.actions.calls if c[0] in ("mute", "send", "kick", "ban", "unmute")], [])
        self.assertEqual(self.actions.names("delete"), [])  # not even Telegram's own "joined" message is touched

    async def test_a_leave_in_a_blocked_group_deletes_nothing(self):
        for state in BLOCKED_STATES:
            with self.subTest(state=state):
                g = await self.group_in(state)
                await self.configure(g, {**FULL, "leave_service": "delete"})
                real = self.break_store() if state == "store_down" else self.s.licenses.get
                try:
                    self.mid += 1
                    msg = Msg(None, chat=g, sender=USER, mid=self.mid)
                    msg.left_chat_member = NS(id=USER)
                    out = {"ran": False}

                    async def handler(event, data):
                        out["ran"] = True
                        await mh.on_left_member(event, data[DATA_KEY], self.services)

                    await self.mw(handler, msg, {})
                    self.assertTrue(out["ran"])
                finally:
                    self.s.licenses.get = real
                self.assertEqual(self.actions.names("delete"), [])

    async def test_after_the_owner_recovers_the_same_join_is_welcomed_and_challenged(self):
        for state in BLOCKED_STATES:
            with self.subTest(state=state):
                g = await self.group_in(state)
                await self.configure(g)
                real = self.break_store() if state == "store_down" else self.s.licenses.get
                try:
                    await self.join(g)
                    self.assertEqual(await self.challenges.get_pending(g, USER), None)
                finally:
                    self.s.licenses.get = real
                await self.owner_recovers(g, state)
                start = len(self.actions.calls)
                ran, mid = await self.join(g)
                self.assertTrue(ran)
                names = [c[0] for c in self.actions.calls[start:]]
                self.assertEqual(names.count("delete"), 1, state)      # the "joined" service message (join_service=delete)
                self.assertEqual(names.count("mute"), 1, state)        # the member is held for verification
                self.assertEqual(names.count("send"), 1, state)        # only the challenge prompt: the welcome waits for the pass (part 8.2)
                self.assertIn((("delete"), g, mid), self.actions.calls[start:])
                self.assertIsNotNone(await self.challenges.get_pending(g, USER))
                self.assertIsNotNone(self.tracker.joined_at(g, USER))  # the newcomer window started

    async def test_a_licensed_group_never_licenses_another(self):
        live, other = await self.live_group(), await self.group_in("pending")
        await self.configure(other)
        before = await self.snap(other)
        await self.join(other)
        self.assertEqual(await self.snap(other), before)
        await self.join(live)
        self.assertIsNotNone(await self.challenges.get_pending(live, USER))
        self.assertEqual(await self.snap(other), before)  # the licensed join changed nothing in the blocked group
        await self.join(other)
        self.assertEqual(await self.snap(other), before)

    async def test_a_button_pressed_in_another_group_cannot_settle_the_challenge(self):
        live, other = await self.live_group(), await self.group_in("pending")
        await self.join(live)
        row = await self.challenges.get_pending(live, USER)
        query = NS(data=f"vf:{row.id}:ok", from_user=NS(id=USER), message=NS(chat=NS(id=other, type="supergroup")))
        await mh.on_verify_callback(query, self.services)
        self.assertIsNotNone(await self.challenges.get_pending(live, USER))
        self.assertEqual(self.actions.names("unmute"), [])


# --------------------------------------------------------------------------- the license ends AFTER something was created
class LicenseLostMidFlightTests(MemberBase):
    async def _prepare(self, how):
        self.vtimers.clear()
        self.wtimers.clear()
        self.actions.next_id = 100  # so the prompt is 101, whatever ran before in this test
        g = await self.live_group(temporary=(how == "expired"))
        ran, mid = await self.join(g)
        self.assertTrue(ran)
        row = await self.challenges.get_pending(g, USER)
        self.assertIsNotNone(row)
        self.assertEqual(len(self.vtimers), 1)
        self.assertEqual(len(self.wtimers), 0)  # part 8.2: a challenged member is not welcomed on join (only after the pass)
        sent_ids = [101]  # `MemberActions` hands ids out in order: the verification prompt
        return g, row, sent_ids

    async def test_nothing_automatic_survives_the_loss_and_the_overdue_member_is_handled_after_recovery(self):
        for how in LOSSES:
            with self.subTest(how=how):
                g, row, sent_ids = await self._prepare(how)
                lose, recover = self.lose(how, g)
                await lose()
                try:
                    start = len(self.actions.calls)
                    claims = dict(self.claims._keys)
                    # 1. the member presses the button: refused, the challenge stays
                    query = NS(data=f"vf:{row.id}:ok", from_user=NS(id=USER), message=NS(chat=NS(id=g, type="supergroup")))
                    out = await mh.on_verify_callback(query, self.services)
                    self.assertIsNotNone(out)
                    self.assertTrue(out[1])  # an alert, never the "verified" toast
                    # 2. time passes (the host sleeps): timers, sweep and the middleware tick all do nothing
                    self.s.clock.advance(minutes=30)
                    self.mono[0] += 10_000
                    for _delay, job in list(self.vtimers) + list(self.wtimers):
                        await job()
                    self.assertEqual(await self.verification.sweep(), 0)
                    ran, _ = await self.say(g, "hello")
                    self.assertTrue(ran)
                    # 3. the newcomer posts a link: the window does not act while blocked
                    ran, _ = await self.say(g, "see https://evil.example.com now")
                    self.assertTrue(ran)
                    self.assertEqual(self.actions.calls[start:], [])
                    self.assertEqual(dict(self.claims._keys), claims)
                    self.assertIsNotNone(await self.challenges.get_pending(g, USER))
                finally:
                    pass  # (the license stays lost until `recover`)
                await recover()
                # after recovery the very next update's tick handles the overdue member (kick), and the window works
                self.mono[0] += 10_000
                ran, mid = await self.say(g, "see https://evil.example.com again")
                self.assertFalse(ran)  # the engine consumed (deleted) the message: no handler runs on it
                self.assertIn(("kick", g, USER), self.actions.calls)
                self.assertIn(("delete", g, mid), self.actions.calls)  # newcomer link deleted ...
                self.assertEqual([c for c in self.actions.names("mute") if c[1] == g], [("mute", g, USER, None)])  # ... delete only
                self.assertIsNone(await self.challenges.get_pending(g, USER))
                # a member who never passed (kicked as overdue) is never welcomed, before or after the recovery
                self.assertEqual([c for c in self.actions.names("send") if c[1] == g], [c for c in self.actions.names("send")
                                                                                      if c[1] == g][:1])
                self.assertEqual(self.wtimers, [])

    async def test_a_late_correct_answer_after_recovery_still_requires_the_presser_to_own_the_challenge(self):
        g, row, _ = await self._prepare("stopped")
        lose, recover = self.lose("stopped", g)
        await lose()
        await recover()
        stranger = NS(data=f"vf:{row.id}:ok", from_user=NS(id=STRANGER), message=NS(chat=NS(id=g, type="supergroup")))
        out = await mh.on_verify_callback(stranger, self.services)
        self.assertTrue(out[1])
        self.assertIsNotNone(await self.challenges.get_pending(g, USER))
        owner = NS(data=f"vf:{row.id}:ok", from_user=NS(id=USER), message=NS(chat=NS(id=g, type="supergroup")))
        out = await mh.on_verify_callback(owner, self.services)
        self.assertFalse(out[1])
        self.assertIsNone(await self.challenges.get_pending(g, USER))
        self.assertIn(("unmute", g, USER), self.actions.calls)


# --------------------------------------------------------------------------- re-adding the bot
class ReAddedBotTests(MemberBase):
    LICENSE_FIELDS = ("status", "expires_at", "activated_at", "activated_by")

    async def _readd(self, g, times=3):
        outs = []
        for _ in range(times):
            outs.append(await membership.handle_bot_added(self.s.license_service, self.notifier, group_id=g, title="Renamed"))
        return outs

    async def test_re_adding_the_bot_never_changes_a_license_or_the_settings(self):
        for state in ("pending", "rejected", "banned", "stopped", "expired"):
            with self.subTest(state=state):
                g = await self.group_in(state)
                await self.configure(g)
                before = await self.s.licenses.get(g)
                settings = dict((await self.s.settings_store.get(g)).settings)
                notes = len(self.notifier.group_messages) + len(self.notifier.owner_messages)
                outs = await self._readd(g)
                after = await self.s.licenses.get(g)
                self.assertTrue(all(not o.created for o in outs))
                self.assertEqual([getattr(after, f) for f in self.LICENSE_FIELDS],
                                 [getattr(before, f) for f in self.LICENSE_FIELDS])
                self.assertEqual(dict((await self.s.settings_store.get(g)).settings), settings)
                self.assertEqual(len(self.notifier.group_messages) + len(self.notifier.owner_messages), notes)
                # a blocked group stays blocked: a join still triggers nothing
                snap = await self.snap(g)
                await self.join(g)
                self.assertEqual(await self.snap(g), snap)

    async def test_re_adding_a_licensed_group_keeps_it_licensed_and_features_working(self):
        g = await self.live_group()
        before = await self.s.licenses.get(g)
        await self._readd(g)
        after = await self.s.licenses.get(g)
        self.assertEqual((after.status, after.activated_by), (LicenseStatus.ACTIVE_PERMANENT, before.activated_by))
        await self.join(g)
        self.assertIsNotNone(await self.challenges.get_pending(g, USER))

    async def test_an_unknown_group_becomes_pending_and_stays_blocked(self):
        g = await self.group_in("unregistered")
        await self.configure(g)
        first, second = await self._readd(g, 2)
        self.assertTrue(first.created)
        self.assertEqual(first.status, LicenseStatus.PENDING)
        self.assertFalse(second.created)
        snap = await self.snap(g)
        await self.join(g)
        self.assertEqual(await self.snap(g), snap)
        self.assertEqual((await self.s.licenses.get(g)).status, LicenseStatus.PENDING)


# --------------------------------------------------------------------------- the handler never acts without a licensed context
class SpyService:
    def __init__(self):
        self.calls = []

    async def on_join(self, *a, **k):
        self.calls.append(("on_join", a))

    async def on_leave(self, *a, **k):
        self.calls.append(("on_leave", a))


class HandlerGateTests(unittest.IsolatedAsyncioTestCase):
    def contexts(self):
        yield None
        for reason in ("pending", "rejected", "banned", "stopped", "expired", "store_unavailable", "gate_error"):
            yield denied(-1001, "supergroup", reason, 5001)
        yield denied(None, "private", "not_a_group", None)
        yield ProtectionContext(-1001, "supergroup", False, "pending", TG_ADMIN, False)

    async def test_no_service_is_called_without_an_allowed_context(self):
        message = NS(chat=NS(id=-1001, title="T"), message_id=5, new_chat_members=[NS(id=5001, full_name="S", is_bot=False)],
                     left_chat_member=NS(id=5001))
        for ctx in self.contexts():
            spies = NS(verification=SpyService(), welcome=SpyService(), newcomers=SpyService())
            await mh.on_new_members(message, ctx, spies)
            await mh.on_left_member(message, ctx, spies)
            for name in ("verification", "welcome", "newcomers"):
                self.assertEqual(getattr(spies, name).calls, [], (ctx, name))

    async def test_the_automatic_entry_points_of_the_member_services_are_exactly_the_audited_ones(self):
        # a new public coroutine on these services must be added to the gate tests above before it can ship
        def public(cls):
            return {n for n in vars(cls) if not n.startswith("_")}
        self.assertEqual(public(VerificationService),
                         {"on_join", "suspicion_signals", "answer", "on_leave", "tick", "sweep", "aclose"})
        self.assertEqual(public(WelcomeService), {"on_join", "on_verified", "on_leave", "aclose"})
        self.assertEqual(public(NewcomerService), {"on_join"})


class ServiceLevelGateTests(MemberBase):
    """Defence in depth: even if a caller forgot the handler's check, the REAL services refuse a denied context."""

    async def test_every_member_service_refuses_a_denied_context_on_its_own(self):
        from guardian.members.welcome import Joined
        g = await self.live_group()  # settings fully enabled and the group really licensed: only the CONTEXT is denied
        joined = [Joined(USER, "Sara")]
        for reason in ("pending", "stopped", "gate_error"):
            ctx = denied(g, "supergroup", reason, USER)
            self.assertEqual((await self.verification.on_join(ctx, 7, joined, "T")).reason, "not_allowed")
            self.assertEqual((await self.welcome.on_join(ctx, 7, joined, "T")).reason, "not_allowed")
            self.assertFalse(await self.welcome.on_leave(ctx, 7))
            self.assertFalse(await self.verification.on_leave(ctx, USER))
            self.assertEqual(await self.newcomers.on_join(ctx, joined), 0)
        self.assertEqual(self.actions.calls, [])
        self.assertIsNone(await self.challenges.get_pending(g, USER))
        self.assertIsNone(self.tracker.joined_at(g, USER))
        self.assertEqual(dict(self.claims._keys), {})


# --------------------------------------------------------------------------- the Inline panel
class PanelBlockedStateTests(tps.WriteBase):
    async def test_every_screen_and_every_button_is_refused_in_every_blocked_state(self):
        self.assertTrue(set(pa.ACTIONS) <= set(codec.SCREENS))  # the loop below covers every button
        for state in BLOCKED_STATES:
            with self.subTest(state=state):
                g = await self.group_in(state)
                await self.s.settings_store.merge(g, {"welcome_enabled": True}, OWNER, self.s.clock())
                real = self.break_store() if state == "store_down" else self.s.licenses.get
                raw_before = await self.raw(g)
                claims, events = dict(self.claims._keys), len(self.s.audit.events)
                try:
                    for screen in codec.SCREENS:
                        out = await self.do(screen, group=g)
                        self.assertIn(out.status, ("license_off", "unavailable"), (state, screen))
                        self.assertEqual((out.text, out.delete), (None, False), (state, screen))
                finally:
                    self.s.licenses.get = real
                self.assertEqual(await self.raw(g), raw_before)
                self.assertEqual(dict(self.claims._keys), claims)
                self.assertEqual(len(self.s.audit.events), events)
        self.assertEqual(self.actions.calls, [])

    async def test_the_panel_works_again_after_the_owner_recovers(self):
        g = await self.group_in("stopped")
        await self.owner_recovers(g, "stopped")
        self.assertEqual((await self.do(codec.SCREEN_HOME, group=g)).status, "home")


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
