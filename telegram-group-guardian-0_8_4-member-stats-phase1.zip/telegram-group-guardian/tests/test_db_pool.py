import unittest

from guardian.db.pool import Database, is_connectivity_error
from guardian.errors import StoreUnavailable


class FakePool:
    def __init__(self):
        self.closed = False

    async def close(self):
        self.closed = True


class Clock:
    def __init__(self):
        self.now = 1000.0

    def __call__(self):
        return self.now


class PoolTests(unittest.IsolatedAsyncioTestCase):
    async def test_success_sets_status_ok(self):
        pool = FakePool()

        async def factory(dsn, lo, hi):
            return pool

        db = Database("postgresql://u:p@h/db", pool_factory=factory)
        self.assertEqual(db.last_known_status, "unknown")
        self.assertIs(await db.ensure_pool(), pool)
        self.assertEqual(db.last_known_status, "ok")
        await db.close()
        self.assertTrue(pool.closed)

    async def test_failure_is_storeunavailable_without_leaking_dsn_then_cooldown_then_retry(self):
        clock, calls = Clock(), {"n": 0}

        async def factory(dsn, lo, hi):
            calls["n"] += 1
            if calls["n"] == 1:
                raise OSError(f"cannot connect to {dsn}")
            return FakePool()

        db = Database("postgresql://u:SECRETPW@h/db", pool_factory=factory, retry_cooldown=30, clock=clock)
        with self.assertRaises(StoreUnavailable) as cm:
            await db.ensure_pool()
        self.assertNotIn("SECRETPW", str(cm.exception))
        self.assertEqual(db.last_known_status, "unavailable")
        with self.assertRaises(StoreUnavailable):  # inside cooldown: no new attempt
            await db.ensure_pool()
        self.assertEqual(calls["n"], 1)
        clock.now += 31
        await db.ensure_pool()
        self.assertEqual((calls["n"], db.last_known_status), (2, "ok"))

    def test_connectivity_classification(self):
        class PostgresConnectionError(Exception):
            pass

        class UniqueViolationError(Exception):
            pass

        self.assertTrue(is_connectivity_error(OSError()))
        self.assertTrue(is_connectivity_error(PostgresConnectionError()))
        self.assertFalse(is_connectivity_error(UniqueViolationError()))
        self.assertFalse(is_connectivity_error(ValueError()))


if __name__ == "__main__":
    unittest.main()
