"""Part 6.7c: `/export reports|audit` (CSV/TXT): arguments, the tabular renderer, the two exporters, the gates, paging/caps and the
private delivery. PostgreSQL / aiogram / Telegram are NOT exercised (fakes only)."""
from __future__ import annotations

import ast
import csv
import io
import re
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest import mock

from executor_stack import A, B, BOT, USER, BrokenClaims, gate
from guardian.audit import EXPORT_DELIVERED, EXPORT_REQUESTED, PERMISSION_DENIED, SecurityEvent
from guardian.export import args as ea
from guardian.export import tabular
from guardian.export.audit_export import HEADER as AUDIT_HEADER
from guardian.export.audit_export import build_audit_export
from guardian.export.reports_export import HEADER as REPORT_HEADER
from guardian.export.reports_export import build_reports_export
from guardian.moderation.commands import Command, parse_command
from guardian.moderation.executor import ModerationCommandService, ResultKind as R
from guardian.reports import ReportService, ReportStatus
from guardian.reports import args as ra
from guardian.reports.memory_store import InMemoryReportStore
from guardian.reports.models import Report, ReportOutcome, ReportPriority, ReportType
from stack import NOW, OWNER, STRANGER, TG_ADMIN, TG_LIMITED_ADMIN, BACKUP
from test_export_command import ExportBase, FakeDelivery, read
from guardian.export.models import DeliveryResult
from guardian.owner_hub.redactor import _looks_secret_name

TZ = "Asia/Riyadh"
TRACE = "0123456789abcdef"


def rows_of(data: bytes):
    text = data.decode("utf-8")
    assert text.startswith("﻿")
    return list(csv.reader(io.StringIO(text[1:], newline="")))


def report(i, group=A, reason="spam links", **kw):
    base = dict(id=i, group_id=group, reporter_id=USER, target_user_id=5000 + i, message_id=70 + i, reason=reason,
                report_type=ReportType.SPAM, priority=ReportPriority.NORMAL, status=ReportStatus.OPEN,
                created_at=NOW - timedelta(hours=100 - i), updated_at=NOW - timedelta(hours=100 - i))
    base.update(kw)
    return Report(**base)


def event(kind="settings_changed", group=A, **kw):
    base = dict(event_type=kind, occurred_at=NOW, actor_telegram_id=OWNER, group_id=group)
    base.update(kw)
    return SecurityEvent(**base)


# ------------------------------------------------------------------------------------------------ arguments
class ArgsTests(unittest.TestCase):
    def test_defaults_and_words_in_both_languages(self):
        r = ea.parse_export(("reports",))
        self.assertEqual((r.what, r.fmt, r.status_key, r.statuses), ("reports", "csv", "all", None))
        a = ea.parse_export(("audit",))
        self.assertEqual((a.what, a.fmt), ("audit", "csv"))
        for words, fmt in ((("csv",), "csv"), (("txt",), "txt"), (("text",), "txt"), (("نص",), "txt"), (("جدول",), "csv")):
            with self.subTest(words):
                self.assertEqual(ea.parse_export(("audit", *words)).fmt, fmt)

    def test_status_words_are_the_reports_command_words_and_any_order(self):
        for word, key in (("open", "open"), ("مفتوحة", "open"), ("taken", "taken"), ("resolved", "resolved"),
                          ("dismissed", "dismissed"), ("closed", "closed"), ("مغلقة", "closed"), ("all", "all"), ("الكل", "all")):
            for order in (("reports", word, "txt"), ("reports", "txt", word)):
                with self.subTest(order):
                    r = ea.parse_export(order)
                    self.assertEqual((r.fmt, r.status_key), ("txt", key))
                    self.assertEqual(r.statuses, ra.status_of(word)[1])
        self.assertEqual(ea.parse_export(("reports", "open")).statuses, (ReportStatus.OPEN, ReportStatus.TAKEN))
        self.assertEqual(ea.parse_export(("reports", "closed")).statuses, (ReportStatus.RESOLVED, ReportStatus.DISMISSED))

    def test_everything_else_is_an_error(self):
        bad = (("reports", "bogus"), ("reports", "csv", "txt"), ("reports", "open", "closed"), ("reports", "csv", "txt", "open"),
               ("audit", "open"), ("audit", "csv", "txt"), ("audit", "7"), ("reports", "10"), ("reports", "-1001"),
               ("settings", "csv"), ("license", "txt"), ("settings", "license"), ("reports", ""))
        for words in bad:
            with self.subTest(words):
                with self.assertRaises(ea.CommandError) as ctx:
                    ea.parse_export(words)
                self.assertEqual(ctx.exception.code, "export_usage")

    def test_the_arabic_alias_needs_the_commands_own_vocabulary(self):
        for text, what, fmt in (("تصدير البلاغات", "reports", "csv"), ("تصدير البلاغات نص", "reports", "txt"),
                                ("تصدير البلاغات الكل csv", "reports", "csv"), ("تصدير التدقيق txt", "audit", "txt"),
                                ("تصدير السجل", "audit", "csv"), ("تصدير بلاغات المفتوحة", "reports", "csv")):
            with self.subTest(text):
                parsed = parse_command(text, "GuardianBot", has_reply=False)
                self.assertIs(parsed.command, Command.EXPORT)
                self.assertTrue(parsed.arabic)
                req = ea.parse_export(parsed.args)
                self.assertEqual((req.what, req.fmt), (what, fmt))
        for text in ("تصدير البلاغات المفتوحة", "تصدير البلاغات المغلقة نص"):
            self.assertIsNotNone(parse_command(text, "GuardianBot", has_reply=False), text)
        for text in ("تصدير البلاغات الى الخارج", "تصدير التدقيق غدا", "تصدير البلاغات والتدقيق", "تصدير البلاغات الكل المفتوحة"):
            with self.subTest(text):
                self.assertIsNone(parse_command(text, "GuardianBot", has_reply=False))

    def test_the_status_helper(self):
        self.assertIsNone(ra.status_of("bogus"))
        self.assertIsNone(ra.status_of(5))
        self.assertEqual(ra.status_of("ALL"), ("all", None))


# ------------------------------------------------------------------------------------------------ tabular renderer
class TabularTests(unittest.TestCase):
    def test_formula_starts_are_neutralised_numbers_and_ids_are_not(self):
        for text in ("=1+1", "+cmd", "-cmd", "@SUM(A1)", "\t=x", "\r=x", "=HYPERLINK(\"http://x\")"):
            with self.subTest(text):
                self.assertEqual(tabular.safe_cell(text), "'" + text)
        for text in ("-1001234567", "12345", "plain", "a=b", "", "'=x"):
            self.assertEqual(tabular.safe_cell(text), text)
        self.assertEqual(tabular.safe_cell(-5), -5)
        self.assertEqual((tabular.safe_cell(None), tabular.safe_cell(True)), ("", ""))

    def test_csv_shape_roundtrips_with_commas_quotes_arabic_and_newlines(self):
        tricky = 'a,"b"\nسطر ثانٍ'
        content, kept = tabular.render_csv(("x", "y"), [[1, tricky], [2, "=bad"]])
        self.assertEqual(kept, 2)
        self.assertTrue(content.startswith("﻿x,y\r\n"))
        self.assertEqual(rows_of(content.encode()), [["x", "y"], ["1", tricky], ["2", "'=bad"]])

    def test_txt_shape_and_values_are_single_lines(self):
        content, kept = tabular.render_txt([("export", "t"), ("group", -5)], [[("a", 1), ("b", "x\ny\x07z"), ("c", None)]])
        self.assertEqual(kept, 1)
        self.assertEqual(content, "export: t\ngroup: -5\nrecords: 1\n\na: 1\nb: x y z\nc: -\n")

    def test_the_byte_budget_drops_the_OLDEST_rows_and_says_so(self):
        rows = [[i, "x" * 100] for i in range(1, 51)]
        with mock.patch.object(tabular, "BYTE_BUDGET", 1500):
            content, kept = tabular.render_csv(("n", "v"), rows)
            self.assertLess(kept, 50)
            self.assertGreater(kept, 0)
            self.assertLessEqual(len(content.encode()), 1500)
            got = rows_of(content.encode())[1:]
            self.assertEqual([r[0] for r in got], [str(i) for i in range(51 - kept, 51)])   # the newest, oldest first
            txt, tkept = tabular.render_txt([("h", 1)], [[("n", i), ("v", "x" * 100)] for i in range(1, 51)], truncated_note="note: cut")
            self.assertLess(tkept, 50)
            self.assertIn("note: cut", txt)
            self.assertIn(f"records: {tkept}", txt)
            self.assertLessEqual(len(txt.encode()), 1500)

    def test_the_budget_is_below_the_delivery_ceiling(self):
        from guardian.export.models import MAX_BYTES
        self.assertLess(tabular.BYTE_BUDGET, MAX_BYTES)

    def test_txt_labels_never_look_like_secret_names(self):
        for label in (*REPORT_HEADER, *AUDIT_HEADER, "export", "group", "exported_at", "timezone", "filter", "records", "note"):
            self.assertFalse(_looks_secret_name(label), label)


# ------------------------------------------------------------------------------------------------ reports exporter
class ReportsExportTests(unittest.TestCase):
    def test_csv_columns_and_values(self):
        taken = report(2, status=ReportStatus.RESOLVED, report_type=ReportType.SCAM, priority=ReportPriority.HIGH, assigned_to=OWNER,
                       outcome=ReportOutcome.ACTION_TAKEN, handled_by=OWNER, handled_at=NOW, reason="رابط احتيال", trace_id=TRACE,
                       idempotency_key="reportrow:secret-key")
        built = build_reports_export(A, [report(1, message_id=None, reason=None), taken], NOW, TZ)
        self.assertEqual((built.file.kind, built.file.name, built.file.rows, built.included, built.truncated),
                         ("csv", "reports_1001_20261029", 2, 2, False))
        table = rows_of(built.file.data())
        self.assertEqual(tuple(table[0]), REPORT_HEADER)
        one, two = (dict(zip(table[0], r)) for r in table[1:])
        self.assertEqual((one["id"], one["status"], one["type"], one["priority"], one["message_id"], one["reason"], one["outcome"]),
                         ("1", "open", "spam", "normal", "", "", ""))
        self.assertEqual((two["status"], two["type"], two["priority"], two["outcome"], two["reason"]),
                         ("resolved", "scam", "high", "action_taken", "رابط احتيال"))
        self.assertEqual((two["reporter_id"], two["target_user_id"], two["assigned_to"], two["handled_by"]),
                         (str(USER), "5002", str(OWNER), str(OWNER)))
        self.assertEqual((two["handled_at"], two["handled_at_local"]), ("2026-10-29T12:00:00Z", "2026-10-29 15:00"))
        text = built.file.content
        for forbidden in (TRACE, "secret-key", "trace", "idempotency"):
            self.assertNotIn(forbidden, text)

    def test_the_reporters_text_cannot_become_a_formula(self):
        built = build_reports_export(A, [report(1, reason='=HYPERLINK("http://evil","x")'), report(2, reason="@cmd"), report(3, reason="+1")], NOW, TZ)
        cells = [r[REPORT_HEADER.index("reason")] for r in rows_of(built.file.data())[1:]]
        self.assertEqual(cells, ['\'=HYPERLINK("http://evil","x")', "'@cmd", "'+1"])

    def test_rows_of_another_group_are_never_exported(self):
        built = build_reports_export(A, [report(1), report(2, group=B), report(3)], NOW, TZ)
        self.assertEqual([r[0] for r in rows_of(built.file.data())[1:]], ["1", "3"])
        self.assertEqual(built.included, 2)

    def test_txt_blocks(self):
        built = build_reports_export(A, [report(1), report(2, reason=None)], NOW, TZ, "txt", status_key="open")
        self.assertEqual((built.file.kind, built.file.name), ("txt", "reports_1001_20261029"))
        text = built.file.content
        self.assertTrue(text.startswith("export: reports\ngroup: -1001\nexported_at: 2026-10-29T12:00:00Z\ntimezone: Asia/Riyadh\nfilter: open\nrecords: 2\n"))
        self.assertIn("id: 1\n", text)
        self.assertIn("reason: spam links\n", text)
        self.assertIn("reason: -\n", text)
        self.assertEqual(text.count("status: open"), 2)

    def test_an_empty_export_is_a_header_only_file(self):
        built = build_reports_export(A, [], NOW, TZ)
        self.assertEqual((built.file.rows, built.included, built.truncated), (0, 0, False))
        self.assertEqual(len(rows_of(built.file.data())), 1)

    def test_the_command_cap_and_the_byte_budget_are_both_reported_as_truncated(self):
        self.assertTrue(build_reports_export(A, [report(1)], NOW, TZ, truncated=True).truncated)
        with mock.patch.object(tabular, "BYTE_BUDGET", 600):
            built = build_reports_export(A, [report(i, reason="x" * 150) for i in range(1, 30)], NOW, TZ)
        self.assertTrue(built.truncated)
        self.assertLess(built.included, 29)
        self.assertEqual(built.file.rows, built.included)

    def test_bad_format_is_a_programming_error(self):
        with self.assertRaises(ValueError):
            build_reports_export(A, [], NOW, TZ, "json")


# ------------------------------------------------------------------------------------------------ audit exporter
class AuditExportTests(unittest.TestCase):
    def test_only_the_content_free_columns_and_never_the_detail(self):
        events = [event("permission_denied", actor_telegram_id=STRANGER, permission="moderate", target_id="-1001", result="denied",
                        trace_id=TRACE, detail="free text TOPSECRET-DETAIL"),
                  event("report_taken", target_id="12", result="applied")]
        built = build_audit_export(A, events, NOW, TZ)
        self.assertEqual((built.file.name, built.file.kind, built.file.rows, built.truncated), ("audit_1001_20261029", "csv", 2, False))
        table = rows_of(built.file.data())
        self.assertEqual(tuple(table[0]), AUDIT_HEADER)
        first = dict(zip(table[0], table[1]))
        self.assertEqual((first["event"], first["actor_id"], first["target"], first["result"], first["permission"], first["trace"]),
                         ("permission_denied", str(STRANGER), "-1001", "denied", "moderate", TRACE))
        self.assertEqual((first["at"], first["at_local"]), ("2026-10-29T12:00:00Z", "2026-10-29 15:00"))
        self.assertNotIn("TOPSECRET", built.file.content)
        self.assertNotIn("free text", built.file.content)

    def test_values_outside_their_closed_vocabulary_are_blanked(self):
        weird = event("Bad Event;DROP", permission="not-a-permission", result="maybe", trace_id="zzz")
        object.__setattr__(weird, "result", "maybe")           # `SecurityEvent` itself already drops unknown results; belt and braces
        object.__setattr__(weird, "permission", "not-a-permission")
        object.__setattr__(weird, "trace_id", "zzz")
        row = dict(zip(AUDIT_HEADER, rows_of(build_audit_export(A, [weird], NOW, TZ).file.data())[1]))
        self.assertEqual((row["event"], row["result"], row["permission"], row["trace"]), ("", "", "", ""))

    def test_a_target_that_looks_like_a_formula_is_neutralised(self):
        row = dict(zip(AUDIT_HEADER, rows_of(build_audit_export(A, [event(target_id="=cmd|' /c calc'!A0")], NOW, TZ).file.data())[1]))
        self.assertTrue(row["target"].startswith("'="))

    def test_other_groups_events_are_dropped_and_the_system_actor_is_blank(self):
        built = build_audit_export(A, [event(group=B), event(actor_telegram_id=None), event(group=None)], NOW, TZ)
        self.assertEqual(built.included, 1)
        self.assertEqual(rows_of(built.file.data())[1][AUDIT_HEADER.index("actor_id")], "")

    def test_txt(self):
        built = build_audit_export(A, [event(target_id="9", result="applied")], NOW, TZ, "txt")
        self.assertEqual(built.file.kind, "txt")
        self.assertTrue(built.file.content.startswith("export: security events\ngroup: -1001\n"))
        self.assertIn("event: settings_changed\n", built.file.content)
        self.assertIn("target: 9\n", built.file.content)


# ------------------------------------------------------------------------------------------------ the command
class Base(ExportBase):
    """The 6.7b stack plus a report service over an in-memory store."""

    async def asyncSetUp(self):
        self.reports_store = InMemoryReportStore()
        await super().asyncSetUp()
        self.msg = 500

    def make_service(self, claims):
        self.reports = ReportService(self.reports_store, self.s.audit, self.s.clock)
        super().make_service(claims)                      # builds `self.delivery` (real, over the fake transport)
        return ModerationCommandService(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions,
            settings_store=self.s.settings_store, actions=self.actions, chat_info=self.s.chat, claims=claims,
            audit=self.s.audit, bot_id=BOT, clock=self.s.clock, group_settings=self.s.settings,
            export_delivery=self.delivery, licenses=self.s.licenses, audit_query=self.s.audit_query, display_timezone=TZ,
            reports=self.reports)

    async def ex(self, text, *, actor=TG_ADMIN, chat=A, protection="default", lang="ar"):
        parsed = parse_command(text, "GuardianBot", has_reply=False)
        assert parsed is not None, text
        self.msg += 1
        prot = gate(chat, actor) if protection == "default" else protection
        return await self.svc.handle(parsed, chat_id=chat, actor_id=actor, message_id=self.msg, protection=prot, reply=None, language=lang)

    async def file_reports(self, n=1, group=A, reason="spam links"):
        out = []
        for i in range(n):
            r, _ = await self.reports.create(group, USER, 6000 + i, 70 + i, reason)
            out.append(r)
            self.s.clock.advance(seconds=1)
        return out

    def last(self):
        return self.transport.sent[-1]


class ReportsCommandTests(Base):
    async def test_a_moderator_gets_the_group_reports_in_private_and_the_group_a_one_liner(self):
        await self.file_reports(3)
        await self.file_reports(2, group=B, reason="other group's report")
        r = await self.ex("/export reports")
        self.assertIs(r.kind, R.DONE)
        self.assertNotIn("spam links", r.text)
        self.assertNotIn("\n", r.text.strip().split("\n")[0].replace("✅", ""))        # a short line, never the content
        user_id, filename, data, caption = self.last()
        self.assertEqual((user_id, filename), (TG_ADMIN, "reports_1001_20261029.csv"))
        self.assertIn("-1001", caption)
        table = rows_of(data)
        self.assertEqual([row[0] for row in table[1:]], ["1", "2", "3"])               # oldest first, this group only
        self.assertNotIn("other group", data.decode())
        self.assertEqual(len(self.transport.sent), 1)

    async def test_status_filter_and_txt_format_and_the_arabic_form(self):
        a, b, c = await self.file_reports(3)
        await self.reports.take(A, b.id, OWNER)
        await self.reports.resolve(A, c.id, OWNER, ReportOutcome.NO_ACTION)
        for text, ids in (("/export reports open", ["1", "2"]), ("/export reports taken", ["2"]), ("/export reports closed", ["3"]),
                          ("/export reports resolved", ["3"]), ("/export reports dismissed", []), ("/export reports all", ["1", "2", "3"])):
            self.s.clock.advance(seconds=60)
            r = await self.ex(text)
            with self.subTest(text):
                self.assertIs(r.kind, R.DONE)
                self.assertEqual([row[0] for row in rows_of(self.last()[2])[1:]], ids)
        self.s.clock.advance(seconds=60)
        r = await self.ex("تصدير البلاغات txt المفتوحة")
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(self.last()[1], "reports_1001_20261029.txt")
        self.assertIn("filter: open", self.last()[2].decode())

    async def test_the_destination_is_the_actor_and_the_audit_names_the_export_only(self):
        await self.file_reports(1, reason="secret-ish reason text")
        await self.ex("/export reports")
        self.assertEqual(self.last()[0], TG_ADMIN)
        started = self.events(EXPORT_REQUESTED)
        self.assertEqual([(e.target_id, e.group_id, e.actor_telegram_id) for e in started], [("reports", A, TG_ADMIN)])
        for e in self.s.audit.events:
            self.assertNotIn("secret-ish", (e.detail or "") + (e.target_id or ""))
        self.assertEqual(len(self.events(EXPORT_DELIVERED)), 1)

    async def test_csv_injection_survives_the_whole_path(self):
        await self.file_reports(1, reason='=HYPERLINK("http://evil.example","click")')
        await self.ex("/export reports")
        cell = rows_of(self.last()[2])[1][REPORT_HEADER.index("reason")]
        self.assertTrue(cell.startswith("'="), cell)

    async def test_a_realistic_file_is_not_masked_by_the_delivery_screen(self):
        reasons = ("روابط مزعجة https://example.com/promo?id=12345&ref=abc", "إساءة لفظية متكررة من العضو", "spam spam spam", None)
        for index, reason in enumerate(reasons):
            await self.reports.create(A, USER, 7000 + index, 80 + index, reason)
            self.s.clock.advance(seconds=1)
        for text in ("/export reports", "/export reports txt"):
            self.s.clock.advance(seconds=60)
            r = await self.ex(text)
            with self.subTest(text):
                self.assertIs(r.kind, R.DONE)
                self.assertNotIn("REDACTED", self.last()[2].decode())
                self.assertNotIn("⚠️", r.text)

    async def test_paging_collects_every_report_across_pages_in_order(self):
        await self.file_reports(120)
        r = await self.ex("/export reports")
        self.assertIs(r.kind, R.DONE)
        ids = [int(row[0]) for row in rows_of(self.last()[2])[1:]]
        self.assertEqual(ids, list(range(1, 121)))
        self.assertNotIn("ℹ️", r.text)                                                  # nothing was left out

    async def test_the_row_cap_keeps_the_newest_and_says_so(self):
        await self.file_reports(60)
        with mock.patch("guardian.export.command.REPORTS_CAP", 55):
            r = await self.ex("/export reports")
        ids = [int(row[0]) for row in rows_of(self.last()[2])[1:]]
        self.assertEqual(ids, list(range(6, 61)))
        self.assertIn("55", r.text)
        self.assertIn("ℹ️", r.text)
        self.assertIn("55", self.last()[3])                                             # the caption says it too

    async def test_exactly_the_cap_is_not_truncated(self):
        await self.file_reports(55)
        with mock.patch("guardian.export.command.REPORTS_CAP", 55):
            r = await self.ex("/export reports")
        self.assertEqual(len(rows_of(self.last()[2])) - 1, 55)
        self.assertNotIn("ℹ️", r.text)

    async def test_a_store_that_ignores_before_id_cannot_loop_forever(self):
        class Stuck:
            calls = 0

            async def list_reports(self, group_id, statuses, limit, before_id=None):
                Stuck.calls += 1
                return [report(i) for i in range(limit, 0, -1)]

        self.svc = ModerationCommandService(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions, settings_store=self.s.settings_store,
            actions=self.actions, chat_info=self.s.chat, claims=self.claims, audit=self.s.audit, bot_id=BOT, clock=self.s.clock,
            group_settings=self.s.settings, export_delivery=self.delivery, licenses=self.s.licenses,
            audit_query=self.s.audit_query, display_timezone=TZ, reports=Stuck())
        r = await self.ex("/export reports")
        self.assertIs(r.kind, R.DONE)
        self.assertLessEqual(Stuck.calls, 2)

    async def test_a_read_failure_is_a_safe_error_and_nothing_is_sent(self):
        class Broken:
            async def list_reports(self, *a, **k):
                raise RuntimeError("db down")

        self.svc = ModerationCommandService(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions, settings_store=self.s.settings_store,
            actions=self.actions, chat_info=self.s.chat, claims=self.claims, audit=self.s.audit, bot_id=BOT, clock=self.s.clock,
            group_settings=self.s.settings, export_delivery=self.delivery, licenses=self.s.licenses,
            audit_query=self.s.audit_query, display_timezone=TZ, reports=Broken())
        r = await self.ex("/export reports")
        self.assertIs(r.kind, R.ERROR)
        self.assertNotIn("db down", r.text)
        self.assertEqual(self.transport.sent, [])

    async def test_without_a_report_service_it_says_unavailable_before_claiming_anything(self):
        self.svc = ModerationCommandService(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions, settings_store=self.s.settings_store,
            actions=self.actions, chat_info=self.s.chat, claims=self.claims, audit=self.s.audit, bot_id=BOT, clock=self.s.clock,
            group_settings=self.s.settings, export_delivery=self.delivery, licenses=self.s.licenses,
            audit_query=self.s.audit_query, display_timezone=TZ)
        r = await self.ex("/export reports")
        self.assertIs(r.kind, R.ERROR)
        self.assertEqual((self.transport.sent, self.events(EXPORT_REQUESTED)), ([], []))
        self.assertIs((await self.ex("/export settings")).kind, R.DONE)                # the other exports are unaffected

    async def test_a_redelivered_update_sends_nothing_twice_and_the_cooldown_applies(self):
        await self.file_reports(1)
        parsed = parse_command("/export reports", "GuardianBot", has_reply=False)
        first = await self.svc.handle(parsed, chat_id=A, actor_id=TG_ADMIN, message_id=900, protection=gate(A, TG_ADMIN), reply=None, language="ar")
        again = await self.svc.handle(parsed, chat_id=A, actor_id=TG_ADMIN, message_id=900, protection=gate(A, TG_ADMIN), reply=None, language="ar")
        self.assertIs(first.kind, R.DONE)
        self.assertIs(again.kind, R.THROTTLED)
        self.assertEqual(len(self.transport.sent), 1)
        self.s.clock.advance(seconds=60)
        later = await self.svc.handle(parsed, chat_id=A, actor_id=TG_ADMIN, message_id=900, protection=gate(A, TG_ADMIN), reply=None, language="ar")
        self.assertIs(later.kind, R.DUPLICATE)
        self.assertEqual(len(self.transport.sent), 1)


class AuditCommandTests(Base):
    async def test_a_moderator_gets_the_group_security_events_and_the_request_itself_is_in_it(self):
        await self.s.audit.record(event("settings_changed", target_id="warn_limit", result="applied", detail="TOPSECRET-DETAIL"))
        await self.s.audit.record(event("permission_denied", group=B, target_id="elsewhere"))
        r = await self.ex("/export audit")
        self.assertIs(r.kind, R.DONE)
        user_id, filename, data, caption = self.last()
        self.assertEqual((user_id, filename), (TG_ADMIN, "audit_1001_20261029.csv"))
        table = rows_of(data)
        names = [dict(zip(table[0], row))["event"] for row in table[1:]]
        self.assertIn("settings_changed", names)
        self.assertIn(EXPORT_REQUESTED, names)
        self.assertNotIn("TOPSECRET", data.decode())
        self.assertNotIn("elsewhere", data.decode())
        self.assertNotIn(str(B), data.decode())

    async def test_txt_and_the_arabic_form(self):
        await self.s.audit.record(event("settings_changed"))
        r = await self.ex("تصدير التدقيق txt")
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(self.last()[1], "audit_1001_20261029.txt")
        self.assertIn("event: settings_changed", self.last()[2].decode())

    async def test_a_full_page_is_reported_as_possibly_truncated(self):
        for i in range(520):
            self.s.audit.events.append(event("settings_changed", target_id=str(i)))
        r = await self.ex("/export audit")
        self.assertEqual(len(rows_of(self.last()[2])) - 1, 500)
        self.assertIn("500", r.text)
        self.assertIn("ℹ️", r.text)

    async def test_a_read_failure_is_a_safe_error(self):
        async def boom(*a, **k):
            raise RuntimeError("db down")
        self.s.audit.for_group = boom
        r = await self.ex("/export audit")
        self.assertIs(r.kind, R.ERROR)
        self.assertEqual(self.transport.sent, [])

    async def test_the_audit_log_never_goes_to_a_group_and_never_through_the_owner_only_query(self):
        body = read("export/command.py")
        self.assertNotIn("security_events(", body)
        self.assertNotIn("audit_for_group", body)
        self.assertEqual(len(re.findall(r"\.for_group\(", body)), 1)
        self.assertIn("self._audit.for_group(chat_id, AUDIT_CAP)", body)


class GatesTests(Base):
    def untouched(self):
        self.assertEqual(self.transport.sent, [])
        self.assertEqual(self.events(EXPORT_REQUESTED), [])

    async def test_non_moderators_are_denied_before_anything_is_read(self):
        await self.file_reports(2)
        for who in (USER, STRANGER, TG_LIMITED_ADMIN, BACKUP):
            for what in ("reports", "audit"):
                r = await self.ex(f"/export {what}", actor=who, protection=gate(A, who))
                with self.subTest(who=who, what=what):
                    self.assertIs(r.kind, R.DENIED)
        self.untouched()
        self.assertGreaterEqual(len(self.events(PERMISSION_DENIED)), 1)

    async def test_a_moderator_of_another_group_cannot_export_this_one(self):
        for what in ("reports", "audit"):
            r = await self.ex(f"/export {what}", chat=B, protection=gate(B, STRANGER), actor=STRANGER)
            self.assertIs(r.kind, R.DENIED)
        self.untouched()

    async def test_a_blocked_licence_stops_everyone_including_the_owner(self):
        for what in ("reports", "audit"):
            for who in (TG_ADMIN, OWNER):
                r = await self.ex(f"/export {what}", actor=who, protection=gate(A, who, allowed=False))
                self.assertIs(r.kind, R.LICENSE_OFF)
        self.untouched()

    async def test_the_group_is_the_chat_it_was_typed_in_never_the_text(self):
        await self.file_reports(1)
        await self.file_reports(4, group=B)
        await self.ex("/export reports all -1002")
        self.assertEqual(len(self.transport.sent), 0)                                   # an extra word is an error, not a group id
        r = await self.ex("/export reports all")
        self.assertEqual(len(rows_of(self.last()[2])) - 1, 1)

    async def test_the_licence_log_is_still_owner_only(self):
        r = await self.ex("/export license")
        self.assertIs(r.kind, R.DENIED)
        self.assertEqual(self.transport.sent, [])

    async def test_it_works_during_dry_run_and_never_writes_reports(self):
        await self.settings(dry_run=True)
        await self.file_reports(2)
        before = [(r.id, r.status) for r in await self.reports.list_reports(A, None, 50)]
        r = await self.ex("/export reports")
        self.assertIs(r.kind, R.DONE)
        self.assertEqual([(x.id, x.status) for x in await self.reports.list_reports(A, None, 50)], before)

    async def test_a_claim_failure_exports_nothing(self):
        self.claims = BrokenClaims()
        self.svc = ModerationCommandService(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions, settings_store=self.s.settings_store,
            actions=self.actions, chat_info=self.s.chat, claims=self.claims, audit=self.s.audit, bot_id=BOT, clock=self.s.clock,
            group_settings=self.s.settings, export_delivery=self.delivery, licenses=self.s.licenses,
            audit_query=self.s.audit_query, display_timezone=TZ, reports=self.reports)
        for what in ("reports", "audit"):
            r = await self.ex(f"/export {what}")
            self.assertIs(r.kind, R.ERROR)
        self.assertEqual(self.transport.sent, [])


class OutcomeTests(Base):
    delivery_mode = DeliveryResult("private_not_started")

    async def test_delivery_codes_map_to_the_same_closed_answers(self):
        for code, kind in (("private_not_started", R.INVALID), ("too_large", R.ERROR), ("too_many_rows", R.ERROR),
                           ("rejected", R.ERROR), ("failed", R.TELEGRAM_FAILED), ("duplicate", R.DUPLICATE), ("invalid", R.ERROR)):
            self.delivery.result = DeliveryResult(code)
            self.s.clock.advance(seconds=60)
            r = await self.ex("/export reports")
            with self.subTest(code):
                self.assertIs(r.kind, kind)
                self.assertNotIn("{", r.text)

    async def test_the_caption_and_the_request_carry_the_group_for_audit_only(self):
        self.delivery.result = DeliveryResult("sent")
        await self.file_reports(1)
        await self.ex("/export reports txt")
        requester, file, key, caption, group = self.delivery.calls[-1]
        self.assertEqual((requester, group, file.kind), (TG_ADMIN, A, "txt"))
        self.assertTrue(key.endswith(":reports"))
        self.assertNotRegex(caption, r"[<>&]")


# ------------------------------------------------------------------------------------------------ structure
SRC = Path(__file__).resolve().parent.parent / "src" / "guardian"


class StructureTests(unittest.TestCase):
    NEW = ("export/tabular.py", "export/reports_export.py", "export/audit_export.py", "export/args.py")

    def imports(self, rel):
        out = []
        for node in ast.walk(ast.parse(read(rel))):
            if isinstance(node, ast.Import):
                out += [a.name for a in node.names]
            elif isinstance(node, ast.ImportFrom):
                out.append(("." * node.level) + (node.module or "") + ":" + ",".join(a.name for a in node.names))
        return out

    def test_the_new_modules_are_pure_and_framework_free(self):
        for rel in self.NEW:
            tree = ast.parse(read(rel))
            self.assertEqual([n for n in ast.walk(tree) if isinstance(n, (ast.AsyncFunctionDef, ast.Await))], [], rel)
            for imp in self.imports(rel):
                with self.subTest(rel=rel, imp=imp):
                    for banned in ("aiogram", "asyncpg", "owner_hub", "hub_transport", "idempotency", "permissions:PermissionService"):
                        self.assertNotIn(banned, imp)

    def test_the_audit_exporter_never_touches_the_free_text_detail(self):
        tree = ast.parse(read("export/audit_export.py"))
        attrs = {n.attr for n in ast.walk(tree) if isinstance(n, ast.Attribute)}
        self.assertNotIn("detail", attrs)
        self.assertNotIn("detail", AUDIT_HEADER)

    def test_the_delivery_and_its_models_are_unchanged_by_6_7c(self):
        for rel in ("export/delivery.py", "export/models.py"):
            for banned in ("reports_export", "audit_export", "tabular"):
                self.assertNotIn(banned, read(rel), rel)

    def test_the_command_order_is_parse_then_owner_or_moderator_check_then_claim_then_audit_then_build_then_deliver(self):
        body = read("export/command.py")
        body = body[body.index("async def handle"):body.index("async def _build")]
        marks = ["parse_export(", "Permission.VIEW_AUDIT", "Permission.MODERATE", "delivery is None", "self._ready(", ".claim(",
                 "record_safely(", "self._build(", ".deliver("]
        positions = [body.index(x) for x in marks]
        self.assertEqual(positions, sorted(positions))

    def test_the_caps_are_below_the_delivery_ceilings(self):
        from guardian.export.audit_export import ROW_CAP as audit_cap
        from guardian.export.models import MAX_ROWS
        from guardian.export.reports_export import ROW_CAP as reports_cap
        self.assertLess(reports_cap, MAX_ROWS)
        self.assertLessEqual(audit_cap, 500)                 # what `PostgresSecurityAudit.for_group` returns at most

    def test_no_new_migration_and_the_group_scope_of_both_reads(self):
        self.assertEqual(sorted(p.name[:4] for p in (SRC / "db" / "sql").glob("0*.sql"))[-1], "0013")
        body = read("export/command.py")
        self.assertIn("self._reports.list_reports(chat_id,", body)


if __name__ == "__main__":
    unittest.main()
