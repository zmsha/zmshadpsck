"""Postgres layer tests WITHOUT a real PostgreSQL.

A recording fake connection captures every statement + arguments. This proves query SHAPE
(group_id scoping, FOR UPDATE, audit in the same transaction, no UPDATE/DELETE of audit),
NOT that PostgreSQL accepts the SQL. Real-database verification is still outstanding
(see TEST_REPORT.md)."""
import re
import unittest
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path

from guardian.audit import PostgresSecurityAudit, SecurityEvent
from guardian.db.migrations import SQL_DIR, discover, run_migrations
from guardian.groups.models import GroupRole
from guardian.groups.postgres_store import PostgresDelegationStore, PostgresSettingsStore, PostgresTrustStore
from guardian.idempotency import PostgresIdempotency
from guardian.licensing.models import AuditEvent, GroupLicense, LicenseStatus as S
from guardian.licensing.postgres_store import PostgresLicenseStore
from helpers import FakeConn

NOW = datetime(2026, 10, 29, 12, tzinfo=timezone.utc)
SRC = Path(__file__).resolve().parent.parent / "src" / "guardian"


class RecConn:
    def __init__(self, fetchval=None, fetchrow=None, fetch=None):
        self.log: list[tuple[str, str, tuple]] = []  # (kind, sql, args)
        self._fetchval, self._fetchrow, self._fetch = fetchval, fetchrow, fetch or []
        self.tx_depth = 0
        self.tx_commits = 0

    def transaction(self):
        conn = self

        class Tx:
            async def __aenter__(self_):
                conn.tx_depth += 1

            async def __aexit__(self_, et, ev, tb):
                conn.tx_depth -= 1
                if et is None:
                    conn.tx_commits += 1
                return False

        return Tx()

    async def _rec(self, kind, sql, args):
        self.log.append((kind, " ".join(sql.split()), args, self.tx_depth))

    async def execute(self, sql, *args):
        await self._rec("execute", sql, args)
        return "DELETE 3"

    async def fetchval(self, sql, *args):
        await self._rec("fetchval", sql, args)
        return self._fetchval

    async def fetchrow(self, sql, *args):
        await self._rec("fetchrow", sql, args)
        return self._fetchrow

    async def fetch(self, sql, *args):
        await self._rec("fetch", sql, args)
        return self._fetch


class RecDb:
    def __init__(self, conn):
        self.conn = conn

    @asynccontextmanager
    async def acquire(self):
        yield self.conn


def lic(status, **kw):
    return GroupLicense(group_id=-1001, title="t", status=status, updated_at=NOW, **kw)


def audit(prev, new, **kw):
    return AuditEvent(group_id=-1001, action="x", previous_status=prev, new_status=new, occurred_at=NOW,
                      actor_telegram_id=1, **kw)


class LicenseTransitionSqlTests(unittest.IsolatedAsyncioTestCase):
    async def test_cas_success_locks_row_updates_and_audits_in_one_transaction(self):
        conn = RecConn(fetchval="pending")
        store = PostgresLicenseStore(RecDb(conn))
        ok = await store.transition(-1001, expected_status=S.PENDING,
                                    new_license=lic(S.ACTIVE_PERMANENT, activated_at=NOW, activated_by=1),
                                    audit=audit(S.PENDING, S.ACTIVE_PERMANENT))
        self.assertTrue(ok)
        kinds = [(k, sql.split()[0] + " " + (sql.split()[1] if sql.startswith("INSERT") else "")) for k, sql, *_ in conn.log]
        sqls = [sql for _, sql, *_ in conn.log]
        self.assertIn("FOR UPDATE", sqls[0])
        self.assertTrue(sqls[1].startswith("UPDATE telegram_groups"))
        self.assertTrue(sqls[2].startswith("INSERT INTO license_audit_log"))
        self.assertTrue(all(depth == 1 for *_, depth in conn.log))  # everything inside the transaction
        self.assertEqual(conn.tx_commits, 1)
        self.assertEqual(conn.log[1][2][0], -1001)  # UPDATE ... WHERE group_id = $1
        self.assertIn("WHERE group_id = $1", sqls[1])

    async def test_cas_mismatch_writes_nothing(self):
        for current in ("banned", None):
            conn = RecConn(fetchval=current)
            ok = await PostgresLicenseStore(RecDb(conn)).transition(
                -1001, expected_status=S.PENDING, new_license=lic(S.ACTIVE_PERMANENT, activated_at=NOW, activated_by=1),
                audit=audit(S.PENDING, S.ACTIVE_PERMANENT))
            self.assertFalse(ok)
            self.assertEqual(len(conn.log), 1)  # only the locking SELECT

    async def test_group_mismatch_between_arguments_is_rejected_before_any_sql(self):
        conn = RecConn(fetchval="pending")
        other = GroupLicense(group_id=-2, title="t", status=S.STOPPED, updated_at=NOW)
        with self.assertRaises(ValueError):
            await PostgresLicenseStore(RecDb(conn)).transition(
                -1001, expected_status=S.PENDING, new_license=other, audit=audit(S.PENDING, S.STOPPED))
        self.assertEqual(conn.log, [])

    async def test_audit_read_is_group_scoped_and_bounded(self):
        conn = RecConn(fetch=[])
        await PostgresLicenseStore(RecDb(conn)).audit_for_group(-1001, limit=10_000)
        _, sql, args, _ = conn.log[0]
        self.assertIn("WHERE group_id = $1", sql)
        self.assertEqual(args, (-1001, 500))


class GroupStoresSqlTests(unittest.IsolatedAsyncioTestCase):
    async def test_delegation_queries_are_scoped(self):
        conn = RecConn(fetchrow=None, fetch=[])
        store = PostgresDelegationStore(RecDb(conn))
        await store.get_live(-1, 5)
        await store.revoke(-1, 5, 9, NOW)
        await store.list_live(-1)
        for _, sql, args, _ in conn.log:
            self.assertIn("group_id = $1", sql)
            self.assertEqual(args[0], -1)

    async def test_grant_locks_and_runs_in_a_transaction(self):
        conn = RecConn(fetchrow={"group_id": -1, "user_id": 5, "role": "moderator", "granted_by": 9,
                                 "granted_at": NOW, "revoked_at": None, "revoked_by": None})
        d, changed = await PostgresDelegationStore(RecDb(conn)).grant(-1, 5, GroupRole.MODERATOR, 9, NOW)
        self.assertFalse(changed)  # same role already live
        self.assertIn("FOR UPDATE", conn.log[0][1])
        self.assertEqual(len(conn.log), 1)
        self.assertEqual(d.role, GroupRole.MODERATOR)

    async def test_trust_and_settings_queries_are_scoped(self):
        conn = RecConn(fetchrow=None, fetch=[])
        t = PostgresTrustStore(RecDb(conn))
        await t.add(-1, 5, 9, None, NOW)
        await t.remove(-1, 5)
        await t.is_trusted(-1, 5)
        await t.list(-1)
        s = PostgresSettingsStore(RecDb(conn))
        await s.get(-1)
        for _, sql, args, _ in conn.log[:6]:
            self.assertEqual(args[0], -1)
            self.assertTrue("group_id = $1" in sql or "VALUES ($1" in sql, sql)

    async def test_idempotency_claim_and_purge(self):
        conn = RecConn(fetchrow={"key": "update:1"})
        store = PostgresIdempotency(RecDb(conn))
        self.assertTrue(await store.claim("update:1"))
        self.assertIn("ON CONFLICT (key) DO NOTHING", conn.log[0][1])
        conn2 = RecConn(fetchrow=None)
        self.assertFalse(await PostgresIdempotency(RecDb(conn2)).claim("update:1"))
        self.assertEqual(await store.purge_older_than(NOW), 3)

    async def test_security_audit_only_inserts(self):
        conn = RecConn()
        await PostgresSecurityAudit(RecDb(conn)).record(SecurityEvent("permission_denied", NOW, 1, -1, "x", "d"))
        self.assertTrue(conn.log[0][1].startswith("INSERT INTO security_audit_log"))


# The ONLY cross-group read in these stores: the OWNER panel's read-only listing (phase 5.3). Exact SQL, so any other
# unscoped query (or a change to this one) still fails the guard below. Its only caller is checked separately.
OWNER_CROSS_GROUP_READS = {
    ("licensing/postgres_store.py", "SELECT <X> FROM telegram_groups ORDER BY updated_at DESC, group_id LIMIT $1"),
}


class StaticSqlGuards(unittest.TestCase):
    def test_no_code_updates_or_deletes_audit_tables(self):
        pattern = re.compile(r"(UPDATE|DELETE\s+FROM|TRUNCATE)\s+(license_audit_log|security_audit_log)", re.I)
        for path in SRC.rglob("*.py"):
            self.assertIsNone(pattern.search(path.read_text(encoding="utf-8")), path.name)

    def test_every_group_table_query_in_group_stores_filters_by_group(self):
        import ast

        for rel in ("groups/postgres_store.py", "licensing/postgres_store.py", "moderation/postgres_store.py", "reports/postgres_store.py",
                    "stats/postgres_store.py", "stats/schedule_postgres_store.py"):
            tree = ast.parse((SRC / rel).read_text(encoding="utf-8"))
            found = 0
            for node in ast.walk(tree):
                if (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                        and node.func.attr in {"execute", "fetch", "fetchrow", "fetchval"} and node.args):
                    arg = node.args[0]
                    if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                        sql = arg.value
                    elif isinstance(arg, ast.JoinedStr):  # f-string: keep literal parts only
                        sql = "".join(v.value if isinstance(v, ast.Constant) else "<X>" for v in arg.values)
                    else:
                        continue
                    found += 1
                    sql = " ".join(sql.split())
                    if (rel, sql) in OWNER_CROSS_GROUP_READS:
                        continue
                    self.assertTrue("group_id = $1" in sql or "VALUES ($1" in sql, (rel, sql))
            self.assertGreater(found, 1 if rel.startswith("stats/") else 6, rel)  # the stats stores have just 2 (counters) / 3 (schedule) statements

    def test_the_cross_group_license_listing_is_only_called_by_the_owner_surfaces(self):
        """Owner-only surfaces: the private owner panel (5.3) and the owner hub statistics (5.5, sent only to OWNER_GROUP_ID)."""
        callers = sorted(str(p.relative_to(SRC)) for p in SRC.rglob("*.py")
                         if re.search(r"\.list_all\(", p.read_text(encoding="utf-8")))
        self.assertEqual(callers, ["owner_hub/reports.py", "owner_panel/service.py"])

    def test_migration_files_are_ordered_unique_and_contain_required_objects(self):
        versions = [v for v, _ in discover()]
        self.assertEqual(versions[:11], ["0001_initial", "0002_security_and_access", "0003_moderation_records",
                                    "0004_members_welcome_verification", "0005_settings_templates", "0006_audit_trace", "0007_audit_retention", "0008_group_reports", "0009_daily_counters", "0010_report_schedule", "0011_content_filter"])
        sql = (SQL_DIR / "0002_security_and_access.sql").read_text(encoding="utf-8")
        for needle in (
            "CREATE TRIGGER license_audit_no_update_delete", "CREATE TRIGGER license_audit_no_truncate",
            "CREATE TRIGGER security_audit_no_update_delete", "FOR EACH STATEMENT",
            "CREATE TABLE IF NOT EXISTS group_delegations", "CREATE UNIQUE INDEX IF NOT EXISTS uq_group_delegations_live",
            "CREATE TABLE IF NOT EXISTS group_trusted_users", "PRIMARY KEY (group_id, user_id)",
            "CREATE TABLE IF NOT EXISTS group_settings", "CREATE TABLE IF NOT EXISTS idempotency_keys",
            "CREATE TABLE IF NOT EXISTS moderation_warnings", "CREATE TABLE IF NOT EXISTS moderation_sanctions",
            "telegram_groups_negative_id", "telegram_groups_active_has_activation", "ON DELETE RESTRICT",
        ):
            self.assertIn(needle, sql)
        # every table that holds per-group data references telegram_groups (or is the audit exception)
        for table in ("group_settings", "group_delegations", "group_trusted_users", "moderation_warnings",
                      "moderation_sanctions"):
            block = sql[sql.index(f"CREATE TABLE IF NOT EXISTS {table}"):]
            block = block[: block.index(");")]
            self.assertIn("REFERENCES telegram_groups (group_id)", block, table)

    def test_0001_is_untouched(self):
        import hashlib
        digest = hashlib.sha256((SQL_DIR / "0001_initial.sql").read_bytes()).hexdigest()
        self.assertEqual(digest, "72b784563aecb473e545c6dbef156574981583396a2c0b9f271569710d266d81")

    def test_status_lists_match_between_python_and_sql(self):
        sql = (SQL_DIR / "0002_security_and_access.sql").read_text(encoding="utf-8")
        values = {s.value for s in S}
        for found in re.findall(r"IN\s*\(\s*((?:'[a-z_]+',?\s*)+)\)", sql):
            names = set(re.findall(r"'([a-z_]+)'", found))
            if names & values:
                self.assertTrue(names <= values | {"ar", "en", "group_manager", "moderator", "mute", "ban", "kick"}, names)


class MigrationRunnerTests(unittest.IsolatedAsyncioTestCase):
    async def test_all_migrations_apply_in_order_on_empty_db(self):
        conn = FakeConn()
        applied = await run_migrations(conn)
        self.assertEqual(applied, ["0001_initial", "0002_security_and_access", "0003_moderation_records",
                                    "0004_members_welcome_verification", "0005_settings_templates", "0006_audit_trace", "0007_audit_retention", "0008_group_reports", "0009_daily_counters", "0010_report_schedule", "0011_content_filter", "0012_content_default_words", "0013_member_activity_stats"])
        again = await run_migrations(FakeConn(applied=dict(conn.applied)))
        self.assertEqual(again, [])


if __name__ == "__main__":
    unittest.main()
