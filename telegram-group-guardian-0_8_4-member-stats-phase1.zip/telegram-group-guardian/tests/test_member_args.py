"""Phase 4 / part 4.6: strict parsers of /welcome /verify /newbie (member_args.py) + the command-parser integration."""
import unittest

from guardian.members import settings as ms
from guardian.moderation.commands import Command, CommandError, parse_command
from guardian.moderation.member_args import parse_newbie_args, parse_verify_args, parse_welcome_args


def welcome(text):
    p = parse_command(text)
    return parse_welcome_args(p.args, p.raw)


def code(fn, *a):
    with unittest.TestCase().assertRaises(CommandError) as cm:
        fn(*a)
    return cm.exception.code


class WelcomeArgs(unittest.TestCase):
    def test_show_toggle_reset_vars(self):
        self.assertEqual(welcome("/welcome").op, "show")
        self.assertEqual(welcome("/welcome show").op, "show")
        self.assertEqual(welcome("/welcome vars").op, "vars")
        self.assertEqual(welcome("/welcome on").patch, {"welcome_enabled": True})
        self.assertEqual(welcome("/welcome off").patch, {"welcome_enabled": False})
        self.assertEqual(welcome("/welcome reset").patch, {"welcome_text": None})

    def test_set_keeps_spacing_newlines_and_long_text_beyond_the_word_cap(self):
        text = "أهلًا {name}\n\nفي  {group}  " + " ".join(["كلمة"] * 60)
        self.assertGreater(len(text.split()), 20)  # more words than the generic argument cap
        r = welcome("/welcome set " + text)
        self.assertEqual(r.patch, {"welcome_text": text.strip()})
        self.assertIn("\n\n", r.patch["welcome_text"])
        self.assertIn("  {group}", r.patch["welcome_text"])

    def test_set_rejects_empty_unknown_variables_unbalanced_and_oversized(self):
        self.assertEqual(code(parse_welcome_args, ("set",), "set"), "welcome_need_text")
        self.assertEqual(code(parse_welcome_args, ("set",), "set   "), "welcome_need_text")
        for bad in ("hi {nope}", "hi {name", "hi {name.__class__}", "hi {id:>10}", "hi }", "x" * (ms.TEMPLATE_MAX_CHARS + 1)):
            self.assertEqual(code(parse_welcome_args, ("set", "x"), "set " + bad), "welcome_bad_template", bad)
        ok = "x" * ms.TEMPLATE_MAX_CHARS  # exactly at the limit is fine
        self.assertEqual(parse_welcome_args(("set", "x"), "set " + ok).patch, {"welcome_text": ok})
        self.assertEqual(parse_welcome_args(("set", "x"), "set {{literal}} {name}").patch,
                         {"welcome_text": "{{literal}} {name}"})

    def test_set_without_raw_text_is_refused_never_guessed(self):
        self.assertEqual(code(parse_welcome_args, ("set", "hello"), ""), "welcome_need_text")

    def test_delete_previous_join_leave(self):
        self.assertEqual(welcome("/welcome delete 5m").patch, {"welcome_delete_after_seconds": 300})
        self.assertEqual(welcome("/welcome delete off").patch, {"welcome_delete_after_seconds": 0})
        self.assertEqual(welcome("/welcome delete 10").patch, {"welcome_delete_after_seconds": 10})
        self.assertEqual(welcome("/welcome previous off").patch, {"welcome_delete_previous": False})
        self.assertEqual(welcome("/welcome join delete").patch, {"join_service": "delete"})
        self.assertEqual(welcome("/welcome leave keep").patch, {"leave_service": "keep"})

    def test_bounds_equal_the_settings_bounds(self):
        lo, hi = ms.WELCOME_DELETE_AFTER
        self.assertEqual(welcome(f"/welcome delete {lo}").patch["welcome_delete_after_seconds"], lo)
        self.assertEqual(welcome(f"/welcome delete {hi}").patch["welcome_delete_after_seconds"], hi)
        for bad in (lo - 1, hi + 1):
            self.assertEqual(code(welcome, f"/welcome delete {bad}"), "welcome_range")
        self.assertEqual(welcome("/welcome delete 0").patch, {"welcome_delete_after_seconds": 0})  # 0 = keep (same as off)
        # every accepted value survives from_raw unchanged
        for n in (lo, 60, hi):
            self.assertEqual(ms.WelcomeSettings.from_raw(welcome(f"/welcome delete {n}").patch).welcome_delete_after_seconds, n)

    def test_unknown_or_extra_words_are_errors(self):
        for text in ("/welcome maybe", "/welcome on now", "/welcome reset x", "/welcome delete", "/welcome delete 5m 6m",
                     "/welcome join maybe", "/welcome previous perhaps", "/welcome vars x"):
            self.assertEqual(code(welcome, text), "welcome_args", text)

    def test_arabic_vocabulary(self):
        self.assertEqual(welcome("الترحيب تفعيل").patch, {"welcome_enabled": True})
        self.assertEqual(welcome("الترحيب تعطيل").patch, {"welcome_enabled": False})
        self.assertEqual(welcome("الترحيب ضبط اهلا بك {name}").patch, {"welcome_text": "اهلا بك {name}"})
        self.assertEqual(welcome("الترحيب حذف ٥m").patch, {"welcome_delete_after_seconds": 300})
        self.assertEqual(welcome("الترحيب الانضمام حذف").patch, {"join_service": "delete"})
        self.assertEqual(welcome("الترحيب المغادرة ابقاء").patch, {"leave_service": "keep"})


class VerifyArgs(unittest.TestCase):
    def v(self, *words):
        return parse_verify_args(words)

    def test_each_setting(self):
        self.assertEqual(self.v().op, "show")
        self.assertEqual(self.v("on").patch, {"verify_enabled": True})
        self.assertEqual(self.v("off").patch, {"verify_enabled": False})
        self.assertEqual(self.v("scope", "suspicious").patch, {"verify_scope": "suspicious"})
        self.assertEqual(self.v("method", "math").patch, {"verify_method": "math"})
        self.assertEqual(self.v("timeout", "5m").patch, {"verify_timeout_seconds": 300})
        self.assertEqual(self.v("attempts", "5").patch, {"verify_max_attempts": 5})
        self.assertEqual(self.v("failure", "kick").patch, {"verify_failure": "kick"})
        self.assertEqual(self.v("failure", "ban").patch, {"verify_failure": "ban"})
        self.assertEqual(self.v("failure", "ban", "2h").patch, {"verify_failure": "ban", "verify_ban_seconds": 7200})

    def test_arabic_words(self):
        self.assertEqual(self.v("النطاق", "المشبوهين").patch, {"verify_scope": "suspicious"})
        self.assertEqual(self.v("الطريقة", "رمز").patch, {"verify_method": "choice"})
        self.assertEqual(self.v("الطريقة", "موافقة").patch, {"verify_method": "admin"})
        self.assertEqual(self.v("الفشل", "طرد").patch, {"verify_failure": "kick"})
        self.assertEqual(self.v("المحاولات", "٣").patch, {"verify_max_attempts": 3})

    def test_bounds_and_parity_with_settings(self):
        lo, hi = ms.VERIFY_TIMEOUT
        self.assertEqual(self.v("timeout", str(lo)).patch["verify_timeout_seconds"], lo)
        self.assertEqual(self.v("timeout", str(hi)).patch["verify_timeout_seconds"], hi)
        for bad in (str(lo - 1), str(hi + 1), "0"):
            self.assertEqual(code(parse_verify_args, ("timeout", bad)), "verify_range", bad)
        self.assertEqual(code(parse_verify_args, ("timeout", "soon")), "verify_args")
        a_lo, a_hi = ms.VERIFY_ATTEMPTS
        self.assertEqual(self.v("attempts", str(a_hi)).patch["verify_max_attempts"], a_hi)
        for bad in ("0", str(a_hi + 1), "9999"):
            self.assertEqual(code(parse_verify_args, ("attempts", bad)), "verify_range", bad)
        self.assertEqual(code(parse_verify_args, ("attempts", "x")), "verify_args")
        b_lo, b_hi = ms.VERIFY_BAN
        self.assertEqual(self.v("failure", "ban", f"{b_hi}s").patch["verify_ban_seconds"], b_hi)
        for bad in (f"{b_lo - 1}s", f"{b_hi + 1}s"):
            self.assertEqual(code(parse_verify_args, ("failure", "ban", bad)), "verify_range", bad)
        for patch in (self.v("method", "choice").patch, self.v("scope", "all").patch, self.v("failure", "ban", "1h").patch):
            eff = ms.VerificationSettings.from_raw(patch)
            for key, value in patch.items():
                self.assertEqual(getattr(eff, key), value)

    def test_unknown_or_extra_words_are_errors(self):
        for words in (("maybe",), ("on", "x"), ("scope",), ("scope", "x"), ("method", "captcha"), ("failure",),
                      ("failure", "restrict", "1h"), ("failure", "ban", "1h", "x"), ("timeout", "5m", "6m")):
            self.assertEqual(code(parse_verify_args, words), "verify_args", words)


class NewbieArgs(unittest.TestCase):
    def n(self, *words):
        return parse_newbie_args(words)

    def test_window_flags_off(self):
        self.assertEqual(self.n().op, "show")
        self.assertEqual(self.n("1h").patch, {"newbie_seconds": 3600})
        self.assertEqual(self.n("off").patch, {"newbie_seconds": 0})
        self.assertEqual(self.n("links", "off").patch, {"newbie_block_links": False})
        self.assertEqual(self.n("media", "on").patch, {"newbie_block_media": True})
        self.assertEqual(self.n("messages", "on").patch, {"newbie_block_messages": True})
        self.assertEqual(self.n("الروابط", "ايقاف").patch, {"newbie_block_links": False})

    def test_bounds(self):
        lo, hi = ms.NEWBIE_WINDOW
        self.assertEqual(self.n(f"{lo}s").patch["newbie_seconds"], lo)
        self.assertEqual(self.n("30d").patch["newbie_seconds"], hi)
        for bad in (f"{lo - 1}s", "31d", "0"):
            self.assertEqual(code(parse_newbie_args, (bad,)), "newbie_range", bad)
        self.assertEqual(ms.NewMemberPolicy.from_raw(self.n("30d").patch).newbie_seconds, hi)

    def test_unknown_or_extra_words_are_errors(self):
        for words in (("soon",), ("1h", "x"), ("links",), ("links", "maybe"), ("off", "x"), ("show", "x")):
            self.assertEqual(code(parse_newbie_args, words), "newbie_args", words)


class CommandParser(unittest.TestCase):
    def test_slash_forms_and_bot_suffix(self):
        self.assertIs(parse_command("/welcome").command, Command.WELCOME)
        self.assertIs(parse_command("/verify@GuardianBot on", "GuardianBot").command, Command.VERIFY)
        self.assertIsNone(parse_command("/verify@OtherBot on", "GuardianBot"))
        self.assertIs(parse_command("/newbie 1h").command, Command.NEWBIE)
        self.assertIs(parse_command("/settings").command, Command.SETTINGS)

    def test_only_welcome_carries_raw(self):
        self.assertEqual(parse_command("/welcome set a  b").raw, "set a  b")
        self.assertEqual(parse_command("/verify on").raw, "")
        self.assertEqual(parse_command("/newbie 1h").raw, "")

    def test_arabic_aliases_need_the_commands_own_vocabulary(self):
        for chat in ("التحقق", "الترحيب", "الترحيب بكم جميعا", "التحقق من الهوية مطلوب", "الاعضاء الجدد", "الاعضاء الجدد كثيرون",
                     "اعدادات المجموعة كلها", "اعدادات", "الاعدادات"):
            self.assertIsNone(parse_command(chat), chat)
        self.assertIs(parse_command("الترحيب تفعيل").command, Command.WELCOME)
        self.assertIs(parse_command("التحقق تفعيل").command, Command.VERIFY)
        self.assertIs(parse_command("التحقق من الاعضاء الطريقة زر").command, Command.VERIFY)
        self.assertIs(parse_command("الاعضاء الجدد 1h").command, Command.NEWBIE)
        self.assertIs(parse_command("اعدادات المجموعة").command, Command.SETTINGS)
        self.assertIs(parse_command("عرض الاعدادات").command, Command.SETTINGS)

    def test_existing_commands_unchanged(self):
        self.assertIs(parse_command("/ban 5").command, Command.BAN)
        self.assertIs(parse_command("حظر @abcde").command, Command.BAN)
        self.assertIs(parse_command("اعدادات الحماية").command, Command.PROTECT)
        self.assertEqual(parse_command("/ban 5").raw, "")


if __name__ == "__main__":
    unittest.main()


class MessagesMatchBounds(unittest.TestCase):
    def test_error_messages_format_without_values_and_state_the_real_limits(self):
        from guardian.i18n import MESSAGES
        from guardian.moderation.messages import error_message
        for lang in ("ar", "en"):
            for c in ("welcome_args", "welcome_need_text", "welcome_bad_template", "welcome_range", "verify_args",
                      "verify_range", "newbie_args", "newbie_range"):
                text = error_message(CommandError(c), lang)  # `t` formats with no values: a stray {placeholder} would raise
                self.assertTrue(text, (lang, c))
            self.assertIn(str(ms.TEMPLATE_MAX_CHARS), MESSAGES[lang]["mod_err_welcome_bad_template"])
        self.assertEqual(ms.WELCOME_DELETE_AFTER, (10, 86400))  # texts say 10 seconds .. 24 hours
        self.assertEqual(ms.VERIFY_TIMEOUT, (60, 86400))
        self.assertEqual(ms.VERIFY_BAN, (60, 7 * 86400))
        self.assertEqual(ms.NEWBIE_WINDOW, (60, 30 * 86400))
