"""Phase 4 / part 3: welcome messages + join/leave service-message control.

The fake Bot mirrors aiogram 3's `send_message` / `delete_message` keywords STRICTLY (unknown keyword => TypeError). It is
not the real aiogram: nothing here proves behaviour against the real library or Telegram (see HANDOFF.md)."""
import asyncio
import unittest
from types import SimpleNamespace as NS

from guardian.bot.actions import AiogramModerationActions
from guardian.bot import members_handler as h
from guardian.idempotency import InMemoryIdempotency
from guardian.members import welcome as w
from guardian.members.welcome import Joined, WelcomeService, build_welcome
from guardian.protection.engine import ActionResult, SendResult
from guardian.protection_gate import ProtectionGate
from stack import A, B, OWNER, STRANGER, Stack

CHAT = -1001234567890
U1, U2, U3 = 5001, 5002, 5003


class FakeActions:
    def __init__(self):
        self.sent, self.deleted = [], []
        self.next_id = 100
        self.send_ok = True
        self.delete_ok = True

    async def send_message(self, chat_id, text):
        self.sent.append((chat_id, text))
        if not self.send_ok:
            return SendResult(False, "forbidden")
        self.next_id += 1
        return SendResult(True, None, self.next_id)

    async def delete_message(self, chat_id, message_id):
        self.deleted.append((chat_id, message_id))
        return ActionResult(self.delete_ok, None if self.delete_ok else "forbidden")


class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A, B)
        await self.s.admin.activate_permanent(OWNER, A)
        await self.s.admin.activate_permanent(OWNER, B)
        self.actions = FakeActions()
        self.claims = InMemoryIdempotency()
        self.scheduled = []
        self.mono = [1000.0]
        self.svc = self.make()
        self.gate = ProtectionGate(self.s.license_service, self.s.perm, NS(notify_group=self._noop, notify_owner=self._noop),
                                   clock=self.s.clock)
        self.mid = 0

    async def _noop(self, *a, **k):
        return None

    def make(self, **kw):
        def schedule(delay, job):
            self.scheduled.append((delay, job))
            return True

        return WelcomeService(self.s.settings_store, self.actions, self.claims, self.s.license_service, clock=self.s.clock,
                              monotonic=lambda: self.mono[0], schedule=schedule, **kw)

    async def cfg(self, group=A, **patch):
        await self.s.settings_store.merge(group, patch, OWNER, self.s.clock())

    async def ctx(self, group=A):
        return await self.gate.evaluate(group, "supergroup", STRANGER)

    async def join(self, members=(Joined(U1, "Sara"),), group=A, mid=None, title="My Group"):
        self.mid += 1
        return await self.svc.on_join(await self.ctx(group), mid or self.mid, list(members), title)


class DefaultsAndLicense(Base):
    async def test_everything_is_off_by_default(self):
        out = await self.join()
        self.assertEqual((out.welcomed, out.reason), (False, "disabled"))
        self.assertEqual((self.actions.sent, self.actions.deleted), ([], []))

    async def test_enabled_group_gets_a_default_arabic_welcome_with_escaped_mention(self):
        await self.cfg(welcome_enabled=True)
        out = await self.join((Joined(U1, "<b>Sara</b> & co"),), title="G <i>")
        self.assertTrue(out.welcomed)
        chat, text = self.actions.sent[0]
        self.assertEqual(chat, A)
        self.assertIn(f'<a href="tg://user?id={U1}">&lt;b&gt;Sara&lt;/b&gt; &amp; co</a>', text)
        self.assertIn("G &lt;i&gt;", text)
        self.assertTrue(text.startswith("أهلًا بك"))

    async def test_group_language_selects_the_default_text(self):
        await self.cfg(welcome_enabled=True)
        await self.s.settings_store.set_language(A, "en", OWNER, self.s.clock())
        await self.join()
        self.assertTrue(self.actions.sent[0][1].startswith("Welcome"))

    async def test_pending_group_does_nothing_at_all(self):
        await self.s.register(-1003)  # registered => pending
        await self.cfg(group=-1003, welcome_enabled=True, join_service="delete", leave_service="delete")
        ctx = await self.ctx(-1003)
        self.assertFalse(ctx.allowed)
        out = await self.svc.on_join(ctx, 7, [Joined(U1, "x")], "t")
        self.assertEqual(out.reason, "not_allowed")
        self.assertFalse(await self.svc.on_leave(ctx, 8))
        self.assertEqual((self.actions.sent, self.actions.deleted), ([], []))

    async def test_expired_license_after_sleep_does_nothing_on_first_update(self):
        from datetime import timedelta
        await self.cfg(group=B, welcome_enabled=True, join_service="delete")
        await self.s.admin.activate_temporary(OWNER, B, self.s.clock() + timedelta(hours=1))
        self.assertTrue((await self.join(group=B)).welcomed)
        self.s.clock.advance(hours=5)  # the service "slept" past expires_at; no sweeper ran
        sent_before = len(self.actions.sent)
        out = await self.join(group=B)
        self.assertEqual((out.welcomed, out.reason), (False, "not_allowed"))
        self.assertEqual(len(self.actions.sent), sent_before)
        self.assertFalse(await self.svc.on_leave(await self.ctx(B), 99))

    async def test_stopped_license_blocks_even_with_everything_enabled(self):
        await self.cfg(welcome_enabled=True, join_service="delete")
        await self.s.admin.stop(OWNER, A)
        out = await self.join()
        self.assertEqual(out.reason, "not_allowed")
        self.assertEqual((self.actions.sent, self.actions.deleted), ([], []))

    async def test_settings_read_failure_fails_closed(self):
        await self.cfg(welcome_enabled=True)

        async def boom(_):
            raise RuntimeError("db down")

        self.s.settings_store.get = boom
        out = await self.join()
        self.assertEqual(out.reason, "settings_unavailable")
        self.assertEqual(self.actions.sent, [])

    async def test_readding_the_bot_does_not_change_the_license(self):
        before = (await self.s.licenses.get(A)).status
        await self.s.license_service.on_bot_added(A, "Group", self.s.clock())
        self.assertEqual((await self.s.licenses.get(A)).status, before)


class TemplateTests(Base):
    async def test_custom_template_variables(self):
        await self.cfg(welcome_enabled=True, welcome_text="Hi {name}! id={id} in {group} {{ok}}")
        await self.join((Joined(U1, "Sara"),), title="Club")
        text = self.actions.sent[0][1]
        self.assertIn("Hi <a href", text)
        self.assertIn(f"id={U1} in Club {{ok}}", text)

    async def test_template_text_is_escaped_not_trusted_as_html(self):
        await self.cfg(welcome_enabled=True, welcome_text="<a href='http://evil'>click</a> {name}")
        await self.join()
        text = self.actions.sent[0][1]
        self.assertNotIn("<a href='http://evil'>", text)
        self.assertIn("&lt;a href='http://evil'&gt;click&lt;/a&gt;", text)

    async def test_invalid_template_falls_back_to_default(self):
        await self.cfg(welcome_enabled=True, welcome_text="{name.__class__} {secret}")
        await self.join()
        self.assertTrue(self.actions.sent[0][1].startswith("أهلًا بك"))

    async def test_values_are_never_reinterpreted_as_a_template(self):
        text = build_welcome("Hi {name}", "en", [Joined(U1, "{group}{0}{id}")], "{name}")
        self.assertIn("{group}{0}{id}", text)

    async def test_several_members_one_message(self):
        text = build_welcome("{name}|{id}", "ar", [Joined(U1, "a"), Joined(U2, "b"), Joined(U3, "c"), Joined(5004, "d")], "g")
        self.assertEqual(text.count("<a href"), 3)
        self.assertTrue(text.endswith(f"+1|{U1}"))

    async def test_long_names_and_titles_are_clipped(self):
        text = build_welcome("{name} {group}", "en", [Joined(U1, "n" * 500)], "t" * 500)
        self.assertLess(len(text), 400)

    async def test_empty_name_falls_back_to_id(self):
        self.assertIn(f">{U1}</a>", build_welcome("{name}", "en", [Joined(U1, "   ")], "g"))


class WhoIsWelcomed(Base):
    async def test_bots_and_the_bot_itself_are_never_welcomed(self):
        await self.cfg(welcome_enabled=True)
        out = await self.join((Joined(777, "MyBot", True), Joined(888, "OtherBot", True)))
        self.assertEqual(out.reason, "no_humans")
        out = await self.join((Joined(777, "MyBot", True), Joined(U1, "Sara")))
        self.assertTrue(out.welcomed)
        self.assertEqual(self.actions.sent[0][1].count("<a href"), 1)

    async def test_invalid_ids_are_ignored(self):
        await self.cfg(welcome_enabled=True)
        out = await self.join((Joined(0, "z"), Joined(-5, "n")))
        self.assertEqual(out.reason, "no_humans")


class IdempotencyAndRate(Base):
    async def test_redelivered_join_message_is_welcomed_once(self):
        await self.cfg(welcome_enabled=True)
        self.assertTrue((await self.join(mid=50)).welcomed)
        out = await self.join(mid=50)
        self.assertEqual((out.welcomed, out.reason), (False, "duplicate"))
        self.assertEqual(len(self.actions.sent), 1)

    async def test_same_message_id_in_another_group_is_independent(self):
        await self.cfg(group=A, welcome_enabled=True)
        await self.cfg(group=B, welcome_enabled=True)
        self.assertTrue((await self.join(mid=50, group=A)).welcomed)
        self.assertTrue((await self.join(mid=50, group=B)).welcomed)

    async def test_claim_store_failure_means_no_welcome(self):
        await self.cfg(welcome_enabled=True)

        async def boom(*a, **k):
            raise RuntimeError("down")

        self.claims.claim = boom
        out = await self.join()
        self.assertEqual((out.welcomed, out.reason), (False, "claim_unavailable"))
        self.assertEqual(self.actions.sent, [])

    async def test_burst_limit_per_group_then_recovers(self):
        await self.cfg(welcome_enabled=True)
        results = [await self.join() for _ in range(w.BURST_LIMIT + 2)]
        self.assertEqual([r.welcomed for r in results], [True] * w.BURST_LIMIT + [False, False])
        self.assertEqual(results[-1].reason, "rate_limited")
        self.mono[0] += w.BURST_WINDOW + 1
        self.assertTrue((await self.join()).welcomed)

    async def test_burst_in_one_group_does_not_limit_another(self):
        await self.cfg(group=A, welcome_enabled=True)
        await self.cfg(group=B, welcome_enabled=True)
        for _ in range(w.BURST_LIMIT + 1):
            await self.join(group=A)
        self.assertTrue((await self.join(group=B)).welcomed)

    async def test_join_without_message_id_is_not_welcomed(self):
        await self.cfg(welcome_enabled=True)
        out = await self.svc.on_join(await self.ctx(), None, [Joined(U1, "a")], "t")
        self.assertFalse(out.welcomed)


class DeleteBehaviour(Base):
    async def test_previous_welcome_deleted_after_the_new_one_is_sent(self):
        await self.cfg(welcome_enabled=True)
        await self.join()
        self.assertEqual(self.actions.deleted, [])
        await self.join()
        self.assertEqual(self.actions.deleted, [(A, 101)])

    async def test_keep_previous_when_disabled(self):
        await self.cfg(welcome_enabled=True, welcome_delete_previous=False)
        await self.join()
        await self.join()
        self.assertEqual(self.actions.deleted, [])

    async def test_failed_send_keeps_the_old_welcome(self):
        await self.cfg(welcome_enabled=True)
        await self.join()
        self.actions.send_ok = False
        out = await self.join()
        self.assertEqual(out.reason, "send_failed")
        self.assertEqual(self.actions.deleted, [])

    async def test_previous_welcome_is_per_group(self):
        await self.cfg(group=A, welcome_enabled=True)
        await self.cfg(group=B, welcome_enabled=True)
        await self.join(group=A)
        await self.join(group=B)
        self.assertEqual(self.actions.deleted, [])  # B's first welcome must not delete A's

    async def test_timed_delete_is_scheduled_and_rechecks_license(self):
        await self.cfg(welcome_enabled=True, welcome_delete_after_seconds=60)
        await self.join()
        (delay, job), = self.scheduled
        self.assertEqual(delay, 60.0)
        await self.s.admin.stop(OWNER, A)
        await job()
        self.assertEqual(self.actions.deleted, [])  # license ended meanwhile: no automatic action

    async def test_timed_delete_runs_when_still_licensed(self):
        await self.cfg(welcome_enabled=True, welcome_delete_after_seconds=60)
        await self.join()
        await self.scheduled[0][1]()
        self.assertEqual(self.actions.deleted, [(A, 101)])

    async def test_no_timer_when_zero(self):
        await self.cfg(welcome_enabled=True)
        await self.join()
        self.assertEqual(self.scheduled, [])

    async def test_default_scheduler_runs_and_aclose_cancels(self):
        slept = []

        async def fake_sleep(d):
            slept.append(d)

        svc = WelcomeService(self.s.settings_store, self.actions, self.claims, self.s.license_service, clock=self.s.clock,
                             sleep=fake_sleep)
        await self.cfg(welcome_enabled=True, welcome_delete_after_seconds=30)
        await svc.on_join(await self.ctx(), 1, [Joined(U1, "a")], "t")
        for _ in range(5):
            await asyncio.sleep(0)
        self.assertEqual(slept, [30.0])
        self.assertEqual(self.actions.deleted, [(A, 101)])
        await svc.aclose()

        gate = asyncio.Event()

        async def blocked(_):
            await gate.wait()

        svc2 = WelcomeService(self.s.settings_store, self.actions, self.claims, self.s.license_service, clock=self.s.clock,
                              sleep=blocked)
        await svc2.on_join(await self.ctx(), 2, [Joined(U1, "a")], "t")
        await asyncio.sleep(0)
        self.assertEqual(len(svc2._tasks), 1)
        await svc2.aclose()
        self.assertEqual(len(svc2._tasks), 0)


class ServiceMessages(Base):
    async def test_join_service_kept_by_default_deleted_on_request(self):
        await self.join(mid=10)
        self.assertEqual(self.actions.deleted, [])
        await self.cfg(join_service="delete")
        out = await self.join(mid=11)
        self.assertEqual((out.service_deleted, self.actions.deleted), (True, [(A, 11)]))

    async def test_join_service_delete_works_with_welcome_disabled(self):
        await self.cfg(join_service="delete", welcome_enabled=False)
        out = await self.join(mid=12)
        self.assertEqual((out.reason, out.service_deleted), ("disabled", True))

    async def test_leave_service_control(self):
        ctx = await self.ctx()
        self.assertFalse(await self.svc.on_leave(ctx, 20))
        await self.cfg(leave_service="delete")
        self.assertTrue(await self.svc.on_leave(ctx, 21))
        self.assertEqual(self.actions.deleted, [(A, 21)])

    async def test_leave_setting_does_not_affect_other_groups(self):
        await self.cfg(group=A, leave_service="delete")
        self.assertFalse(await self.svc.on_leave(await self.ctx(B), 22))
        self.assertEqual(self.actions.deleted, [])

    async def test_dry_run_never_deletes_service_messages(self):
        await self.cfg(join_service="delete", leave_service="delete", dry_run=True)
        out = await self.join(mid=30)
        self.assertFalse(out.service_deleted)
        self.assertFalse(await self.svc.on_leave(await self.ctx(), 31))
        self.assertEqual(self.actions.deleted, [])

    async def test_delete_failure_is_reported_not_raised(self):
        await self.cfg(join_service="delete")
        self.actions.delete_ok = False
        self.assertFalse((await self.join(mid=40)).service_deleted)

    async def test_invalid_setting_values_fall_back_to_keep(self):
        await self.cfg(join_service="purge", leave_service=True, welcome_enabled="yes")
        out = await self.join(mid=41)
        self.assertEqual((out.reason, self.actions.deleted), ("disabled", []))


class HandlerTests(Base):
    def message(self, members, mid=9, title="Club"):
        return NS(message_id=mid, chat=NS(title=title), new_chat_members=members)

    def services(self):
        return NS(welcome=self.svc)

    async def test_handler_maps_telegram_users(self):
        await self.cfg(welcome_enabled=True)
        users = [NS(id=U1, full_name="Sara K", is_bot=False), NS(id=777, full_name="Bot", is_bot=True)]
        await h.on_new_members(self.message(users), await self.ctx(), self.services())
        self.assertEqual(len(self.actions.sent), 1)
        self.assertIn("Sara K", self.actions.sent[0][1])
        self.assertIn("Club", self.actions.sent[0][1])

    async def test_handler_does_nothing_without_license_or_context_or_service(self):
        await self.s.register(-1004)
        await self.cfg(group=-1004, welcome_enabled=True)
        users = [NS(id=U1, full_name="x", is_bot=False)]
        await h.on_new_members(self.message(users), await self.ctx(-1004), self.services())
        await h.on_new_members(self.message(users), None, self.services())
        await h.on_new_members(self.message(users), await self.ctx(), NS(welcome=None))
        await h.on_left_member(NS(message_id=1), None, self.services())
        self.assertEqual((self.actions.sent, self.actions.deleted), ([], []))

    async def test_handler_itself_never_calls_the_service_without_a_license(self):
        calls = []

        class Rec:
            async def on_join(self, *a):
                calls.append("join")

            async def on_leave(self, *a):
                calls.append("leave")

        await self.s.register(-1005)
        denied = await self.ctx(-1005)
        self.assertFalse(denied.allowed)
        await h.on_new_members(self.message([NS(id=U1, full_name="a", is_bot=False)]), denied, NS(welcome=Rec()))
        await h.on_left_member(NS(message_id=3), denied, NS(welcome=Rec()))
        self.assertEqual(calls, [])
        await h.on_new_members(self.message([NS(id=U1, full_name="a", is_bot=False)]), await self.ctx(), NS(welcome=Rec()))
        await h.on_left_member(NS(message_id=3), await self.ctx(), NS(welcome=Rec()))
        self.assertEqual(calls, ["join", "leave"])

    async def test_handler_swallows_service_errors(self):
        class Boom:
            async def on_join(self, *a):
                raise RuntimeError("x")

            async def on_leave(self, *a):
                raise RuntimeError("x")

        ctx = await self.ctx()
        await h.on_new_members(self.message([NS(id=U1, full_name="a", is_bot=False)]), ctx, NS(welcome=Boom()))
        await h.on_left_member(NS(message_id=3), ctx, NS(welcome=Boom()))

    async def test_handler_ignores_malformed_members(self):
        self.assertEqual(h.joined_members(NS(new_chat_members=[NS(id="x"), NS(id=True), NS(id=U1, first_name="F")])),
                         [Joined(U1, "F", False)])


# ------------------------------------------------------------------ adapter (signature-strict fake Bot)
class TelegramForbiddenError(Exception): ...


class StrictBot:
    def __init__(self):
        self.calls = []
        self.error = None
        self.returned = NS(message_id=555)

    async def send_message(self, chat_id, text, *, parse_mode=None, disable_notification=None):
        self.calls.append(("send_message", chat_id, text, parse_mode, disable_notification))
        if self.error:
            raise self.error
        return self.returned


class AdapterTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.bot = StrictBot()
        self.act = AiogramModerationActions(self.bot)

    async def test_success_returns_the_message_id_and_sends_silent_html(self):
        r = await self.act.send_message(CHAT, "hello")
        self.assertEqual((r.ok, r.error, r.message_id), (True, None, 555))
        self.assertEqual(self.bot.calls, [("send_message", CHAT, "hello", "HTML", True)])

    async def test_refuses_bad_input_without_calling_telegram(self):
        for chat, text in ((0, "x"), (True, "x"), (CHAT, ""), (CHAT, "   "), (CHAT, "x" * 4097), (CHAT, None)):
            self.assertFalse((await self.act.send_message(chat, text)).ok)
        self.assertEqual(self.bot.calls, [])

    async def test_telegram_failure_becomes_a_result(self):
        self.bot.error = TelegramForbiddenError("bot was kicked SECRET")
        r = await self.act.send_message(CHAT, "hello")
        self.assertEqual((r.ok, r.error, r.message_id), (False, "forbidden", None))

    async def test_unusable_returned_id_is_not_tracked(self):
        for bad in (NS(message_id=None), NS(message_id=0), NS(message_id=True), NS()):
            self.bot.returned = bad
            self.assertFalse((await self.act.send_message(CHAT, "hello")).ok)


if __name__ == "__main__":
    unittest.main()
