"""Part 6.5b: the `/stats [day|week|month]` command (group: moderators of THIS group; private: the primary owner, all groups),
its strict arguments, rendering, menu/help registration and the safety properties (gates first, no cross-group data, read only).
PostgreSQL / aiogram / Telegram are NOT exercised (fakes only)."""
from __future__ import annotations

import re
import string
import unittest
from pathlib import Path
from types import SimpleNamespace as NS

from executor_stack import A, B, BOT, BOT_NAME, OTHER, USER, ExecBase, gate
from guardian.audit import InMemorySecurityAudit
from guardian.bot import commands_menu
from guardian.bot import moderation_handler as mh
from guardian.bot import owner_panel_handler as oh
from guardian.errors import PermissionDenied
from guardian.i18n import MESSAGES, t
from guardian.moderation.commands import STATS_COMMANDS, Command, CommandError, parse_command
from guardian.moderation.executor import ModerationCommandService, ResultKind as R
from guardian.owner_panel.service import OwnerPanelService
from guardian.stats import CounterRecorder, GroupStats, StatsPeriod, StatsService, args as sa
from guardian.stats.memory_store import InMemoryCounterStore
from guardian.stats.owner_command import OwnerStatsService, match
from guardian.stats.render import MAX_AUDIT_LINES, render
from stack import BACKUP, NOW, OWNER, STRANGER, TG_ADMIN, Stack
from test_stats import TZ, at, seeded

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src" / "guardian"


class Spy:
    """Wraps a StatsService; records the (group, period) of every read."""

    def __init__(self, inner=None, fail: bool = False):
        self.inner, self.fail, self.calls = inner, fail, []

    async def group_stats(self, group_id, period=StatsPeriod.DAY, now=None):
        self.calls.append((group_id, period))
        if self.fail:
            raise RuntimeError("stats store down")
        return await self.inner.group_stats(group_id, period, now)

    async def overall(self, group_ids, period=StatsPeriod.DAY, now=None):
        self.calls.append((tuple(group_ids), period))
        if self.fail:
            raise RuntimeError("stats store down")
        return await self.inner.overall(group_ids, period, now)


# ------------------------------------------------------------------------------------------------ arguments
class ArgsTests(unittest.TestCase):
    def test_default_is_today_and_words_in_both_languages(self):
        self.assertIs(sa.parse_period(()), StatsPeriod.DAY)
        for words, period in ((("day", "today", "اليوم", "يوم", "DAY"), StatsPeriod.DAY),
                              (("week", "weekly", "الأسبوع", "الاسبوع", "أسبوع", "اسبوعي"), StatsPeriod.WEEK),
                              (("month", "monthly", "الشهر", "شهر", "شهري"), StatsPeriod.MONTH)):
            for w in words:
                with self.subTest(w):
                    self.assertIs(sa.parse_period((w,)), period)

    def test_every_period_has_a_word_and_a_label(self):
        self.assertEqual(set(sa.PERIOD_WORDS.values()), set(StatsPeriod))
        for lang in ("ar", "en"):
            for p in StatsPeriod:
                self.assertIn(f"stats_period_{p.value}", MESSAGES[lang])

    def test_strict_errors(self):
        for args, code in ((("year",), "stats_period"), (("5",), "stats_period"), (("week", "month"), "stats_usage"),
                           (("week", "all"), "stats_usage"), (("all",), "stats_period"), (("-1001",), "stats_period")):
            with self.subTest(args), self.assertRaises(CommandError) as cm:
                sa.parse_period(args)
            self.assertEqual(cm.exception.code, code)

    def test_every_error_code_is_localized(self):
        for code in ("stats_usage", "stats_period"):
            for lang in ("ar", "en"):
                self.assertIn(f"mod_err_{code}", MESSAGES[lang])

    def test_alias_vocabulary_check(self):
        self.assertTrue(sa.alias_args_ok(()))
        self.assertTrue(sa.alias_args_ok(("الاسبوع",)))
        self.assertFalse(sa.alias_args_ok(("الماضي",)))
        self.assertFalse(sa.alias_args_ok(("اليوم", "كانت")))


class ParserTests(unittest.TestCase):
    def p(self, text, **kw):
        return parse_command(text, BOT_NAME, **kw)

    def test_slash_forms(self):
        self.assertIs(self.p("/stats").command, Command.STATS)
        self.assertEqual(self.p("/stats week").args, ("week",))
        self.assertIs(self.p(f"/STATS@{BOT_NAME} month").command, Command.STATS)
        self.assertIsNone(self.p("/stats@OtherBot week"))      # addressed to another bot
        self.assertIsNone(self.p("/statistics"))

    def test_arabic_aliases_are_whole_message_or_command_vocabulary(self):
        for text in ("الاحصائيات", "الإحصائيات", "احصائيات", "إحصائيات الأسبوع", "الاحصائيات الشهر", "احصائيات المجموعة",
                     "احصائيات المجموعة اليوم", "احصاءات"):
            with self.subTest(text):
                parsed = self.p(text)
                self.assertIsNotNone(parsed)
                self.assertIs(parsed.command, Command.STATS)
                self.assertTrue(parsed.arabic)

    def test_a_sentence_that_merely_starts_with_the_word_is_ordinary_chat(self):
        for text in ("احصائيات الاسبوع الماضي كانت سيئة", "الاحصائيات تقول ان", "احصائيات رائعة", "احصائيات المجموعة ممتازة"):
            with self.subTest(text):
                self.assertIsNone(self.p(text))
                self.assertIsNone(self.p(text, has_reply=True))

    def test_stats_is_a_moderator_command_not_public(self):
        from guardian.moderation.commands import PUBLIC
        self.assertNotIn(Command.STATS, PUBLIC)
        self.assertEqual(STATS_COMMANDS, {Command.STATS})


# ------------------------------------------------------------------------------------------------ rendering
class RenderTests(unittest.IsolatedAsyncioTestCase):
    async def test_group_view_matches_the_service_numbers(self):
        svc = await seeded()
        text = render(await svc.group_stats(A, StatsPeriod.DAY), "ar")
        for needle in ("إحصائيات المجموعة", "اليوم", "2026-10-29", "مخالفات تصرّف فيها البوت: 4", "أوامر منفَّذة: 6",
                       "أوامر مرفوضة: 1", "تلقائية: 1 • يدوية: 1 • مسحوبة: 1", "كتم: تلقائي 1 • يدوي 1", "رُفعت: 1",
                       "جديدة: 2 • مفتوحة الآن: 1", "سبام 1", "احتيال 1", "إجراء 1", "3 حدث", "permission_denied</code>: 2"):
            self.assertIn(needle, text)
        self.assertNotIn("113", text)            # group B's 99 violations never leak into group A
        self.assertNotIn("الإحصائيات الإجمالية", text)

    async def test_english_and_period_range_line(self):
        svc = await seeded()
        week = render(await svc.group_stats(A, StatsPeriod.WEEK), "en")
        self.assertIn("last 7 days", week)
        self.assertIn("2026-10-23 → 2026-10-29", week)
        self.assertIn("Violations the bot acted on: 14", week)

    async def test_overall_header_totals_and_cut_notice(self):
        svc = await seeded()
        total = await svc.overall([A, B], StatsPeriod.WEEK)
        text = render(total, "en", overall=True)
        self.assertIn("Overall statistics", text)
        self.assertIn("(2 groups)", text)
        self.assertIn("Violations the bot acted on: 113", text)
        self.assertNotIn("only the first", text.lower())
        self.assertIn("Only the first 500 groups", render(total, "en", overall=True, cut_at=500))

    async def test_a_missing_section_is_named_and_never_shown_as_zero(self):
        svc = await seeded()
        svc._audit = None
        svc._counters = None
        stats = await svc.group_stats(A, StatsPeriod.DAY)
        self.assertEqual(set(stats.missing), {"audit", "counters"})
        text = render(stats, "ar")
        self.assertIn("تعذّرت قراءة قسم «السجل الأمني»", text)
        self.assertIn("تعذّرت قراءة قسم «النشاط»", text)
        self.assertNotIn("مخالفات تصرّف فيها البوت", text)   # not a zero line
        self.assertNotIn("حدث\n", text)
        self.assertIn("البلاغات", text)                       # the readable sections are still shown

    def test_audit_lines_are_limited_sorted_and_escaped(self):
        rng = StatsPeriod.DAY
        from guardian.stats.models import period_range
        stats = GroupStats(A, period_range(rng, NOW, TZ), audit={f"e{i}": i + 1 for i in range(8)} | {"<b>x</b>": 20})
        text = render(stats, "en")
        self.assertEqual(text.count("• <code>"), MAX_AUDIT_LINES)
        self.assertIn("&lt;b&gt;x&lt;/b&gt;</code>: 20", text)
        self.assertNotIn("<b>x</b>", text)
        self.assertLess(text.index("&lt;b&gt;x"), text.index("e7"))   # most frequent first
        self.assertIn("and 4 more event types", text)

    async def test_it_fits_one_telegram_message_with_room_to_spare(self):
        svc = await seeded()
        self.assertLess(len(render(await svc.overall([A, B], StatsPeriod.MONTH), "ar", overall=True)), 1500)

    def test_i18n_keys_and_placeholders_match_between_languages(self):
        fmt = string.Formatter()
        keys = [k for k in MESSAGES["ar"] if k.startswith("stats_") or k.startswith("mod_err_stats_")]
        self.assertGreater(len(keys), 25)
        for key in keys:
            self.assertIn(key, MESSAGES["en"], key)
            names = lambda lang: {f for _, f, _, _ in fmt.parse(MESSAGES[lang][key]) if f}
            self.assertEqual(names("ar"), names("en"), key)


# ------------------------------------------------------------------------------------------------ group command
class GroupCommandTests(ExecBase):
    async def asyncSetUp(self):
        self.spy = Spy(await seeded())
        self.counter_store = InMemoryCounterStore()
        await super().asyncSetUp()

    def make_service(self, claims, stats="spy"):
        return ModerationCommandService(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions,
            settings_store=self.s.settings_store, actions=self.actions, chat_info=self.s.chat, claims=claims,
            audit=self.s.audit, bot_id=BOT, clock=self.s.clock, group_settings=self.s.settings,
            stats=self.spy if stats == "spy" else stats,
            counters=CounterRecorder(self.counter_store, TZ, self.s.clock))

    async def test_a_moderator_gets_this_groups_numbers(self):
        r = await self.run_cmd("/stats")
        self.assertIs(r.kind, R.INFO)
        self.assertTrue(r.ok)
        self.assertIs(r.command, Command.STATS)
        self.assertIn("مخالفات تصرّف فيها البوت: 4", r.text)
        self.assertEqual(self.spy.calls, [(A, StatsPeriod.DAY)])
        self.assertIsNone(r.redirect_chat_id)

    async def test_the_period_is_passed_through_in_both_languages(self):
        for text, period in (("/stats day", StatsPeriod.DAY), ("/stats week", StatsPeriod.WEEK), ("/stats month", StatsPeriod.MONTH),
                             ("الاحصائيات الاسبوع", StatsPeriod.WEEK), ("احصائيات الشهر", StatsPeriod.MONTH), ("الاحصائيات", StatsPeriod.DAY)):
            self.spy.calls.clear()
            with self.subTest(text):
                r = await self.run_cmd(text)
                self.assertIs(r.kind, R.INFO)
                self.assertEqual(self.spy.calls, [(A, period)])

    async def test_the_group_is_always_the_chat_never_the_text(self):
        # even a crafted id in the arguments is a parse error: the argument is never a group id
        r = await self.run_cmd(f"/stats {B}")
        self.assertIs(r.kind, R.INVALID)
        self.assertEqual(self.spy.calls, [])
        await self.run_cmd("/stats")
        self.assertEqual({c[0] for c in self.spy.calls}, {A})

    async def test_another_group_where_the_actor_is_no_moderator_is_denied_without_a_read(self):
        r = await self.run_cmd("/stats", actor=TG_ADMIN, chat=B, protection=gate(B, TG_ADMIN))   # TG_ADMIN administers only A
        self.assertIs(r.kind, R.DENIED)
        self.assertEqual(self.spy.calls, [])

    async def test_a_plain_member_is_denied_and_nothing_is_read(self):
        r = await self.run_cmd("/stats", actor=USER, protection=gate(A, USER))
        self.assertIs(r.kind, R.DENIED)
        self.assertNotIn("4", r.text)
        self.assertEqual(self.spy.calls, [])
        today = self.s.clock().date()
        self.assertEqual(await self.counter_store.totals(A, today, today), {"command_rejected": 1})

    async def test_a_blocked_licence_stops_it_before_any_read(self):
        for who in (TG_ADMIN, OWNER):
            r = await self.run_cmd("/stats", actor=who, protection=gate(A, who, allowed=False))
            self.assertIs(r.kind, R.LICENSE_OFF)
            self.assertNotIn("📊", r.text)
        r = await self.run_cmd("/stats", protection=None)
        self.assertIs(r.kind, R.LICENSE_OFF)
        r = await self.run_cmd("/stats", protection=gate(B, TG_ADMIN))   # a gate that belongs to ANOTHER chat
        self.assertIs(r.kind, R.LICENSE_OFF)
        self.assertEqual(self.spy.calls, [])

    async def test_the_owner_may_read_a_licensed_group(self):
        r = await self.run_cmd("/stats week", actor=OWNER, protection=gate(A, OWNER))
        self.assertIs(r.kind, R.INFO)
        self.assertEqual(self.spy.calls, [(A, StatsPeriod.WEEK)])
        self.assertNotIn("الإحصائيات الإجمالية", r.text)   # never the overall view inside a group

    async def test_invalid_arguments_are_reported_without_a_read(self):
        for text, key in (("/stats year", "mod_err_stats_period"), ("/stats week month", "mod_err_stats_usage"),
                          ("/stats all", "mod_err_stats_period")):
            with self.subTest(text):
                r = await self.run_cmd(text)
                self.assertIs(r.kind, R.INVALID)
                self.assertEqual(r.text, t(key, "ar"))
        self.assertEqual(self.spy.calls, [])

    async def test_a_failing_source_is_a_safe_error_with_no_detail(self):
        self.spy.fail = True
        r = await self.run_cmd("/stats")
        self.assertIs(r.kind, R.ERROR)
        self.assertEqual(r.text, t("action_failed_safe", "ar"))
        self.assertNotIn("down", r.text)

    async def test_without_a_stats_service_it_answers_a_safe_error(self):
        self.svc = self.make_service(self.claims, stats=None)
        r = await self.run_cmd("/stats")
        self.assertIs(r.kind, R.ERROR)

    async def test_it_is_read_only_and_works_in_dry_run(self):
        await self.settings(dry_run=True)
        before_claims, before_events = dict(self.claims._keys), list(self.s.audit.events)
        r = await self.run_cmd("/stats month")
        self.assertIs(r.kind, R.INFO)
        self.assertEqual(self.actions.calls, [])
        self.assertEqual(self.claims._keys, before_claims)
        self.assertEqual(self.s.audit.events, before_events)

    async def test_a_redelivered_update_is_harmless(self):
        a = await self.run_cmd("/stats", msg=7)
        b = await self.run_cmd("/stats", msg=7)
        self.assertEqual(a.text, b.text)       # a read has no claim: asking twice just answers twice

    async def test_it_counts_as_a_handled_command_and_a_denied_one_as_rejected(self):
        today = self.s.clock().date()
        await self.run_cmd("/stats")
        await self.run_cmd("/stats", actor=USER, protection=gate(A, USER))
        totals = await self.counter_store.totals(A, today, today)
        self.assertEqual(totals.get("command"), 1)
        self.assertEqual(totals.get("command_rejected"), 1)

    async def test_it_is_not_posted_to_a_report_destination(self):
        await self.settings(reports_destination=-100999)
        r = await self.run_cmd("/stats")
        self.assertIsNone(r.redirect_chat_id)   # counts only; the destination is for report listings


# ------------------------------------------------------------------------------------------------ owner (private)
SECRET = "x" * 40


class OwnerStatsTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A, B)
        self.spy = Spy(await seeded())
        self.panel = OwnerPanelService(permissions=self.s.perm, licenses=self.s.licenses, audit=self.s.audit, secret=SECRET,
                                       clock=self.s.clock)
        self.svc = OwnerStatsService(stats=self.spy, owner_panel=self.panel, permissions=self.s.perm)

    def parsed(self, text="/stats"):
        return match(text, BOT_NAME)

    async def run_as(self, user=OWNER, *, chat_id=None, chat_type="private", text="/stats", lang="ar"):
        return await self.svc.run(self.parsed(text), chat_id=user if chat_id is None else chat_id, chat_type=chat_type,
                                  user_id=user, lang=lang)

    async def test_the_owner_gets_the_total_of_every_registered_group(self):
        r = await self.run_as(text="/stats week")
        self.assertEqual(r.status, "ok")
        self.assertIn("الإحصائيات الإجمالية", r.text)
        self.assertIn("(2 مجموعة)", r.text)
        self.assertIn("مخالفات تصرّف فيها البوت: 113", r.text)
        (ids, period), = self.spy.calls
        self.assertEqual(set(ids), {A, B})
        self.assertIs(period, StatsPeriod.WEEK)

    async def test_arabic_form_and_english_language(self):
        r = await self.run_as(text="الاحصائيات الشهر", lang="en")
        self.assertEqual(r.status, "ok")
        self.assertIn("Overall statistics", r.text)
        self.assertIs(self.spy.calls[0][1], StatsPeriod.MONTH)

    async def test_everyone_else_gets_silence_and_no_read(self):
        for user in (TG_ADMIN, STRANGER, BACKUP):
            with self.subTest(user):
                self.assertIsNone(await self.run_as(user))
        self.assertEqual(self.spy.calls, [])

    async def test_only_a_private_chat_of_the_owner_themselves(self):
        self.assertIsNone(await self.run_as(OWNER, chat_id=A, chat_type="supergroup"))
        self.assertIsNone(await self.run_as(OWNER, chat_id=A, chat_type="private"))     # id of another chat
        self.assertIsNone(await self.run_as(OWNER, chat_id=-5, chat_type="private"))
        self.assertIsNone(await self.run_as(OWNER, chat_id=True, chat_type="private"))  # type: ignore[arg-type]
        for ctype in ("group", "supergroup", "channel", None, ""):     # the type alone refuses, whatever the ids are
            with self.subTest(ctype):
                self.assertIsNone(await self.run_as(OWNER, chat_id=OWNER, chat_type=ctype))  # type: ignore[arg-type]
        self.assertEqual(self.spy.calls, [])

    async def test_a_broken_permission_check_fails_closed(self):
        class Broken:
            async def check_global(self, *a, **k):
                raise RuntimeError("boom")

        svc = OwnerStatsService(stats=self.spy, owner_panel=self.panel, permissions=Broken())
        self.assertIsNone(await svc.run(self.parsed(), chat_id=OWNER, chat_type="private", user_id=OWNER))
        self.assertEqual(self.spy.calls, [])

    async def test_bad_arguments_get_the_usage_message(self):
        r = await self.run_as(text="/stats year")
        self.assertEqual((r.status, r.text), ("usage", t("mod_err_stats_period", "ar")))
        r = await self.run_as(text="/stats week month")
        self.assertEqual(r.status, "usage")
        self.assertEqual(self.spy.calls, [])

    async def test_no_registered_groups(self):
        s = Stack()
        panel = OwnerPanelService(permissions=s.perm, licenses=s.licenses, audit=s.audit, secret=SECRET)
        svc = OwnerStatsService(stats=self.spy, owner_panel=panel, permissions=s.perm)
        r = await svc.run(self.parsed(), chat_id=OWNER, chat_type="private", user_id=OWNER, lang="ar")
        self.assertEqual((r.status, r.text), ("empty", t("stats_no_groups", "ar")))

    async def test_failures_are_a_safe_message(self):
        self.spy.fail = True
        r = await self.run_as()
        self.assertEqual((r.status, r.text), ("unavailable", t("action_failed_safe", "ar")))

        class Down(type(self.s.licenses)):
            async def list_all(self, limit=2000):
                raise RuntimeError("db down")

        panel = OwnerPanelService(permissions=self.s.perm, licenses=Down(), audit=self.s.audit, secret=SECRET)
        svc = OwnerStatsService(stats=self.spy, owner_panel=panel, permissions=self.s.perm)
        r = await svc.run(self.parsed(), chat_id=OWNER, chat_type="private", user_id=OWNER)
        self.assertEqual(r.status, "unavailable")
        self.assertIsNone(await OwnerStatsService(stats=None, owner_panel=self.panel, permissions=self.s.perm)
                          .run(self.parsed(), chat_id=STRANGER, chat_type="private", user_id=STRANGER))

    async def test_group_ids_is_owner_only_and_limited(self):
        ids, cut = await self.panel.group_ids(OWNER, 500)
        self.assertEqual((set(ids), cut), ({A, B}, False))
        ids, cut = await self.panel.group_ids(OWNER, 1)
        self.assertEqual((len(ids), cut), (1, True))
        for user in (TG_ADMIN, STRANGER, None):
            with self.subTest(user), self.assertRaises(PermissionDenied):
                await self.panel.group_ids(user, 500)

    async def test_the_view_is_cut_at_the_limit_and_says_so(self):
        class Many:
            async def group_ids(self, user_id, limit):
                return [A, B], True

        svc = OwnerStatsService(stats=self.spy, owner_panel=Many(), permissions=self.s.perm)
        r = await svc.run(self.parsed(), chat_id=OWNER, chat_type="private", user_id=OWNER, lang="en")
        self.assertIn("Only the first 500 groups", r.text)

    def test_match_only_returns_stats(self):
        self.assertIsNotNone(match("/stats", BOT_NAME))
        self.assertIsNotNone(match("الاحصائيات", None))
        for text in ("/ban 5", "/owner", "hello", "/stats@OtherBot", "احصائيات رائعة جدا", None, 5):
            with self.subTest(text):
                self.assertIsNone(match(text, BOT_NAME))


# ------------------------------------------------------------------------------------------------ handler (private)
class PMsg:
    def __init__(self, text, *, user=OWNER, chat_type="private", chat_id=None, is_bot=False, fail=False):
        self.text = text
        self.chat = NS(id=user if chat_id is None else chat_id, type=chat_type)
        self.from_user = NS(id=user, is_bot=is_bot, language_code="ar")
        self.answers, self.fail = [], fail

    async def answer(self, text, **kw):
        if self.fail:
            raise RuntimeError("cannot send")
        self.answers.append(text)


async def _me():
    return NS(username=BOT_NAME)


BOT_OBJ = NS(me=_me)


class HandlerTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A, B)
        panel = OwnerPanelService(permissions=self.s.perm, licenses=self.s.licenses, audit=self.s.audit, secret=SECRET)
        self.services = NS(settings=NS(default_language="ar"),
                           owner_stats=OwnerStatsService(stats=await seeded(), owner_panel=panel, permissions=self.s.perm))

    async def test_match_is_private_text_from_a_person_only(self):
        self.assertIsNotNone(await oh.match_stats_command(PMsg("/stats"), BOT_OBJ))
        self.assertIsNotNone(await oh.match_stats_command(PMsg("الاحصائيات الاسبوع"), BOT_OBJ))
        self.assertIsNotNone(await oh.match_stats_command(PMsg(f"/stats@{BOT_NAME}"), BOT_OBJ))
        for msg in (PMsg("/stats", chat_type="supergroup", chat_id=A), PMsg("/stats", chat_type="group", chat_id=A),
                    PMsg("/stats", is_bot=True), PMsg("/stats@OtherBot"), PMsg("/start"), PMsg(None)):
            with self.subTest(msg.text, ctype=msg.chat.type):
                self.assertIsNone(await oh.match_stats_command(msg, BOT_OBJ))

    async def test_the_owner_is_answered_in_private(self):
        msg = PMsg("/stats")
        parsed = await oh.match_stats_command(msg, BOT_OBJ)
        self.assertEqual(await oh.execute_stats(msg, parsed, services=self.services), "ok")
        self.assertEqual(len(msg.answers), 1)
        self.assertIn("الإحصائيات الإجمالية", msg.answers[0])

    async def test_a_stranger_in_private_gets_silence(self):
        msg = PMsg("/stats", user=STRANGER)
        parsed = await oh.match_stats_command(msg, BOT_OBJ)
        self.assertIsNone(await oh.execute_stats(msg, parsed, services=self.services))
        self.assertEqual(msg.answers, [])

    async def test_a_failed_send_never_raises(self):
        msg = PMsg("/stats", fail=True)
        parsed = await oh.match_stats_command(msg, BOT_OBJ)
        self.assertEqual(await oh.execute_stats(msg, parsed, services=self.services), "ok")
        self.assertEqual(msg.answers, [])

    async def test_without_the_service_nothing_happens(self):
        msg = PMsg("/stats")
        parsed = await oh.match_stats_command(msg, BOT_OBJ)
        self.assertIsNone(await oh.execute_stats(msg, parsed, services=NS(settings=NS(default_language="ar"))))

    async def test_in_a_group_the_moderation_handler_answers_and_the_owner_handler_does_not(self):
        # the moderation router matches `/stats` in a group (and only there)
        from test_moderation_integration import Msg
        self.assertIsNotNone(await mh.match_command(Msg("/stats", chat=A), BOT_OBJ))
        self.assertIsNone(await mh.match_command(PMsg("/stats"), BOT_OBJ))


# ------------------------------------------------------------------------------------------------ registration / static
class RegistrationTests(unittest.TestCase):
    def test_menu_and_help(self):
        self.assertIn("stats", commands_menu.MODERATION)
        self.assertNotIn("stats", commands_menu.PUBLIC + commands_menu.BASIC)
        for lang in ("en", "ar"):
            self.assertIn("stats", commands_menu.DESCRIPTIONS[lang])
        admin_menu = [m for m in commands_menu.build_menus() if m.scope == "all_chat_administrators"]
        default_menu = [m for m in commands_menu.build_menus() if m.scope == "default"]
        for m in admin_menu:
            self.assertIn("stats", [c for c, _ in m.commands])
        for m in default_menu:
            self.assertNotIn("stats", [c for c, _ in m.commands])
        for lang in ("ar", "en"):
            self.assertIn("/stats", t("help", lang))

    def test_the_command_name_is_a_valid_telegram_command(self):
        self.assertRegex(Command.STATS.value, r"^[a-z0-9_]{1,32}$")

    def test_the_owner_router_has_the_private_stats_handler(self):
        router = (SRC / "bot" / "routers" / "owner_panel.py").read_text(encoding="utf-8")
        self.assertIn("_is_stats_command", router)
        self.assertIn("execute_stats", router)

    def test_services_and_app_wiring(self):
        from guardian.services import Services
        self.assertIsNone(Services.__dataclass_fields__["owner_stats"].default)
        app = (SRC / "app.py").read_text(encoding="utf-8")
        self.assertIn("owner_stats=OwnerStatsService(", app)
        self.assertIn("stats=stats_service,", app)  # the moderation service receives the stats service

    def test_no_new_migration(self):
        """6.5b added none: after 0009 the only one is 0010 (part 6.6a, the periodic-report schedule)."""
        from guardian.db.migrations import discover
        self.assertEqual([v for v, _ in discover()][8:], ["0009_daily_counters", "0010_report_schedule", "0011_content_filter", "0012_content_default_words", "0013_member_activity_stats"])


class StaticGuardTests(unittest.TestCase):
    FILES = ("args.py", "render.py", "commands.py", "owner_command.py")

    def read(self, name):
        return (SRC / "stats" / name).read_text(encoding="utf-8")

    def test_the_command_layer_is_framework_free(self):
        for name in self.FILES:
            with self.subTest(name):
                self.assertIsNone(re.search(r"^\s*(import|from)\s+(aiogram|asyncpg|fastapi)", self.read(name), re.M))

    def test_neither_file_lists_groups_or_writes_anything(self):
        for name in self.FILES:
            text = self.read(name)
            with self.subTest(name):
                for forbidden in ("list_all", "send_message", "claim(", ".update(", ".record(", ".bump(", "INSERT", "DELETE"):
                    self.assertNotIn(forbidden, text)

    def test_the_group_command_never_takes_a_group_id_from_the_arguments(self):
        text = self.read("commands.py")
        self.assertIn("group_stats(chat_id, period)", text)
        self.assertNotIn("parsed.args[", text)

    def test_the_executor_runs_the_stats_branch_only_after_both_gates(self):
        src = (SRC / "moderation" / "executor.py").read_text(encoding="utf-8")
        gate_at = src.index("Permission.MODERATE, context_chat_id=chat_id)\n        if protection is None")
        self.assertLess(gate_at, src.index("if cmd in STATS_COMMANDS"))
        self.assertLess(src.index("if protection is None or not protection.allowed", gate_at), src.index("if cmd in STATS_COMMANDS"))


if __name__ == "__main__":
    unittest.main()
