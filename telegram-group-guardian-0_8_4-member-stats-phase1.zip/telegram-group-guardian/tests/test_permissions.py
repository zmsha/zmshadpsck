import unittest

from guardian.audit import PERMISSION_DENIED
from guardian.errors import PermissionDenied
from guardian.groups.models import GroupRole
from guardian.permissions import (
    OWNER_ONLY,
    ROLE_PERMISSIONS,
    TELEGRAM_ADMIN_PERMISSIONS,
    ActorLevel,
    Permission,
)
from stack import (A, B, BACKUP, DELEGATE, OWNER, OWNER_GROUP, STRANGER, TG_ADMIN, TG_CREATOR,
                   TG_LIMITED_ADMIN, Stack)


class PermissionTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A, B)

    async def allowed(self, user, group, perm, **kw):
        return (await self.s.perm.check(user, group, perm, **kw)).allowed

    async def test_owner_has_everything_in_any_group(self):
        for perm in Permission:
            for g in (A, B):
                self.assertTrue(await self.allowed(OWNER, g, perm), (perm, g))

    async def test_owner_only_permissions_are_denied_to_everyone_else(self):
        await self.s.deleg_store.grant(A, DELEGATE, GroupRole.GROUP_MANAGER, OWNER, self.s.clock())
        for user in (BACKUP, STRANGER, TG_CREATOR, TG_ADMIN, DELEGATE):
            for perm in OWNER_ONLY:
                d = await self.s.perm.check(user, A, perm)
                self.assertFalse(d.allowed, (user, perm))
                self.assertEqual(d.reason, "owner_only")

    async def test_matrices_never_contain_owner_only(self):
        self.assertFalse(TELEGRAM_ADMIN_PERMISSIONS & OWNER_ONLY)
        for perms in ROLE_PERMISSIONS.values():
            self.assertFalse(perms & OWNER_ONLY)

    async def test_backup_owner_has_no_license_rights_and_no_default_group_rights(self):
        self.assertFalse(self.s.authority.can_change_license(BACKUP))
        self.assertFalse(await self.allowed(BACKUP, A, Permission.CHANGE_LICENSE))
        self.assertFalse(await self.allowed(BACKUP, A, Permission.MODERATE))

    async def test_stranger_denied_everything(self):
        for perm in Permission:
            self.assertFalse(await self.allowed(STRANGER, A, perm), perm)

    async def test_telegram_creator_and_admin_get_group_rights_in_their_group_only(self):
        for perm in TELEGRAM_ADMIN_PERMISSIONS:
            self.assertTrue(await self.allowed(TG_CREATOR, A, perm))
            self.assertTrue(await self.allowed(TG_ADMIN, A, perm))
        # TG_ADMIN is only an admin in A
        self.assertFalse(await self.allowed(TG_ADMIN, B, Permission.MODERATE))
        self.assertFalse(await self.allowed(TG_ADMIN, B, Permission.MANAGE_SETTINGS))

    async def test_admin_without_restrict_right_cannot_moderate(self):
        self.assertFalse(await self.allowed(TG_LIMITED_ADMIN, A, Permission.MODERATE))
        self.assertTrue(await self.allowed(TG_LIMITED_ADMIN, A, Permission.MANAGE_SETTINGS))

    async def test_group_admins_cannot_change_license_even_as_creator(self):
        d = await self.s.perm.check(TG_CREATOR, A, Permission.CHANGE_LICENSE)
        self.assertFalse(d.allowed)

    async def test_owner_group_membership_or_adminship_grants_nothing(self):
        # TG_CREATOR owns the OWNER_GROUP chat: still not the primary owner.
        for perm in OWNER_ONLY:
            self.assertFalse(await self.allowed(TG_CREATOR, OWNER_GROUP, perm))
            self.assertFalse(await self.allowed(TG_CREATOR, A, perm))

    async def test_delegation_is_scoped_to_its_group(self):
        await self.s.deleg_store.grant(A, DELEGATE, GroupRole.MODERATOR, OWNER, self.s.clock())
        self.assertTrue(await self.allowed(DELEGATE, A, Permission.MODERATE))
        self.assertFalse(await self.allowed(DELEGATE, A, Permission.MANAGE_SETTINGS))  # moderator only
        self.assertFalse(await self.allowed(DELEGATE, B, Permission.MODERATE))  # other group
        await self.s.deleg_store.grant(A, DELEGATE, GroupRole.GROUP_MANAGER, OWNER, self.s.clock())
        self.assertTrue(await self.allowed(DELEGATE, A, Permission.MANAGE_SETTINGS))
        await self.s.deleg_store.revoke(A, DELEGATE, OWNER, self.s.clock())
        self.assertFalse(await self.allowed(DELEGATE, A, Permission.MODERATE))

    async def test_context_chat_must_match_target_group_even_for_owner(self):
        d = await self.s.perm.check(OWNER, A, Permission.CHANGE_LICENSE, context_chat_id=B)
        self.assertFalse(d.allowed)
        self.assertEqual(d.reason, "chat_mismatch")
        self.assertTrue(await self.allowed(OWNER, A, Permission.CHANGE_LICENSE, context_chat_id=A))

    async def test_invalid_identities_are_rejected(self):
        for bad in ("111111111", None, True, 0, -5, 1.5, [OWNER]):
            d = await self.s.perm.check(bad, A, Permission.CHANGE_LICENSE)
            self.assertFalse(d.allowed, bad)
        for bad_group in (None, "−1001", 0, 1001, True):
            self.assertFalse(await self.allowed(OWNER, bad_group, Permission.MODERATE), bad_group)

    async def test_lookup_failures_fail_closed(self):
        self.s.chat.fail = True
        d = await self.s.perm.check(TG_ADMIN, A, Permission.MODERATE)
        self.assertFalse(d.allowed)
        self.assertEqual(d.reason, "lookup_failed")

        async def boom(*a, **k):
            raise RuntimeError("db down")

        self.s.deleg_store.get_live = boom
        d = await self.s.perm.check(TG_ADMIN, A, Permission.MODERATE)
        self.assertEqual(d.reason, "store_unavailable")
        self.assertFalse(d.allowed)
        # the owner does not depend on the database/Telegram at all
        self.assertTrue(await self.allowed(OWNER, A, Permission.CHANGE_LICENSE))

    async def test_require_raises_and_denials_are_audited_once_per_interval(self):
        for _ in range(3):
            with self.assertRaises(PermissionDenied):
                await self.s.perm.require(STRANGER, A, Permission.CHANGE_LICENSE)
        events = [e for e in self.s.audit.events if e.event_type == PERMISSION_DENIED]
        self.assertEqual(len(events), 1)  # throttled
        self.assertEqual((events[0].actor_telegram_id, events[0].group_id, events[0].permission),
                         (STRANGER, A, "change_license"))
        self.s.clock.advance(seconds=61)
        with self.assertRaises(PermissionDenied):
            await self.s.perm.require(STRANGER, A, Permission.CHANGE_LICENSE)
        self.assertEqual(len([e for e in self.s.audit.events if e.event_type == PERMISSION_DENIED]), 2)

    async def test_audit_failure_never_turns_denial_into_approval(self):
        async def boom(event):
            raise RuntimeError("audit down")

        self.s.audit.record = boom
        d = await self.s.perm.check(STRANGER, A, Permission.CHANGE_LICENSE)
        self.assertFalse(d.allowed)

    async def test_protection_from_automation(self):
        await self.s.deleg_store.grant(A, DELEGATE, GroupRole.MODERATOR, OWNER, self.s.clock())
        for user in (OWNER, BACKUP, TG_CREATOR, TG_ADMIN, DELEGATE):
            self.assertTrue(await self.s.perm.is_protected(user, A), user)
        self.assertFalse(await self.s.perm.is_protected(STRANGER, A))
        self.assertFalse(await self.s.perm.is_protected(TG_ADMIN, B))  # admin of A only
        self.assertFalse(await self.s.perm.is_protected("x", A))

    async def test_protection_fails_safe_when_uncertain(self):
        self.s.chat.fail = True
        self.assertTrue(await self.s.perm.is_protected(STRANGER, A))  # do NOT punish when unsure

    async def test_trust_list_is_per_group_and_not_a_blanket_exemption(self):
        await self.s.trust_store.add(A, STRANGER, OWNER, None, self.s.clock())
        self.assertTrue(await self.s.perm.is_trusted(STRANGER, A))
        self.assertFalse(await self.s.perm.is_trusted(STRANGER, B))
        # part 4.2: trust is NOT full exemption (see members/trust.py); only protected users are fully exempt
        self.assertFalse(await self.s.perm.is_exempt_from_automation(STRANGER, A))

    async def test_is_trusted_rejects_bad_ids_and_raises_on_store_failure(self):
        self.assertFalse(await self.s.perm.is_trusted("x", A))
        self.assertFalse(await self.s.perm.is_trusted(True, A))
        async def boom(*a, **k):
            raise RuntimeError("down")
        self.s.trust_store.is_trusted = boom
        with self.assertRaises(RuntimeError):
            await self.s.perm.is_trusted(STRANGER, A)

    async def test_actor_level_reported(self):
        self.assertIs((await self.s.perm.check(OWNER, A, Permission.MODERATE)).level, ActorLevel.OWNER)
        self.assertIs((await self.s.perm.check(TG_ADMIN, A, Permission.MODERATE)).level, ActorLevel.TELEGRAM_ADMIN)


if __name__ == "__main__":
    unittest.main()
