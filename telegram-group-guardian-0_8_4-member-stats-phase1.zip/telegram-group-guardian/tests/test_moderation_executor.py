from datetime import timedelta

from executor_stack import A, B, BOT, OTHER, USER, BrokenClaims, ExecBase
from guardian.groups.models import GroupRole
from guardian.moderation.executor import ResultKind as R
from guardian.moderation.models import SanctionKind as K
from guardian.telegram_rights import ChatMemberInfo
from stack import BACKUP, DELEGATE, NOW, OWNER, STRANGER, TG_ADMIN, TG_CREATOR, TG_LIMITED_ADMIN


class GatesAndPermissions(ExecBase):
    async def test_unauthorized_actors_are_denied_without_any_action(self):
        for actor in (STRANGER, TG_LIMITED_ADMIN):
            r = await self.run_cmd("/ban", actor=actor, reply_to=USER, msg=10 + actor % 7)
            self.assertEqual(r.kind, R.DENIED, actor)
        self.assertEqual(self.actions.calls, [])
        self.assertEqual(await self.s.sanction_store.get_active(A, USER, NOW), [])

    async def test_delegated_moderator_is_allowed(self):
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.MODERATOR)
        r = await self.run_cmd("/kick", actor=DELEGATE, reply_to=USER)
        self.assertEqual(r.kind, R.DONE)

    async def test_owner_may_moderate_but_backup_owner_has_no_group_rights(self):
        # Phase 2 decision #1 (HANDOFF): the backup owner is only protected, it has no moderation rights.
        self.member(USER)
        self.assertEqual((await self.run_cmd("/kick", actor=OWNER, reply_to=USER, msg=1)).kind, R.DONE)
        self.assertEqual((await self.run_cmd("/kick", actor=BACKUP, reply_to=USER, msg=2)).kind, R.DENIED)

    async def test_admin_of_one_group_cannot_moderate_another(self):
        self.member(USER, group=B)
        r = await self.run_cmd("/ban", chat=B, reply_to=USER)  # TG_ADMIN is admin of A only
        self.assertEqual(r.kind, R.DENIED)
        self.assertEqual(self.actions.calls, [])

    async def test_license_off_stops_moderation(self):
        self.member(USER)
        for prot in (None, "off", "mismatch"):
            from executor_stack import gate
            p = {None: None, "off": gate(allowed=False), "mismatch": gate(chat_id=B)}[prot]
            r = await self.run_cmd("/ban", reply_to=USER, protection=p, msg=20)
            self.assertEqual(r.kind, R.LICENSE_OFF, prot)
        self.assertEqual(self.actions.calls, [])

    async def test_permission_checked_before_license(self):
        from executor_stack import gate
        r = await self.run_cmd("/ban", actor=STRANGER, reply_to=USER, protection=gate(allowed=False))
        self.assertEqual(r.kind, R.DENIED)  # no license detail leaked to non-moderators

    async def test_anonymous_admin_identity_cannot_run_commands(self):
        r = await self.run_cmd("/ban", actor=1087968824, reply_to=USER)
        self.assertEqual(r.kind, R.DENIED)

    async def test_permission_store_failure_fails_closed(self):
        self.s.chat.fail = True
        r = await self.run_cmd("/ban", reply_to=USER)
        self.assertIn(r.kind, (R.DENIED, R.ERROR))
        self.assertEqual(self.actions.calls, [])


class TargetsAndProtection(ExecBase):
    async def test_protected_targets_are_refused(self):
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.MODERATOR)
        for i, uid in enumerate((OWNER, BACKUP, TG_CREATOR, DELEGATE, 777000)):
            for cmd in ("/ban", "/mute", "/kick", "/warn"):
                r = await self.run_cmd(cmd, reply_to=uid, msg=100 + i * 10 + len(cmd))
                self.assertEqual(r.kind, R.INVALID, (uid, cmd))
        self.assertEqual(self.actions.calls, [])

    async def test_self_and_bot_refused(self):
        self.assertEqual((await self.run_cmd("/ban", reply_to=TG_ADMIN, msg=1)).kind, R.INVALID)
        self.assertEqual((await self.run_cmd(f"/ban {BOT}", msg=2)).kind, R.INVALID)
        self.assertEqual(self.actions.calls, [])

    async def test_missing_and_ambiguous_target(self):
        self.assertEqual((await self.run_cmd("/ban", msg=1)).kind, R.INVALID)
        self.assertEqual((await self.run_cmd(f"/ban {USER} 30m", reply_to=OTHER, msg=2)).kind, R.INVALID)

    async def test_error_text_is_localized_and_safe(self):
        r = await self.run_cmd("/mute 5001 30x")
        self.assertEqual(r.kind, R.INVALID)
        self.assertIn("m", r.text)  # unit hint
        self.assertEqual(self.actions.calls, [])

    async def test_target_by_id_and_text_mention(self):
        self.member(USER)
        self.assertEqual((await self.run_cmd(f"/kick {USER}", msg=1)).kind, R.DONE)
        self.member(OTHER)
        self.assertEqual((await self.run_cmd("/kick Ali", msg=2, mention=OTHER)).kind, R.DONE)


class BanUnban(ExecBase):
    async def test_permanent_ban_records_and_acts(self):
        self.member(USER)
        r = await self.run_cmd("/ban spam", reply_to=USER)
        self.assertEqual((r.kind, r.target_id), (R.DONE, USER))
        self.assertEqual(self.actions.calls, [("ban", A, USER, None)])
        act = await self.s.sanction_store.get_active(A, USER, NOW)
        self.assertEqual([(x.kind, x.expires_at, x.reason, x.issued_by) for x in act], [(K.BAN, None, "spam", TG_ADMIN)])
        self.assertIn(str(USER), r.text)

    async def test_temporary_ban_until(self):
        self.member(USER)
        r = await self.run_cmd(f"/ban {USER} 7d flood", msg=2)
        self.assertEqual(r.kind, R.DONE)
        self.assertEqual(self.actions.calls, [("ban", A, USER, NOW + timedelta(days=7))])
        (b,) = await self.s.sanction_store.get_active(A, USER, NOW)
        self.assertEqual(b.expires_at, NOW + timedelta(days=7))

    async def test_arabic_alias_flow(self):
        from guardian.moderation.commands import parse_command
        from guardian.moderation.targets import ReplyInfo
        from executor_stack import gate
        self.member(USER)
        parsed = parse_command("حظر ٧d تكرار", "GuardianBot", has_reply=True)
        r = await self.svc.handle(parsed, chat_id=A, actor_id=TG_ADMIN, message_id=3, protection=gate(),
                                  reply=ReplyInfo(USER))
        self.assertEqual(r.kind, R.DONE)
        self.assertEqual(self.actions.calls[0][3], NOW + timedelta(days=7))

    async def test_already_banned_is_noop(self):
        self.member(USER, "kicked")
        r = await self.run_cmd("/ban", reply_to=USER)
        self.assertEqual(r.kind, R.NOOP)
        self.assertEqual(self.actions.calls, [])

    async def test_ban_of_a_user_who_left_is_allowed(self):
        self.member(USER, "left")
        self.assertEqual((await self.run_cmd("/ban", reply_to=USER)).kind, R.DONE)

    async def test_unban_lifts_ledger(self):
        self.member(USER)
        await self.run_cmd("/ban", reply_to=USER, msg=1)
        self.member(USER, "kicked")
        r = await self.run_cmd("/unban", reply_to=USER, msg=2)
        self.assertEqual(r.kind, R.DONE)
        self.assertEqual(self.actions.names(), ["ban", "unban"])
        self.assertEqual(await self.s.sanction_store.get_active(A, USER, NOW), [])

    async def test_unban_when_not_banned_is_noop_but_cleans_stale_ledger(self):
        self.member(USER)
        await self.run_cmd("/ban", reply_to=USER, msg=1)  # ledger says banned
        self.member(USER, "member")  # ...but Telegram says otherwise (manual unban)
        r = await self.run_cmd("/unban", reply_to=USER, msg=2)
        self.assertEqual(r.kind, R.NOOP)
        self.assertEqual(self.actions.names(), ["ban"])  # no Telegram call
        self.assertEqual(await self.s.sanction_store.get_active(A, USER, NOW), [])

    async def test_non_punitive_commands_are_not_blocked_by_target_protection(self):
        # a protected target is refused for ban/mute/kick/warn but /unban and /unmute only say "nothing to do"
        r = await self.run_cmd(f"/unban {TG_CREATOR}", msg=1)
        self.assertEqual(r.kind, R.NOOP)
        r = await self.run_cmd(f"/unmute {TG_CREATOR}", msg=2)
        self.assertEqual(r.kind, R.NOOP)
        self.assertEqual(self.actions.calls, [])


class MuteUnmuteKick(ExecBase):
    async def test_mute_temporary_and_unmute(self):
        self.member(USER)
        r = await self.run_cmd("/mute 30m", reply_to=USER, msg=1)
        self.assertEqual((r.kind, self.actions.calls[0]), (R.DONE, ("mute", A, USER, NOW + timedelta(minutes=30))))
        (m,) = await self.s.sanction_store.get_active(A, USER, NOW)
        self.assertEqual(m.kind, K.MUTE)
        self.member(USER, "restricted")
        r = await self.run_cmd("/unmute", reply_to=USER, msg=2)
        self.assertEqual(r.kind, R.DONE)
        self.assertEqual(self.actions.names(), ["mute", "unmute"])
        self.assertEqual(await self.s.sanction_store.get_active(A, USER, NOW), [])

    async def test_mute_default_permanent(self):
        self.member(USER)
        await self.run_cmd("/mute", reply_to=USER)
        self.assertEqual(self.actions.calls[0][3], None)

    async def test_mute_requires_present_member(self):
        for st in ("left", "kicked"):
            self.member(USER, st)
            self.assertEqual((await self.run_cmd("/mute", reply_to=USER, msg=hash(st) % 1000)).kind, R.INVALID, st)
        self.assertEqual(self.actions.calls, [])

    async def test_unmute_member_not_restricted_is_noop(self):
        self.member(USER)
        self.assertEqual((await self.run_cmd("/unmute", reply_to=USER)).kind, R.NOOP)
        self.assertEqual(self.actions.calls, [])

    async def test_kick_records_without_expiry_and_is_never_active(self):
        self.member(USER)
        r = await self.run_cmd("/kick bye", reply_to=USER)
        self.assertEqual((r.kind, self.actions.calls), (R.DONE, [("kick", A, USER)]))
        self.assertEqual(await self.s.sanction_store.get_active(A, USER, NOW), [])  # a kick is instantaneous
        self.assertIn("sanction_recorded", self.audit_types())

    async def test_kick_requires_present_member(self):
        self.member(USER, "left")
        self.assertEqual((await self.run_cmd("/kick", reply_to=USER)).kind, R.INVALID)


class TelegramAndSafety(ExecBase):
    async def test_telegram_failures_record_nothing(self):
        self.member(USER)
        for i, (err, word) in enumerate((("forbidden", "mod_tg_forbidden"), ("rate_limited", "mod_tg_rate_limited"),
                                          ("not_found", "mod_tg_not_found"), ("other", "action_failed_safe"))):
            self.actions.fail["ban"] = err
            from guardian.i18n import t
            r = await self.run_cmd("/ban", reply_to=USER, msg=50 + i)
            self.assertEqual((r.kind, r.text), (R.TELEGRAM_FAILED, t(word, "ar")), err)
        self.assertEqual(await self.s.sanction_store.get_active(A, USER, NOW), [])
        self.assertEqual(self.audit_types().count("moderation_action_failed"), 4)

    async def test_failed_unban_keeps_ledger(self):
        self.member(USER)
        await self.run_cmd("/ban", reply_to=USER, msg=1)
        self.member(USER, "kicked")
        self.actions.fail["unban"] = "forbidden"
        r = await self.run_cmd("/unban", reply_to=USER, msg=2)
        self.assertEqual(r.kind, R.TELEGRAM_FAILED)
        self.assertEqual(len(await self.s.sanction_store.get_active(A, USER, NOW)), 1)

    async def test_ledger_failure_after_success_keeps_action_and_is_audited(self):
        self.member(USER)

        async def boom(*a, **k):
            raise RuntimeError("db down")
        self.s.sanctions.record = boom
        r = await self.run_cmd("/ban", reply_to=USER)
        self.assertEqual(r.kind, R.DONE)
        self.assertIn("moderation_record_error", self.audit_types())

    async def test_bot_missing_rights_blocks_without_consuming_claim(self):
        self.member(USER)
        self.s.chat.set(A, BOT, ChatMemberInfo("administrator", True, False, True))
        r = await self.run_cmd("/ban", reply_to=USER, msg=7)
        self.assertEqual(r.kind, R.BOT_RIGHTS)
        self.assertEqual(self.actions.calls, [])
        self.s.chat.set(A, BOT, ChatMemberInfo("administrator", True, True, True))
        self.assertEqual((await self.run_cmd("/ban", reply_to=USER, msg=7)).kind, R.DONE)  # same message retried

    async def test_bot_lookup_failure_fails_closed(self):
        self.member(USER)

        async def fail(chat_id):
            from guardian.errors import TelegramLookupFailed
            raise TelegramLookupFailed("down")
        self.s.chat.get_bot_member = fail
        r = await self.run_cmd("/ban", reply_to=USER)
        self.assertEqual(r.kind, R.BOT_RIGHTS)
        self.assertEqual(self.actions.calls, [])

    async def test_redelivered_update_acts_once_and_stays_silent(self):
        self.member(USER)
        first = await self.run_cmd("/kick", reply_to=USER, msg=9)
        again = await self.run_cmd("/kick", reply_to=USER, msg=9)
        self.assertEqual((first.kind, again.kind, again.text), (R.DONE, R.DUPLICATE, ""))
        self.assertEqual(self.actions.names(), ["kick"])

    async def test_same_message_id_in_other_group_is_independent(self):
        from executor_stack import gate
        self.member(USER)
        self.member(USER, group=B)
        a = await self.run_cmd("/kick", actor=TG_CREATOR, reply_to=USER, msg=9, chat=A, protection=gate(A, TG_CREATOR))
        b = await self.run_cmd("/kick", actor=TG_CREATOR, reply_to=USER, msg=9, chat=B, protection=gate(B, TG_CREATOR))
        self.assertEqual((a.kind, b.kind), (R.DONE, R.DONE))
        self.assertEqual(self.actions.calls, [("kick", A, USER), ("kick", B, USER)])

    async def test_claim_store_failure_means_no_action(self):
        self.member(USER)
        svc = self.make_service(BrokenClaims())
        from guardian.moderation.commands import parse_command
        from guardian.moderation.targets import ReplyInfo
        from executor_stack import gate
        r = await svc.handle(parse_command("/ban", "GuardianBot", has_reply=True), chat_id=A, actor_id=TG_ADMIN,
                             message_id=1, protection=gate(), reply=ReplyInfo(USER))
        self.assertEqual(r.kind, R.ERROR)
        self.assertEqual(self.actions.calls, [])

    async def test_unexpected_exception_never_escapes(self):
        self.member(USER)

        async def boom(*a, **k):
            raise ValueError("bug")
        self.actions.ban_member = boom
        r = await self.run_cmd("/ban", reply_to=USER)
        self.assertEqual(r.kind, R.ERROR)
        self.assertNotIn("bug", r.text)


if __name__ == "__main__":
    import unittest
    unittest.main()
