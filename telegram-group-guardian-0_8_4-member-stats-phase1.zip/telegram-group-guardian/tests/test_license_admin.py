import asyncio
import unittest
from datetime import timedelta

from guardian.audit import LICENSE_ACTION_REJECTED
from guardian.errors import (ConcurrentModification, GroupNotRegistered, InvalidInput, InvalidTransition,
                             PermissionDenied)
from guardian.groups.models import GroupRole
from guardian.licensing.admin import MAX_LICENSE_HORIZON, Outcome
from guardian.licensing.models import DenyReason, LicenseStatus as S
from stack import A, B, BACKUP, DELEGATE, OWNER, STRANGER, TG_ADMIN, TG_CREATOR, Stack


class LicenseAdminTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A, B)
        self.now = self.s.clock()

    async def status(self, g=A):
        return (await self.s.licenses.get(g)).status

    # ---- happy paths + audit content
    async def test_permanent_activation_stores_null_expiry_and_audits(self):
        r = await self.s.admin.activate_permanent(OWNER, A, reason="paid", context_chat_id=A)
        self.assertIs(r.outcome, Outcome.CHANGED)
        lic = await self.s.licenses.get(A)
        self.assertIs(lic.status, S.ACTIVE_PERMANENT)
        self.assertIsNone(lic.expires_at)
        self.assertEqual((lic.activated_by, lic.activated_at), (OWNER, self.now))
        ev = (await self.s.licenses.audit_for_group(A))[-1]
        self.assertEqual((ev.action, ev.actor_telegram_id, ev.previous_status, ev.new_status, ev.reason),
                         ("activate_permanent", OWNER, S.PENDING, S.ACTIVE_PERMANENT, "paid"))
        self.assertTrue((await self.s.license_service.check(A, self.now)).allowed)

    async def test_temporary_activation_and_expiry_after_sleep(self):
        exp = self.now + timedelta(days=10)
        await self.s.admin.activate_temporary(OWNER, A, exp)
        lic = await self.s.licenses.get(A)
        self.assertEqual((lic.status, lic.expires_at), (S.ACTIVE_TEMPORARY, exp))
        # service "sleeps" past expiry: first check denies, row is persisted as expired (system audit)
        later = exp + timedelta(hours=1)
        d = await self.s.license_service.check(A, later)
        self.assertFalse(d.allowed)
        self.assertIs(d.reason, DenyReason.EXPIRED)
        self.assertIs(await self.status(), S.EXPIRED)
        self.assertEqual((await self.s.licenses.audit_for_group(A))[-1].action, "auto_expire")
        self.assertIsNone((await self.s.licenses.audit_for_group(A))[-1].actor_telegram_id)

    async def test_renewal_counts_from_the_supplied_time_not_the_old_expiry(self):
        await self.s.admin.activate_temporary(OWNER, A, self.now + timedelta(days=30))
        self.s.clock.advance(days=5)
        new_exp = self.s.clock() + timedelta(days=7)  # 7 days from the renewal moment
        r = await self.s.admin.activate_temporary(OWNER, A, new_exp)
        self.assertEqual(r.action, "renew")
        self.assertEqual((await self.s.licenses.get(A)).expires_at, new_exp)

    async def test_renew_from_lapsed_license_uses_effective_expired_status(self):
        exp = self.now + timedelta(days=1)
        await self.s.admin.activate_temporary(OWNER, A, exp)
        self.s.clock.advance(days=3)  # lapsed, still stored as active_temporary
        r = await self.s.admin.activate_temporary(OWNER, A, self.s.clock() + timedelta(days=2))
        self.assertEqual(r.action, "renew")
        ev = (await self.s.licenses.audit_for_group(A))[-1]
        self.assertIs(ev.previous_status, S.EXPIRED)

    async def test_full_lifecycle_audit_trail(self):
        a = self.s.admin
        await a.activate_permanent(OWNER, A)
        await a.stop(OWNER, A, reason="payment issue")
        await a.activate_temporary(OWNER, A, self.now + timedelta(days=1))
        await a.ban(OWNER, A, reason="abuse")
        await a.unban(OWNER, A)
        await a.reject(OWNER, A)
        await a.allow(OWNER, A)
        trail = [(e.action, e.previous_status, e.new_status) for e in await self.s.licenses.audit_for_group(A)]
        self.assertEqual(trail, [
            ("register_pending", None, S.PENDING),
            ("activate_permanent", S.PENDING, S.ACTIVE_PERMANENT),
            ("stop", S.ACTIVE_PERMANENT, S.STOPPED),
            ("activate_temporary", S.STOPPED, S.ACTIVE_TEMPORARY),
            ("ban", S.ACTIVE_TEMPORARY, S.BANNED),
            ("unban", S.BANNED, S.PENDING),
            ("reject", S.PENDING, S.REJECTED),
            ("allow", S.REJECTED, S.PENDING),
        ])
        self.assertTrue(all(e.actor_telegram_id in (None, OWNER) for e in await self.s.licenses.audit_for_group(A)))
        self.assertIs(await self.status(), S.PENDING)  # lifting never auto-activates
        self.assertFalse((await self.s.license_service.check(A, self.now)).allowed)

    async def test_banned_or_rejected_cannot_be_activated_directly(self):
        await self.s.admin.ban(OWNER, A)
        with self.assertRaises(InvalidTransition):
            await self.s.admin.activate_permanent(OWNER, A)
        with self.assertRaises(InvalidTransition):
            await self.s.admin.activate_temporary(OWNER, A, self.now + timedelta(days=1))
        self.assertIs(await self.status(), S.BANNED)
        self.assertTrue(any(e.event_type == LICENSE_ACTION_REJECTED for e in self.s.audit.events))
        await self.s.admin.unban(OWNER, A)
        await self.s.admin.reject(OWNER, A)
        with self.assertRaises(InvalidTransition):
            await self.s.admin.activate_permanent(OWNER, A)

    # ---- who may NOT change a license
    async def test_everyone_except_primary_owner_is_denied_and_nothing_changes(self):
        await self.s.deleg_store.grant(A, DELEGATE, GroupRole.GROUP_MANAGER, OWNER, self.now)
        actions = ["activate_permanent", "stop", "reject", "ban", "unban", "allow"]
        for actor in (STRANGER, BACKUP, TG_CREATOR, TG_ADMIN, DELEGATE, "111111111", None, True):
            for name in actions:
                with self.assertRaises(PermissionDenied, msg=(actor, name)):
                    await getattr(self.s.admin, name)(actor, A)
            with self.assertRaises(PermissionDenied):
                await self.s.admin.activate_temporary(actor, A, self.now + timedelta(days=1))
        self.assertIs(await self.status(), S.PENDING)
        self.assertEqual([e.action for e in await self.s.licenses.audit_for_group(A)], ["register_pending"])
        self.assertTrue(self.s.audit.events)  # denials were recorded

    async def test_banned_group_owner_cannot_unban(self):
        await self.s.admin.ban(OWNER, A)
        for actor in (TG_CREATOR, TG_ADMIN, BACKUP, STRANGER):
            with self.assertRaises(PermissionDenied):
                await self.s.admin.unban(actor, A)
            with self.assertRaises(PermissionDenied):
                await self.s.admin.allow(actor, A)
        self.assertIs(await self.status(), S.BANNED)

    async def test_command_in_other_chat_cannot_change_this_group(self):
        with self.assertRaises(PermissionDenied) as cm:
            await self.s.admin.activate_permanent(OWNER, A, context_chat_id=B)
        self.assertEqual(cm.exception.reason, "chat_mismatch")
        self.assertIs(await self.status(A), S.PENDING)
        self.assertIs(await self.status(B), S.PENDING)

    async def test_unregistered_group_is_not_created_by_activation(self):
        with self.assertRaises(GroupNotRegistered):
            await self.s.admin.activate_permanent(OWNER, -777)
        self.assertIsNone(await self.s.licenses.get(-777))

    # ---- input validation
    async def test_expiry_validation(self):
        bad = [self.now, self.now - timedelta(seconds=1), self.now + MAX_LICENSE_HORIZON + timedelta(days=1),
               "2030-01-01", None, 12345]
        for value in bad:
            with self.assertRaises(InvalidInput, msg=value):
                await self.s.admin.activate_temporary(OWNER, A, value)
        import datetime as dt
        with self.assertRaises(InvalidInput):
            await self.s.admin.activate_temporary(OWNER, A, dt.datetime(2030, 1, 1))  # naive
        self.assertIs(await self.status(), S.PENDING)

    async def test_reason_is_sanitized_and_secrets_redacted(self):
        reason = "line1\nline2 \x00 token 123456789:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA " + "x" * 400
        await self.s.admin.activate_permanent(OWNER, A, reason=reason)
        stored = (await self.s.licenses.get(A)).note
        self.assertNotIn("AAAAAAAA", stored)
        self.assertNotIn("\n", stored)
        self.assertLessEqual(len(stored), 200)

    # ---- idempotency / races
    async def test_repeating_a_request_is_a_noop_without_duplicate_audit(self):
        await self.s.admin.activate_permanent(OWNER, A)
        again = await self.s.admin.activate_permanent(OWNER, A)
        self.assertIs(again.outcome, Outcome.NO_CHANGE)
        exp = self.now + timedelta(days=3)
        await self.s.admin.stop(OWNER, A)
        await self.s.admin.activate_temporary(OWNER, A, exp)
        self.assertIs((await self.s.admin.activate_temporary(OWNER, A, exp)).outcome, Outcome.NO_CHANGE)
        self.assertIs((await self.s.admin.ban(OWNER, A)).outcome, Outcome.CHANGED)
        self.assertIs((await self.s.admin.ban(OWNER, A)).outcome, Outcome.NO_CHANGE)
        actions = [e.action for e in await self.s.licenses.audit_for_group(A)]
        self.assertEqual(actions, ["register_pending", "activate_permanent", "stop", "activate_temporary", "ban"])

    async def test_concurrent_identical_requests_produce_one_change(self):
        results = await asyncio.gather(*[self.s.admin.activate_permanent(OWNER, A) for _ in range(10)])
        self.assertEqual(sum(r.outcome is Outcome.CHANGED for r in results), 1)
        self.assertEqual(len([e for e in await self.s.licenses.audit_for_group(A) if e.action == "activate_permanent"]), 1)

    async def test_lost_race_to_a_different_state_raises_conflict(self):
        real = self.s.licenses.transition

        async def sneaky(group_id, **kw):
            # someone bans the group between our read and our write
            await real(group_id, expected_status=S.PENDING,
                       new_license=(await self.s.licenses.get(group_id)).__class__(
                           group_id=group_id, title="t", status=S.BANNED, updated_at=self.now),
                       audit=kw["audit"].__class__(group_id=group_id, action="ban", previous_status=S.PENDING,
                                                   new_status=S.BANNED, occurred_at=self.now, actor_telegram_id=OWNER))
            return await real(group_id, **kw)

        self.s.licenses.transition = sneaky
        with self.assertRaises(ConcurrentModification):
            await self.s.admin.activate_permanent(OWNER, A)
        self.assertIs(await self.status(), S.BANNED)

    # ---- isolation
    async def test_actions_on_one_group_never_touch_another(self):
        await self.s.admin.activate_permanent(OWNER, A)
        await self.s.admin.ban(OWNER, B)
        self.assertIs(await self.status(A), S.ACTIVE_PERMANENT)
        self.assertIs(await self.status(B), S.BANNED)
        self.assertNotIn("ban", [e.action for e in await self.s.licenses.audit_for_group(A)])
        self.assertTrue(all(e.group_id == B for e in await self.s.licenses.audit_for_group(B)))


class ReaddBotTests(unittest.IsolatedAsyncioTestCase):
    async def test_removing_and_readding_bot_never_reactivates_or_unbans(self):
        s = Stack()
        await s.register(A)
        await s.admin.ban(OWNER, A)
        await s.license_service.on_bot_added(A, "renamed", s.clock())  # bot re-added
        self.assertIs((await s.licenses.get(A)).status, S.BANNED)
        await s.admin.unban(OWNER, A)
        await s.admin.activate_permanent(OWNER, A)
        await s.license_service.on_bot_added(A, "again", s.clock())
        self.assertIs((await s.licenses.get(A)).status, S.ACTIVE_PERMANENT)


if __name__ == "__main__":
    unittest.main()
