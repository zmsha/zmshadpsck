import logging
import unittest

from guardian.logging_setup import REDACTED, RedactingFormatter, redact
from helpers import VALID_ENV


class RedactionTests(unittest.TestCase):
    def test_token_shaped_strings(self):
        text = f"call https://api.telegram.org/bot{VALID_ENV['BOT_TOKEN']}/getMe failed"
        self.assertNotIn("AAAAAAAA", redact(text))

    def test_bare_token(self):
        self.assertEqual(redact(f"token={VALID_ENV['BOT_TOKEN']};"), f"token={REDACTED};")

    def test_url_password(self):
        out = redact("conn postgresql://dbuser:s3cretPW@db.example.com:5432/x failed")
        self.assertNotIn("s3cretPW", out)
        self.assertIn("dbuser", out)
        self.assertIn(REDACTED, out)

    def test_explicit_secrets_longest_first(self):
        out = redact("abc-secret-123 and secret", secrets=("secret", "abc-secret-123"))
        self.assertEqual(out, f"{REDACTED} and {REDACTED}")

    def test_plain_text_untouched(self):
        self.assertEqual(redact("hello 12345 world"), "hello 12345 world")

    def test_formatter_redacts_tracebacks(self):
        formatter = RedactingFormatter(secrets=("TOPSECRETVALUE",))
        try:
            raise RuntimeError("bad TOPSECRETVALUE here")
        except RuntimeError:
            import sys

            record = logging.LogRecord("t", logging.ERROR, __file__, 1, "failed", None, sys.exc_info())
        self.assertNotIn("TOPSECRETVALUE", formatter.format(record))


if __name__ == "__main__":
    unittest.main()
