"""Durable escalation: the protection engine now counts offenses from `moderation_sanctions`."""
import asyncio
import unittest
from datetime import timedelta

from guardian.audit import SANCTION_RECORDED
from guardian.idempotency import InMemoryIdempotency
from guardian.moderation.memory_store import InMemorySanctionStore
from guardian.moderation.models import SanctionKind as K
from guardian.protection.engine import ActionResult, MessageView, OutcomeKind, ProtectionEngine, PROTECTION_LEDGER_ERROR
from guardian.protection.offenses import SanctionOffenseLedger
from guardian.protection.tracking import KeyedLocks
from guardian.protection_gate import ProtectionGate
from guardian.telegram_rights import ChatMemberInfo
from helpers import FakeNotifier
from stack import A, B, NOW, OWNER, STRANGER, TG_ADMIN, Stack
from test_protection_engine import BOT, FakeActions

BAD = "buy at https://evil.com"


class LedgerBase(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A, B)
        await self.s.admin.activate_permanent(OWNER, A)
        await self.s.admin.activate_permanent(OWNER, B)
        for g in (A, B):
            self.s.chat.set(g, BOT, ChatMemberInfo("administrator", True, True, True))
        self.actions = FakeActions()
        self.claims = InMemoryIdempotency()
        self.store = self.s.sanction_store          # the SAME store survives "restarts"
        self.engine = self.new_engine()
        self.gate = ProtectionGate(self.s.license_service, self.s.perm, FakeNotifier(), clock=self.s.clock)
        self.mid = 0

    def new_engine(self, ledger=None):
        return ProtectionEngine(self.s.settings_store, self.actions, self.s.chat, self.claims, self.s.audit,
                                FakeNotifier(), clock=self.s.clock,
                                ledger=ledger or SanctionOffenseLedger(self.store))

    async def send(self, text=BAD, user=STRANGER, group=A, mid=None, advance=0.0, engine=None):
        if advance:
            self.s.clock.advance(seconds=advance)
        self.mid += 1
        ctx = await self.gate.evaluate(group, "supergroup", user)
        return await (engine or self.engine).handle(
            ctx, MessageView(group, user, mid or self.mid, text), self.s.clock())


class DurableEscalationTests(LedgerBase):
    async def test_escalation_survives_restart(self):
        self.assertEqual((await self.send()).muted_seconds, 600)
        self.s.clock.advance(seconds=700)
        restarted = self.new_engine()                    # fresh process: no in-memory counters at all
        self.assertEqual((await self.send(engine=restarted)).muted_seconds, 3600)

    async def test_automatic_mute_is_recorded_as_system_sanction(self):
        await self.send()
        [row] = await self.store.get_active(A, STRANGER, self.s.clock())
        self.assertEqual((row.kind, row.issued_by, row.violation, row.group_id), (K.MUTE, None, "links", A))
        self.assertEqual(row.expires_at, NOW + timedelta(seconds=600))
        self.assertTrue(row.idempotency_key.startswith("op:sanction:"))

    async def test_escalation_is_per_group(self):
        await self.send(group=A)
        o = await self.send(group=B)
        self.assertEqual(o.muted_seconds, 600)           # group B starts at level 1

    async def test_manual_sanctions_do_not_escalate_but_block_inflight_mutes(self):
        # a moderator muted the user by hand: in-flight violations are deleted only...
        await self.s.sanctions.record(TG_ADMIN, A, STRANGER, K.MUTE,
                                      expires_at=NOW + timedelta(hours=1), context_chat_id=A)
        o = await self.send()
        self.assertEqual((o.kind, o.deleted, o.muted_seconds), (OutcomeKind.ACTED, True, None))
        self.assertEqual(self.actions.muted, [])
        # ...and once it is lifted the engine starts at level 1 (manual rows are not offenses)
        await self.s.sanctions.lift(TG_ADMIN, A, STRANGER, K.MUTE, context_chat_id=A)
        self.assertEqual((await self.send()).muted_seconds, 600)

    async def test_active_ban_also_blocks_new_mutes(self):
        await self.s.sanctions.record(OWNER, A, STRANGER, K.BAN)
        self.assertIsNone((await self.send()).muted_seconds)

    async def test_failed_mute_is_not_recorded_and_does_not_escalate(self):
        self.actions.mute_result = ActionResult(False, "forbidden")
        await self.send()
        self.assertEqual(await self.store.count_auto_mutes(A, STRANGER, NOW - timedelta(days=1)), 0)
        self.actions.mute_result = ActionResult(True)
        self.assertEqual((await self.send(advance=1)).muted_seconds, 600)

    async def test_redelivered_update_records_one_sanction(self):
        await self.send(mid=42)
        again = await self.send(mid=42)
        self.assertEqual(again.kind, OutcomeKind.DUPLICATE_DELIVERY)
        self.assertEqual(await self.store.count_auto_mutes(A, STRANGER, NOW - timedelta(days=1)), 1)

    async def test_dry_run_writes_nothing(self):
        await self.s.settings_store.merge(A, {"dry_run": True}, OWNER, NOW)
        o = await self.send()
        self.assertEqual(o.kind, OutcomeKind.DRY_RUN)
        self.assertEqual((self.actions.deleted, self.actions.muted), ([], []))
        self.assertEqual(await self.store.count_auto_mutes(A, STRANGER, NOW - timedelta(days=1)), 0)

    async def test_protected_sender_never_recorded(self):
        o = await self.send(user=TG_ADMIN)
        self.assertEqual(o.kind, OutcomeKind.NONE)
        self.assertEqual(await self.store.get_active(A, TG_ADMIN, self.s.clock()), [])

    async def test_escalation_window_uses_database_records(self):
        await self.s.settings_store.merge(A, {"escalation_window_seconds": 3600}, OWNER, NOW)
        await self.send()
        self.s.clock.advance(seconds=7200)
        self.assertEqual((await self.send()).muted_seconds, 600)


class LedgerFailureTests(LedgerBase):
    async def test_unreadable_ledger_deletes_but_does_not_guess_a_mute(self):
        class Broken(SanctionOffenseLedger):
            async def is_restricted(self, *a):
                raise RuntimeError("db down")

        engine = self.new_engine(Broken(self.store))
        o = await self.send(engine=engine)
        self.assertEqual((o.kind, o.deleted, o.muted_seconds), (OutcomeKind.ACTED, True, None))
        self.assertEqual(self.actions.muted, [])
        self.assertIn(PROTECTION_LEDGER_ERROR, [e.event_type for e in self.s.audit.events])

    async def test_write_failure_keeps_the_mute_and_audits(self):
        class NoWrite(SanctionOffenseLedger):
            async def record_mute(self, *a, **k):
                raise RuntimeError("db down")

        engine = self.new_engine(NoWrite(self.store))
        o = await self.send(engine=engine)
        self.assertEqual((o.kind, o.muted_seconds), (OutcomeKind.ACTED, 600))
        self.assertEqual(len(self.actions.muted), 1)
        self.assertIn(PROTECTION_LEDGER_ERROR, [e.event_type for e in self.s.audit.events])

    async def test_default_engine_works_without_a_ledger(self):
        engine = ProtectionEngine(self.s.settings_store, self.actions, self.s.chat, self.claims, self.s.audit,
                                  FakeNotifier(), clock=self.s.clock)
        self.assertEqual((await self.send(engine=engine)).muted_seconds, 600)


class ConcurrencyTests(LedgerBase):
    async def test_burst_of_concurrent_violations_mutes_once(self):
        async def slow_mute(chat_id, user_id, until):
            self.actions.muted.append((chat_id, user_id, until))
            await asyncio.sleep(0.01)  # a real Telegram call yields; without the lock all 6 would mute
            return ActionResult(True)

        self.actions.mute_member = slow_mute
        ctx = await self.gate.evaluate(A, "supergroup", STRANGER)
        results = await asyncio.gather(*(
            self.engine.handle(ctx, MessageView(A, STRANGER, 100 + i, BAD), self.s.clock()) for i in range(6)))
        self.assertEqual(len(self.actions.muted), 1)
        self.assertEqual(sorted(r.muted_seconds or 0 for r in results), [0, 0, 0, 0, 0, 600])
        self.assertEqual(await self.store.count_auto_mutes(A, STRANGER, NOW - timedelta(days=1)), 1)

    async def test_keyed_locks_are_released(self):
        locks = KeyedLocks()
        async with locks.hold((1, 2)):
            self.assertEqual(len(locks), 1)
        self.assertEqual(len(locks), 0)
        with self.assertRaises(RuntimeError):
            async with locks.hold((1, 2)):
                raise RuntimeError("x")
        self.assertEqual(len(locks), 0)


class LedgerUnitTests(unittest.IsolatedAsyncioTestCase):
    async def test_offense_numbering_and_validation(self):
        store = InMemorySanctionStore()
        ledger = SanctionOffenseLedger(store)
        self.assertEqual(await ledger.next_offense(A, 9, 3600, NOW), 1)
        await ledger.record_mute(A, 9, "flood", 600, NOW, "k1")
        await ledger.record_mute(A, 9, "flood", 600, NOW, "k1")          # same key: still one row
        self.assertEqual(await ledger.next_offense(A, 9, 3600, NOW + timedelta(seconds=1)), 2)
        self.assertEqual(await ledger.next_offense(A, 9, 3600, NOW + timedelta(seconds=3600)), 1)  # window edge
        self.assertTrue(await ledger.is_restricted(A, 9, NOW))
        self.assertFalse(await ledger.is_restricted(A, 9, NOW + timedelta(seconds=600)))
        self.assertFalse(await ledger.is_restricted(B, 9, NOW))
        from guardian.errors import InvalidInput
        with self.assertRaises(InvalidInput):
            await ledger.record_mute(A, 9, "flood", 5, NOW)


if __name__ == "__main__":
    unittest.main()
