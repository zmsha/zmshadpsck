import unittest
from datetime import datetime, timedelta, timezone

from guardian.licensing.admin import MAX_LICENSE_HORIZON, LicenseAdminService
from guardian.licensing.duration_parser import (
    MAX_DURATION, DurationParseError, DurationUnit as U, ParsedDuration, compute_expiry,
    format_duration, parse_duration,
)
from guardian.errors import InvalidInput
from guardian.time_utils import format_display

H, D, W, M = U.HOUR, U.DAY, U.WEEK, U.MONTH


def P(text):
    p = parse_duration(text)
    return p.amount, p.unit


def reason(text):
    try:
        parse_duration(text)
    except DurationParseError as exc:
        return exc.reason
    raise AssertionError(f"{text!r} was accepted")


class SingularAndDualTests(unittest.TestCase):
    def test_bare_singular_is_one(self):
        for text, unit in [("ساعة", H), ("ساعه", H), ("يوم", D), ("أسبوع", W), ("اسبوع", W), ("شهر", M)]:
            with self.subTest(text):
                self.assertEqual(P(text), (1, unit))

    def test_dual_is_two(self):
        for text, unit in [("ساعتين", H), ("ساعتان", H), ("يومين", D), ("يومان", D),
                           ("أسبوعين", W), ("اسبوعين", W), ("شهرين", M), ("شهران", M)]:
            with self.subTest(text):
                self.assertEqual(P(text), (2, unit))

    def test_one_word_after_unit(self):
        self.assertEqual(P("يوم واحد"), (1, D))
        self.assertEqual(P("أسبوع واحد"), (1, W))
        self.assertEqual(P("ساعة واحدة"), (1, H))
        self.assertEqual(P("شهر واحد"), (1, M))

    def test_english(self):
        self.assertEqual(P("hour"), (1, H))
        self.assertEqual(P("3 Days"), (3, D))
        self.assertEqual(P("2 WEEKS"), (2, W))
        self.assertEqual(P("1 month"), (1, M))
        self.assertEqual(P("for 5 hours"), (5, H))


class NumberTests(unittest.TestCase):
    def test_ascii_numbers_all_units(self):
        self.assertEqual(P("2 ساعة"), (2, H))
        self.assertEqual(P("10 أيام"), (10, D))
        self.assertEqual(P("3 أسابيع"), (3, W))
        self.assertEqual(P("2 شهر"), (2, M))
        self.assertEqual(P("4 أشهر"), (4, M))
        self.assertEqual(P("6 شهور"), (6, M))
        self.assertEqual(P("15 يوم"), (15, D))

    def test_arabic_indic_digits(self):
        self.assertEqual(P("٣ أيام"), (3, D))
        self.assertEqual(P("١٠ أيام"), (10, D))
        self.assertEqual(P("٢ شهر"), (2, M))

    def test_persian_digits(self):
        self.assertEqual(P("۱۲ ساعة"), (12, H))

    def test_mixed_digit_scripts(self):
        self.assertEqual(P("1٢ يوم"), (12, D))

    def test_glued_number_and_unit(self):
        self.assertEqual(P("3ايام"), (3, D))
        self.assertEqual(P("٣أيام"), (3, D))
        self.assertEqual(P("2hours"), (2, H))

    def test_number_words(self):
        for text, n in [("ثلاث ساعات", 3), ("ثلاثة أيام", 3), ("أربعة أيام", 4), ("خمس ساعات", 5),
                        ("ستة أيام", 6), ("سبعة أيام", 7), ("ثمانية أيام", 8), ("تسع ساعات", 9),
                        ("عشرة أيام", 10)]:
            with self.subTest(text):
                self.assertEqual(P(text)[0], n)

    def test_leading_zeros_are_fine(self):
        self.assertEqual(P("007 يوم"), (7, D))


class NormalisationTests(unittest.TestCase):
    def test_hamza_and_taa_variants(self):
        self.assertEqual(P("3 ايام"), P("3 أيام"))
        self.assertEqual(P("2 اسبوع"), P("2 أسبوع"))
        self.assertEqual(P("2 ساعه"), P("2 ساعة"))

    def test_tatweel_and_diacritics(self):
        self.assertEqual(P("يـــوم"), (1, D))
        self.assertEqual(P("3 أَيَّام"), (3, D))
        self.assertEqual(P("شَهْرَيْن"), (2, M))

    def test_whitespace_and_prefix(self):
        self.assertEqual(P("   لمدة   3    أيام  "), (3, D))
        self.assertEqual(P("مدة يومين"), (2, D))
        self.assertEqual(P("\t2\nأسابيع"), (2, W))

    def test_returns_frozen_value(self):
        p = parse_duration("يوم")
        with self.assertRaises(Exception):
            p.amount = 5
        self.assertEqual(p, ParsedDuration(1, D))
        self.assertEqual(len({p, ParsedDuration(1, D)}), 1)


class RejectionTests(unittest.TestCase):
    def test_empty(self):
        for value in ["", "   ", "لمدة", None, 5, b"2 days"]:
            with self.subTest(repr(value)):
                self.assertEqual(reason(value), "empty")

    def test_zero(self):
        for text in ["0 يوم", "٠ يوم", "000 ساعة", "صفر ايام", "0"]:
            with self.subTest(text):
                self.assertEqual(reason(text), "zero")

    def test_negative(self):
        for text in ["-3 ايام", "−3 ايام", "–2 ساعة", "-1", "-0 يوم", "-٢ يوم"]:
            with self.subTest(text):
                self.assertEqual(reason(text), "negative")

    def test_fractional(self):
        for text in ["2.5 يوم", "2,5 يوم", "٢٫٥ يوم", "نصف يوم", "نص ساعة", "ربع ساعة", "نصف"]:
            with self.subTest(text):
                self.assertEqual(reason(text), "fractional")

    def test_unknown_unit(self):
        for text in ["سنة", "2 سنة", "10 دقائق", "3 minutes", "ابدا", "2 يوما"]:
            with self.subTest(text):
                self.assertEqual(reason(text), "unknown_unit")

    def test_missing_unit(self):
        for text in ["3", "٣", "ثلاث", "10"]:
            with self.subTest(text):
                self.assertEqual(reason(text), "missing_unit")

    def test_ambiguous(self):
        for text in ["ايام", "أيام", "ساعات", "أسابيع", "شهور", "2 ساعتين", "3 يومين", "ايام واحد", "ساعتين واحد"]:
            with self.subTest(text):
                self.assertEqual(reason(text), "ambiguous")

    def test_invalid_number(self):
        for text in ["يوم 3", "abc يوم", "3x يوم", "+3 يوم", "٣-٤ يوم", "واحد يوم", "يوم يوم"]:
            with self.subTest(text):
                self.assertIn(reason(text), {"invalid_number", "unknown_unit", "too_many_tokens"})

    def test_too_many_tokens(self):
        for text in ["3 ايام اضافية", "يوم يوم يوم", "لمدة 3 ايام و ساعة", "2 ساعة 3 ايام"]:
            with self.subTest(text):
                self.assertEqual(reason(text), "too_many_tokens")

    def test_control_characters_are_not_a_unit(self):
        self.assertEqual(reason("3 ايام\x00"), "unknown_unit")
        self.assertEqual(reason("\x00"), "unknown_unit")

    def test_errors_are_invalid_input(self):
        with self.assertRaises(InvalidInput):
            parse_duration("")


class LimitTests(unittest.TestCase):
    def test_constant_matches_license_service_horizon(self):
        self.assertEqual(MAX_DURATION, MAX_LICENSE_HORIZON)

    def test_boundary_days(self):
        self.assertEqual(P("1830 يوم"), (1830, D))
        self.assertEqual(reason("1831 يوم"), "too_large")

    def test_boundary_months_are_30_days(self):
        self.assertEqual(P("61 شهر"), (61, M))          # 1830 days exactly
        self.assertEqual(reason("62 شهر"), "too_large")  # 1860 days

    def test_boundary_weeks_and_hours(self):
        self.assertEqual(P("261 أسبوع"), (261, W))       # 1827 days
        self.assertEqual(reason("262 أسبوع"), "too_large")  # 1834 days
        self.assertEqual(P("43920 ساعة"), (43920, H))    # exactly 1830 days
        self.assertEqual(reason("43921 ساعة"), "too_large")

    def test_huge_digit_strings_do_not_explode(self):
        self.assertEqual(reason("9" * 5000 + " يوم"), "too_large")
        self.assertEqual(reason("99999999 ساعة"), "too_large")
        self.assertEqual(reason("٩" * 400 + " شهر"), "too_large")

    def test_long_zero_padding_is_not_too_large(self):
        self.assertEqual(P("0" * 50 + "3 يوم"), (3, D))


class MonthIsThirtyDaysTests(unittest.TestCase):
    def test_month_delta(self):
        self.assertEqual(parse_duration("شهر").delta, timedelta(days=30))
        self.assertEqual(parse_duration("شهرين").delta, timedelta(days=60))
        self.assertEqual(parse_duration("3 اشهر").delta, timedelta(days=90))

    def test_other_deltas(self):
        self.assertEqual(parse_duration("ساعة").delta, timedelta(hours=1))
        self.assertEqual(parse_duration("2 يوم").delta, timedelta(days=2))
        self.assertEqual(parse_duration("اسبوعين").delta, timedelta(days=14))

    def test_month_does_not_depend_on_calendar(self):
        for start in [datetime(2026, 1, 31, tzinfo=timezone.utc), datetime(2026, 2, 1, tzinfo=timezone.utc),
                      datetime(2028, 2, 1, tzinfo=timezone.utc), datetime(2026, 12, 31, tzinfo=timezone.utc)]:
            with self.subTest(start):
                self.assertEqual(compute_expiry(start, parse_duration("شهر")) - start, timedelta(days=30))

    def test_jan_31_plus_month(self):
        end = compute_expiry(datetime(2026, 1, 31, 10, 0, tzinfo=timezone.utc), parse_duration("شهر"))
        self.assertEqual(end, datetime(2026, 3, 2, 10, 0, tzinfo=timezone.utc))


class ExpiryAndDisplayTests(unittest.TestCase):
    NOW = datetime(2026, 10, 31, 21, 30, tzinfo=timezone.utc)

    def test_expiry_is_utc_and_starts_now(self):
        end = compute_expiry(self.NOW, parse_duration("يوم"))
        self.assertEqual(end, datetime(2026, 11, 1, 21, 30, tzinfo=timezone.utc))
        self.assertEqual(end.utcoffset(), timedelta(0))

    def test_aware_non_utc_input_is_normalised(self):
        plus3 = timezone(timedelta(hours=3))
        end = compute_expiry(datetime(2026, 11, 1, 0, 30, tzinfo=plus3), parse_duration("يوم"))
        self.assertEqual(end, datetime(2026, 11, 1, 21, 30, tzinfo=timezone.utc))

    def test_naive_now_is_rejected(self):
        with self.assertRaises(ValueError):
            compute_expiry(datetime(2026, 10, 31, 21, 30), parse_duration("يوم"))

    def test_shown_in_mecca_time(self):
        end = compute_expiry(self.NOW, parse_duration("يوم"))
        self.assertEqual(format_display(end, "Asia/Riyadh"), "2026-11-02 00:30 (Asia/Riyadh)")

    def test_longest_duration_passes_license_service_validation(self):
        end = compute_expiry(self.NOW, parse_duration("1830 يوم"))
        self.assertEqual(LicenseAdminService._validate_expiry(end, self.NOW), end)

    def test_every_accepted_duration_is_in_the_future_and_in_range(self):
        for text in ["ساعة", "يوم", "أسبوع", "شهر", "61 شهر", "1830 يوم"]:
            with self.subTest(text):
                end = compute_expiry(self.NOW, parse_duration(text))
                self.assertEqual(LicenseAdminService._validate_expiry(end, self.NOW), end)


class FormatTests(unittest.TestCase):
    def test_arabic_forms(self):
        cases = {"ساعة": "ساعة", "يومين": "يومين", "3 أيام": "3 أيام", "10 أيام": "10 أيام",
                 "11 يوم": "11 يوم", "15 يوم": "15 يوم", "شهرين": "شهرين", "4 اشهر": "4 أشهر",
                 "3 أسابيع": "3 أسابيع", "12 ساعة": "12 ساعة", "اسبوع": "أسبوع"}
        for text, expected in cases.items():
            with self.subTest(text):
                self.assertEqual(format_duration(parse_duration(text)), expected)

    def test_english_forms(self):
        self.assertEqual(format_duration(parse_duration("ساعة"), "en"), "1 hour")
        self.assertEqual(format_duration(parse_duration("يومين"), "en"), "2 days")
        self.assertEqual(format_duration(parse_duration("شهر"), "en"), "1 month")

    def test_round_trip(self):
        for text in ["ساعة", "يومين", "3 أيام", "15 يوم", "شهرين", "4 أشهر", "10 أسابيع", "12 ساعة"]:
            with self.subTest(text):
                p = parse_duration(text)
                self.assertEqual(parse_duration(format_duration(p)), p)
                self.assertEqual(parse_duration(format_duration(p, "en")), p)


class ExportTests(unittest.TestCase):
    def test_package_exports(self):
        import guardian.licensing as lic
        for name in ["parse_duration", "compute_expiry", "format_duration", "DurationParseError", "MAX_DURATION"]:
            self.assertTrue(hasattr(lic, name), name)


if __name__ == "__main__":
    unittest.main()
