"""Arabic aliases for EVERY command (part 9.3). Arabic commands are important to the owner, so this file is a guard:
a command added later without an Arabic alias fails here. Pure parsers only (no aiogram/Telegram)."""
from __future__ import annotations

import ast
import pathlib
import unittest

from guardian.bot.basic_commands import parse_basic_command
from guardian.moderation import commands as mc
from guardian.moderation.commands import Command, parse_command
from guardian.owner_panel.template_commands import parse_template_command
from guardian.owner_panel.sandbox_commands import parse_sandbox_command
from guardian.owner_panel.command import parse_owner_command
from guardian.backup.command import parse_backup_command
from guardian.backup.restore_command import parse_restore_command
from guardian.licensing.commands import parse_license_command

SRC = pathlib.Path(__file__).resolve().parents[1] / "src" / "guardian"


class EveryModerationCommandHasArabic(unittest.TestCase):
    def test_every_command_enum_member_has_an_arabic_alias(self):
        self.assertEqual(set(Command), set(mc._ARABIC_ALIASES))
        for cmd, aliases in mc._ARABIC_ALIASES.items():
            self.assertTrue(aliases, cmd)
            for alias in aliases:
                self.assertTrue(any("\u0600" <= ch <= "\u06ff" for ch in alias), (cmd, alias))

    def test_menu_commands_all_covered(self):
        from guardian.bot import commands_menu as menu
        slash = set(menu.BASIC) | set(menu.PUBLIC) | set(menu.MODERATION)
        covered = {c.value for c in Command} | set(menu.BASIC)
        self.assertEqual(slash - covered, set())


class BasicCommandsArabic(unittest.TestCase):
    def test_private(self):
        for text, want in (("ابدأ", "start"), ("بدء", "start"), ("مساعدة", "help"), ("المساعدة", "help"),
                           ("حالة البوت", "status"), ("الحالة", "status"), ("  مساعدة  ", "help"),
                           ("الأوامر", "commands"), ("الاوامر", "commands"), ("اوامر", "commands"), ("أوامر", "commands")):
            self.assertEqual(parse_basic_command(text, private=True), want, text)

    def test_group_only_distinctive_phrases(self):
        for text, want in (("قائمة الاوامر", "help"), ("قائمة الأوامر", "help"), ("اوامر البوت", "help"), ("ابدأ البوت", "start"),
                           ("الاوامر", "commands"), ("الأوامر", "commands")):
            self.assertEqual(parse_basic_command(text, private=False), want, text)
        for text in ("مساعدة", "ابدأ", "بدء", "اوامر", "حالة البوت", "الحالة"):
            self.assertIsNone(parse_basic_command(text, private=False), text)  # "حالة البوت" in a group = licence command

    def test_ordinary_chat_is_never_a_command(self):
        for text in ("مساعدة لو سمحت", "ابدأ العمل", "الحالة سيئة", "/help", "", "   ", "قائمة الاوامر اليوم", None, 5):
            self.assertIsNone(parse_basic_command(text, private=True), text)
            self.assertIsNone(parse_basic_command(text, private=False), text)

    def test_group_status_arabic_is_the_licence_command(self):
        parsed = parse_license_command("حالة البوت")
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed.command.value, "status")


class ProtectArabicAlias(unittest.TestCase):
    def test_short_alias_with_subcommand(self):
        for text, args in (("حماية فلتر ai off", ("فلتر", "ai", "off")), ("حماية اباحي off", ("اباحي", "off")),
                           ("الحماية فلتر صور ايقاف", ("فلتر", "صور", "ايقاف")), ("حماية الروابط تشغيل", ("الروابط", "تشغيل")),
                           ("حماية فلتر استثناء اضف 123", ("فلتر", "استثناء", "اضف", "123"))):
            parsed = parse_command(text)
            self.assertIsNotNone(parsed, text)
            self.assertEqual((parsed.command, parsed.args, parsed.arabic), (Command.PROTECT, args, True), text)

    def test_long_aliases_still_work_and_bare_short_word_is_chat(self):
        self.assertEqual(parse_command("اعدادات الحماية").command, Command.PROTECT)
        self.assertEqual(parse_command("ضبط الحماية فلتر ai off").command, Command.PROTECT)
        for text in ("حماية", "الحماية", "حماية الاطفال مهمة", "الحماية واجبة علينا"):
            self.assertIsNone(parse_command(text), text)

    def test_every_documented_filter_command_parses_in_arabic(self):
        from guardian.moderation import config_args
        for text in ("حماية فلتر ai off", "حماية فلتر ايموجي on", "حماية فلتر اللغات off", "حماية فلتر الاسماء on",
                     "حماية فلتر صور off", "حماية فلتر استثناء قائمة", "حماية فلتر استثناء مسح", "حماية اباحي قائمة",
                     "حماية اباحي مسح", "حماية اباحي اضف كلمة", "حماية اباحي ازل كلمة"):
            parsed = parse_command(text)
            self.assertIsNotNone(parsed, text)
            config_args.parse_protect_args(parsed.args)  # must not raise


class FilterPhrases(unittest.TestCase):
    """Part 9.4: natural Arabic sentences for the content filter (`تفعيل فلتر ai`, `اضافة كلمة X`...)."""

    def _protect(self, text):
        from guardian.moderation import config_args
        parsed = parse_command(text)
        self.assertIsNotNone(parsed, text)
        self.assertEqual((parsed.command, parsed.arabic), (Command.PROTECT, True), text)
        return config_args.parse_protect_args(parsed.args)

    def test_text_filter_on_off(self):
        for text, on in (("تفعيل الفلتر النصي", True), ("تشغيل الفلتر النصي", True), ("ايقاف الفلتر النصي", False),
                         ("إيقاف الفلتر النصي", False), ("تعطيل الفلتر النصي", False)):
            parsed = self._protect(text)
            self.assertEqual((parsed.op, parsed.patch), ("set", {"adult_enabled": on}), text)

    def test_add_and_remove_one_word_and_many_words(self):
        self.assertEqual(self._protect("اضافة كلمة سكس").op, "adult_add")
        self.assertEqual(self._protect("اضف كلمة سكس").words, ("سكس",))
        self.assertEqual(self._protect("حذف كلمة سكس").op, "adult_remove")
        self.assertEqual(self._protect("ازالة كلمة سكس").op, "adult_remove")
        many = self._protect("اضافة كلمات كلب حمار تيس")
        self.assertEqual((many.op, many.words), ("adult_add", ("كلب", "حمار", "تيس")))
        many = self._protect("حذف كلمات كلب حمار")
        self.assertEqual((many.op, many.words), ("adult_remove", ("كلب", "حمار")))
        self.assertEqual(self._protect("اضافة كلمات كلب").words, ("كلب",))

    def test_list_and_clear_are_whole_message_only(self):
        self.assertEqual(self._protect("قائمة الكلمات").op, "adult_list")
        self.assertEqual(self._protect("مسح الكلمات").op, "adult_clear")
        self.assertIsNone(parse_command("قائمة الكلمات اليوم"))
        self.assertIsNone(parse_command("مسح الكلمات من اللوحة"))

    def test_ai_filter_both_spellings(self):
        for text, on in (("تفعيل فلتر الذكاء الاصطناعي", True), ("تفعيل فلتر ai", True), ("تفعيل فلتر AI", True),
                         ("تعطيل فلتر الذكاء الاصطناعي", False), ("تعطيل فلتر ai", False), ("ايقاف فلتر ai", False),
                         ("تفعيل الفلتر الذكاء الاصطناعي", True)):
            parsed = self._protect(text)
            self.assertEqual((parsed.op, parsed.patch), ("set", {"cf_ai": on}), text)

    def test_other_filters(self):
        for text, key in (("تفعيل فلتر الايموجي", "cf_emoji"), ("تعطيل فلتر اللغات", "cf_scripts"),
                          ("تفعيل فلتر الاسماء", "cf_names"), ("تعطيل فلتر الصور", "cf_photos")):
            parsed = self._protect(text)
            self.assertEqual(list(parsed.patch), [key], text)

    def test_ordinary_chat_is_not_a_command(self):
        for text in ("حذف كلمة من الجملة", "اضف كلمة جديدة وجميلة", "اضافة كلمة", "حذف كلمات", "تفعيل الفلتر", "تفعيل فلتر",
                     "نريد تفعيل فلتر ai", "تفعيل فلتر ai الان", "تعطيل فلتر الصور بسرعة", "اضافة كلمات"):
            self.assertIsNone(parse_command(text), text)

    def test_no_clash_with_existing_aliases(self):
        self.assertEqual(parse_command("مسح التحذيرات @ahmed123").command, Command.CLEARWARNS)
        self.assertEqual(parse_command("حذف الرسائل 5").command, Command.PURGE)
        self.assertIsNone(parse_license_command("تفعيل فلتر ai"))
        self.assertEqual(parse_license_command("تفعيل البوت").command.value, "activate")


class DefaultsArabic(unittest.TestCase):
    def test_all_four_actions(self):
        for text, action, name, code in (
                ("الافتراضيات", "defaults_show", None, None), ("عرض الافتراضيات", "defaults_show", None, None),
                ("تعيين الافتراضيات قالبي", "defaults_set", "قالبي", None), ("الافتراضيات تعيين قالب 1", "defaults_set", "قالب 1", None),
                ("اعادة الافتراضيات", "defaults_reset", None, None), ("إعادة الافتراضيات", "defaults_reset", None, None),
                ("الافتراضيات اعادة", "defaults_reset", None, None),
                ("تاكيد الافتراضيات AB12CD", "defaults_confirm", None, "AB12CD"), ("تأكيد الافتراضيات AB12CD", "defaults_confirm", None, "AB12CD")):
            parsed = parse_template_command(text)
            self.assertIsNotNone(parsed, text)
            self.assertEqual((parsed.action, parsed.name, parsed.code), (action, name, code), text)

    def test_bad_forms_are_usage_or_ignored(self):
        self.assertEqual(parse_template_command("تاكيد الافتراضيات").action, "usage")
        self.assertEqual(parse_template_command("اعادة الافتراضيات زيادة").action, "usage")
        self.assertEqual(parse_template_command("تعيين الافتراضيات").action, "usage")
        self.assertIsNone(parse_template_command("الافتراضيات الحلوة جدا اليوم"))
        self.assertIsNone(parse_template_command("تعيين الاعدادات قالب"))


class OwnerCommandsArabic(unittest.TestCase):
    def test_owner_family(self):
        self.assertIsNotNone(parse_owner_command("لوحة المالك"))
        self.assertEqual(parse_template_command("القوالب").action, "list")
        self.assertEqual(parse_template_command("حفظ قالب x -100123").action, "save")
        self.assertEqual(parse_template_command("قارن قالب x -100123").action, "diff")
        self.assertEqual(parse_template_command("حذف قالب x").action, "delete")
        self.assertEqual(parse_template_command("تطبيق قالب x -100123").action, "apply")
        self.assertEqual(parse_template_command("تاكيد قالب AB12CD").action, "confirm")
        self.assertEqual(parse_sandbox_command("تجربة").action, "status")
        self.assertEqual(parse_sandbox_command("تجربة انهاء").action, "end")
        self.assertEqual(parse_backup_command("نسخة احتياطية").action, "preview")
        self.assertEqual(parse_backup_command("تأكيد نسخة AB12CD").action, "confirm")
        self.assertEqual(parse_restore_command("استعادة نسخة").action, "preview")
        for text, cmd in (("تفعيل البوت", "activate"), ("إيقاف البوت", "stop"), ("حالة البوت", "status")):
            self.assertEqual(parse_license_command(text).command.value, cmd, text)


class RouterWiring(unittest.TestCase):
    """aiogram is not installed in the test environment: check the wiring from the source."""

    def test_basic_router_registers_the_arabic_handler(self):
        src = (SRC / "bot" / "routers" / "basic.py").read_text(encoding="utf-8")
        tree = ast.parse(src)
        funcs = {n.name for n in ast.walk(tree) if isinstance(n, ast.AsyncFunctionDef)}
        self.assertTrue({"cmd_start", "cmd_help", "cmd_status", "on_arabic_basic", "_is_arabic_basic"} <= funcs)
        self.assertIn("parse_basic_command", src)
        self.assertIn("private=message.chat.type == \"private\"", src)

    def test_basic_commands_module_is_pure(self):
        src = (SRC / "bot" / "basic_commands.py").read_text(encoding="utf-8")
        imported = {n.module or "" for n in ast.walk(ast.parse(src)) if isinstance(n, ast.ImportFrom)}
        self.assertFalse(any(m.startswith(("aiogram", "fastapi", "asyncpg")) for m in imported))


if __name__ == "__main__":
    unittest.main()
