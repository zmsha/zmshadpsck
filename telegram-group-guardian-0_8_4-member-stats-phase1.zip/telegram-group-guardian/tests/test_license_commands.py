"""Part 5.2: `تفعيل البوت [مدة]` / `إيقاف البوت` / `حالة البوت` (+ `/activate`, `/deactivate`).

Stdlib-only: the aiogram router (`bot/routers/licensing.py`), `create_app` and real Telegram are NOT exercised here.
"""
from __future__ import annotations

import asyncio
import unittest
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace as NS

import helpers  # noqa: F401
from guardian.bot import license_handler as h
from guardian.bot.middlewares import ProtectionGateMiddleware
from guardian.groups.models import GroupRole
from guardian.idempotency import InMemoryIdempotency
from guardian.i18n import MESSAGES
from guardian.licensing.commands import (LicenseCommand as C, LicenseCommandService, ParsedLicenseCommand,
                                         ResultKind as R, parse_license_command)
from guardian.licensing.models import LicenseStatus as S
from guardian.protection_gate import ProtectionGate
from guardian.services import Services
from guardian.telegram_rights import ChatMemberInfo
from helpers import FakeNotifier
from stack import A, B, BACKUP, DELEGATE, NOW, OWNER, STRANGER, TG_ADMIN, TG_CREATOR, Stack

ANON = 1087968824  # GroupAnonymousBot
SRC = Path(__file__).resolve().parents[1] / "src" / "guardian"


def P(text, username=None):
    return parse_license_command(text, username)


class ParserTests(unittest.TestCase):
    def test_arabic_commands(self):
        self.assertEqual(P("تفعيل البوت"), ParsedLicenseCommand(C.ACTIVATE, "", True))
        self.assertEqual(P("إيقاف البوت").command, C.STOP)
        self.assertEqual(P("ايقاف البوت").command, C.STOP)
        self.assertEqual(P("حالة البوت").command, C.STATUS)
        self.assertEqual(P("حاله البوت").command, C.STATUS)

    def test_activate_with_duration_text(self):
        for text, arg in [("تفعيل البوت ساعة", "ساعه"), ("تفعيل البوت 3 أيام", "3 ايام"), ("تفعيل البوت لمدة شهرين", "لمده شهرين"),
                          ("  تفعيل   البوت   ٢  أسبوع ", "2 اسبوع")]:
            with self.subTest(text):
                parsed = P(text)
                self.assertEqual((parsed.command, parsed.arg), (C.ACTIVATE, arg))

    def test_tatweel_and_diacritics(self):
        self.assertEqual(P("تفعـيل البوت").command, C.ACTIVATE)
        self.assertEqual(P("حَالَةُ البوت" .replace("ُ", "")).command, C.STATUS)

    def test_not_commands(self):
        for text in ["تفعيل", "تفعيل البوتات", "تفعيل البوتات 3 ايام", "أريد تفعيل البوت", "ايقاف البوت الان", "حالة البوت اليوم",
                     "ايقاف البوت 3 ايام", "", "   ", None, 5, "مرحبا", "x" * 300, "تفعيل البوت " + "ا" * 300]:
            with self.subTest(repr(text)[:30]):
                self.assertIsNone(P(text))

    def test_slash_forms(self):
        self.assertEqual(P("/activate"), ParsedLicenseCommand(C.ACTIVATE, "", False))
        self.assertEqual(P("/activate 2 days").arg, "2 days")
        self.assertEqual(P("/ACTIVATE 1 month").command, C.ACTIVATE)
        self.assertEqual(P("/deactivate").command, C.STOP)

    def test_slash_addressed_forms(self):
        self.assertEqual(P("/activate@GuardBot 1 week", "guardbot").arg, "1 week")
        self.assertIsNone(P("/activate@other_bot", "guardbot"))
        self.assertIsNone(P("/activate@guardbot", None))  # own name unknown: ignore addressed forms

    def test_slash_non_commands(self):
        for text in ["/deactivate now", "/stop", "/status", "/activateme", "/ activate", "//activate"]:
            with self.subTest(text):
                self.assertIsNone(P(text))


class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A, B)
        self.claims = InMemoryIdempotency()
        self.svc = LicenseCommandService(license_admin=self.s.admin, license_service=self.s.license_service,
                                         permissions=self.s.perm, claims=self.claims, clock=self.s.clock)
        self.mid = 100

    async def run_cmd(self, text, actor=OWNER, chat=A, lang="ar", mid=None):
        parsed = P(text, "guardbot")
        self.assertIsNotNone(parsed, text)
        if mid is None:
            self.mid += 1
            mid = self.mid
        return await self.svc.handle(parsed, chat_id=chat, actor_id=actor, message_id=mid, language=lang)

    async def lic(self, chat=A):
        return await self.s.licenses.get(chat)


class OwnerActivationTests(Base):
    async def test_permanent_activation(self):
        res = await self.run_cmd("تفعيل البوت")
        lic = await self.lic()
        self.assertEqual(res.kind, R.CHANGED)
        self.assertEqual((lic.status, lic.expires_at, lic.activated_by), (S.ACTIVE_PERMANENT, None, OWNER))
        self.assertIn("دائمًا", res.text)

    async def test_temporary_activation_starts_now_and_shows_mecca_time(self):
        res = await self.run_cmd("تفعيل البوت 3 أيام")
        lic = await self.lic()
        self.assertEqual((lic.status, lic.expires_at), (S.ACTIVE_TEMPORARY, NOW + timedelta(days=3)))
        self.assertIn("2026-11-01 15:00 (Asia/Riyadh)", res.text)
        self.assertIn("3 أيام", res.text)

    async def test_month_is_30_days(self):
        await self.run_cmd("تفعيل البوت شهر")
        self.assertEqual((await self.lic()).expires_at, NOW + timedelta(days=30))
        await self.run_cmd("تفعيل البوت شهرين")
        self.assertEqual((await self.lic()).expires_at, NOW + timedelta(days=60))

    async def test_arabic_digits_and_words(self):
        await self.run_cmd("تفعيل البوت ١٠ أيام")
        self.assertEqual((await self.lic()).expires_at, NOW + timedelta(days=10))
        await self.run_cmd("تفعيل البوت لمدة ثلاث ساعات")
        self.assertEqual((await self.lic()).expires_at, NOW + timedelta(hours=3))

    async def test_slash_commands_work_too(self):
        await self.run_cmd("/activate 2 weeks")
        self.assertEqual((await self.lic()).expires_at, NOW + timedelta(days=14))
        await self.run_cmd("/deactivate")
        self.assertEqual((await self.lic()).status, S.STOPPED)

    async def test_longest_duration_is_accepted(self):
        res = await self.run_cmd("تفعيل البوت 1830 يوم")
        self.assertEqual(res.kind, R.CHANGED)
        self.assertEqual((await self.lic()).expires_at, NOW + timedelta(days=1830))

    async def test_english_reply(self):
        res = await self.run_cmd("/activate 2 days", lang="en")
        self.assertIn("activated for", res.text)
        self.assertIn("2 days", res.text)

    async def test_audit_records_the_owner(self):
        await self.run_cmd("تفعيل البوت 2 يوم")
        last = self.s.licenses.audit_log[-1]
        self.assertEqual((last.actor_telegram_id, last.group_id, last.new_status), (OWNER, A, S.ACTIVE_TEMPORARY))

    async def test_other_groups_untouched(self):
        await self.run_cmd("تفعيل البوت")
        self.assertEqual((await self.lic(B)).status, S.PENDING)

    async def test_unregistered_group(self):
        res = await self.run_cmd("تفعيل البوت", chat=-1555)
        self.assertEqual(res.kind, R.REFUSED)
        self.assertIsNone(await self.lic(-1555))


class RenewalTests(Base):
    async def test_renewal_starts_from_the_moment_of_the_command(self):
        await self.run_cmd("تفعيل البوت 3 أيام")
        self.s.clock.advance(days=1)
        res = await self.run_cmd("تفعيل البوت 5 أيام")
        self.assertEqual((await self.lic()).expires_at, self.s.clock() + timedelta(days=5))  # from now, NOT old expiry + 5d
        self.assertIn("تجديد", res.text)

    async def test_renew_after_expiry_after_sleep(self):
        await self.run_cmd("تفعيل البوت ساعة")
        self.s.clock.advance(days=5)  # the service slept; nothing persisted the expiry
        res = await self.run_cmd("تفعيل البوت أسبوع")
        lic = await self.lic()
        self.assertEqual((res.kind, lic.status, lic.expires_at), (R.CHANGED, S.ACTIVE_TEMPORARY, self.s.clock() + timedelta(days=7)))

    async def test_permanent_then_temporary_and_back(self):
        await self.run_cmd("تفعيل البوت")
        await self.run_cmd("تفعيل البوت 2 يوم")
        self.assertEqual((await self.lic()).status, S.ACTIVE_TEMPORARY)
        await self.run_cmd("تفعيل البوت")
        self.assertEqual((await self.lic()).expires_at, None)

    async def test_permanent_repeat_is_no_change(self):
        await self.run_cmd("تفعيل البوت")
        res = await self.run_cmd("تفعيل البوت")
        self.assertEqual(res.kind, R.NO_CHANGE)
        self.assertEqual(len([e for e in self.s.licenses.audit_log if e.action == "activate_permanent"]), 1)


class StopTests(Base):
    async def test_stop_active(self):
        await self.run_cmd("تفعيل البوت")
        res = await self.run_cmd("إيقاف البوت")
        self.assertEqual((res.kind, (await self.lic()).status), (R.CHANGED, S.STOPPED))
        self.assertIn("إيقاف", res.text)

    async def test_stop_twice_is_no_change(self):
        await self.run_cmd("تفعيل البوت")
        await self.run_cmd("إيقاف البوت")
        self.assertEqual((await self.run_cmd("إيقاف البوت")).kind, R.NO_CHANGE)

    async def test_stop_pending_is_refused_with_state(self):
        res = await self.run_cmd("إيقاف البوت")
        self.assertEqual(res.kind, R.REFUSED)
        self.assertIn("بانتظار", res.text)
        self.assertEqual((await self.lic()).status, S.PENDING)

    async def test_activate_after_stop(self):
        await self.run_cmd("تفعيل البوت")
        await self.run_cmd("إيقاف البوت")
        await self.run_cmd("تفعيل البوت يوم")
        self.assertEqual((await self.lic()).status, S.ACTIVE_TEMPORARY)

    async def test_rejected_and_banned_need_lifting_first(self):
        await self.s.admin.reject(OWNER, A)
        res = await self.run_cmd("تفعيل البوت")
        self.assertEqual(res.kind, R.REFUSED)
        self.assertIn("رفع", res.text)
        self.assertEqual((await self.lic()).status, S.REJECTED)
        await self.s.admin.ban(OWNER, B)
        res = await self.run_cmd("تفعيل البوت 3 أيام", chat=B)
        self.assertEqual((await self.lic(B)).status, S.BANNED)
        self.assertIn("رفع", res.text)


class NonOwnerTests(Base):
    async def assert_unchanged(self):
        lic = await self.lic()
        self.assertEqual((lic.status, lic.expires_at), (S.PENDING, None))
        self.assertEqual([e.action for e in self.s.licenses.audit_log if e.action != "register_pending"], [])

    async def test_telegram_admins_are_told_owner_only(self):
        for actor in (TG_CREATOR, TG_ADMIN):
            for text in ["تفعيل البوت", "تفعيل البوت 3 أيام", "إيقاف البوت", "/activate"]:
                with self.subTest((actor, text)):
                    res = await self.run_cmd(text, actor=actor)
                    self.assertEqual(res.kind, R.OWNER_ONLY)
                    self.assertIn("مالك البوت", res.text)
        await self.assert_unchanged()

    async def test_delegates_cannot_activate_or_renew(self):
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.GROUP_MANAGER)
        res = await self.run_cmd("تفعيل البوت", actor=DELEGATE)
        self.assertEqual(res.kind, R.OWNER_ONLY)
        await self.assert_unchanged()

    async def test_strangers_and_members_get_silence(self):
        for text in ["تفعيل البوت", "تفعيل البوت 3 أيام", "إيقاف البوت"]:
            res = await self.run_cmd(text, actor=STRANGER)
            self.assertEqual((res.kind, res.text), (R.IGNORED, ""))
        await self.assert_unchanged()

    async def test_backup_owner_cannot_change_license(self):
        res = await self.run_cmd("تفعيل البوت", actor=BACKUP)
        self.assertEqual(res.text, "")
        self.s.chat.set(A, BACKUP, ChatMemberInfo("administrator", True, True, True))
        res = await self.run_cmd("تفعيل البوت", actor=BACKUP)
        self.assertEqual(res.kind, R.OWNER_ONLY)
        await self.assert_unchanged()

    async def test_anonymous_admin_and_service_accounts_are_ignored(self):
        for actor in (ANON, 777000, 136817688, None, 0, -5, True, "111111111"):
            with self.subTest(repr(actor)):
                res = await self.run_cmd("تفعيل البوت", actor=actor)
                self.assertEqual((res.kind, res.text), (R.IGNORED, ""))
        await self.assert_unchanged()

    async def test_owner_in_another_group_cannot_change_this_one(self):
        # the permission check requires the command's chat to be the target group
        decision = await self.s.perm.check(OWNER, A, __import__("guardian.permissions", fromlist=["Permission"]).Permission.CHANGE_LICENSE,
                                           context_chat_id=B)
        self.assertEqual((decision.allowed, decision.reason), (False, "chat_mismatch"))

    async def test_denials_are_audited_and_do_not_burn_claims(self):
        await self.run_cmd("تفعيل البوت", actor=STRANGER, mid=7)
        self.assertTrue(any(e.group_id == A and e.permission == "change_license" for e in self.s.audit.events))
        res = await self.run_cmd("تفعيل البوت", actor=OWNER, mid=7)  # the same message id is still usable by the owner
        self.assertEqual(res.kind, R.CHANGED)

    async def test_lookup_failure_denies_non_owner_but_not_owner(self):
        self.s.chat.fail = True
        res = await self.run_cmd("تفعيل البوت", actor=TG_ADMIN)
        self.assertEqual(res.kind, R.IGNORED)
        self.assertEqual((await self.run_cmd("تفعيل البوت")).kind, R.CHANGED)


class InvalidDurationTests(Base):
    CASES = {"0 يوم": "zero", "-3 ايام": "negative", "2.5 يوم": "fractional", "3": "missing_unit", "3 سنوات": "unknown_unit",
             "ايام": "ambiguous", "2 ساعتين": "ambiguous", "100 شهر": "too_large", "1831 يوم": "too_large",
             "3 ايام اضافية": "too_many_tokens", "يوم يوم": "invalid_number"}

    async def test_rejected_without_changing_anything(self):
        for text, reason in self.CASES.items():
            with self.subTest(text):
                res = await self.run_cmd("تفعيل البوت " + text)
                self.assertEqual(res.kind, R.INVALID)
                self.assertIn(MESSAGES["ar"][f"lic_dur_err_{reason}"].split(" (")[0][:12], res.text)
                self.assertIn("أمثلة", res.text)
        self.assertEqual((await self.lic()).status, S.PENDING)

    async def test_every_error_reason_has_a_message_in_both_languages(self):
        for reason in ["empty", "missing_unit", "unknown_unit", "invalid_number", "zero", "negative", "fractional", "ambiguous",
                       "too_many_tokens", "too_large"]:
            for lang in ("ar", "en"):
                self.assertIn(f"lic_dur_err_{reason}", MESSAGES[lang])

    async def test_non_owner_typing_a_bad_duration_learns_nothing(self):
        res = await self.run_cmd("تفعيل البوت 0 يوم", actor=STRANGER)
        self.assertEqual((res.kind, res.text), (R.IGNORED, ""))


class IdempotencyTests(Base):
    async def test_redelivered_update_applies_once(self):
        first = await self.run_cmd("تفعيل البوت 3 أيام", mid=55)
        expiry = (await self.lic()).expires_at
        self.s.clock.advance(hours=5)
        second = await self.run_cmd("تفعيل البوت 3 أيام", mid=55)
        self.assertEqual((first.kind, second.kind, second.text), (R.CHANGED, R.IGNORED, ""))
        self.assertEqual((await self.lic()).expires_at, expiry)

    async def test_distinct_messages_apply_separately(self):
        await self.run_cmd("تفعيل البوت 3 أيام", mid=1)
        self.s.clock.advance(hours=5)
        await self.run_cmd("تفعيل البوت 3 أيام", mid=2)
        self.assertEqual((await self.lic()).expires_at, self.s.clock() + timedelta(days=3))

    async def test_claim_failure_changes_nothing(self):
        class Broken:
            async def claim(self, key, now=None):
                raise RuntimeError("db down")
        svc = LicenseCommandService(license_admin=self.s.admin, license_service=self.s.license_service,
                                    permissions=self.s.perm, claims=Broken(), clock=self.s.clock)
        res = await svc.handle(P("تفعيل البوت"), chat_id=A, actor_id=OWNER, message_id=1)
        self.assertEqual(res.kind, R.ERROR)
        self.assertEqual((await self.lic()).status, S.PENDING)


class FailureTests(Base):
    async def test_store_down_fails_safe(self):
        async def boom(group_id):
            raise RuntimeError("db down")
        self.s.licenses.get = boom
        res = await self.run_cmd("تفعيل البوت")
        self.assertEqual(res.kind, R.ERROR)
        self.assertNotIn("db down", res.text)

    async def test_command_never_raises_on_garbage_actor(self):
        res = await self.svc.handle(P("حالة البوت"), chat_id=A, actor_id=object(), message_id=1)
        self.assertEqual(res.kind, R.IGNORED)


class StatusTests(Base):
    async def test_permanent_status(self):
        await self.run_cmd("تفعيل البوت")
        res = await self.run_cmd("حالة البوت", actor=TG_ADMIN)
        self.assertEqual(res.kind, R.STATUS)
        for needle in ("مفعّلة دائمًا", "دائم", "تعمل", "Asia/Riyadh"):
            self.assertIn(needle, res.text)

    async def test_temporary_status_shows_expiry_and_remaining(self):
        await self.run_cmd("تفعيل البوت 3 أيام")
        self.s.clock.advance(hours=2)
        res = await self.run_cmd("حالة البوت")
        self.assertIn("2026-11-01 15:00 (Asia/Riyadh)", res.text)
        self.assertIn("يومين", res.text)  # 2 days 22 h left -> "يومين"
        self.assertIn("تعمل", res.text)

    async def test_remaining_hours_and_less_than_an_hour(self):
        await self.run_cmd("تفعيل البوت 5 ساعات")
        self.s.clock.advance(minutes=30)
        self.assertIn("4 ساعات", (await self.run_cmd("حالة البوت")).text)
        self.s.clock.advance(hours=4, minutes=15)
        self.assertIn("أقل من ساعة", (await self.run_cmd("حالة البوت")).text)

    async def test_expired_status_is_readable_and_protection_off(self):
        await self.run_cmd("تفعيل البوت ساعة")
        self.s.clock.advance(days=2)
        res = await self.run_cmd("حالة البوت", actor=TG_CREATOR)
        self.assertEqual(res.kind, R.STATUS)
        self.assertIn("منتهية", res.text)
        self.assertIn("متوقفة", res.text)

    async def test_pending_stopped_banned_statuses(self):
        self.assertIn("بانتظار", (await self.run_cmd("حالة البوت")).text)
        await self.s.admin.ban(OWNER, B)
        self.assertIn("محظورة", (await self.run_cmd("حالة البوت", chat=B)).text)

    async def test_unregistered_group(self):
        res = await self.run_cmd("حالة البوت", chat=-1777)
        self.assertEqual(res.kind, R.STATUS)
        self.assertIn("غير مسجلة", res.text)

    async def test_only_admins_delegates_and_owner_see_status(self):
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.MODERATOR)
        for actor in (OWNER, TG_CREATOR, TG_ADMIN, DELEGATE):
            with self.subTest(actor):
                self.assertEqual((await self.run_cmd("حالة البوت", actor=actor)).kind, R.STATUS)
        for actor in (STRANGER, BACKUP, ANON, None):
            with self.subTest(actor):
                res = await self.run_cmd("حالة البوت", actor=actor)
                self.assertEqual((res.kind, res.text), (R.IGNORED, ""))

    async def test_group_admin_of_another_group_sees_nothing(self):
        res = await self.run_cmd("حالة البوت", actor=TG_ADMIN, chat=B)  # TG_ADMIN is an admin of A only
        self.assertEqual(res.text, "")

    async def test_status_is_read_only(self):
        await self.run_cmd("تفعيل البوت 2 أيام")
        before = list(self.s.licenses.audit_log)
        await self.run_cmd("حالة البوت")
        self.assertEqual(self.s.licenses.audit_log, before)

    async def test_store_error_text(self):
        async def boom(group_id):
            raise RuntimeError("db down")
        self.s.licenses.get = boom
        res = await self.run_cmd("حالة البوت")
        self.assertIn("تعذر", res.text)

    async def test_english_status(self):
        await self.run_cmd("تفعيل البوت")
        res = await self.run_cmd("حالة البوت", lang="en")
        self.assertIn("Bot status", res.text)
        self.assertIn("running", res.text)


# --------------------------------------------------------------------------- Telegram message glue
class Msg:
    def __init__(self, text, *, chat=A, ctype="supergroup", sender=OWNER, mid=1, lang="ar", is_bot=False):
        self.text, self.message_id = text, mid
        self.chat = NS(id=chat, type=ctype, title="T")
        self.from_user = NS(id=sender, is_bot=is_bot, language_code=lang) if sender else None
        self.replies: list[str] = []
        self.fail_reply = False

    async def reply(self, text):
        if self.fail_reply:
            raise RuntimeError("cannot send")
        self.replies.append(text)


class FakeBot:
    def __init__(self, username="guardbot", fail=False):
        self.username, self.fail, self.me_calls = username, fail, 0

    async def me(self):
        self.me_calls += 1
        await asyncio.sleep(0)
        if self.fail:
            raise RuntimeError("getMe down")
        return NS(id=777, username=self.username)


class HandlerTests(Base):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.services = NS(license_commands=self.svc, settings=NS(default_language="ar"))
        self.bot = FakeBot()

    async def go(self, msg):
        parsed = await h.match_command(msg, self.bot)
        return None if parsed is None else await h.execute(msg, parsed, services=self.services)

    async def test_owner_activates_and_gets_a_reply(self):
        msg = Msg("تفعيل البوت 2 يوم")
        res = await self.go(msg)
        self.assertEqual(res.kind, R.CHANGED)
        self.assertEqual(len(msg.replies), 1)
        self.assertEqual((await self.lic()).status, S.ACTIVE_TEMPORARY)

    async def test_arabic_commands_do_not_call_getme(self):
        await self.go(Msg("تفعيل البوت"))
        self.assertEqual(self.bot.me_calls, 0)

    async def test_slash_with_bot_suffix(self):
        await self.go(Msg("/activate@guardbot 3 days"))
        self.assertEqual((await self.lic()).expires_at, NOW + timedelta(days=3))
        self.assertEqual(await self.go(Msg("/activate@somebot")), None)

    async def test_getme_down_keeps_arabic_working_and_ignores_addressed_slash(self):
        self.bot = FakeBot(fail=True)
        self.assertIsNone(await self.go(Msg("/activate@guardbot")))
        self.assertEqual((await self.go(Msg("تفعيل البوت"))).kind, R.CHANGED)

    async def test_only_group_text_from_real_senders(self):
        for msg in [Msg("تفعيل البوت", ctype="private", chat=OWNER), Msg("تفعيل البوت", ctype="channel"),
                    Msg("تفعيل البوت", sender=None), Msg("تفعيل البوت", is_bot=True), Msg(None)]:
            self.assertIsNone(await self.go(msg))
        self.assertEqual((await self.lic()).status, S.PENDING)

    async def test_plain_conversation_is_ignored(self):
        self.assertIsNone(await self.go(Msg("مرحبا بالجميع")))

    async def test_reply_failure_never_raises_or_undoes(self):
        msg = Msg("تفعيل البوت")
        msg.fail_reply = True
        res = await self.go(msg)
        self.assertEqual(res.kind, R.CHANGED)
        self.assertEqual((await self.lic()).status, S.ACTIVE_PERMANENT)

    async def test_silent_results_send_nothing(self):
        msg = Msg("تفعيل البوت", sender=STRANGER)
        await self.go(msg)
        self.assertEqual(msg.replies, [])

    async def test_sender_language_is_used(self):
        msg = Msg("/activate 1 day", lang="en-US")
        await self.go(msg)
        self.assertIn("activated for", msg.replies[0])

    async def test_missing_service_is_a_noop(self):
        parsed = await h.match_command(Msg("تفعيل البوت"), self.bot)
        self.assertIsNone(await h.execute(Msg("تفعيل البوت"), parsed, services=NS(license_commands=None, settings=NS(default_language="ar"))))


class MiddlewareTests(Base):
    """The owner's command must work in every license state (the middleware only enriches the update)."""

    async def test_owner_reactivates_through_the_real_gate_in_every_blocked_state(self):
        gate = ProtectionGate(self.s.license_service, self.s.perm, FakeNotifier(), clock=self.s.clock)
        mw = ProtectionGateMiddleware(gate)
        services = NS(license_commands=self.svc, settings=NS(default_language="ar"))
        bot = FakeBot()

        async def handler(event, data):
            parsed = await h.match_command(event, bot)
            return await h.execute(event, parsed, services=services)

        await self.s.admin.activate_temporary(OWNER, A, NOW + timedelta(hours=1))
        self.s.clock.advance(days=1)  # expired by time only
        res = await mw(handler, Msg("تفعيل البوت 2 أيام", mid=1), {})
        self.assertEqual(res.kind, R.CHANGED)
        await self.s.admin.stop(OWNER, A)
        res = await mw(handler, Msg("تفعيل البوت", mid=2), {})
        self.assertEqual((res.kind, (await self.lic()).status), (R.CHANGED, S.ACTIVE_PERMANENT))
        await self.s.admin.ban(OWNER, A)
        res = await mw(handler, Msg("تفعيل البوت", mid=3), {})
        self.assertEqual((res.kind, (await self.lic()).status), (R.REFUSED, S.BANNED))
        res = await mw(handler, Msg("حالة البوت", mid=4, sender=TG_CREATOR), {})
        self.assertEqual(res.kind, R.STATUS)


class WiringTests(unittest.TestCase):
    def test_services_field_defaults_to_none(self):
        self.assertIn("license_commands", Services.__dataclass_fields__)
        self.assertIsNone(Services.__dataclass_fields__["license_commands"].default)

    def test_app_and_dispatcher_wire_the_commands(self):
        app = (SRC / "app.py").read_text(encoding="utf-8")
        factory = (SRC / "bot" / "factory.py").read_text(encoding="utf-8")
        self.assertIn("license_commands=LicenseCommandService(", app)
        self.assertIn("display_timezone=settings.display_timezone", app)
        self.assertIn("dp.include_router(licensing.router)", factory)

    def test_router_registers_only_messages(self):
        src = (SRC / "bot" / "routers" / "licensing.py").read_text(encoding="utf-8")
        self.assertIn("@router.message(", src)
        self.assertNotIn("edited_message", src)
        self.assertNotIn("callback_query", src)


if __name__ == "__main__":
    unittest.main()
