"""Phase 4 / part 4.7b: the panel's welcome / verification / new-member screens and their write buttons.

What must hold: (1) a button carries only a signed NAME, the value lives on the server (`panel.actions.ACTIONS`);
(2) a press that WRITES re-checks MANAGE_SETTINGS on the server (hiding buttons is cosmetic), claims by the callback query
id, and goes through the same path as the commands (compare with effective values, `GroupSettingsService.update`, audit
with key names only); (3) every earlier panel guarantee (owner binding, MODERATE, live license, forged data) still holds
for every new screen/action."""
from __future__ import annotations

import re
import unittest
from types import SimpleNamespace as NS

from executor_stack import BOT
from guardian.audit import FORGED_CALLBACK
from guardian.bot import panel_handler as ph
from guardian.groups.models import GroupRole
from guardian.groups.service import validate_settings_patch
from guardian.members import settings as ms
from guardian.moderation.executor import ModerationCommandService
from guardian.panel import actions as pa
from guardian.panel import codec
from guardian.panel.service import PanelService
from guardian.telegram_rights import ChatMemberInfo
from stack import DELEGATE, OWNER, STRANGER, TG_ADMIN, TG_LIMITED_ADMIN
import test_panel as tp
from test_panel import SECRET, KEY, fake_markup

from guardian.protection.settings import ProtectionSettings
CLASSES = {pa.TOPIC_WELCOME: ms.WelcomeSettings, pa.TOPIC_VERIFY: ms.VerificationSettings,
           pa.TOPIC_NEWBIE: ms.NewMemberPolicy, pa.TOPIC_PROTECT: ProtectionSettings}
MEMBER_CLASSES = {k: v for k, v in CLASSES.items() if k != pa.TOPIC_PROTECT}
TOPIC_CHANGES = {  # a button in each topic that changes something from the defaults
    pa.TOPIC_WELCOME: "welon", pa.TOPIC_VERIFY: "veron", pa.TOPIC_NEWBIE: "nwhour"}


def labels(rows):
    return [label for row in rows for label, _ in row]


def screens_of(rows):
    return [codec.parse(data).screen for row in rows for _, data in row]


# ----------------------------------------------------------------------------- the server-side action table
class ActionTableTests(unittest.TestCase):
    def test_names_are_valid_unique_and_never_collide_with_screens(self):
        names = list(pa.ACTIONS)
        self.assertEqual(len(names), len(set(names)))
        for name in names:
            self.assertRegex(name, r"^[a-z]{1,8}$")
        base = {codec.SCREEN_HOME, codec.SCREEN_CLOSE, *pa.TOPICS}
        self.assertFalse(base & set(names))
        self.assertEqual(sorted(codec.SCREENS), sorted([*base, *names]))

    def test_every_action_fits_telegrams_limit_with_the_longest_ids(self):
        for name in pa.ACTIONS:
            data = codec.build(KEY, -(2**63), 10**18 - 1, name)
            self.assertLessEqual(len(data.encode()), 64, name)
            self.assertEqual(codec.parse(data).screen, name)

    def test_every_patch_is_accepted_by_the_validator_and_kept_by_from_raw(self):
        for name, spec in pa.ACTIONS.items():
            self.assertIn(spec.topic, pa.TOPICS, name)
            patch = dict(spec.patch)
            validate_settings_patch(patch)                              # what GroupSettingsService.update enforces
            cfg = CLASSES[spec.topic].from_raw(patch)                   # a value we send is a value we keep
            for key, value in patch.items():
                self.assertEqual(getattr(cfg, key), value, f"{name}:{key}")

    def test_patches_only_touch_their_own_topic_and_are_immutable(self):
        for name, spec in pa.ACTIONS.items():
            fields = set(CLASSES[spec.topic].__dataclass_fields__)
            self.assertTrue(set(spec.patch) <= fields, name)
            self.assertTrue(spec.patch, name)
            with self.assertRaises(TypeError):
                spec.patch["x"] = 1
        with self.assertRaises(TypeError):
            pa.ACTIONS["welon"] = None

    def test_one_button_changes_exactly_one_setting(self):
        for name, spec in pa.ACTIONS.items():
            self.assertEqual(len(spec.patch), 1, name)

    def test_every_member_setting_the_commands_expose_has_a_button_or_is_deliberately_left_to_commands(self):
        covered = {k for spec in pa.ACTIONS.values() for k in spec.patch}
        # Free text (`/welcome set`) and exact custom values stay commands; everything else is reachable from the panel.
        member_covered = {k for spec in pa.ACTIONS.values() if spec.topic in MEMBER_CLASSES for k in spec.patch}
        self.assertEqual(member_covered, {f for c in MEMBER_CLASSES.values() for f in c.__dataclass_fields__})
        self.assertLessEqual(covered, {f for c in CLASSES.values() for f in c.__dataclass_fields__})


# ----------------------------------------------------------------------------- with real settings writes
class WriteBase(tp.PanelBase):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.svc = ModerationCommandService(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions,
            settings_store=self.s.settings_store, actions=self.actions, chat_info=self.s.chat, claims=self.claims,
            audit=self.s.audit, bot_id=BOT, clock=self.s.clock, group_settings=self.s.settings)
        self.panel = PanelService(permissions=self.s.perm, licenses=self.s.license_service, commands=self.svc,
                                  audit=self.s.audit, secret=SECRET, clock=self.s.clock, ttl_seconds=None)
        self.q = 0

    def qid(self):
        self.q += 1
        return f"cbq{self.q}"

    async def do(self, screen, *, owner=TG_ADMIN, presser=None, group=None, query_id="auto", data=None, ctype="supergroup"):
        group = self.g if group is None else group
        data = codec.build(KEY, group, owner, screen) if data is None else data
        qid = self.qid() if query_id == "auto" else query_id
        return await self.panel.press(group, ctype, owner if presser is None else presser, data, "ar", qid)

    async def raw(self, group=None):
        row = await self.s.settings_store.get(self.g if group is None else group)
        return {} if row is None else dict(row.settings)

    def changed(self, group=None):
        g = self.g if group is None else group
        return [e for e in self.s.audit.events if e.group_id == g and e.event_type == "settings_changed"]

    async def untouched(self, raw_before, claims_before, events_before):
        self.assertEqual(await self.raw(), raw_before)
        self.assertEqual(self.claims._keys, claims_before)
        self.assertEqual(len(self.s.audit.events), events_before)
        self.assertEqual(self.actions.calls, [])

    async def snapshot(self):
        return await self.raw(), dict(self.claims._keys), len(self.s.audit.events)


# ----------------------------------------------------------------------------- screens (read only)
class ScreenTests(WriteBase):
    async def test_home_offers_the_five_screens_plus_refresh_and_close(self):
        out = await self.do(codec.SCREEN_HOME)
        self.assertEqual(screens_of(out.buttons), ["welcome", "verify", "newbie", "protect", "trust", "home", "close"])

    async def test_each_topic_screen_shows_current_values_and_signed_buttons_bound_to_the_owner(self):
        for topic in pa.WRITABLE_TOPICS:
            out = await self.do(topic)
            self.assertEqual((out.status, out.alert, out.delete), ("topic", False, False), topic)
            self.assertIn("<b>", out.text)
            for row in out.buttons:
                for _, data in row:
                    cb = codec.parse(data)
                    self.assertEqual(cb.owner_id, TG_ADMIN)
                    self.assertTrue(codec.verify(KEY, self.g, cb))
            shown = screens_of(out.buttons)
            self.assertEqual(shown[-2:], ["home", "close"], topic)                # back + close always last
            self.assertTrue(any(s in pa.ACTIONS for s in shown), topic)
            self.assertTrue(all(pa.ACTIONS[s].topic == topic for s in shown if s in pa.ACTIONS), topic)

    async def test_reading_a_screen_writes_claims_and_audits_nothing(self):
        before = await self.snapshot()
        for topic in pa.TOPICS:
            await self.do(topic)
        await self.untouched(*before)

    async def test_the_screen_text_is_the_same_text_the_command_shows(self):
        await self.do("welon")
        out = await self.do(pa.TOPIC_WELCOME)
        cmd, _ = await self.svc.panel_topic(pa.TOPIC_WELCOME, self.g, "ar")
        self.assertIn(cmd, out.text)

    async def test_buttons_mark_the_current_value_and_offer_the_opposite_for_toggles(self):
        out = await self.do(pa.TOPIC_VERIFY)
        self.assertEqual(self._toggle_target(out, "veron", "veroff"), "veron")   # off now: the button turns it ON
        await self.do("veron")
        out = await self.do(pa.TOPIC_VERIFY)
        self.assertEqual(self._toggle_target(out, "veron", "veroff"), "veroff")
        marked = [label for label in labels(out.buttons) if label.startswith("✅")]
        self.assertTrue(any("زر" in m for m in marked))                             # default method `button`
        self.assertTrue(any("5" in m for m in marked))                               # default timeout 5 minutes

    @staticmethod
    def _toggle_target(out, a, b):
        found = [s for s in screens_of(out.buttons) if s in (a, b)]
        assert len(found) == 1, found
        return found[0]

    async def test_conditional_buttons(self):
        shown = lambda out: screens_of(out.buttons)  # noqa: E731
        self.assertNotIn("welreset", shown(await self.do(pa.TOPIC_WELCOME)))
        await self.svc.panel_write(pa.TOPIC_WELCOME, {"welcome_text": "hi {name}"}, self.g, TG_ADMIN, "op:t:1", "ar")
        out = await self.do(pa.TOPIC_WELCOME)
        self.assertIn("welreset", shown(out))
        self.assertIn("hi ", out.text)                                              # the custom text is shown
        self.assertNotIn("vbhour", shown(await self.do(pa.TOPIC_VERIFY)))           # ban length only when failure=ban
        await self.do("vfban")
        self.assertIn("vbhour", shown(await self.do(pa.TOPIC_VERIFY)))

    async def test_the_custom_welcome_text_is_html_escaped_in_the_screen(self):
        await self.svc.panel_write(pa.TOPIC_WELCOME, {"welcome_text": "<b>{name}</b> & co"}, self.g, TG_ADMIN, "op:t:2", "ar")
        out = await self.do(pa.TOPIC_WELCOME)
        self.assertIn("&lt;b&gt;{name}&lt;/b&gt; &amp; co", out.text)

    async def test_a_moderator_delegate_reads_but_gets_no_write_buttons(self):
        await self.s.delegations.grant(OWNER, self.g, DELEGATE, GroupRole.MODERATOR)
        for topic in pa.WRITABLE_TOPICS:
            out = await self.do(topic, owner=DELEGATE)
            self.assertEqual(out.status, "topic")
            self.assertEqual(screens_of(out.buttons), ["home", "close"], topic)
            self.assertIn("🔒", out.text)

    async def test_a_group_manager_delegate_gets_the_write_buttons(self):
        await self.s.delegations.grant(OWNER, self.g, DELEGATE, GroupRole.GROUP_MANAGER)
        out = await self.do(pa.TOPIC_WELCOME, owner=DELEGATE)
        self.assertIn("welon", screens_of(out.buttons))
        self.assertNotIn("🔒", out.text)

    async def test_a_failing_manage_check_degrades_to_a_read_only_view_and_writes_stay_refused(self):
        real = self.panel._perm

        class Flaky:
            async def check(inner, actor, group, perm, **k):
                if perm.name == "MANAGE_SETTINGS":
                    raise RuntimeError("telegram down")
                return await real.check(actor, group, perm, **k)
        self.panel._perm = Flaky()
        try:
            out = await self.do(pa.TOPIC_WELCOME)
            self.assertEqual(screens_of(out.buttons), ["home", "close"])
            self.assertIn("🔒", out.text)
            before = await self.snapshot()
            w = await self.do("welon")
            self.assertEqual((w.status, w.alert, w.text), ("unavailable", True, None))
        finally:
            self.panel._perm = real
        await self.untouched(*before)

    async def test_an_unknown_topic_is_rejected_before_any_claim(self):
        for call in (lambda: self.svc.panel_write("bogus", {"x": 1}, self.g, TG_ADMIN, "op:t:9", "ar"),
                     lambda: self.svc.panel_topic("bogus", self.g, "ar")):
            with self.assertRaises(ValueError):
                await call()
        self.assertEqual(self.claims._keys, {})

    async def test_unreadable_settings_never_show_a_screen(self):
        async def boom(*a, **k):
            raise RuntimeError("store down")
        real, self.s.settings_store.get = self.s.settings_store.get, boom
        try:
            for topic in pa.TOPICS:
                out = await self.do(topic)
                self.assertEqual((out.status, out.alert, out.text, out.buttons), ("unavailable", True, None, None))
        finally:
            self.s.settings_store.get = real

    async def test_english_screens_and_buttons(self):
        out = await self.panel.press(self.g, "supergroup", TG_ADMIN, codec.build(KEY, self.g, TG_ADMIN, "verify"), "en", "q1")
        self.assertIn("Verification", out.text)
        self.assertTrue(any("Back" in label for label in labels(out.buttons)))
        self.assertFalse(any(re.search("[\\u0600-\\u06FF]", label) for label in labels(out.buttons)))

    async def test_a_screen_for_a_read_only_admin_works_in_dry_run_and_so_do_writes(self):
        await self.s.settings_store.merge(self.g, {"dry_run": True}, OWNER, self.s.clock())
        self.assertEqual((await self.do(pa.TOPIC_NEWBIE)).status, "topic")
        self.assertEqual((await self.do("nwday")).status, "saved")                 # settings are not punitive


# ----------------------------------------------------------------------------- writes
class WriteTests(WriteBase):
    async def test_every_action_ends_with_exactly_its_value_and_nothing_else_changed(self):
        for name, spec in pa.ACTIONS.items():
            with self.subTest(action=name):
                before = await self.raw()
                out = await self.do(name)
                self.assertIn(out.status, ("saved", "noop"), name)
                after = await self.raw()
                cfg = CLASSES[spec.topic].from_raw(after)
                for key, value in spec.patch.items():
                    self.assertEqual(getattr(cfg, key), value, f"{name}:{key}")
                self.assertEqual({k: v for k, v in after.items() if k not in spec.patch},
                                 {k: v for k, v in before.items() if k not in spec.patch}, name)

    async def test_a_change_saves_audits_key_names_only_and_redraws_the_screen(self):
        out = await self.do("veron")
        self.assertEqual((out.status, out.toast, out.alert), ("saved", "تم الحفظ ✅", False))
        self.assertTrue(ms.VerificationSettings.from_raw(await self.raw()).verify_enabled)
        self.assertIn("veroff", screens_of(out.buttons))                            # the screen now offers the way back
        (event,) = self.changed()
        self.assertEqual((event.actor_telegram_id, event.detail), (TG_ADMIN, "keys=verify_enabled"))
        self.assertEqual(len(self.claims._keys), 1)

    async def test_the_claim_key_is_the_group_and_the_callback_id(self):
        await self.do("welon", query_id="987654321")
        self.assertEqual(list(self.claims._keys), [f"op:panel:{self.g}:987654321"])

    async def test_pressing_the_value_already_set_changes_nothing_but_refreshes(self):
        await self.do("nwday")
        events, raw = len(self.s.audit.events), await self.raw()
        out = await self.do("nwday")                                                # a stale button
        self.assertEqual((out.status, out.alert), ("noop", False))
        self.assertEqual((out.toast, await self.raw(), len(self.s.audit.events)), ("لا تغيير: الإعداد بهذه القيمة بالفعل.", raw, events))
        self.assertTrue(out.text)                                                     # fresh values shown

    async def test_a_redelivered_press_writes_and_audits_once_and_shows_nothing(self):
        await self.do("welon", query_id="same")
        raw, events = await self.raw(), len(self.s.audit.events)
        out = await self.do("weloff", query_id="same")                              # same callback id => same press
        self.assertEqual((out.status, out.text, out.buttons, out.toast), ("duplicate", None, None, ""))
        self.assertEqual((await self.raw(), len(self.s.audit.events)), (raw, events))

    async def test_a_press_without_a_valid_callback_id_never_writes(self):
        before = await self.snapshot()
        for bad in (None, "", 5, True, b"x", "a b", "a/b", "a:b", "é", "x" * 65, "x\n", ["a"]):
            out = await self.do("welon", query_id=bad)
            self.assertEqual((out.status, out.alert, out.text), ("unavailable", True, None), repr(bad))
        await self.untouched(*before)

    async def test_ids_with_dashes_and_underscores_are_fine(self):
        self.assertEqual((await self.do("welon", query_id="a-b_C9")).status, "saved")

    async def test_an_admin_without_the_moderation_right_gets_neither_screens_nor_writes(self):
        self.s.chat.set(self.g, TG_LIMITED_ADMIN, ChatMemberInfo("administrator", True, False, True))
        before = await self.snapshot()
        for screen in (*pa.TOPICS, "welon", "veron", "nwhour"):
            out = await self.do(screen, owner=TG_LIMITED_ADMIN)
            self.assertEqual((out.status, out.alert, out.text), ("not_admin", True, None), screen)
        await self.untouched(*before)

    async def test_a_hand_built_write_by_a_read_only_delegate_is_refused_on_the_server(self):
        await self.s.delegations.grant(OWNER, self.g, DELEGATE, GroupRole.MODERATOR)
        before = await self.snapshot()
        for name in pa.ACTIONS:
            out = await self.do(name, owner=DELEGATE)                                 # validly signed, buttons hidden or not
            self.assertEqual((out.status, out.alert, out.text), ("not_manager", True, None), name)
        await self.untouched(*before)

    async def test_the_commands_service_denying_the_write_is_also_a_refusal(self):
        real_perm = self.s.perm
        calls = {"n": 0}

        class Flaky:
            def __init__(self, inner):
                self.inner = inner

            async def check(self, *a, **k):                    # the panel's own check passes ...
                return await self.inner.check(*a, **k)

            async def require(self, *a, **k):                  # ... but the service's require refuses
                calls["n"] += 1
                return await self.inner.require(STRANGER, *a[1:], **k)
        self.svc._member_cfg._perm = Flaky(real_perm)
        before = await self.snapshot()
        out = await self.do("welon")
        self.assertEqual((out.status, out.alert), ("not_manager", True))
        self.assertEqual(calls["n"], 1)
        raw, claims, _ = before                                  # the service's own refusal is audited as a denial
        self.assertEqual((await self.raw(), self.claims._keys, self.actions.calls), (raw, claims, []))

    async def test_another_admin_cannot_write_through_my_panel(self):
        other = 900_099
        self.s.chat.set(self.g, other, ChatMemberInfo("administrator", True, True, True))
        before = await self.snapshot()
        out = await self.do("welon", owner=TG_ADMIN, presser=other)
        self.assertEqual((out.status, out.alert), ("not_owner", True))
        await self.untouched(*before)

    async def test_a_plain_member_and_a_demoted_admin_cannot_write(self):
        before = await self.snapshot()
        self.assertEqual((await self.do("welon", owner=STRANGER)).status, "not_admin")
        self.s.chat.set(self.g, TG_ADMIN, ChatMemberInfo("member"))
        self.assertEqual((await self.do("welon")).status, "not_admin")
        await self.untouched(*before)

    async def test_tampered_or_foreign_signatures_are_forged_and_write_nothing(self):
        good = codec.build(KEY, self.g, TG_ADMIN, "vfkick")
        _, owner, _, tag = good.split(":")
        other = await self.active_group()
        before = await self.snapshot()
        for data, group in ((f"pn:{owner}:vfban:{tag}", self.g),             # another action under this action's tag
                            (good, other),                                      # a panel carried into another group
                            (f"pn:{STRANGER}:vfkick:{tag}", self.g),          # swapped owner
                            (f"pn:{owner}:vfkick:{'0' * 12}", self.g)):
            out = await self.do("vfkick", data=data, group=group)
            self.assertEqual((out.status, out.text), ("forged", None), data)
        self.assertEqual(len(self.forged()) + len(self.forged(other)), 4)
        self.assertEqual(await self.raw(), before[0])
        self.assertEqual(await self.raw(other), {})
        self.assertEqual(self.claims._keys, before[1])

    async def test_a_value_cannot_be_smuggled_through_the_button(self):
        before = await self.snapshot()
        for name in ("vtone", "vtone=5", "verify_timeout_seconds", "vtone:5", "vt5", "VTONE"):
            data = f"pn:{TG_ADMIN}:{name}:{'0' * 12}" if name.isalpha() and name.islower() else f"pn:{TG_ADMIN}:{name}:{'a' * 12}"
            self.assertIsNone(codec.parse(data) if name != "vtone" else None, name)
        out = await self.do("vtone", data=f"pn:{TG_ADMIN}:vtone:{'0' * 12}")
        self.assertEqual(out.status, "forged")
        self.assertEqual(await self.raw(), before[0])

    async def test_every_blocked_license_state_refuses_every_write(self):
        from test_phase3_final_handoff import BLOCKED_STATES
        for state in BLOCKED_STATES:
            with self.subTest(state=state):
                g = await self.group_in(state)
                real = self.break_store() if state == "store_down" else self.s.licenses.get
                try:
                    for presser in (TG_ADMIN, OWNER):
                        if state == "store_down" and presser == OWNER:
                            continue
                        for name in pa.ACTIONS:
                            out = await self.do(name, owner=presser, group=g)
                            self.assertIn(out.status, ("license_off", "unavailable"), (state, name))
                            self.assertEqual((out.alert, out.text), (True, None))
                finally:
                    self.s.licenses.get = real
                self.assertIsNone(await self.s.settings_store.get(g))
                self.assertFalse([k for k in self.claims._keys if f":{g}:" in k])
                self.assertEqual(self.changed(g), [])

    async def test_a_license_that_expires_stops_the_writes_at_that_moment(self):
        from datetime import timedelta
        g = await self.group_in("pending")
        await self.s.admin.activate_temporary(OWNER, g, self.s.clock() + timedelta(hours=1))
        self.assertEqual((await self.do("welon", group=g)).status, "saved")
        self.s.clock.advance(hours=2)
        self.assertEqual((await self.do("weloff", group=g)).status, "license_off")
        self.assertTrue(ms.WelcomeSettings.from_raw(await self.raw(g)).welcome_enabled)

    async def test_the_owner_recovering_a_state_revives_the_buttons(self):
        g = await self.group_in("banned")
        self.assertEqual((await self.do("welon", group=g)).status, "license_off")
        await self.owner_recovers(g, "banned")
        self.assertEqual((await self.do("welon", group=g)).status, "saved")

    async def test_groups_are_isolated(self):
        other = await self.active_group()
        await self.do("veron")
        self.assertEqual(await self.raw(other), {})
        self.assertEqual(self.changed(other), [])

    async def test_reset_returns_to_the_default_text(self):
        await self.svc.panel_write(pa.TOPIC_WELCOME, {"welcome_text": "x {name}"}, self.g, TG_ADMIN, "op:t:3", "ar")
        out = await self.do("welreset")
        self.assertEqual(out.status, "saved")
        self.assertIsNone(ms.WelcomeSettings.from_raw(await self.raw()).welcome_text)
        self.assertNotIn("welreset", screens_of(out.buttons))

    async def test_a_store_failure_fails_closed(self):
        async def boom(*a, **k):
            raise RuntimeError("store down")
        real, self.s.settings.update = self.s.settings.update, boom
        try:
            out = await self.do("welon")
        finally:
            self.s.settings.update = real
        self.assertEqual((out.status, out.alert, out.text), ("unavailable", True, None))
        self.assertEqual(await self.raw(), {})

    async def test_a_claim_store_failure_writes_nothing(self):
        async def boom(*a, **k):
            raise RuntimeError("claims down")
        real, self.claims.claim = self.claims.claim, boom
        try:
            out = await self.do("welon")
        finally:
            self.claims.claim = real
        self.assertEqual((out.status, out.alert), ("unavailable", True))
        self.assertEqual(await self.raw(), {})

    async def test_a_commands_service_that_raises_or_lacks_settings_fails_closed(self):
        async def boom(*a, **k):
            raise RuntimeError("no bot id")
        for broken in (NS(panel_write=boom, panel_topic=boom), NS()):
            real, self.panel._commands = self.panel._commands, broken
            try:
                for screen in ("welon", pa.TOPIC_WELCOME):
                    out = await self.do(screen)
                    self.assertEqual((out.status, out.alert, out.text), ("unavailable", True, None))
            finally:
                self.panel._commands = real
        self.assertEqual(await self.raw(), {})

    async def test_without_group_settings_the_write_is_a_safe_error(self):
        svc = ModerationCommandService(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions,
            settings_store=self.s.settings_store, actions=self.actions, chat_info=self.s.chat, claims=self.claims,
            audit=self.s.audit, bot_id=BOT, clock=self.s.clock)
        self.panel._commands = svc
        out = await self.do("welon")
        self.assertEqual((out.status, out.alert), ("unavailable", True))
        self.assertEqual(self.claims._keys, {})

    async def test_advice_about_missing_bot_rights_is_shown_but_does_not_block(self):
        self.s.chat.set(self.g, BOT, ChatMemberInfo("administrator", True, False, False))   # cannot restrict/delete
        out = await self.do("veron")
        self.assertEqual(out.status, "saved")
        self.assertTrue(ms.VerificationSettings.from_raw(await self.raw()).verify_enabled)
        self.assertIn("⚠", out.text)

    async def test_english_write(self):
        out = await self.panel.press(self.g, "supergroup", TG_ADMIN, codec.build(KEY, self.g, TG_ADMIN, "welon"), "en", "e1")
        self.assertEqual((out.status, out.toast), ("saved", "Saved ✅"))


# ----------------------------------------------------------------------------- aiogram-independent glue
class HandlerWriteTests(WriteBase):
    Panelled = tp.CallbackHandlerTests.Panelled

    def svcs(self, panel="default"):
        return NS(settings=NS(default_language="ar"), panel=self.panel if panel == "default" else panel)

    def query(self, message, owner=TG_ADMIN, presser=None, screen=codec.SCREEN_HOME, data=None, group=None, qid="hq1"):
        data = self.data(self.g if group is None else group, owner, screen) if data is None else data
        return NS(id=qid, data=data, message=message,
                  from_user=NS(id=owner if presser is None else presser, language_code="ar"))

    async def test_a_write_button_saves_and_edits_the_message_in_place(self):
        m = self.Panelled(self.g)
        toast = await ph.on_panel_callback(self.query(m, screen="veron"), self.svcs(), fake_markup)
        self.assertEqual(toast, ("تم الحفظ ✅", False))
        (text, markup), = m.edits
        self.assertIn("التحقق", text)
        self.assertEqual(markup[0], "MARKUP")
        self.assertTrue(ms.VerificationSettings.from_raw(await self.raw()).verify_enabled)

    async def test_the_callback_query_id_is_the_idempotency_anchor(self):
        m = self.Panelled(self.g)
        await ph.on_panel_callback(self.query(m, screen="veron", qid="dup1"), self.svcs(), fake_markup)
        m2 = self.Panelled(self.g)
        toast = await ph.on_panel_callback(self.query(m2, screen="veroff", qid="dup1"), self.svcs(), fake_markup)
        self.assertEqual((toast, m2.edits), (("", False), []))
        self.assertTrue(ms.VerificationSettings.from_raw(await self.raw()).verify_enabled)

    async def test_a_query_without_an_id_cannot_write(self):
        m = self.Panelled(self.g)
        q = self.query(m, screen="veron")
        del q.id
        toast = await ph.on_panel_callback(q, self.svcs(), fake_markup)
        self.assertTrue(toast[1])
        self.assertEqual((m.edits, await self.raw()), ([], {}))

    async def test_a_refused_write_press_neither_edits_nor_deletes(self):
        for kw in ({"owner": STRANGER}, {"owner": TG_ADMIN, "presser": 900_099}, {"data": "pn:1:welon:" + "0" * 12}):
            for screen in pa.ACTIONS:
                m = self.Panelled(self.g)
                toast = await ph.on_panel_callback(self.query(m, screen=screen, **kw), self.svcs(), fake_markup)
                self.assertTrue(toast[1], (kw, screen))
                self.assertEqual((m.edits, m.deleted), ([], 0), (kw, screen))
        self.assertEqual(await self.raw(), {})

    async def test_the_write_group_comes_from_the_pressed_message_not_the_data(self):
        other = await self.active_group()
        m = self.Panelled(other)
        toast = await ph.on_panel_callback(self.query(m, screen="welon", group=self.g), self.svcs(), fake_markup)
        self.assertTrue(toast[1])
        self.assertEqual((await self.raw(), await self.raw(other)), ({}, {}))


if __name__ == "__main__":
    unittest.main()
