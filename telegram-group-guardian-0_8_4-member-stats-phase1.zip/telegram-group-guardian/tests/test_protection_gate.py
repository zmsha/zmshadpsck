import unittest
from datetime import timedelta
from types import SimpleNamespace as NS

from guardian.groups.models import GroupRole
from guardian.bot.middlewares import ProtectionGateMiddleware
from guardian.protection_gate import ProtectionGate
from helpers import FakeNotifier
from stack import A, B, BACKUP, DELEGATE, OWNER, STRANGER, TG_ADMIN, Stack


class GateBase(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        self.notifier = FakeNotifier()
        self.gate = ProtectionGate(self.s.license_service, self.s.perm, self.notifier, clock=self.s.clock)
        await self.s.register(A, B)

    async def ev(self, group=A, sender=STRANGER, chat_type="supergroup", **kw):
        return await self.gate.evaluate(group, chat_type, sender, **kw)


class LicenseStateTests(GateBase):
    async def test_pending_denied(self):
        c = await self.ev()
        self.assertFalse(c.allowed)
        self.assertFalse(c.can_sanction)
        self.assertEqual(c.reason, "pending")

    async def test_active_permanent_allows_and_member_can_be_sanctioned(self):
        await self.s.admin.activate_permanent(OWNER, A)
        c = await self.ev()
        self.assertTrue(c.allowed and c.can_sanction)

    async def test_stopped_rejected_banned_denied(self):
        for action, reason in (("stop", "stopped"), ("reject", "rejected"), ("ban", "banned")):
            g = {"stop": A, "reject": B}.get(action, -1003)
            await self.s.register(g)
            if action == "stop":
                await self.s.admin.activate_permanent(OWNER, g)
            await getattr(self.s.admin, action)(OWNER, g)
            c = await self.ev(group=g)
            self.assertFalse(c.allowed, action)
            self.assertEqual(c.reason, reason)
            self.assertFalse(c.can_sanction)

    async def test_expired_after_sleep_blocks_first_update(self):
        await self.s.admin.activate_temporary(OWNER, A, self.s.clock() + timedelta(days=1))
        self.assertTrue((await self.ev()).allowed)
        self.s.clock.advance(days=2)  # service slept; no scheduler ran
        c = await self.ev()
        self.assertFalse(c.allowed)
        self.assertEqual(c.reason, "expired")
        # boundary: exactly at expires_at is already expired
        await self.s.register(-1004)
        exp = self.s.clock() + timedelta(hours=1)
        await self.s.admin.activate_temporary(OWNER, -1004, exp)
        self.s.clock.advance(hours=1)
        self.assertFalse((await self.ev(group=-1004)).allowed)

    async def test_store_failure_fails_closed(self):
        await self.s.admin.activate_permanent(OWNER, A)

        async def boom(*a, **k):
            raise RuntimeError("db down")

        self.s.licenses.get = boom
        c = await self.ev()
        self.assertFalse(c.allowed)
        self.assertEqual(c.reason, "store_unavailable")

    async def test_unexpected_exception_fails_closed(self):
        await self.s.admin.activate_permanent(OWNER, A)

        async def boom(*a, **k):
            raise RuntimeError("bug")

        self.s.perm.is_exempt_from_automation = boom
        c = await self.ev()
        self.assertFalse(c.allowed)
        self.assertEqual(c.reason, "gate_error")

    async def test_private_and_channel_chats_not_a_group(self):
        for t in ("private", "channel", ""):
            c = await self.ev(chat_type=t)
            self.assertFalse(c.allowed)
            self.assertEqual(c.reason, "not_a_group")


class RegistrationTests(GateBase):
    async def test_unknown_group_registered_pending_once_and_not_protected(self):
        c = await self.ev(group=-1050, title="New")
        self.assertFalse(c.allowed)
        self.assertEqual(c.reason, "pending")
        self.assertEqual((await self.s.licenses.get(-1050)).status.value, "pending")
        await self.ev(group=-1050, title="New")
        self.assertEqual(len(self.notifier.owner_messages), 1)  # owner notified only on first registration

    async def test_registration_failure_denied(self):
        async def boom(*a, **k):
            raise RuntimeError("db")

        self.s.licenses.register_pending_if_absent = boom
        c = await self.ev(group=-1060)
        self.assertFalse(c.allowed)

    async def test_readd_never_reactivates_or_unbans(self):
        await self.s.register(-1070)
        await self.s.admin.ban(OWNER, -1070)
        await self.ev(group=-1070)
        await self.gate.evaluate(-1070, "group", STRANGER)  # bot removed + re-added = more updates
        self.assertEqual((await self.s.licenses.get(-1070)).status.value, "banned")


class ExemptionTests(GateBase):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        await self.s.admin.activate_permanent(OWNER, A)

    async def test_protected_senders_never_sanctioned(self):
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.MODERATOR, context_chat_id=A)
        for who in (OWNER, BACKUP, TG_ADMIN, DELEGATE, 777000, 1087968824, 136817688):
            c = await self.ev(sender=who)
            self.assertTrue(c.allowed, who)
            self.assertFalse(c.can_sanction, who)

    async def test_trusted_is_flagged_but_not_exempt(self):
        await self.s.trust.add(OWNER, A, 910_000, context_chat_id=A)
        c = await self.ev(sender=910_000)
        self.assertTrue(c.can_sanction)  # part 4.2: no blanket exemption; the engine skips only listed rules
        self.assertTrue(c.sender_trusted)
        self.assertFalse((await self.ev(sender=STRANGER)).sender_trusted)

    async def test_trust_lookup_failure_does_not_sanction(self):
        async def boom(*a, **k):
            raise RuntimeError("down")
        self.s.trust_store.is_trusted = boom
        c = await self.ev(sender=STRANGER)
        self.assertTrue(c.allowed)
        self.assertFalse(c.can_sanction)

    async def test_missing_or_anonymous_sender_exempt(self):
        self.assertFalse((await self.ev(sender=None)).can_sanction)
        self.assertFalse((await self.ev(sender=STRANGER, anonymous_sender=True)).can_sanction)

    async def test_admin_status_lookup_failure_does_not_sanction(self):
        self.s.chat.fail = True
        self.assertFalse((await self.ev()).can_sanction)

    async def test_admin_of_other_group_is_not_exempt_here(self):
        await self.s.admin.activate_permanent(OWNER, B)
        # TG_ADMIN is admin only in A: in B they are a plain member
        self.assertTrue((await self.ev(group=B, sender=TG_ADMIN)).can_sanction)


class MiddlewareTests(GateBase):
    async def run_mw(self, event):
        seen = {}

        async def handler(e, data):
            seen.update(data)
            return "handled"

        r = await ProtectionGateMiddleware(self.gate)(handler, event, {})
        return r, seen

    def msg(self, group=A, sender=STRANGER, ctype="supergroup", sender_chat=None):
        return NS(chat=NS(id=group, type=ctype, title="T"), from_user=NS(id=sender) if sender else None,
                  sender_chat=sender_chat)

    async def test_never_blocks_handler_even_when_denied(self):
        for status_setup in ("pending", "expired", "stopped", "banned"):
            g = {"pending": A, "expired": B, "stopped": -1101, "banned": -1102}[status_setup]
            await self.s.register(g)
            if status_setup == "expired":
                await self.s.admin.activate_temporary(OWNER, g, self.s.clock() + timedelta(hours=1))
                self.s.clock.advance(hours=2)
            elif status_setup == "stopped":
                await self.s.admin.activate_permanent(OWNER, g)
                await self.s.admin.stop(OWNER, g)
            elif status_setup == "banned":
                await self.s.admin.ban(OWNER, g)
            r, seen = await self.run_mw(self.msg(group=g, sender=OWNER))  # owner license command path
            self.assertEqual(r, "handled", status_setup)
            self.assertFalse(seen["protection"].allowed, status_setup)

    async def test_injects_allowed_context_and_sender_chat_is_anonymous(self):
        await self.s.admin.activate_permanent(OWNER, A)
        _, seen = await self.run_mw(self.msg())
        self.assertTrue(seen["protection"].can_sanction)
        _, seen = await self.run_mw(self.msg(sender_chat=NS(id=A)))
        self.assertFalse(seen["protection"].can_sanction)

    async def test_private_chat_context_not_a_group(self):
        _, seen = await self.run_mw(self.msg(group=OWNER, ctype="private"))
        self.assertEqual(seen["protection"].reason, "not_a_group")

    async def test_malformed_event_fails_closed_and_still_calls_handler(self):
        r, seen = await self.run_mw(NS())
        self.assertEqual(r, "handled")
        self.assertFalse(seen["protection"].allowed)


class OwnerPathsUnblockedTests(GateBase):
    async def test_owner_can_renew_expired_group_while_protection_off(self):
        await self.s.admin.activate_temporary(OWNER, A, self.s.clock() + timedelta(hours=1))
        self.s.clock.advance(hours=3)
        self.assertFalse((await self.ev()).allowed)
        r = await self.s.admin.activate_permanent(OWNER, A, context_chat_id=A)  # not gated by the gate
        self.assertEqual(r.outcome.value, "changed")
        self.assertTrue((await self.ev()).allowed)


if __name__ == "__main__":
    unittest.main()
