import unittest
from types import SimpleNamespace as NS

from guardian.bot.actions import AiogramModerationActions, classify_error
from guardian.bot.middlewares import ProtectionGateMiddleware
from guardian.groups.models import GroupRole
from guardian.idempotency import InMemoryIdempotency
from guardian.protection.engine import ActionResult, MessageView, OutcomeKind, ProtectionEngine
from guardian.protection_gate import ProtectionGate
from guardian.telegram_rights import ChatMemberInfo
from helpers import FakeNotifier
from stack import A, B, DELEGATE, OWNER, STRANGER, TG_ADMIN, Stack

BOT = 777


class FakeActions:
    def __init__(self):
        self.deleted, self.muted = [], []
        self.delete_result = ActionResult(True)
        self.mute_result = ActionResult(True)

    async def delete_message(self, chat_id, message_id):
        self.deleted.append((chat_id, message_id))
        return self.delete_result

    async def mute_member(self, chat_id, user_id, until):
        self.muted.append((chat_id, user_id, until))
        return self.mute_result


class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A, B)
        await self.s.admin.activate_permanent(OWNER, A)
        self.s.chat.set(A, BOT, ChatMemberInfo("administrator", True, True, True))
        self.notifier = FakeNotifier()
        self.actions = FakeActions()
        self.claims = InMemoryIdempotency()
        self.engine = ProtectionEngine(self.s.settings_store, self.actions, self.s.chat, self.claims,
                                       self.s.audit, self.notifier, clock=self.s.clock)
        self.gate = ProtectionGate(self.s.license_service, self.s.perm, self.notifier, clock=self.s.clock)
        self.mid = 0

    async def cfg(self, group=A, **patch):
        await self.s.settings_store.merge(group, patch, OWNER, self.s.clock())

    async def send(self, text="hello", user=STRANGER, group=A, entities=(), edit=False, mid=None, advance=0.0):
        if advance:
            self.s.clock.advance(seconds=advance)
        self.mid += 1
        ctx = await self.gate.evaluate(group, "supergroup", user)
        return await self.engine.handle(
            ctx, MessageView(group, user, mid or self.mid, text, tuple(entities), edit), self.s.clock())


class LinkSanctionTests(Base):
    async def test_link_deleted_and_muted_with_escalation(self):
        o = await self.send("buy at https://evil.com")
        self.assertEqual((o.kind, o.violation, o.deleted, o.muted_seconds), (OutcomeKind.ACTED, "links", True, 600))
        self.assertEqual(self.actions.deleted, [(A, 1)])
        self.assertEqual(self.actions.muted[0][:2], (A, STRANGER))
        self.assertEqual(self.actions.muted[0][2], self.s.clock() + __import__("datetime").timedelta(seconds=600))
        self.s.clock.advance(seconds=700)  # first mute over; second offense escalates
        o2 = await self.send("again evil.com")
        self.assertEqual(o2.muted_seconds, 3600)
        self.s.clock.advance(seconds=4000)
        self.assertEqual((await self.send("evil.com")).muted_seconds, 86400)
        self.s.clock.advance(days=2)
        self.assertEqual((await self.send("evil.com")).muted_seconds, 86400)  # capped at last step

    async def test_escalation_resets_after_window(self):
        await self.cfg(escalation_window_seconds=3600)
        await self.send("evil.com")
        self.s.clock.advance(seconds=7200)
        self.assertEqual((await self.send("evil.com")).muted_seconds, 600)

    async def test_allowlisted_domain_and_clean_text_untouched(self):
        await self.cfg(links_allow_domains=["good.com"])
        self.assertEqual((await self.send("see https://sub.good.com/p")).kind, OutcomeKind.NONE)
        self.assertEqual((await self.send("plain text")).kind, OutcomeKind.NONE)
        self.assertEqual(self.actions.deleted, [])

    async def test_allowlist_is_per_group(self):
        await self.s.admin.activate_permanent(OWNER, B)
        self.s.chat.set(B, BOT, ChatMemberInfo("administrator", True, True, True))
        await self.cfg(A, links_allow_domains=["good.com"])
        self.assertEqual((await self.send("good.com", group=A)).kind, OutcomeKind.NONE)
        self.assertEqual((await self.send("good.com", group=B)).kind, OutcomeKind.ACTED)

    async def test_links_disabled_and_invite_toggle(self):
        await self.cfg(links_enabled=False)
        self.assertEqual((await self.send("evil.com")).kind, OutcomeKind.NONE)
        await self.cfg(links_enabled=True, links_allow_invites=True)
        self.assertEqual((await self.send("t.me/+abc")).kind, OutcomeKind.NONE)

    async def test_edited_message_with_link_is_sanctioned_but_not_counted_as_flood(self):
        self.assertEqual((await self.send("evil.com", edit=True)).kind, OutcomeKind.ACTED)
        await self.cfg(flood_max_messages=2)
        for _ in range(5):
            self.assertEqual((await self.send("hi", edit=True)).kind, OutcomeKind.NONE)

    async def test_never_bans_only_delete_and_mute(self):
        for _ in range(6):
            await self.send("evil.com", advance=100000)
        self.assertEqual(set(dir(self.actions)) & {"ban_member", "kick_member"}, set())


class ProtectedAndLicenseTests(Base):
    async def test_protected_senders_never_sanctioned(self):
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.MODERATOR, context_chat_id=A)
        await self.s.trust.add(OWNER, A, 910_000, context_chat_id=A)
        for who in (OWNER, TG_ADMIN, DELEGATE, 910_000, 777000, 1087968824):
            self.assertEqual((await self.send("evil.com", user=who)).kind, OutcomeKind.NONE, who)
        self.assertEqual((self.actions.deleted, self.actions.muted), ([], []))

    async def test_no_action_when_license_not_active(self):
        await self.s.admin.stop(OWNER, A)
        self.assertEqual((await self.send("evil.com")).kind, OutcomeKind.NONE)
        self.assertEqual(self.actions.deleted, [])
        self.assertEqual((await self.send("evil.com", group=B)).kind, OutcomeKind.NONE)  # pending

    async def test_mismatched_context_is_ignored(self):
        ctx = await self.gate.evaluate(A, "supergroup", STRANGER)
        o = await self.engine.handle(ctx, MessageView(B, STRANGER, 1, "evil.com"), self.s.clock())
        self.assertEqual(o.kind, OutcomeKind.NONE)


class DryRunAndIdempotencyTests(Base):
    async def test_dry_run_calls_nothing(self):
        await self.cfg(dry_run=True)
        ctx = await self.gate.evaluate(A, "supergroup", STRANGER)
        calls_before = self.s.chat.calls
        o = await self.engine.handle(ctx, MessageView(A, STRANGER, 1, "evil.com"), self.s.clock())
        self.assertEqual((o.kind, o.violation), (OutcomeKind.DRY_RUN, "links"))
        self.assertEqual((self.actions.deleted, self.actions.muted), ([], []))
        self.assertEqual(self.s.chat.calls, calls_before)  # no Telegram lookups made by the engine
        self.assertTrue(await self.claims.claim("op:sanction:%d:%d:1" % (A, STRANGER)))  # nothing was claimed
        ev = [e for e in await self.s.audit.for_group(A) if e.event_type == "auto_sanction_dry_run"]
        self.assertEqual(len(ev), 1)
        self.assertNotIn("evil", ev[0].detail or "")  # no message content in audit

    async def test_redelivered_update_does_not_repeat_sanction(self):
        o1 = await self.send("evil.com", mid=500)
        o2 = await self.send("evil.com", mid=500)  # same message_id redelivered
        self.assertEqual((o1.kind, o2.kind), (OutcomeKind.ACTED, OutcomeKind.DUPLICATE_DELIVERY))
        self.assertEqual((len(self.actions.deleted), len(self.actions.muted)), (1, 1))

    async def test_claim_store_failure_means_no_action(self):
        async def boom(*a, **k):
            raise RuntimeError("db")
        self.claims.claim = boom
        self.assertEqual((await self.send("evil.com")).kind, OutcomeKind.UNSAFE_NO_ACTION)
        self.assertEqual(self.actions.deleted, [])


class BotRightsTests(Base):
    async def test_missing_rights_no_action_owner_notified_once(self):
        self.s.chat.set(A, BOT, ChatMemberInfo("member"))
        for _ in range(3):
            self.assertEqual((await self.send("evil.com")).kind, OutcomeKind.BOT_RIGHTS_MISSING)
        self.assertEqual((self.actions.deleted, self.actions.muted), ([], []))
        self.assertEqual(len(self.notifier.owner_messages), 1)  # throttled
        self.s.clock.advance(seconds=700)
        await self.send("evil.com")
        self.assertEqual(len(self.notifier.owner_messages), 2)

    async def test_unknown_rights_do_nothing(self):
        self.s.chat.fail = True
        o = await self.send("evil.com", user=STRANGER)
        # the gate itself cannot verify admin status => exempt => no action at all
        self.assertEqual(o.kind, OutcomeKind.NONE)
        self.assertEqual(self.actions.deleted, [])

    async def test_rights_lookup_failure_after_gate_passes(self):
        ctx = await self.gate.evaluate(A, "supergroup", STRANGER)
        self.s.chat.fail = True
        o = await self.engine.handle(ctx, MessageView(A, STRANGER, 9, "evil.com"), self.s.clock())
        self.assertEqual(o.kind, OutcomeKind.UNSAFE_NO_ACTION)
        self.assertEqual(self.actions.deleted, [])

    async def test_only_delete_right_deletes_without_mute(self):
        self.s.chat.set(A, BOT, ChatMemberInfo("administrator", True, False, True))
        o = await self.send("evil.com")
        self.assertEqual((o.deleted, o.muted_seconds), (True, None))
        self.assertEqual(self.actions.muted, [])

    async def test_only_restrict_right_mutes_without_delete(self):
        self.s.chat.set(A, BOT, ChatMemberInfo("administrator", False, True, True))
        o = await self.send("evil.com")
        self.assertEqual((o.deleted, o.muted_seconds), (False, 600))
        self.assertFalse(o.consumed)


class FloodAndDuplicateTests(Base):
    async def test_flood_triggers_after_threshold_and_resets(self):
        await self.cfg(flood_max_messages=3, flood_window_seconds=10)
        outs = [await self.send(f"msg {i}", advance=1) for i in range(3)]
        self.assertTrue(all(o.kind is OutcomeKind.NONE for o in outs))
        o = await self.send("msg 4", advance=1)
        self.assertEqual((o.kind, o.violation), (OutcomeKind.ACTED, "flood"))
        self.assertEqual(o.muted_seconds, 600)

    async def test_slow_user_not_flagged(self):
        await self.cfg(flood_max_messages=3, flood_window_seconds=10)
        for i in range(10):
            self.assertEqual((await self.send(f"m{i}", advance=5)).kind, OutcomeKind.NONE)

    async def test_flood_is_per_user_and_per_group(self):
        await self.cfg(flood_max_messages=2)
        for i in range(2):
            await self.send(f"a{i}", user=STRANGER, advance=0.1)
        self.assertEqual((await self.send("b", user=900_100, advance=0.1)).kind, OutcomeKind.NONE)

    async def test_inflight_messages_after_mute_only_deleted_no_new_offense(self):
        await self.cfg(flood_max_messages=2)
        for i in range(3):
            await self.send(f"x{i}", advance=0.1)
        self.assertEqual(len(self.actions.muted), 1)
        for i in range(10):
            await self.send(f"y{i}", advance=0.1)
        self.assertEqual(len(self.actions.muted), 1)  # no repeated mute / escalation burst

    async def test_duplicate_messages(self):
        await self.cfg(duplicate_max_repeats=3, duplicate_window_seconds=60, flood_enabled=False)
        self.assertEqual((await self.send("Buy now!!", advance=5)).kind, OutcomeKind.NONE)
        self.assertEqual((await self.send("buy   NOW!!", advance=5)).kind, OutcomeKind.NONE)
        o = await self.send("BUY now!!", advance=5)
        self.assertEqual((o.kind, o.violation), (OutcomeKind.ACTED, "duplicate"))

    async def test_duplicate_outside_window_and_short_text_ignored(self):
        await self.cfg(duplicate_max_repeats=2, duplicate_window_seconds=10, flood_enabled=False)
        for _ in range(4):
            self.assertEqual((await self.send("same text here", advance=20)).kind, OutcomeKind.NONE)
        for _ in range(5):
            self.assertEqual((await self.send("ok", advance=1)).kind, OutcomeKind.NONE)

    async def test_flood_disabled(self):
        await self.cfg(flood_enabled=False, duplicate_enabled=False)
        for i in range(30):
            self.assertEqual((await self.send(f"m{i}", advance=0.1)).kind, OutcomeKind.NONE)


class TelegramErrorTests(Base):
    async def test_delete_failure_still_mutes_and_never_raises(self):
        self.actions.delete_result = ActionResult(False, "not_found")
        o = await self.send("evil.com")
        self.assertEqual((o.kind, o.deleted, o.muted_seconds), (OutcomeKind.ACTED, False, 600))

    async def test_mute_failure_is_not_counted_as_muted(self):
        self.actions.mute_result = ActionResult(False, "forbidden")
        o = await self.send("evil.com")
        self.assertEqual((o.deleted, o.muted_seconds), (True, None))

    async def test_engine_exception_means_no_action(self):
        async def boom(*a, **k):
            raise RuntimeError("x")
        self.actions.delete_message = boom
        self.assertEqual((await self.send("evil.com")).kind, OutcomeKind.UNSAFE_NO_ACTION)

    async def test_settings_store_failure_uses_safe_defaults(self):
        async def boom(*a, **k):
            raise RuntimeError("db")
        self.s.settings_store.get = boom
        self.assertEqual((await self.send("evil.com")).kind, OutcomeKind.ACTED)  # default: links blocked


class AdapterTests(unittest.IsolatedAsyncioTestCase):
    def test_classify(self):
        class TelegramRetryAfter(Exception):
            retry_after = 2

        class TelegramForbiddenError(Exception): ...

        self.assertEqual(classify_error(TelegramRetryAfter("x")), "rate_limited")
        self.assertEqual(classify_error(TelegramForbiddenError("x")), "forbidden")
        self.assertEqual(classify_error(Exception("Bad Request: message to delete not found")), "not_found")
        self.assertEqual(classify_error(Exception("boom")), "other")

    async def test_retry_after_once_then_gives_up_without_raising(self):
        class RA(Exception):
            retry_after = 1

        calls, slept = [], []

        class Bot:
            async def delete_message(self, c, m):
                calls.append(1)
                raise RA("secret details")

        async def sleep(s):
            slept.append(s)

        r = await AiogramModerationActions(Bot(), sleep=sleep).delete_message(A, 1)
        self.assertEqual((r.ok, r.error, len(calls), slept), (False, "rate_limited", 2, [1.0]))

    async def test_success(self):
        class Bot:
            async def delete_message(self, c, m): return True

        self.assertTrue((await AiogramModerationActions(Bot()).delete_message(A, 1)).ok)


class MiddlewareIntegrationTests(Base):
    def ev(self, text, user=STRANGER, mid=1, **extra):
        return NS(chat=NS(id=A, type="supergroup", title="T"), from_user=NS(id=user), sender_chat=None,
                  message_id=mid, text=text, entities=None, caption=None, caption_entities=None, **extra)

    async def run_mw(self, event, **kw):
        seen = []

        async def handler(e, d):
            seen.append(e)
            return "handled"

        r = await ProtectionGateMiddleware(self.gate, self.engine, **kw)(handler, event, {})
        return r, seen

    async def test_violating_message_not_passed_to_handlers(self):
        r, seen = await self.run_mw(self.ev("evil.com"))
        self.assertEqual((r, seen), (None, []))
        self.assertEqual(len(self.actions.deleted), 1)

    async def test_clean_message_and_owner_commands_pass(self):
        r, seen = await self.run_mw(self.ev("hello"))
        self.assertEqual(r, "handled")
        r, _ = await self.run_mw(self.ev("/status evil.com", user=OWNER, mid=2))
        self.assertEqual(r, "handled")
        self.assertEqual(self.actions.deleted, [])

    async def test_expired_group_passes_through_without_action(self):
        await self.s.admin.stop(OWNER, A)
        r, _ = await self.run_mw(self.ev("evil.com", mid=3))
        self.assertEqual(r, "handled")
        self.assertEqual(self.actions.deleted, [])

    async def test_engine_crash_never_blocks_handler(self):
        async def boom(*a, **k):
            raise RuntimeError("x")
        self.engine.handle = boom
        r, _ = await self.run_mw(self.ev("hello", mid=4))
        self.assertEqual(r, "handled")

    async def test_edited_message_flag(self):
        r, _ = await self.run_mw(self.ev("evil.com", mid=5), is_edit=True)
        self.assertIsNone(r)


if __name__ == "__main__":
    unittest.main()
