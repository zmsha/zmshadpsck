"""HTTP-level tests. Require fastapi + aiogram + httpx; SKIPPED when they are not installed.

NOTE: these were written in an offline sandbox and have NEVER been executed (see TEST_REPORT.md).
"""
import importlib.util
import unittest

from helpers import VALID_ENV

HAVE_DEPS = all(importlib.util.find_spec(m) for m in ("fastapi", "aiogram", "httpx"))


class FakeBot:
    class session:  # noqa: N801
        @staticmethod
        async def close():
            return None

    async def set_webhook(self, **kwargs):
        return True


class FakeDispatcher:
    def __init__(self):
        self.fed = []

    async def feed_update(self, bot, update):
        self.fed.append(update.update_id)

    def resolve_used_update_types(self):
        return ["message", "my_chat_member"]


class FakeDatabase:
    last_known_status = "unknown"

    async def ensure_pool(self):
        return None

    async def close(self):
        return None


@unittest.skipUnless(HAVE_DEPS, "fastapi/aiogram/httpx not installed")
class AppTests(unittest.TestCase):
    def setUp(self):
        from fastapi.testclient import TestClient

        from guardian.app import create_app
        from guardian.config import load_settings

        env = dict(VALID_ENV, RUN_MIGRATIONS_ON_STARTUP="false")
        self.settings = load_settings(env)
        self.dispatcher = FakeDispatcher()
        app = create_app(self.settings, bot=FakeBot(), dispatcher=self.dispatcher, database=FakeDatabase())
        self.client = TestClient(app)
        self.client.__enter__()

    def tearDown(self):
        self.client.__exit__(None, None, None)

    def test_health(self):
        r = self.client.get("/health")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json(), {"status": "ok", "database": "unknown"})

    def test_docs_are_disabled(self):
        for path in ("/docs", "/redoc", "/openapi.json"):
            self.assertEqual(self.client.get(path).status_code, 404)

    def test_webhook_rejects_missing_or_wrong_secret(self):
        body = {"update_id": 1}
        self.assertEqual(self.client.post("/telegram/webhook", json=body).status_code, 403)
        r = self.client.post("/telegram/webhook", json=body, headers={"X-Telegram-Bot-Api-Secret-Token": "wrong"})
        self.assertEqual(r.status_code, 403)
        self.assertEqual(self.dispatcher.fed, [])

    def test_webhook_accepts_valid_secret_and_dedups(self):
        headers = {"X-Telegram-Bot-Api-Secret-Token": self.settings.webhook_secret}
        for _ in range(2):
            self.assertEqual(self.client.post("/telegram/webhook", json={"update_id": 7}, headers=headers).status_code, 200)
        self.assertEqual(self.dispatcher.fed, [7])

    def test_webhook_bad_payload(self):
        headers = {"X-Telegram-Bot-Api-Secret-Token": self.settings.webhook_secret}
        self.assertEqual(self.client.post("/telegram/webhook", json={"no": "id"}, headers=headers).status_code, 400)

    # --- Phase 8.1 additions (skipped without fastapi/aiogram/httpx; NEVER executed in the build sandbox) ---

    def test_webhook_rejects_non_object_boolean_and_unparsable_bodies(self):
        headers = {"X-Telegram-Bot-Api-Secret-Token": self.settings.webhook_secret}
        url = "/telegram/webhook"
        self.assertEqual(self.client.post(url, json=[1, 2], headers=headers).status_code, 400)
        self.assertEqual(self.client.post(url, json={"update_id": True}, headers=headers).status_code, 400)
        self.assertEqual(self.client.post(url, content=b"not json", headers=headers).status_code, 400)
        self.assertEqual(self.dispatcher.fed, [])

    def test_a_failing_dispatcher_still_answers_200_and_the_retry_is_not_fed_again(self):
        class Boom(FakeDispatcher):
            async def feed_update(self, bot, update):
                self.fed.append(update.update_id)
                raise RuntimeError("handler blew up")

        from fastapi.testclient import TestClient

        from guardian.app import create_app

        dispatcher = Boom()
        app = create_app(self.settings, bot=FakeBot(), dispatcher=dispatcher, database=FakeDatabase())
        headers = {"X-Telegram-Bot-Api-Secret-Token": self.settings.webhook_secret}
        with TestClient(app) as client:
            for _ in range(2):
                r = client.post("/telegram/webhook", json={"update_id": 11}, headers=headers)
                self.assertEqual(r.status_code, 200)
                self.assertEqual(r.json(), {"ok": True})
        self.assertEqual(dispatcher.fed, [11])


if __name__ == "__main__":
    unittest.main()
