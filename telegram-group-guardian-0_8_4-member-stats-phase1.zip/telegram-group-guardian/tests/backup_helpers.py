"""Fakes for the backup tests (stdlib only)."""
from __future__ import annotations

from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone

from guardian.backup.format import TABLES, BY_NAME

T0 = datetime(2026, 11, 1, 9, 30, 15, tzinfo=timezone.utc)
FIXED_NOW = datetime(2026, 11, 1, 12, 0, 0, tzinfo=timezone.utc)


def sample_rows() -> dict[str, list[dict]]:
    """A realistic little database: two groups, Arabic text, JSON settings, every table non-empty."""
    g1, g2 = -1001, -1002
    d = lambda n: T0 + timedelta(minutes=n)  # noqa: E731
    return {
        "telegram_groups": [
            dict(group_id=g1, title="مجموعة الاختبار", license_status="active_temporary", activated_at=d(0), expires_at=d(60 * 24 * 30),
                 activated_by=111, status_note=None, created_at=d(-5), updated_at=d(0)),
            dict(group_id=g2, title="Second group", license_status="active_permanent", activated_at=d(1), expires_at=None,
                 activated_by=111, status_note="ok", created_at=d(-4), updated_at=d(1)),
        ],
        "license_audit_log": [
            dict(id=1, group_id=g1, actor_telegram_id=111, action="activate", previous_status="pending",
                 new_status="active_temporary", expires_at=d(60 * 24 * 30), reason="شهر واحد", occurred_at=d(0)),
            dict(id=2, group_id=g2, actor_telegram_id=None, action="auto", previous_status=None, new_status="pending",
                 expires_at=None, reason=None, occurred_at=d(1)),
        ],
        "group_settings": [
            dict(group_id=g1, language="ar", settings={"links": {"mode": "delete"}, "flood": 5, "نص": "قيمة"}, updated_at=d(2), updated_by=111),
            dict(group_id=g2, language=None, settings={}, updated_at=d(3), updated_by=None),
        ],
        "group_delegations": [
            dict(id=1, group_id=g1, user_id=222, role="moderator", granted_by=111, granted_at=d(4), revoked_at=None, revoked_by=None),
            dict(id=2, group_id=g1, user_id=333, role="group_manager", granted_by=111, granted_at=d(4), revoked_at=d(9), revoked_by=111),
        ],
        "group_trusted_users": [
            dict(group_id=g1, user_id=444, added_by=222, added_at=d(5), note="موثوق"),
            dict(group_id=g1, user_id=555, added_by=222, added_at=d(6), note=None),
            dict(group_id=g2, user_id=444, added_by=111, added_at=d(7), note=None),
        ],
        "group_trusted_bots": [dict(group_id=g1, bot_id=777, added_by=222, added_at=d(5), note="bot")],
        "moderation_warnings": [
            dict(id=1, group_id=g1, user_id=444, issued_by=None, reason="spam", created_at=d(10), expires_at=d(10 + 60 * 24),
                 revoked_at=None, revoked_by=None, idempotency_key="warn:-1001:5:77"),
        ],
        "moderation_sanctions": [
            dict(id=1, group_id=g1, user_id=444, kind="mute", issued_by=222, reason=None, created_at=d(11), expires_at=d(71),
                 lifted_at=None, lifted_by=None, idempotency_key="sanc:-1001:6:78", violation="flood"),
        ],
        "group_reports": [
            dict(id=1, group_id=g1, reporter_id=555, target_user_id=444, message_id=900, reason="إعلان مزعج", report_type="spam",
                 priority="normal", status="open", assigned_to=None, outcome=None, handled_by=None, handled_at=None,
                 created_at=d(12), updated_at=d(12), trace_id="0123456789abcdef", idempotency_key="reportrow:-1001:9"),
        ],
        "settings_templates": [
            dict(id=1, name="قالب", name_key="قالب", settings={"flood": 3}, created_by=111, created_at=d(13), updated_at=d(13),
                 source_group_id=g1),
        ],
        "global_default_settings": [dict(singleton=True, settings={"language": "ar"}, version=2, updated_by=111, updated_at=d(14))],
    }


class FakeSnapshot:
    """Serves rows ordered by the spec key, strictly after `after`, at most `limit` (like the real SQL)."""

    def __init__(self, data: dict[str, list[dict]], log: list, *, stuck: bool = False, boom: Exception | None = None) -> None:
        self.data, self.log, self.stuck, self.boom = data, log, stuck, boom

    async def read_page(self, spec, after, limit):
        self.log.append((spec.name, after, limit))
        if self.boom is not None:
            raise self.boom
        rows = sorted(self.data.get(spec.name, []), key=lambda r: tuple(r[k] for k in spec.key))
        if after is not None and not self.stuck:
            rows = [r for r in rows if tuple(r[k] for k in spec.key) > tuple(after)]
        return [dict(r) for r in rows[:limit]]


class FakeReader:
    def __init__(self, data: dict[str, list[dict]] | None = None, *, stuck: bool = False, boom: Exception | None = None) -> None:
        self.data = sample_rows() if data is None else data
        self.log: list = []
        self.stuck, self.boom = stuck, boom
        self.opened = 0

    @asynccontextmanager
    async def snapshot(self):
        self.opened += 1
        yield FakeSnapshot(self.data, self.log, stuck=self.stuck, boom=self.boom)


def known_tables() -> set[str]:
    return set(BY_NAME) & {t.name for t in TABLES}
