import unittest

from guardian.errors import (ConcurrentModification, GroupNotRegistered, InvalidInput, InvalidTransition,
                             PermissionDenied, StoreUnavailable)
from guardian.user_errors import message_for


class UserErrorTests(unittest.TestCase):
    def test_messages_are_generic_and_localized(self):
        secret = "postgresql://u:pw@h/db 123456789:AAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        for exc in (PermissionDenied("change_license", secret), GroupNotRegistered(secret), InvalidTransition(secret),
                    InvalidInput(secret), ConcurrentModification(secret), StoreUnavailable(secret), RuntimeError(secret)):
            for lang in ("ar", "en"):
                text = message_for(exc, lang)
                self.assertTrue(text)
                self.assertNotIn("postgresql", text)
                self.assertNotIn("AAAA", text)
        self.assertNotEqual(message_for(PermissionDenied("p", "r"), "ar"), message_for(PermissionDenied("p", "r"), "en"))


if __name__ == "__main__":
    unittest.main()
