"""Phase 8.1 - the gaps `docs/TEST_MATRIX.md` found, and a guard that keeps the matrix honest.

Why structural (AST) tests for two of them: `guardian.app` and `guardian.bot.routers.errors` import
fastapi/aiogram at module level, and those are NOT installable in the build sandbox (see TEST_REPORT.md).
These tests therefore read the source with `ast` and pin the behaviour that matters for safety. The real
HTTP behaviour of the same paths is covered by `test_app_integration.py`, which only runs where fastapi,
aiogram and httpx are installed (it was skipped in the sandbox - never claim it passed).
"""
from __future__ import annotations

import ast
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "src" / "guardian" / "app.py"
ERRORS = ROOT / "src" / "guardian" / "bot" / "routers" / "errors.py"
MATRIX = ROOT / "docs" / "TEST_MATRIX.md"
TESTS = ROOT / "tests"


def _func(tree: ast.AST, name: str) -> ast.AST:
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name:
            return node
    raise AssertionError(f"function {name} not found")


def _tries(fn: ast.AST) -> list[ast.Try]:
    return [n for n in ast.walk(fn) if isinstance(n, ast.Try)]


def _calls(node: ast.AST, attr: str) -> bool:
    return any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == attr
               for n in ast.walk(node))


def _returns_error_status(node: ast.AST) -> bool:
    """True when anything under `node` returns a JSONResponse with a status_code keyword."""
    for n in ast.walk(node):
        if isinstance(n, ast.Call) and getattr(n.func, "id", None) == "JSONResponse":
            if any(k.arg == "status_code" for k in n.keywords):
                return True
    return False


class WebhookErrorPathTests(unittest.TestCase):
    """The webhook must never make Telegram redeliver an update the bot already acted on."""

    @classmethod
    def setUpClass(cls):
        cls.fn = _func(ast.parse(APP.read_text(encoding="utf-8")), "telegram_webhook")

    def test_a_dispatcher_failure_is_answered_200_so_telegram_does_not_redeliver(self):
        feed = [t for t in _tries(self.fn) if _calls(t, "feed_update")]
        self.assertEqual(len(feed), 1, "feed_update must sit in exactly one try block")
        handlers = feed[0].handlers
        self.assertTrue(handlers, "the dispatch try block needs an except")
        for h in handlers:
            self.assertFalse(_returns_error_status(h), "an update failure must not turn into a non-2xx answer")
            self.assertTrue(any(isinstance(n, ast.Call) and getattr(n.func, "attr", "") == "error"
                                for n in ast.walk(h)), "the failure must be logged")

    def test_a_failing_durable_dedup_does_not_stop_the_update_or_enable_anything(self):
        claim = [t for t in _tries(self.fn) if _calls(t, "claim")]
        self.assertEqual(len(claim), 1)
        for h in claim[0].handlers:
            self.assertFalse(any(isinstance(n, ast.Return) for n in ast.walk(h)),
                             "a dedup outage must fall through to the (fail-closed) handlers, not return")
            self.assertFalse(any(isinstance(n, ast.Raise) for n in ast.walk(h)))

    def test_only_a_real_integer_update_id_is_accepted(self):
        src = ast.unparse(self.fn)
        self.assertIn("isinstance(update_id, int)", src)
        self.assertIn("isinstance(update_id, bool)", src, "True/False must not pass as an update id")
        self.assertIn("isinstance(payload, dict)", src, "a JSON list/number must be a 400, not a crash")

    def test_the_only_client_errors_are_one_403_and_two_400s(self):
        codes = sorted(k.value.value for n in ast.walk(self.fn) if isinstance(n, ast.Call)
                       for k in n.keywords if k.arg == "status_code" and isinstance(k.value, ast.Constant))
        self.assertEqual(codes, [400, 400, 403])  # bad secret; unparsable body; bad update_id

    def test_the_catch_all_http_handler_answers_a_fixed_body_without_the_exception_text(self):
        tree = ast.parse(APP.read_text(encoding="utf-8"))
        fn = _func(tree, "unhandled")
        returns = [n for n in ast.walk(fn) if isinstance(n, ast.Return)]
        self.assertEqual(len(returns), 1)
        text = ast.unparse(returns[0])
        self.assertIn("'error': 'internal'", text)
        self.assertIn("500", text)
        self.assertNotIn("exc", text.replace("exc_info", ""), "the answer must not echo the exception")


class CentralErrorHandlerTests(unittest.TestCase):
    """`bot/routers/errors.py::on_error`: log, answer generically in private only, never propagate."""

    @classmethod
    def setUpClass(cls):
        cls.src = ERRORS.read_text(encoding="utf-8")
        cls.fn = _func(ast.parse(cls.src), "on_error")

    def test_it_always_reports_the_error_as_handled(self):
        returns = [n for n in ast.walk(self.fn) if isinstance(n, ast.Return)]
        self.assertEqual(len(returns), 1)
        self.assertIsInstance(returns[0].value, ast.Constant)
        self.assertIs(returns[0].value.value, True)
        self.assertFalse(any(isinstance(n, ast.Raise) for n in ast.walk(self.fn)))

    def test_a_failing_reply_is_swallowed_and_the_reply_is_private_only(self):
        tries = _tries(self.fn)
        self.assertEqual(len(tries), 1)
        self.assertTrue(_calls(tries[0], "answer"))
        self.assertTrue(any(isinstance(h.type, ast.Name) and h.type.id == "Exception" for h in tries[0].handlers))
        self.assertIn("message.chat.type == 'private'", ast.unparse(self.fn))

    def test_the_user_sees_only_a_generic_text_with_a_trace_id_never_the_exception(self):
        answer = [n for n in ast.walk(self.fn) if isinstance(n, ast.Call) and getattr(n.func, "attr", "") == "answer"]
        self.assertEqual(len(answer), 1)
        text = ast.unparse(answer[0])
        self.assertIn("error_generic", text)
        self.assertIn("trace_id", text)
        self.assertNotIn("exception", text)


def _declared_tests() -> dict[str, set[str]]:
    """{file name: {'Class.test_x' | 'test_x'}} read from the test sources (no import, no run)."""
    out: dict[str, set[str]] = {}
    for f in TESTS.glob("test_*.py"):
        names: set[str] = set()
        for node in ast.parse(f.read_text(encoding="utf-8")).body:
            if isinstance(node, ast.ClassDef):
                names.update(f"{node.name}.{m.name}" for m in node.body
                             if isinstance(m, (ast.FunctionDef, ast.AsyncFunctionDef)) and m.name.startswith("test"))
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test"):
                names.add(node.name)
        out[f.name] = names
    return out


REF = re.compile(r"`(test_[a-z0-9_]+\.py)::([A-Za-z0-9_.]+)`")


class MatrixIsHonestTests(unittest.TestCase):
    """`docs/TEST_MATRIX.md` may not name a test that does not exist, nor drop a mandatory item."""

    @classmethod
    def setUpClass(cls):
        cls.text = MATRIX.read_text(encoding="utf-8")
        cls.declared = _declared_tests()

    def test_every_test_the_matrix_names_exists(self):
        refs = REF.findall(self.text)
        self.assertGreater(len(refs), 60)
        missing = [f"{f}::{n}" for f, n in refs if n not in self.declared.get(f, set())]
        self.assertEqual(missing, [])

    def _section(self, heading: str) -> str:
        m = re.search(rf"(?ms)^### {re.escape(heading)}\b.*?(?=^### |^## |\Z)", self.text)
        self.assertIsNotNone(m, f"matrix section missing: {heading}")
        return m.group(0)

    def test_all_nine_mandatory_licence_items_are_present_and_each_names_a_test(self):
        for i in range(1, 10):
            sec = self._section(f"L{i}")
            self.assertTrue(REF.search(sec), f"L{i} names no test")

    def test_all_the_coverage_categories_are_present_and_each_names_a_test(self):
        for key in ("links", "sanctions", "warnings", "durations", "permissions", "isolation", "bypass", "forged",
                    "owner-group", "dry-run", "export-restore", "idempotency", "telegram-errors", "webhook"):
            sec = self._section(f"C-{key}")
            self.assertTrue(REF.search(sec), f"C-{key} names no test")

    def test_what_could_not_run_is_stated(self):
        for needle in ("skipped", "fastapi", "aiogram", "PostgreSQL"):
            self.assertIn(needle, self.text)


if __name__ == "__main__":
    unittest.main()
