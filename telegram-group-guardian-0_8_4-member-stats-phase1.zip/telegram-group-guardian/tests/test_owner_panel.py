"""Phase 5 / part 5.3: the OWNER panel (read only) -- signed callbacks, owner-only service, views, command parser, aiogram-free
glue, the new store listing and the global owner permission. aiogram/FastAPI/PostgreSQL are NOT exercised (not installable in
the build sandbox): the router is checked statically and the Postgres store against a fake connection."""
from __future__ import annotations

import re
import unittest
from contextlib import asynccontextmanager
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace as NS

import helpers  # noqa: F401
from guardian.audit import FORGED_CALLBACK, PERMISSION_DENIED
from guardian.bot import owner_panel_handler as h
from guardian.i18n import MESSAGES
from guardian.licensing.memory_store import InMemoryLicenseStore
from guardian.licensing.models import GroupLicense, LicenseStatus as S, effective_status
from guardian.licensing.postgres_store import PostgresLicenseStore
from guardian.owner_panel import codec, views
from guardian.owner_panel.command import ParsedOwnerCommand, parse_owner_command
from guardian.owner_panel.service import MAX_SEARCHES, OwnerPanelService
from guardian.permissions import OWNER_ONLY, Permission
from guardian.services import Services
from stack import A, B, BACKUP, DELEGATE, NOW, OWNER, STRANGER, TG_ADMIN, TG_CREATOR, Stack

SRC = Path(__file__).resolve().parents[1] / "src" / "guardian"
SECRET = "owner-panel-test-secret-0123456789"
KEY = codec.derive_key(SECRET)
ANON = 1087968824


def cb(screen, chat=OWNER, **kw):
    return codec.build(KEY, chat, screen, **kw)


def buttons_flat(outcome):
    return [b for row in (outcome.buttons or ()) for b in row]


def find(outcome, needle):
    for label, data in buttons_flat(outcome):
        if needle in label:
            return data
    raise AssertionError(f"no button containing {needle!r} in {[l for l, _ in buttons_flat(outcome)]}")


# ----------------------------------------------------------------------------- codec
class CodecTests(unittest.TestCase):
    def test_round_trip_every_screen(self):
        cases = [(codec.LIST, dict(filter="p", page=3)), (codec.FILTERS, dict(filter="x", page=0)),
                 (codec.DETAIL, dict(group_id=-1001234567890, filter="b", page=12)), (codec.SEARCH_HELP, {}),
                 (codec.CLEAR_SEARCH, {}), (codec.CLOSE, {})]
        for screen, kw in cases:
            with self.subTest(screen):
                parsed = codec.parse(cb(screen, **kw))
                self.assertEqual(parsed.screen, screen)
                self.assertTrue(codec.verify(KEY, OWNER, parsed))
                if "filter" in kw:
                    self.assertEqual((parsed.filter, parsed.page), (kw["filter"], kw["page"]))
                self.assertEqual(parsed.group_id, kw.get("group_id"))

    def test_the_pressed_chat_is_part_of_the_signature(self):
        parsed = codec.parse(cb(codec.LIST, filter="a", page=0))
        self.assertFalse(codec.verify(KEY, STRANGER, parsed))
        for bad_chat in (-1001, 0, True, None, "111"):
            self.assertFalse(codec.verify(KEY, bad_chat, parsed), bad_chat)

    def test_changed_filter_page_group_or_screen_fails(self):
        data = cb(codec.DETAIL, group_id=-1001, filter="a", page=0)
        tag = data.rsplit(":", 1)[1]
        for forged in (f"ow:d:-1002:a:0:{tag}", f"ow:d:-1001:b:0:{tag}", f"ow:d:-1001:a:1:{tag}", f"ow:l:a:0:{tag}",
                       f"ow:x:{tag}", f"ow:d:-1001:a:0:{'0' * 12}"):
            parsed = codec.parse(forged)
            self.assertIsNotNone(parsed, forged)
            self.assertFalse(codec.verify(KEY, OWNER, parsed), forged)

    def test_another_secret_fails(self):
        other = codec.derive_key("another-owner-secret-value-xyz")
        parsed = codec.parse(codec.build(other, OWNER, codec.LIST))
        self.assertFalse(codec.verify(KEY, OWNER, parsed))

    def test_owner_and_group_panel_keys_are_domain_separated(self):
        from guardian.panel import codec as group_codec
        self.assertNotEqual(codec.derive_key(SECRET), group_codec.derive_key(SECRET))

    def test_malformed_data_is_rejected(self):
        tag = "a" * 12
        for bad in (None, 5, b"ow:x:" + tag.encode(), "", "ow", "pn:x:" + tag, f"ow:x:{tag}:extra", f"ow:l:a:{tag}",
                    f"ow:l:z:0:{tag}", f"ow:l:ab:0:{tag}", f"ow:l:a:12345:{tag}", f"ow:l:a:-1:{tag}", f"ow:l:a:٣:{tag}",
                    f"ow:d:1001:a:0:{tag}", f"ow:d:-0:a:0:{tag}", f"ow:d:-01:a:0:{tag}", f"ow:d:-99999999999999999999:a:0:{tag}",
                    f"ow:d:-1001:a:{tag}", f"ow:q:{tag}", f"ow:x:{'A' * 12}", f"ow:x:{'a' * 11}", "ow:x:" + "a" * 70,
                    f"ow:l:a:0:{tag}\n", f"OW:x:{tag}"):
            with self.subTest(repr(bad)[:40]):
                self.assertIsNone(codec.parse(bad))

    def test_longest_callback_fits_telegram_limit(self):
        data = cb(codec.DETAIL, group_id=-(2**63), filter="b", page=codec.MAX_PAGE)
        self.assertLessEqual(len(data.encode()), 64)
        self.assertIsNotNone(codec.parse(data))

    def test_build_validation(self):
        for kw in (dict(screen="zz"), dict(screen=codec.LIST, filter="z"), dict(screen=codec.LIST, page=-1),
                   dict(screen=codec.LIST, page=10_000), dict(screen=codec.LIST, page=True),
                   dict(screen=codec.DETAIL), dict(screen=codec.DETAIL, group_id=5), dict(screen=codec.DETAIL, group_id=True),
                   dict(screen=codec.DETAIL, group_id=-(2**63) - 1)):
            with self.subTest(kw), self.assertRaises(ValueError):
                codec.build(KEY, OWNER, **kw)
        for chat in (-5, 0, True):
            with self.assertRaises(ValueError):
                codec.build(KEY, chat, codec.LIST)
        with self.assertRaises(ValueError):
            codec.derive_key("")


# ----------------------------------------------------------------------------- permissions (global owner check)
class GlobalOwnerPermissionTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()

    async def test_only_the_primary_owner_passes(self):
        self.assertTrue((await self.s.perm.check_global(OWNER, Permission.OWNER_PANEL)).allowed)
        for who in (BACKUP, STRANGER, TG_ADMIN, TG_CREATOR, DELEGATE, ANON, 777000, 0, -5, None, True, "111111111", 1.0):
            with self.subTest(who):
                self.assertFalse((await self.s.perm.check_global(who, Permission.OWNER_PANEL)).allowed)

    async def test_the_new_permission_is_owner_only_for_every_group_check_too(self):
        self.assertIn(Permission.OWNER_PANEL, OWNER_ONLY)
        await self.s.register(A)
        for who in (BACKUP, TG_ADMIN, TG_CREATOR, STRANGER):
            self.assertFalse((await self.s.perm.check(who, A, Permission.OWNER_PANEL, context_chat_id=A)).allowed, who)

    async def test_non_owner_only_permissions_are_refused_globally_even_for_the_owner(self):
        for perm in Permission:
            if perm not in OWNER_ONLY:
                with self.subTest(perm):
                    self.assertFalse((await self.s.perm.check_global(OWNER, perm)).allowed)

    async def test_denials_are_audited_and_throttled(self):
        await self.s.perm.check_global(STRANGER, Permission.OWNER_PANEL)
        await self.s.perm.check_global(STRANGER, Permission.OWNER_PANEL)
        events = [e for e in self.s.audit.events if e.event_type == PERMISSION_DENIED]
        self.assertEqual(len(events), 1)
        self.assertEqual((events[0].actor_telegram_id, events[0].group_id, events[0].permission),
                         (STRANGER, None, "owner_panel"))
        await self.s.perm.check_global(STRANGER, Permission.OWNER_PANEL, audit_denial=False)
        self.s.clock.advance(minutes=5)
        await self.s.perm.check_global(STRANGER, Permission.OWNER_PANEL)
        self.assertEqual(len([e for e in self.s.audit.events if e.event_type == PERMISSION_DENIED]), 2)


# ----------------------------------------------------------------------------- stores
class StoreListingTests(unittest.IsolatedAsyncioTestCase):
    async def test_in_memory_list_all_orders_and_limits(self):
        store = InMemoryLicenseStore()
        for i, minute in enumerate([2, 0, 4, 1, 3]):
            await store.register_pending_if_absent(-1000 - i, f"G{i}", NOW + timedelta(minutes=minute))
        await store.register_pending_if_absent(-1100, "tie-a", NOW)
        await store.register_pending_if_absent(-1200, "tie-b", NOW)
        rows = await store.list_all()
        # newest change first; equal times by group id (ascending)
        self.assertEqual([r.group_id for r in rows], [-1002, -1004, -1000, -1003, -1200, -1100, -1001])
        self.assertEqual(len(await store.list_all(2)), 2)
        self.assertEqual(len(await store.list_all(0)), 1)       # clamped to >= 1
        self.assertEqual(len(await store.list_all(10**9)), 7)   # clamped to <= 5000

    async def test_postgres_list_all_is_one_read_only_query(self):
        calls = []

        class Conn:
            async def fetch(self, sql, *args):
                calls.append((" ".join(sql.split()), args))
                return [dict(group_id=-5, title="T", license_status="active_temporary", activated_at=NOW,
                             expires_at=NOW + timedelta(days=1), activated_by=OWNER, status_note=None, updated_at=NOW)]

        class Db:
            @asynccontextmanager
            async def acquire(self):
                yield Conn()

        rows = await PostgresLicenseStore(Db()).list_all(10**9)
        self.assertEqual(len(rows), 1)
        self.assertEqual((rows[0].group_id, rows[0].status), (-5, S.ACTIVE_TEMPORARY))
        sql, args = calls[0]
        self.assertTrue(sql.startswith("SELECT") and "FROM telegram_groups" in sql and "LIMIT $1" in sql)
        self.assertEqual(args, (5000,))
        self.assertNotRegex(sql, r"(?i)\b(UPDATE|INSERT|DELETE)\b")


# ----------------------------------------------------------------------------- pure views
def lic(gid, title, status=S.PENDING, **kw):
    kw.setdefault("updated_at", NOW)
    return GroupLicense(gid, title, status, **kw)


class ViewsTests(unittest.TestCase):
    def b(self, screen, **kw):
        return codec.build(KEY, OWNER, screen, **kw)

    def test_effective_status_is_expired_after_the_time_even_if_stored_active(self):
        row = lic(-1, "T", S.ACTIVE_TEMPORARY, activated_at=NOW, expires_at=NOW + timedelta(hours=1))
        self.assertIs(effective_status(row, NOW), S.ACTIVE_TEMPORARY)
        self.assertIs(effective_status(row, NOW + timedelta(hours=1)), S.EXPIRED)   # boundary: now >= expires_at
        self.assertIs(effective_status(lic(-2, "P"), NOW), S.PENDING)

    def test_counts_and_filter_use_the_effective_status(self):
        later = NOW + timedelta(days=2)
        rows = [lic(-1, "a"), lic(-2, "b", S.ACTIVE_PERMANENT, activated_at=NOW),
                lic(-3, "c", S.ACTIVE_TEMPORARY, activated_at=NOW, expires_at=NOW + timedelta(days=1)),
                lic(-4, "d", S.BANNED), lic(-5, "e", S.STOPPED), lic(-6, "f", S.REJECTED), lic(-7, "g", S.EXPIRED)]
        c = views.counts(rows, later)
        self.assertEqual((c["a"], c["p"], c["d"], c["t"], c["x"], c["s"], c["r"], c["b"]), (7, 1, 1, 0, 2, 1, 1, 1))
        self.assertEqual({r.group_id for r in views.select(rows, "x", "", later)}, {-3, -7})
        self.assertEqual({r.group_id for r in views.select(rows, "t", "", NOW)}, {-3})
        self.assertEqual(len(views.select(rows, "a", "", NOW)), 7)

    def test_every_filter_code_maps_to_a_status_and_label(self):
        self.assertEqual(set(views.FILTER_STATUS), set(codec.FILTER_CODES))
        for code in codec.FILTER_CODES:
            for lang in ("ar", "en"):
                self.assertTrue(views.filter_label(code, lang))

    def test_pending_groups_come_first_then_newest(self):
        rows = [lic(-1, "old", S.STOPPED, updated_at=NOW), lic(-2, "new", S.STOPPED, updated_at=NOW + timedelta(hours=1)),
                lic(-3, "pend", S.PENDING, updated_at=NOW - timedelta(days=5))]
        self.assertEqual([r.group_id for r in views.ordered(rows, NOW)], [-3, -2, -1])

    def test_search_matches_title_id_arabic_forms_and_digits(self):
        row = lic(-1001234567890, "مجموعة الأصدقاء Alpha")
        for q in ("alpha", "ALPHA", "الاصدقاء", "أصدقاء", "1234", "١٢٣٤", "-100123", "مجموعه"):
            with self.subTest(q):
                self.assertTrue(views.matches(row, views.normalise_query(q)), q)
        for q in ("beta", "9999", "الاصدقاءء"):
            with self.subTest(q):
                self.assertFalse(views.matches(row, views.normalise_query(q)), q)
        self.assertTrue(views.matches(lic(-5, None), ""))
        self.assertFalse(views.matches(lic(-5, None), "x"))
        self.assertEqual(views.normalise_query(None), "")

    def test_clean_strips_controls_bidi_and_truncates(self):
        self.assertEqual(views.clean("a‮b\nc\x00d  e", 50), "a b c d e")
        self.assertEqual(views.clean("x" * 100, 10), "x" * 9 + "…")
        self.assertEqual(views.clean(None, 10), "")

    def test_list_pagination_buttons_and_clamping(self):
        rows = [lic(-i, f"G{i}") for i in range(1, 21)]  # 20 groups -> 3 pages of 8
        text, buttons = views.render_list(rows, filt="a", page=1, query="", now=NOW, lang="ar", b=self.b)
        self.assertEqual(len(buttons), 8 + 3)                     # 8 groups + nav + tools + refresh/close
        nav = [lbl for lbl, _ in buttons[8]]
        self.assertEqual(len(nav), 3)
        self.assertIn("2/3", text)
        _, first = views.render_list(rows, filt="a", page=0, query="", now=NOW, lang="ar", b=self.b)
        self.assertEqual(len(first[8]), 2)                        # no "previous" on page 1
        _, last = views.render_list(rows, filt="a", page=2, query="", now=NOW, lang="ar", b=self.b)
        self.assertEqual(len(last[4]), 2)                         # 4 groups on the last page; no "next"
        text, buttons = views.render_list(rows, filt="a", page=99, query="", now=NOW, lang="ar", b=self.b)
        self.assertIn("3/3", text)                                # a stale page number is clamped
        self.assertEqual(views.page_count(0), 1)

    def test_list_empty_and_search_state(self):
        text, buttons = views.render_list([], filt="p", page=0, query="zz", now=NOW, lang="en", b=self.b)
        self.assertIn("No matching groups", text)
        self.assertIn("zz", text)
        labels = [lbl for row in buttons for lbl, _ in row]
        self.assertTrue(any("Clear search" in lbl for lbl in labels))
        self.assertFalse(any("Search" == lbl.split(" ", 1)[-1] for lbl in labels))
        _, plain = views.render_list([], filt="a", page=0, query="", now=NOW, lang="en", b=self.b)
        self.assertTrue(any("Search" in lbl for row in plain for lbl, _ in row))

    def test_titles_are_escaped_in_text_and_raw_in_buttons(self):
        row = lic(-1, "<b>x</b> & y")
        text, buttons = views.render_list([row], filt="a", page=0, query="", now=NOW, lang="ar", b=self.b)
        self.assertIn("&lt;b&gt;x&lt;/b&gt; &amp; y", text)
        self.assertNotIn("<b>x</b>", text)
        self.assertIn("<b>x</b> & y", buttons[0][0][0])          # a plain-text button label

    def test_button_labels_are_short_and_untitled_groups_show_the_id(self):
        _, buttons = views.render_list([lic(-1, "x" * 200), lic(-2, None)], filt="a", page=0, query="", now=NOW,
                                       lang="ar", b=self.b)
        self.assertLessEqual(len(buttons[0][0][0]), views.LABEL_MAX)
        self.assertIn("-2", buttons[1][0][0])

    def test_truncation_notice(self):
        text, _ = views.render_list([lic(-1, "a")], filt="a", page=0, query="", now=NOW, lang="en", b=self.b, truncated_at=2000)
        self.assertIn("2000", text)

    def test_detail_permanent_temporary_expired_pending(self):
        tz = "Asia/Riyadh"
        perm = lic(-1, "P", S.ACTIVE_PERMANENT, activated_at=NOW, activated_by=OWNER)
        text, buttons = views.render_detail(perm, now=NOW, tz=tz, lang="ar", b=self.b, filt="a", page=0)
        self.assertIn("دائم", text)
        self.assertIn(str(OWNER), text)
        self.assertIn("تعمل", text)
        self.assertEqual(len(buttons), 2)
        temp = lic(-2, "T", S.ACTIVE_TEMPORARY, activated_at=NOW, activated_by=OWNER, expires_at=NOW + timedelta(days=3))
        text, _ = views.render_detail(temp, now=NOW, tz=tz, lang="ar", b=self.b, filt="a", page=0)
        self.assertIn("2026-11-01 15:00 (Asia/Riyadh)", text)    # 12:00 UTC + 3 days, shown in Mecca time
        self.assertIn("3 أيام", text)
        text, _ = views.render_detail(temp, now=NOW + timedelta(days=4), tz=tz, lang="en", b=self.b, filt="a", page=0)
        self.assertIn("ended at 2026-11-01 15:00", text)
        self.assertIn("Expired", MESSAGES["en"]["license_expired"].capitalize())
        self.assertIn("off", text)
        text, _ = views.render_detail(lic(-3, "W"), now=NOW, tz=tz, lang="ar", b=self.b, filt="a", page=0)
        self.assertIn("بانتظار موافقة المالك", text)
        self.assertIn("—", text)

    def test_detail_note_is_escaped_and_bounded(self):
        row = lic(-1, "N", S.STOPPED, note="<i>why</i>" + "x" * 500)
        text, _ = views.render_detail(row, now=NOW, tz="UTC", lang="en", b=self.b, filt="a", page=0)
        self.assertIn("&lt;i&gt;why&lt;/i&gt;", text)
        self.assertLess(len(text), 700)

    def test_detail_back_button_returns_to_the_same_list_page(self):
        _, buttons = views.render_detail(lic(-1, "G"), now=NOW, tz="UTC", lang="ar", b=self.b, filt="p", page=4)
        parsed = codec.parse(buttons[0][0][1])
        self.assertEqual((parsed.screen, parsed.filter, parsed.page), (codec.LIST, "p", 4))

    def test_filter_menu_marks_current_and_counts(self):
        counted = {code: i for i, code in enumerate(codec.FILTER_CODES)}
        text, buttons = views.render_filters(counted, current="t", page=2, query="", lang="ar", b=self.b)
        self.assertEqual(len(buttons), len(codec.FILTER_CODES) + 1)
        marked = [row[0][0] for row in buttons[:-1] if row[0][0].startswith("✅")]
        self.assertEqual(len(marked), 1)
        self.assertIn(f"({counted['t']})", marked[0])
        back = codec.parse(buttons[-1][0][1])
        self.assertEqual((back.screen, back.filter, back.page), (codec.LIST, "t", 2))


# ----------------------------------------------------------------------------- the service
class ServiceBase(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        self.svc = self.make()

    def make(self, **kw):
        kw.setdefault("licenses", self.s.licenses)
        return OwnerPanelService(permissions=self.s.perm, audit=self.s.audit, secret=SECRET, clock=self.s.clock, **kw)

    async def seed(self):
        await self.s.register(A, B, -1003, -1004, -1005)
        await self.s.admin.activate_permanent(OWNER, A, context_chat_id=A)
        await self.s.admin.activate_temporary(OWNER, B, NOW + timedelta(days=5), context_chat_id=B)
        await self.s.admin.activate_permanent(OWNER, -1003, context_chat_id=-1003)
        await self.s.admin.stop(OWNER, -1003, context_chat_id=-1003)
        await self.s.admin.ban(OWNER, -1004, context_chat_id=-1004)

    async def press(self, data, *, chat=OWNER, presser=OWNER, ctype="private", lang="ar"):
        return await self.svc.press(chat, ctype, presser, data, lang)

    def snapshot(self):
        return (dict(self.s.licenses._rows), list(self.s.licenses.audit_log))

    def forged_count(self):
        return len([e for e in self.s.audit.events if e.event_type == FORGED_CALLBACK])


class OpenTests(ServiceBase):
    async def test_owner_opens_the_list_in_the_private_chat(self):
        await self.seed()
        out = await self.svc.open(OWNER, "private", OWNER, None, "ar")
        self.assertEqual(out.status, "list")
        self.assertIn("5", out.text)
        for gid in (A, B, -1003, -1004, -1005):
            self.assertIn(str(gid), out.text)
        self.assertIn("Group -1005", out.text)
        self.assertTrue(all(codec.verify(KEY, OWNER, codec.parse(d)) for _, d in buttons_flat(out)))

    async def test_nobody_else_gets_anything_and_denials_are_audited(self):
        await self.seed()
        for who in (BACKUP, STRANGER, TG_ADMIN, TG_CREATOR, DELEGATE, ANON, 777000):
            with self.subTest(who):
                self.assertIsNone(await self.svc.open(who, "private", who, None))
        self.assertTrue([e for e in self.s.audit.events if e.event_type == PERMISSION_DENIED])

    async def test_owner_gets_nothing_in_groups_or_other_chats(self):
        await self.seed()
        self.assertIsNone(await self.svc.open(A, "supergroup", OWNER))
        self.assertIsNone(await self.svc.open(A, "group", OWNER))
        self.assertIsNone(await self.svc.open(OWNER, "channel", OWNER))
        self.assertIsNone(await self.svc.open(STRANGER, "private", OWNER))    # chat is not the owner's private chat
        for bad in (None, True, 0, -5, "111111111"):
            self.assertIsNone(await self.svc.open(bad, "private", OWNER))
            self.assertIsNone(await self.svc.open(OWNER, "private", bad))

    async def test_search_filters_the_list_and_a_bare_open_clears_it(self):
        await self.seed()
        out = await self.svc.open(OWNER, "private", OWNER, "1004")
        self.assertIn("-1004", out.text)
        self.assertNotIn("-1003", out.text)
        self.assertIn("1004", out.text.split("البحث")[1])
        out = await self.svc.open(OWNER, "private", OWNER, "group -1003")
        self.assertIn("-1003", out.text)
        again = await self.svc.open(OWNER, "private", OWNER, None)
        self.assertIn("-1003", again.text)
        self.assertIn("-1004", again.text)

    async def test_search_text_too_long_is_refused_with_a_message(self):
        out = await self.svc.open(OWNER, "private", OWNER, "x" * 80)
        self.assertEqual(out.status, "query_too_long")
        self.assertIn("64", out.text)
        self.assertIsNone(out.buttons)

    async def test_search_memory_is_bounded(self):
        for i in range(MAX_SEARCHES + 5):
            self.svc._remember(1000 + i, f"q{i}")
        self.assertEqual(len(self.svc._queries), MAX_SEARCHES)
        self.svc._remember(1000 + MAX_SEARCHES + 4, "")
        self.assertNotIn(1000 + MAX_SEARCHES + 4, self.svc._queries)

    async def test_store_failure_fails_closed_without_data(self):
        class Down(InMemoryLicenseStore):
            async def list_all(self, limit=2000):
                raise RuntimeError("db down")

        svc = self.make(licenses=Down())
        out = await svc.open(OWNER, "private", OWNER)
        self.assertEqual(out.status, "unavailable")
        self.assertTrue(out.alert)
        self.assertIsNone(out.text)


class PressTests(ServiceBase):
    async def test_every_screen_for_the_owner(self):
        await self.seed()
        opened = await self.svc.open(OWNER, "private", OWNER)
        listing = await self.press(cb(codec.LIST, filter="a", page=0))
        self.assertEqual(listing.status, "list")
        filters = await self.press(find(opened, "تصفية"))
        self.assertEqual(filters.status, "filters")
        self.assertIn("(5)", filters.text + "".join(l for l, _ in buttons_flat(filters)))
        detail = await self.press(cb(codec.DETAIL, group_id=A, filter="a", page=0))
        self.assertEqual(detail.status, "detail")
        self.assertIn("دائم", detail.text)
        self.assertEqual((await self.press(cb(codec.CLOSE))).delete, True)
        help_ = await self.press(cb(codec.SEARCH_HELP))
        self.assertTrue(help_.alert)
        self.assertIn("/owner", help_.toast)
        self.assertIsNone(help_.text)

    async def test_filtering_by_status(self):
        await self.seed()
        expect = {"p": {-1005}, "d": {A}, "t": {B}, "s": {-1003}, "b": {-1004}, "r": set(), "x": set()}
        for code, ids in expect.items():
            with self.subTest(code):
                out = await self.press(cb(codec.LIST, filter=code, page=0))
                shown = {g for g in (A, B, -1003, -1004, -1005) if f"<code>{g}</code>" in out.text}
                self.assertEqual(shown, ids)

    async def test_a_temporary_license_that_ran_out_while_the_host_slept_shows_as_expired(self):
        await self.seed()
        self.s.clock.advance(days=6)            # B's stored status is still active_temporary: nothing persisted the expiry
        self.assertIs(self.s.licenses._rows[B].status, S.ACTIVE_TEMPORARY)
        expired = await self.press(cb(codec.LIST, filter="x", page=0))
        self.assertIn(f"<code>{B}</code>", expired.text)
        temp = await self.press(cb(codec.LIST, filter="t", page=0))
        self.assertNotIn(f"<code>{B}</code>", temp.text)
        detail = await self.press(cb(codec.DETAIL, group_id=B, filter="a", page=0))
        self.assertIn("منتهية", detail.text)
        self.assertIn("متوقفة", detail.text)    # protection is off

    async def test_search_applies_to_pages_filters_and_counts_until_cleared(self):
        await self.seed()
        await self.svc.open(OWNER, "private", OWNER, "1003")
        out = await self.press(cb(codec.LIST, filter="a", page=0))
        self.assertIn("<code>-1003</code>", out.text)
        self.assertNotIn("<code>-1004</code>", out.text)
        filters = await self.press(cb(codec.FILTERS, filter="a", page=0))
        self.assertIn("الكل (1)", "".join(l for l, _ in buttons_flat(filters)))
        cleared = await self.press(find(out, "إلغاء البحث"))
        self.assertIn("<code>-1004</code>", cleared.text)
        self.assertNotIn("البحث", cleared.text.split("\n")[1] if "\n" in cleared.text else "")

    async def test_pagination_walks_all_groups(self):
        await self.s.register(*[-2000 - i for i in range(19)])
        out = await self.svc.open(OWNER, "private", OWNER)
        seen = set(re.findall(r"<code>(-\d+)</code>", out.text))
        pages = 1
        while True:
            nxt = [d for l, d in buttons_flat(out) if "التالي" in l]
            if not nxt:
                break
            out = await self.press(nxt[0])
            seen |= set(re.findall(r"<code>(-\d+)</code>", out.text))
            pages += 1
        self.assertEqual((pages, len(seen)), (3, 19))

    async def test_detail_of_an_unknown_group_and_group_isolation(self):
        await self.seed()
        missing = await self.press(cb(codec.DETAIL, group_id=-424242, filter="a", page=0))
        self.assertEqual(missing.status, "missing")
        detail = await self.press(cb(codec.DETAIL, group_id=A, filter="a", page=0))
        self.assertIn(f"<code>{A}</code>", detail.text)
        for other in (B, -1003, -1004, -1005):
            self.assertNotIn(str(other), detail.text)

    async def test_the_owner_panel_never_writes_a_license(self):
        await self.seed()
        before = self.snapshot()
        await self.svc.open(OWNER, "private", OWNER, "g")
        for data in (cb(codec.LIST, filter="p"), cb(codec.FILTERS), cb(codec.DETAIL, group_id=A), cb(codec.DETAIL, group_id=-9),
                     cb(codec.SEARCH_HELP), cb(codec.CLEAR_SEARCH), cb(codec.CLOSE)):
            await self.press(data)
            await self.press(data, presser=STRANGER, chat=STRANGER)
        self.assertEqual(self.snapshot(), before)

    # -- authorization: every press, by the real presser ------------------------------------------------------------
    async def test_a_non_owner_with_a_valid_looking_callback_gets_nothing(self):
        await self.seed()
        for who in (STRANGER, BACKUP, TG_ADMIN, TG_CREATOR, DELEGATE):
            data = codec.build(KEY, who, codec.DETAIL, group_id=A)   # even signed for HIS OWN chat (key leaked / replayed)
            out = await self.press(data, chat=who, presser=who)
            with self.subTest(who):
                self.assertEqual(out.status, "not_owner")
                self.assertIsNone(out.text)
                self.assertIsNone(out.buttons)
                self.assertTrue(out.alert)
        self.assertGreaterEqual(self.forged_count(), 5)

    async def test_the_owner_callback_replayed_by_someone_else_is_refused(self):
        await self.seed()
        data = cb(codec.LIST)
        out = await self.press(data, chat=STRANGER, presser=STRANGER)   # chat differs from the signed one
        self.assertEqual(out.status, "forged")
        self.assertIsNone(out.text)
        self.assertGreaterEqual(self.forged_count(), 1)

    async def test_hand_made_and_tampered_callbacks(self):
        await self.seed()
        good = cb(codec.DETAIL, group_id=A)
        tampered = good.replace(str(A), str(B))
        for data in (tampered, f"ow:l:a:0:{'0' * 12}", f"ow:x:{'f' * 12}"):
            out = await self.press(data)
            with self.subTest(data):
                self.assertEqual(out.status, "forged")
                self.assertIsNone(out.text)
        before = self.forged_count()
        self.assertIsNone(await self.press("ow:zzz"))               # malformed, our prefix: audited, ignored
        self.assertEqual(self.forged_count(), before + 1)
        self.assertIsNone(await self.press("pn:1:home:" + "a" * 12))  # not ours: silent
        self.assertIsNone(await self.press(None))
        self.assertEqual(self.forged_count(), before + 1)

    async def test_only_in_the_private_chat_of_the_presser(self):
        await self.seed()
        data = cb(codec.LIST)
        for ctype in ("group", "supergroup", "channel", None, ""):
            self.assertIsNone(await self.press(data, ctype=ctype), ctype)
        self.assertIsNone(await self.press(data, chat=A))
        self.assertIsNone(await self.press(data, chat=STRANGER))      # message chat != presser
        for bad in (None, True, 0, -5, "111111111", ANON * 0):
            self.assertIsNone(await self.press(data, presser=bad), bad)

    async def test_authorization_failure_of_the_permission_service_means_refusal(self):
        await self.seed()

        class Broken:
            async def check_global(self, *a, **k):
                raise RuntimeError("boom")

        svc = OwnerPanelService(permissions=Broken(), licenses=self.s.licenses, audit=self.s.audit, secret=SECRET)
        out = await svc.press(OWNER, "private", OWNER, cb(codec.LIST), "ar")
        self.assertEqual(out.status, "not_owner")
        self.assertIsNone(out.text)
        self.assertIsNone(await svc.open(OWNER, "private", OWNER))

    async def test_store_failures_fail_closed(self):
        class Down(InMemoryLicenseStore):
            async def list_all(self, limit=2000):
                raise RuntimeError("db down")

            async def get(self, group_id):
                raise RuntimeError("db down")

        svc = self.make(licenses=Down())
        for data in (cb(codec.LIST), cb(codec.FILTERS), cb(codec.DETAIL, group_id=A)):
            out = await svc.press(OWNER, "private", OWNER, data, "ar")
            with self.subTest(data):
                self.assertEqual(out.status, "unavailable")
                self.assertIsNone(out.text)

    async def test_large_installations_are_cut_with_a_notice(self):
        await self.s.register(*[-3000 - i for i in range(5)])
        svc = self.make(max_groups=3)
        out = await svc.open(OWNER, "private", OWNER)
        self.assertIn("3", out.text)
        self.assertIn("⚠️", out.text)
        self.assertEqual(len(re.findall(r"<code>-\d+</code>", out.text)), 3)
        full = await self.make(max_groups=5).open(OWNER, "private", OWNER)
        self.assertNotIn("⚠️", full.text)

    async def test_english_texts(self):
        await self.seed()
        out = await self.svc.press(OWNER, "private", OWNER, cb(codec.LIST), "en")
        self.assertIn("Owner panel", out.text)
        self.assertIn("Page 1/1", out.text)


# ----------------------------------------------------------------------------- command parser
class CommandParserTests(unittest.TestCase):
    def test_accepted_forms(self):
        self.assertEqual(parse_owner_command("/owner"), ParsedOwnerCommand(""))
        self.assertEqual(parse_owner_command("/OWNER  alpha  beta ").search, "alpha  beta")
        self.assertEqual(parse_owner_command("/owner@GuardBot x", "guardbot").search, "x")
        self.assertEqual(parse_owner_command("لوحة المالك"), ParsedOwnerCommand(""))
        self.assertEqual(parse_owner_command("  لوحة   المالك  "), ParsedOwnerCommand(""))
        self.assertEqual(parse_owner_command("لوحة المالك الأصدقاء 12").search, "الأصدقاء 12")
        self.assertEqual(parse_owner_command("لـوحه المالك").search, "")

    def test_not_commands(self):
        for text in (None, 5, "", "   ", "owner", "/owners", "/ owner", "//owner", "لوحة", "المالك", "لوحة المالكين", "لوحه التحكم",
                     "قل لوحة المالك", "/owner@other_bot", "/owner@guardbot", "x" * 300, "/panel", "/start"):
            with self.subTest(repr(text)[:30]):
                self.assertIsNone(parse_owner_command(text, None))

    def test_addressed_to_another_bot_is_ignored(self):
        self.assertIsNone(parse_owner_command("/owner@other", "guardbot"))


# ----------------------------------------------------------------------------- aiogram-free glue
class Msg:
    def __init__(self, text, *, chat_id=OWNER, ctype="private", user=OWNER, bot=False, lang="ar", fail=False):
        self.text = text
        self.chat = NS(id=chat_id, type=ctype)
        self.from_user = NS(id=user, is_bot=bot, language_code=lang)
        self.sent = []
        self._fail = fail

    async def answer(self, text, reply_markup=None):
        if self._fail:
            raise RuntimeError("telegram down")
        self.sent.append((text, reply_markup))


class Bot:
    async def me(self):
        return NS(username="GuardBot")


class Query:
    def __init__(self, data, *, chat_id=OWNER, ctype="private", user=OWNER, edit_fails=False, delete_fails=False):
        self.data, self.from_user, self.id = data, NS(id=user, language_code="ar"), "q1"
        self.edits, self.deleted = [], 0
        outer = self

        class M:
            chat = NS(id=chat_id, type=ctype)

            async def edit_text(self, text, reply_markup=None):
                if edit_fails:
                    raise RuntimeError("message is not modified")
                outer.edits.append((text, reply_markup))

            async def delete(self):
                if delete_fails:
                    raise RuntimeError("too old")
                outer.deleted += 1

        self.message = M()


class GlueTests(ServiceBase):
    def services(self, owner_panel="default"):
        return NS(settings=NS(default_language="ar"), owner_panel=self.svc if owner_panel == "default" else owner_panel)

    async def test_match_command_private_text_only(self):
        self.assertEqual(await h.match_command(Msg("/owner"), Bot()), ParsedOwnerCommand(""))
        self.assertEqual((await h.match_command(Msg("/owner@guardbot hi"), Bot())).search, "hi")
        self.assertEqual((await h.match_command(Msg("لوحة المالك hi"), Bot())).search, "hi")
        for msg in (Msg("/owner", ctype="group", chat_id=A), Msg("/owner", ctype="supergroup", chat_id=A),
                    Msg("/owner", bot=True), Msg("hello"), Msg(None), Msg("/owner@other")):
            self.assertIsNone(await h.match_command(msg, Bot()))
        msg = Msg("/owner")
        msg.from_user = None
        self.assertIsNone(await h.match_command(msg, Bot()))

    async def test_execute_sends_the_panel_to_the_owner_only(self):
        await self.seed()
        msg = Msg("/owner")
        self.assertEqual(await h.execute(msg, ParsedOwnerCommand(""), services=self.services(), make_markup=lambda r: r), "list")
        self.assertEqual(len(msg.sent), 1)
        self.assertIn("لوحة المالك", msg.sent[0][0])
        self.assertTrue(msg.sent[0][1])
        stranger = Msg("/owner", chat_id=STRANGER, user=STRANGER)
        self.assertIsNone(await h.execute(stranger, ParsedOwnerCommand(""), services=self.services(), make_markup=lambda r: r))
        self.assertEqual(stranger.sent, [])

    async def test_execute_survives_a_failing_send_a_missing_service_and_a_crashing_service(self):
        await self.seed()
        failing = Msg("/owner", fail=True)
        self.assertEqual(await h.execute(failing, ParsedOwnerCommand(""), services=self.services(), make_markup=lambda r: r), "list")
        self.assertIsNone(await h.execute(Msg("/owner"), ParsedOwnerCommand(""), services=self.services(None), make_markup=lambda r: r))

        class Crash:
            async def open(self, *a, **k):
                raise RuntimeError("x")

        self.assertIsNone(await h.execute(Msg("/owner"), ParsedOwnerCommand(""), services=self.services(Crash()), make_markup=lambda r: r))

    async def test_execute_too_long_search_is_answered_without_buttons(self):
        msg = Msg("/owner " + "x" * 100)
        status = await h.execute(msg, ParsedOwnerCommand("x" * 100), services=self.services(), make_markup=lambda r: r)
        self.assertEqual(status, "query_too_long")
        self.assertEqual(msg.sent[0][1], None)

    async def test_callback_edits_the_panel_in_place(self):
        await self.seed()
        q = Query(cb(codec.DETAIL, group_id=A))
        self.assertEqual(await h.on_owner_callback(q, self.services(), lambda r: r), ("", False))
        self.assertEqual(len(q.edits), 1)
        self.assertIn(str(A), q.edits[0][0])

    async def test_callback_close_deletes_and_search_help_only_toasts(self):
        q = Query(cb(codec.CLOSE))
        await h.on_owner_callback(q, self.services(), lambda r: r)
        self.assertEqual((q.deleted, q.edits), (1, []))
        q = Query(cb(codec.SEARCH_HELP))
        toast, alert = await h.on_owner_callback(q, self.services(), lambda r: r)
        self.assertTrue(alert and "/owner" in toast)
        self.assertEqual((q.deleted, q.edits), (0, []))

    async def test_callback_of_a_non_owner_edits_nothing(self):
        await self.seed()
        q = Query(codec.build(KEY, STRANGER, codec.DETAIL, group_id=A), chat_id=STRANGER, user=STRANGER)
        toast, alert = await h.on_owner_callback(q, self.services(), lambda r: r)
        self.assertTrue(alert and toast)
        self.assertEqual((q.edits, q.deleted), ([], 0))

    async def test_callback_not_ours_in_a_group_or_without_service_is_ignored(self):
        self.assertIsNone(await h.on_owner_callback(Query("pn:1:home:" + "a" * 12), self.services(), lambda r: r))
        self.assertIsNone(await h.on_owner_callback(Query(cb(codec.LIST), ctype="supergroup", chat_id=A), self.services(), lambda r: r))
        self.assertIsNone(await h.on_owner_callback(Query(cb(codec.LIST)), self.services(None), lambda r: r))

    async def test_callback_edit_and_delete_failures_never_raise(self):
        await self.seed()
        q = Query(cb(codec.LIST), edit_fails=True)
        self.assertEqual(await h.on_owner_callback(q, self.services(), lambda r: r), ("", False))
        q = Query(cb(codec.CLOSE), delete_fails=True)
        self.assertEqual(await h.on_owner_callback(q, self.services(), lambda r: r), ("", False))

    async def test_callback_crash_answers_unavailable(self):
        class Crash:
            async def press(self, *a, **k):
                raise RuntimeError("x")

        toast, alert = await h.on_owner_callback(Query(cb(codec.LIST)), self.services(Crash()), lambda r: r)
        self.assertTrue(alert and toast)


# ----------------------------------------------------------------------------- wiring / static guards
class StaticGuardTests(unittest.TestCase):
    def test_the_package_only_reads_except_actions_py(self):
        """5.4: the single file allowed to change anything is `actions.py`, and only through the license admin service."""
        for path in (SRC / "owner_panel").glob("*.py"):
            if path.name == "actions.py":
                continue
            text = path.read_text(encoding="utf-8")
            for forbidden in (".transition(", ".register_pending", "license_admin", "LicenseAdminService", "activate_", ".stop(",
                              ".ban(", ".reject(", ".unban(", ".merge(", "INSERT", "UPDATE ", "DELETE "):
                self.assertNotIn(forbidden, text, (path.name, forbidden))

    def test_every_i18n_key_used_exists_in_both_languages(self):
        used = set()
        for path in list((SRC / "owner_panel").glob("*.py")) + [SRC / "bot" / "owner_panel_handler.py"]:
            used |= set(re.findall(r'\bt\(\s*"(ow_[a-z_]+)"', path.read_text(encoding="utf-8")))
            used |= set(re.findall(r'"(ow_(?:protection_on|protection_off))"', path.read_text(encoding="utf-8")))
        self.assertGreater(len(used), 20)
        for lang in ("ar", "en"):
            self.assertFalse(used - set(MESSAGES[lang]), lang)
        for lang in ("ar", "en"):
            for key in MESSAGES[lang]:
                if key.startswith("ow_btn_"):
                    self.assertLessEqual(len(MESSAGES[lang][key]), 24, key)

    def test_wiring(self):
        self.assertIn("owner_panel", Services.__dataclass_fields__)
        self.assertIsNone(Services.__dataclass_fields__["owner_panel"].default)
        factory = (SRC / "bot" / "factory.py").read_text(encoding="utf-8")
        self.assertIn("dp.include_router(owner_panel.router)", factory)
        app = (SRC / "app.py").read_text(encoding="utf-8")
        # 6.5b: the instance is built once (`owner_panel_service`) because the owner's /stats also needs it (group ids)
        self.assertIn("owner_panel_service = OwnerPanelService(", app)
        self.assertIn("owner_panel=owner_panel_service", app)
        self.assertIn("licenses=license_store", app[app.index("owner_panel_service = OwnerPanelService("):])

    def test_router_is_filter_gated_and_private_only_text(self):
        router = (SRC / "bot" / "routers" / "owner_panel.py").read_text(encoding="utf-8")
        self.assertIn('F.data.startswith("ow:")', router)
        self.assertIn("_is_owner_command", router)
        self.assertNotIn("ReplyKeyboard", router)
        self.assertIn("InlineKeyboardMarkup", router)

    def test_the_panel_never_answers_in_groups(self):
        handler = (SRC / "bot" / "owner_panel_handler.py").read_text(encoding="utf-8")
        self.assertIn('!= "private"', handler)

    def test_no_secret_or_env_content_in_the_panel_texts(self):
        for key, text in MESSAGES["ar"].items():
            if key.startswith("ow_"):
                self.assertNotRegex(text, r"(?i)token|password|DATABASE_URL|\.env")


if __name__ == "__main__":
    unittest.main()
