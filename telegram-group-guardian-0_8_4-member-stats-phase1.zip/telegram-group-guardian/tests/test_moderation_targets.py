import unittest

from guardian.groups.models import GroupRole
from guardian.moderation.targets import (ReplyInfo, Target, TargetError, TargetInput, looks_like_target,
                                         resolve_target, split_target_args)
from guardian.telegram_rights import ChatMemberInfo
from stack import A, B, BACKUP, DELEGATE, OWNER, STRANGER, TG_ADMIN, TG_CREATOR, Stack

BOT, USER, OTHER = 777, 5001, 5002


class Names:
    def __init__(self, table=None, fail=False):
        self.table, self.fail, self.calls = table or {}, fail, []

    async def resolve(self, group_id, username):
        self.calls.append((group_id, username))
        if self.fail:
            raise RuntimeError("down")
        return self.table.get(username)


class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A, B)

    async def go(self, inp, *, group=A, actor=STRANGER, names=None, protected=True):
        return await resolve_target(inp, group_id=group, actor_id=actor, bot_id=BOT, permissions=self.s.perm,
                                    chat_info=self.s.chat, usernames=names, require_unprotected=protected)

    async def code(self, inp, **kw):
        with self.assertRaises(TargetError) as cm:
            await self.go(inp, **kw)
        return cm.exception.code


class SourceTests(Base):
    async def test_reply(self):
        t = await self.go(TargetInput(reply=ReplyInfo(USER)))
        self.assertEqual(t, Target(USER, "reply", "member"))

    async def test_reply_without_user_or_from_channel(self):
        self.assertEqual(await self.code(TargetInput(reply=ReplyInfo(None))), "unresolvable")
        self.assertEqual(await self.code(TargetInput(reply=ReplyInfo(USER, sender_chat=True))), "unresolvable")

    async def test_numeric_id_incl_arabic_digits(self):
        self.assertEqual((await self.go(TargetInput(token="5001"))).user_id, 5001)
        t = await self.go(TargetInput(token="٥٠٠١"))
        self.assertEqual((t.user_id, t.via), (5001, "id"))

    async def test_text_mention(self):
        t = await self.go(TargetInput(token="Ali", mention_user_id=USER))
        self.assertEqual((t.user_id, t.via), (USER, "mention"))

    async def test_username_via_resolver(self):
        names = Names({"ali_user": USER})
        t = await self.go(TargetInput(token="@Ali_User"), names=names)
        self.assertEqual((t.user_id, t.via), (USER, "username"))
        self.assertEqual(names.calls, [(A, "ali_user")])  # lower-cased, '@' stripped, group-scoped

    async def test_username_failures_fail_closed(self):
        self.assertEqual(await self.code(TargetInput(token="@ali_user")), "username_unresolved")  # no resolver
        self.assertEqual(await self.code(TargetInput(token="@nobody1"), names=Names()), "username_unresolved")
        self.assertEqual(await self.code(TargetInput(token="@ali_user"), names=Names(fail=True)), "username_unresolved")
        self.assertEqual(await self.code(TargetInput(token="@chat_x"), names=Names({"chat_x": -100123})), "username_unresolved")

    async def test_format_and_missing(self):
        for tok in ("@ab", "@1abcde", "ali_user", "hello world", "ali!", "-5001", "5001.5", "@" + "a" * 40):
            self.assertEqual(await self.code(TargetInput(token=tok)), "format", tok)
        for tok in (None, "", "  "):
            self.assertEqual(await self.code(TargetInput(token=tok)), "missing")

    async def test_invalid_ids(self):
        for tok in ("0", str(2**63), "9" * 19):
            self.assertEqual(await self.code(TargetInput(token=tok)), "invalid", tok)
        self.assertEqual(await self.code(TargetInput(mention_user_id=-5)), "invalid")


class ValidationTests(Base):
    async def test_self_and_bot(self):
        self.assertEqual(await self.code(TargetInput(reply=ReplyInfo(USER)), actor=USER), "self")
        self.assertEqual(await self.code(TargetInput(token=str(BOT))), "bot")
        self.assertEqual(await self.code(TargetInput(token=str(BOT)), protected=False), "bot")

    async def test_protected_categories(self):
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.MODERATOR)
        for uid in (OWNER, BACKUP, TG_ADMIN, TG_CREATOR, DELEGATE, 777000, 1087968824):
            self.assertEqual(await self.code(TargetInput(token=str(uid))), "protected", uid)

    async def test_non_punitive_allows_protected_and_self(self):
        t = await self.go(TargetInput(token=str(TG_ADMIN)), protected=False)
        self.assertEqual((t.user_id, t.status), (TG_ADMIN, "administrator"))
        self.assertEqual((await self.go(TargetInput(reply=ReplyInfo(USER)), actor=USER, protected=False)).user_id, USER)

    async def test_admin_of_other_group_is_not_protected_here(self):
        self.assertEqual((await self.go(TargetInput(token=str(TG_ADMIN)), group=B)).user_id, TG_ADMIN)

    async def test_lookup_failure_fails_closed(self):
        self.s.chat.fail = True
        self.assertEqual(await self.code(TargetInput(token=str(USER))), "lookup_failed")

    async def test_status_passthrough_and_fresh_lookup(self):
        self.s.chat.set(A, USER, ChatMemberInfo("kicked"))
        self.assertEqual((await self.go(TargetInput(token=str(USER)))).status, "kicked")

    async def test_error_is_invalid_input_without_echo(self):
        with self.assertRaises(TargetError) as cm:
            await self.go(TargetInput(token="secret-token!"))
        self.assertNotIn("secret", str(cm.exception))


class SplitTests(unittest.TestCase):
    def test_without_reply(self):
        self.assertEqual(split_target_args(["5001", "30m", "spam"], None), ("5001", ["30m", "spam"]))
        self.assertEqual(split_target_args([], None), (None, []))

    def test_with_reply_keeps_all_args(self):
        self.assertEqual(split_target_args(["30m", "spam"], ReplyInfo(USER)), (None, ["30m", "spam"]))
        self.assertEqual(split_target_args([], ReplyInfo(USER)), (None, []))

    def test_reply_plus_explicit_target_is_ambiguous(self):
        for first in ("5001", "@ali_user", "٥٠٠١"):
            with self.assertRaises(TargetError) as cm:
                split_target_args([first, "30m"], ReplyInfo(OTHER))
            self.assertEqual(cm.exception.code, "ambiguous")

    def test_reply_with_plain_word_reason_is_not_ambiguous(self):
        for word in ("flooding", "spam1", "ali_user", "اعلانات"):
            self.assertEqual(split_target_args([word], ReplyInfo(USER)), (None, [word]))

    def test_looks_like_target(self):
        self.assertTrue(looks_like_target("@ali_user") and looks_like_target("123"))
        self.assertFalse(any(looks_like_target(x) for x in ("30m", "spam", "", None, "1h")))


if __name__ == "__main__":
    unittest.main()
