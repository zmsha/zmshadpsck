"""Part 8.2 (owner decision): a member who is challenged is welcomed only AFTER passing / being approved.

Same real chain as the phase-4 handoff tests (gate -> middleware -> `members_handler` -> real services) with in-memory stores.
Nothing here proves behaviour against the real aiogram / Telegram."""
from __future__ import annotations

import random
import unittest
from types import SimpleNamespace as NS

from executor_stack import USER
from guardian.bot import members_handler as mh
from guardian.members.verification import APPROVE, REJECT, VerificationService, VerifyOutcome
from guardian.members.welcome import Joined, WelcomeService
from stack import OWNER, STRANGER, TG_ADMIN
import test_phase4_final_handoff as base


def press(g, row_id, value="ok", who=USER, name="Sara"):
    return NS(data=f"vf:{row_id}:{value}", from_user=NS(id=who, full_name=name),
              message=NS(chat=NS(id=g, type="supergroup", title="T")))


class WelcomeAfterVerifyTests(base.MemberBase):
    async def sends(self, g):
        return [c for c in self.actions.calls if c[0] == "send" and c[1] == g]

    async def start(self, **patch):
        g = await self.live_group()
        await self.configure(g, {**base.FULL, **patch})
        await self.join(g)
        row = await self.challenges.get_pending(g, USER)
        return g, row

    async def test_a_challenged_member_is_not_welcomed_on_join_but_the_service_message_is_still_handled(self):
        g, row = await self.start()
        self.assertIsNotNone(row)
        self.assertEqual(len(await self.sends(g)), 1)                      # the challenge prompt only
        self.assertEqual(len(self.actions.names("delete")), 1)            # join_service=delete still runs
        self.assertEqual(self.wtimers, [])

    async def test_a_correct_press_welcomes_exactly_once(self):
        g, row = await self.start()
        out = await mh.on_verify_callback(press(g, row.id), self.services)
        self.assertEqual(out[1], False)
        sends = await self.sends(g)
        self.assertEqual(len(sends), 2)
        self.assertIn("Sara", sends[1][2])
        self.assertIn(f"tg://user?id={USER}", sends[1][2])
        self.assertEqual(len(self.wtimers), 1)                             # welcome_delete_after_seconds applies
        again = await mh.on_verify_callback(press(g, row.id), self.services)  # a second press: the challenge is gone
        self.assertTrue(again[1])
        self.assertEqual(len(await self.sends(g)), 2)

    async def test_the_welcome_claim_is_per_challenge(self):
        g, row = await self.start()
        await mh.on_verify_callback(press(g, row.id), self.services)
        dup = await self.welcome.on_verified(g, Joined(USER, "Sara"), "T", row.id)
        self.assertEqual((dup.welcomed, dup.reason), (False, "duplicate"))
        self.assertEqual(len(await self.sends(g)), 2)

    async def test_two_members_passing_in_the_same_group_are_both_welcomed(self):
        g, row = await self.start()
        await self.join(g, who=5002)
        row2 = await self.challenges.get_pending(g, 5002)
        self.assertIsNotNone(row2)
        await mh.on_verify_callback(press(g, row.id), self.services)
        await mh.on_verify_callback(press(g, row2.id, who=5002, name="Omar"), self.services)
        sends = await self.sends(g)
        self.assertEqual(len(sends), 4)                                    # two prompts + two welcomes
        self.assertIn("tg://user?id=5002", sends[-1][2])                  # the second member, by id
        self.assertIn(f"tg://user?id={USER}", sends[-2][2])

    async def test_only_a_success_outcome_naming_the_member_can_trigger_a_welcome(self):
        g, row = await self.start()
        for kind in ("wrong", "failed", "expired", "not_yours", "gone", "unavailable", "rejected", "not_admin"):
            out = NS(kind=kind, text="x", alert=True, user_id=USER, name="Sara")  # even if a user id were attached
            await mh._welcome_verified(out, self.services, g, USER, press(g, row.id).message, press(g, row.id))
        self.assertEqual(len(await self.sends(g)), 1)
        ok = NS(kind="passed", text="x", alert=False, user_id=None, name="")   # a success without the member: nothing to do
        await mh._welcome_verified(ok, self.services, g, USER, press(g, row.id).message, press(g, row.id))
        self.assertEqual(len(await self.sends(g)), 1)

    async def test_failed_expired_and_rejected_members_are_never_welcomed(self):
        # failed: three wrong answers
        g, row = await self.start()
        for _ in range(3):
            await mh.on_verify_callback(press(g, row.id, "no"), self.services)
        self.assertIsNone(await self.challenges.get_pending(g, USER))
        self.assertEqual(len(await self.sends(g)), 1)
        # expired: the sweep resolves it
        g2, row2 = await self.start()
        self.s.clock.advance(minutes=30)
        await self.verification.sweep()
        self.assertIsNone(await self.challenges.get_pending(g2, USER))
        self.assertEqual(len(await self.sends(g2)), 1)
        # rejected by an admin
        g3, row3 = await self.start(verify_method="admin")
        out = await mh.on_verify_callback(press(g3, row3.id, REJECT, who=TG_ADMIN, name="Admin"), self.services)
        self.assertIsNotNone(out)
        self.assertEqual(len(await self.sends(g3)), 1)
        self.assertEqual(self.wtimers, [])

    async def test_an_admin_approval_welcomes_the_member_by_the_name_remembered_at_join(self):
        g, row = await self.start(verify_method="admin")
        await mh.on_verify_callback(press(g, row.id, APPROVE, who=TG_ADMIN, name="Admin"), self.services)
        sends = await self.sends(g)
        self.assertEqual(len(sends), 2)
        self.assertIn("Sara", sends[1][2])
        self.assertNotIn("Admin", sends[1][2])

    async def test_after_a_restart_the_name_falls_back_to_the_numeric_id_but_the_member_is_still_welcomed(self):
        g, row = await self.start(verify_method="admin")
        self.services.verification = VerificationService(
            self.s.settings_store, self.actions, self.challenges, self.s.license_service, self.s.perm,
            claims=self.claims, clock=self.s.clock, monotonic=lambda: self.mono[0], schedule=lambda d, j: True,
            rng=random.Random(7))
        await mh.on_verify_callback(press(g, row.id, APPROVE, who=TG_ADMIN, name="Admin"), self.services)
        sends = await self.sends(g)
        self.assertEqual(len(sends), 2)
        self.assertIn(f">{USER}</a>", sends[1][2])
        self.assertNotIn("Admin", sends[1][2])

    async def test_welcome_disabled_means_no_welcome_after_the_pass_either(self):
        g, row = await self.start(welcome_enabled=False)
        await mh.on_verify_callback(press(g, row.id), self.services)
        self.assertEqual(len(await self.sends(g)), 1)

    async def test_a_member_who_was_never_challenged_is_welcomed_on_join_as_before(self):
        g = await self.live_group()
        await self.configure(g, {**base.FULL, "verify_enabled": False})
        await self.join(g)
        self.assertEqual(len(await self.sends(g)), 1)
        self.assertEqual(len(self.wtimers), 1)

    async def test_on_verified_re_checks_the_licence_and_the_arguments(self):
        g, row = await self.start()
        await self.s.admin.stop(OWNER, g)
        out = await self.welcome.on_verified(g, Joined(USER, "Sara"), "T", row.id)
        self.assertEqual((out.welcomed, out.reason), (False, "not_allowed"))
        for bad in ((0, Joined(USER, "S"), 1), (g, Joined(USER, "S", True), 1), (g, Joined(-5, "S"), 1),
                    (g, Joined(USER, "S"), 0), (g, "Sara", 1)):
            res = await self.welcome.on_verified(bad[0], bad[1], "T", bad[2])
            self.assertFalse(res.welcomed)
        self.assertEqual(len(await self.sends(g)), 1)

    async def test_a_welcome_send_failure_or_a_crash_never_breaks_the_callback_answer(self):
        g, row = await self.start()

        async def boom(*a, **k):
            raise RuntimeError("welcome down")
        self.welcome.on_verified = boom
        out = await mh.on_verify_callback(press(g, row.id), self.services)
        self.assertEqual(out[1], False)                                    # the member still gets the success toast

    async def test_a_press_by_a_stranger_never_welcomes_anybody(self):
        g, row = await self.start()
        out = await mh.on_verify_callback(press(g, row.id, who=STRANGER), self.services)
        self.assertTrue(out[1])
        self.assertEqual(len(await self.sends(g)), 1)


class JoinHandlerFilterTests(unittest.IsolatedAsyncioTestCase):
    """`on_new_members` hands the welcome service only the members that were NOT held back by verification."""

    async def run_join(self, verification):
        seen = {}

        class W:
            async def on_join(self, ctx, mid, joined, title):
                seen["joined"] = [m.user_id for m in joined]

        msg = NS(message_id=9, chat=NS(title="G"), new_chat_members=[
            NS(id=1, full_name="A", is_bot=False), NS(id=2, full_name="B", is_bot=False), NS(id=3, full_name="C", is_bot=True)])
        ctx = NS(allowed=True, chat_id=-100)
        await mh.on_new_members(msg, ctx, NS(verification=verification, welcome=W()))
        return seen["joined"]

    async def test_challenged_and_enforced_members_are_held_back(self):
        class V:
            async def on_join(self, *a): return VerifyOutcome(challenged=(1,), enforced=(2,))
        self.assertEqual(await self.run_join(V()), [3])

    async def test_nothing_held_back_when_verification_did_nothing_or_failed(self):
        class V0:
            async def on_join(self, *a): return VerifyOutcome(reason="disabled")

        class V1:
            async def on_join(self, *a): raise RuntimeError("x")

        class V2:
            async def on_join(self, *a): return None
        for v in (V0(), V1(), V2(), None):
            self.assertEqual(await self.run_join(v), [1, 2, 3])

    async def test_junk_ids_in_the_outcome_are_ignored(self):
        class V:
            async def on_join(self, *a): return VerifyOutcome(challenged=(True, "1"), enforced=())  # type: ignore[arg-type]
        self.assertEqual(await self.run_join(V()), [1, 2, 3])


if __name__ == "__main__":
    unittest.main()
