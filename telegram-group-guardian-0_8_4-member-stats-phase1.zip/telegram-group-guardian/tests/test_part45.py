"""Phase 4 / part 5: suspicious-only scope, admin approval, anti-rejoin, and the newcomer restriction window."""
import unittest
from datetime import timedelta
from types import SimpleNamespace as NS

from guardian.bot import members_handler as h
from guardian.bot.actions import AiogramModerationActions
from guardian.bot.middlewares import ProtectionGateMiddleware
from guardian.members import verification as v
from guardian.members.models import ChallengeStatus
from guardian.members.newcomers import NewcomerService, NewcomerTracker
from guardian.members.welcome import Joined
from guardian.protection.engine import MessageView, OutcomeKind, ProtectionEngine
from stack import A, B, OWNER, STRANGER, TG_ADMIN, DELEGATE, Stack
from test_protection_engine import Base as EngineBase
from test_verification import Base, U1, U2, FakeActions

MOD = 930_001  # delegated moderator


class SuspiciousScopeTests(Base):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        await self.enable(verify_scope="suspicious")

    def full(self, uid=U1, name="Sara"):
        return Joined(uid, name, False, f"user{uid}")

    async def test_ordinary_member_is_left_alone_and_costs_one_photo_lookup(self):
        out = await self.join((self.full(),))
        self.assertEqual((out.challenged, out.reason, self.act.calls), ((), "nothing_to_do", []))
        self.assertEqual(self.act.photo_calls, [U1])

    async def test_no_username_is_suspicious_without_a_photo_lookup(self):
        out = await self.join((Joined(U1, "x"),))
        self.assertEqual(out.challenged, (U1,))
        self.assertEqual(self.act.photo_calls, [])

    async def test_no_photo_is_suspicious(self):
        self.act.photos[U1] = False
        self.assertEqual((await self.join((self.full(),))).challenged, (U1,))

    async def test_unknown_photo_is_not_a_signal(self):
        self.act.photos[U1] = None
        self.assertEqual((await self.join((self.full(),))).challenged, ())

    async def test_photo_lookup_crash_is_not_a_signal(self):
        async def boom(uid): raise RuntimeError("x")
        self.act.has_profile_photo = boom
        self.assertEqual((await self.join((self.full(),))).challenged, ())

    async def test_join_wave_makes_everyone_from_the_fifth_suspicious(self):
        got = []
        for i in range(v.WAVE_COUNT + 1):
            out = await self.join((self.full(7000 + i),))
            got.append(bool(out.challenged))
        self.assertEqual(got, [False] * (v.WAVE_COUNT - 1) + [True, True])

    async def test_wave_expires_with_the_window(self):
        for i in range(v.WAVE_COUNT):
            await self.join((self.full(7000 + i),))
        self.mono[0] += 100
        self.assertEqual((await self.join((self.full(7099),))).challenged, (7099,))
        self.mono[0] += 100
        self.assertEqual((await self.join((self.full(7100),))).challenged, ())

    async def test_wave_is_per_group(self):
        await self.enable(B, verify_scope="suspicious")
        for i in range(v.WAVE_COUNT - 1):
            await self.join((self.full(7000 + i),), group=B)
        self.assertEqual((await self.join((self.full(7100),), group=A)).challenged, ())

    async def test_exempt_still_exempt_when_suspicious(self):
        self.assertEqual((await self.join((Joined(TG_ADMIN, "a"),))).challenged, ())

    async def test_signals_are_named(self):
        self.act.photos[U1] = False
        self.assertEqual(await self.svc.suspicion_signals(self.full(), True), ("no_photo", "wave"))
        self.assertEqual(await self.svc.suspicion_signals(Joined(U1, "x", False, ""), False), ("no_username",))


class AdminApprovalTests(Base):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        await self.enable(verify_method="admin", verify_failure="kick")
        await self.s.delegations.add(OWNER, A, MOD, "moderator", context_chat_id=A) if hasattr(self.s.delegations, "add") else None
        await self.join()
        self.row = await self.pending()

    async def test_prompt_has_approve_and_reject_buttons_and_no_answer(self):
        self.assertIsNone(self.row.answer)
        buttons = self.act.names("send")[0][3]
        self.assertEqual([c[0] for c in buttons[0]], ["✅ موافقة", "⛔ رفض"])
        self.assertEqual([c[1] for c in buttons[0]], [f"vf:{self.row.id}:ap", f"vf:{self.row.id}:rj"])
        self.assertIn("موافقة أحد المشرفين", self.act.names("send")[0][2])

    async def test_telegram_admin_approves_and_member_is_unmuted(self):
        out = await self.svc.answer(A, self.row.id, TG_ADMIN, "ap")
        self.assertEqual(out.kind, "approved")
        done = await self.store.get(A, self.row.id)
        self.assertEqual((done.status, done.resolved_by), (ChallengeStatus.APPROVED, TG_ADMIN))
        self.assertEqual(self.act.names("unmute"), [("unmute", A, U1)])

    async def test_owner_can_reject_and_failure_action_applies(self):
        out = await self.svc.answer(A, self.row.id, OWNER, "rj")
        self.assertEqual(out.kind, "rejected")
        done = await self.store.get(A, self.row.id)
        self.assertEqual((done.status, done.resolved_by), (ChallengeStatus.REJECTED, OWNER))
        self.assertEqual(self.act.names("kick"), [("kick", A, U1)])

    async def test_ordinary_member_other_user_and_the_member_cannot_decide(self):
        for presser in (U2, U1, STRANGER):
            out = await self.svc.answer(A, self.row.id, presser, "ap")
            self.assertEqual((out.kind, out.alert), ("not_admin", True))
        self.assertTrue((await self.store.get(A, self.row.id)).is_pending)
        self.assertEqual(self.act.names("unmute"), [])

    async def test_admin_of_another_group_cannot_decide(self):
        # TG_CREATOR is creator of A and B; OWNER is global. A plain admin of B only:
        from guardian.telegram_rights import ChatMemberInfo
        self.s.chat.set(B, 940_001, ChatMemberInfo("administrator", True, True, True))
        out = await self.svc.answer(A, self.row.id, 940_001, "ap")
        self.assertEqual(out.kind, "not_admin")

    async def test_button_in_another_group_is_unreachable(self):
        self.assertEqual((await self.svc.answer(B, self.row.id, OWNER, "ap")).kind, "gone")

    async def test_member_promoted_to_admin_still_cannot_approve_themselves(self):
        from guardian.telegram_rights import ChatMemberInfo
        self.s.chat.set(A, U1, ChatMemberInfo("administrator", True, True, True))
        self.assertEqual((await self.svc.answer(A, self.row.id, U1, "ap")).kind, "not_admin")
        self.assertTrue((await self.store.get(A, self.row.id)).is_pending)

    async def test_garbage_value_is_gone(self):
        self.assertEqual((await self.svc.answer(A, self.row.id, OWNER, "ok")).kind, "gone")

    async def test_two_admins_racing_only_one_wins(self):
        a = await self.svc.answer(A, self.row.id, OWNER, "ap")
        b = await self.svc.answer(A, self.row.id, TG_ADMIN, "rj")
        self.assertEqual((a.kind, b.kind), ("approved", "gone"))
        self.assertEqual(self.act.names("kick"), [])

    async def test_late_press_expires_it(self):
        self.s.clock.advance(seconds=301)
        self.assertEqual((await self.svc.answer(A, self.row.id, OWNER, "ap")).kind, "expired")
        self.assertEqual(len(self.act.names("kick")), 1)

    async def test_no_decision_means_timeout_failure_action(self):
        self.s.clock.advance(hours=1)
        await self.svc.sweep()
        self.assertEqual(len(self.act.names("kick")), 1)

    async def test_license_stopped_blocks_the_admin_too(self):
        await self.s.admin.stop(OWNER, A)
        self.assertEqual((await self.svc.answer(A, self.row.id, OWNER, "ap")).kind, "unavailable")
        self.assertEqual(self.act.names("unmute"), [])

    async def test_permission_lookup_failure_decides_nothing(self):
        async def boom(*a, **k): raise RuntimeError("x")
        self.svc._perm.check = boom
        self.assertEqual((await self.svc.answer(A, self.row.id, OWNER, "ap")).kind, "unavailable")
        self.assertTrue((await self.store.get(A, self.row.id)).is_pending)

    async def test_callback_handler_routes_admin_press_by_real_presser(self):
        q = NS(data=f"vf:{self.row.id}:ap", from_user=NS(id=U2), message=NS(chat=NS(id=A, type="supergroup")))
        res = await h.on_verify_callback(q, NS(verification=self.svc))
        self.assertEqual(res, ("للمشرفين فقط", True))


class RejoinTests(Base):
    async def failed_once(self, **patch):
        await self.enable(verify_method="math", verify_max_attempts=1, **patch)
        await self.join(mid=1)
        row = await self.pending()
        wrong = next(str(n) for n in range(30) if str(n) != row.answer)
        await self.svc.answer(A, row.id, U1, wrong)
        self.act.calls.clear()

    async def test_restrict_rejoin_is_muted_again_without_a_new_challenge(self):
        await self.failed_once(verify_failure="restrict")
        out = await self.join(mid=2)
        self.assertEqual((out.challenged, out.enforced), ((), (U1,)))
        self.assertEqual(self.act.calls, [("mute", A, U1, None)])
        self.assertIsNone(await self.pending())

    async def test_kick_rejoin_is_kicked_again(self):
        await self.failed_once(verify_failure="kick")
        await self.join(mid=2)
        self.assertEqual(self.act.calls, [("kick", A, U1)])

    async def test_ban_rejoin_gets_a_temporary_ban(self):
        await self.failed_once(verify_failure="ban", verify_ban_seconds=600)
        await self.join(mid=2)
        self.assertEqual(self.act.calls, [("ban", A, U1, self.s.clock() + timedelta(seconds=600))])

    async def test_redelivered_rejoin_acts_once(self):
        await self.failed_once(verify_failure="kick")
        await self.join(mid=2)
        await self.join(mid=2)
        self.assertEqual(len(self.act.names("kick")), 1)

    async def test_expired_challenge_counts_too(self):
        await self.enable(verify_failure="kick")
        await self.join(mid=1)
        self.s.clock.advance(hours=1)
        await self.svc.sweep()
        self.act.calls.clear()
        await self.join(mid=2)
        self.assertEqual(len(self.act.names("kick")), 1)

    async def test_window_ends(self):
        await self.failed_once(verify_failure="kick")
        self.s.clock.advance(hours=5)
        self.assertEqual((await self.join(mid=2)).enforced, (U1,))   # still inside 6 h
        self.s.clock.advance(hours=1, seconds=5)
        out = await self.join(mid=3)
        self.assertEqual((out.challenged, out.enforced), ((U1,), ()))

    async def test_passed_member_rejoining_gets_a_normal_challenge(self):
        await self.enable()
        await self.join(mid=1)
        row = await self.pending()
        await self.svc.answer(A, row.id, U1, "ok")
        self.assertEqual((await self.join(mid=2)).challenged, (U1,))

    async def test_failure_in_another_group_does_not_count(self):
        await self.enable(B)
        await self.failed_once(verify_failure="kick")
        self.assertEqual((await self.join(group=B, mid=9)).challenged, (U1,))

    async def test_dry_run_and_exempt_never_enforced(self):
        await self.failed_once(verify_failure="kick")
        await self.cfg(dry_run=True)
        self.assertEqual((await self.join(mid=2)).reason, "dry_run")
        await self.cfg(dry_run=False)
        await self.s.trust.add(OWNER, A, U1, context_chat_id=A)
        await self.join(mid=3)
        self.assertEqual(self.act.calls, [])

    async def test_history_failure_falls_back_to_a_fresh_challenge(self):
        await self.failed_once(verify_failure="kick")
        async def boom(*a, **k): raise RuntimeError("db")
        self.store.recent_unsuccessful = boom
        self.assertEqual((await self.join(mid=4)).challenged, (U1,))

    async def test_claim_failure_enforces_nothing(self):
        await self.failed_once(verify_failure="kick")
        async def boom(*a, **k): raise RuntimeError("db")
        self.svc._claims.claim = boom
        out = await self.join(mid=5)
        self.assertEqual((out.enforced, self.act.calls), ((), []))

    async def test_rejoin_scope_suspicious_still_enforced_for_ordinary_member(self):
        await self.failed_once(verify_failure="kick")
        await self.cfg(verify_scope="suspicious")
        await self.join((Joined(U1, "Sara", False, "sara"),), mid=6)
        self.assertEqual(len(self.act.names("kick")), 1)


class NewcomerEngineTests(EngineBase):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.tracker = NewcomerTracker()
        self.engine = ProtectionEngine(self.s.settings_store, self.actions, self.s.chat, self.claims, self.s.audit,
                                       self.notifier, clock=self.s.clock, newcomers=self.tracker)
        self.svc = NewcomerService(self.s.settings_store, self.s.perm, self.tracker, clock=self.s.clock)
        await self.cfg(links_enabled=False)  # isolate the newcomer rule from the link rule

    async def joined(self, user=STRANGER, group=A, members=None):
        ctx = await self.gate.evaluate(group, "supergroup", user)
        return await self.svc.on_join(ctx, members or [Joined(user, "n")])

    async def msg(self, text="hi", media=False, edit=False, user=STRANGER, group=A, advance=0.0):
        if advance:
            self.s.clock.advance(seconds=advance)
        self.mid += 1
        ctx = await self.gate.evaluate(group, "supergroup", user)
        return await self.engine.handle(ctx, MessageView(group, user, self.mid, text, (), edit, False, None, media),
                                        self.s.clock())

    async def test_off_by_default(self):
        self.assertEqual(await self.joined(), 0)
        self.assertEqual((await self.msg("https://evil.example")).kind, OutcomeKind.NONE)

    async def test_link_inside_window_is_deleted_without_mute_then_allowed_after(self):
        await self.cfg(newbie_seconds=600)
        self.assertEqual(await self.joined(), 1)
        o = await self.msg("see https://evil.example/x")
        self.assertEqual((o.kind, o.violation, o.deleted, o.muted_seconds), (OutcomeKind.ACTED, "newbie", True, None))
        self.assertEqual(self.actions.muted, [])
        self.assertEqual((await self.msg("plain text")).kind, OutcomeKind.NONE)   # messages are allowed by default
        o2 = await self.msg("https://evil.example", advance=601)
        self.assertEqual(o2.kind, OutcomeKind.NONE)

    async def test_link_rule_outranks_the_newcomer_rule(self):
        await self.cfg(newbie_seconds=600, links_enabled=True)
        await self.joined()
        o = await self.msg("https://evil.example")
        self.assertEqual((o.violation, o.muted_seconds), ("links", 600))

    async def test_window_boundary_is_exact(self):
        await self.cfg(newbie_seconds=600)
        await self.joined()
        self.assertEqual((await self.msg("https://evil.example", advance=599)).violation, "newbie")
        self.assertEqual((await self.msg("https://evil.example", advance=1)).kind, OutcomeKind.NONE)

    async def test_media_blocked_and_text_allowed(self):
        await self.cfg(newbie_seconds=600)
        await self.joined()
        self.assertEqual((await self.msg("", media=True)).violation, "newbie")
        self.assertEqual((await self.msg("hello")).kind, OutcomeKind.NONE)

    async def test_media_and_link_switches_are_independent(self):
        await self.cfg(newbie_seconds=600, newbie_block_media=False, newbie_block_links=False)
        await self.joined()
        self.assertEqual((await self.msg("https://evil.example", media=True)).kind, OutcomeKind.NONE)

    async def test_block_messages_silences_the_newcomer_but_not_edits_of_nothing(self):
        await self.cfg(newbie_seconds=600, newbie_block_messages=True)
        await self.joined()
        self.assertEqual((await self.msg("hello")).violation, "newbie")
        self.assertEqual((await self.msg("hello again", edit=True)).kind, OutcomeKind.NONE)

    async def test_edit_adding_a_link_is_caught(self):
        await self.cfg(newbie_seconds=600)
        await self.joined()
        self.assertEqual((await self.msg("https://evil.example", edit=True)).violation, "newbie")

    async def test_allow_list_is_honoured(self):
        await self.cfg(newbie_seconds=600, links_allow_domains=["good.example"])
        await self.joined()
        self.assertEqual((await self.msg("https://good.example/a")).kind, OutcomeKind.NONE)
        self.assertEqual((await self.msg("https://evil.example/a")).violation, "newbie")

    async def test_non_joined_member_is_unrestricted(self):
        await self.cfg(newbie_seconds=600)
        self.assertEqual((await self.msg("https://evil.example")).kind, OutcomeKind.NONE)

    async def test_trusted_exempt_and_bot_joins_are_not_tracked(self):
        await self.cfg(newbie_seconds=600)
        await self.s.trust.add(OWNER, A, 910_009, context_chat_id=A)
        ctx = await self.gate.evaluate(A, "supergroup", STRANGER)
        n = await self.svc.on_join(ctx, [Joined(910_009, "t"), Joined(TG_ADMIN, "a"), Joined(OWNER, "o"),
                                         Joined(990, "b", True), Joined(-3, "bad")])
        self.assertEqual(n, 0)

    async def test_member_trusted_after_joining_skips_the_window(self):
        await self.cfg(newbie_seconds=600)
        await self.joined()
        await self.s.trust.add(OWNER, A, STRANGER, context_chat_id=A)
        self.assertEqual((await self.msg("https://evil.example")).kind, OutcomeKind.NONE)

    async def test_license_stopped_tracks_nothing_and_blocks_engine(self):
        await self.cfg(newbie_seconds=600)
        await self.s.admin.stop(OWNER, A)
        self.assertEqual(await self.joined(), 0)
        self.assertEqual((await self.msg("https://evil.example")).kind, OutcomeKind.NONE)

    async def test_groups_are_isolated(self):
        await self.s.admin.activate_permanent(OWNER, B)
        await self.cfg(newbie_seconds=600)
        await self.cfg(B, newbie_seconds=600, links_enabled=False)
        await self.joined(group=A)
        self.assertEqual((await self.msg("https://evil.example", group=B)).kind, OutcomeKind.NONE)

    async def test_policy_off_stops_the_restriction(self):
        await self.cfg(newbie_seconds=600)
        await self.joined()
        await self.cfg(newbie_seconds=0)
        self.assertEqual((await self.msg("https://evil.example")).kind, OutcomeKind.NONE)

    async def test_dry_run_deletes_nothing(self):
        await self.cfg(newbie_seconds=600, dry_run=True)
        await self.joined()
        o = await self.msg("https://evil.example")
        self.assertEqual((o.kind, self.actions.deleted), (OutcomeKind.DRY_RUN, []))

    async def test_settings_failure_means_no_restriction(self):
        await self.cfg(newbie_seconds=600)
        await self.joined()
        real = self.s.settings_store.get
        calls = []
        async def flaky(g):
            calls.append(1)
            if len(calls) > 1:   # the engine's first read works, the newcomer policy read fails
                raise RuntimeError("db")
            return await real(g)
        self.s.settings_store.get = flaky
        self.assertEqual((await self.msg("https://evil.example")).kind, OutcomeKind.NONE)

    async def test_tracker_is_bounded(self):
        t = NewcomerTracker(max_entries=3)
        for i in range(1, 6):
            t.record(A, i, self.s.clock())
        self.assertEqual((t.joined_at(A, 1), t.joined_at(A, 2)), (None, None))
        self.assertIsNotNone(t.joined_at(A, 5))

    async def test_handler_tracks_newcomers_when_verification_is_absent(self):
        await self.cfg(newbie_seconds=600)
        ctx = await self.gate.evaluate(A, "supergroup", STRANGER)
        msg = NS(message_id=3, chat=NS(title="G"), new_chat_members=[NS(id=STRANGER, full_name="S", is_bot=False, username="s")])
        await h.on_new_members(msg, ctx, NS(verification=None, welcome=None, newcomers=self.svc))
        self.assertIsNotNone(self.tracker.joined_at(A, STRANGER))

    async def test_middleware_marks_media_messages(self):
        seen = []
        class Eng:
            async def handle(self, ctx, view):
                seen.append(view.has_media)
                return NS(consumed=False)
        class Gate:
            async def evaluate(self, *a, **k):
                from guardian.protection_gate import ProtectionContext
                return ProtectionContext(A, "supergroup", True, "none", 5, False)
        async def handler(e, d): return None
        mw = ProtectionGateMiddleware(Gate(), Eng())
        base = dict(chat=NS(id=A, type="supergroup"), from_user=NS(id=5), sender_chat=None, message_id=1, text=None)
        for ctype in ("photo", "text", "new_chat_members"):
            await mw(handler, NS(content_type=ctype, **base), {})
        self.assertEqual(seen, [True, False, False])


class PhotoAdapterTests(unittest.IsolatedAsyncioTestCase):
    async def test_has_profile_photo(self):
        class Bot:
            def __init__(self): self.total = 2; self.err = None
            async def get_user_profile_photos(self, user_id, *, limit=None):
                if self.err: raise self.err
                return NS(total_count=self.total)
        bot = Bot(); act = AiogramModerationActions(bot)
        self.assertIs(await act.has_profile_photo(5), True)
        bot.total = 0
        self.assertIs(await act.has_profile_photo(5), False)
        bot.total = "x"
        self.assertIsNone(await act.has_profile_photo(5))
        bot.err = RuntimeError("boom")
        self.assertIsNone(await act.has_profile_photo(5))
        self.assertIsNone(await act.has_profile_photo(-5))


if __name__ == "__main__":
    unittest.main()
