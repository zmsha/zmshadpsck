"""Part 8.3: README and TROUBLESHOOTING match the real code (commands, variables, links, honesty statements).

Text-only checks. They do NOT prove that Telegram/PostgreSQL/Render behave as documented.
"""
from __future__ import annotations

import re
import unittest
from pathlib import Path

from guardian.bot.commands_menu import BASIC
from guardian.licensing.commands import _SLASH as LICENSE_SLASH
from guardian.moderation.commands import Command

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src" / "guardian"
README = (ROOT / "README.md").read_text(encoding="utf-8")
TROUBLE = (ROOT / "docs" / "TROUBLESHOOTING.md").read_text(encoding="utf-8")

# owner-side slash commands: each name must appear as a string literal in the parser that owns it
OWNER_PARSERS = {
    "owner": "owner_panel/command.py",
    "template": "owner_panel/template_commands.py",
    "templates": "owner_panel/template_commands.py",
    "defaults": "owner_panel/template_commands.py",
    "defaultword": "owner_panel/default_words_commands.py",
    "defaultwords": "owner_panel/default_words_commands.py",
    "sandbox": "owner_panel/sandbox_commands.py",
    "backup": "backup/command.py",
    "restore": "backup/restore_command.py",
    "commands": "bot/routers/basic.py",   # public: the English twin of `الاوامر` (registered by aiogram's Command filter)
    "apicheck": "owner_panel/api_check_commands.py",
    "apis": "owner_panel/api_check_commands.py",
    "userstats": "member_stats/commands.py",
    "topmembers": "member_stats/commands.py",
    "groupstats": "member_stats/commands.py",
}


# `/x` spans in the README that are NOT commands of this bot: an HTTP route and BotFather's own command
NOT_BOT_COMMANDS = {"health": "HTTP route", "newbot": "BotFather command"}


def slash_names(text: str) -> set[str]:
    """First word of every inline-code span that starts with `/` (``/ban``, ``/report show|take`` ...)."""
    names = set()
    for span in re.findall(r"`(/[^`]+)`", text):
        m = re.match(r"/([A-Za-z]+)", span)
        if m:
            names.add(m.group(1).lower())
    return names


class CommandsMatchTheParsers(unittest.TestCase):
    def test_every_slash_command_in_the_readme_is_real(self):
        known = {c.value for c in Command} | set(BASIC) | set(LICENSE_SLASH)
        for name in slash_names(README) - known - set(NOT_BOT_COMMANDS):
            with self.subTest(command=name):
                self.assertIn(name, OWNER_PARSERS, f"/{name} is documented but no parser is known for it")
                source = (SRC / OWNER_PARSERS[name]).read_text(encoding="utf-8")
                self.assertRegex(source, r"[\"']%s[\"']" % name)

    def test_the_two_exemptions_are_what_they_claim(self):
        self.assertIn('"/health"', (SRC / "app.py").read_text(encoding="utf-8"))
        self.assertIn("/newbot", README)
        self.assertIn("BotFather", README)

    def test_every_moderation_command_is_documented(self):
        documented = slash_names(README)
        for cmd in Command:
            with self.subTest(command=cmd.value):
                self.assertIn(cmd.value, documented)

    def test_every_owner_command_is_documented(self):
        documented = slash_names(README)
        for name in OWNER_PARSERS:
            with self.subTest(command=name):
                self.assertIn(name, documented)

    def test_basic_and_license_commands_are_documented(self):
        documented = slash_names(README)
        for name in set(BASIC) | set(LICENSE_SLASH):
            with self.subTest(command=name):
                self.assertIn(name, documented)

    def test_documented_arabic_license_commands_parse(self):
        from guardian.licensing.commands import LicenseCommand, parse_license_command
        for text, expected in (("تفعيل البوت", LicenseCommand.ACTIVATE), ("تفعيل البوت 3 أيام", LicenseCommand.ACTIVATE),
                               ("تفعيل البوت شهر", LicenseCommand.ACTIVATE), ("تفعيل البوت 2 week", LicenseCommand.ACTIVATE),
                               ("إيقاف البوت", LicenseCommand.STOP), ("حالة البوت", LicenseCommand.STATUS)):
            with self.subTest(text=text):
                parsed = parse_license_command(text)
                self.assertIsNotNone(parsed)
                self.assertEqual(parsed.command, expected)
        for phrase in ("تفعيل البوت 3 أيام", "إيقاف البوت", "حالة البوت"):
            self.assertIn(phrase, README)

    def test_documented_license_durations_parse_and_the_moderation_ones_do_not(self):
        from guardian.licensing.duration_parser import DurationParseError, parse_duration
        for ok in ("3 أيام", "شهر", "2 week"):
            parse_duration(ok)
        for bad in ("7d", "2h"):
            with self.assertRaises(DurationParseError):
                parse_duration(bad)
        self.assertIn("`7d` و`2h` **ليستا** صيغ ترخيص", TROUBLE)

    def test_documented_arabic_owner_panel_phrase_parses(self):
        from guardian.owner_panel.command import parse_owner_command
        self.assertIsNotNone(parse_owner_command("لوحة المالك"))


class EnvironmentVariables(unittest.TestCase):
    def test_every_variable_of_env_example_is_in_the_readme_table(self):
        names = set(re.findall(r"(?m)^#?\s*([A-Z][A-Z0-9_]+)=", (ROOT / ".env.example").read_text(encoding="utf-8")))
        self.assertGreaterEqual(len(names), 15)
        for name in names:
            with self.subTest(variable=name):
                self.assertIn(f"`{name}`", README)

    def test_every_variable_the_config_reads_is_documented(self):
        source = (SRC / "config.py").read_text(encoding="utf-8")
        for name in set(re.findall(r"\"([A-Z][A-Z0-9_]{3,})\"", source)):
            if name in {"BOT_TOKEN", "DATABASE_URL", "OWNER_TELEGRAM_ID", "WEBHOOK_SECRET"} or "_" in name:
                with self.subTest(variable=name):
                    if name in {"RENDER_EXTERNAL_URL"}:
                        continue
                    self.assertIn(name, README)


class LinksAndStructure(unittest.TestCase):
    def test_every_documented_file_exists(self):
        for text in (README, TROUBLE):
            for path in re.findall(r"`((?:docs/)?[A-Za-z0-9_]+\.(?:md|yaml|txt|example))`", text):
                with self.subTest(path=path):
                    self.assertTrue((ROOT / path).exists() or (ROOT / "docs" / path).exists(), path)

    def test_troubleshooting_covers_the_required_symptoms(self):
        headings = re.findall(r"(?m)^## .+$", TROUBLE)
        for needle in ("البوت لا يردّ", "pending", "403", "قاعدة البيانات غير متاحة", "ملفات التصدير",
                       "فشلت الاستعادة", "النوم"):
            with self.subTest(heading=needle):
                self.assertTrue(any(needle in h for h in headings), f"no section heading mentions {needle}")

    def test_the_restore_codes_pointer_matches_a_real_heading(self):
        self.assertIn("مرجع سريع للأكواد المغلقة", (ROOT / "docs" / "BACKUP_RESTORE.md").read_text(encoding="utf-8"))
        self.assertIn("مرجع سريع للأكواد المغلقة", TROUBLE)

    def test_the_readme_has_an_english_summary_and_a_limits_section(self):
        self.assertIn("## English summary", README)
        self.assertIn("## 13. القيود المعروفة", README)


class HonestyStatements(unittest.TestCase):
    def test_the_decided_limits_are_stated_in_the_limits_section(self):
        limits = README.split("## 13. القيود المعروفة")[1].split("## 14.")[0]
        for needle in ("الشهر = **30 يومًا**", "`dry_run`", "أوامر الإشراف فقط", "`license_audit_log` بلا `trace_id`",
                       "لم يُجرَّب على الحقيقي"):
            with self.subTest(needle=needle):
                self.assertIn(needle, limits)

    def test_no_claim_of_deployment_or_a_real_run(self):
        self.assertIn("لم يُنشَر شيء", README)
        self.assertIn("Nothing has been run against real Telegram", README)
        for forbidden in ("تم النشر", "نُشر بنجاح", "جُرِّب على Telegram الحقيقي", "deployed successfully"):
            self.assertNotIn(forbidden, README + TROUBLE)

    def test_the_endpoint_codes_documented_match_the_app(self):
        app = (SRC / "app.py").read_text(encoding="utf-8")
        for code in ("403", "400"):
            self.assertIn(f"status_code={code}", app)
            self.assertIn(code, TROUBLE)
        self.assertIn("X-Telegram-Bot-Api-Secret-Token", TROUBLE)
        self.assertIn("X-Telegram-Bot-Api-Secret-Token", (SRC / "webhook.py").read_text(encoding="utf-8"))

    def test_the_documented_export_and_backup_cooldowns_match_the_code(self):
        self.assertRegex((SRC / "backup/service.py").read_text(encoding="utf-8"), r"300")
        self.assertIn("300 ثانية", TROUBLE)
        self.assertIn("30 ثانية", TROUBLE)


if __name__ == "__main__":
    unittest.main()
