"""Closing part 3: bot-enforced slow mode inside ProtectionEngine (+ service-message guard in the middleware)."""
from __future__ import annotations

import unittest
from types import SimpleNamespace as NS

from guardian.bot.middlewares import ProtectionGateMiddleware, _is_service
from guardian.protection.engine import ActionResult, MessageView, OutcomeKind
from guardian.protection.tracking import LastSeen
from guardian.telegram_rights import ChatMemberInfo
from stack import A, B, DELEGATE, OWNER, STRANGER, TG_ADMIN
from test_protection_engine import BOT, Base
from guardian.groups.models import GroupRole

OTHER = 900_777


class SlowmodeTests(Base):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        await self.cfg(slowmode_seconds=30)

    async def test_too_fast_message_is_deleted_without_any_mute_or_offense(self):
        self.assertEqual((await self.send("one")).kind, OutcomeKind.NONE)
        o = await self.send("two", advance=10)
        self.assertEqual((o.kind, o.violation, o.deleted, o.muted_seconds), (OutcomeKind.ACTED, "slowmode", True, None))
        self.assertEqual(self.actions.deleted, [(A, 2)])
        self.assertEqual(self.actions.muted, [])
        self.assertIn("auto_sanction", [e.event_type for e in self.s.audit.events])

    async def test_a_deleted_message_does_not_restart_the_interval(self):
        await self.send("a")                         # accepted at t=0
        self.assertEqual((await self.send("b", advance=10)).violation, "slowmode")   # t=10, deleted
        o = await self.send("c", advance=21)         # t=31: 31 s after the last ACCEPTED one
        self.assertEqual(o.kind, OutcomeKind.NONE)
        self.assertEqual((await self.send("d", advance=5)).violation, "slowmode")    # restarted at t=31

    async def test_exact_boundary_is_allowed(self):
        await self.send("a")
        self.assertEqual((await self.send("b", advance=30)).kind, OutcomeKind.NONE)

    async def test_off_by_default_and_for_invalid_values(self):
        for value in (0, 4, 99999, "30", True):
            await self.cfg(slowmode_seconds=value)
            await self.send("x", user=OTHER)
            self.assertEqual((await self.send("y", user=OTHER, advance=1)).kind, OutcomeKind.NONE, value)

    async def test_exempt_people_are_never_touched(self):
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.MODERATOR)
        await self.s.trust.add(OWNER, A, OTHER)
        for who in (OWNER, TG_ADMIN, DELEGATE, OTHER):
            await self.send("a", user=who)
            self.assertEqual((await self.send("b", user=who, advance=1)).kind, OutcomeKind.NONE, who)
        self.assertEqual(self.actions.deleted, [])

    async def test_redelivery_of_the_accepted_message_is_never_a_violation(self):
        await self.send("hello", mid=50)
        o = await self.send("hello", mid=50, advance=1)   # the same Telegram message delivered again
        self.assertEqual(o.kind, OutcomeKind.NONE)
        self.assertEqual(self.actions.deleted, [])

    async def test_redelivery_of_a_violating_message_deletes_once(self):
        await self.send("a")
        first = await self.send("b", mid=60, advance=5)
        again = await self.send("b", mid=60, advance=1)
        self.assertEqual((first.kind, again.kind), (OutcomeKind.ACTED, OutcomeKind.DUPLICATE_DELIVERY))
        self.assertEqual(self.actions.deleted, [(A, 60)])

    async def test_edits_and_service_messages_neither_violate_nor_restart(self):
        await self.send("a")
        self.assertEqual((await self.send("a edited", edit=True, advance=5)).kind, OutcomeKind.NONE)
        ctx = await self.gate.evaluate(A, "supergroup", STRANGER)
        join = await self.engine.handle(ctx, MessageView(A, STRANGER, 900, None, (), False, True), self.s.clock())
        self.assertEqual(join.kind, OutcomeKind.NONE)
        self.assertEqual((await self.send("b", advance=5)).violation, "slowmode")   # timer still from "a"

    async def test_service_message_does_not_start_the_timer_for_a_new_member(self):
        ctx = await self.gate.evaluate(A, "supergroup", OTHER)
        await self.engine.handle(ctx, MessageView(A, OTHER, 1, None, (), False, True), self.s.clock())
        self.assertEqual((await self.send("first real message", user=OTHER, advance=1)).kind, OutcomeKind.NONE)

    async def test_dry_run_deletes_nothing(self):
        await self.cfg(dry_run=True)
        await self.send("a")
        o = await self.send("b", advance=1)
        self.assertEqual(o.kind, OutcomeKind.DRY_RUN)
        self.assertEqual((self.actions.deleted, self.claims._keys), ([], {}))

    async def test_needs_only_the_delete_right(self):
        self.s.chat.set(A, BOT, ChatMemberInfo("administrator", True, False, True))   # cannot restrict, can delete
        await self.send("a")
        self.assertTrue((await self.send("b", advance=1)).deleted)
        self.s.chat.set(A, BOT, ChatMemberInfo("administrator", False, True, True))   # cannot delete
        o = await self.send("c", advance=1)
        self.assertEqual(o.kind, OutcomeKind.BOT_RIGHTS_MISSING)
        self.assertEqual(self.actions.deleted, [(A, 2)])
        self.assertEqual(len(self.notifier.owner_messages if hasattr(self.notifier, "owner_messages") else [1]), 1)

    async def test_unknown_rights_do_nothing(self):
        await self.send("a")
        from guardian.errors import TelegramLookupFailed

        async def down(chat_id):
            raise TelegramLookupFailed("down")

        self.s.chat.get_bot_member = down  # only the bot's own rights are unreadable (a total outage would exempt everyone)
        o = await self.send("b", advance=1)
        self.assertEqual(o.kind, OutcomeKind.UNSAFE_NO_ACTION)
        self.assertEqual(self.actions.deleted, [])

    async def test_failed_delete_is_reported_not_claimed_as_done(self):
        self.actions.delete_result = ActionResult(False, "forbidden")
        await self.send("a")
        o = await self.send("b", advance=1)
        self.assertEqual((o.kind, o.deleted), (OutcomeKind.ACTED, False))

    async def test_slowmode_never_creates_offenses_so_a_later_link_is_a_first_offense(self):
        await self.send("a")
        for i in range(3):
            await self.send(f"x{i}", advance=1)
        self.s.clock.advance(seconds=40)
        o = await self.send("see https://evil.example")
        self.assertEqual((o.violation, o.muted_seconds), ("links", 600))

    async def test_stronger_rules_win_inside_the_interval(self):
        await self.send("a")
        o = await self.send("https://evil.example", advance=1)
        self.assertEqual((o.violation, o.muted_seconds), ("links", 600))

    async def test_per_group_and_per_user(self):
        await self.send("a")
        self.assertEqual((await self.send("b", user=OTHER, advance=1)).kind, OutcomeKind.NONE)     # another user
        self.s.chat.set(B, BOT, ChatMemberInfo("administrator", True, True, True))
        self.assertEqual((await self.send("c", group=B, advance=1)).kind, OutcomeKind.NONE)          # another group (no slowmode)

    async def test_clock_going_backwards_is_lenient(self):
        await self.send("a")
        self.assertEqual((await self.send("b", advance=-5)).kind, OutcomeKind.NONE)


class LastSeenTests(unittest.TestCase):
    def test_bounded_lru(self):
        ls = LastSeen(max_keys=3)
        for i in range(5):
            ls.put(i, float(i), i)
        self.assertEqual((len(ls), ls.get(0), ls.get(4)), (3, None, (4.0, 4)))
        ls.put(2, 9.0, 9)
        ls.put(7, 1.0, 1)
        self.assertEqual((ls.get(2), ls.get(3)), ((9.0, 9), None))  # touched key survives, oldest evicted
        ls.forget(2)
        self.assertIsNone(ls.get(2))


class ServiceMessageDetectionTests(unittest.TestCase):
    def test_content_types(self):
        for ct in ("text", "photo", "video", "sticker", "voice", "poll", "animation", "document"):
            self.assertFalse(_is_service(NS(content_type=ct)), ct)
        for ct in ("new_chat_members", "left_chat_member", "pinned_message", "forum_topic_created", "unknown",
                   "new_chat_title", "video_chat_started"):
            self.assertTrue(_is_service(NS(content_type=ct)), ct)
        self.assertFalse(_is_service(NS()))                                   # fakes without the attribute
        self.assertFalse(_is_service(NS(content_type=NS(value="text"))))      # enum-like
        self.assertTrue(_is_service(NS(content_type=NS(value="new_chat_members"))))

    def test_middleware_marks_the_view(self):
        mw = ProtectionGateMiddleware(gate=None)
        ctx = NS(chat_id=A, sender_id=STRANGER)
        ev = NS(message_id=3, text=None, caption=None, entities=None, caption_entities=None, content_type="new_chat_members")
        self.assertTrue(mw._view(ev, ctx).service)
        ev.content_type = "text"
        self.assertFalse(mw._view(ev, ctx).service)


if __name__ == "__main__":
    unittest.main()
