"""Part 9.2: the content filter (lexicon, evasions, emojis, scripts), Gemini (scrubbing, parsing, key rotation), the guard
(ladder, immediate bans, AI judgement, admin review, new-member screening) and its wiring. No network, no aiogram."""
import asyncio
import json
import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

from guardian.bot.middlewares import ProtectionGateMiddleware
from guardian.content_filter import gemini as G
from guardian.content_filter.classifier import BLOCK, CLEAN, SUSPECT, ContentClassifier, default_classifier
from guardian.content_filter.emojis import find_banned_emoji
from guardian.content_filter.ladder import step_for
from guardian.content_filter.lexicon import default_lexicon, load
from guardian.content_filter.scripts import find_blocked_script
from guardian.content_filter.service import (ContentGuard, ContentView, NewMember, encode_callback, parse_callback)
from guardian.content_filter.store import InMemoryContentLedger, InMemoryReviewStore
from guardian.idempotency import InMemoryIdempotency
from guardian.protection.adult_words import _BUILTIN as OLD_BUILTIN
from guardian.protection.engine import ActionResult, SendResult
from guardian.protection_gate import ProtectionGate
from guardian.telegram_rights import AdminInfo, ChatMemberInfo
from helpers import FakeNotifier
from stack import A, B, OWNER, STRANGER, TG_ADMIN, Stack

BOT = 777
STRANGER2, STRANGER3 = 800_001, 800_002  # ordinary members (STRANGER + 1 is the group creator in the shared stack)
LEX = default_lexicon()
CLS = default_classifier()


# ------------------------------------------------------------------------------------------------ lexicon / classifier
class LexiconTests(unittest.TestCase):
    def test_the_bundled_data_loads_clean(self):
        self.assertEqual(LEX.problems, ())
        self.assertGreater(len(LEX.explicit), 50)
        self.assertGreater(len(LEX.hints), 30)
        self.assertGreater(len(LEX.phrases_suspect), 50)
        self.assertGreater(len(LEX.patterns), 5)
        self.assertEqual(len(LEX.banned_emojis), 9)
        for emoji in "🍆🍑🍌💦👅🍒🔞💋🫦":
            self.assertIn(emoji, LEX.banned_emojis)

    def test_the_old_adult_words_are_still_caught(self):
        for word in sorted(OLD_BUILTIN):
            if len(word) < 2:
                continue
            self.assertNotEqual(CLS.classify(word).level, CLEAN, word)

    def test_false_positives_json_is_honoured(self):
        fp = LEX.false_positives
        for item in fp["innocent_words"]:
            self.assertEqual(CLS.classify(item["word"]).level, CLEAN, item["word"])
        for sentence in fp["innocent_sentences"]:
            self.assertEqual(CLS.classify(sentence).level, CLEAN, sentence)

    def test_an_innocent_word_never_lets_a_violating_sentence_through(self):
        for sentence in LEX.false_positives["violating_sentences_with_innocent_words"]:
            self.assertEqual(CLS.classify(sentence).level, BLOCK, sentence)

    def test_the_named_innocent_words(self):
        for text in ("كسوة", "كساء", "زبيب", "الحساب", "مصدر", "كسوة الكعبة وزبيب ومصدر الحساب"):
            self.assertEqual(CLS.classify(text).level, CLEAN, text)

    def test_evasions(self):
        for text in ("سكسسسس", "س ك س", "س.ك.س", "ســـكـــس", "s e x v i d e o", "p0rn", "P.O.R.N", "xxx", "kosomak",
                     "والسكس", "بالسكس", "شاهد bl0wj0b", "نيييك"):
            self.assertNotEqual(CLS.classify(text).level, CLEAN, text)

    def test_levels(self):
        self.assertEqual(CLS.classify("نيك امك").level, BLOCK)
        self.assertEqual(CLS.classify("ديوث").level, BLOCK)
        self.assertEqual(CLS.classify("ابغى بنت تكلمني خاص").level, SUSPECT)
        self.assertEqual(CLS.classify("who wants to chat private").level, SUSPECT)
        self.assertEqual(CLS.classify("hello everyone").level, CLEAN)
        self.assertEqual(CLS.classify("").level, CLEAN)
        self.assertEqual(CLS.classify(None).level, CLEAN)

    def test_everyday_arabic_stays_clean(self):
        for text in ("مني الف سلام", "الجنسية السعودية", "عاري عن الصحة", "فكس", "بكس", "هذا من جنس واحد؟", "كاس العالم"):
            self.assertEqual(CLS.classify(text).level, CLEAN, text)

    def test_custom_words_are_block(self):
        self.assertEqual(CLS.classify("هذه كلمتنا", ("كلمتنا",)).level, BLOCK)
        self.assertEqual(CLS.classify("هذه كلمتنا").level, CLEAN)

    def test_a_bad_data_line_is_reported_not_fatal(self):
        import tempfile
        from pathlib import Path

        with tempfile.TemporaryDirectory() as d:
            p = Path(d)
            (p / "words_explicit.txt").write_text("سكس\n", encoding="utf-8")
            (p / "patterns.txt").write_text("block|(unclosed\nbad level|x\nblock|(a+)+$\n", encoding="utf-8")
            lex = load(p)
        self.assertIn("سكس", lex.explicit)
        self.assertGreaterEqual(len(lex.problems), 2)
        self.assertEqual(ContentClassifier(lex).classify("سكس").level, BLOCK)


class EmojiAndScriptTests(unittest.TestCase):
    def test_banned_emoji(self):
        for text in ("🍆", "hello 🍆️ there", "اسم 🍑", "x💦y", "🔞"):
            self.assertIsNotNone(find_banned_emoji(text), text)
        for text in ("🍎 تفاح", "🙂", "", None, "plain"):
            self.assertIsNone(find_banned_emoji(text), text)

    def test_blocked_scripts(self):
        hits = {"привет": "CYRILLIC", "你好": "CJK", "ありがとう": "HIRAGANA", "カタカナ": "KATAKANA", "한국어": "HANGUL",
                "γειά": "GREEK", "สวัสดี": "THAI", "नमस्ते": "DEVANAGARI", "hello Ж": "CYRILLIC"}
        for text, script in hits.items():
            self.assertEqual(find_blocked_script(text), script, text)

    def test_ignored_content(self):
        for text in ("مرحبا hello 123", "https://ru.wikipedia.org/wiki/Привет", "🙂 😂", "@Иван", "12345", "π", "Ω",
                     "www.пример.рф/path", "(مرحبا)", "", None):
            self.assertIsNone(find_blocked_script(text), text)

    def test_hebrew_is_off_until_enabled(self):
        self.assertIsNone(find_blocked_script("שלום"))
        self.assertEqual(find_blocked_script("שלום", frozenset({"HEBREW"})), "HEBREW")


class LadderTests(unittest.TestCase):
    def test_steps(self):
        self.assertEqual([step_for(n).action for n in (1, 2, 3, 4, 5, 99)], ["warn", "mute", "mute", "ban", "ban", "ban"])
        self.assertEqual((step_for(2).seconds, step_for(3).seconds), (3600, 86400))
        self.assertEqual(step_for(0).action, "warn")
        self.assertEqual(step_for(True).action, "warn")


# ------------------------------------------------------------------------------------------------ Gemini
def ok_body(verdict="SAFE", confidence=0.9, reason="fine"):
    text = json.dumps({"verdict": verdict, "confidence": confidence, "reason": reason})
    return json.dumps({"candidates": [{"content": {"parts": [{"text": text}]}}]}).encode()


def err_body(status, message="x", delay=None, code=429):
    err = {"code": code, "status": status, "message": message}
    if delay:
        err["details"] = [{"@type": "type.googleapis.com/google.rpc.RetryInfo", "retryDelay": delay}]
    return json.dumps({"error": err}).encode()


class Clock:
    def __init__(self):
        self.now = datetime(2026, 11, 5, 12, 0, tzinfo=timezone.utc)

    def __call__(self):
        return self.now

    def advance(self, **kw):
        self.now += timedelta(**kw)


class Transport:
    """script[key] = list of (status, body) answers in order; the last one repeats."""

    def __init__(self, script):
        self.script, self.calls, self.bodies = script, [], []

    async def __call__(self, url, headers, body, timeout):
        key = headers["x-goog-api-key"]
        self.calls.append(key)
        self.bodies.append(body)
        answers = self.script[key]
        item = answers.pop(0) if len(answers) > 1 else answers[0]
        if isinstance(item, Exception):
            raise item
        return item


class GeminiHelpersTests(unittest.TestCase):
    def test_scrub_hides_personal_data(self):
        out = G.scrub("call +966 50 123 4567 or mail a.b@x.com via https://t.me/abc and @someone now")
        for leaked in ("966", "a.b@x.com", "t.me", "someone"):
            self.assertNotIn(leaked, out)
        self.assertLessEqual(len(G.scrub("ا" * 5000)), G.MAX_AI_TEXT)

    def test_parse_verdict(self):
        v = G.parse_verdict('```json\n{"verdict":"block","confidence":0.8,"reason":"explicit"}\n```')
        self.assertEqual((v.verdict, v.confidence, v.reason), ("BLOCK", 0.8, "explicit"))
        self.assertEqual(G.parse_verdict('{"verdict":"SAFE","confidence":85,"reason":""}').confidence, 0.85)
        for bad in ("", None, "nope", '{"verdict":"MAYBE","confidence":1}', '{"verdict":"SAFE"}', '{"verdict":"SAFE","confidence":"x"}',
                    '{"verdict":"SAFE","confidence":-1}', "[1,2]", 5):
            self.assertIsNone(G.parse_verdict(bad), bad)

    def test_decide_never_trusts_a_failure_or_doubt(self):
        R = lambda v, c: G.AIResult(G.AIVerdict(v, c, ""))  # noqa: E731
        self.assertEqual(G.decide(R("SAFE", 0.9)), "safe")
        self.assertEqual(G.decide(R("SAFE", 0.4)), "warning")
        self.assertEqual(G.decide(R("BLOCK", 0.9)), "block")
        self.assertEqual(G.decide(R("BLOCK", 0.5)), "warning")
        self.assertEqual(G.decide(R("WARNING", 1.0)), "warning")
        self.assertEqual(G.decide(G.AIResult(failure=G.F_NETWORK)), "warning")

    def test_request_carries_no_identity(self):
        body = json.dumps(G.build_text_request("hello @user https://x.com +966501234567"))
        for leaked in ("@user", "x.com", "966501234567"):
            self.assertNotIn(leaked, body)

    def test_load_keys(self):
        env = {"GEMINI_API_KEY_1": "k1", "GEMINI_API_KEY_2": " k2 ", "GEMINI_API_KEY_3": "", "GEMINI_API_KEY_5": "k1",
               "GEMINI_API_KEYS": "k3, k4,k5,k6"}
        self.assertEqual(G.load_keys(env), ["k1", "k2", "k3", "k4", "k5"])
        self.assertEqual(G.load_keys({}), [])

    def test_a_key_never_shows_in_repr(self):
        pool = G.KeyPool(["SECRET-KEY-VALUE"])
        self.assertNotIn("SECRET", repr(pool))
        self.assertNotIn("SECRET", repr(pool._slots[0]))
        self.assertNotIn("SECRET", str(pool._slots[0]))

    def test_quota_reset_is_in_the_future(self):
        now = datetime(2026, 11, 5, 12, 0, tzinfo=timezone.utc)
        reset = G.next_quota_reset(now)
        self.assertGreater(reset, now)
        self.assertLessEqual(reset - now, timedelta(hours=25))


class KeyRotationTests(unittest.IsolatedAsyncioTestCase):
    def make(self, script, keys=("k1", "k2", "k3"), store=None):
        self.clock = Clock()
        self.tr = Transport(script)
        self.pool = G.KeyPool(list(keys), store, clock=self.clock)
        return G.GeminiClient(self.pool, self.tr, clock=self.clock)

    async def test_first_key_is_used_and_answer_parsed(self):
        c = self.make({"k1": [(200, ok_body("WARNING", 0.7, "hmm"))], "k2": [(200, ok_body())], "k3": [(200, ok_body())]})
        r = await c.review_text("hello there")
        self.assertEqual((r.verdict.verdict, r.verdict.confidence), ("WARNING", 0.7))
        self.assertEqual(self.tr.calls, ["k1"])

    async def test_quota_exhaustion_moves_to_the_next_key_and_back_after_renewal(self):
        c = self.make({"k1": [(429, err_body("RESOURCE_EXHAUSTED")), (200, ok_body())], "k2": [(200, ok_body("BLOCK", 0.9, "x"))],
                       "k3": [(200, ok_body())]})
        r = await c.review_text("hello there")
        self.assertEqual(r.verdict.verdict, "BLOCK")
        self.assertEqual(self.tr.calls, ["k1", "k2"])
        self.assertEqual(self.pool.summary()[0], (1, G.K_EXHAUSTED))
        await c.review_text("again")  # k1 still cooling down: goes straight to k2
        self.assertEqual(self.tr.calls[-1], "k2")
        self.clock.advance(hours=26)  # the daily quota renewed
        await c.review_text("later")
        self.assertEqual(self.tr.calls[-1], "k1")
        self.assertEqual(self.pool.summary()[0], (1, G.K_OK))

    async def test_a_short_retry_delay_is_a_short_cooldown(self):
        c = self.make({"k1": [(429, err_body("RESOURCE_EXHAUSTED", delay="20s")), (200, ok_body())], "k2": [(200, ok_body())]})
        await c.review_text("hello there")
        self.clock.advance(seconds=30)
        await c.review_text("hello there")
        self.assertEqual(self.tr.calls[-1], "k1")

    async def test_all_exhausted_is_a_failure_never_safe(self):
        c = self.make({k: [(429, err_body("RESOURCE_EXHAUSTED"))] for k in ("k1", "k2", "k3")})
        r = await c.review_text("hello there")
        self.assertFalse(r.ok)
        self.assertEqual(r.failure, G.F_ALL_EXHAUSTED)
        self.assertEqual(G.decide(r), "warning")
        again = await c.review_text("x y z")
        self.assertEqual(again.failure, G.F_ALL_EXHAUSTED)
        self.assertEqual(len(self.tr.calls), 3)  # the second call made no request at all

    async def test_an_invalid_key_is_skipped_separately(self):
        c = self.make({"k1": [(400, err_body("INVALID_ARGUMENT", "API key not valid. Please pass a valid API key.", code=400)), (200, ok_body())],
                       "k2": [(200, ok_body())], "k3": [(200, ok_body())]})
        r = await c.review_text("hello there")
        self.assertTrue(r.ok)
        self.assertEqual(self.pool.summary()[0], (1, G.K_INVALID))
        self.clock.advance(hours=7)  # parked keys are re-checked later
        await c.review_text("hello there")
        self.assertEqual(self.tr.calls[-1], "k1")

    async def test_403_marks_invalid(self):
        c = self.make({"k1": [(403, err_body("PERMISSION_DENIED", code=403))], "k2": [(200, ok_body())]})
        self.assertTrue((await c.review_text("hello there")).ok)
        self.assertEqual(self.pool.summary()[0], (1, G.K_INVALID))

    async def test_network_errors_never_mark_a_key(self):
        c = self.make({"k1": [G.TransportError("timeout")], "k2": [(200, ok_body())]})
        r = await c.review_text("hello there")
        self.assertEqual(r.failure, G.F_NETWORK)
        self.assertEqual(self.pool.summary(), [(1, G.K_OK), (2, G.K_OK), (3, G.K_OK)])
        self.assertEqual(self.tr.calls, ["k1"])  # the others were not burned

    async def test_server_errors_try_the_next_key_without_marking(self):
        c = self.make({"k1": [(503, err_body("UNAVAILABLE", code=503))], "k2": [(200, ok_body())]})
        self.assertTrue((await c.review_text("hello there")).ok)
        self.assertEqual(self.pool.summary()[0], (1, G.K_OK))

    async def test_malformed_answer_is_a_failure(self):
        c = self.make({"k1": [(200, json.dumps({"candidates": [{"content": {"parts": [{"text": "not json"}]}}]}).encode())]})
        r = await c.review_text("hello there")
        self.assertEqual(r.failure, G.F_BAD_RESPONSE)

    async def test_the_models_own_safety_block_is_not_clean(self):
        body = json.dumps({"promptFeedback": {"blockReason": "SAFETY"}}).encode()
        c = self.make({"k1": [(200, body)]})
        r = await c.review_text("hello there")
        self.assertEqual(G.decide(r), "warning")

    async def test_no_keys(self):
        c = self.make({}, keys=())
        self.assertEqual((await c.review_text("hello there")).failure, G.F_NO_KEYS)
        self.assertFalse(c.configured)

    async def test_state_is_persisted_and_a_replaced_key_starts_clean(self):
        store = G.MemoryKeyStateStore()
        c = self.make({"k1": [(429, err_body("RESOURCE_EXHAUSTED"))], "k2": [(200, ok_body())]}, keys=("k1", "k2"), store=store)
        await c.review_text("hello there")
        self.assertEqual(store.rows[1].status, G.K_EXHAUSTED)
        again = G.KeyPool(["k1", "k2"], store, clock=self.clock)  # a restart
        self.assertEqual((await again.acquire()).index, 2)
        replaced = G.KeyPool(["NEW", "k2"], store, clock=self.clock)  # key 1 was replaced
        self.assertEqual((await replaced.acquire()).index, 1)

    async def test_image_review(self):
        c = self.make({"k1": [(200, ok_body("BLOCK", 0.95, "explicit"))]})
        r = await c.review_image(b"\xff\xd8jpeg")
        self.assertEqual(r.verdict.verdict, "BLOCK")
        self.assertIn(b"inlineData", self.tr.bodies[0])
        self.assertEqual((await c.review_image(b"")).failure, G.F_BAD_REQUEST)
        self.assertEqual((await c.review_image(b"x" * (G.MAX_IMAGE_BYTES + 1))).failure, G.F_BAD_REQUEST)

    async def test_the_key_is_only_ever_sent_as_a_header(self):
        c = self.make({"k1": [(200, ok_body())]})
        await c.review_text("hello there")
        self.assertNotIn(b"k1", self.tr.bodies[0])


# ------------------------------------------------------------------------------------------------ the guard
class FakeActions:
    def __init__(self):
        self.deleted, self.muted, self.unmuted, self.banned, self.sent = [], [], [], [], []
        self.dm_fail: set[int] = set()
        self.photo: bytes | None = None
        self.photo_calls = 0
        self.fail_ban = False

    async def delete_message(self, chat_id, message_id):
        self.deleted.append((chat_id, message_id))
        return ActionResult(True)

    async def mute_member(self, chat_id, user_id, until):
        self.muted.append((chat_id, user_id, until))
        return ActionResult(True)

    async def unmute_member(self, chat_id, user_id):
        self.unmuted.append((chat_id, user_id))
        return ActionResult(True)

    async def ban_member(self, chat_id, user_id, until):
        if self.fail_ban:
            return ActionResult(False, "forbidden")
        self.banned.append((chat_id, user_id, until))
        return ActionResult(True)

    async def send_message(self, chat_id, text, buttons=None):
        self.sent.append((chat_id, text, buttons))
        if chat_id in self.dm_fail:
            return SendResult(False, "forbidden")
        return SendResult(True, None, len(self.sent))

    async def fetch_profile_photo(self, user_id):
        self.photo_calls += 1
        return self.photo


class FakeAI:
    def __init__(self, *results, configured=True):
        self.results, self.calls, self.image_calls = list(results), [], []
        self._configured = configured

    @property
    def configured(self):
        return self._configured

    def _next(self):
        return self.results.pop(0) if len(self.results) > 1 else self.results[0]

    async def review_text(self, text):
        self.calls.append(text)
        return self._next()

    async def review_image(self, image, mime="image/jpeg"):
        self.image_calls.append(len(image))
        return self._next()


def verdict(v, c=0.9, reason="r"):
    return G.AIResult(G.AIVerdict(v, c, reason))


FAIL = G.AIResult(failure=G.F_ALL_EXHAUSTED)


class GuardBase(unittest.IsolatedAsyncioTestCase):
    ai_results: tuple = ()

    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A, B)
        await self.s.admin.activate_permanent(OWNER, A)
        await self.s.admin.activate_permanent(OWNER, B)
        self.s.chat.set(A, BOT, ChatMemberInfo("administrator", True, True, True))
        self.s.chat.admins[A] = [AdminInfo(TG_ADMIN, "Admin One"), AdminInfo(BOT, "bot", is_bot=True)]
        self.actions = FakeActions()
        self.ledger, self.reviews = InMemoryContentLedger(), InMemoryReviewStore()
        self.ai = FakeAI(*self.ai_results) if self.ai_results else None
        self.guard = self.build(self.ai)
        self.gate = ProtectionGate(self.s.license_service, self.s.perm, FakeNotifier(), clock=self.s.clock)
        self.mid = 0

    def build(self, ai, notifier=None):
        return ContentGuard(self.s.settings_store, self.actions, self.s.chat, InMemoryIdempotency(), self.s.audit, self.ledger,
                            self.reviews, ai=ai, photos=self.actions, permissions=self.s.perm, notifier=notifier,
                            owner_ids=(OWNER,), clock=self.s.clock)

    async def cfg(self, group=A, **patch):
        await self.s.settings_store.merge(group, patch, OWNER, self.s.clock())

    async def say(self, text, user=STRANGER, *, first="Ali", last=None, username=None, mid=None, group=A, edit=False):
        if mid is None:
            self.mid += 1
            mid = self.mid
        ctx = await self.gate.evaluate(group, "supergroup", user)
        view = ContentView(group, user, mid, text, first, last, username, "Grp", edit)
        return await self.guard.handle_message(ctx, view, self.s.clock())

    def events(self, kind):
        return [e for e in self.s.audit.events if e.event_type == kind]


class LadderFlowTests(GuardBase):
    async def test_warning_then_1h_then_24h_then_ban(self):
        self.assertTrue(await self.say("نيك امك"))
        self.assertEqual((len(self.actions.deleted), self.actions.muted, self.actions.banned), (1, [], []))
        self.assertIn("تحذير", self.actions.sent[-1][1])
        self.s.clock.advance(minutes=5)
        self.assertTrue(await self.say("porn"))
        self.assertEqual(self.actions.muted[-1][2] - self.s.clock(), timedelta(seconds=3600))
        self.s.clock.advance(minutes=5)
        self.assertTrue(await self.say("سكس"))
        self.assertEqual(self.actions.muted[-1][2] - self.s.clock(), timedelta(seconds=86400))
        self.s.clock.advance(minutes=5)
        self.assertTrue(await self.say("شرموطة"))
        self.assertEqual(self.actions.banned, [(A, STRANGER, None)])
        self.assertEqual(len(self.actions.deleted), 4)

    async def test_offenses_are_per_group_and_per_member(self):
        await self.say("سكس")
        await self.say("سكس", user=STRANGER2)
        self.assertEqual(self.actions.muted, [])  # each one is on their first offense
        await self.say("سكس", group=B)
        self.assertEqual(self.actions.muted, [])

    async def test_old_offenses_age_out(self):
        await self.say("سكس")
        self.s.clock.advance(days=31)
        await self.say("سكس")
        self.assertEqual(self.actions.muted, [])  # a warning again

    async def test_a_failed_mute_does_not_escalate(self):
        await self.say("سكس")
        self.s.clock.advance(minutes=1)

        async def refuse(*a):
            return ActionResult(False, "forbidden")

        self.actions.mute_member = refuse
        await self.say("سكس")
        self.assertEqual(len(self.ledger.rows), 1)

    async def test_edits_are_checked(self):
        self.assertTrue(await self.say("سكس", edit=True))

    async def test_clean_messages_untouched(self):
        self.assertFalse(await self.say("مرحبا بالجميع"))
        self.assertEqual((self.actions.deleted, self.actions.sent), ([], []))

    async def test_a_redelivered_update_acts_once(self):
        self.assertTrue(await self.say("سكس", mid=50))
        self.assertTrue(await self.say("سكس", mid=50))
        self.assertEqual(len(self.actions.deleted), 1)
        self.assertEqual(len(self.ledger.rows), 1)


class ImmediateBanTests(GuardBase):
    async def test_banned_emoji_in_the_message(self):
        self.assertTrue(await self.say("شوف 🍆 هنا"))
        self.assertEqual(self.actions.banned, [(A, STRANGER, None)])
        self.assertEqual(len(self.actions.deleted), 1)
        self.assertEqual(self.actions.muted, [])

    async def test_banned_emoji_in_the_name_or_username_even_with_clean_text(self):
        self.assertTrue(await self.say("مرحبا", first="Sara 🍑"))
        self.assertTrue(await self.say("مرحبا", user=STRANGER2, username="x🔞y"))
        self.assertEqual(len(self.actions.banned), 2)

    async def test_blocked_script_in_text_deletes_and_bans(self):
        self.assertTrue(await self.say("hello привет"))
        self.assertEqual(self.actions.banned, [(A, STRANGER, None)])
        self.assertTrue(await self.say("你好", user=STRANGER2))
        self.assertEqual(len(self.actions.banned), 2)

    async def test_scripts_are_not_applied_to_names(self):
        self.assertFalse(await self.say("مرحبا", first="Иван", last="张伟", username="ivan"))
        self.assertEqual(self.actions.banned, [])

    async def test_url_and_digits_do_not_trigger_the_script_rule(self):
        self.assertFalse(await self.say("https://ru.wikipedia.org/wiki/Привет 12345"))

    async def test_switches(self):
        await self.cfg(cf_emoji=False, cf_scripts=False)
        self.assertFalse(await self.say("🍆 привет"))
        await self.cfg(adult_enabled=False)
        self.assertFalse(await self.say("سكس"))

    async def test_a_failed_ban_is_not_recorded(self):
        self.actions.fail_ban = True
        await self.say("🍆")
        self.assertEqual(self.ledger.rows, [])


class ExemptionTests(GuardBase):
    async def test_owner_and_telegram_admins_are_exempt_from_everything(self):
        for who in (OWNER, TG_ADMIN):
            self.assertFalse(await self.say("سكس 🍆 привет", user=who))
        self.assertEqual((self.actions.deleted, self.actions.banned, self.actions.muted), ([], [], []))

    async def test_listed_ids_are_exempt(self):
        await self.cfg(cf_exempt=[STRANGER])
        self.assertFalse(await self.say("سكس 🍆"))

    async def test_no_action_when_the_license_is_inactive(self):
        s2 = Stack()
        await s2.register(A)  # pending, never activated
        gate = ProtectionGate(s2.license_service, s2.perm, FakeNotifier(), clock=s2.clock)
        ctx = await gate.evaluate(A, "supergroup", STRANGER)
        self.assertFalse(await self.guard.handle_message(ctx, ContentView(A, STRANGER, 1, "سكس"), self.s.clock()))

    async def test_services_messages_are_ignored(self):
        ctx = await self.gate.evaluate(A, "supergroup", STRANGER)
        self.assertFalse(await self.guard.handle_message(ctx, ContentView(A, STRANGER, 1, "سكس", service=True)))


class SafetyRuleTests(GuardBase):
    async def test_dry_run_only_audits(self):
        await self.cfg(dry_run=True)
        self.assertFalse(await self.say("سكس"))
        self.assertEqual((self.actions.deleted, self.actions.sent), ([], []))
        self.assertTrue(self.events("content_filter_dry_run"))

    async def test_missing_bot_rights_do_nothing_and_tell_the_owner(self):
        self.s.chat.set(A, BOT, ChatMemberInfo("member"))
        notifier = FakeNotifier()
        guard = self.build(None, notifier)
        ctx = await self.gate.evaluate(A, "supergroup", STRANGER)
        self.assertFalse(await guard.handle_message(ctx, ContentView(A, STRANGER, 1, "سكس"), self.s.clock()))
        self.assertEqual(self.actions.deleted, [])
        self.assertTrue(self.events("content_filter_blocked_bot_rights"))
        self.assertEqual(len(notifier.owner_messages), 1)

    async def test_unknown_rights_do_nothing(self):
        self.s.chat.fail = True
        self.assertFalse(await self.say("سكس"))
        self.assertEqual(self.actions.deleted, [])

    async def test_a_broken_ledger_deletes_but_never_guesses_a_penalty(self):
        async def boom(*a, **k):
            raise RuntimeError("db")

        self.ledger.count_since = boom
        await self.say("سكس")
        self.assertEqual((self.actions.muted, self.actions.banned), ([], []))


class SuspectFlowTests(GuardBase):
    ai_results = (verdict("SAFE", 0.95),)

    async def test_ai_safe_leaves_the_message_alone(self):
        self.assertFalse(await self.say("ابغى بنت تكلمني خاص"))
        self.assertEqual(self.actions.deleted, [])
        self.assertEqual(len(self.ai.calls), 1)

    async def test_only_suspicious_text_reaches_gemini_and_without_identity(self):
        await self.say("مرحبا بالجميع")
        await self.say("سكس")  # clear violation: handled locally
        self.assertEqual(self.ai.calls, [])
        await self.say("ابغى بنت تكلمني خاص", first="Secret", username="secret_user")
        self.assertEqual(len(self.ai.calls), 1)
        self.assertNotIn("Secret", self.ai.calls[0])

    async def test_ai_warning_opens_a_review(self):
        self.ai.results = [verdict("WARNING", 0.7, "dating solicitation")]
        self.assertTrue(await self.say("ابغى بنت تكلمني خاص"))
        self.assertEqual(self.actions.muted[-1][2] - self.s.clock(), timedelta(seconds=86400))
        self.assertEqual(self.actions.banned, [])
        review = await self.reviews.get(A, 1)
        self.assertEqual((review.user_id, review.status, review.source), (STRANGER, "pending", "message"))
        dms = [m for m in self.actions.sent if m[0] in (OWNER, TG_ADMIN)]
        self.assertEqual({m[0] for m in dms}, {OWNER, TG_ADMIN})
        buttons = dms[0][2][0]
        self.assertEqual([b[1] for b in buttons], [f"cf:{A}:1:c", f"cf:{A}:1:r"])
        self.assertTrue(all(len(b[1].encode()) <= 64 for b in buttons))
        self.assertEqual((await self.reviews.get(A, 1)).notified, 2)
        self.assertEqual(self.ledger.rows, [])  # a suspicion is not an offense until confirmed

    async def test_ai_block_follows_the_ladder(self):
        self.ai.results = [verdict("BLOCK", 0.9, "explicit")]
        self.assertTrue(await self.say("ابغى بنت تكلمني خاص"))
        self.assertEqual(self.actions.muted, [])
        self.assertEqual(self.ledger.rows[0]["action"], "warn")

    async def test_low_confidence_block_is_only_a_review(self):
        self.ai.results = [verdict("BLOCK", 0.5)]
        await self.say("ابغى بنت تكلمني خاص")
        self.assertEqual(await self.reviews.get(A, 1) is not None, True)

    async def test_ai_failure_is_never_safe(self):
        self.ai.results = [FAIL]
        self.assertTrue(await self.say("ابغى بنت تكلمني خاص"))
        self.assertEqual(len(self.actions.muted), 1)
        self.assertTrue(self.events("content_filter_ai_failed"))
        self.assertIsNotNone(await self.reviews.get(A, 1))

    async def test_gemini_switched_off_or_missing_is_a_review_too(self):
        await self.cfg(cf_ai=False)
        await self.say("ابغى بنت تكلمني خاص")
        self.assertEqual(self.ai.calls, [])
        self.assertIsNotNone(await self.reviews.get(A, 1))
        await self.cfg(cf_ai=True)
        self.guard = self.build(None)
        await self.say("ابغى بنت تكلمني خاص", user=STRANGER2)
        self.assertIsNotNone(await self.reviews.get(A, 2))

    async def test_unreachable_admins_are_logged_and_the_group_is_told(self):
        self.ai.results = [verdict("WARNING", 0.7)]
        self.actions.dm_fail = {OWNER, TG_ADMIN}
        await self.say("ابغى بنت تكلمني خاص")
        failed = self.events("content_review_dm_failed")
        self.assertEqual({e.actor_telegram_id for e in failed}, {OWNER, TG_ADMIN})
        self.assertTrue(self.events("content_review_unreachable"))
        self.assertTrue(any("/start" in m[1] for m in self.actions.sent if m[0] == A))
        self.assertEqual((await self.reviews.get(A, 1)).failed, 2)

    async def test_one_reachable_admin_is_enough(self):
        self.ai.results = [verdict("WARNING", 0.7)]
        self.actions.dm_fail = {TG_ADMIN}
        await self.say("ابغى بنت تكلمني خاص")
        self.assertEqual(len(self.events("content_review_dm_failed")), 1)
        self.assertFalse(self.events("content_review_unreachable"))


class ReviewDecisionTests(GuardBase):
    ai_results = (verdict("WARNING", 0.7, "dating"),)

    async def asyncSetUp(self):
        await super().asyncSetUp()
        await self.say("ابغى بنت تكلمني خاص")

    async def test_confirm_bans_and_the_first_decision_wins(self):
        text, alert = await self.guard.decide(A, 1, "c", TG_ADMIN, self.s.clock())
        self.assertFalse(alert)
        self.assertEqual(self.actions.banned, [(A, STRANGER, None)])
        review = await self.reviews.get(A, 1)
        self.assertEqual((review.status, review.decided_by), ("confirmed", TG_ADMIN))
        self.assertIsNotNone(review.decided_at)
        again, alert = await self.guard.decide(A, 1, "r", OWNER, self.s.clock())
        self.assertTrue(alert)
        self.assertEqual(self.actions.unmuted, [])  # the late "reject" did nothing
        self.assertEqual(len(self.actions.banned), 1)
        self.assertEqual((await self.reviews.get(A, 1)).status, "confirmed")
        self.assertTrue(self.events("content_review_confirmed"))

    async def test_reject_unmutes_without_an_offense(self):
        await self.guard.decide(A, 1, "r", OWNER, self.s.clock())
        self.assertEqual(self.actions.unmuted, [(A, STRANGER)])
        self.assertEqual((self.actions.banned, self.ledger.rows), ([], []))
        self.assertTrue(self.events("content_review_rejected"))

    async def test_a_member_or_stranger_cannot_decide(self):
        text, alert = await self.guard.decide(A, 1, "c", STRANGER, self.s.clock())
        self.assertTrue(alert)
        self.assertEqual(self.actions.banned, [])
        self.assertEqual((await self.reviews.get(A, 1)).status, "pending")
        self.assertTrue(self.events("permission_denied"))

    async def test_a_limited_admin_without_the_restrict_right_cannot_decide(self):
        from stack import TG_LIMITED_ADMIN

        _, alert = await self.guard.decide(A, 1, "c", TG_LIMITED_ADMIN, self.s.clock())
        self.assertTrue(alert)
        self.assertEqual(self.actions.banned, [])

    async def test_a_forged_group_or_id_finds_nothing(self):
        for group, rid in ((B, 1), (A, 99)):
            _, alert = await self.guard.decide(group, rid, "c", OWNER, self.s.clock())
            self.assertTrue(alert)
        self.assertEqual(self.actions.banned, [])

    async def test_a_failed_telegram_action_still_records_the_first_decision(self):
        self.actions.fail_ban = True
        text, alert = await self.guard.decide(A, 1, "c", OWNER, self.s.clock())
        self.assertTrue(alert)
        self.assertEqual((await self.reviews.get(A, 1)).status, "confirmed")
        self.assertTrue(self.events("content_review_action_failed"))

    async def test_the_decision_is_race_safe(self):
        results = await asyncio.gather(self.guard.decide(A, 1, "c", OWNER, self.s.clock()),
                                       self.guard.decide(A, 1, "r", TG_ADMIN, self.s.clock()))
        self.assertEqual(sorted(alert for _, alert in results), [False, True])

    def test_callback_codec(self):
        self.assertEqual(parse_callback(encode_callback(-1001234567890, 42, "c")), (-1001234567890, 42, "c"))
        for bad in (None, "", "cf:1:2:c", "cf:-1:0:c", "cf:-1:2:x", "vf:-1:2:c", "cf:-1:2", "cf:-1:a:c", "cf:--1:2:c", "x" * 99):
            self.assertIsNone(parse_callback(bad), bad)


class NewMemberTests(GuardBase):
    ai_results = (verdict("SAFE", 0.95),)

    async def screen(self, **kw):
        member = NewMember(**{"user_id": STRANGER, "first_name": "Ali", **kw})
        return await self.guard.screen_member(A, member, "Grp", self.s.clock())

    async def test_clean_member_passes_and_nothing_is_sent_to_gemini_without_a_photo(self):
        self.assertIsNone(await self.screen())
        self.assertEqual((self.ai.calls, self.ai.image_calls), ([], []))
        self.assertEqual(self.actions.photo_calls, 1)

    async def test_banned_emoji_in_the_name_is_an_immediate_ban(self):
        self.assertEqual(await self.screen(first_name="Sexy 🍑"), "ban")
        self.assertEqual(self.actions.banned, [(A, STRANGER, None)])

    async def test_explicit_name_is_an_immediate_ban(self):
        self.assertEqual(await self.screen(first_name="porn", last_name="star"), "ban")
        self.assertEqual(await self.screen(user_id=STRANGER2, first_name="Ali", username="xxx_videos"), "ban")

    async def test_suspicious_name_goes_to_gemini(self):
        self.assertIsNone(await self.screen(first_name="hot girls"))
        self.assertEqual(len(self.ai.calls), 1)
        self.ai.results = [verdict("WARNING", 0.6, "suggestive name")]
        self.assertEqual(await self.screen(user_id=STRANGER2, first_name="hot girls"), "review")
        self.assertEqual(self.actions.banned, [])
        self.assertEqual(len(self.actions.muted), 1)

    async def test_suspicious_name_with_gemini_down_is_reviewed_not_ignored(self):
        self.ai.results = [FAIL]
        self.assertEqual(await self.screen(first_name="hot girls"), "review")

    async def test_photo_explicit_is_a_ban(self):
        self.actions.photo = b"\xff\xd8photo"
        self.ai.results = [verdict("BLOCK", 0.97, "nudity")]
        self.assertEqual(await self.screen(), "ban")
        self.assertEqual(self.ai.image_calls, [len(self.actions.photo)])

    async def test_photo_doubtful_is_a_review_with_a_24h_mute(self):
        self.actions.photo = b"\xff\xd8photo"
        self.ai.results = [verdict("WARNING", 0.6, "suggestive")]
        self.assertEqual(await self.screen(), "review")
        self.assertEqual(self.actions.muted[0][2] - self.s.clock(), timedelta(seconds=86400))
        self.assertEqual((await self.reviews.get(A, 1)).source, "photo")

    async def test_photo_safe_does_nothing(self):
        self.actions.photo = b"\xff\xd8photo"
        self.assertIsNone(await self.screen())

    async def test_no_photo_or_a_failed_check_never_punishes(self):
        self.actions.photo = None
        self.assertIsNone(await self.screen())
        self.actions.photo = b"\xff\xd8photo"
        self.ai.results = [FAIL]
        self.assertIsNone(await self.screen(user_id=STRANGER2))
        self.assertTrue(self.events("content_filter_photo_unchecked"))
        self.assertEqual((self.actions.banned, self.actions.muted), ([], []))

    async def test_photo_switch_and_missing_gemini(self):
        self.actions.photo = b"\xff\xd8photo"
        await self.cfg(cf_photos=False)
        self.assertIsNone(await self.screen())
        self.assertEqual(self.actions.photo_calls, 0)
        await self.cfg(cf_photos=True)
        self.guard = self.build(None)
        self.assertIsNone(await self.screen(user_id=STRANGER3))
        self.assertEqual(self.actions.photo_calls, 0)

    async def test_bots_admins_and_listed_ids_are_not_screened(self):
        self.assertIsNone(await self.screen(first_name="🍆", is_bot=True))
        self.assertIsNone(await self.screen(user_id=TG_ADMIN, first_name="🍆"))
        self.assertIsNone(await self.screen(user_id=OWNER, first_name="🍆"))
        await self.cfg(cf_exempt=[STRANGER])
        self.assertIsNone(await self.screen(first_name="🍆"))
        self.assertEqual(self.actions.banned, [])

    async def test_no_action_without_the_restrict_right(self):
        self.s.chat.set(A, BOT, ChatMemberInfo("administrator", True, False, True))
        self.assertIsNone(await self.screen(first_name="🍆"))
        self.assertEqual(self.actions.banned, [])

    async def test_screening_never_raises(self):
        async def boom(*a, **k):
            raise RuntimeError("down")

        self.guard._load = boom
        self.assertIsNone(await self.screen(first_name="🍆"))


# ------------------------------------------------------------------------------------------------ wiring
class MiddlewareTests(GuardBase):
    async def test_the_guard_runs_before_the_engine_and_consumes_the_message(self):
        engine_calls = []

        class Engine:
            async def handle(self, ctx, view):
                engine_calls.append(view)
                return SimpleNamespace(consumed=False)

        mw = ProtectionGateMiddleware(self.gate, Engine(), content_guard=self.guard)
        reached = []

        async def handler(event, data):
            reached.append(event)
            return "handled"

        def event(text, mid):
            return SimpleNamespace(chat=SimpleNamespace(id=A, type="supergroup", title="G"),
                                   from_user=SimpleNamespace(id=STRANGER, first_name="Ali", last_name=None, username=None),
                                   message_id=mid, text=text, caption=None, entities=None, caption_entities=None,
                                   sender_chat=None, via_bot=None)

        self.assertIsNone(await mw(handler, event("سكس", 1), {}))
        self.assertEqual((engine_calls, reached), ([], []))
        self.assertEqual(await mw(handler, event("مرحبا", 2), {}), "handled")
        self.assertEqual(len(engine_calls), 1)

    async def test_a_crashing_guard_never_blocks_the_message(self):
        class Boom:
            async def handle_message(self, *a, **k):
                raise RuntimeError("x")

        mw = ProtectionGateMiddleware(self.gate, None, content_guard=Boom())

        async def handler(event, data):
            return "handled"

        event = SimpleNamespace(chat=SimpleNamespace(id=A, type="supergroup", title="G"),
                                from_user=SimpleNamespace(id=STRANGER, first_name="A"), message_id=1, text="hi",
                                sender_chat=None, via_bot=None)
        self.assertEqual(await mw(handler, event, {}), "handled")


class CommandAndSettingsTests(unittest.TestCase):
    def test_the_new_settings_are_template_keys_and_validated(self):
        from guardian.owner_templates.templates import TEMPLATE_KEYS
        from guardian.protection.settings import ProtectionSettings

        for key in ("cf_ai", "cf_emoji", "cf_scripts", "cf_names", "cf_photos", "cf_exempt"):
            self.assertIn(key, TEMPLATE_KEYS)
        s = ProtectionSettings.from_raw({"cf_exempt": [5, "x", 5, True, -3, 7], "cf_emoji": "no"})
        self.assertEqual(s.cf_exempt, (5, 7))
        self.assertTrue(s.cf_emoji)

    def test_protect_filter_parsing(self):
        from guardian.moderation.command_error import CommandError
        from guardian.moderation.config_args import parse_protect_args as P

        self.assertEqual(P(["filter", "ai", "off"]).patch, {"cf_ai": False})
        self.assertEqual(P(["فلتر", "photos", "on"]).patch, {"cf_photos": True})
        self.assertEqual(P(["filter", "exempt", "add", "123", "456"]).ids, (123, 456))
        self.assertEqual(P(["filter", "exempt", "list"]).op, "filter_exempt_list")
        for bad in (["filter"], ["filter", "ai"], ["filter", "exempt", "add", "abc"], ["filter", "exempt", "add"],
                    ["filter", "nothing", "on"]):
            with self.assertRaises(CommandError, msg=str(bad)):
                P(bad)

    def test_the_overview_line_renders_in_both_languages(self):
        from guardian.moderation.settings_commands import render_lines
        from guardian.protection.settings import ProtectionSettings

        for lang in ("ar", "en"):
            self.assertTrue(render_lines(ProtectionSettings(), ("filter",), lang))


class PackagingTests(unittest.TestCase):
    def test_the_data_files_exist_and_secrets_are_not_in_the_repo(self):
        from pathlib import Path

        data = Path(__file__).resolve().parents[1] / "src" / "guardian" / "content_filter" / "data"
        for name in ("words_explicit.txt", "words_hints.txt", "words_insults.txt", "phrases.txt", "patterns.txt",
                     "exceptions.txt", "false_positives.json", "banned_emojis.txt", "blocked_scripts.txt"):
            self.assertTrue((data / name).is_file(), name)
        root = Path(__file__).resolve().parents[1]
        for path in list(root.glob("*.md")) + list((root / "docs").glob("*.md")) + [root / ".env.example", root / "render.yaml"]:
            text = path.read_text(encoding="utf-8")
            self.assertNotRegex(text, r"AIza[0-9A-Za-z_-]{30,}", path.name)


if __name__ == "__main__":
    unittest.main()
