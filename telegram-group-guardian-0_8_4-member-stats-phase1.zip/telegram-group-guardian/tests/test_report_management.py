"""Part 6.4a: report management from chat: `/reports`, `/report show|take|resolve|dismiss|type|priority`, their Arabic
words, the owner-approved destination, the handler's redirect, and the service's type/priority moves.
PostgreSQL / aiogram / Telegram are NOT exercised: the PG store is checked against a recording fake connection."""
from __future__ import annotations

import re
import unittest
from pathlib import Path
from types import SimpleNamespace as NS

from executor_stack import A, B, BOT, BOT_NAME, OTHER, USER, BrokenClaims, ExecBase, gate
from guardian.audit import (COMMAND_REJECTED, REPORT_DESTINATION_SET, REPORT_UPDATED, SETTINGS_CHANGED, InMemorySecurityAudit)
from guardian.bot import commands_menu
from guardian.bot import moderation_handler as h
from guardian.errors import InvalidInput
from guardian.i18n import MESSAGES, t
from guardian.moderation.commands import Command, CommandError, parse_command
from guardian.moderation.executor import ModerationCommandService, ResultKind as R
from guardian.moderation.targets import ReplyInfo
from guardian.owner_templates.templates import TEMPLATE_KEYS, effective_settings
from guardian.permissions import OWNER_ONLY, Permission
from guardian.reports import ReportOutcome, ReportPriority, ReportService, ReportStatus, ReportType, TransitionCode
from guardian.reports import args as ra
from guardian.reports.destination import DESTINATION_KEY, destination_of
from guardian.reports.memory_store import InMemoryReportStore
from guardian.reports.postgres_store import PostgresReportStore
from guardian.telegram_rights import ChatMemberInfo
from stack import BACKUP, NOW, OWNER, STRANGER, TG_ADMIN, TG_CREATOR, TG_LIMITED_ADMIN
from test_info_commands import adm
from test_moderation_integration import Msg
from test_reports import RecConn, RecDb, row

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src" / "guardian"
ADMIN2 = 7002
DEST = -100777


# ----------------------------------------------------------------------------------------------- argument parsing
class ArgsTests(unittest.TestCase):
    def test_actions_in_both_languages(self):
        for words, action in ((("show", "عرض", "تفاصيل"), ra.ReportAction.SHOW), (("take", "استلام", "استلم"), ra.ReportAction.TAKE),
                              (("resolve", "حسم", "حل", "معالجة"), ra.ReportAction.RESOLVE),
                              (("dismiss", "رفض", "تجاهل"), ra.ReportAction.DISMISS), (("type", "نوع"), ra.ReportAction.TYPE),
                              (("priority", "أولوية", "اولوية", "PRIORITY"), ra.ReportAction.PRIORITY)):
            for w in words:
                with self.subTest(w):
                    self.assertIs(ra.parse_admin((w, "12", *(["spam"] if action is ra.ReportAction.TYPE else
                                                              ["high"] if action is ra.ReportAction.PRIORITY else []))).action, action)

    def test_ids_are_strict(self):
        self.assertEqual(ra.parse_admin(("take", "١٢")).report_id, 12)  # Arabic-Indic digits
        for bad in ("0", "-3", "1.5", "abc", "", "9" * 19, "1e3", "+4"):
            with self.subTest(bad), self.assertRaises(CommandError) as cm:
                ra.parse_admin(("take", bad))
            self.assertEqual(cm.exception.code, "report_id")
        with self.assertRaises(CommandError) as cm:
            ra.parse_admin(("take",))
        self.assertEqual(cm.exception.code, "report_id")

    def test_outcomes_types_priorities(self):
        self.assertIs(ra.parse_admin(("resolve", "5")).outcome, ReportOutcome.ACTION_TAKEN)
        self.assertIs(ra.parse_admin(("resolve", "5", "none")).outcome, ReportOutcome.NO_ACTION)
        self.assertIs(ra.parse_admin(("dismiss", "5")).outcome, ReportOutcome.NO_ACTION)
        self.assertIs(ra.parse_admin(("dismiss", "5", "كاذب")).outcome, ReportOutcome.FALSE_REPORT)
        self.assertIs(ra.parse_admin(("type", "5", "احتيال")).report_type, ReportType.SCAM)
        self.assertIs(ra.parse_admin(("priority", "5", "عالية")).priority, ReportPriority.HIGH)
        for args, code in ((("resolve", "5", "false"), "report_outcome"), (("dismiss", "5", "action"), "report_outcome"),
                           (("type", "5", "x"), "report_type"), (("type", "5"), "report_type"),
                           (("priority", "5", "urgent"), "report_priority"), (("priority", "5"), "report_priority"),
                           (("show", "5", "extra"), "report_usage"), (("take", "5", "x"), "report_usage"),
                           (("resolve", "5", "none", "x"), "report_usage"), (("nonsense", "5"), "report_usage"), ((), "report_usage")):
            with self.subTest(args), self.assertRaises(CommandError) as cm:
                ra.parse_admin(args)
            self.assertEqual(cm.exception.code, code)

    def test_every_vocabulary_word_maps_to_a_real_enum_member(self):
        for table, enum_cls in ((ra.TYPE_WORDS, ReportType), (ra.PRIORITY_WORDS, ReportPriority)):
            self.assertEqual(set(table.values()), set(enum_cls))
        self.assertEqual(set(ra.RESOLVE_WORDS.values()), {ReportOutcome.ACTION_TAKEN, ReportOutcome.NO_ACTION})
        self.assertEqual(set(ra.DISMISS_WORDS.values()), {ReportOutcome.NO_ACTION, ReportOutcome.FALSE_REPORT})

    def test_list_args(self):
        self.assertEqual(ra.parse_list(()).status_key, "open")
        self.assertEqual(ra.parse_list(()).statuses, (ReportStatus.OPEN, ReportStatus.TAKEN))
        self.assertIsNone(ra.parse_list(("all",)).statuses)
        self.assertEqual(ra.parse_list(("closed",)).statuses, (ReportStatus.RESOLVED, ReportStatus.DISMISSED))
        self.assertEqual(ra.parse_list(("محسومة", "40")).before_id, 40)
        self.assertEqual(ra.parse_list(("40",)).before_id, 40)
        for bad in (("banana",), ("open", "x"), ("open", "1", "2"), ("open", "0")):
            with self.subTest(bad), self.assertRaises(CommandError):
                ra.parse_list(bad)

    def test_destination_args(self):
        self.assertEqual(ra.parse_destination(("destination",)).op, "show")
        self.assertEqual(ra.parse_destination(("وجهة", "group")).op, "group")
        d = ra.parse_destination(("dest", "-1001234"))
        self.assertEqual((d.op, d.chat_id), ("set", -1001234))
        for bad in (("destination", "1234"), ("destination", "0"), ("destination", "-0"), ("destination", "abc"),
                    ("destination", "-1", "-2"), ("destination", "-" + "9" * 19)):
            with self.subTest(bad), self.assertRaises(CommandError) as cm:
                ra.parse_destination(bad)
            self.assertEqual(cm.exception.code, "report_dest")


class ParserTests(unittest.TestCase):
    def p(self, text, reply=False):
        return parse_command(text, BOT_NAME, has_reply=reply)

    def test_english_forms(self):
        self.assertIs(self.p("/reports").command, Command.REPORTS)
        self.assertIs(self.p("/reports@GuardianBot closed 40").command, Command.REPORTS)
        self.assertIsNone(self.p("/reports@OtherBot"))
        self.assertEqual(self.p("/report take 5").args, ("take", "5"))

    def test_arabic_list_aliases_need_the_commands_own_words(self):
        for text in ("البلاغات", "قائمة البلاغات", "عرض البلاغات", "البلاغات مفتوحة", "البلاغات الكل 30", "البلاغات وجهة", "البلاغات وجهة -1001"):
            with self.subTest(text):
                parsed = self.p(text)
                self.assertIsNotNone(parsed)
                self.assertIs(parsed.command, Command.REPORTS)
                self.assertTrue(parsed.arabic)
        for chat in ("البلاغات كثيرة اليوم", "البلاغات هذا الأسبوع كثيرة", "قائمة البلاغات طويلة جدا"):
            with self.subTest(chat):
                self.assertIsNone(self.p(chat))

    def test_arabic_report_management_needs_action_and_number(self):
        for text, args in (("بلاغ استلام 5", ("استلام", "5")), ("بلاغ حسم 5 بدون", ("حسم", "5", "بدون")),
                           ("ابلاغ نوع 7 سبام", ("نوع", "7", "سبام")), ("بلاغ أولوية 7 عالية", ("أولوية", "7", "عالية"))):
            with self.subTest(text):
                parsed = self.p(text)
                self.assertIs(parsed.command, Command.REPORT)
                self.assertEqual(parsed.args, args)
        for chat in ("بلاغ استلام", "بلاغ عن مشكلة", "بلاغ رفض كل شيء", "بلاغ", "ابلغ المشرفين"):
            with self.subTest(chat):
                self.assertIsNone(self.p(chat))

    def test_a_reply_keeps_the_old_rule(self):
        parsed = self.p("بلاغ استلم هذا", reply=True)  # a reply: always a new report whose words are the reason
        self.assertIs(parsed.command, Command.REPORT)


# ----------------------------------------------------------------------------------------------- service moves
def svc(audit=None):
    return ReportService(InMemoryReportStore(), audit, lambda: NOW)


class ReclassifyTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.audit = InMemorySecurityAudit()
        self.s = svc(self.audit)
        self.r, _ = await self.s.create(A, USER, OTHER, 5, "private words")
        self.other, _ = await self.s.create(B, USER, OTHER, 5)

    async def test_type_and_priority_change_with_audit_of_ids_and_vocabulary_only(self):
        m = await self.s.set_type(A, self.r.id, TG_ADMIN, "scam")
        self.assertEqual((m.code, m.report.report_type), (TransitionCode.OK, ReportType.SCAM))
        m = await self.s.set_priority(A, self.r.id, TG_ADMIN, ReportPriority.HIGH)
        self.assertEqual((m.code, m.report.priority), (TransitionCode.OK, ReportPriority.HIGH))
        rows = [(e.event_type, e.target_id, e.result, e.detail) for e in self.audit.events if e.event_type == REPORT_UPDATED]
        self.assertEqual(rows, [(REPORT_UPDATED, str(self.r.id), "applied", "type=scam"),
                                (REPORT_UPDATED, str(self.r.id), "applied", "priority=high")])
        self.assertNotIn("private", repr(self.audit.events))

    async def test_same_value_is_unchanged_and_silent(self):
        await self.s.set_type(A, self.r.id, TG_ADMIN, "spam")
        n = len(self.audit.events)
        m = await self.s.set_type(A, self.r.id, TG_ADMIN, "spam")
        self.assertEqual(m.code, TransitionCode.UNCHANGED)
        m = await self.s.set_priority(A, self.r.id, TG_ADMIN, "normal")  # the default
        self.assertEqual(m.code, TransitionCode.UNCHANGED)
        self.assertEqual(len(self.audit.events), n)

    async def test_closed_and_foreign_and_invalid(self):
        await self.s.resolve(A, self.r.id, TG_ADMIN)
        self.assertEqual((await self.s.set_type(A, self.r.id, TG_ADMIN, "spam")).code, TransitionCode.CLOSED)
        self.assertEqual((await self.s.set_priority(A, self.r.id, TG_ADMIN, "high")).code, TransitionCode.CLOSED)
        self.assertEqual((await self.s.get(A, self.r.id)).report_type, ReportType.OTHER)
        self.assertEqual((await self.s.set_type(A, self.other.id, TG_ADMIN, "spam")).code, TransitionCode.NOT_FOUND)  # B's report
        self.assertEqual((await self.s.get(B, self.other.id)).report_type, ReportType.OTHER)
        for bad in ("nonsense", None, 5):
            with self.assertRaises(InvalidInput):
                await self.s.set_type(A, self.r.id, TG_ADMIN, bad)
        with self.assertRaises(InvalidInput):
            await self.s.set_priority(A, self.r.id, TG_ADMIN, "urgent")

    async def test_store_refuses_an_unknown_field(self):
        with self.assertRaises(InvalidInput):
            await InMemoryReportStore().set_meta(A, 1, "status", "open", NOW)
        with self.assertRaises(InvalidInput):
            await PostgresReportStore(RecDb(RecConn())).set_meta(A, 1, "reporter_id", "1", NOW)


class PostgresMetaTests(unittest.IsolatedAsyncioTestCase):
    async def test_one_guarded_update_per_field_scoped_by_group(self):
        conn = RecConn(fetchrow=row(report_type="scam"))
        store = PostgresReportStore(RecDb(conn))
        moved = await store.set_meta(A, 4, "report_type", "scam", NOW)
        self.assertEqual(moved.report_type, ReportType.SCAM)
        _, sql, args = conn.log[0]
        self.assertTrue(sql.startswith("UPDATE group_reports SET report_type = $3"))
        self.assertIn("group_id = $1 AND id = $2", sql)
        self.assertIn("status IN ('open', 'taken')", sql)
        self.assertIn("report_type <> $3", sql)
        self.assertEqual(args, (A, 4, "scam", NOW))
        conn2 = RecConn(fetchrow=None)
        self.assertIsNone(await PostgresReportStore(RecDb(conn2)).set_meta(A, 4, "priority", "high", NOW))
        self.assertIn("priority = $3", conn2.log[0][1])
        self.assertNotIn("%", conn2.log[0][1])  # a fixed statement: no interpolated column

    async def test_invalid_value_is_refused_before_any_sql(self):
        conn = RecConn()
        with self.assertRaises(ValueError):
            await PostgresReportStore(RecDb(conn)).set_meta(A, 1, "priority", "urgent", NOW)
        self.assertEqual(conn.log, [])


# ----------------------------------------------------------------------------------------------- commands
class MgmtBase(ExecBase):
    async def asyncSetUp(self):
        self.reports_store = InMemoryReportStore()
        await super().asyncSetUp()
        self.s.chat.set(A, ADMIN2, ChatMemberInfo("administrator", True, True, True))
        self.msg = 100

    def make_service(self, claims):
        self.reports = ReportService(self.reports_store, self.s.audit, self.s.clock)
        return ModerationCommandService(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions,
            settings_store=self.s.settings_store, actions=self.actions, chat_info=self.s.chat, claims=claims,
            audit=self.s.audit, bot_id=BOT, clock=self.s.clock, group_settings=self.s.settings, reports=self.reports)

    async def rc(self, text, *, actor=TG_ADMIN, chat=A, reply_to=None, protection="default", msg=None, lang="ar"):
        parsed = parse_command(text, BOT_NAME, has_reply=reply_to is not None)
        assert parsed is not None, text
        self.msg += 1
        prot = gate(chat, actor) if protection == "default" else protection
        reply = ReplyInfo(reply_to, message_id=9) if reply_to is not None else None
        return await self.svc.handle(parsed, chat_id=chat, actor_id=actor, message_id=msg or self.msg, protection=prot,
                                     reply=reply, language=lang)

    async def file(self, n=1, group=A, reason="spam links"):
        out = []
        for i in range(n):
            r, _ = await self.reports.create(group, USER, OTHER + i, 70 + i, reason)
            out.append(r)
            self.s.clock.advance(seconds=1)
        return out

    def types(self):
        return [e.event_type for e in self.s.audit.events]


class AccessTests(MgmtBase):
    COMMANDS = ("/reports", "/reports all", "/report show 1", "/report take 1", "/report resolve 1", "/report dismiss 1",
                "/report type 1 spam", "/report priority 1 high", "/reports destination", "/reports destination group")

    async def test_a_member_is_denied_everything_and_nothing_changes(self):
        await self.file()
        for text in self.COMMANDS:
            with self.subTest(text):
                res = await self.rc(text, actor=STRANGER)
                self.assertIs(res.kind, R.DENIED, text)
                self.assertEqual(res.text, t("permission_denied", "ar"))
        self.assertEqual((await self.reports.get(A, 1)).status, ReportStatus.OPEN)
        self.assertIn(COMMAND_REJECTED, self.types())

    async def test_an_admin_without_restrict_right_and_the_backup_owner_are_denied(self):
        self.s.chat.set(A, TG_LIMITED_ADMIN, ChatMemberInfo("administrator", True, False, True))
        for who in (TG_LIMITED_ADMIN, BACKUP):
            res = await self.rc("/report take 1", actor=who)
            self.assertIs(res.kind, R.DENIED, who)

    async def test_permission_is_checked_before_the_license_and_before_parsing(self):
        res = await self.rc("/report take banana", actor=STRANGER, protection=gate(A, STRANGER, allowed=False))
        self.assertIs(res.kind, R.DENIED)  # no hint about the vocabulary, no license detail for a non-moderator

    async def test_license_off_blocks_every_command_and_writes_nothing(self):
        await self.file()
        off = gate(A, TG_ADMIN, allowed=False)
        for text in self.COMMANDS:
            with self.subTest(text):
                res = await self.rc(text, protection=off)
                self.assertIs(res.kind, R.LICENSE_OFF, text)
        self.assertEqual((await self.reports.get(A, 1)).status, ReportStatus.OPEN)
        self.assertIsNone(await self.s.settings_store.get(A))
        self.assertNotIn("report_taken", self.types())

    async def test_a_gate_for_another_chat_is_not_accepted(self):
        res = await self.rc("/reports", protection=gate(B, TG_ADMIN))
        self.assertIs(res.kind, R.LICENSE_OFF)
        res = await self.rc("/reports", protection=None)
        self.assertIs(res.kind, R.LICENSE_OFF)

    async def test_owner_and_group_admins_may_manage_but_only_in_their_own_group(self):
        await self.file()
        for who in (OWNER, TG_CREATOR, TG_ADMIN, ADMIN2):
            res = await self.rc("/report show 1", actor=who)
            self.assertIs(res.kind, R.INFO, who)
        self.s.chat.set(B, ADMIN2, ChatMemberInfo("member"))
        res = await self.rc("/reports", actor=ADMIN2, chat=B)
        self.assertIs(res.kind, R.DENIED)

    async def test_without_a_report_service_it_fails_safe(self):
        svc2 = ModerationCommandService(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions,
            settings_store=self.s.settings_store, actions=self.actions, chat_info=self.s.chat, claims=self.claims,
            audit=self.s.audit, bot_id=BOT, clock=self.s.clock, group_settings=self.s.settings)
        res = await svc2.handle(parse_command("/reports", BOT_NAME), chat_id=A, actor_id=TG_ADMIN, message_id=5,
                                protection=gate(A, TG_ADMIN))
        self.assertIs(res.kind, R.ERROR)


class ListShowTests(MgmtBase):
    async def test_empty_list(self):
        res = await self.rc("/reports")
        self.assertIs(res.kind, R.INFO)
        self.assertIn("لا توجد بلاغات", res.text)
        self.assertIsNone(res.redirect_chat_id)

    async def test_newest_first_with_filters_and_without_reasons(self):
        r1, r2, r3 = await self.file(3, reason="SECRET-REASON")
        await self.reports.take(A, r2.id, TG_ADMIN)
        await self.reports.dismiss(A, r3.id, TG_ADMIN, "false_report")
        res = await self.rc("/reports")
        ids = [int(x) for x in re.findall(r"#(\d+)", res.text)]
        self.assertEqual(ids, [r2.id, r1.id])  # open + taken, newest first, the dismissed one is not listed
        self.assertNotIn("SECRET-REASON", res.text)
        self.assertIn(f"<code>{OTHER + 1}</code>", res.text)
        self.assertEqual([int(x) for x in re.findall(r"#(\d+)", (await self.rc("/reports all")).text)], [3, 2, 1])
        self.assertEqual([int(x) for x in re.findall(r"#(\d+)", (await self.rc("/reports taken")).text)], [2])
        self.assertEqual([int(x) for x in re.findall(r"#(\d+)", (await self.rc("/reports dismissed")).text)], [3])
        self.assertEqual([int(x) for x in re.findall(r"#(\d+)", (await self.rc("البلاغات مرفوضة")).text)], [3])
        self.assertIn("(2)", (await self.rc("/reports")).text)  # the count header

    async def test_paging(self):
        await self.file(13)
        first = await self.rc("/reports")
        self.assertEqual(len(re.findall(r"<b>#\d+</b>", first.text)), 10)
        self.assertIn("/reports open 4", first.text)  # the hint carries the last shown id
        second = await self.rc("/reports open 4")
        self.assertEqual([int(x) for x in re.findall(r"<b>#(\d+)</b>", second.text)], [3, 2, 1])
        self.assertNotIn("للمزيد", second.text)

    async def test_other_groups_reports_never_appear(self):
        await self.file(2, group=B)
        res = await self.rc("/reports all")
        self.assertIn("لا توجد بلاغات", res.text)
        res = await self.rc("/report show 1")
        self.assertIs(res.kind, R.INVALID)
        self.assertIn("#1", res.text)
        self.assertNotIn(str(OTHER), res.text)

    async def test_show_details_escape_the_reporters_words(self):
        (r,) = await self.file(1, reason="<b>bad</b> & <a href='x'>x</a>")
        res = await self.rc(f"/report show {r.id}")
        self.assertIs(res.kind, R.INFO)
        self.assertEqual(res.target_id, OTHER)
        self.assertIn("&lt;b&gt;bad&lt;/b&gt;", res.text)
        self.assertNotIn("<b>bad</b>", res.text)
        self.assertNotIn("<a href='x'>", res.text)
        self.assertIn(f"<code>{USER}</code>", res.text)
        self.assertIn("https://t.me/c/1/70", res.text)  # the reported message's link (A = -1001)
        self.assertIn("2026-10-29 15:00", res.text)  # 12:00 UTC shown in Asia/Riyadh

    async def test_show_a_handled_report_names_who_and_the_outcome(self):
        (r,) = await self.file(1)
        await self.reports.resolve(A, r.id, ADMIN2, "no_action")
        res = await self.rc(f"/report show {r.id}")
        self.assertIn(f"<code>{ADMIN2}</code>", res.text)
        self.assertIn("بلا إجراء", res.text)
        res = await self.rc(f"/report show {r.id}", lang="en")
        self.assertIn("no action", res.text)

    async def test_show_a_taken_report_names_the_holder(self):
        (r,) = await self.file(1)
        await self.reports.take(A, r.id, ADMIN2)
        self.assertIn(f"المسؤول: <code>{ADMIN2}</code>", (await self.rc(f"/report show {r.id}")).text)

    async def test_english_output(self):
        await self.file(1)
        res = await self.rc("/reports", lang="en")
        self.assertIn("Reports — open", res.text)
        self.assertNotRegex(res.text, "[؀-ۿ]")


class ChangeTests(MgmtBase):
    async def test_take_resolve_flow_with_audit(self):
        (r,) = await self.file(1)
        res = await self.rc(f"/report take {r.id}")
        self.assertIs(res.kind, R.DONE)
        self.assertEqual((await self.reports.get(A, r.id)).assigned_to, TG_ADMIN)
        res = await self.rc(f"/report resolve {r.id}")
        self.assertIs(res.kind, R.DONE)
        self.assertIn("تم اتخاذ إجراء", res.text)
        got = await self.reports.get(A, r.id)
        self.assertEqual((got.status, got.outcome, got.handled_by), (ReportStatus.RESOLVED, ReportOutcome.ACTION_TAKEN, TG_ADMIN))
        self.assertEqual([x for x in self.types() if x.startswith("report_")], ["report_taken", "report_resolved"])
        self.assertEqual(self.actions.calls, [])  # closing a report never sanctions anyone

    async def test_dismiss_outcomes(self):
        a, b = await self.file(2)
        self.assertIs((await self.rc(f"/report dismiss {a.id} false")).kind, R.DONE)
        self.assertIs((await self.rc(f"/report dismiss {b.id}")).kind, R.DONE)
        self.assertEqual((await self.reports.get(A, a.id)).outcome, ReportOutcome.FALSE_REPORT)
        self.assertEqual((await self.reports.get(A, b.id)).outcome, ReportOutcome.NO_ACTION)

    async def test_arabic_words_do_the_same(self):
        r1, r2, r3 = await self.file(3)
        self.assertIs((await self.rc(f"بلاغ استلام {r1.id}")).kind, R.DONE)
        self.assertIs((await self.rc(f"بلاغ حسم {r1.id} بدون")).kind, R.DONE)
        self.assertIs((await self.rc(f"بلاغ رفض {r2.id} كاذب")).kind, R.DONE)
        self.assertIs((await self.rc(f"بلاغ نوع {r3.id} احتيال")).kind, R.DONE)
        self.assertIs((await self.rc(f"بلاغ اولوية {r3.id} عالية")).kind, R.DONE)
        self.assertEqual((await self.reports.get(A, r1.id)).outcome, ReportOutcome.NO_ACTION)
        self.assertEqual((await self.reports.get(A, r2.id)).outcome, ReportOutcome.FALSE_REPORT)
        got = await self.reports.get(A, r3.id)
        self.assertEqual((got.report_type, got.priority), (ReportType.SCAM, ReportPriority.HIGH))

    async def test_type_and_priority(self):
        (r,) = await self.file(1)
        self.assertIn("احتيال", (await self.rc(f"/report type {r.id} scam")).text)
        self.assertIn("عالية", (await self.rc(f"/report priority {r.id} high")).text)
        self.assertEqual([x for x in self.types() if x == REPORT_UPDATED], [REPORT_UPDATED] * 2)
        res = await self.rc(f"/report type {r.id} scam")
        self.assertIs(res.kind, R.NOOP)
        self.assertEqual(self.types().count(REPORT_UPDATED), 2)  # nothing new audited

    async def test_conflicts_are_reported_not_applied(self):
        (r,) = await self.file(1)
        await self.rc(f"/report take {r.id}", actor=TG_ADMIN)
        res = await self.rc(f"/report take {r.id}", actor=ADMIN2)
        self.assertIs(res.kind, R.INVALID)
        self.assertIn(f"<code>{TG_ADMIN}</code>", res.text)
        self.assertEqual((await self.reports.get(A, r.id)).assigned_to, TG_ADMIN)
        res = await self.rc(f"/report take {r.id}", actor=TG_ADMIN)  # the holder again
        self.assertIs(res.kind, R.NOOP)
        await self.rc(f"/report dismiss {r.id}", actor=ADMIN2)
        res = await self.rc(f"/report resolve {r.id}")
        self.assertIs(res.kind, R.INVALID)
        self.assertIn("مغلق", res.text)
        res = await self.rc(f"/report priority {r.id} high")
        self.assertIs(res.kind, R.INVALID)
        self.assertEqual((await self.reports.get(A, r.id)).priority, ReportPriority.NORMAL)

    async def test_a_missing_or_foreign_report_changes_nothing(self):
        (foreign,) = await self.file(1, group=B)
        for text in (f"/report take {foreign.id}", "/report resolve 999", "/report type 999 spam", "/report priority 999 low"):
            with self.subTest(text):
                res = await self.rc(text)
                self.assertIs(res.kind, R.INVALID)
        self.assertEqual((await self.reports.get(B, foreign.id)).status, ReportStatus.OPEN)
        self.assertNotIn("report_taken", self.types())

    async def test_bad_arguments_are_invalid_and_never_claim_or_write(self):
        (r,) = await self.file(1)
        keys = dict(self.claims._keys)
        for text in ("/report take", "/report take abc", "/report take 1 2", "/report type 1 nope", "/report priority 1",
                     "/report resolve 1 false", "/report dismiss 1 action", "/reports banana", "/reports open x",
                     "/reports destination 1234"):
            with self.subTest(text):
                res = await self.rc(text)
                self.assertIs(res.kind, R.INVALID, text)
                self.assertTrue(res.text)
        self.assertEqual(self.claims._keys, keys)
        self.assertEqual((await self.reports.get(A, r.id)).status, ReportStatus.OPEN)

    async def test_a_redelivered_update_acts_once(self):
        (r,) = await self.file(1)
        first = await self.rc(f"/report take {r.id}", msg=555)
        again = await self.rc(f"/report take {r.id}", msg=555)
        self.assertIs(first.kind, R.DONE)
        self.assertIs(again.kind, R.DUPLICATE)
        self.assertEqual(again.text, "")
        self.assertEqual(self.types().count("report_taken"), 1)

    async def test_a_claim_store_failure_changes_nothing(self):
        (r,) = await self.file(1)
        self.svc = self.make_service(BrokenClaims())
        res = await self.rc(f"/report take {r.id}")
        self.assertIs(res.kind, R.ERROR)
        self.assertEqual((await self.reports.get(A, r.id)).status, ReportStatus.OPEN)

    async def test_it_works_in_dry_run_because_nothing_is_sanctioned(self):
        (r,) = await self.file(1)
        await self.settings(dry_run=True)
        self.assertIs((await self.rc(f"/report take {r.id}")).kind, R.DONE)

    async def test_two_admins_racing_exactly_one_takes_it(self):
        (r,) = await self.file(1)
        import asyncio
        a, b = await asyncio.gather(self.rc(f"/report take {r.id}", actor=TG_ADMIN), self.rc(f"/report take {r.id}", actor=ADMIN2))
        self.assertEqual(sorted([a.kind.value, b.kind.value]), ["done", "invalid"])


class ReplyStaysAReportTests(MgmtBase):
    """A `/report` that is a reply is ALWAYS a new report: management words in it are just the reason."""

    async def setUp_admins(self):
        self.s.chat.admins[A] = [adm(TG_CREATOR, "Boss", creator=True), adm(TG_ADMIN, "Alice"), adm(BOT, "GuardianBot", bot=True)]

    async def test_a_reply_with_management_words_files_a_report(self):
        await self.setUp_admins()
        res = await self.rc("/report take 5", actor=USER, reply_to=OTHER)
        self.assertIs(res.kind, R.DONE)
        self.assertIn("take 5", res.text)
        rows = await self.reports.list_reports(A)
        self.assertEqual((len(rows), rows[0].reason, rows[0].status), (1, "take 5", ReportStatus.OPEN))

    async def test_a_plain_report_without_reply_still_asks_for_a_reply(self):
        for text in ("/report", "/report please look"):
            res = await self.rc(text, actor=USER)
            self.assertIs(res.kind, R.INVALID)
            self.assertIn("ردّ على رسالة", res.text)

    async def test_a_member_cannot_manage_by_typing_the_words(self):
        await self.file()
        res = await self.rc("/report take 1", actor=USER)
        self.assertIs(res.kind, R.DENIED)
        res = await self.rc("بلاغ حسم 1", actor=USER)
        self.assertIs(res.kind, R.DENIED)
        self.assertEqual((await self.reports.get(A, 1)).status, ReportStatus.OPEN)


# ----------------------------------------------------------------------------------------------- destination
class DestinationTests(MgmtBase):
    async def raw(self, group=A):
        row_ = await self.s.settings_store.get(group)
        return dict(row_.settings) if row_ is not None else {}

    def test_destination_of_is_strict(self):
        self.assertEqual(destination_of({DESTINATION_KEY: DEST}, A), DEST)
        for bad in (None, 0, 5, True, "x", -1.5, [DEST], {}, 2 ** 63, -(2 ** 63) - 1):
            self.assertEqual(destination_of({DESTINATION_KEY: bad}, A), A, bad)
        for raw in (None, "x", [], {}):
            self.assertEqual(destination_of(raw, A), A)

    def test_it_is_not_a_template_key_and_never_part_of_effective_settings(self):
        self.assertNotIn(DESTINATION_KEY, TEMPLATE_KEYS)
        self.assertNotIn(DESTINATION_KEY, effective_settings({DESTINATION_KEY: DEST}))

    def test_the_permission_is_owner_only(self):
        self.assertIn(Permission.REPORT_DESTINATION, OWNER_ONLY)

    async def test_show_defaults_to_the_group(self):
        res = await self.rc("/reports destination")
        self.assertIs(res.kind, R.INFO)
        self.assertIn("هذه المجموعة نفسها", res.text)

    async def test_only_the_primary_owner_can_change_it(self):
        for who in (TG_ADMIN, TG_CREATOR, ADMIN2, BACKUP, STRANGER):
            res = await self.rc(f"/reports destination {DEST}", actor=who)
            self.assertIs(res.kind, R.DENIED, who)
        self.assertIsNone(await self.s.settings_store.get(A))
        self.assertNotIn(REPORT_DESTINATION_SET, self.types())

    async def test_the_owner_approves_then_everyone_sees_it(self):
        res = await self.rc(f"/reports destination {DEST}", actor=OWNER)
        self.assertIs(res.kind, R.DONE)
        self.assertEqual((await self.raw())[DESTINATION_KEY], DEST)
        shown = await self.rc("/reports destination", actor=TG_ADMIN)
        self.assertIn(str(DEST), shown.text)
        ev = [e for e in self.s.audit.events if e.event_type == REPORT_DESTINATION_SET]
        self.assertEqual([(e.actor_telegram_id, e.group_id, e.target_id, e.result, e.detail) for e in ev],
                         [(OWNER, A, str(DEST), "applied", f"destination={DEST}")])
        changed = [e.detail for e in self.s.audit.events if e.event_type == SETTINGS_CHANGED]
        self.assertEqual(changed, [f"keys={DESTINATION_KEY}"])  # key names only

    async def test_clearing_and_the_group_itself_are_the_same(self):
        await self.rc(f"/reports destination {DEST}", actor=OWNER)
        res = await self.rc("/reports destination group", actor=OWNER)
        self.assertIs(res.kind, R.DONE)
        self.assertEqual(destination_of(await self.raw(), A), A)
        self.assertIs((await self.rc("/reports destination group", actor=OWNER)).kind, R.NOOP)
        await self.rc(f"/reports destination {DEST}", actor=OWNER)
        self.assertIs((await self.rc(f"/reports destination {A}", actor=OWNER)).kind, R.DONE)  # this very chat = group
        self.assertEqual(destination_of(await self.raw(), A), A)

    async def test_same_destination_is_a_noop_without_audit(self):
        await self.rc(f"/reports destination {DEST}", actor=OWNER)
        n = self.types().count(REPORT_DESTINATION_SET)
        self.assertIs((await self.rc(f"/reports destination {DEST}", actor=OWNER)).kind, R.NOOP)
        self.assertEqual(self.types().count(REPORT_DESTINATION_SET), n)

    async def test_an_unreachable_chat_is_refused(self):
        for info in (ChatMemberInfo("left"), ChatMemberInfo("kicked"), ChatMemberInfo("unknown")):
            self.s.chat.set(DEST, BOT, info)
            res = await self.rc(f"/reports destination {DEST}", actor=OWNER)
            self.assertIs(res.kind, R.INVALID, info.status)
        self.s.chat.set(DEST, BOT, ChatMemberInfo("member"))
        self.s.chat.fail = True
        self.assertIs((await self.rc(f"/reports destination {DEST}", actor=OWNER)).kind, R.INVALID)
        self.assertIsNone(await self.s.settings_store.get(A))

    async def test_a_redelivered_change_writes_once(self):
        first = await self.rc(f"/reports destination {DEST}", actor=OWNER, msg=900)
        again = await self.rc(f"/reports destination {DEST}", actor=OWNER, msg=900)
        self.assertIs(first.kind, R.DONE)
        self.assertIs(again.kind, R.DUPLICATE)
        self.assertEqual(self.types().count(REPORT_DESTINATION_SET), 1)

    async def test_it_is_per_group(self):
        await self.rc(f"/reports destination {DEST}", actor=OWNER)
        self.assertIn("هذه المجموعة نفسها", (await self.rc("/reports destination", actor=OWNER, chat=B)).text)

    async def test_listings_and_details_go_to_the_destination_but_confirmations_stay(self):
        (r,) = await self.file(1, reason="private words")
        await self.rc(f"/reports destination {DEST}", actor=OWNER)
        listing = await self.rc("/reports")
        self.assertEqual(listing.redirect_chat_id, DEST)
        self.assertIn(f"#{r.id}", listing.text)
        details = await self.rc(f"/report show {r.id}")
        self.assertEqual(details.redirect_chat_id, DEST)
        self.assertIn("private words", details.text)
        empty = await self.rc("/reports closed")
        self.assertEqual(empty.redirect_chat_id, DEST)  # even "nothing" goes there: the group learns nothing
        for text in (f"/report take {r.id}", f"/report type {r.id} spam", f"/report priority {r.id} low", "/reports destination",
                     f"/report show {r.id + 50}"):
            res = await self.rc(text)
            self.assertIsNone(res.redirect_chat_id, text)
            self.assertNotIn("private words", res.text)

    async def test_an_unreadable_setting_lists_nothing(self):
        (r,) = await self.file(1, reason="private words")
        real = self.s.settings_store.get

        async def boom(group):
            raise RuntimeError("db down")
        self.s.settings_store.get = boom
        try:
            for text in ("/reports", f"/report show {r.id}", "/reports destination"):
                res = await self.rc(text)
                self.assertIs(res.kind, R.ERROR, text)
                self.assertNotIn("private words", res.text)
                self.assertIsNone(res.redirect_chat_id)
        finally:
            self.s.settings_store.get = real

    async def test_a_corrupt_stored_value_falls_back_to_the_group(self):
        await self.file(1)
        await self.settings(**{DESTINATION_KEY: 12345})  # positive: a user id, never a destination
        res = await self.rc("/reports")
        self.assertIsNone(res.redirect_chat_id)
        await self.settings(**{DESTINATION_KEY: "-100777"})
        self.assertIsNone((await self.rc("/reports")).redirect_chat_id)

    async def test_a_template_apply_cannot_carry_a_destination(self):
        # the keys a template may write are exactly TEMPLATE_KEYS: the destination is none of them
        self.assertTrue(set(TEMPLATE_KEYS).isdisjoint({DESTINATION_KEY}))


# ----------------------------------------------------------------------------------------------- handler redirect
class FakeBotSender:
    def __init__(self, fail=False):
        self.sent, self.fail = [], fail

    async def send_message(self, chat_id, text, **kw):
        if self.fail:
            raise RuntimeError("forbidden")
        self.sent.append((chat_id, text))


class HandlerTests(MgmtBase):
    async def go(self, text, *, sender=TG_ADMIN, fail=False, fail_reply=False):
        msg = Msg(text, chat=A, sender=sender, mid=self.next_mid())
        msg.bot = FakeBotSender(fail)
        msg.fail_reply = fail_reply
        parsed = parse_command(text, BOT_NAME, has_reply=False)
        services = NS(moderation_commands=self.svc, settings=NS(default_language="ar"), panel=None)
        res = await h.execute(msg, parsed, protection=gate(A, sender), services=services)
        return msg, res

    def next_mid(self):
        self.msg += 1
        return self.msg

    async def test_without_a_destination_the_answer_stays_in_the_group(self):
        await self.file(1)
        msg, _ = await self.go("/reports")
        self.assertEqual(len(msg.replies), 1)
        self.assertIn("#1", msg.replies[0])
        self.assertEqual(msg.bot.sent, [])

    async def test_with_a_destination_the_content_goes_there_and_the_group_gets_a_notice(self):
        await self.file(1, reason="private words")
        await self.rc(f"/reports destination {DEST}", actor=OWNER)
        msg, _ = await self.go("/report show 1")
        self.assertEqual([c for c, _ in msg.bot.sent], [DEST])
        self.assertIn("private words", msg.bot.sent[0][1])
        self.assertEqual(msg.replies, [t("report_dest_sent", "ar")])
        self.assertNotIn("private words", "".join(msg.replies))

    async def test_a_failed_send_never_falls_back_to_the_group(self):
        await self.file(1, reason="private words")
        await self.rc(f"/reports destination {DEST}", actor=OWNER)
        msg, _ = await self.go("/reports", fail=True)
        self.assertEqual(msg.replies, [t("report_dest_failed", "ar")])
        self.assertNotIn("private words", "".join(msg.replies))
        self.assertNotIn("#1", "".join(msg.replies))

    async def test_a_failing_notice_reply_never_raises(self):
        await self.file(1)
        await self.rc(f"/reports destination {DEST}", actor=OWNER)
        msg, res = await self.go("/reports", fail_reply=True)
        self.assertIs(res.kind, R.INFO)
        self.assertEqual(len(msg.bot.sent), 1)


# ----------------------------------------------------------------------------------------------- guards / wiring
class StaticTests(unittest.TestCase):
    def test_no_framework_no_listing_of_all_groups_no_direct_sending(self):
        for name in ("commands.py", "args.py", "destination.py"):
            text = (SRC / "reports" / name).read_text(encoding="utf-8")
            self.assertNotRegex(text, r"(?m)^\s*(from|import) (aiogram|asyncpg|fastapi)", name)
            self.assertNotIn("list_all", text, name)
            self.assertNotIn("send_message", text, name)  # the command layer never talks to Telegram: the handler does
            self.assertNotIn("owner_hub", text, name)

    def test_the_handler_is_the_only_sender_to_a_destination_and_uses_the_result_field_only(self):
        text = (SRC / "bot" / "moderation_handler.py").read_text(encoding="utf-8")
        self.assertEqual(text.count("send_message("), 1)
        self.assertIn("result.redirect_chat_id", text)

    def test_all_the_report_keys_exist_in_both_languages_with_the_same_placeholders(self):
        ar, en = MESSAGES["ar"], MESSAGES["en"]
        self.assertEqual(set(ar), set(en))
        used = set(re.findall(r'\bt\("([a-z_]+)"', (SRC / "reports" / "commands.py").read_text(encoding="utf-8")))
        used |= {f"report_{kind}_{v.value}" for kind, enum_cls in (("status", ReportStatus), ("type", ReportType),
                                                                    ("prio", ReportPriority), ("outcome", ReportOutcome))
                 for v in enum_cls}
        used |= {f"report_filter_{k}" for k in ("open", "taken", "resolved", "dismissed", "closed", "all")}
        used |= {"mod_err_report_" + c for c in ("usage", "id", "type", "priority", "outcome", "status", "dest")}
        used |= {"report_dest_sent", "report_dest_failed"}
        self.assertGreater(len(used), 40)
        for key in used:
            with self.subTest(key):
                self.assertIn(key, ar)
                self.assertEqual(sorted(re.findall(r"\{(\w+)\}", ar[key])), sorted(re.findall(r"\{(\w+)\}", en[key])), key)

    def test_error_codes_all_have_localized_messages(self):
        from guardian.moderation.messages import error_message
        for code in ("report_usage", "report_id", "report_type", "report_priority", "report_outcome", "report_status", "report_dest"):
            for lang in ("ar", "en"):
                self.assertTrue(error_message(CommandError(code), lang), (code, lang))

    def test_the_help_and_the_menu_mention_the_commands_without_breaking_html(self):
        for lang in ("ar", "en"):
            text = t("help", lang)
            self.assertIn("/reports", text)
            self.assertNotIn("<", text)  # the help is sent as HTML: no stray angle brackets
        self.assertIn("reports", commands_menu.MODERATION)
        self.assertNotIn("reports", commands_menu.PUBLIC)
        for lang in ("ar", "en"):
            self.assertIn("reports", commands_menu.DESCRIPTIONS[lang])
        for spec in commands_menu.build_menus():
            names = [n for n, _ in spec.commands]
            self.assertEqual("reports" in names, spec.scope == "all_chat_administrators")
            self.assertTrue(all(len(d) <= 256 for _, d in spec.commands))

    def test_report_is_still_public_and_reports_is_not(self):
        from guardian.moderation.commands import PUBLIC
        self.assertIn(Command.REPORT, PUBLIC)
        self.assertNotIn(Command.REPORTS, PUBLIC)


if __name__ == "__main__":
    unittest.main()
