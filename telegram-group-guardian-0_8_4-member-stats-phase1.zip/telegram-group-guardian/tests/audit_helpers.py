"""Import side effect only: make sure no secrets registered by another test leak into this one."""
from guardian.audit import register_secrets

register_secrets(())
