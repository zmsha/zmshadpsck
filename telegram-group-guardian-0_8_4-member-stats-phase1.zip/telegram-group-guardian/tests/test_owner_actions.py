"""Phase 5 / part 5.4: LICENSE ACTIONS from the owner panel -- signed action callbacks, the action table, the views, the server
side flow (stale guard, one claim per press, confirmation, every refusal) and the aiogram-free glue. aiogram/FastAPI/PostgreSQL
are NOT exercised (not installable in the build sandbox): the real `LicenseAdminService`, `PermissionService`, stores and claims
are used in memory; the router is checked statically."""
from __future__ import annotations

import re
import unittest
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace as NS

import helpers  # noqa: F401
from guardian.audit import FORGED_CALLBACK, LICENSE_ACTION_REJECTED
from guardian.bot import owner_panel_handler as h
from guardian.errors import ConcurrentModification, GroupNotRegistered, InvalidInput, InvalidTransition, PermissionDenied
from guardian.i18n import MESSAGES, t
from guardian.idempotency import InMemoryIdempotency, operation_key
from guardian.licensing import admin as admin_mod
from guardian.licensing.admin import MAX_LICENSE_HORIZON
from guardian.licensing.memory_store import InMemoryLicenseStore
from guardian.licensing.models import GroupLicense, LicenseStatus as S
from guardian.owner_panel import actions as act, codec, views
from guardian.owner_panel.actions import OwnerActions
from guardian.owner_panel.service import OwnerPanelService
from guardian.time_utils import format_display
from stack import A, B, BACKUP, DELEGATE, NOW, OWNER, STRANGER, TG_ADMIN, TG_CREATOR, Stack

SRC = Path(__file__).resolve().parents[1] / "src" / "guardian"
SECRET = "owner-actions-test-secret-0123456789"
KEY = codec.derive_key(SECRET)
TZ = "Asia/Riyadh"
ALL_STATUSES = list(S)


def build(screen, chat=OWNER, **kw):
    return codec.build(KEY, chat, screen, **kw)


def do(code, status, gid=A, chat=OWNER, filt="a", page=0):
    return build(codec.DO, chat, action=code, status=status, group_id=gid, filter=filt, page=page)


def ask(code, status, gid=A, chat=OWNER, filt="a", page=0):
    return build(codec.ASK, chat, action=code, status=status, group_id=gid, filter=filt, page=page)


def flat(outcome_or_buttons):
    buttons = getattr(outcome_or_buttons, "buttons", outcome_or_buttons) or ()
    return [b for row in buttons for b in row]


def parsed_buttons(outcome_or_buttons):
    return [(label, codec.parse(data)) for label, data in flat(outcome_or_buttons)]


def button(outcome_or_buttons, screen, action=None):
    for label, cb in parsed_buttons(outcome_or_buttons):
        if cb.screen == screen and (action is None or cb.action == action):
            return next(d for l, d in flat(outcome_or_buttons) if l == label and codec.parse(d) == cb)
    raise AssertionError(f"no {screen}/{action} button in {[(l, c.screen, c.action) for l, c in parsed_buttons(outcome_or_buttons)]}")


def has_button(outcome_or_buttons, screen, action=None):
    return any(cb.screen == screen and (action is None or cb.action == action) for _, cb in parsed_buttons(outcome_or_buttons))


# ----------------------------------------------------------------------------- codec (new screens)
class CodecActionTests(unittest.TestCase):
    def test_round_trip_of_the_three_new_screens(self):
        for screen, kw in ((codec.MENU, dict(group_id=-1001234567890, filter="p", page=3)),
                           (codec.ASK, dict(group_id=-1001, filter="a", page=0, action="st", status="d")),
                           (codec.DO, dict(group_id=-1001, filter="b", page=9999, action="t365", status="x"))):
            with self.subTest(screen):
                parsed = codec.parse(build(screen, **kw))
                self.assertEqual(parsed.screen, screen)
                self.assertTrue(codec.verify(KEY, OWNER, parsed))
                for field, value in kw.items():
                    self.assertEqual(getattr(parsed, "group_id" if field == "group_id" else field), value, field)

    def test_every_action_and_status_round_trips(self):
        for code in codec.ACTION_CODES:
            for status in codec.STATUS_CODES:
                parsed = codec.parse(do(code, status))
                self.assertEqual((parsed.action, parsed.status), (code, status))
                self.assertTrue(codec.verify(KEY, OWNER, parsed))

    def test_the_signature_binds_screen_action_status_group_filter_page_and_chat(self):
        data = ask("st", "d", gid=-1001, filt="a", page=0)
        tag = data.rsplit(":", 1)[1]
        forged = [f"ow:y:st:d:-1001:a:0:{tag}",    # confirmation screen turned into the executing screen
                  f"ow:a:bn:d:-1001:a:0:{tag}",    # another action
                  f"ow:a:st:p:-1001:a:0:{tag}",    # another expected status
                  f"ow:a:st:d:-1002:a:0:{tag}",    # another group
                  f"ow:a:st:d:-1001:b:0:{tag}", f"ow:a:st:d:-1001:a:1:{tag}", f"ow:a:st:d:-1001:a:0:{'0' * 12}"]
        for data_ in forged:
            parsed = codec.parse(data_)
            self.assertIsNotNone(parsed, data_)
            self.assertFalse(codec.verify(KEY, OWNER, parsed), data_)
        self.assertFalse(codec.verify(KEY, STRANGER, codec.parse(data)))
        menu = build(codec.MENU, group_id=-1001)
        self.assertFalse(codec.verify(KEY, OWNER, codec.parse(menu.replace("ow:m:", "ow:d:"))))

    def test_malformed_action_callbacks_are_rejected(self):
        tag = "a" * 12
        for bad in (f"ow:y:zz:p:-1001:a:0:{tag}", f"ow:y:T1:p:-1001:a:0:{tag}", f"ow:y:st:a:-1001:a:0:{tag}",
                    f"ow:y:st:z:-1001:a:0:{tag}", f"ow:y:st:pp:-1001:a:0:{tag}", f"ow:y:st:p:1001:a:0:{tag}",
                    f"ow:y:st:p:-1001:a:{tag}", f"ow:y:st:p:-1001:a:0:0:{tag}", f"ow:y:st:p:-1001:z:0:{tag}",
                    f"ow:y:st:p:-1001:a:١:{tag}", f"ow:y::p:-1001:a:0:{tag}", f"ow:y:st:p:-0:a:0:{tag}",
                    f"ow:m:-1001:a:{tag}", f"ow:m:-1001:a:0:extra:{tag}", f"ow:m:1001:a:0:{tag}", f"ow:m:-1001:z:0:{tag}",
                    f"ow:a:st:p:-1001:a:0:{tag}\n", f"ow:Y:st:p:-1001:a:0:{tag}"):
            with self.subTest(bad):
                self.assertIsNone(codec.parse(bad))

    def test_longest_action_callback_fits_telegram_limit(self):
        for screen in (codec.ASK, codec.DO):
            data = build(screen, group_id=-(2**63), filter="b", page=codec.MAX_PAGE, action="t365", status="b")
            self.assertLessEqual(len(data.encode()), 64)
            self.assertIsNotNone(codec.parse(data))
        self.assertLessEqual(len(build(codec.MENU, group_id=-(2**63), filter="b", page=codec.MAX_PAGE).encode()), 64)

    def test_build_validation_of_the_new_screens(self):
        good = dict(group_id=-1001, action="st", status="d")
        for screen, bad in ((codec.DO, dict(good, action="zz")), (codec.DO, dict(good, action=None)),
                            (codec.DO, dict(good, status="a")), (codec.DO, dict(good, status="pp")),
                            (codec.DO, dict(good, status=None)), (codec.ASK, dict(good, group_id=None)),
                            (codec.ASK, dict(good, group_id=5)), (codec.ASK, dict(good, group_id=True)),
                            (codec.MENU, dict(group_id=None)), (codec.MENU, dict(group_id=7))):
            with self.subTest((screen, bad)), self.assertRaises(ValueError):
                build(screen, **bad)


# ----------------------------------------------------------------------------- the action table
METHOD_KIND = {"activate_permanent": admin_mod.ACTIVATE_PERMANENT, "activate_temporary": admin_mod.ACTIVATE_TEMPORARY,
               "stop": admin_mod.STOP, "reject": admin_mod.REJECT, "ban": admin_mod.BAN, "unban": admin_mod.UNBAN,
               "allow": admin_mod.ALLOW}


class ActionTableTests(unittest.TestCase):
    def test_specs_match_the_codec_codes(self):
        self.assertEqual(set(act.SPECS), set(codec.ACTION_CODES))
        self.assertEqual(act.DURATION_CODES, ("t1", "t7", "t30", "t90", "t180", "t365"))
        self.assertEqual([act.SPECS[c].days for c in act.DURATION_CODES], [1, 7, 30, 90, 180, 365])
        self.assertLess(max(act.SPECS[c].days for c in act.DURATION_CODES), MAX_LICENSE_HORIZON.days)
        for spec in act.SPECS.values():
            self.assertIn(spec.method, METHOD_KIND)
            self.assertEqual(spec.days is not None, spec.method == "activate_temporary")

    def test_status_codes_cover_every_status_and_agree_with_the_filters(self):
        self.assertEqual(set(act.STATUS_CODE), set(S))
        self.assertEqual(set(act.STATUS_CODE.values()), set(codec.STATUS_CODES))
        self.assertEqual(len(set(act.STATUS_CODE.values())), len(S))
        for status, code in act.STATUS_CODE.items():
            self.assertIs(views.FILTER_STATUS[code], status)

    def test_a_status_never_offers_a_transition_the_admin_service_refuses_or_a_no_op(self):
        self.assertEqual(set(act.ROWS), set(S))
        for status, rows in act.ROWS.items():
            tokens = [tok for row in rows for tok in row]
            self.assertEqual(len(tokens), len(set(tokens)), status)
            for token in tokens:
                codes = act.DURATION_CODES if token == act.MENU else (token,)
                for code in codes:
                    kind = METHOD_KIND[act.SPECS[code].method]
                    self.assertIn(status, admin_mod._ALLOWED_FROM[kind], (status, code))
        flat_ = {st: {tok for row in rows for tok in row} for st, rows in act.ROWS.items()}
        self.assertNotIn("ap", flat_[S.ACTIVE_PERMANENT])       # no-ops are not offered
        self.assertNotIn("st", flat_[S.STOPPED])
        self.assertNotIn("rj", flat_[S.REJECTED])
        self.assertEqual(flat_[S.BANNED], {"ub"})                 # a banned group can only be unbanned
        self.assertEqual(flat_[S.REJECTED], {"al", "bn"})
        for status in (S.REJECTED, S.BANNED):
            self.assertNotIn(act.MENU, flat_[status])             # lift first: no activation from rejected/banned

    def test_confirmation_matrix(self):
        for status in S:
            for code in ("st", "rj", "bn"):
                self.assertTrue(act.needs_confirm(code, status), (code, status))
            for code in ("ub", "al"):
                self.assertFalse(act.needs_confirm(code, status), (code, status))
            for code in ("ap", *act.DURATION_CODES):
                self.assertEqual(act.needs_confirm(code, status), status in (S.ACTIVE_PERMANENT, S.ACTIVE_TEMPORARY),
                                 (code, status))

    def test_texts_exist_in_both_languages(self):
        for lang in ("ar", "en"):
            for code in act.SPECS:
                self.assertTrue(act.name_of(code, lang).strip(), (code, lang))
            for code in ("st", "rj", "bn", "ap"):
                self.assertTrue(act.warning_of(code, lang).strip())
        self.assertNotEqual(act.warning_of("st", "ar"), act.warning_of("bn", "ar"))
        self.assertIn("30 يومًا", act.name_of("t30", "ar"))
        self.assertEqual([act.days_phrase(n, "ar") for n in (1, 7, 30)], ["يوم واحد", "7 أيام", "30 يومًا"])
        self.assertEqual([act.days_phrase(n, "en") for n in (1, 7)], ["1 day", "7 days"])
        labels = {l for l, _ in flat(views.render_duration_menu(lic(), now=NOW, lang="ar", b=b_, filt="a", page=0)[1])}
        self.assertTrue({"يوم واحد", "7 أيام", "30 يومًا", "90 يومًا", "180 يومًا", "365 يومًا"} <= labels)


# ----------------------------------------------------------------------------- pure views
def lic(status=S.PENDING, gid=-1001, title="G", **kw):
    kw.setdefault("updated_at", NOW)
    return GroupLicense(gid, title, status, **kw)


def b_(screen, **kw):
    return codec.build(KEY, OWNER, screen, **kw)


class ViewActionTests(unittest.TestCase):
    def detail(self, row, *, lang="ar", with_actions=True, now=NOW, filt="a", page=0):
        return views.render_detail(row, now=now, tz=TZ, lang=lang, b=b_, filt=filt, page=page, with_actions=with_actions)

    def test_without_actions_the_detail_is_the_old_read_only_layout(self):
        _, buttons = self.detail(lic(), with_actions=False)
        self.assertEqual([len(r) for r in buttons], [1, 2])
        self.assertFalse(any(cb.screen in (codec.DO, codec.ASK, codec.MENU) for _, cb in parsed_buttons(buttons)))

    def test_pending_buttons(self):
        _, buttons = self.detail(lic(S.PENDING))
        got = {(cb.screen, cb.action) for _, cb in parsed_buttons(buttons) if cb.screen in (codec.DO, codec.ASK, codec.MENU)}
        self.assertEqual(got, {(codec.DO, "ap"), (codec.MENU, None), (codec.ASK, "rj"), (codec.ASK, "bn")})
        for _, cb in parsed_buttons(buttons):
            if cb.screen in (codec.DO, codec.ASK):
                self.assertEqual(cb.status, "p")

    def test_active_permanent_and_temporary_buttons_ask_before_replacing_or_stopping(self):
        perm = lic(S.ACTIVE_PERMANENT, activated_at=NOW)
        _, buttons = self.detail(perm)
        got = {(cb.screen, cb.action) for _, cb in parsed_buttons(buttons) if cb.screen in (codec.DO, codec.ASK, codec.MENU)}
        self.assertEqual(got, {(codec.MENU, None), (codec.ASK, "st"), (codec.ASK, "bn")})
        temp = lic(S.ACTIVE_TEMPORARY, activated_at=NOW, expires_at=NOW + timedelta(days=3))
        text, buttons = self.detail(temp)
        got = {(cb.screen, cb.action) for _, cb in parsed_buttons(buttons) if cb.screen in (codec.DO, codec.ASK, codec.MENU)}
        self.assertEqual(got, {(codec.MENU, None), (codec.ASK, "ap"), (codec.ASK, "st"), (codec.ASK, "bn")})
        labels = [l for l, _ in flat(buttons)]
        self.assertIn(t("ow_btn_menu_renew", "ar"), labels)
        self.assertIn(t("ow_btn_make_perm", "ar"), labels)

    def test_rejected_banned_stopped_expired(self):
        def kinds(row, now=NOW):
            _, buttons = self.detail(row, now=now)
            return {(cb.screen, cb.action) for _, cb in parsed_buttons(buttons) if cb.screen in (codec.DO, codec.ASK, codec.MENU)}
        self.assertEqual(kinds(lic(S.REJECTED)), {(codec.DO, "al"), (codec.ASK, "bn")})
        self.assertEqual(kinds(lic(S.BANNED)), {(codec.DO, "ub")})
        self.assertEqual(kinds(lic(S.STOPPED)), {(codec.DO, "ap"), (codec.MENU, None), (codec.ASK, "rj"), (codec.ASK, "bn")})
        expired = lic(S.ACTIVE_TEMPORARY, activated_at=NOW, expires_at=NOW + timedelta(hours=1))
        later = NOW + timedelta(days=2)
        self.assertEqual(kinds(expired, later), {(codec.DO, "ap"), (codec.MENU, None), (codec.ASK, "rj"), (codec.ASK, "bn")})

    def test_buttons_carry_the_effective_status_the_owner_sees(self):
        expired = lic(S.ACTIVE_TEMPORARY, activated_at=NOW, expires_at=NOW + timedelta(hours=1))
        _, buttons = self.detail(expired, now=NOW + timedelta(days=2))
        for _, cb in parsed_buttons(buttons):
            if cb.screen in (codec.DO, codec.ASK):
                self.assertEqual(cb.status, "x")        # stored 'active_temporary', effective 'expired'

    def test_every_action_button_is_signed_for_the_owner_chat_and_the_group(self):
        for status in S:
            row = lic(status, gid=-777, activated_at=NOW, expires_at=NOW + timedelta(days=3)
                      if status is S.ACTIVE_TEMPORARY else None)
            _, buttons = self.detail(row, filt="p", page=4)
            for _, cb in parsed_buttons(buttons):
                self.assertTrue(codec.verify(KEY, OWNER, cb))
                self.assertFalse(codec.verify(KEY, STRANGER, cb))
                if cb.screen in (codec.DO, codec.ASK, codec.MENU):
                    self.assertEqual((cb.group_id, cb.filter, cb.page), (-777, "p", 4))

    def test_duration_menu(self):
        text, buttons = views.render_duration_menu(lic(S.PENDING, title="<b>x</b>"), now=NOW, lang="ar", b=b_, filt="a", page=0)
        self.assertNotIn("<b>x</b>", text)
        self.assertIn("-1001", text)
        self.assertIn("30", text)
        durations = [cb for _, cb in parsed_buttons(buttons) if cb.action]
        self.assertEqual([cb.action for cb in durations], list(act.DURATION_CODES))
        self.assertTrue(all(cb.screen == codec.DO and cb.status == "p" for cb in durations))   # nothing active: no confirmation
        self.assertEqual([len(r) for r in buttons], [2, 2, 2, 2])
        active = lic(S.ACTIVE_TEMPORARY, activated_at=NOW, expires_at=NOW + timedelta(days=1))
        _, buttons = views.render_duration_menu(active, now=NOW, lang="en", b=b_, filt="a", page=0)
        durations = [cb for _, cb in parsed_buttons(buttons) if cb.action]
        self.assertTrue(all(cb.screen == codec.ASK and cb.status == "t" for cb in durations))  # replacing an active license
        back = [cb for _, cb in parsed_buttons(buttons) if cb.screen == codec.DETAIL]
        self.assertEqual(len(back), 1)

    def test_confirmation_screen(self):
        row = lic(S.ACTIVE_PERMANENT, title="<i>g</i>", activated_at=NOW)
        for lang in ("ar", "en"):
            text, buttons = views.render_confirm(row, "st", now=NOW, lang=lang, b=b_, filt="a", page=2)
            self.assertNotIn("<i>g</i>", text)
            self.assertIn(act.warning_of("st", lang), text)
            self.assertIn(act.name_of("st", lang), text)
            yes = [cb for _, cb in parsed_buttons(buttons) if cb.screen == codec.DO]
            self.assertEqual([(c.action, c.status, c.group_id, c.page) for c in yes], [("st", "d", -1001, 2)])
            self.assertEqual(len([1 for _, cb in parsed_buttons(buttons) if cb.screen == codec.DETAIL]), 1)
            self.assertEqual(len([1 for _, cb in parsed_buttons(buttons) if cb.screen == codec.CLOSE]), 1)


# ----------------------------------------------------------------------------- server flow
class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        self.claims = InMemoryIdempotency()
        self.actions = OwnerActions(license_admin=self.s.admin, licenses=self.s.licenses, claims=self.claims,
                                    clock=self.s.clock)
        self.svc = self.make()
        await self.s.register(A, B)
        self.n = 0

    def make(self, **kw):
        kw.setdefault("actions", self.actions)
        kw.setdefault("licenses", self.s.licenses)
        return OwnerPanelService(permissions=self.s.perm, audit=self.s.audit, secret=SECRET,
                                 clock=self.s.clock, **kw)

    async def press(self, data, *, presser=OWNER, chat=None, cbid="auto", ctype="private", service=None):
        if cbid == "auto":
            self.n += 1
            cbid = f"cb{self.n}"
        return await (service or self.svc).press(presser if chat is None else chat, ctype, presser, data, "ar", cbid)

    def row(self, gid=A):
        return self.s.licenses._rows[gid]

    def snapshot(self):
        return dict(self.s.licenses._rows), list(self.s.licenses.audit_log)

    def last_audit(self, gid=A):
        return [e for e in self.s.licenses.audit_log if e.group_id == gid][-1]

    def forged_events(self):
        return [e for e in self.s.audit.events if e.event_type == FORGED_CALLBACK]

    async def detail(self, gid=A, service=None):
        return await self.press(build(codec.DETAIL, group_id=gid), service=service)


class PanelDrivenFlowTests(Base):
    async def test_activate_permanently_from_the_detail_buttons(self):
        detail = await self.detail()
        out = await self.press(button(detail, codec.DO, "ap"))
        self.assertEqual((out.status, out.alert), ("done", False))
        self.assertEqual(self.row().status, S.ACTIVE_PERMANENT)
        self.assertEqual(self.row().activated_by, OWNER)
        self.assertIn("دائمًا", out.toast)
        self.assertIn("دائم", out.text)
        entry = self.last_audit()
        self.assertEqual((entry.action, entry.previous_status, entry.new_status, entry.actor_telegram_id),
                         ("activate_permanent", S.PENDING, S.ACTIVE_PERMANENT, OWNER))
        # the screen now offers what an active group offers
        self.assertTrue(has_button(out, codec.ASK, "st"))
        self.assertFalse(has_button(out, codec.DO, "ap"))

    async def test_activate_for_a_chosen_period_counts_from_now(self):
        detail = await self.detail()
        menu = await self.press(button(detail, codec.MENU))
        self.assertEqual(menu.status, "menu")
        self.s.clock.advance(minutes=7)
        out = await self.press(button(menu, codec.DO, "t30"))
        self.assertEqual(out.status, "done")
        expected = NOW + timedelta(minutes=7, days=30)
        self.assertEqual((self.row().status, self.row().expires_at), (S.ACTIVE_TEMPORARY, expected))
        self.assertIn(format_display(expected, TZ), out.toast)
        self.assertEqual(self.last_audit().action, "activate_temporary")

    async def test_every_duration_button_gives_exactly_that_many_days(self):
        for i, (code, days) in enumerate(zip(act.DURATION_CODES, (1, 7, 30, 90, 180, 365))):
            with self.subTest(code):
                gid = -2000 - i
                await self.s.register(gid)
                out = await self.press(do(code, "p", gid=gid))
                self.assertEqual(out.status, "done", out.toast)
                self.assertEqual(self.row(gid).expires_at, NOW + timedelta(days=days))

    async def test_renewing_an_active_license_asks_and_counts_from_now_not_from_the_old_expiry(self):
        await self.s.admin.activate_temporary(OWNER, B, NOW + timedelta(days=5))
        self.s.clock.advance(days=1)
        detail = await self.detail(B)
        menu = await self.press(button(detail, codec.MENU))
        before = self.snapshot()
        confirm = await self.press(button(menu, codec.ASK, "t7"))
        self.assertEqual(confirm.status, "confirm")
        self.assertEqual(self.snapshot(), before)               # asking changes nothing
        out = await self.press(button(confirm, codec.DO, "t7"))
        self.assertEqual(out.status, "done")
        self.assertEqual(self.row(B).expires_at, self.s.clock() + timedelta(days=7))   # NOT old expiry + 7
        self.assertEqual(self.last_audit(B).action, "renew")
        self.assertIn("جُدّد", out.toast)

    async def test_a_permanent_license_can_be_turned_into_a_timed_one_only_after_confirmation(self):
        await self.s.admin.activate_permanent(OWNER, A)
        confirm = await self.press(ask("t7", "d"))
        self.assertEqual(confirm.status, "confirm")
        self.assertIn(act.warning_of("t7", "ar"), confirm.text)
        self.assertEqual(self.row().status, S.ACTIVE_PERMANENT)
        out = await self.press(button(confirm, codec.DO, "t7"))
        self.assertEqual((self.row().status, self.row().expires_at), (S.ACTIVE_TEMPORARY, NOW + timedelta(days=7)))
        self.assertEqual(out.status, "done")

    async def test_a_temporary_license_becomes_permanent_after_confirmation(self):
        await self.s.admin.activate_temporary(OWNER, A, NOW + timedelta(days=2))
        detail = await self.detail()
        confirm = await self.press(button(detail, codec.ASK, "ap"))
        out = await self.press(button(confirm, codec.DO, "ap"))
        self.assertEqual(out.status, "done")
        self.assertEqual((self.row().status, self.row().expires_at), (S.ACTIVE_PERMANENT, None))

    async def test_stop_asks_first_and_changes_nothing_until_confirmed(self):
        await self.s.admin.activate_permanent(OWNER, A)
        detail = await self.detail()
        before = self.snapshot()
        confirm = await self.press(button(detail, codec.ASK, "st"))
        self.assertEqual(confirm.status, "confirm")
        self.assertIn(act.warning_of("st", "ar"), confirm.text)
        self.assertEqual(self.snapshot(), before)
        cancelled = await self.press(button(confirm, codec.DETAIL))
        self.assertEqual(cancelled.status, "detail")
        self.assertEqual(self.snapshot(), before)
        out = await self.press(button(confirm, codec.DO, "st"))
        self.assertEqual((out.status, self.row().status), ("done", S.STOPPED))
        self.assertIn("متوقفة", out.text)
        self.assertEqual(self.last_audit().action, "stop")
        self.assertTrue(has_button(out, codec.DO, "ap"))      # and the stopped screen offers re-activation

    async def test_reject_allow_ban_unban_cycle(self):
        detail = await self.detail()
        out = await self.press(button(await self.press(button(detail, codec.ASK, "rj")), codec.DO, "rj"))
        self.assertEqual((out.status, self.row().status), ("done", S.REJECTED))
        self.assertFalse(has_button(out, codec.MENU))         # lift first
        out = await self.press(button(out, codec.DO, "al"))
        self.assertEqual((out.status, self.row().status), ("done", S.PENDING))
        out = await self.press(button(await self.press(button(out, codec.ASK, "bn")), codec.DO, "bn"))
        self.assertEqual((out.status, self.row().status), ("done", S.BANNED))
        self.assertEqual([cb.action for _, cb in parsed_buttons(out) if cb.screen in (codec.DO, codec.ASK, codec.MENU)], ["ub"])
        out = await self.press(button(out, codec.DO, "ub"))
        self.assertEqual((out.status, self.row().status), ("done", S.PENDING))
        actions = [e.action for e in self.s.licenses.audit_log if e.group_id == A][-4:]
        self.assertEqual(actions, ["reject", "allow", "ban", "unban"])

    async def test_banning_an_active_group_cuts_it_off(self):
        await self.s.admin.activate_permanent(OWNER, A)
        out = await self.press(do("bn", "d"))
        self.assertEqual((out.status, self.row().status), ("done", S.BANNED))
        self.assertIn("محظورة", out.text)
        self.assertIn("متوقفة", out.text)                     # protection off

    async def test_the_results_belong_to_one_group_only(self):
        await self.press(do("ap", "p", gid=A))
        self.assertEqual((self.row(A).status, self.row(B).status), (S.ACTIVE_PERMANENT, S.PENDING))
        self.assertEqual([e for e in self.s.licenses.audit_log if e.group_id == B and e.actor_telegram_id == OWNER], [])

    async def test_a_signed_button_cannot_be_pointed_at_another_group(self):
        data = do("ap", "p", gid=A)
        forged = data.replace(str(A), str(B))
        before = self.snapshot()
        out = await self.press(forged)
        self.assertEqual(out.status, "forged")
        self.assertEqual(self.snapshot(), before)


class StaleAndIdempotencyTests(Base):
    async def test_a_stale_button_is_refused_and_applies_nothing(self):
        stale = do("rj", "p")                                  # drawn while the group was pending
        await self.s.admin.activate_permanent(OWNER, A)        # ... then the group changed
        before = self.snapshot()
        out = await self.press(stale, cbid="c-stale")
        self.assertEqual((out.status, out.alert), ("stale", True))
        self.assertEqual(self.snapshot(), before)
        self.assertIn("دائم", out.text)                       # the owner sees the REAL state
        self.assertTrue(await self.claims.claim(operation_key("ow", A, "c-stale")))   # a refused press consumes no claim

    async def test_a_stale_confirmation_screen_is_not_shown(self):
        await self.s.admin.activate_permanent(OWNER, A)
        out = await self.press(ask("st", "p"))                 # the owner saw "pending" when the button was drawn
        self.assertEqual((out.status, out.alert), ("stale", True))
        self.assertNotIn(act.warning_of("st", "ar"), out.text)
        self.assertEqual(self.row().status, S.ACTIVE_PERMANENT)

    async def test_the_effective_status_decides_a_lapsed_timed_license_is_expired(self):
        await self.s.admin.activate_temporary(OWNER, B, NOW + timedelta(days=5))
        self.s.clock.advance(days=6)
        stale = await self.press(do("t30", "t", gid=B))        # the button still thinks it is active
        self.assertEqual(stale.status, "stale")
        detail = await self.detail(B)
        self.assertIn("منتهية", detail.text)
        out = await self.press(button(await self.press(button(detail, codec.MENU)), codec.DO, "t30"))
        self.assertEqual(out.status, "done")
        self.assertEqual(self.row(B).expires_at, self.s.clock() + timedelta(days=30))
        self.assertEqual(self.last_audit(B).action, "renew")   # an expired license is renewed, not "activated"
        self.assertEqual(self.last_audit(B).previous_status, S.EXPIRED)

    async def test_one_press_is_applied_once(self):
        first = await self.press(do("ap", "p"), cbid="same")
        self.assertEqual(first.status, "done")
        again = await self.press(do("ap", "p"), cbid="same")   # redelivered: the status already moved on
        self.assertNotEqual(again.status, "done")
        self.assertEqual(len([e for e in self.s.licenses.audit_log if e.group_id == A and e.action == "activate_permanent"]), 1)

    async def test_repeating_the_same_result_is_reported_as_no_change(self):
        await self.s.admin.activate_temporary(OWNER, A, NOW + timedelta(days=7))
        before = self.snapshot()
        out = await self.press(do("t7", "t"))                  # same clock, same 7 days: exactly the current expiry
        self.assertEqual((out.status, out.alert), ("no_change", False))
        self.assertIn("لا تغيير", out.toast)
        self.assertEqual(self.snapshot(), before)               # no second audit row

    async def test_an_already_claimed_press_does_nothing_and_says_nothing(self):
        await self.claims.claim(operation_key("ow", A, "taken"))
        before = self.snapshot()
        out = await self.press(do("ap", "p"), cbid="taken")
        self.assertEqual((out.status, out.toast, out.text, out.buttons), ("duplicate", "", None, None))
        self.assertEqual(self.snapshot(), before)

    async def test_a_press_without_a_usable_callback_id_changes_nothing(self):
        before = self.snapshot()
        for bad in (None, "", "a b", "x" * 101, 5, "é", "a\nb", b"cb"):
            with self.subTest(repr(bad)):
                out = await self.press(do("ap", "p"), cbid=bad)
                self.assertEqual((out.status, out.alert), ("invalid", True))
                self.assertEqual(self.snapshot(), before)

    async def test_the_claim_is_per_group_and_per_press(self):
        await self.press(do("ap", "p", gid=A), cbid="k1")
        out = await self.press(do("ap", "p", gid=B), cbid="k1")   # same id, other group: its own key
        self.assertEqual(out.status, "done")
        self.assertEqual(self.row(B).status, S.ACTIVE_PERMANENT)

    async def test_a_failed_claim_store_changes_nothing(self):
        class Down:
            async def claim(self, key, now=None):
                raise RuntimeError("db down")

        called = []

        class Admin:
            async def activate_permanent(self, *a, **k):
                called.append(1)

        svc = self.make(actions=OwnerActions(license_admin=Admin(), licenses=self.s.licenses, claims=Down(), clock=self.s.clock))
        before = self.snapshot()
        out = await self.press(do("ap", "p"), service=svc)
        self.assertEqual((out.status, out.alert), ("failed", True))
        self.assertEqual((called, self.snapshot()), ([], before))


class RefusalTests(Base):
    async def test_nobody_but_the_primary_owner_runs_actions(self):
        before = self.snapshot()
        for who in (STRANGER, BACKUP, TG_ADMIN, TG_CREATOR, DELEGATE):
            for data in (do("ap", "p", chat=who), ask("st", "p", chat=who), build(codec.MENU, chat=who, group_id=A)):
                with self.subTest((who, data[:6])):
                    out = await self.press(data, presser=who)       # even signed for his own chat (key replay)
                    self.assertEqual((out.status, out.alert), ("not_owner", True))
                    self.assertIsNone(out.text)
        self.assertEqual(self.snapshot(), before)
        self.assertGreaterEqual(len(self.forged_events()), 5)

    async def test_chat_and_actor_must_match_and_be_private(self):
        before = self.snapshot()
        self.assertIsNone(await self.press(do("ap", "p"), chat=STRANGER))               # pressed in another chat
        self.assertIsNone(await self.press(do("ap", "p"), chat=-1001, ctype="supergroup"))     # pressed inside a group
        self.assertIsNone(await self.press(do("ap", "p"), ctype="group"))
        self.assertEqual(self.snapshot(), before)

    async def test_tampered_callbacks_are_forged(self):
        data = do("st", "p")
        tag = data.rsplit(":", 1)[1]
        before = self.snapshot()
        for forged in (f"ow:y:bn:p:{A}:a:0:{tag}", f"ow:y:st:d:{A}:a:0:{tag}", f"ow:y:st:p:{B}:a:0:{tag}",
                       f"ow:y:st:p:{A}:a:0:{'f' * 12}"):
            out = await self.press(forged)
            self.assertEqual((out.status, out.alert), ("forged", True), forged)
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(len(self.forged_events()), 4)

    async def test_a_valid_signature_still_cannot_force_a_forbidden_transition(self):
        await self.s.admin.ban(OWNER, A)
        before = list(self.s.licenses._rows.items())
        for code in ("ap", "t7", "st", "rj", "al"):
            out = await self.press(do(code, "b"))
            self.assertEqual((out.status, out.alert), ("bad_state", True), code)
            self.assertIn("محظورة", out.toast)
        self.assertEqual(list(self.s.licenses._rows.items()), before)
        self.assertGreaterEqual(len([e for e in self.s.audit.events if e.event_type == LICENSE_ACTION_REJECTED]), 5)

    async def test_without_an_executor_the_panel_is_read_only(self):
        svc = self.make(actions=None)
        detail = await self.press(build(codec.DETAIL, group_id=A), service=svc)
        self.assertFalse(any(cb.screen in (codec.DO, codec.ASK, codec.MENU) for _, cb in parsed_buttons(detail)))
        before = self.snapshot()
        for data in (do("ap", "p"), ask("st", "p"), build(codec.MENU, group_id=A)):
            out = await self.press(data, service=svc)
            self.assertEqual((out.status, out.alert, out.text), ("actions_unavailable", True, None))
        self.assertEqual(self.snapshot(), before)

    async def test_an_unknown_group_gets_the_missing_screen(self):
        for data in (do("ap", "p", gid=-4242), ask("st", "p", gid=-4242), build(codec.MENU, group_id=-4242)):
            out = await self.press(data)
            self.assertEqual(out.status, "missing")
            self.assertIn("لم تعد مسجّلة", out.text)
        self.assertNotIn(-4242, self.s.licenses._rows)

    async def test_a_store_failure_while_reading_answers_unavailable(self):
        class Down(InMemoryLicenseStore):
            async def get(self, group_id):
                raise RuntimeError("db down")

        calls = []

        class Admin:
            def __getattr__(self, name):
                async def fn(*a, **k):
                    calls.append(name)
                return fn

        svc = self.make(licenses=Down(), actions=OwnerActions(license_admin=Admin(), licenses=Down(), claims=self.claims))
        for data in (do("ap", "p"), ask("st", "p"), build(codec.MENU, group_id=A)):
            out = await self.press(data, service=svc)
            self.assertEqual((out.status, out.alert, out.text), ("unavailable", True, None))
        self.assertEqual(calls, [])


class AdminErrorMappingTests(Base):
    async def run_with(self, exc):
        class Admin:
            def __getattr__(self, name):
                async def fn(*a, **k):
                    raise exc
                return fn

        svc = self.make(actions=OwnerActions(license_admin=Admin(), licenses=self.s.licenses, claims=self.claims,
                                             clock=self.s.clock))
        before = self.snapshot()
        out = await self.press(do("ap", "p"), service=svc)
        self.assertEqual(self.snapshot(), before)
        return out

    async def test_every_admin_failure_becomes_a_safe_answer(self):
        cases = ((PermissionDenied("change_license", "owner_only"), "not_owner", False),
                 (InvalidTransition("x"), "bad_state", True), (ConcurrentModification("x"), "retry", True),
                 (InvalidInput("x"), "failed", True), (RuntimeError("boom"), "failed", True),
                 (GroupNotRegistered("x"), "missing", False))
        for exc, status, with_screen in cases:
            with self.subTest(type(exc).__name__):
                out = await self.run_with(exc)
                self.assertEqual(out.status, status)
                if status != "missing":
                    self.assertTrue(out.alert)
                if status in ("bad_state", "retry", "failed"):
                    self.assertIsNotNone(out.text)               # the owner is shown the real state, not left blind
                    self.assertTrue(has_button(out, codec.DO, "ap"))
                    self.assertNotIn("boom", out.toast + out.text)


# ----------------------------------------------------------------------------- aiogram-free glue
class Query:
    def __init__(self, data, qid="q-77"):
        self.data, self.from_user, self.id = data, NS(id=OWNER, language_code="ar"), qid
        self.edits = []
        outer = self

        class M:
            chat = NS(id=OWNER, type="private")

            async def edit_text(self, text, reply_markup=None):
                outer.edits.append((text, reply_markup))

            async def delete(self):
                pass

        self.message = M()


class GlueTests(Base):
    def services(self):
        return NS(settings=NS(default_language="ar"), owner_panel=self.svc)

    async def test_the_callback_query_id_is_the_idempotency_key(self):
        q = Query(do("ap", "p"))
        toast, alert = await h.on_owner_callback(q, self.services(), lambda r: r)
        self.assertEqual(self.row().status, S.ACTIVE_PERMANENT)
        self.assertEqual(alert, False)
        self.assertIn("دائمًا", toast)
        self.assertEqual(len(q.edits), 1)
        self.assertFalse(await self.claims.claim(operation_key("ow", A, "q-77")))     # consumed by that press

    async def test_a_stale_press_edits_the_screen_to_the_real_state_and_alerts(self):
        await self.s.admin.activate_permanent(OWNER, A)
        q = Query(do("rj", "p"))
        toast, alert = await h.on_owner_callback(q, self.services(), lambda r: r)
        self.assertTrue(alert and toast)
        self.assertEqual(self.row().status, S.ACTIVE_PERMANENT)
        self.assertIn("دائم", q.edits[0][0])


# ----------------------------------------------------------------------------- static guards
class StaticTests(unittest.TestCase):
    def test_only_actions_py_touches_the_admin_service(self):
        for path in (SRC / "owner_panel").glob("*.py"):
            text = path.read_text(encoding="utf-8")
            if path.name == "actions.py":
                self.assertIn("self._admin", text)
                for forbidden in (".transition(", ".register_pending", "INSERT", "UPDATE ", "DELETE ", "list_all"):
                    self.assertNotIn(forbidden, text, forbidden)    # never the store's write side, never SQL
            else:
                self.assertNotIn("_admin", text, path.name)

    def test_the_wiring_passes_the_executor_with_the_shared_claims(self):
        app = (SRC / "app.py").read_text(encoding="utf-8")
        self.assertIn("OwnerActions(license_admin=license_admin_obj, licenses=license_store, claims=claims)", app)
        handler = (SRC / "bot" / "owner_panel_handler.py").read_text(encoding="utf-8")
        self.assertIn('getattr(query, "id", None)', handler)

    def test_every_ow_key_used_anywhere_exists_in_both_languages(self):
        used = set()
        for path in list((SRC / "owner_panel").glob("*.py")) + [SRC / "bot" / "owner_panel_handler.py"]:
            used |= set(re.findall(r'"(ow_[a-z_]+)"', path.read_text(encoding="utf-8")))
        self.assertGreater(len(used), 60)
        for lang in ("ar", "en"):
            self.assertFalse(used - set(MESSAGES[lang]), (lang, used - set(MESSAGES[lang])))

    def test_toasts_fit_telegrams_200_character_limit(self):
        values = dict(when="2026-12-31 23:59", status="منتهية — expired", n=365)
        for lang in ("ar", "en"):
            for key in MESSAGES[lang]:
                if key.startswith(("ow_done_", "ow_stale", "ow_bad_state", "ow_retry", "ow_action_failed", "ow_invalid",
                                   "ow_not_owner", "ow_actions_unavailable")):
                    self.assertLessEqual(len(t(key, lang, **values)), 200, (lang, key))

    def test_the_new_buttons_are_short_enough_for_a_phone(self):
        for lang in ("ar", "en"):
            for key in MESSAGES[lang]:
                if key.startswith("ow_btn_"):
                    self.assertLessEqual(len(MESSAGES[lang][key]), 24, key)


if __name__ == "__main__":
    unittest.main()
