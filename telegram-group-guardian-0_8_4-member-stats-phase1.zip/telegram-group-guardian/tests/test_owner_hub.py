"""Phase 5 / part 5.5: the OWNER HUB (`OWNER_GROUP_ID`) -- the secret redactor (text + files), the safe sender (fixed destination,
never raises, cooldown, timeout), the mirroring notifier, the reports, and the two license-change hooks (owner panel and group
commands). aiogram/FastAPI/PostgreSQL/Telegram are NOT exercised (not installable in the build sandbox): the transport is a
fake and the aiogram adapter is checked statically."""
from __future__ import annotations

import ast
import asyncio
import inspect
import logging
import re
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

import helpers  # noqa: F401
from helpers import VALID_ENV
from guardian.config import load_settings
from guardian.i18n import MESSAGES, Raw, t
from guardian.licensing.commands import LicenseCommandService, parse_license_command
from guardian.licensing.models import GroupLicense, LicenseStatus as S
from guardian.membership import handle_bot_added
from guardian.idempotency import InMemoryIdempotency
from guardian.owner_hub import redactor as rd
from guardian.owner_hub import reports as rp
from guardian.owner_hub.mirror import HubMirroringNotifier
from guardian.owner_hub.reports import HubReporter, license_change_text, stats_text
from guardian.owner_hub.sender import DisabledHub, MAX_TEXT, OwnerHubSender, fit_html
from guardian.owner_panel import codec
from guardian.owner_panel.actions import OwnerActions
from guardian.owner_panel.service import OwnerPanelService
from stack import A, B, NOW, OWNER, OWNER_GROUP, STRANGER, TG_ADMIN, Clock, Stack

SRC = Path(__file__).resolve().parents[1] / "src" / "guardian"
SETTINGS = load_settings(VALID_ENV)
SECRETS = SETTINGS.secret_values()
TOKEN = VALID_ENV["BOT_TOKEN"]
DSN = VALID_ENV["DATABASE_URL"]
PANEL_SECRET = "owner-hub-test-secret-0123456789"
KEY = codec.derive_key(PANEL_SECRET)
TZ = "Asia/Riyadh"


class FakeTransport:
    def __init__(self, fail=None, delay=0.0):
        self.messages: list[tuple[int, str]] = []
        self.documents: list[tuple[int, str, bytes, str | None]] = []
        self.fail, self.delay, self.calls = fail, delay, 0

    async def _maybe(self):
        self.calls += 1
        if self.delay:
            await asyncio.sleep(self.delay)
        if self.fail is not None:
            raise self.fail

    async def send_message(self, chat_id, text):
        await self._maybe()
        self.messages.append((chat_id, text))

    async def send_document(self, chat_id, filename, data, caption):
        await self._maybe()
        self.documents.append((chat_id, filename, data, caption))


def make_hub(transport=None, clock=None, **kw):
    transport = transport or FakeTransport()
    kw.setdefault("secrets", SECRETS)
    return OwnerHubSender(transport, OWNER_GROUP, clock=clock or Clock(), **kw), transport


# ============================================================================================ redactor: text
class RedactTextTests(unittest.TestCase):
    def test_the_configured_secrets_never_survive_wherever_they_appear(self):
        for secret in SECRETS:
            for text in (f"x {secret} y", f"{secret}", f"a\n{secret}\nb", f"<code>{secret}</code>"):
                self.assertNotIn(secret, rd.redact_text(text, SECRETS))

    def test_bot_token_shaped_strings_are_masked_even_if_unknown(self):
        out = rd.redact_text("token 987654321:ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ here")
        self.assertNotIn("987654321", out)
        self.assertIn("***", out)

    def test_a_database_url_is_removed_whole_including_the_host(self):
        out = rd.redact_text(f"connect {DSN} failed")
        self.assertNotIn("db.example.com", out)
        self.assertNotIn("dbuser", out)
        self.assertNotIn("s3cretPW", out)
        self.assertEqual(out, "connect *** failed")

    def test_other_dsn_schemes(self):
        for url in ("postgres://u:p@h/db", "mysql://u:p@h/db", "redis://:p@h:6379/0", "mongodb+srv://u:p@h/db"):
            self.assertEqual(rd.redact_text(f"x {url} y"), "x *** y", url)

    def test_the_url_encoded_form_of_a_secret_is_masked_too(self):
        secret = "p@ss/w0rd#1"
        self.assertNotIn("p%40ss", rd.redact_text("dsn p%40ss%2Fw0rd%231 end", (secret,)))

    def test_pairs_with_secret_names_are_masked_and_others_kept(self):
        text = "BOT_TOKEN=abc123\nDB_PASSWORD: hunter22\nLOG_LEVEL=INFO\nuser: bob\nAPI_KEY = 'k-1'\n\"password\": \"zzz\""
        out = rd.redact_text(text)
        for leaked in ("abc123", "hunter22", "k-1", "zzz"):
            self.assertNotIn(leaked, out)
        self.assertIn("LOG_LEVEL=INFO", out)
        self.assertIn("user: bob", out)

    def test_private_key_blocks_and_auth_headers(self):
        pem = "-----BEGIN RSA PRIVATE KEY-----\nMIIBOgIBAAJBAKj34GkxFhD90vcNLYLInFEX6Ppy1tPf9Cnzj4p4WGeKLs1Pt8Qu\n-----END RSA PRIVATE KEY-----"
        self.assertEqual(rd.redact_text(f"a {pem} b"), "a *** b")
        self.assertNotIn("abcdefgh12345678", rd.redact_text("Authorization: Bearer abcdefgh12345678"))
        self.assertNotIn("abcdefgh12345678", rd.redact_text("sent bearer abcdefgh12345678 ok"))

    def test_long_random_looking_keys_are_masked_but_plain_long_words_are_not(self):
        key = "sk" + "a1B2" * 12
        self.assertNotIn(key, rd.redact_text(f"key {key}"))
        word = "x" * 60
        self.assertIn(word, rd.redact_text(word))

    def test_normal_report_content_is_untouched(self):
        text = "<b>تقرير</b> المجموعة <code>-1001234567890</code> — 2026-10-31 15:00 (Asia/Riyadh)\n• منتهية: <b>3</b>\nuser 111111111"
        self.assertEqual(rd.redact_text(text, SECRETS), text)

    def test_idempotent_and_total(self):
        once = rd.redact_text(f"{TOKEN} {DSN} PASSWORD=x", SECRETS)
        self.assertEqual(rd.redact_text(once, SECRETS), once)
        self.assertEqual(rd.redact_text(None), "")
        self.assertEqual(rd.redact_text(""), "")
        self.assertEqual(rd.redact_text(12345), "12345")  # type: ignore[arg-type]

    def test_very_short_secrets_are_ignored_not_used_to_shred_text(self):
        self.assertEqual(rd.redact_text("a b c", ("a", "")), "a b c")


# ============================================================================================ redactor: files
class ScreenFileTests(unittest.TestCase):
    def verdict(self, name, data=b"hello", secrets=SECRETS):
        return rd.screen_file(name, data, secrets)

    def test_env_files_are_refused_whatever_their_content(self):
        for name in (".env", ".env.production", "prod.env", "x/.env", "C:\\app\\.env", ".ENV", "my.env.txt", "secrets.txt",
                     "credentials.json", "passwords.csv", "db-password.txt"):
            v = self.verdict(name)
            self.assertFalse(v.allowed, name)
            self.assertEqual(v.reason, "blocked_name", name)
            self.assertEqual(v.data, b"")

    def test_key_material_archives_and_databases_are_refused(self):
        for name in ("server.pem", "k.key", "a.p12", "id_rsa", "id_rsa.pub", "store.jks", "dump.sql", "a.sqlite", "b.zip", "c.tar", "d.gz"):
            self.assertFalse(self.verdict(name).allowed, name)

    def test_only_plain_text_formats_may_be_sent(self):
        for name in ("a.txt", "a.csv", "a.tsv", "a.json", "a.md", "a.log", "A.TXT"):
            self.assertTrue(self.verdict(name).allowed, name)
        for name in ("a.py", "a.exe", "a", "a.html", "a.pdf", "a.xlsx"):
            self.assertEqual(self.verdict(name).reason, "extension_not_allowed", name)

    def test_size_binary_empty_and_invalid_inputs(self):
        self.assertEqual(self.verdict("a.txt", b"x" * (rd.MAX_FILE_BYTES + 1)).reason, "too_large")
        self.assertEqual(self.verdict("a.txt", b"\xff\xfe\x00\x01").reason, "not_text")
        self.assertEqual(self.verdict("a.txt", b"ab\x00cd").reason, "not_text")
        self.assertEqual(self.verdict("a.txt", b"  \n ").reason, "empty")
        self.assertEqual(self.verdict("a.txt", "text").reason, "not_text")
        self.assertEqual(self.verdict("", b"x").reason, "bad_name")
        self.assertEqual(self.verdict(None, b"x").reason, "bad_name")
        self.assertEqual(self.verdict("a\x00.txt", b"x").reason, "bad_name")

    def test_a_private_key_inside_an_allowed_file_refuses_the_file(self):
        data = b"notes\n-----BEGIN PRIVATE KEY-----\nabc\n-----END PRIVATE KEY-----\n"
        self.assertEqual(self.verdict("notes.txt", data).reason, "private_key")

    def test_a_dotenv_shaped_file_is_refused_not_cleaned(self):
        data = f"BOT_TOKEN={TOKEN}\nDATABASE_URL={DSN}\nOWNER_TELEGRAM_ID=1\nWEBHOOK_SECRET=x\n".encode()
        v = self.verdict("settings.txt", data)
        self.assertEqual((v.allowed, v.reason, v.data), (False, "dotenv_content", b""))

    def test_a_normal_file_is_sent_redacted(self):
        data = f"group,note\n-1001,ok\n-1002,{TOKEN}\n".encode()
        v = self.verdict("report.csv", data)
        self.assertTrue(v.allowed)
        self.assertNotIn(TOKEN.encode(), v.data)
        self.assertIn(b"-1001,ok", v.data)
        self.assertEqual(v.redactions, 1)

    def test_the_file_name_is_sanitised_and_cannot_traverse_or_leak(self):
        self.assertEqual(self.verdict("../../etc/x.txt").filename, "x.txt")
        self.assertEqual(self.verdict("تقرير.txt").filename, "file.txt")
        self.assertEqual(self.verdict("a b.CSV").filename, "a_b.csv")
        self.assertNotIn("s3cretPW", self.verdict("s3cretPW-report.txt").filename)
        self.assertLessEqual(len(self.verdict("n" * 500 + ".txt").filename), rd.MAX_FILENAME_LEN)

    def test_no_known_secret_can_be_in_an_allowed_result(self):
        blob = "\n".join(f"line {i} {s}" for i, s in enumerate(SECRETS)).encode()
        v = self.verdict("dump.txt", blob)
        self.assertTrue(v.allowed)
        for secret in SECRETS:
            self.assertNotIn(secret.encode(), v.data)


# ============================================================================================ fit_html
class FitHtmlTests(unittest.TestCase):
    def test_short_text_is_unchanged(self):
        self.assertEqual(fit_html("<b>x</b>"), "<b>x</b>")

    def test_long_text_is_cut_inside_the_limit_with_tags_closed(self):
        text = "<b>" + "line one\n" * 1000 + "</b>"
        out = fit_html(text)
        self.assertLessEqual(len(out), 4096)
        self.assertTrue(out.endswith("…</b>"))
        self.assertEqual(out.count("<b>"), out.count("</b>"))

    def test_a_half_tag_or_entity_at_the_cut_is_removed(self):
        for tail in ("<code", "<a href=\"x", "&amp", "&#12"):
            out = fit_html("x" * 30 + tail + "y" * 100, limit=40)
            self.assertNotIn(tail, out, tail)

    def test_nested_tags_close_in_reverse_order(self):
        out = fit_html("<b><code>" + "z" * 200, limit=50)
        self.assertTrue(out.endswith("…</code></b>"))


# ============================================================================================ sender
class SenderTests(unittest.IsolatedAsyncioTestCase):
    async def test_text_goes_only_to_the_configured_group_and_is_redacted(self):
        hub, tr = make_hub()
        res = await hub.send_text(f"<b>تقرير</b> {TOKEN} {DSN}")
        self.assertEqual((res.delivered, res.reason), (True, "sent"))
        self.assertEqual(len(tr.messages), 1)
        chat, text = tr.messages[0]
        self.assertEqual(chat, OWNER_GROUP)
        self.assertIn("<b>تقرير</b>", text)
        for secret in SECRETS:
            self.assertNotIn(secret, text)

    async def test_no_public_send_method_accepts_a_destination(self):
        for name in ("send_text", "send_file", "post_text"):
            params = list(inspect.signature(getattr(OwnerHubSender, name)).parameters)
            self.assertFalse({"chat_id", "chat", "group_id", "destination", "to"} & set(params), (name, params))

    async def test_disabled_hub_does_nothing_and_never_fails(self):
        for hub in (DisabledHub(), OwnerHubSender(FakeTransport(), None), OwnerHubSender(None, OWNER_GROUP)):
            self.assertFalse(hub.enabled)
            self.assertEqual((await hub.send_text("x")).reason, "disabled")
            self.assertEqual((await hub.send_file("a.txt", b"x")).reason, "disabled")
            hub.post_text("x")  # no task, no error
            self.assertEqual(hub.health().consecutive_failures, 0)

    async def test_empty_or_none_text_is_not_sent(self):
        hub, tr = make_hub()
        for text in ("", "   ", None):
            self.assertEqual((await hub.send_text(text)).reason, "empty")
        self.assertEqual(tr.calls, 0)

    async def test_a_transport_failure_is_swallowed_and_recorded(self):
        hub, tr = make_hub(FakeTransport(fail=RuntimeError(f"HTTP 403 {TOKEN}")))
        res = await hub.send_text("x")
        self.assertEqual((res.delivered, res.reason), (False, "failed"))
        health = hub.health()
        self.assertEqual((health.consecutive_failures, health.last_error_kind), (1, "RuntimeError"))

    async def test_the_failure_log_never_contains_the_exception_text(self):
        hub, _ = make_hub(FakeTransport(fail=RuntimeError(f"boom {TOKEN}")))
        logging.disable(logging.NOTSET)
        try:
            with self.assertLogs("guardian.owner_hub.sender", level="WARNING") as cm:
                await hub.send_text("x")
        finally:
            logging.disable(logging.CRITICAL)
        joined = "\n".join(cm.output)
        self.assertNotIn(TOKEN, joined)
        self.assertNotIn("boom", joined)
        self.assertIn("RuntimeError", joined)

    async def test_failures_pause_sending_then_resume(self):
        clock = Clock()
        hub, tr = make_hub(FakeTransport(fail=RuntimeError("down")), clock=clock)
        await hub.send_text("1")
        self.assertEqual(tr.calls, 1)
        self.assertEqual((await hub.send_text("2")).reason, "cooldown")
        self.assertEqual(tr.calls, 1)                        # skipped, the broken hub is not hammered
        self.assertEqual(hub.health().skipped_in_cooldown, 1)
        clock.advance(seconds=61)
        tr.fail = None
        self.assertEqual((await hub.send_text("3")).reason, "sent")
        health = hub.health()
        self.assertEqual((health.consecutive_failures, health.cooldown_until), (0, None))

    async def test_the_pause_grows_and_is_capped(self):
        clock = Clock()
        hub, tr = make_hub(FakeTransport(fail=RuntimeError("down")), clock=clock)
        seen = []
        for _ in range(8):
            clock.advance(hours=1)
            await hub.send_text("x")
            seen.append(hub.health().cooldown_until - clock())
        self.assertEqual(seen[0], timedelta(seconds=60))
        self.assertEqual(seen[1], timedelta(seconds=120))
        self.assertEqual(seen[2], timedelta(seconds=240))
        self.assertEqual(max(seen), timedelta(minutes=15))

    async def test_a_hung_telegram_call_times_out_instead_of_stalling(self):
        hub, tr = make_hub(FakeTransport(delay=5), timeout=0.05)
        res = await asyncio.wait_for(hub.send_text("x"), timeout=2)
        self.assertEqual((res.delivered, res.reason), (False, "timeout"))
        self.assertEqual(hub.health().last_error_kind, "timeout")

    async def test_there_is_no_retry_inside_one_call(self):
        hub, tr = make_hub(FakeTransport(fail=RuntimeError("x")))
        await hub.send_text("x")
        await hub.send_file("a.txt", b"x")  # in cooldown now
        self.assertEqual(tr.calls, 1)

    async def test_files_pass_the_screen_before_anything_is_sent(self):
        hub, tr = make_hub()
        for name in (".env", "secrets.txt", "a.pem", "a.py"):
            res = await hub.send_file(name, b"data")
            self.assertFalse(res.delivered, name)
            self.assertTrue(res.reason.startswith("file_rejected:"), name)
        self.assertEqual((tr.calls, tr.documents), (0, []))
        self.assertEqual(hub.health().consecutive_failures, 0)  # a refused file is not a delivery failure

    async def test_an_allowed_file_is_sent_redacted_with_a_redacted_caption(self):
        hub, tr = make_hub()
        res = await hub.send_file("../report.csv", f"a,b\n1,{TOKEN}\n".encode(), caption=f"<b>تقرير</b> {DSN}")
        self.assertTrue(res.delivered)
        chat, name, data, caption = tr.documents[0]
        self.assertEqual((chat, name), (OWNER_GROUP, "report.csv"))
        self.assertNotIn(TOKEN.encode(), data)
        self.assertNotIn("db.example.com", caption)
        self.assertIn("<b>تقرير</b>", caption)

    async def test_a_dotenv_content_is_refused_even_under_a_harmless_name(self):
        hub, tr = make_hub()
        res = await hub.send_file("notes.txt", f"BOT_TOKEN={TOKEN}\nDATABASE_URL={DSN}\nWEBHOOK_SECRET=abc\n".encode())
        self.assertEqual(res.reason, "file_rejected:dotenv_content")
        self.assertEqual(tr.calls, 0)

    async def test_post_text_does_not_block_and_drain_waits(self):
        hub, tr = make_hub(FakeTransport(delay=0.05))
        hub.post_text("later")
        self.assertEqual(tr.messages, [])
        await hub.drain()
        self.assertEqual(len(tr.messages), 1)

    async def test_post_text_with_a_failing_hub_never_raises(self):
        hub, tr = make_hub(FakeTransport(fail=RuntimeError("down")))
        hub.post_text("x")
        await hub.drain()
        self.assertEqual(hub.health().consecutive_failures, 1)

    async def test_a_message_over_the_limit_is_cut_not_dropped(self):
        hub, tr = make_hub()
        await hub.send_text("<b>" + "line\n" * 3000)
        text = tr.messages[0][1]
        self.assertLessEqual(len(text), 4096)
        self.assertTrue(text.endswith("</b>"))

    def test_post_text_without_a_running_loop_is_dropped_silently(self):
        hub, tr = make_hub()
        hub.post_text("x")
        self.assertEqual(tr.calls, 0)


# ============================================================================================ mirroring notifier
class FakeInner:
    def __init__(self, fail=False):
        self.fail, self.owner, self.group = fail, [], []

    async def notify_owner(self, text):
        if self.fail:
            raise RuntimeError("private chat unreachable")
        self.owner.append(text)

    async def notify_group(self, group_id, text):
        self.group.append((group_id, text))


class MirrorTests(unittest.IsolatedAsyncioTestCase):
    async def test_owner_notices_reach_both_the_private_chat_and_the_hub(self):
        hub, tr = make_hub()
        inner = FakeInner()
        await HubMirroringNotifier(inner, hub).notify_owner("📥 new group")
        await hub.drain()
        self.assertEqual((inner.owner, [m[1] for m in tr.messages]), (["📥 new group"], ["📥 new group"]))

    async def test_group_notices_are_not_mirrored(self):
        hub, tr = make_hub()
        inner = FakeInner()
        await HubMirroringNotifier(inner, hub).notify_group(A, "pending")
        await hub.drain()
        self.assertEqual((inner.group, tr.calls), ([(A, "pending")], 0))

    async def test_a_failing_private_message_still_raises_to_the_caller_and_still_reaches_the_hub(self):
        hub, tr = make_hub()
        notifier = HubMirroringNotifier(FakeInner(fail=True), hub)
        with self.assertRaises(RuntimeError):
            await notifier.notify_owner("x")
        await hub.drain()
        self.assertEqual(len(tr.messages), 1)

    async def test_a_failing_hub_never_disturbs_the_private_notice(self):
        hub, tr = make_hub(FakeTransport(fail=RuntimeError("hub down")))
        inner = FakeInner()
        await HubMirroringNotifier(inner, hub).notify_owner("x")
        await hub.drain()
        self.assertEqual(inner.owner, ["x"])

    async def test_registering_a_group_works_when_the_hub_and_the_private_chat_both_fail(self):
        s = Stack()
        hub, tr = make_hub(FakeTransport(fail=RuntimeError("hub down")))
        notifier = HubMirroringNotifier(FakeInner(fail=True), hub)
        outcome = await handle_bot_added(s.license_service, notifier, group_id=A, title="Group A")
        await hub.drain()
        self.assertEqual((outcome.created, outcome.status), (True, S.PENDING))
        self.assertEqual((await s.licenses.get(A)).status, S.PENDING)
        decision = await s.license_service.check(A)
        self.assertFalse(decision.allowed)  # pending: protection stays off, hub or no hub

    async def test_a_new_group_notice_reaches_the_hub_with_title_and_id(self):
        s = Stack()
        hub, tr = make_hub()
        await handle_bot_added(s.license_service, HubMirroringNotifier(FakeInner(), hub), group_id=A, title="Group <A>")
        await hub.drain()
        text = tr.messages[0][1]
        self.assertIn(str(A), text)
        self.assertIn("Group &lt;A&gt;", text)


# ============================================================================================ reports
def lic(gid, status, expires=None, title=None, activated=None):
    return GroupLicense(gid, title if title is not None else f"G{gid}", status, NOW, activated or NOW, expires, OWNER)


class ReportTextTests(unittest.TestCase):
    def test_statistics_use_the_effective_status_not_the_stored_one(self):
        rows = [lic(-1, S.ACTIVE_PERMANENT), lic(-2, S.ACTIVE_TEMPORARY, NOW + timedelta(days=30)),
                lic(-3, S.ACTIVE_TEMPORARY, NOW - timedelta(days=1)), lic(-4, S.PENDING), lic(-5, S.BANNED)]
        text = stats_text(rows, NOW, TZ, "ar")
        self.assertIn("المجموعات</b>: 5", text)
        self.assertRegex(text, r"منتهية: <b>1</b>")           # the lapsed temporary one
        self.assertRegex(text, r"مفعّلة مؤقتًا: <b>1</b>")
        self.assertRegex(text, r"محظورة: <b>1</b>")

    def test_no_groups_and_english(self):
        self.assertIn("لا مجموعات", stats_text([], NOW, TZ, "ar"))
        self.assertIn("No groups", stats_text([], NOW, TZ, "en"))
        self.assertIn("Groups</b>: 1", stats_text([lic(-1, S.PENDING)], NOW, TZ, "en"))

    def test_groups_ending_within_a_week_are_listed_soonest_first_and_capped(self):
        rows = [lic(-10 - i, S.ACTIVE_TEMPORARY, NOW + timedelta(days=1 + i % 6, hours=i)) for i in range(8)]
        rows.append(lic(-99, S.ACTIVE_TEMPORARY, NOW + timedelta(days=20)))
        text = stats_text(rows, NOW, TZ, "ar")
        lines = [l for l in text.splitlines() if l.startswith("• G-")]
        self.assertEqual(len(lines), rp.MAX_EXPIRING_LINES)
        self.assertNotIn("-99", text)
        self.assertIn("Asia/Riyadh", lines[0])
        self.assertIn("G-10", lines[0])

    def test_titles_are_escaped(self):
        text = stats_text([lic(-1, S.ACTIVE_TEMPORARY, NOW + timedelta(days=1), title="<script>x</script>")], NOW, TZ, "ar")
        self.assertNotIn("<script>", text)
        self.assertIn("&lt;script&gt;", text)

    def test_license_change_texts_for_every_action(self):
        temp = lic(A, S.ACTIVE_TEMPORARY, NOW + timedelta(days=30))
        perm = lic(A, S.ACTIVE_PERMANENT)
        cases = [("activate_permanent", perm, "تفعيل دائم"), ("activate_temporary", temp, "تفعيل لمدة"), ("renew", temp, "تجديد"),
                 ("stop", lic(A, S.STOPPED), "إيقاف"), ("reject", lic(A, S.REJECTED), "رفض"), ("ban", lic(A, S.BANNED), "حظر"),
                 ("unban", lic(A, S.PENDING), "رفع الحظر"), ("allow", lic(A, S.PENDING), "إعادة السماح")]
        for action, row, word in cases:
            with self.subTest(action):
                text = license_change_text(row, action, rp.SOURCE_PANEL, NOW, TZ, "ar")
                self.assertIn(word, text)
                self.assertIn(str(A), text)
                self.assertIn("لوحة المالك", text)
                self.assertEqual("الانتهاء" in text, row.status is S.ACTIVE_TEMPORARY)
                for secret in SECRETS:
                    self.assertNotIn(secret, text)

    def test_license_change_text_shows_mecca_time_source_and_english(self):
        row = lic(A, S.ACTIVE_TEMPORARY, NOW + timedelta(days=3))
        ar = license_change_text(row, "activate_temporary", rp.SOURCE_COMMAND, NOW, TZ, "ar")
        self.assertIn("2026-11-01 15:00 (Asia/Riyadh)", ar)
        self.assertIn("أمر في المجموعة", ar)
        self.assertIn("Group command".lower(), license_change_text(row, "renew", rp.SOURCE_COMMAND, NOW, TZ, "en").lower())

    def test_an_untitled_group_has_a_label(self):
        text = license_change_text(GroupLicense(A, None, S.PENDING, NOW), "unban", rp.SOURCE_PANEL, NOW, TZ, "ar")
        self.assertIn("بدون عنوان", text)

    def test_every_hub_key_exists_in_both_languages(self):
        keys = {k for k in MESSAGES["ar"] if k.startswith("hub_")}
        self.assertGreaterEqual(len(keys), 20)
        self.assertEqual(keys, {k for k in MESSAGES["en"] if k.startswith("hub_")})


class ReporterTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A, B)
        await self.s.admin.activate_permanent(OWNER, A, context_chat_id=A)
        self.hub, self.tr = make_hub(clock=self.s.clock)
        self.rep = HubReporter(self.hub, self.s.licenses, display_timezone=TZ, version="9.9.9-test", environment="test",
                               clock=self.s.clock)

    async def test_startup_report_has_version_time_database_and_statistics(self):
        await self.rep.startup(db_status="ok")
        text = self.tr.messages[0][1]
        for part in ("9.9.9-test", "test", "2026-10-29 15:00 (Asia/Riyadh)", "متصلة", "المجموعات</b>: 2"):
            self.assertIn(part, text)

    async def test_startup_report_never_contains_a_secret(self):
        await self.rep.startup(db_status="ok")
        for secret in SECRETS:
            self.assertNotIn(secret, self.tr.messages[0][1])

    async def test_database_down_or_unknown_skips_statistics(self):
        reads = []
        original = self.s.licenses.list_all

        async def spy(*a, **k):
            reads.append(1)
            return await original(*a, **k)

        self.s.licenses.list_all = spy
        await self.rep.startup(db_status="unavailable")
        await self.rep.startup(db_status="unknown")
        self.assertEqual(reads, [])
        down, unknown = (m[1] for m in self.tr.messages)
        self.assertIn("غير متاحة", down)
        self.assertIn("لم تُفحص", unknown)
        self.assertIn("تعذر قراءة", down)

    async def test_statistics_survive_a_store_failure(self):
        async def broken(*a, **k):
            raise RuntimeError("db down")

        self.s.licenses.list_all = broken
        self.assertIn("تعذر قراءة", await self.rep.stats())
        await self.rep.startup(db_status="ok")
        self.assertEqual(len(self.tr.messages), 1)

    async def test_post_startup_is_scheduled_and_drain_waits(self):
        self.rep.post_startup("ok")
        self.assertEqual(self.tr.messages, [])
        await self.rep.drain()
        self.assertEqual(len(self.tr.messages), 1)

    async def test_post_startup_with_a_disabled_hub_schedules_nothing(self):
        rep = HubReporter(DisabledHub(), self.s.licenses)
        rep.post_startup("ok")
        self.assertEqual(rep._tasks, set())

    async def test_a_dead_hub_does_not_break_the_startup_report(self):
        hub, tr = make_hub(FakeTransport(fail=RuntimeError("down")), clock=self.s.clock)
        await HubReporter(hub, self.s.licenses, clock=self.s.clock).startup(db_status="ok")
        self.assertEqual(hub.health().consecutive_failures, 1)

    async def test_license_changed_ignores_missing_data(self):
        self.rep.license_changed(None, "stop", "panel")
        self.rep.license_changed(lic(A, S.STOPPED), None, "panel")
        await self.rep.drain()
        self.assertEqual(self.tr.messages, [])


# ============================================================================================ hooks
def press_data(code, status, gid=A, chat=OWNER):
    return codec.build(KEY, chat, codec.DO, action=code, status=status, group_id=gid, filter="a", page=0)


class PanelHookTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A, B)
        self.hub, self.tr = make_hub(clock=self.s.clock)
        self.rep = HubReporter(self.hub, self.s.licenses, display_timezone=TZ, clock=self.s.clock)
        self.claims = InMemoryIdempotency()
        actions = OwnerActions(license_admin=self.s.admin, licenses=self.s.licenses, claims=self.claims, clock=self.s.clock)
        self.svc = OwnerPanelService(permissions=self.s.perm, licenses=self.s.licenses, audit=self.s.audit, secret=PANEL_SECRET,
                                     clock=self.s.clock, actions=actions, hub=self.rep)
        self.n = 0

    async def press(self, data, *, presser=OWNER, chat=None, cbid=None):
        self.n += 1
        return await self.svc.press(presser if chat is None else chat, "private", presser, data, "ar", cbid or f"cb{self.n}")

    async def test_a_change_made_from_the_panel_is_reported_after_it_was_applied(self):
        out = await self.press(press_data("ap", "p"))
        self.assertEqual(out.status, "done")
        await self.rep.drain()
        self.assertEqual(len(self.tr.messages), 1)
        chat, text = self.tr.messages[0]
        self.assertEqual(chat, OWNER_GROUP)
        for part in ("تفعيل دائم", str(A), "لوحة المالك", "مفعّلة دائمًا"):
            self.assertIn(part, text)
        self.assertEqual((await self.s.licenses.get(A)).status, S.ACTIVE_PERMANENT)

    async def test_nothing_is_reported_when_nothing_changed(self):
        await self.press(press_data("ap", "p"))
        await self.rep.drain()
        before = len(self.tr.messages)
        stale = await self.press(press_data("ap", "p"))                   # the group is not pending any more
        same = await self.press(press_data("ap", "d"))                    # permanent -> permanent: no change
        real = await self.press(press_data("st", "d"), cbid="same")       # a real change ...
        again = await self.press(press_data("st", "d"), cbid="same")      # ... redelivered after it: stale (5.4 decision 5)
        await self.rep.drain()
        self.assertEqual((stale.status, same.status, real.status, again.status), ("stale", "no_change", "done", "stale"))
        self.assertEqual(len(self.tr.messages) - before, 1)               # only the real stop

    async def test_a_forged_press_from_a_stranger_changes_and_reports_nothing(self):
        out = await self.press(press_data("ap", "p", chat=STRANGER), presser=STRANGER, chat=STRANGER)
        self.assertNotEqual(out.status, "done")
        out2 = await self.press(press_data("ap", "p"), presser=TG_ADMIN, chat=TG_ADMIN)
        self.assertNotEqual(out2.status, "done")
        await self.rep.drain()
        self.assertEqual((self.tr.calls, (await self.s.licenses.get(A)).status), (0, S.PENDING))

    async def test_a_dead_owner_group_never_blocks_or_repeats_the_change(self):
        hub, tr = make_hub(FakeTransport(fail=RuntimeError("chat not found")), clock=self.s.clock)
        self.svc._hub = HubReporter(hub, self.s.licenses, clock=self.s.clock)
        out = await self.press(press_data("ap", "p"))
        await self.svc._hub.drain()
        self.assertEqual(out.status, "done")
        self.assertEqual((await self.s.licenses.get(A)).status, S.ACTIVE_PERMANENT)
        self.assertEqual(len([e for e in self.s.licenses.audit_log if e.group_id == A and e.action == "activate_permanent"]), 1)
        self.assertEqual(tr.calls, 1)                                      # one attempt, no retry

    async def test_without_a_hub_the_panel_works_as_before(self):
        svc = OwnerPanelService(permissions=self.s.perm, licenses=self.s.licenses, audit=self.s.audit, secret=PANEL_SECRET,
                                clock=self.s.clock, actions=OwnerActions(license_admin=self.s.admin, licenses=self.s.licenses,
                                                                         claims=InMemoryIdempotency(), clock=self.s.clock))
        out = await svc.press(OWNER, "private", OWNER, press_data("ap", "p"), "ar", "x1")
        self.assertEqual(out.status, "done")


class CommandHookTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A)
        self.hub, self.tr = make_hub(clock=self.s.clock)
        self.rep = HubReporter(self.hub, self.s.licenses, display_timezone=TZ, clock=self.s.clock)
        self.svc = LicenseCommandService(license_admin=self.s.admin, license_service=self.s.license_service, permissions=self.s.perm,
                                         claims=InMemoryIdempotency(), clock=self.s.clock, hub=self.rep)
        self.mid = 0

    async def run_cmd(self, text, actor=OWNER, chat=A):
        self.mid += 1
        return await self.svc.handle(parse_license_command(text, "guardbot"), chat_id=chat, actor_id=actor, message_id=self.mid)

    async def test_an_owner_command_is_reported_with_its_source(self):
        res = await self.run_cmd("تفعيل البوت 3 أيام")
        await self.rep.drain()
        self.assertEqual(len(self.tr.messages), 1)
        text = self.tr.messages[0][1]
        self.assertIn("أمر في المجموعة", text)
        self.assertIn("2026-11-01 15:00 (Asia/Riyadh)", text)
        self.assertIsNotNone(res)

    async def test_stop_is_reported_and_a_repeat_is_not(self):
        await self.run_cmd("تفعيل البوت")
        await self.run_cmd("إيقاف البوت")
        await self.run_cmd("إيقاف البوت")           # already stopped: no change
        await self.rep.drain()
        self.assertEqual(len(self.tr.messages), 2)

    async def test_refused_or_non_owner_commands_report_nothing(self):
        await self.run_cmd("تفعيل البوت", actor=TG_ADMIN)
        await self.run_cmd("تفعيل البوت", actor=STRANGER)
        await self.run_cmd("تفعيل البوت 0 يوم")      # invalid duration
        await self.rep.drain()
        self.assertEqual((self.tr.calls, (await self.s.licenses.get(A)).status), (0, S.PENDING))

    async def test_a_dead_hub_does_not_change_the_command_result(self):
        hub, tr = make_hub(FakeTransport(fail=RuntimeError("down")), clock=self.s.clock)
        self.svc._hub = HubReporter(hub, self.s.licenses, clock=self.s.clock)
        res = await self.run_cmd("تفعيل البوت")
        await self.svc._hub.drain()
        self.assertEqual((await self.s.licenses.get(A)).status, S.ACTIVE_PERMANENT)
        self.assertIn("دائمًا", res.text)


class RawTextTests(unittest.TestCase):
    def test_raw_text_is_inserted_as_is_but_ordinary_values_are_still_escaped(self):
        self.assertIn("<b>x</b>", t("hub_stats", "ar", total=1, lines=Raw("<b>x</b>")))
        self.assertIn("&lt;b&gt;x&lt;/b&gt;", t("hub_stats", "ar", total=1, lines="<b>x</b>"))

    def test_a_group_title_can_never_be_raw(self):
        # titles are user-controlled: the reports only wrap text they built themselves from t() pieces
        text = license_change_text(lic(A, S.PENDING, title="<b>x</b>"), "unban", rp.SOURCE_PANEL, NOW, TZ, "ar")
        self.assertIn("&lt;b&gt;x&lt;/b&gt;", text)


# ============================================================================================ static guards
class StaticGuardTests(unittest.TestCase):
    def read(self, rel):
        return (SRC / rel).read_text(encoding="utf-8")

    def test_the_hub_package_only_observes(self):
        """It may read licenses (`list_all`) and tell the sender; it must never change a license, a setting or a sanction."""
        forbidden = re.compile(r"\.(transition|activate_permanent|activate_temporary|stop|reject|ban|unban|allow|set_setting|"
                               r"register_pending_if_absent|record|upsert|delete|insert)\(")
        for path in (SRC / "owner_hub").glob("*.py"):
            self.assertIsNone(forbidden.search(path.read_text(encoding="utf-8")), path.name)

    def test_the_hub_never_imports_a_write_side_service(self):
        for path in (SRC / "owner_hub").glob("*.py"):
            tree = ast.parse(path.read_text(encoding="utf-8"))
            for node in ast.walk(tree):
                if isinstance(node, ast.ImportFrom):
                    mod = node.module or ""
                    self.assertNotIn("admin", mod, path.name)
                    self.assertNotIn("moderation", mod, path.name)
                    self.assertNotIn("postgres_store", mod, path.name)
                    self.assertNotIn("aiogram", mod, path.name)

    def test_the_aiogram_adapter_is_thin_and_uses_the_fixed_chat_the_sender_gives(self):
        tree = ast.parse(self.read("bot/hub_transport.py"))
        calls = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                 and n.func.attr in {"send_message", "send_document"}]
        self.assertEqual(sorted(c.func.attr for c in calls), ["send_document", "send_message"])
        for call in calls:
            self.assertIsInstance(call.args[0], ast.Name)
            self.assertEqual(call.args[0].id, "chat_id")
            self.assertEqual([k.arg for k in call.keywords if k.arg == "parse_mode"], [])

    def test_the_app_builds_the_hub_from_the_configured_group_and_mirrors_the_owner_notifier(self):
        src = self.read("app.py")
        self.assertIn("settings.owner_group_id", src)
        self.assertIn("secrets=settings.secret_values()", src)
        self.assertIn("HubMirroringNotifier(TelegramNotifier(", src)
        self.assertEqual(src.count("hub=hub_reporter"), 2)           # owner panel + group license commands
        self.assertIn("hub_reporter.post_startup(", src)
        self.assertIn("await hub_reporter.drain()", src)

    def test_owner_group_membership_still_grants_nothing(self):
        perms = self.read("permissions.py")
        self.assertIn("OWNER_GROUP_ID", perms)
        for path in (SRC / "owner_hub").glob("*.py"):
            self.assertNotIn("owner_group_id", path.read_text(encoding="utf-8"), path.name)  # the sender gets a plain id, no authority

    def test_no_env_file_or_secret_is_part_of_the_project_tree(self):
        root = SRC.parents[1]
        for path in root.rglob(".env"):
            self.fail(f"a .env file is in the project: {path}")


if __name__ == "__main__":
    unittest.main()
