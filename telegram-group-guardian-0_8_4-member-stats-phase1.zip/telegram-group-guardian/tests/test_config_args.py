"""Closing part 3, pure parsing: `/lock /unlock /slowmode /antiflood /protect` (parse_command + config_args).

No Telegram, no permissions here: only text -> typed value / stable error code."""
from __future__ import annotations

import unittest

from guardian.i18n import MESSAGES
from guardian.moderation import config_args as ca
from guardian.moderation.commands import (
    CONFIG_COMMANDS, LOCK_COMMANDS, SETTINGS_COMMANDS, Command, CommandError, parse_command,
)
from guardian.moderation.messages import error_message
from guardian.protection.settings import (
    DEFAULT_ESCALATION, DUPLICATE_REPEATS, DUPLICATE_WINDOW, ESCALATION_WINDOW, FLOOD_MESSAGES, FLOOD_WINDOW,
    MAX_MUTE, MIN_MUTE, SLOWMODE, WARN_LIMIT, ProtectionSettings,
)

BOT = "GuardianBot"


def p(text, reply=False):
    return parse_command(text, BOT, has_reply=reply)


def code(fn, *a):
    try:
        fn(*a)
    except CommandError as exc:
        return exc.code
    raise AssertionError("no CommandError raised")


class AliasTests(unittest.TestCase):
    def test_slash_forms_and_bot_suffix(self):
        for text, cmd in (("/lock all", Command.LOCK), ("/UNLOCK media", Command.UNLOCK), ("/slowmode", Command.SLOWMODE),
                          ("/antiflood on", Command.ANTIFLOOD), ("/protect", Command.PROTECT),
                          (f"/lock@{BOT} media", Command.LOCK)):
            self.assertIs(p(text).command, cmd, text)
        self.assertIsNone(p("/lock@OtherBot media"))
        self.assertEqual(LOCK_COMMANDS | SETTINGS_COMMANDS, CONFIG_COMMANDS)

    def test_arabic_aliases_with_their_own_vocabulary(self):
        for text, cmd in (("قفل الوسائط", Command.LOCK), ("اقفل الكل", Command.LOCK), ("قفل الملصقات الاستطلاعات", Command.LOCK),
                          ("فتح الوسائط", Command.UNLOCK), ("افتح النص", Command.UNLOCK), ("الغاء القفل الكل", Command.UNLOCK),
                          ("قفل الروابط", Command.LOCK),  # recognised so the user gets the helpful "no such permission" answer
                          ("الوضع البطيء", Command.SLOWMODE), ("الوضع البطئ 30", Command.SLOWMODE),
                          ("وضع بطيء ايقاف", Command.SLOWMODE), ("الوضع البطيء ٣٠", Command.SLOWMODE),
                          ("مكافحة الفيضان", Command.ANTIFLOOD), ("مكافحة الفيضان تشغيل", Command.ANTIFLOOD),
                          ("مضاد الفيضان 6 10", Command.ANTIFLOOD), ("اعدادات الحماية", Command.PROTECT),
                          ("ضبط الحماية الروابط تشغيل", Command.PROTECT), ("إعدادات الحماية", Command.PROTECT)):
            parsed = p(text)
            self.assertIsNotNone(parsed, text)
            self.assertIs(parsed.command, cmd, text)
            self.assertTrue(parsed.arabic)

    def test_ordinary_chat_is_never_a_command(self):
        for text in ("قفل الباب", "قفل", "فتح الموضوع", "فتح", "اقفل الباب وراءك", "افتح النافذة", "قفل الوسائط والصور",
                     "الوضع البطيء جدا اليوم", "الوضع البطيء ثلاثين", "مكافحة الفيضان مهمة", "مكافحة الفيضان 1 2 3",
                     "اعدادات الحماية غير واضحة", "ضبط الحماية الان", "الغاء القفل", "قفل كل شيء"):
            self.assertIsNone(p(text), text)
        # a reply does not make ordinary words a config command either (no member target is involved)
        self.assertIsNone(p("قفل الباب", reply=True))
        self.assertIsNone(p("فتح الموضوع", reply=True))

    def test_new_aliases_do_not_shadow_existing_ones(self):
        self.assertIs(p("الغاء الحظر @abcde").command, Command.UNBAN)
        self.assertIs(p("الغاء الكتم", reply=True).command, Command.UNMUTE)
        self.assertIs(p("الغاء التثبيت").command, Command.UNPIN)
        self.assertIs(p("حظر", reply=True).command, Command.BAN)
        self.assertIsNone(p("تفعيل البوت"))  # licensing words are not ours


class LockArgsTests(unittest.TestCase):
    def test_types_flags_and_synonyms(self):
        a = ca.parse_lock_args(["media"])
        self.assertEqual(a.types, ("media",))
        self.assertEqual(set(a.flags), set(ca.FLAG_MEDIA))
        self.assertEqual(ca.parse_lock_args(["الوسائط"]).types, ("media",))
        self.assertEqual(ca.parse_lock_args(["Stickers"]).flags, ca.FLAG_STICKERS)
        self.assertEqual(ca.parse_lock_args(["gifs"]).types, ("stickers",))
        self.assertEqual(ca.parse_lock_args(["الاستطلاعات"]).flags, ("can_send_polls",))
        self.assertEqual(ca.parse_lock_args(["المعاينة"]).flags, ("can_add_web_page_previews",))
        self.assertEqual(ca.parse_lock_args(["النص"]).flags, ("can_send_messages",))

    def test_several_types_dedupe_and_all_absorbs(self):
        a = ca.parse_lock_args(["polls", "media", "polls"])
        self.assertEqual(a.types, ("polls", "media"))
        self.assertEqual(len(a.flags), len(set(a.flags)))
        every = ca.parse_lock_args(["media", "all", "text"])
        self.assertEqual(every.types, ("all",))
        self.assertEqual(set(every.flags), set(ca.LOCKABLE_FLAGS))

    def test_dangerous_permissions_are_never_lockable(self):
        for flag in ("can_change_info", "can_invite_users", "can_pin_messages", "can_manage_topics"):
            self.assertNotIn(flag, ca.LOCKABLE_FLAGS)
        self.assertEqual(ca.LOCKABLE_FLAGS, set(ca.FLAG_TEXT + ca.FLAG_MEDIA + ca.FLAG_STICKERS + ca.FLAG_POLLS + ca.FLAG_PREVIEWS))

    def test_errors_never_guess(self):
        self.assertEqual(code(ca.parse_lock_args, []), "lock_need_type")  # a bare /lock locks nothing
        self.assertEqual(code(ca.parse_lock_args, ["files"]), "lock_unknown")
        self.assertEqual(code(ca.parse_lock_args, ["media", "oops"]), "lock_unknown")
        self.assertEqual(code(ca.parse_lock_args, ["links"]), "lock_links")
        self.assertEqual(code(ca.parse_lock_args, ["الروابط"]), "lock_links")
        self.assertEqual(code(ca.parse_lock_args, ["media"] * 9), "too_many_args")


class SlowmodeAndFloodArgsTests(unittest.TestCase):
    def test_slowmode_values(self):
        self.assertIsNone(ca.parse_slowmode_args([]).seconds)
        for word, seconds in (("30", 30), ("30s", 30), ("5m", 300), ("1h", 3600), ("٣٠", 30), ("5", 5), ("1H", 3600),
                              ("off", 0), ("0", 0), ("ايقاف", 0), ("OFF", 0)):
            self.assertEqual(ca.parse_slowmode_args([word]).seconds, seconds, word)

    def test_slowmode_errors(self):
        for bad, expected in (("4", "slowmode_range"), ("3601", "slowmode_range"), ("2h", "slowmode_range"),
                              ("abc", "slowmode_format"), ("-5", "slowmode_format"), ("1.5", "slowmode_format"),
                              ("5x", "slowmode_format"), ("", "slowmode_format")):
            self.assertEqual(code(ca.parse_slowmode_args, [bad]), expected, bad)
        self.assertEqual(code(ca.parse_slowmode_args, ["5", "10"]), "slowmode_format")

    def test_antiflood_forms(self):
        self.assertIsNone(ca.parse_antiflood_args([]).patch)
        self.assertEqual(ca.parse_antiflood_args(["on"]).patch, {"flood_enabled": True})
        self.assertEqual(ca.parse_antiflood_args(["تشغيل"]).patch, {"flood_enabled": True})
        self.assertEqual(ca.parse_antiflood_args(["off"]).patch, {"flood_enabled": False})
        self.assertEqual(ca.parse_antiflood_args(["0"]).patch, {"flood_enabled": False})
        self.assertEqual(ca.parse_antiflood_args(["8"]).patch, {"flood_enabled": True, "flood_max_messages": 8})
        self.assertEqual(ca.parse_antiflood_args(["٨", "20"]).patch,
                         {"flood_enabled": True, "flood_max_messages": 8, "flood_window_seconds": 20})
        self.assertEqual(ca.parse_antiflood_args(["5", "1m"]).patch["flood_window_seconds"], 60)

    def test_antiflood_errors(self):
        self.assertEqual(code(ca.parse_antiflood_args, ["1"]), "antiflood_range")
        self.assertEqual(code(ca.parse_antiflood_args, ["101"]), "antiflood_range")
        self.assertEqual(code(ca.parse_antiflood_args, ["5", "1"]), "antiflood_range")
        self.assertEqual(code(ca.parse_antiflood_args, ["5", "601"]), "antiflood_range")
        self.assertEqual(code(ca.parse_antiflood_args, ["many"]), "antiflood_args")
        self.assertEqual(code(ca.parse_antiflood_args, ["on", "5"]), "antiflood_args")
        self.assertEqual(code(ca.parse_antiflood_args, ["5", "10", "x"]), "antiflood_args")
        self.assertEqual(code(ca.parse_antiflood_args, ["5", "xx"]), "antiflood_args")


class ProtectArgsTests(unittest.TestCase):
    def pp(self, *words):
        return ca.parse_protect_args(list(words))

    def test_show_and_allow_list(self):
        self.assertEqual(self.pp().op, "show")
        self.assertEqual(self.pp("show").op, "show")
        self.assertEqual(self.pp("allow").op, "allow_list")
        self.assertEqual(self.pp("allow", "list").op, "allow_list")
        self.assertEqual(self.pp("النطاقات", "عرض").op, "allow_list")
        self.assertEqual(code(ca.parse_protect_args, ["show", "x"]), "protect_args")

    def test_toggles(self):
        self.assertEqual(self.pp("links", "off").patch, {"links_enabled": False})
        self.assertEqual(self.pp("الروابط", "تشغيل").patch, {"links_enabled": True})
        self.assertEqual(self.pp("links", "1").patch, {"links_enabled": True})
        self.assertEqual(self.pp("invites", "allow").patch, {"links_allow_invites": True})
        self.assertEqual(self.pp("invites", "block").patch, {"links_allow_invites": False})
        self.assertEqual(self.pp("الدعوات", "منع").patch, {"links_allow_invites": False})
        for bad in (("links",), ("links", "maybe"), ("links", "on", "off"), ("dryrun",), ("dryrun", "x")):
            self.assertEqual(code(ca.parse_protect_args, list(bad)), "protect_bool", bad)
        self.assertEqual(code(ca.parse_protect_args, ["invites", "on"]), "protect_args")  # on/off is ambiguous for invites

    def test_flood_duplicates_slowmode_reuse_the_command_rules(self):
        self.assertEqual(self.pp("flood", "6", "10").patch,
                         {"flood_enabled": True, "flood_max_messages": 6, "flood_window_seconds": 10})
        self.assertEqual(self.pp("duplicates", "off").patch, {"duplicate_enabled": False})
        self.assertEqual(self.pp("duplicates", "4", "2m").patch,
                         {"duplicate_enabled": True, "duplicate_max_repeats": 4, "duplicate_window_seconds": 120})
        self.assertEqual(self.pp("slowmode", "30").patch, {"slowmode_seconds": 30})
        self.assertEqual(self.pp("slowmode", "off").patch, {"slowmode_seconds": 0})
        self.assertEqual(code(ca.parse_protect_args, ["flood", "1"]), "protect_range")
        self.assertEqual(code(ca.parse_protect_args, ["duplicates", "2", "4"]), "protect_range")
        self.assertEqual(code(ca.parse_protect_args, ["slowmode", "4"]), "protect_range")
        self.assertEqual(code(ca.parse_protect_args, ["flood", "lots"]), "protect_args")
        self.assertEqual(code(ca.parse_protect_args, ["slowmode"]), "protect_args")

    def test_escalation_window_warn(self):
        self.assertEqual(self.pp("escalation", "10m", "1h", "1d").patch["escalation_mutes_seconds"], [600, 3600, 86400])
        self.assertEqual(self.pp("escalation", "default").patch["escalation_mutes_seconds"], list(DEFAULT_ESCALATION))
        self.assertEqual(self.pp("escalation", "30d").patch["escalation_mutes_seconds"], [MAX_MUTE])
        self.assertEqual(code(ca.parse_protect_args, ["escalation", "31d"]), "protect_range")
        self.assertEqual(code(ca.parse_protect_args, ["escalation", "30s"]), "duration")
        self.assertEqual(code(ca.parse_protect_args, ["escalation", "10"]), "duration")
        self.assertEqual(code(ca.parse_protect_args, ["escalation"]), "protect_args")
        self.assertEqual(code(ca.parse_protect_args, ["escalation"] + ["10m"] * 11), "protect_range")
        self.assertEqual(self.pp("window", "7d").patch, {"escalation_window_seconds": 7 * 86400})
        self.assertEqual(code(ca.parse_protect_args, ["window", "30m"]), "protect_range")
        self.assertEqual(self.pp("warnlimit", "5").patch, {"warn_limit": 5})
        self.assertEqual(code(ca.parse_protect_args, ["warnlimit", "0"]), "protect_range")
        self.assertEqual(code(ca.parse_protect_args, ["warnlimit", "21"]), "protect_range")
        self.assertEqual(code(ca.parse_protect_args, ["warnlimit", "x"]), "protect_args")

    def test_warnaction_requires_an_explicit_duration_for_mute_and_ban(self):
        self.assertEqual(self.pp("warnaction", "kick").patch, {"warn_action": "kick"})
        self.assertEqual(self.pp("warnaction", "mute", "1d").patch, {"warn_action": "mute", "warn_action_seconds": 86400})
        self.assertEqual(self.pp("warnaction", "ban", "perm").patch, {"warn_action": "ban", "warn_action_seconds": 0})
        self.assertEqual(self.pp("warnaction", "حظر", "دائم").patch, {"warn_action": "ban", "warn_action_seconds": 0})
        for bad in (("warnaction",), ("warnaction", "mute"), ("warnaction", "ban"), ("warnaction", "kick", "1d"),
                    ("warnaction", "explode", "1d"), ("warnaction", "mute", "1d", "x")):
            self.assertEqual(code(ca.parse_protect_args, list(bad)), "protect_args", bad)
        self.assertEqual(code(ca.parse_protect_args, ["warnaction", "mute", "5s"]), "duration")

    def test_dryrun_is_flagged_owner_only(self):
        a = self.pp("dryrun", "on")
        self.assertEqual((a.patch, a.owner_only), ({"dry_run": True}, True))
        self.assertFalse(self.pp("links", "off").owner_only)

    def test_allow_domains(self):
        a = self.pp("allow", "add", "https://WWW.Example.com/x", "docs.python.org", "example.com")
        self.assertEqual((a.op, a.domains), ("allow_add", ("example.com", "docs.python.org")))
        self.assertEqual(self.pp("allow", "remove", "example.com").op, "allow_remove")
        self.assertEqual(self.pp("allow", "clear").op, "allow_clear")
        self.assertEqual(self.pp("allow", "-", "a.com").op, "allow_remove")
        self.assertEqual(code(ca.parse_protect_args, ["allow", "add"]), "protect_args")
        self.assertEqual(code(ca.parse_protect_args, ["allow", "add", "not a domain!"]), "protect_domain")
        self.assertEqual(code(ca.parse_protect_args, ["allow", "add", "ok.com", "bad..com"]), "protect_domain")
        self.assertEqual(code(ca.parse_protect_args, ["allow", "clear", "x.com"]), "protect_args")
        self.assertEqual(code(ca.parse_protect_args, ["allow", "wipe"]), "protect_args")

    def test_unknown_subcommand(self):
        self.assertEqual(code(ca.parse_protect_args, ["explode"]), "protect_args")
        self.assertEqual(code(ca.parse_protect_args, ["x"] * 21), "too_many_args")


class ParityAndMessagesTests(unittest.TestCase):
    def test_every_accepted_boundary_value_survives_from_raw_and_one_beyond_is_rejected(self):
        cases = (("flood_max_messages", FLOOD_MESSAGES, lambda v: ["flood", str(v)], "protect_range"),
                 ("duplicate_max_repeats", DUPLICATE_REPEATS, lambda v: ["duplicates", str(v)], "protect_range"),
                 ("warn_limit", WARN_LIMIT, lambda v: ["warnlimit", str(v)], "protect_range"),
                 ("slowmode_seconds", SLOWMODE, lambda v: ["slowmode", f"{v}s"], "protect_range"))
        for key, (lo, hi), words, err in cases:
            for value in (lo, hi):
                patch = ca.parse_protect_args(words(value)).patch
                self.assertEqual(getattr(ProtectionSettings.from_raw(patch), key), value, (key, value))
            for value in (lo - 1, hi + 1):
                self.assertEqual(code(ca.parse_protect_args, words(value)), err, (key, value))
        win = (("flood_window_seconds", FLOOD_WINDOW, lambda v: ["flood", "5", f"{v}s"]),
               ("duplicate_window_seconds", DUPLICATE_WINDOW, lambda v: ["duplicates", "5", f"{v}s"]))
        for key, (lo, hi), words in win:
            for value in (lo, hi):
                self.assertEqual(getattr(ProtectionSettings.from_raw(ca.parse_protect_args(words(value)).patch), key), value)
            for value in (lo - 1, hi + 1):
                self.assertEqual(code(ca.parse_protect_args, words(value)), "protect_range", (key, value))
        for value in (ESCALATION_WINDOW[0], ESCALATION_WINDOW[1]):
            patch = ca.parse_protect_args(["window", f"{value // 3600}h"]).patch
            self.assertEqual(ProtectionSettings.from_raw(patch).escalation_window_seconds, value)
        for value in (MIN_MUTE, MAX_MUTE):
            patch = ca.parse_protect_args(["escalation", f"{value // 60}m"]).patch
            self.assertEqual(ProtectionSettings.from_raw(patch).escalation_mutes_seconds, (value,))

    def test_slowmode_setting_is_clamped_to_off_when_invalid(self):
        for bad in (-1, 1, 4, 3601, True, "30", 2.5, None):
            self.assertEqual(ProtectionSettings.from_raw({"slowmode_seconds": bad}).slowmode_seconds, 0, bad)
        self.assertEqual(ProtectionSettings.from_raw({"slowmode_seconds": 30}).slowmode_seconds, 30)
        self.assertEqual(ProtectionSettings().slowmode_seconds, 0)

    def test_every_error_code_has_a_message_in_both_languages(self):
        codes = ("lock_need_type", "lock_unknown", "lock_links", "slowmode_format", "slowmode_range", "antiflood_args",
                 "antiflood_range", "protect_args", "protect_bool", "protect_range", "protect_domain", "too_many_args")
        for c in codes:
            for lang in ("ar", "en"):
                self.assertIsNotNone(error_message(CommandError(c), lang), (c, lang))
        self.assertIn("/protect links on", MESSAGES["en"]["mod_err_lock_links"])

    def test_alias_vocabulary_check_is_closed_for_unknown_commands(self):
        self.assertFalse(ca.alias_args_ok("ban", ["x"]))


if __name__ == "__main__":
    unittest.main()
