"""Part 6.5a: daily counters, `StatsService` over real data, the engine/command hooks and migration 0009.
PostgreSQL itself is NOT exercised: the stores are checked against a recording fake connection."""
from __future__ import annotations

import re
import unittest
from contextlib import asynccontextmanager
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from executor_stack import A as GA, B as GB, BOT, BOT_NAME, ExecBase, gate
from guardian.audit import InMemorySecurityAudit, SecurityEvent
from guardian.db.migrations import discover
from guardian.errors import InvalidInput
from guardian.moderation.commands import parse_command
from guardian.moderation.executor import ModerationCommandService, ResultKind as R
from guardian.moderation.memory_store import InMemorySanctionStore, InMemoryWarningStore
from guardian.moderation.models import SanctionKind
from guardian.moderation.postgres_store import PostgresSanctionStore, PostgresWarningStore
from guardian.moderation.targets import ReplyInfo
from guardian.reports.memory_store import InMemoryReportStore
from guardian.reports.models import ReportOutcome, ReportPriority, ReportStatus, ReportType
from guardian.reports.postgres_store import PostgresReportStore
from guardian.stats import (Counter, CounterRecorder, GroupStats, StatsPeriod, StatsService, combine, day_bucket,
                            period_range)
from guardian.stats.memory_store import InMemoryCounterStore
from guardian.stats.models import COUNTER_VALUES
from guardian.stats.postgres_store import PostgresCounterStore
from guardian.audit import PostgresSecurityAudit
from stack import NOW, OWNER, TG_ADMIN

ROOT = Path(__file__).resolve().parent.parent
SQL = ROOT / "src" / "guardian" / "db" / "sql" / "0009_daily_counters.sql"
TZ = "Asia/Riyadh"
USER, OTHER = 5001, 5002
# 2026-10-29 12:00 UTC == 15:00 in Riyadh (UTC+3, no DST)
HOUR = timedelta(hours=1)


def at(day: int, hour: int = 12) -> datetime:
    return datetime(2026, 10, day, hour, 0, tzinfo=timezone.utc)


class RangeTests(unittest.TestCase):
    def test_day_bucket_uses_the_local_date(self):
        self.assertEqual(day_bucket(datetime(2026, 10, 29, 20, 59, tzinfo=timezone.utc), TZ), date(2026, 10, 29))
        self.assertEqual(day_bucket(datetime(2026, 10, 29, 21, 0, tzinfo=timezone.utc), TZ), date(2026, 10, 30))

    def test_day_week_month_windows(self):
        d = period_range(StatsPeriod.DAY, NOW, TZ)
        self.assertEqual((d.start_day, d.end_day), (date(2026, 10, 29), date(2026, 10, 29)))
        self.assertEqual(d.start, datetime(2026, 10, 28, 21, 0, tzinfo=timezone.utc))  # local midnight
        self.assertEqual(d.end, datetime(2026, 10, 29, 21, 0, tzinfo=timezone.utc))
        w = period_range(StatsPeriod.WEEK, NOW, TZ)
        self.assertEqual((w.start_day, w.end_day), (date(2026, 10, 23), date(2026, 10, 29)))
        self.assertEqual(w.end - w.start, timedelta(days=7))
        m = period_range(StatsPeriod.MONTH, NOW, TZ)
        self.assertEqual((m.start_day, m.end_day), (date(2026, 9, 30), date(2026, 10, 29)))
        self.assertEqual(m.end - m.start, timedelta(days=30))

    def test_the_window_follows_the_local_day_not_the_utc_day(self):
        late = datetime(2026, 10, 29, 22, 30, tzinfo=timezone.utc)  # already Oct 30 in Riyadh
        self.assertEqual(period_range(StatsPeriod.DAY, late, TZ).start_day, date(2026, 10, 30))

    def test_dst_zone_has_local_midnight_bounds(self):
        r = period_range(StatsPeriod.DAY, datetime(2026, 3, 29, 12, 0, tzinfo=timezone.utc), "Europe/Berlin")
        self.assertEqual(r.end - r.start, timedelta(hours=23))  # the spring-forward day is 23 h long

    def test_unknown_period_is_rejected(self):
        with self.assertRaises(ValueError):
            period_range("year", NOW, TZ)  # type: ignore[arg-type]


class CounterTests(unittest.IsolatedAsyncioTestCase):
    async def test_bump_and_totals_by_day_range(self):
        store = InMemoryCounterStore()
        rec = CounterRecorder(store, TZ, lambda: NOW)
        self.assertTrue(await rec.bump(GA, Counter.VIOLATION))
        self.assertTrue(await rec.bump(GA, Counter.VIOLATION, amount=2))
        self.assertTrue(await rec.bump(GA, Counter.COMMAND, at(27)))
        self.assertTrue(await rec.bump(GB, Counter.VIOLATION))  # another group
        self.assertEqual(await store.totals(GA, date(2026, 10, 29), date(2026, 10, 29)), {"violation": 3})
        self.assertEqual(await store.totals(GA, date(2026, 10, 27), date(2026, 10, 29)), {"violation": 3, "command": 1})
        self.assertEqual(await store.totals(GB, date(2026, 10, 1), date(2026, 10, 31)), {"violation": 1})
        self.assertEqual(await store.totals(GA, date(2026, 11, 1), date(2026, 11, 5)), {})

    async def test_the_recorder_never_raises(self):
        class Down:
            async def bump(self, *a):
                raise RuntimeError("db down")

        rec = CounterRecorder(Down(), TZ, lambda: NOW)
        self.assertFalse(await rec.bump(GA, Counter.COMMAND))
        ok = CounterRecorder(InMemoryCounterStore(), TZ, lambda: NOW)
        self.assertFalse(await ok.bump(7, Counter.COMMAND))        # not a group id (positive)
        self.assertFalse(await ok.bump(GA, "nonsense"))             # type: ignore[arg-type]
        self.assertFalse(await ok.bump(GA, Counter.COMMAND, amount=0))
        self.assertFalse(await ok.bump(GA, Counter.COMMAND, amount=True))  # type: ignore[arg-type]

    async def test_a_late_event_lands_on_the_local_day(self):
        store = InMemoryCounterStore()
        rec = CounterRecorder(store, TZ)
        await rec.bump(GA, Counter.COMMAND, datetime(2026, 10, 29, 22, 0, tzinfo=timezone.utc))
        self.assertEqual(await store.totals(GA, date(2026, 10, 30), date(2026, 10, 30)), {"command": 1})
        self.assertEqual(await store.totals(GA, date(2026, 10, 29), date(2026, 10, 29)), {})


async def seeded():
    """Real stores with a little of everything in group A (and noise in group B / outside the window)."""
    warns, sancs, reports, audit, counters = (InMemoryWarningStore(), InMemorySanctionStore(), InMemoryReportStore(),
                                              InMemorySecurityAudit(), InMemoryCounterStore())
    await warns.add(GA, USER, None, "auto", at(29, 8))
    await warns.add(GA, USER, TG_ADMIN, "manual", at(29, 9))
    w3, _ = await warns.add(GA, OTHER, TG_ADMIN, "manual", at(25))
    await warns.revoke_one(GA, w3.id, TG_ADMIN, at(29, 10))      # revoked today, issued last week
    await warns.add(GB, USER, None, "other group", at(29, 8))
    await sancs.record(GA, USER, SanctionKind.MUTE, None, None, at(29, 8), at(29, 9))
    await sancs.record(GA, USER, SanctionKind.MUTE, TG_ADMIN, None, at(29, 9))
    await sancs.record(GA, OTHER, SanctionKind.BAN, TG_ADMIN, None, at(20))   # outside the day, inside the month
    await sancs.record(GB, USER, SanctionKind.KICK, TG_ADMIN, None, at(29, 8))
    await sancs.lift(GA, USER, SanctionKind.MUTE, TG_ADMIN, at(29, 10))      # lifts the still-active manual mute
    r1, _ = await reports.add(GA, USER, OTHER, 1, "x", ReportType.SPAM, ReportPriority.NORMAL, at(29, 8))
    await reports.add(GA, USER, OTHER, 2, "y", ReportType.SCAM, ReportPriority.NORMAL, at(29, 9))
    await reports.add(GB, USER, OTHER, 3, "z", ReportType.SPAM, ReportPriority.NORMAL, at(29, 9))
    await reports.transition(GA, r1.id, (ReportStatus.OPEN,), ReportStatus.RESOLVED, TG_ADMIN, at(29, 11),
                             ReportOutcome.ACTION_TAKEN)
    for etype, when, gid in (("permission_denied", at(29, 8), GA), ("permission_denied", at(29, 9), GA),
                             ("settings_changed", at(29, 10), GA), ("permission_denied", at(20), GA),
                             ("permission_denied", at(29, 8), GB)):
        await audit.record(SecurityEvent(etype, when, 1, gid))
    rec = CounterRecorder(counters, TZ, lambda: NOW)
    await rec.bump(GA, Counter.VIOLATION, at(29, 9), 4)
    await rec.bump(GA, Counter.COMMAND, at(29, 9), 6)
    await rec.bump(GA, Counter.COMMAND_REJECTED, at(29, 9), 1)
    await rec.bump(GA, Counter.VIOLATION, at(27, 9), 10)
    await rec.bump(GB, Counter.VIOLATION, at(29, 9), 99)
    return StatsService(warnings=warns, sanctions=sancs, reports=reports, audit=audit, counters=counters,
                        display_timezone=TZ, clock=lambda: at(29, 12))


class ServiceTests(unittest.IsolatedAsyncioTestCase):
    async def test_a_day_of_real_data(self):
        st = await (await seeded()).group_stats(GA, StatsPeriod.DAY)
        self.assertEqual(st.group_id, GA)
        self.assertEqual(st.warnings, {"issued_auto": 1, "issued_manual": 1, "revoked": 1})
        self.assertEqual(st.sanctions["mute_auto"], 1)
        self.assertEqual(st.sanctions["mute_manual"], 1)
        self.assertEqual((st.sanctions["ban_manual"], st.sanctions["kick_manual"]), (0, 0))
        self.assertEqual(st.sanctions["lifted"], 1)
        self.assertEqual((st.reports["created"], st.reports["type_spam"], st.reports["type_scam"]), (2, 1, 1))
        self.assertEqual((st.reports["handled_action_taken"], st.reports["open_now"]), (1, 1))
        self.assertEqual(st.audit, {"permission_denied": 2, "settings_changed": 1})
        self.assertEqual(st.counters, {"violation": 4, "command": 6, "command_rejected": 1})
        self.assertTrue(st.complete)

    async def test_week_and_month_widen_the_window(self):
        svc = await seeded()
        week = await svc.group_stats(GA, StatsPeriod.WEEK)
        self.assertEqual(week.counters["violation"], 14)           # 4 today + 10 two days ago
        self.assertEqual(week.warnings["issued_manual"], 2)       # the one issued on the 25th joins in
        self.assertEqual(week.sanctions["ban_manual"], 0)         # the 20th is outside 7 days
        month = await svc.group_stats(GA, StatsPeriod.MONTH)
        self.assertEqual(month.sanctions["ban_manual"], 1)
        self.assertEqual(month.audit["permission_denied"], 3)

    async def test_groups_are_isolated(self):
        st = await (await seeded()).group_stats(GB, StatsPeriod.DAY)
        self.assertEqual(st.counters["violation"], 99)
        self.assertEqual((st.warnings["issued_auto"], st.sanctions["kick_manual"], st.reports["created"]), (1, 1, 1))
        self.assertEqual(st.audit, {"permission_denied": 1})

    async def test_an_empty_group_is_all_zero(self):
        svc = await seeded()
        st = await svc.group_stats(-1999, StatsPeriod.DAY)
        self.assertTrue(all(v == 0 for v in st.counters.values()))
        self.assertTrue(all(v == 0 for v in st.reports.values()))
        self.assertTrue(all(v == 0 for v in st.sanctions.values()))
        self.assertEqual(st.audit, {})
        self.assertTrue(st.complete)

    async def test_the_range_is_half_open(self):
        rng = period_range(StatsPeriod.DAY, at(29), TZ)
        audit = InMemorySecurityAudit()
        await audit.record(SecurityEvent("a", rng.start, 1, GA))               # first instant: in
        await audit.record(SecurityEvent("b", rng.end, 1, GA))                 # the next day's first instant: out
        await audit.record(SecurityEvent("c", rng.start - timedelta(microseconds=1), 1, GA))
        self.assertEqual(await audit.count_by_type(GA, rng.start, rng.end), {"a": 1})

    async def test_a_failing_source_is_reported_not_hidden(self):
        class Down:
            async def count_in_range(self, *a):
                raise RuntimeError("boom")

            async def count(self, *a):
                raise RuntimeError("boom")

            async def totals(self, *a):
                raise RuntimeError("boom")

        svc = await seeded()
        svc._reports, svc._counters = Down(), Down()
        st = await svc.group_stats(GA, StatsPeriod.DAY)
        self.assertEqual(st.missing, ("reports", "counters"))
        self.assertFalse(st.complete)
        self.assertEqual(st.reports["created"], 0)       # zero-filled, but flagged as missing
        self.assertEqual(st.warnings["issued_auto"], 1)  # the other sections still answer

    async def test_a_missing_source_is_flagged(self):
        st = await StatsService(display_timezone=TZ, clock=lambda: NOW).group_stats(GA)
        self.assertEqual(st.missing, ("warnings", "sanctions", "reports", "audit", "counters"))

    async def test_invalid_group_and_period(self):
        svc = await seeded()
        for bad in (0, 5, True, "x", None):
            with self.assertRaises(InvalidInput):
                await svc.group_stats(bad)  # type: ignore[arg-type]
        with self.assertRaises(ValueError):
            await svc.group_stats(GA, "year")  # type: ignore[arg-type]

    async def test_overall_sums_the_named_groups_only(self):
        svc = await seeded()
        total = await svc.overall([GA, GB, GA], StatsPeriod.DAY)    # duplicate ignored
        self.assertIsNone(total.group_id)
        self.assertEqual(total.groups, 2)
        self.assertEqual(total.counters["violation"], 4 + 99)
        self.assertEqual(total.reports["created"], 3)
        self.assertEqual(total.audit["permission_denied"], 3)
        only_a = await svc.overall([GA])
        self.assertEqual(only_a.counters["violation"], 4)
        with self.assertRaises(InvalidInput):
            await svc.overall([])
        with self.assertRaises(InvalidInput):
            await svc.overall(list(range(-1, -600, -1)))

    async def test_combine_unions_missing_and_rejects_mixed_ranges(self):
        r1, r2 = period_range(StatsPeriod.DAY, NOW, TZ), period_range(StatsPeriod.WEEK, NOW, TZ)
        a, b = GroupStats(GA, r1, missing=("audit",)), GroupStats(GB, r1, missing=("reports",))
        self.assertEqual(combine([a, b]).missing, ("reports", "audit"))
        with self.assertRaises(ValueError):
            combine([a, GroupStats(GB, r2)])
        with self.assertRaises(ValueError):
            combine([])


class HookTests(ExecBase):
    """The command executor feeds the counters; a broken counter never changes a command's result."""

    async def asyncSetUp(self):
        self.store = InMemoryCounterStore()
        self.rec = CounterRecorder(self.store, TZ, lambda: NOW)
        await super().asyncSetUp()

    def make_service(self, claims):
        return ModerationCommandService(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions,
            settings_store=self.s.settings_store, actions=self.actions, chat_info=self.s.chat, claims=claims,
            audit=self.s.audit, bot_id=BOT, clock=self.s.clock, group_settings=self.s.settings, counters=self.rec)

    async def totals(self, group=GA):
        return await self.store.totals(group, date(2026, 1, 1), date(2026, 12, 31))

    async def test_a_permitted_command_counts_as_handled(self):
        res = await self.run_cmd("/id")
        self.assertIsNot(res.kind, R.DENIED)
        self.assertEqual((await self.totals()).get("command"), 1)

    async def test_a_denied_command_counts_as_rejected_every_time(self):
        for i in range(3):  # the audit row is throttled (60 s); the counter is not
            res = await self.run_cmd("/ban", actor=987654, msg=10 + i, reply_to=OTHER)
            self.assertIs(res.kind, R.DENIED)
        self.assertEqual(await self.totals(), {"command_rejected": 3})
        self.assertEqual(self.audit_types().count("command_rejected"), 1)

    async def test_a_redelivered_command_counts_once(self):
        await self.run_cmd("/ban", reply_to=OTHER, msg=20)
        first = dict(await self.totals())
        res = await self.run_cmd("/ban", reply_to=OTHER, msg=20)  # same message id: claimed already
        self.assertIs(res.kind, R.DUPLICATE)
        self.assertEqual(await self.totals(), first)

    async def test_a_broken_counter_does_not_change_the_result(self):
        class Boom:
            async def bump(self, *a, **k):
                raise RuntimeError("counters down")

        self.svc._counters = Boom()
        res = await self.run_cmd("/id")
        self.assertIsNot(res.kind, R.ERROR)

    async def test_without_counters_nothing_is_written(self):
        self.svc._counters = None
        await self.run_cmd("/id")
        self.assertEqual(await self.totals(), {})


class EngineHookTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        from test_protection_engine import Base  # reuse the engine fixture
        self.base = Base()
        await self.base.asyncSetUp()
        self.store = InMemoryCounterStore()
        self.rec = CounterRecorder(self.store, TZ, lambda: self.base.s.clock())
        self.base.engine._counters = self.rec

    async def total(self):
        return await self.store.totals(GA, date(2026, 1, 1), date(2027, 12, 31))

    async def test_an_acted_violation_is_counted_once(self):
        out = await self.base.send("buy at https://evil.com")
        self.assertEqual(out.kind.value, "acted")
        self.assertEqual(await self.total(), {"violation": 1})
        # the same message delivered again: a duplicate delivery, not a second violation
        again = await self.base.send("buy at https://evil.com", mid=self.base.mid)
        self.assertEqual(again.kind.value, "duplicate_delivery")
        self.assertEqual(await self.total(), {"violation": 1})

    async def test_clean_messages_and_dry_run_are_not_counted(self):
        await self.base.send("hello there")
        self.assertEqual(await self.total(), {})
        await self.base.cfg(dry_run=True)
        out = await self.base.send("https://evil.com")
        self.assertEqual(out.kind.value, "dry_run")
        self.assertEqual(await self.total(), {})

    async def test_a_broken_counter_never_changes_the_engine_decision(self):
        class Boom:
            async def bump(self, *a, **k):
                raise RuntimeError("down")

        self.base.engine._counters = Boom()
        out = await self.base.send("https://evil.com")
        self.assertEqual((out.kind.value, out.deleted), ("acted", True))


# ---------------------------------------------------------------- PostgreSQL layer (recording fake connection)
class RecConn:
    def __init__(self, fetchrow=None, fetch=None, fetchval=None, fetches=None):
        self.log: list[tuple[str, str, tuple]] = []
        self._fetchrow, self._fetch, self._fetchval = fetchrow, fetch or [], fetchval
        self._fetches = list(fetches) if fetches is not None else None  # one result list per `fetch` call, in order

    async def execute(self, sql, *args):
        self.log.append(("execute", " ".join(sql.split()), args))
        return "INSERT 0 1"

    async def fetchrow(self, sql, *args):
        self.log.append(("fetchrow", " ".join(sql.split()), args))
        return self._fetchrow

    async def fetch(self, sql, *args):
        self.log.append(("fetch", " ".join(sql.split()), args))
        if self._fetches is not None:
            return self._fetches.pop(0) if self._fetches else []
        return self._fetch

    async def fetchval(self, sql, *args):
        self.log.append(("fetchval", " ".join(sql.split()), args))
        return self._fetchval


class RecDb:
    def __init__(self, conn):
        self.conn = conn

    @asynccontextmanager
    async def acquire(self):
        yield self.conn


class PostgresTests(unittest.IsolatedAsyncioTestCase):
    async def test_counter_upsert_is_one_atomic_statement_scoped_by_group(self):
        conn = RecConn()
        await PostgresCounterStore(RecDb(conn)).bump(GA, date(2026, 10, 29), Counter.VIOLATION, 2, NOW)
        kind, sql, args = conn.log[0]
        self.assertTrue(sql.startswith("INSERT INTO daily_group_counters"))
        self.assertIn("ON CONFLICT (group_id, day, counter) DO UPDATE SET value = daily_group_counters.value + EXCLUDED.value", sql)
        self.assertEqual(args, (GA, date(2026, 10, 29), "violation", 2, NOW))

    async def test_counter_totals_query(self):
        conn = RecConn(fetch=[{"counter": "violation", "total": 5}, {"counter": "command", "total": None}])
        out = await PostgresCounterStore(RecDb(conn)).totals(GA, date(2026, 10, 1), date(2026, 10, 29))
        self.assertEqual(out, {"violation": 5, "command": 0})
        self.assertIn("WHERE group_id = $1 AND day BETWEEN $2 AND $3 GROUP BY counter", conn.log[0][1])

    async def test_range_queries_filter_by_group_and_use_half_open_ranges(self):
        s, e = at(29, 0), at(30, 0)
        conn = RecConn(fetchrow={"issued_auto": 1, "issued_manual": 2, "revoked": None})
        self.assertEqual(await PostgresWarningStore(RecDb(conn)).count_in_range(GA, s, e),
                         {"issued_auto": 1, "issued_manual": 2, "revoked": 0})
        conn = RecConn(fetch=[{"kind": "mute", "automatic": True, "n": 3}, {"kind": "ban", "automatic": False, "n": 1}],
                       fetchval=2)
        self.assertEqual(await PostgresSanctionStore(RecDb(conn)).count_in_range(GA, s, e),
                         {"mute_auto": 3, "ban_manual": 1, "lifted": 2})
        conn = RecConn(fetches=[[{"report_type": "spam", "n": 2}, {"report_type": "scam", "n": 1}],
                                [{"outcome": "action_taken", "n": 1}]])
        out = await PostgresReportStore(RecDb(conn)).count_in_range(GA, s, e)
        self.assertEqual(out, {"type_spam": 2, "type_scam": 1, "created": 3, "handled_action_taken": 1})
        conn = RecConn(fetch=[{"event_type": "permission_denied", "n": 4}])
        self.assertEqual(await PostgresSecurityAudit(RecDb(conn)).count_by_type(GA, s, e), {"permission_denied": 4})
        self.assertEqual(len(conn.log), 1)
        for c in (conn,):
            for _, sql, args in c.log:
                self.assertIn("group_id = $1", sql)
                self.assertEqual(args[0], GA)
                self.assertRegex(sql, r">= \$2 AND \w+ < \$3")

    async def test_every_range_query_is_scoped_and_never_writes_the_audit_tables(self):
        for path in (ROOT / "src" / "guardian" / "stats").glob("*.py"):
            self.assertIsNone(re.search(r"(UPDATE|DELETE\s+FROM|TRUNCATE)\s+(license_audit_log|security_audit_log)",
                                        path.read_text(encoding="utf-8"), re.I), path.name)


class MigrationTests(unittest.TestCase):
    def test_0009_is_discovered_after_0008(self):
        versions = [v for v, _ in discover()]
        self.assertEqual(versions[7:9], ["0008_group_reports", "0009_daily_counters"])

    def test_the_table_is_per_group_with_a_closed_counter_vocabulary(self):
        sql = SQL.read_text(encoding="utf-8")
        self.assertIn("REFERENCES telegram_groups (group_id) ON DELETE RESTRICT", sql)
        self.assertIn("PRIMARY KEY (group_id, day, counter)", sql)
        found = re.search(r"counter\s+TEXT\s+NOT NULL CHECK \(counter IN \(([^)]*)\)\)", sql)
        self.assertIsNotNone(found)
        self.assertEqual(tuple(re.findall(r"'([a-z_]+)'", found.group(1))), COUNTER_VALUES)

    def test_it_touches_no_other_table_and_no_audit_trigger(self):
        sql = SQL.read_text(encoding="utf-8")
        code = "\n".join(l for l in sql.splitlines() if not l.lstrip().startswith("--"))
        self.assertNotRegex(code, r"(?i)\b(ALTER|DROP|TRIGGER|UPDATE|DELETE\s+FROM)\b")
        self.assertEqual(re.findall(r"(?i)CREATE TABLE IF NOT EXISTS (\w+)", code), ["daily_group_counters"])


if __name__ == "__main__":
    unittest.main()
