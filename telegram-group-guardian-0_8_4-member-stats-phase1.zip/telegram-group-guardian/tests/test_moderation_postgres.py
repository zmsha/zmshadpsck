"""SQL SHAPE tests for the moderation stores and migration 0003, WITHOUT a real PostgreSQL.
They prove group scoping, idempotent inserts and constraint coverage — NOT that PostgreSQL accepts the SQL
(real-database verification is still outstanding; see TEST_REPORT.md)."""
import hashlib
import re
import unittest
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path

from guardian.db.migrations import SQL_DIR, discover
from guardian.errors import InvalidInput
from guardian.moderation.models import SanctionKind as K
from guardian.moderation.postgres_store import PostgresSanctionStore, PostgresWarningStore

NOW = datetime(2026, 10, 29, 12, tzinfo=timezone.utc)
SRC = Path(__file__).resolve().parent.parent / "src" / "guardian"


class Conn:
    def __init__(self, rows=(), values=(), status="UPDATE 0"):
        self.rows, self.values, self.status = list(rows), list(values), status
        self.log = []

    async def fetchrow(self, sql, *args):
        self.log.append(("fetchrow", " ".join(sql.split()), args))
        return self.rows.pop(0) if self.rows else None

    async def fetch(self, sql, *args):
        self.log.append(("fetch", " ".join(sql.split()), args))
        return self.rows

    async def fetchval(self, sql, *args):
        self.log.append(("fetchval", " ".join(sql.split()), args))
        return self.values.pop(0) if self.values else None

    async def execute(self, sql, *args):
        self.log.append(("execute", " ".join(sql.split()), args))
        return self.status


class Db:
    def __init__(self, conn):
        self.conn = conn

    @asynccontextmanager
    async def acquire(self):
        yield self.conn


def wrow(**kw):
    base = dict(id=1, group_id=-1001, user_id=7, issued_by=9, reason=None, created_at=NOW, expires_at=None,
                revoked_at=None, revoked_by=None, idempotency_key=None)
    return {**base, **kw}


def srow(**kw):
    base = dict(id=1, group_id=-1001, user_id=7, kind="mute", issued_by=None, reason=None, created_at=NOW,
                expires_at=NOW + timedelta(minutes=10), lifted_at=None, lifted_by=None, violation="links",
                idempotency_key="op:sanction:-1001:7:1")
    return {**base, **kw}


class WarningSqlTests(unittest.IsolatedAsyncioTestCase):
    async def test_add_inserts_with_group_first_and_conflict_target_matching_the_unique_index(self):
        conn = Conn(rows=[wrow(idempotency_key="k")])
        w, created = await PostgresWarningStore(Db(conn)).add(-1001, 7, 9, "r", NOW, None, "k")
        kind, sql, args = conn.log[0]
        self.assertTrue(created and w.user_id == 7)
        self.assertIn("VALUES ($1, $2, $3, $4, $5, $6, $7)", sql)
        self.assertIn("ON CONFLICT (group_id, idempotency_key) WHERE idempotency_key IS NOT NULL DO NOTHING", sql)
        self.assertEqual(args[:2], (-1001, 7))

    async def test_repeated_key_returns_existing_row_scoped_by_group(self):
        conn = Conn(rows=[None, wrow(id=5, idempotency_key="k")])
        w, created = await PostgresWarningStore(Db(conn)).add(-1001, 7, 9, None, NOW, None, "k")
        self.assertEqual((created, w.id), (False, 5))
        _, sql, args = conn.log[1]
        self.assertIn("WHERE group_id = $1 AND idempotency_key = $2", sql)
        self.assertEqual(args, (-1001, "k"))

    async def test_reads_and_updates_are_group_scoped(self):
        conn = Conn(rows=[wrow()], values=[2], status="UPDATE 2")
        st = PostgresWarningStore(Db(conn))
        await st.list_active(-1001, 7, NOW)
        self.assertEqual(await st.count_active(-1001, 7, NOW), 2)
        self.assertEqual(await st.revoke_all(-1001, 7, 9, NOW), 2)
        conn.status = "UPDATE 1"
        self.assertTrue(await st.revoke_one(-1001, 3, 9, NOW))
        conn.status = "UPDATE 0"
        self.assertFalse(await st.revoke_one(-1001, 3, 9, NOW))
        for _, sql, args in conn.log:
            self.assertIn("group_id = $1", sql)
            self.assertEqual(args[0], -1001)
        for _, sql, _ in conn.log[:3]:
            self.assertIn("revoked_at IS NULL", sql)
        self.assertIn("expires_at IS NULL OR expires_at > $3", conn.log[0][1])


class SanctionSqlTests(unittest.IsolatedAsyncioTestCase):
    async def test_record_conflict_target_and_cross_group_key(self):
        conn = Conn(rows=[srow()])
        s, created = await PostgresSanctionStore(Db(conn)).record(
            -1001, 7, K.MUTE, None, None, NOW, NOW + timedelta(minutes=10), "links", "op:sanction:-1001:7:1")
        sql = conn.log[0][1]
        self.assertTrue(created and s.kind is K.MUTE and s.automatic)
        self.assertIn("ON CONFLICT (idempotency_key) DO NOTHING RETURNING", sql)
        self.assertEqual(conn.log[0][2][:3], (-1001, 7, "mute"))
        # conflict, but the existing row belongs to ANOTHER group: refuse, never return it
        conn = Conn(rows=[None, None])
        with self.assertRaises(InvalidInput):
            await PostgresSanctionStore(Db(conn)).record(-1001, 7, K.MUTE, None, None, NOW, None, None, "k")
        self.assertIn("WHERE group_id = $1 AND idempotency_key = $2", conn.log[1][1])

    async def test_repeated_key_same_group_returns_existing(self):
        conn = Conn(rows=[None, srow(id=4)])
        s, created = await PostgresSanctionStore(Db(conn)).record(-1001, 7, K.MUTE, None, None, NOW, None, None, "k")
        self.assertEqual((created, s.id), (False, 4))

    async def test_active_excludes_kicks_lifted_and_expired_and_is_scoped(self):
        conn = Conn(rows=[srow()])
        st = PostgresSanctionStore(Db(conn))
        await st.get_active(-1001, 7, NOW)
        await st.get_active(-1001, 7, NOW, (K.BAN,))
        for _, sql, args in conn.log:
            self.assertIn("group_id = $1 AND user_id = $2", sql)
            for needle in ("kind <> 'kick'", "lifted_at IS NULL", "expires_at IS NULL OR expires_at > $4"):
                self.assertIn(needle, sql)
        self.assertEqual(conn.log[0][2][2], ["mute", "ban"])
        self.assertEqual(conn.log[1][2][2], ["ban"])

    async def test_lift_and_escalation_count(self):
        conn = Conn(values=[3], status="UPDATE 2")
        st = PostgresSanctionStore(Db(conn))
        self.assertEqual(await st.lift(-1001, 7, K.BAN, 9, NOW), 2)
        self.assertEqual(await st.count_auto_mutes(-1001, 7, NOW), 3)
        lift_sql, count_sql = conn.log[0][1], conn.log[1][1]
        self.assertIn("WHERE group_id = $1 AND user_id = $2 AND kind = $3", lift_sql)
        self.assertIn("kind <> 'kick'", lift_sql)
        self.assertIn("kind = 'mute' AND issued_by IS NULL AND created_at > $3", count_sql)
        self.assertIn("group_id = $1 AND user_id = $2", count_sql)


class MigrationShapeTests(unittest.TestCase):
    def setUp(self):
        self.sql = (SQL_DIR / "0003_moderation_records.sql").read_text(encoding="utf-8")
        self.sql2 = (SQL_DIR / "0002_security_and_access.sql").read_text(encoding="utf-8")

    def test_0003_is_discovered_after_0002_and_earlier_files_are_untouched(self):
        self.assertEqual([v for v, _ in discover()][2], "0003_moderation_records")  # later migrations may follow
        self.assertEqual(hashlib.sha256((SQL_DIR / "0002_security_and_access.sql").read_bytes()).hexdigest(),
                         "8b48363b13fc1c10d978d7f76dfe52cfd80cbbad338cc2a7bb8d90aa2f1cba7d")

    def test_0003_only_alters_existing_moderation_tables(self):
        self.assertNotRegex(self.sql, r"(?i)\bDROP\b")
        self.assertNotRegex(self.sql, r"(?i)CREATE TABLE")
        tables = set(re.findall(r"(?i)ALTER TABLE (\w+)", self.sql))
        self.assertEqual(tables, {"moderation_warnings", "moderation_sanctions"})

    def test_conflict_targets_have_matching_unique_indexes(self):
        # warnings: ON CONFLICT (group_id, idempotency_key) WHERE idempotency_key IS NOT NULL
        self.assertIn("CREATE UNIQUE INDEX IF NOT EXISTS uq_moderation_warnings_idem", self.sql)
        self.assertIn("(group_id, idempotency_key) WHERE idempotency_key IS NOT NULL", self.sql)
        # sanctions: ON CONFLICT (idempotency_key) relies on the column-level UNIQUE from 0002
        self.assertIn("idempotency_key  TEXT UNIQUE", self.sql2)

    def test_required_constraints_and_indexes_present(self):
        for needle in (
            "moderation_warnings_expiry_after_create", "moderation_warnings_revoked_pair",
            "moderation_sanctions_expiry_after_create", "moderation_sanctions_kick_no_expiry",
            "moderation_sanctions_lift_consistent", "moderation_sanctions_violation_len",
            "idx_moderation_sanctions_auto_mutes", "WHERE issued_by IS NULL AND kind = 'mute'",
        ):
            self.assertIn(needle, self.sql)

    def test_store_sql_matches_migrated_columns(self):
        code = (SRC / "moderation" / "postgres_store.py").read_text(encoding="utf-8")
        for col in ("violation", "idempotency_key", "lifted_by", "revoked_by", "issued_by"):
            self.assertIn(col, code)
        self.assertIn("ADD COLUMN idempotency_key TEXT", self.sql)
        self.assertIn("ADD COLUMN violation TEXT", self.sql)

    def test_no_code_deletes_moderation_rows(self):
        pattern = re.compile(r"(DELETE\s+FROM|TRUNCATE)\s+moderation_", re.I)
        for path in SRC.rglob("*.py"):
            self.assertIsNone(pattern.search(path.read_text(encoding="utf-8")), path.name)

    def test_sanction_kinds_match_between_python_and_sql(self):
        found = re.search(r"kind\s+TEXT NOT NULL CHECK \(kind IN \(([^)]*)\)", self.sql2).group(1)
        self.assertEqual(set(re.findall(r"'(\w+)'", found)), {k.value for k in K})


if __name__ == "__main__":
    unittest.main()
