"""Part 7: integration glue (message handler, visible-users resolver, lazy service, menus, wiring helpers).

Everything runs against duck-typed fakes: the aiogram router (`bot/routers/moderation.py`), `create_app` and the real
Telegram are NOT exercised here (aiogram/fastapi are not installable in the build sandbox).
"""
from __future__ import annotations

import asyncio
import re
import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace as NS

from executor_stack import A, B, BOT, BOT_NAME, OTHER, USER, ExecBase, gate
from guardian.bot import commands_menu
from guardian.bot import moderation_handler as h
from guardian.bot.middlewares import ProtectionGateMiddleware
from guardian.moderation.commands import Command, ParsedCommand
from guardian.moderation.executor import CommandResult, ResultKind as R
from guardian.moderation.provider import LazyModerationCommands
from guardian.moderation.usernames import VisibleUsers
from guardian.protection_gate import ProtectionGate
from helpers import FakeNotifier
from stack import STRANGER, TG_ADMIN, Stack

T0 = datetime(2026, 10, 30, 10, 0, tzinfo=timezone.utc)


class Clk:
    def __init__(self):
        self.now = T0

    def __call__(self):
        return self.now


# --------------------------------------------------------------------------- fakes
class FakeBot:
    def __init__(self, username=BOT_NAME, bot_id=BOT, fail=False):
        self.username, self.id, self.fail, self.me_calls = username, bot_id, fail, 0

    async def me(self):
        self.me_calls += 1
        await asyncio.sleep(0)  # a real network call yields: lets concurrent callers interleave
        if self.fail:
            raise RuntimeError("getMe down")
        return NS(id=self.id, username=self.username)


def ent(kind, offset, length, user=None):
    return NS(type=kind, offset=offset, length=length, user=NS(id=user) if user else None)


class Msg:
    def __init__(self, text, *, chat=A, ctype="supergroup", sender=TG_ADMIN, mid=1, reply_to=None, entities=None,
                 lang="ar", is_bot=False, sender_chat_reply=False, topic_root=False, username=None, new_members=None):
        self.text, self.message_id, self.entities = text, mid, entities
        self.chat = NS(id=chat, type=ctype, title="T")
        self.from_user = NS(id=sender, is_bot=is_bot, language_code=lang, username=username) if sender else None
        self.sender_chat = None
        self.reply_to_message = None
        if topic_root:
            self.reply_to_message = NS(forum_topic_created=NS(name="x"), from_user=NS(id=BOT), sender_chat=None)
        elif sender_chat_reply:
            self.reply_to_message = NS(from_user=None, sender_chat=NS(id=-100))
        elif reply_to is not None:
            self.reply_to_message = NS(from_user=NS(id=reply_to, is_bot=False, username=f"user{reply_to}"), sender_chat=None)
        self.new_chat_members = new_members
        self.replies: list[str] = []
        self.fail_reply = False

    async def reply(self, text):
        if self.fail_reply:
            raise RuntimeError("cannot send")
        self.replies.append(text)


# --------------------------------------------------------------------------- VisibleUsers
class VisibleUsersTests(unittest.IsolatedAsyncioTestCase):
    def make(self, **kw):
        self.clk = Clk()
        return VisibleUsers(clock=self.clk, **kw)

    async def test_observe_and_resolve_case_insensitive_and_at_prefix(self):
        v = self.make()
        self.assertTrue(v.observe(A, USER, "@Some_User"))
        self.assertEqual(await v.resolve(A, "some_user"), USER)
        self.assertEqual(await v.resolve(A, "@SOME_USER"), USER)

    async def test_groups_are_isolated(self):
        v = self.make()
        v.observe(A, USER, "some_user")
        self.assertIsNone(await v.resolve(B, "some_user"))

    async def test_rename_drops_the_old_name(self):
        v = self.make()
        v.observe(A, USER, "old_name")
        v.observe(A, USER, "new_name")
        self.assertIsNone(await v.resolve(A, "old_name"))
        self.assertEqual(await v.resolve(A, "new_name"), USER)
        self.assertEqual(len(v), 1)

    async def test_name_taken_by_another_account_replaces_old_owner(self):
        v = self.make()
        v.observe(A, USER, "shared_name")
        v.observe(A, OTHER, "shared_name")
        self.assertEqual(await v.resolve(A, "shared_name"), OTHER)
        v.observe(A, USER, "another_one")  # old owner re-observed under a different name: no stale link back
        self.assertEqual(await v.resolve(A, "shared_name"), OTHER)

    async def test_entries_expire(self):
        v = self.make(ttl=timedelta(days=1))
        v.observe(A, USER, "some_user")
        self.clk.now = T0 + timedelta(days=1, seconds=1)
        self.assertIsNone(await v.resolve(A, "some_user"))
        self.assertEqual(len(v), 0)

    async def test_bounded_lru(self):
        v = self.make(max_entries=3)
        for i in range(5):
            v.observe(A, 1000 + i, f"user_{i}abc")
        self.assertEqual(len(v), 3)
        self.assertIsNone(await v.resolve(A, "user_0abc"))
        self.assertEqual(await v.resolve(A, "user_4abc"), 1004)

    async def test_invalid_input_is_rejected_not_stored(self):
        v = self.make()
        for g, u, n in [(A, USER, None), (A, USER, "ab"), (A, USER, "1bad_name"), (A, USER, "has space"), (A, 0, "valid_name"),
                        (A, -5, "valid_name"), (A, True, "valid_name"), ("x", USER, "valid_name"), (0, USER, "valid_name"),
                        (A, USER, "x" * 40)]:
            self.assertFalse(v.observe(g, u, n), (g, u, n))
        self.assertEqual(len(v), 0)

    async def test_forget(self):
        v = self.make()
        v.observe(A, USER, "some_user")
        v.forget(A, USER)
        self.assertIsNone(await v.resolve(A, "some_user"))


# --------------------------------------------------------------------------- observe_users
class ObserveTests(unittest.TestCase):
    def test_only_when_licensed_and_group(self):
        v = VisibleUsers()
        h.observe_users(v, Msg("hi", username="alice_x1"), gate(allowed=False))
        h.observe_users(v, Msg("hi", ctype="private", username="alice_x1"), gate())
        h.observe_users(v, Msg("hi", username="alice_x1"), None)
        h.observe_users(None, Msg("hi", username="alice_x1"), gate())
        self.assertEqual(len(v), 0)
        h.observe_users(v, Msg("hi", username="alice_x1"), gate())
        self.assertEqual(len(v), 1)

    def test_reply_target_new_members_and_bots(self):
        v = VisibleUsers()
        m = Msg("hi", username="alice_x1", reply_to=USER, new_members=[NS(id=OTHER, is_bot=False, username="newbie_77"),
                                                                       NS(id=999, is_bot=True, username="some_bot")])
        h.observe_users(v, m, gate())
        self.assertEqual(len(v), 3)  # sender, replied-to user, new member; the bot is skipped
        self.assertEqual(asyncio.run(v.resolve(A, "newbie_77")), OTHER)
        self.assertIsNone(asyncio.run(v.resolve(A, "some_bot")))


# --------------------------------------------------------------------------- match / reply / mention
class MatchTests(unittest.IsolatedAsyncioTestCase):
    async def test_group_commands_match(self):
        bot = FakeBot()
        p = await h.match_command(Msg("/ban 1h spam", reply_to=USER), bot)
        self.assertEqual((p.command, p.args), (Command.BAN, ("1h", "spam")))
        p = await h.match_command(Msg(f"/mute@{BOT_NAME} 30m", reply_to=USER), bot)
        self.assertEqual(p.command, Command.MUTE)

    async def test_non_commands_and_wrong_places_do_not_match(self):
        bot = FakeBot()
        cases = [Msg("/ban", ctype="private"), Msg("/ban", ctype="channel"), Msg("/ban", sender=None),
                 Msg("/ban", is_bot=True), Msg("hello there"), Msg("/ban@OtherBot"), Msg(None), Msg("/start"),
                 Msg("/unknown_cmd")]
        for m in cases:
            self.assertIsNone(await h.match_command(m, bot), m.text)

    async def test_addressed_form_ignored_when_getme_fails_but_plain_works(self):
        bot = FakeBot(fail=True)
        self.assertIsNone(await h.match_command(Msg(f"/ban@{BOT_NAME}", reply_to=USER), bot))
        self.assertIsNotNone(await h.match_command(Msg("/ban", reply_to=USER), bot))

    async def test_arabic_alias_needs_reply_or_explicit_target_and_skips_getme(self):
        bot = FakeBot()
        self.assertIsNone(await h.match_command(Msg("حظر الناس كلهم"), bot))
        self.assertIsNotNone(await h.match_command(Msg("حظر", reply_to=USER), bot))
        self.assertIsNotNone(await h.match_command(Msg("كتم @some_user 1h"), bot))
        self.assertEqual(bot.me_calls, 0)

    async def test_forum_topic_root_is_not_a_reply(self):
        bot = FakeBot()
        self.assertIsNone(h.reply_info(Msg("x", topic_root=True)))
        self.assertIsNone(await h.match_command(Msg("حظر", topic_root=True), bot))  # no reply, no target => chat

    def test_reply_info_variants(self):
        self.assertIsNone(h.reply_info(Msg("x")))
        self.assertEqual(h.reply_info(Msg("x", reply_to=USER)).user_id, USER)
        r = h.reply_info(Msg("x", sender_chat_reply=True))
        self.assertEqual((r.user_id, r.sender_chat), (None, True))


class MentionTests(unittest.TestCase):
    def parsed(self, text):
        from guardian.moderation.commands import parse_command
        return parse_command(text, BOT_NAME)

    def test_text_mention_on_first_arg(self):
        text = "/ban Alice 1h spam"
        m = Msg(text, entities=[ent("bot_command", 0, 4), ent("text_mention", 5, 5, user=USER)])
        p, uid = h.resolve_mention(m, self.parsed(text))
        self.assertEqual((uid, p.args), (USER, ("Alice", "1h", "spam")))

    def test_multi_word_name_collapses_and_never_becomes_the_reason(self):
        text = "/ban John Smith 1h spam"
        m = Msg(text, entities=[ent("text_mention", 5, 10, user=USER)])
        p, uid = h.resolve_mention(m, self.parsed(text))
        self.assertEqual((uid, p.args), (USER, ("John", "1h", "spam")))

    def test_offsets_are_utf16_not_codepoints(self):
        text = "/kick 😀x"  # the emoji is 2 UTF-16 units but 1 code point
        m = Msg(text, entities=[ent("text_mention", 6, 3, user=USER)])
        p, uid = h.resolve_mention(m, self.parsed(text))
        self.assertEqual((uid, p.args), (USER, ("😀x",)))
        text2 = "😀 /kick Bob"  # command preceded by an emoji? not a command at all
        self.assertIsNone(self.parsed(text2))

    def test_utf16_remainder_after_astral_name(self):
        text = "/ban \U0001F600x\U0001F600y 1h spam"  # name = 6 UTF-16 units but only 4 code points
        m = Msg(text, entities=[ent("text_mention", 5, 6, user=USER)])
        p, uid = h.resolve_mention(m, self.parsed(text))
        self.assertEqual((uid, p.args), (USER, ("\U0001F600x\U0001F600y", "1h", "spam")))

    def test_offset_after_astral_character_in_later_argument_position(self):
        text = "/warn Zoe 😀 reason"
        m = Msg(text, entities=[ent("text_mention", 6, 3, user=USER)])
        p, uid = h.resolve_mention(m, self.parsed(text))
        self.assertEqual((uid, p.args), (USER, ("Zoe", "😀", "reason")))

    def test_ignored_cases(self):
        text = "/ban Alice 1h"
        bad = [
            [ent("mention", 5, 5)],                               # plain mention, no user
            [ent("text_mention", 6, 4, user=USER)],               # not at the first arg
            [ent("text_mention", 5, 3, user=USER)],               # does not cover the whole word
            [ent("text_mention", 5, 5, user=0)],                  # invalid id
            [ent("text_mention", 5, 5, user=None)],               # no user
            None, [],
        ]
        for entities in bad:
            p, uid = h.resolve_mention(Msg(text, entities=entities), self.parsed(text))
            self.assertIsNone(uid, entities)
            self.assertEqual(p.args, ("Alice", "1h"))

    def test_entity_ending_mid_word_is_ignored(self):
        text = "/ban Alice Bobby"
        m = Msg(text, entities=[ent("text_mention", 5, 9, user=USER)])  # ends inside "Bobby"
        p, uid = h.resolve_mention(m, self.parsed(text))
        self.assertIsNone(uid)


# --------------------------------------------------------------------------- end to end through the real service
class EndToEnd(ExecBase):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.users = VisibleUsers(clock=self.s.clock)
        self.bot = FakeBot()
        self.built: list[int] = []

        def build(bot_id):
            self.built.append(bot_id)
            from guardian.moderation.executor import ModerationCommandService
            return ModerationCommandService(
                permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions,
                settings_store=self.s.settings_store, actions=self.actions, chat_info=self.s.chat, claims=self.claims,
                audit=self.s.audit, bot_id=bot_id, usernames=self.users, clock=self.s.clock)

        self.services = NS(settings=NS(default_language="ar"), moderation_commands=LazyModerationCommands(self.bot, build))

    async def send(self, msg, protection="default"):
        parsed = await h.match_command(msg, self.bot)
        self.assertIsNotNone(parsed, msg.text)
        prot = gate(msg.chat.id, msg.from_user.id) if protection == "default" else protection
        return await h.execute(msg, parsed, protection=prot, services=self.services)

    async def test_reply_ban_executes_and_answers_in_html(self):
        self.member(USER)
        m = Msg("/ban 1h spam", reply_to=USER)
        r = await self.send(m)
        self.assertEqual((r.kind, self.actions.names()), (R.DONE, ["ban"]))
        self.assertEqual(len(m.replies), 1)
        self.assertIn(str(USER), m.replies[0])
        self.assertEqual(self.built, [BOT])

    async def test_text_mention_target(self):
        self.member(USER)
        text = "/mute Ali Baba 30m"
        m = Msg(text, entities=[ent("text_mention", 6, 8, user=USER)])
        r = await self.send(m)
        self.assertEqual((r.kind, r.target_id, self.actions.names()), (R.DONE, USER, ["mute"]))

    async def test_username_resolved_from_visible_users(self):
        self.member(USER)
        h.observe_users(self.users, Msg("hi", sender=USER, username="seen_user"), gate())
        r = await self.send(Msg("/kick @seen_user"))
        self.assertEqual((r.kind, r.target_id), (R.DONE, USER))

    async def test_unknown_username_is_a_clean_error(self):
        r = await self.send(Msg("/ban @never_seen"))
        self.assertEqual(r.kind, R.INVALID)
        self.assertEqual(self.actions.calls, [])

    async def test_username_from_another_group_is_not_used(self):
        self.users.observe(B, USER, "seen_user")
        r = await self.send(Msg("/ban @seen_user"))
        self.assertEqual(r.kind, R.INVALID)

    async def test_non_admin_gets_denied_reply_and_nothing_happens(self):
        self.member(USER)
        m = Msg("/ban", sender=STRANGER, reply_to=USER)
        r = await self.send(m)
        self.assertEqual((r.kind, self.actions.calls), (R.DENIED, []))
        self.assertEqual(len(m.replies), 1)

    async def test_missing_protection_context_fails_closed(self):
        self.member(USER)
        r = await self.send(Msg("/ban", reply_to=USER), protection=None)
        self.assertEqual((r.kind, self.actions.calls), (R.LICENSE_OFF, []))

    async def test_redelivered_command_sends_no_second_reply(self):
        self.member(USER)
        m1, m2 = Msg("/ban", reply_to=USER, mid=55), Msg("/ban", reply_to=USER, mid=55)
        await self.send(m1)
        r2 = await self.send(m2)
        self.assertEqual((r2.kind, m2.replies, self.actions.names()), (R.DUPLICATE, [], ["ban"]))

    async def test_reply_failure_never_raises_and_action_stays(self):
        self.member(USER)
        m = Msg("/ban", reply_to=USER)
        m.fail_reply = True
        r = await self.send(m)
        self.assertEqual((r.kind, self.actions.names()), (R.DONE, ["ban"]))

    async def test_getme_failure_fails_closed_without_telegram_calls(self):
        self.member(USER)
        self.bot.fail = True
        parsed = ParsedCommand(Command.BAN, ())
        m = Msg("/ban", reply_to=USER)
        r = await h.execute(m, parsed, protection=gate(), services=self.services)
        self.assertEqual((r.kind, self.actions.calls), (R.ERROR, []))
        self.assertTrue(m.replies)
        self.bot.fail = False  # recovers on the next command (the failure is not cached)
        r = await h.execute(Msg("/ban", reply_to=USER, mid=2), parsed, protection=gate(), services=self.services)
        self.assertEqual(r.kind, R.DONE)

    async def test_service_is_built_once_under_concurrency(self):
        self.member(USER)
        parsed = ParsedCommand(Command.WARNINGS, ())
        msgs = [Msg("/warnings", reply_to=USER, mid=i) for i in range(1, 6)]
        await asyncio.gather(*(h.execute(m, parsed, protection=gate(), services=self.services) for m in msgs))
        self.assertEqual((self.built, self.bot.me_calls), ([BOT], 1))

    async def test_invalid_bot_id_is_rejected(self):
        self.bot.id = 0
        m = Msg("/ban", reply_to=USER)
        r = await h.execute(m, ParsedCommand(Command.BAN, ()), protection=gate(), services=self.services)
        self.assertEqual((r.kind, self.built), (R.ERROR, []))

    async def test_language_follows_the_sender(self):
        self.member(USER)
        ar = Msg("/ban", reply_to=USER, lang="ar", mid=1)
        en = Msg("/ban", reply_to=OTHER, lang="en", mid=2)
        self.member(OTHER)
        await self.send(ar)
        await self.send(en)
        self.assertNotEqual(ar.replies[0], en.replies[0])
        self.assertRegex(en.replies[0], r"[A-Za-z]")


# --------------------------------------------------------------------------- middleware observer
class MiddlewareObserverTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A)
        self.gate = ProtectionGate(self.s.license_service, self.s.perm, FakeNotifier(), clock=self.s.clock)

    def event(self):
        return NS(chat=NS(id=A, type="supergroup", title="T"), from_user=NS(id=STRANGER, is_bot=False, username="seen_user"),
                  sender_chat=None)

    async def test_observer_sees_context_and_handler_still_runs(self):
        seen = []

        async def handler(event, data):
            return "handled"

        mw = ProtectionGateMiddleware(self.gate, observer=lambda e, c: seen.append((e, c)))
        self.assertEqual(await mw(handler, self.event(), {}), "handled")
        self.assertEqual(len(seen), 1)
        self.assertFalse(seen[0][1].allowed)  # group is pending: observers must check `allowed` themselves

    async def test_failing_observer_never_blocks(self):
        async def handler(event, data):
            return "handled"

        def boom(e, c):
            raise RuntimeError("x")

        self.assertEqual(await ProtectionGateMiddleware(self.gate, observer=boom)(handler, self.event(), {}), "handled")

    async def test_pending_group_users_are_not_remembered(self):
        users = VisibleUsers()

        async def handler(event, data):
            return None

        mw = ProtectionGateMiddleware(self.gate, observer=lambda e, c: h.observe_users(users, e, c))
        await mw(handler, self.event(), {})
        self.assertEqual(len(users), 0)


# --------------------------------------------------------------------------- command menus
class MenuTests(unittest.TestCase):
    def test_every_menu_entry_is_valid_for_telegram(self):
        for spec in commands_menu.build_menus():
            self.assertTrue(1 <= len(spec.commands) <= 100)
            for cmd, desc in spec.commands:
                self.assertRegex(cmd, r"^[a-z0-9_]{1,32}$")
                self.assertTrue(3 <= len(desc) <= 256, (cmd, desc))
            self.assertEqual(len({c for c, _ in spec.commands}), len(spec.commands))

    def test_moderation_commands_match_the_parser_and_are_admin_scoped(self):
        self.assertEqual(set(commands_menu.MODERATION) | set(commands_menu.PUBLIC), {c.value for c in Command})
        self.assertTrue(set(commands_menu.MODERATION).isdisjoint(commands_menu.PUBLIC))
        for spec in commands_menu.build_menus():
            names = {c for c, _ in spec.commands}
            self.assertTrue(set(commands_menu.PUBLIC) <= names)  # everyone sees the public commands
            if spec.scope == "default":
                self.assertTrue(names.isdisjoint(commands_menu.MODERATION))
            else:
                self.assertTrue(set(commands_menu.MODERATION) <= names)
        self.assertEqual({(s.scope, s.language_code) for s in commands_menu.build_menus()},
                         {("default", None), ("default", "ar"), ("all_chat_administrators", None),
                          ("all_chat_administrators", "ar")})

    def test_descriptions_exist_in_both_languages(self):
        names = set(commands_menu.BASIC + commands_menu.PUBLIC + commands_menu.MODERATION)
        self.assertEqual(set(commands_menu.DESCRIPTIONS["en"]), names)
        self.assertEqual(set(commands_menu.DESCRIPTIONS["ar"]), names)

    def test_arabic_menu_uses_arabic_text(self):
        ar = next(s for s in commands_menu.build_menus() if s.scope == "default" and s.language_code == "ar")
        self.assertTrue(all(re.search(r"[؀-ۿ]", d) for _, d in ar.commands))


class HelpTextTests(unittest.TestCase):
    def test_help_mentions_moderation_in_both_languages(self):
        from guardian.i18n import t
        for lang in ("ar", "en"):
            self.assertIn("/ban", t("help", lang))


if __name__ == "__main__":
    unittest.main()
