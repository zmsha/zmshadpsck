"""Closing part 3, private-handoff check for the NEW commands: with the REAL license gate, no blocked state lets
/lock /unlock /slowmode /antiflood /protect reach Telegram, the settings or the claim store (owner included), the middleware
never drops the update, and the owner's recovery paths keep working. Also proves the slow-mode protection obeys the gate."""
from __future__ import annotations

from types import SimpleNamespace as NS

from executor_stack import BOT, USER
from guardian.moderation.executor import ModerationCommandService, ResultKind as R
from stack import OWNER, STRANGER, TG_ADMIN
from test_moderation_integration import Msg
from test_phase3_final_handoff import BLOCKED_STATES, Pipeline

NEW = ("/lock all", "/unlock media", "/slowmode 30", "/slowmode", "/antiflood off", "/protect", "/protect links off",
       "/protect allow add a.com", "قفل الوسائط", "الوضع البطيء ٣٠", "مكافحة الفيضان ايقاف", "اعدادات الحماية")


class NewCommandsGate(Pipeline):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.svc = ModerationCommandService(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions,
            settings_store=self.s.settings_store, actions=self.actions, chat_info=self.s.chat, claims=self.claims,
            audit=self.s.audit, bot_id=BOT, clock=self.s.clock, group_settings=self.s.settings)
        self.services = NS(settings=NS(default_language="ar"), moderation_commands=self.svc)

    async def assert_new_off(self, g, who):
        calls, claims = len(self.actions.calls), dict(self.claims._keys)
        for text in NEW:
            self.mid += 1
            ran, res = await self.deliver(Msg(text, chat=g, sender=who, mid=self.mid))
            self.assertTrue(ran, text)
            self.assertIsNotNone(res, text)
            self.assertEqual(res.kind, R.LICENSE_OFF, text)
        self.assertEqual(self.actions.calls[calls:], [])
        self.assertEqual(self.claims._keys, claims)
        self.assertIsNone(await self.s.settings_store.get(g))

    async def test_every_blocked_state_blocks_every_new_command(self):
        for state in BLOCKED_STATES:
            with self.subTest(state=state):
                g = await self.group_in(state)
                real = self.break_store() if state == "store_down" else self.s.licenses.get
                try:
                    await self.assert_new_off(g, TG_ADMIN)
                    if state != "store_down":
                        await self.assert_new_off(g, OWNER)
                finally:
                    self.s.licenses.get = real

    async def test_after_owner_recovery_commands_work_and_slowmode_protects(self):
        for state in BLOCKED_STATES:
            with self.subTest(state=state):
                g = await self.group_in(state)
                real = self.break_store() if state == "store_down" else self.s.licenses.get
                try:
                    await self.assert_new_off(g, TG_ADMIN)
                finally:
                    self.s.licenses.get = real
                await self.owner_recovers(g, state)
                self.mid += 1
                _, res = await self.deliver(Msg("/lock media", chat=g, sender=TG_ADMIN, mid=self.mid))
                self.assertEqual(res.kind, R.DONE)
                self.assertEqual(self.actions.calls[-1][0], "set_perms")
                self.mid += 1
                _, res = await self.deliver(Msg("/slowmode 30", chat=g, sender=TG_ADMIN, mid=self.mid))
                self.assertEqual(res.kind, R.DONE)
                self.mid += 1
                await self.deliver(Msg("hello", chat=g, sender=STRANGER, mid=self.mid))
                before = len(self.actions.calls)
                self.mid += 1
                await self.deliver(Msg("hello again", chat=g, sender=STRANGER, mid=self.mid))
                self.assertEqual(self.actions.calls[before][0], "delete")   # slow mode is live once licensed

    async def test_slowmode_setting_alone_protects_nothing_while_blocked(self):
        g = await self.group_in("pending")
        await self.s.settings_store.merge(g, {"slowmode_seconds": 30}, OWNER, self.s.clock())
        for _ in range(3):
            self.mid += 1
            await self.deliver(Msg("spam", chat=g, sender=STRANGER, mid=self.mid))
        self.assertEqual([c for c in self.actions.calls if c[0] == "delete"], [])
