import unittest

from guardian.errors import InvalidInput
from guardian.moderation import duration as d
from guardian.moderation.models import MAX_TEMP_SECONDS


class ParseOk(unittest.TestCase):
    def test_basic_units(self):
        for text, want in [("30m", 1800), ("12h", 43200), ("7d", 604800), ("1w", 604800), ("90s", 90), ("60s", 60)]:
            self.assertEqual(d.parse_duration(text), want, text)

    def test_case_space_and_arabic_units(self):
        for text, want in [("30M", 1800), (" 2 H ", 7200), ("٣٠د", 1800), ("٥ ساعات", 18000), ("۲ يوم", 172800),
                           ("1 أسبوع", 604800), ("10 دقائق", 600), ("1 hour", 3600), ("2days", 172800)]:
            self.assertEqual(d.parse_duration(text), want, text)

    def test_arabic_digits_and_invisible_marks(self):
        self.assertEqual(d.parse_duration("\u200f٧\u200fd"), 604800)
        self.assertEqual(d.parse_duration("１２h"), 43200)  # full-width digits
        self.assertEqual(d.parse_duration("٣ـ٠m".replace("ـ", "")), 1800)

    def test_boundaries(self):
        self.assertEqual(d.parse_duration("366d"), MAX_TEMP_SECONDS)
        self.assertEqual(d.parse_duration("1m"), d.MIN_DURATION_SECONDS)
        self.assertEqual(d.MAX_DURATION_SECONDS, MAX_TEMP_SECONDS)  # single source of truth


class ParseRejects(unittest.TestCase):
    def code(self, text):
        with self.assertRaises(d.DurationError) as cm:
            d.parse_duration(text)
        self.assertIsInstance(cm.exception, InvalidInput)
        return cm.exception.code

    def test_codes(self):
        cases = {"": "empty", "   ": "empty", None: "empty", 30: "empty", "0m": "zero", "٠س": "zero", "-5m": "negative",
                 "\u22125m": "negative", "30": "format", "m": "format", "1.5h": "format", "1,5h": "format",
                 "5 m 3": "format", "30x": "unit", "5years": "unit", "30s": "too_short", "59s": "too_short",
                 "367d": "too_long", "999999d": "too_long", "9999999h": "too_long", "1y": "unit"}
        for text, want in cases.items():
            self.assertEqual(self.code(text), want, repr(text))

    def test_huge_number_rejected_without_overflow_or_guess(self):
        self.assertEqual(self.code("9" * 40 + "d"), "format")

    def test_permanent_words_are_not_durations(self):
        for w in ("perm", "forever", "دائم"):
            self.assertEqual(self.code(w), "format")  # no digits => never a duration

    def test_no_secret_or_input_echo_in_message(self):
        with self.assertRaises(d.DurationError) as cm:
            d.parse_duration("evil<script>")
        self.assertNotIn("evil", str(cm.exception))


class Helpers(unittest.TestCase):
    def test_permanent_words(self):
        for w in ("perm", "Permanent", " دائم ", "للأبد", "FOREVER"):
            self.assertTrue(d.is_permanent_word(w), w)
        for w in ("30m", "", None, "permanently"):
            self.assertFalse(d.is_permanent_word(w), w)

    def test_quick_presets_all_valid(self):
        for label, secs in d.QUICK_DURATIONS:
            self.assertEqual(d.parse_duration(label), secs)

    def test_format(self):
        self.assertEqual(d.format_duration(86400, "en"), "1d")
        self.assertEqual(d.format_duration(7200, "ar"), "2 ساعة")
        self.assertEqual(d.format_duration(90, "en"), "90s")


if __name__ == "__main__":
    unittest.main()
