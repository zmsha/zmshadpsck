"""Part 6: aiogram adapter for MemberActions (ban / unban / mute / unmute / kick).

The fake Bot mirrors the aiogram 3 / Bot API method signatures STRICTLY (unknown keyword => TypeError), so a
typo in a parameter name fails here. It is NOT the real aiogram: nothing below proves behaviour against the
real library or Telegram (see HANDOFF.md / TEST_REPORT.md).
"""
from __future__ import annotations

import contextlib
import inspect
import logging
import sys
import types
import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace as NS
from typing import get_type_hints

from executor_stack import A, B, BOT, USER, ExecBase
from guardian.bot import actions as actions_module
from guardian.bot.actions import (
    KICK_BAN_WINDOW_SECONDS, PERMISSION_FLAGS, AiogramModerationActions, classify_error,
)
from guardian.moderation.executor import MemberActions, ResultKind as R
from guardian.moderation.models import SanctionKind as K
from guardian.protection.engine import ActionResult, ModerationActions
from stack import NOW, TG_ADMIN

NOW_UTC = datetime(2026, 10, 30, 10, 0, tzinfo=timezone.utc)
CHAT, UID = -1001234567890, 5001


class TelegramRetryAfter(Exception):
    def __init__(self, retry_after):
        super().__init__("Flood control SECRET-DETAIL")
        self.retry_after = retry_after


class TelegramForbiddenError(Exception): ...


class TelegramBadRequest(Exception): ...


class Perms:
    """Stand-in for aiogram.types.ChatPermissions."""

    def __init__(self, **flags):
        self.flags = flags

    def all_false(self):
        return all(v is False for v in self.flags.values()) and bool(self.flags)


def muted():
    return Perms(**{n: False for n in PERMISSION_FLAGS})


class FakeBot:
    """Signature-strict stand-in for the five aiogram Bot methods used. `script[method]` = list of exceptions /
    None consumed one per call (None => success)."""

    def __init__(self):
        self.calls: list[tuple[str, tuple, dict]] = []
        self.script: dict[str, list] = {}
        self.chat = NS(permissions=Perms(can_send_messages=True, can_send_photos=False))

    async def _do(self, name, *args, **kw):
        self.calls.append((name, args, kw))
        queue = self.script.get(name)
        step = queue.pop(0) if queue else None
        if isinstance(step, BaseException):
            raise step
        return True

    async def ban_chat_member(self, chat_id, user_id, until_date=None, revoke_messages=None):
        return await self._do("ban_chat_member", chat_id, user_id, until_date=until_date, revoke_messages=revoke_messages)

    async def unban_chat_member(self, chat_id, user_id, only_if_banned=None):
        return await self._do("unban_chat_member", chat_id, user_id, only_if_banned=only_if_banned)

    async def restrict_chat_member(self, chat_id, user_id, permissions, use_independent_chat_permissions=None,
                                   until_date=None):
        return await self._do("restrict_chat_member", chat_id, user_id, permissions=permissions,
                              use_independent_chat_permissions=use_independent_chat_permissions, until_date=until_date)

    async def get_chat(self, chat_id):
        await self._do("get_chat", chat_id)
        return self.chat

    async def delete_message(self, chat_id, message_id):
        return await self._do("delete_message", chat_id, message_id)

    def names(self):
        return [c[0] for c in self.calls]

    def kw(self, name):
        return next(c[2] for c in self.calls if c[0] == name)


@contextlib.contextmanager
def logging_enabled():
    """tests/helpers.py silences logging globally; the log assertions below need it back on."""
    previous = logging.root.manager.disable
    logging.disable(logging.NOTSET)
    try:
        yield
    finally:
        logging.disable(previous)


def make(bot=None, **kw):
    bot = bot or FakeBot()
    slept: list[float] = []

    async def sleep(s):
        slept.append(s)

    kw.setdefault("clock", lambda: NOW_UTC)
    kw.setdefault("muted_permissions", muted)
    return AiogramModerationActions(bot, sleep=sleep, **kw), bot, slept


class ClassifyTests(unittest.TestCase):
    def test_known_error_texts(self):
        cases = {
            "Bad Request: user is an administrator of the chat": "forbidden",
            "Bad Request: can't remove chat owner": "forbidden",
            "Bad Request: not enough rights to restrict/unrestrict chat member": "forbidden",
            "Bad Request: CHAT_ADMIN_REQUIRED": "forbidden",
            "Bad Request: USER_NOT_PARTICIPANT": "not_found",
            "Bad Request: PARTICIPANT_ID_INVALID": "not_found",
            "Bad Request: user not found": "not_found",
            "Bad Request: chat not found": "not_found",
            "Bad Request: method is available for supergroup and channel chats only": "other",
            "weird": "other",
        }
        for text, expected in cases.items():
            with self.subTest(text=text):
                self.assertEqual(classify_error(TelegramBadRequest(text)), expected)
        self.assertEqual(classify_error(TelegramForbiddenError("bot was kicked")), "forbidden")
        self.assertEqual(classify_error(TelegramRetryAfter(5)), "rate_limited")


class ProtocolConformance(unittest.TestCase):
    def test_adapter_matches_both_protocols(self):
        for proto in (MemberActions, ModerationActions):
            for name, member in inspect.getmembers(proto, inspect.isfunction):
                if name.startswith("_"):
                    continue
                with self.subTest(proto=proto.__name__, method=name):
                    want = list(inspect.signature(member).parameters)
                    got = list(inspect.signature(getattr(AiogramModerationActions, name)).parameters)
                    self.assertEqual(got, want)
                    self.assertTrue(inspect.iscoroutinefunction(getattr(AiogramModerationActions, name)))


class BanTests(unittest.IsolatedAsyncioTestCase):
    async def test_permanent_ban_sends_no_until_and_does_not_revoke_messages(self):
        a, bot, _ = make()
        r = await a.ban_member(CHAT, UID, None)
        self.assertEqual(r, ActionResult(True))
        self.assertEqual(bot.calls, [("ban_chat_member", (CHAT, UID), {"until_date": None, "revoke_messages": None})])

    async def test_temporary_ban_passes_aware_utc_until(self):
        a, bot, _ = make()
        until = NOW_UTC + timedelta(hours=1)
        self.assertTrue((await a.ban_member(CHAT, UID, until)).ok)
        sent = bot.kw("ban_chat_member")["until_date"]
        self.assertEqual(sent, until)
        self.assertIsNotNone(sent.tzinfo)

    async def test_non_utc_aware_until_is_normalized_to_utc(self):
        a, bot, _ = make()
        local = (NOW_UTC + timedelta(hours=2)).astimezone(timezone(timedelta(hours=3)))
        await a.ban_member(CHAT, UID, local)
        sent = bot.kw("ban_chat_member")["until_date"]
        self.assertEqual((sent, sent.utcoffset()), (local, timedelta(0)))

    async def test_until_outside_telegram_window_is_refused_without_calling_telegram(self):
        """<30 s or >366 d would silently become a PERMANENT ban."""
        a, bot, _ = make()
        bad = [
            NOW_UTC - timedelta(minutes=5),
            NOW_UTC,
            NOW_UTC + timedelta(seconds=10),
            NOW_UTC + timedelta(seconds=30),
            NOW_UTC + timedelta(days=366, seconds=1),
            NOW_UTC + timedelta(days=4000),
            datetime(2026, 10, 30, 11, 0),  # naive: ambiguous
        ]
        for until in bad:
            with self.subTest(until=until):
                self.assertEqual(await a.ban_member(CHAT, UID, until), ActionResult(False, "other"))
                self.assertEqual(await a.mute_member(CHAT, UID, until), ActionResult(False, "other"))
        self.assertEqual(bot.calls, [])

    async def test_window_boundaries_are_accepted(self):
        a, bot, _ = make()
        self.assertTrue((await a.ban_member(CHAT, UID, NOW_UTC + timedelta(seconds=31))).ok)
        self.assertTrue((await a.ban_member(CHAT, UID, NOW_UTC + timedelta(days=366))).ok)

    async def test_non_datetime_until_is_refused_not_raised(self):
        a, bot, _ = make()
        for junk in ("tomorrow", 3600, object()):
            self.assertEqual(await a.ban_member(CHAT, UID, junk), ActionResult(False, "other"))
        self.assertEqual(bot.calls, [])

    async def test_invalid_ids_are_refused(self):
        a, bot, _ = make()
        for chat, user in [(CHAT, 0), (CHAT, -5), (0, UID), (True, UID), (CHAT, True), ("x", UID), (CHAT, "5001"), (CHAT, None)]:
            with self.subTest(chat=chat, user=user):
                for call in (a.ban_member(chat, user, None), a.unban_member(chat, user), a.mute_member(chat, user, None),
                             a.unmute_member(chat, user), a.kick_member(chat, user)):
                    self.assertEqual(await call, ActionResult(False, "other"))
        self.assertEqual(bot.calls, [])

    async def test_errors_become_results_never_exceptions(self):
        cases = [
            (TelegramForbiddenError("x"), "forbidden"),
            (TelegramBadRequest("Bad Request: user is an administrator of the chat"), "forbidden"),
            (TelegramBadRequest("Bad Request: USER_NOT_PARTICIPANT"), "not_found"),
            (TelegramBadRequest("whatever"), "other"),
            (RuntimeError("network"), "other"),
            (TelegramRetryAfter(60), "rate_limited"),  # too long to wait: returned, not slept
        ]
        for exc, kind in cases:
            with self.subTest(kind=kind, exc=type(exc).__name__):
                a, bot, slept = make()
                bot.script["ban_chat_member"] = [exc]
                self.assertEqual(await a.ban_member(CHAT, UID, None), ActionResult(False, kind))
                self.assertEqual(slept, [])

    async def test_short_retry_after_is_retried_exactly_once(self):
        a, bot, slept = make()
        bot.script["ban_chat_member"] = [TelegramRetryAfter(1)]
        self.assertTrue((await a.ban_member(CHAT, UID, None)).ok)
        self.assertEqual((bot.names(), slept), (["ban_chat_member"] * 2, [1.0]))
        a, bot, slept = make()
        bot.script["ban_chat_member"] = [TelegramRetryAfter(1), TelegramRetryAfter(1), None]
        self.assertEqual(await a.ban_member(CHAT, UID, None), ActionResult(False, "rate_limited"))
        self.assertEqual(len(bot.calls), 2)

    async def test_logs_never_contain_exception_text(self):
        a, bot, _ = make()
        bot.script["ban_chat_member"] = [TelegramBadRequest("token 123:SECRET-DETAIL leaked")]
        with logging_enabled(), self.assertLogs(actions_module.log, level="WARNING") as cm:
            await a.ban_member(CHAT, UID, None)
        self.assertNotIn("SECRET-DETAIL", "\n".join(cm.output))
        self.assertIn("TelegramBadRequest", "\n".join(cm.output))


class UnbanTests(unittest.IsolatedAsyncioTestCase):
    async def test_unban_is_always_only_if_banned(self):
        a, bot, _ = make()
        self.assertTrue((await a.unban_member(CHAT, UID)).ok)
        self.assertEqual(bot.calls, [("unban_chat_member", (CHAT, UID), {"only_if_banned": True})])

    async def test_unban_failure_is_a_result(self):
        a, bot, _ = make()
        bot.script["unban_chat_member"] = [TelegramForbiddenError("x")]
        self.assertEqual(await a.unban_member(CHAT, UID), ActionResult(False, "forbidden"))


class MuteTests(unittest.IsolatedAsyncioTestCase):
    async def test_permanent_mute_denies_everything(self):
        a, bot, _ = make()
        self.assertTrue((await a.mute_member(CHAT, UID, None)).ok)
        kw = bot.kw("restrict_chat_member")
        self.assertTrue(kw["permissions"].all_false())
        self.assertEqual(set(kw["permissions"].flags), set(PERMISSION_FLAGS))
        self.assertIsNone(kw["until_date"])

    async def test_temporary_mute_passes_until(self):
        a, bot, _ = make()
        until = NOW_UTC + timedelta(minutes=10)
        await a.mute_member(CHAT, UID, until)
        self.assertEqual(bot.kw("restrict_chat_member")["until_date"], until)

    async def test_permission_factory_failure_fails_closed(self):
        def boom():
            raise ImportError("aiogram missing")

        a, bot, _ = make(muted_permissions=boom)
        self.assertEqual(await a.mute_member(CHAT, UID, None), ActionResult(False, "other"))
        self.assertEqual(bot.calls, [])

    async def test_default_factory_builds_all_false_using_only_known_fields(self):
        class ChatPermissions:  # stub of the pydantic model: only some flags exist in this "version"
            model_fields = {"can_send_messages": 1, "can_send_photos": 1, "can_pin_messages": 1}

            def __init__(self, **kw):
                self.kw = kw

        fake_types = types.ModuleType("aiogram.types")
        fake_types.ChatPermissions = ChatPermissions
        fake_pkg = types.ModuleType("aiogram")
        saved = {k: sys.modules.get(k) for k in ("aiogram", "aiogram.types")}
        sys.modules.update({"aiogram": fake_pkg, "aiogram.types": fake_types})
        try:
            built = actions_module._all_denied_permissions()
        finally:
            for k, v in saved.items():
                if v is None:
                    sys.modules.pop(k, None)
                else:
                    sys.modules[k] = v
        self.assertEqual(built.kw, {"can_send_messages": False, "can_send_photos": False, "can_pin_messages": False})

    async def test_default_factory_without_aiogram_fails_closed_not_raises(self):
        saved = {k: sys.modules.pop(k) for k in list(sys.modules) if k == "aiogram" or k.startswith("aiogram.")}
        sys.modules["aiogram"] = None  # makes `import aiogram...` raise ImportError
        try:
            a, bot, _ = make(muted_permissions=actions_module._all_denied_permissions)
            self.assertEqual(await a.mute_member(CHAT, UID, None), ActionResult(False, "other"))
            self.assertEqual(bot.calls, [])
        finally:
            sys.modules.pop("aiogram", None)
            sys.modules.update(saved)


class UnmuteTests(unittest.IsolatedAsyncioTestCase):
    async def test_unmute_restores_the_group_default_permissions_exactly(self):
        a, bot, _ = make()
        self.assertTrue((await a.unmute_member(CHAT, UID)).ok)
        self.assertEqual(bot.names(), ["get_chat", "restrict_chat_member"])
        kw = bot.kw("restrict_chat_member")
        self.assertIs(kw["permissions"], bot.chat.permissions)  # the group's defaults, not "allow all"
        self.assertTrue(kw["use_independent_chat_permissions"])
        self.assertIsNone(kw["until_date"])

    async def test_unreadable_defaults_refuse_instead_of_allowing_everything(self):
        a, bot, _ = make()
        bot.chat = NS(permissions=None)
        self.assertEqual(await a.unmute_member(CHAT, UID), ActionResult(False, "other"))
        bot.chat = NS()
        self.assertEqual(await a.unmute_member(CHAT, UID), ActionResult(False, "other"))
        self.assertNotIn("restrict_chat_member", bot.names())

    async def test_get_chat_failure_is_returned_and_nothing_is_restricted(self):
        a, bot, _ = make()
        bot.script["get_chat"] = [TelegramForbiddenError("x")]
        self.assertEqual(await a.unmute_member(CHAT, UID), ActionResult(False, "forbidden"))
        self.assertEqual(bot.names(), ["get_chat"])

    async def test_restrict_failure_is_returned(self):
        a, bot, _ = make()
        bot.script["restrict_chat_member"] = [TelegramBadRequest("Bad Request: USER_NOT_PARTICIPANT")]
        self.assertEqual(await a.unmute_member(CHAT, UID), ActionResult(False, "not_found"))

    async def test_get_chat_rate_limit_is_retried_once(self):
        a, bot, slept = make()
        bot.script["get_chat"] = [TelegramRetryAfter(2)]
        self.assertTrue((await a.unmute_member(CHAT, UID)).ok)
        self.assertEqual(slept, [2.0])


class KickTests(unittest.IsolatedAsyncioTestCase):
    async def test_kick_is_a_short_temporary_ban_then_unban(self):
        a, bot, _ = make()
        self.assertEqual(await a.kick_member(CHAT, UID), ActionResult(True))
        self.assertEqual(bot.names(), ["ban_chat_member", "unban_chat_member"])
        self.assertEqual(bot.kw("ban_chat_member")["until_date"], NOW_UTC + timedelta(seconds=KICK_BAN_WINDOW_SECONDS))
        self.assertEqual(bot.kw("unban_chat_member"), {"only_if_banned": True})

    async def test_failed_ban_returns_its_error_and_never_unbans(self):
        for exc, kind in [(TelegramForbiddenError("x"), "forbidden"), (RuntimeError("n"), "other")]:
            a, bot, _ = make()
            bot.script["ban_chat_member"] = [exc]
            self.assertEqual(await a.kick_member(CHAT, UID), ActionResult(False, kind))
            self.assertEqual(bot.names(), ["ban_chat_member"])

    async def test_transient_unban_failure_is_retried_once_then_succeeds(self):
        a, bot, _ = make()
        bot.script["unban_chat_member"] = [RuntimeError("blip")]
        self.assertEqual(await a.kick_member(CHAT, UID), ActionResult(True))
        self.assertEqual(bot.names(), ["ban_chat_member", "unban_chat_member", "unban_chat_member"])

    async def test_unban_that_keeps_failing_reports_kick_incomplete_and_logs(self):
        a, bot, _ = make()
        bot.script["unban_chat_member"] = [RuntimeError("a"), RuntimeError("b")]
        with logging_enabled(), self.assertLogs(actions_module.log, level="ERROR"):
            r = await a.kick_member(CHAT, UID)
        self.assertEqual(r, ActionResult(False, "kick_incomplete"))
        self.assertEqual(bot.names().count("unban_chat_member"), 2)

    async def test_forbidden_unban_is_not_retried(self):
        a, bot, _ = make()
        bot.script["unban_chat_member"] = [TelegramForbiddenError("x")]
        self.assertEqual(await a.kick_member(CHAT, UID), ActionResult(False, "kick_incomplete"))
        self.assertEqual(bot.names().count("unban_chat_member"), 1)


class PartTwoCompatibility(unittest.IsolatedAsyncioTestCase):
    async def test_engine_mute_and_delete_still_work(self):
        a, bot, _ = make()
        self.assertTrue((await a.delete_message(CHAT, 9)).ok)
        self.assertTrue((await a.mute_member(CHAT, UID, NOW_UTC + timedelta(minutes=10))).ok)
        self.assertEqual(bot.names(), ["delete_message", "restrict_chat_member"])


# --------------------------------------------------------------------------- through the real command service
class ServiceThroughAdapter(ExecBase):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.bot = FakeBot()
        self.actions = AiogramModerationActions(self.bot, clock=self.s.clock, muted_permissions=muted)
        self.svc = self.make_service(self.claims)

    async def test_ban_with_duration_reaches_telegram_and_ledger(self):
        self.member(USER)
        r = await self.run_cmd("/ban 1h spam", reply_to=USER)
        self.assertEqual(r.kind, R.DONE)
        self.assertEqual(self.bot.names(), ["ban_chat_member"])
        self.assertEqual(self.bot.kw("ban_chat_member")["until_date"], NOW + timedelta(hours=1))
        self.assertEqual([x.kind for x in await self.s.sanction_store.get_active(A, USER, NOW)], [K.BAN])

    async def test_permanent_ban_has_no_until(self):
        self.member(USER)
        await self.run_cmd("/ban", reply_to=USER)
        self.assertIsNone(self.bot.kw("ban_chat_member")["until_date"])

    async def test_mute_then_unmute_then_unban_roundtrip(self):
        self.member(USER)
        self.assertEqual((await self.run_cmd("/mute 30m", reply_to=USER, msg=1)).kind, R.DONE)
        self.member(USER, "restricted")
        self.assertEqual((await self.run_cmd("/unmute", reply_to=USER, msg=2)).kind, R.DONE)
        self.assertEqual(self.bot.names(), ["restrict_chat_member", "get_chat", "restrict_chat_member"])
        self.assertIs(self.bot.calls[-1][2]["permissions"], self.bot.chat.permissions)
        self.member(USER, "kicked")
        self.assertEqual((await self.run_cmd("/unban", reply_to=USER, msg=3)).kind, R.DONE)
        self.assertEqual(self.bot.calls[-1][0:3:2], ("unban_chat_member", {"only_if_banned": True}))

    async def test_kick_success(self):
        self.member(USER)
        r = await self.run_cmd("/kick", reply_to=USER)
        self.assertEqual(r.kind, R.DONE)
        self.assertEqual(self.bot.names(), ["ban_chat_member", "unban_chat_member"])

    async def test_kick_incomplete_is_reported_audited_and_not_recorded_as_success(self):
        self.member(USER)
        self.bot.script["unban_chat_member"] = [RuntimeError("a"), RuntimeError("b")]
        r = await self.run_cmd("/kick", reply_to=USER)
        self.assertEqual(r.kind, R.TELEGRAM_FAILED)
        self.assertIn("/unban", r.text)
        self.assertIn("moderation_action_failed", self.audit_types())
        failure = [e for e in self.s.audit.events if e.event_type == "moderation_action_failed"][-1]
        self.assertIn("kick_incomplete", failure.detail)
        self.assertNotIn("sanction_recorded", self.audit_types())

    async def test_forbidden_target_admin_is_a_clean_failure(self):
        self.member(USER)
        self.bot.script["ban_chat_member"] = [TelegramBadRequest("Bad Request: user is an administrator of the chat")]
        r = await self.run_cmd("/ban", reply_to=USER)
        self.assertEqual(r.kind, R.TELEGRAM_FAILED)
        self.assertEqual(await self.s.sanction_store.get_active(A, USER, NOW), [])

    async def test_unauthorized_and_dry_run_never_reach_telegram(self):
        self.member(USER)
        self.assertEqual((await self.run_cmd("/ban", actor=999001, reply_to=USER, msg=1)).kind, R.DENIED)
        await self.settings(dry_run=True)
        for i, (cmd, status) in enumerate((("/ban", "member"), ("/mute", "member"), ("/kick", "member"),
                                           ("/unban", "kicked"), ("/unmute", "restricted")), start=10):
            self.member(USER, status)
            self.assertEqual((await self.run_cmd(cmd, reply_to=USER, msg=i)).kind, R.DRY_RUN, cmd)
        self.assertEqual(self.bot.calls, [])

    async def test_redelivered_update_hits_telegram_once(self):
        self.member(USER)
        first = await self.run_cmd("/ban", reply_to=USER, msg=77)
        again = await self.run_cmd("/ban", reply_to=USER, msg=77)
        self.assertEqual((first.kind, again.kind), (R.DONE, R.DUPLICATE))
        self.assertEqual(self.bot.names(), ["ban_chat_member"])

    async def test_other_group_is_never_touched(self):
        self.member(USER, group=B)
        self.assertEqual((await self.run_cmd("/ban", chat=B, reply_to=USER)).kind, R.DENIED)
        self.assertEqual(self.bot.calls, [])

    async def test_warn_limit_kick_through_adapter(self):
        self.member(USER)
        await self.settings(warn_limit=1, warn_action="kick")
        r = await self.run_cmd("/warn", reply_to=USER)
        self.assertEqual(r.kind, R.DONE)
        self.assertEqual(self.bot.names(), ["ban_chat_member", "unban_chat_member"])


if __name__ == "__main__":
    unittest.main()
