"""Part 8.2: automatic security / consistency guards over the whole tree (static scans + a few behavioural checks).

(a) no secrets in source/docs/examples  (b) nothing assigns the owner id outside `Settings`  (c) every aiogram callback prefix is
known and every router is a thin adapter  (d) every SQL statement touching a group table carries `group_id` or is on a documented
whitelist  (e) claims precede every Telegram side effect of the command paths  (g) imports == requirements, migrations contiguous
(h) no TODO / stub code  (+ the executor's own Telegram right for /ban /unban /mute /unmute /kick /warn).
Nothing here proves behaviour against the real aiogram / Telegram / PostgreSQL."""
from __future__ import annotations

import ast
import re
import sys
import unittest
from pathlib import Path

from executor_stack import USER, ExecBase
from guardian.moderation.executor import ResultKind as R
from guardian.telegram_rights import ChatMemberInfo
from stack import A, TG_ADMIN, TG_LIMITED_ADMIN

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src" / "guardian"
TEXT_SUFFIXES = {".py", ".md", ".yaml", ".yml", ".toml", ".txt", ".example", ".sql"}


def repo_files(*, with_tests: bool):
    for p in sorted(ROOT.rglob("*")):
        if not p.is_file() or "__pycache__" in p.parts or ".git" in p.parts:
            continue
        if p.parts[len(ROOT.parts)] == "tests" and not with_tests:
            continue
        if p.suffix in TEXT_SUFFIXES or p.name in {".env.example", ".gitignore"}:
            yield p


def src_files():
    return sorted(SRC.rglob("*.py"))


def tree_of(p: Path) -> ast.AST:
    return ast.parse(p.read_text(encoding="utf-8"))


# ------------------------------------------------------------------------------------------------- (a) secrets
TOKEN = re.compile(r"\b\d{8,12}:[A-Za-z0-9_-]{35}\b")
DB_URL = re.compile(r"(?:postgres(?:ql)?|mysql|redis|amqp)://([^\s:/@\"']+):([^\s@\"']+)@")
PEM = re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")
PLACEHOLDER_PASSWORDS = {"password", "pass", "كلمة_المرور", "PASSWORD", "<password>", "secret", "changeme"}


class NoSecretsInTheTree(unittest.TestCase):
    def test_no_bot_token_private_key_or_real_looking_database_url_outside_tests(self):
        bad = []
        for p in repo_files(with_tests=False):
            text = p.read_text(encoding="utf-8", errors="ignore")
            rel = p.relative_to(ROOT)
            for m in TOKEN.finditer(text):
                bad.append((str(rel), "bot token shape"))
            for m in PEM.finditer(text):
                bad.append((str(rel), "private key"))
            for m in DB_URL.finditer(text):
                if m.group(2) not in PLACEHOLDER_PASSWORDS:
                    bad.append((str(rel), "database url with a non-placeholder password"))
        self.assertEqual(bad, [])

    def test_the_scan_really_detects_each_shape(self):
        self.assertTrue(TOKEN.search("123456789:" + "A" * 35))
        self.assertTrue(PEM.search("-----BEGIN RSA PRIVATE KEY-----"))
        m = DB_URL.search("postgresql://bob:s3cr3tvalue@host/db")
        self.assertTrue(m and m.group(2) not in PLACEHOLDER_PASSWORDS)

    def test_env_and_archives_are_not_part_of_the_tree(self):
        names = {p.name for p in ROOT.rglob("*") if p.is_file() and ".git" not in p.parts}
        self.assertNotIn(".env", names)
        self.assertFalse([n for n in names if n.endswith((".pem", ".key", ".zip", ".sqlite", ".db"))])


# ------------------------------------------------------------------------------------------------- (b) owner id
class NobodyAssignsTheOwner(unittest.TestCase):
    def test_owner_ids_are_only_ever_assigned_when_building_settings(self):
        hits = []
        for p in src_files():
            for n in ast.walk(tree_of(p)):
                targets = []
                if isinstance(n, ast.Assign):
                    targets = n.targets
                elif isinstance(n, (ast.AugAssign, ast.AnnAssign)):
                    targets = [n.target]
                for t in targets:
                    name = t.attr if isinstance(t, ast.Attribute) else t.id if isinstance(t, ast.Name) else ""
                    if "owner_telegram_id" in name:
                        hits.append(p.name)
        self.assertEqual(set(hits), {"config.py"})

    def test_no_setattr_trick_and_authority_is_built_in_one_place_from_settings(self):
        for p in src_files():
            text = p.read_text(encoding="utf-8")
            self.assertNotRegex(text, r"setattr\([^)]*owner_telegram_id", p.name)
        builders = [p.name for p in src_files() if re.search(r"\bAuthority\(", p.read_text(encoding="utf-8"))]
        self.assertEqual(builders, ["app.py"])
        self.assertIn("Authority(settings.owner_telegram_id, settings.backup_owner_telegram_id)",
                      (SRC / "app.py").read_text(encoding="utf-8"))

    def test_no_sql_writes_an_owner_column(self):
        for p in sorted((SRC / "db" / "sql").glob("*.sql")):
            self.assertNotRegex(p.read_text(encoding="utf-8").lower(), r"owner_telegram_id")


# ------------------------------------------------------------------------------------------------- (c) handlers
RAW_TELEGRAM_WRITES = {"ban_chat_member", "restrict_chat_member", "unban_chat_member", "delete_message", "delete_messages",
                       "pin_chat_message", "unpin_chat_message", "set_chat_permissions", "send_document", "promote_chat_member"}


class RoutersAreThinAdapters(unittest.TestCase):
    def test_the_callback_prefixes_are_exactly_the_audited_ones(self):
        found = {}
        for p in sorted((SRC / "bot" / "routers").glob("*.py")):
            for m in re.finditer(r"callback_query\(F\.data\.startswith\(\"([a-z]+:)\"\)\)", p.read_text(encoding="utf-8")):
                found[m.group(1)] = p.stem
        # a new callback prefix needs its forged-callback tests first, then an edit here
        self.assertEqual(found, {"pn:": "panel", "ow:": "owner_panel", "vf:": "members", "cf:": "members"})

    def test_every_callback_handler_module_reads_the_presser_from_telegram_not_from_the_data(self):
        for name in ("panel_handler.py", "owner_panel_handler.py", "members_handler.py"):
            text = (SRC / "bot" / name).read_text(encoding="utf-8")
            self.assertIn("from_user", text, name)

    def test_routers_never_call_a_telegram_write_directly(self):
        for p in sorted((SRC / "bot" / "routers").glob("*.py")):
            attrs = {n.attr for n in ast.walk(tree_of(p)) if isinstance(n, ast.Attribute)}
            self.assertFalse(attrs & RAW_TELEGRAM_WRITES, p.name)

    def test_every_router_handler_delegates_to_a_service_or_handler_module(self):
        for p in sorted((SRC / "bot" / "routers").glob("*.py")):
            if p.name in ("__init__.py", "errors.py"):
                continue
            for fn in [n for n in ast.walk(tree_of(p)) if isinstance(n, ast.AsyncFunctionDef)]:
                if not any(isinstance(d, ast.Call) or isinstance(d, ast.Attribute) for d in fn.decorator_list):
                    continue  # a filter helper, not a handler
                body = ast.dump(fn)
                self.assertTrue("services" in body or "Name(id='h'" in body or "Attribute(value=Name(id='h'" in body,
                                f"{p.name}:{fn.name} does not delegate")


# ------------------------------------------------------------------------------------------------- (d) group_id in SQL
SQL_WORDS = re.compile(r"\b(SELECT|INSERT INTO|UPDATE|DELETE FROM)\b", re.IGNORECASE)
# (file, table) pairs that intentionally act across groups, with the reason
CROSS_GROUP = {
    ("members/postgres_store.py", "member_verifications"): "retention sweep of RESOLVED challenges by age (returns ids only)",
    ("owner_templates/store_pg.py", "settings_templates"): "owner-only global templates (not group data)",
}


def group_tables() -> set[str]:
    mig = "".join(p.read_text(encoding="utf-8") for p in sorted((SRC / "db" / "sql").glob("*.sql")))
    out = set()
    for m in re.finditer(r"CREATE TABLE(?: IF NOT EXISTS)?\s+(\w+)\s*\((.*?)\n\);", mig, re.S):
        if "group_id" in m.group(2):
            out.add(m.group(1))
    return out


def sql_literals(p: Path):
    tree = tree_of(p)
    docs = set()
    for n in ast.walk(tree):
        if isinstance(n, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)) and n.body \
                and isinstance(n.body[0], ast.Expr) and isinstance(getattr(n.body[0], "value", None), ast.Constant):
            docs.add(id(n.body[0].value))
    for n in ast.walk(tree):
        if isinstance(n, ast.Constant) and isinstance(n.value, str) and id(n) not in docs and SQL_WORDS.search(n.value):
            yield n.lineno, n.value


class EverySqlStatementIsGroupScoped(unittest.TestCase):
    def test_statements_on_group_tables_carry_group_id_or_are_whitelisted(self):
        tables, bad = group_tables(), []
        self.assertIn("group_reports", tables)
        for p in src_files():
            rel = str(p.relative_to(SRC))
            if rel.startswith("backup/"):
                continue  # whole-database backup/restore: owner-only, explicit column registry (own guards in test_backup*)
            for line, sql in sql_literals(p):
                for t in tables:
                    if re.search(r"\b" + t + r"\b", sql) and "group_id" not in sql and (rel, t) not in CROSS_GROUP:
                        bad.append((rel, line, t))
        self.assertEqual(bad, [])

    def test_the_whitelist_has_no_stale_entries(self):
        for (rel, table), reason in CROSS_GROUP.items():
            self.assertTrue(reason)
            self.assertTrue(any(re.search(r"\b" + table + r"\b", s) and "group_id" not in s
                                for _l, s in sql_literals(SRC / rel)), (rel, table))

    def test_backup_modules_are_owner_only_and_nothing_else_imports_them(self):
        for p in src_files():
            rel = str(p.relative_to(SRC))
            if rel.startswith("backup/") or rel in ("app.py", "services.py") or rel.startswith("bot/"):
                continue
            self.assertNotRegex(p.read_text(encoding="utf-8"), r"from \.+backup|import guardian\.backup", rel)


# ------------------------------------------------------------------------------------------------- (e) claims first
def order(text: str, first: str, second: str) -> bool:
    return 0 <= text.index(first) < text.index(second)


class ClaimsPrecedeSideEffects(unittest.TestCase):
    def test_member_commands_claim_before_executing(self):
        text = (SRC / "moderation" / "executor.py").read_text(encoding="utf-8")
        self.assertTrue(order(text, "claimed = await self._claims.claim(key)", "return await self._execute(ctx, key)"))

    def test_message_commands_claim_before_pin_unpin_purge(self):
        text = (SRC / "moderation" / "message_commands.py").read_text(encoding="utf-8")
        self.assertTrue(order(text, "self._claims.claim(operation_key(\"mod\"", "return await self._pin("))

    def test_lock_commands_claim_before_changing_permissions(self):
        text = (SRC / "moderation" / "lock_commands.py").read_text(encoding="utf-8")
        self.assertIn("claim(", text)
        self.assertTrue(order(text, "claim(", "set_default_permissions("))

    def test_welcome_and_verification_are_claimed_per_event(self):
        w = (SRC / "members" / "welcome.py").read_text(encoding="utf-8")
        self.assertTrue(order(w, "operation_key(\"welcome\"", "_send_welcome(group, cfg"))
        self.assertTrue(order(w, "operation_key(\"welcomepass\"", "_send_welcome(group_id, cfg"))
        v = (SRC / "members" / "verification.py").read_text(encoding="utf-8")
        self.assertTrue(order(v, "operation_key(\"verify\"", "mute_member(group, member.user_id, None)"))

    def test_the_protection_engine_records_the_offense_through_a_claim_before_muting(self):
        text = (SRC / "protection" / "engine.py").read_text(encoding="utf-8")
        self.assertIn("claim", text)


# ------------------------------------------------------------------------------------------------- (g) imports / migrations
REQ_TO_MODULE = {"aiogram": "aiogram", "fastapi": "fastapi", "uvicorn": "uvicorn", "asyncpg": "asyncpg",
                 "python-dotenv": "dotenv", "tzdata": None}  # tzdata is data for zoneinfo: never imported


class DependenciesAndMigrations(unittest.TestCase):
    def requirements(self) -> set[str]:
        out = set()
        for line in (ROOT / "requirements.txt").read_text(encoding="utf-8").splitlines():
            line = line.split("#")[0].strip()
            if line:
                out.add(re.split(r"[=<>~!]", line)[0].strip().lower())
        return out

    def test_every_third_party_import_is_a_pinned_requirement_and_vice_versa(self):
        imported = set()
        for p in src_files():
            for n in ast.walk(tree_of(p)):
                if isinstance(n, ast.Import):
                    imported |= {a.name.split(".")[0] for a in n.names}
                elif isinstance(n, ast.ImportFrom) and n.level == 0 and n.module:
                    imported.add(n.module.split(".")[0])
        third = {m for m in imported if m not in sys.stdlib_module_names and m != "guardian"}
        reqs = self.requirements()
        self.assertEqual(reqs, set(REQ_TO_MODULE))
        self.assertEqual(third, {m for m in REQ_TO_MODULE.values() if m})
        for line in (ROOT / "requirements.txt").read_text(encoding="utf-8").splitlines():
            if line.strip() and not line.startswith("#"):
                self.assertIn("==", line, line)  # pinned

    def test_migrations_are_contiguous_unique_and_named_consistently(self):
        files = sorted(p.name for p in (SRC / "db" / "sql").glob("*.sql"))
        numbers = [int(f[:4]) for f in files]
        self.assertEqual(numbers, list(range(1, len(files) + 1)))
        self.assertEqual(len(set(numbers)), len(numbers))
        for f in files:
            self.assertRegex(f, r"^\d{4}_[a-z0-9_]+\.sql$")

    def test_a_delivered_migration_is_never_edited_the_runner_checks_checksums(self):
        text = (SRC / "db" / "migrations.py").read_text(encoding="utf-8")
        self.assertRegex(text, r"checksum|sha256")


# ------------------------------------------------------------------------------------------------- (h) honesty scan
class NoPlaceholderCode(unittest.TestCase):
    def test_no_todo_fixme_or_not_implemented_markers_in_the_source(self):
        pattern = re.compile(r"\b(TODO|FIXME|XXX|HACK)\b|NotImplemented")
        bad = [(p.name, m.group(0)) for p in src_files() for m in pattern.finditer(p.read_text(encoding="utf-8"))]
        self.assertEqual(bad, [])

    def test_stub_bodies_exist_only_in_protocol_classes(self):
        bad = []
        for p in src_files():
            tree = tree_of(p)
            protocol_funcs = set()
            for cls in [n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]:
                if any(ast.unparse(b).startswith("Protocol") for b in cls.bases):
                    protocol_funcs |= {id(f) for f in cls.body if isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef))}
            for f in [n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]:
                body = [x for x in f.body if not (isinstance(x, ast.Expr) and isinstance(x.value, ast.Constant)
                                                  and isinstance(x.value.value, str))]
                stub = len(body) == 1 and (isinstance(body[0], ast.Pass) or (
                    isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) and body[0].value.value is Ellipsis))
                if stub and id(f) not in protocol_funcs:
                    bad.append((p.name, f.name))
        self.assertEqual(bad, [])


# ------------------------------------------------------------------------------------------------- executor's own right
class SanctionCommandsNeedTheExecutorsTelegramRight(ExecBase):
    """Owner decision (part 8.2): /ban /unban /mute /unmute /kick /warn need the executor's OWN right to restrict members,
    like /pin and /purge need theirs. The single enforcement point is the MODERATE decision (live Telegram lookup)."""

    COMMANDS = ("/ban", "/unban", "/mute", "/unmute", "/kick", "/warn")

    async def test_an_admin_without_the_restrict_right_is_denied_for_every_one_of_them_with_no_effect(self):
        self.member(USER)
        for i, cmd in enumerate(self.COMMANDS):
            r = await self.run_cmd(cmd, actor=TG_LIMITED_ADMIN, reply_to=USER, msg=100 + i)
            self.assertEqual(r.kind, R.DENIED, cmd)
        self.assertEqual(self.actions.calls, [])

    async def test_the_right_is_looked_up_live_so_a_just_revoked_right_is_honoured(self):
        self.member(USER)
        ok = await self.run_cmd("/kick", actor=TG_ADMIN, reply_to=USER, msg=1)
        self.assertEqual(ok.kind, R.DONE)
        self.s.chat.set(A, TG_ADMIN, ChatMemberInfo("administrator", True, False, True))  # restrict right revoked
        self.member(USER)
        again = await self.run_cmd("/kick", actor=TG_ADMIN, reply_to=USER, msg=2)
        self.assertEqual(again.kind, R.DENIED)

    async def test_a_telegram_lookup_failure_denies_every_one_of_them(self):
        self.member(USER)
        self.s.chat.fail = True
        try:
            for i, cmd in enumerate(self.COMMANDS):
                r = await self.run_cmd(cmd, actor=TG_ADMIN, reply_to=USER, msg=200 + i)
                self.assertIn(r.kind, (R.DENIED, R.ERROR), cmd)
        finally:
            self.s.chat.fail = False
        self.assertEqual(self.actions.calls, [])

    async def test_an_admin_with_the_restrict_right_can_use_them(self):
        self.member(USER)
        self.assertEqual((await self.run_cmd("/mute", actor=TG_ADMIN, reply_to=USER, msg=1)).kind, R.DONE)


if __name__ == "__main__":
    unittest.main()
