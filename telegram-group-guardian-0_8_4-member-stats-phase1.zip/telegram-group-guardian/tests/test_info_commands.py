"""Part 3.5-1: /id /info /admins /report (info_commands.py) + their parser, adapter and menu pieces."""
from __future__ import annotations

import unittest
from datetime import timedelta
from types import SimpleNamespace as NS

from executor_stack import A, B, BOT, BOT_NAME, OTHER, USER, ExecBase, gate
from guardian.bot import moderation_handler as h
from guardian.bot.chat_info import AiogramChatInfo
from guardian.errors import TelegramLookupFailed
from guardian.moderation.commands import Command, parse_command
from guardian.moderation.executor import ResultKind as R
from guardian.moderation.info_commands import clean_display, message_link
from guardian.moderation.models import SanctionKind
from guardian.moderation.targets import ReplyInfo
from guardian.telegram_rights import AdminInfo, ChatMemberInfo, admin_info_from_telegram
from stack import DELEGATE, OWNER, STRANGER, TG_ADMIN, TG_CREATOR, TG_LIMITED_ADMIN


def adm(uid, name="Admin", *, creator=False, anonymous=False, bot=False, title=None, delete=True, restrict=True, username=None):
    return AdminInfo(uid, name, username, creator, anonymous, bot, title, delete or creator, restrict or creator)


class InfoBase(ExecBase):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.s.chat.admins[A] = [adm(TG_CREATOR, "Boss", creator=True), adm(TG_ADMIN, "Alice", title="mod"),
                                 adm(BOT, "GuardianBot", bot=True)]

    async def cmd(self, text, **kw):
        kw.setdefault("actor", USER)
        return await self.run_cmd(text, **kw)

    def advance(self, **kw):
        self.s.clock.advance(**kw)


# ----------------------------------------------------------------------------- parser
class ParserTests(unittest.TestCase):
    def p(self, text, reply=False):
        return parse_command(text, BOT_NAME, has_reply=reply)

    def test_english_commands(self):
        for text, cmd in (("/id", Command.ID), ("/info 123", Command.INFO), ("/admins", Command.ADMINS),
                          ("/report spam", Command.REPORT), ("/ID", Command.ID), (f"/id@{BOT_NAME}", Command.ID)):
            self.assertIs(self.p(text).command, cmd, text)
        self.assertIsNone(self.p("/id@OtherBot"))
        self.assertEqual(self.p("/report spam links").args, ("spam", "links"))

    def test_standalone_arabic_aliases_only_as_the_whole_message(self):
        self.assertIs(self.p("ايدي").command, Command.ID)
        self.assertIs(self.p("الأيدي").command if False else self.p("الايدي").command, Command.ID)
        self.assertIs(self.p("المشرفين").command, Command.ADMINS)
        self.assertIs(self.p("  المشرفين  ").command, Command.ADMINS)
        for chatter in ("ايدي يا شباب", "المشرفين وينكم", "المشرفين @abcde", "ايدي 123"):
            self.assertIsNone(self.p(chatter), chatter)
            self.assertIsNone(self.p(chatter, reply=True), chatter)

    def test_report_and_info_aliases_need_a_reply_or_target(self):
        self.assertIsNone(self.p("بلاغ"))
        self.assertIs(self.p("بلاغ", reply=True).command, Command.REPORT)
        self.assertIs(self.p("ابلاغ سبام", reply=True).command, Command.REPORT)
        self.assertIsNone(self.p("معلومات عن البوت"))
        self.assertIs(self.p("معلومات @abcde").command, Command.INFO)
        self.assertIs(self.p("معلومات العضو 12345").command, Command.INFO)

    def test_existing_commands_unchanged(self):
        self.assertIs(self.p("/ban 5").command, Command.BAN)
        self.assertIs(self.p("حظر @abcde").command, Command.BAN)
        self.assertEqual({c.value for c in Command},
                         {"ban", "unban", "mute", "unmute", "kick", "warn", "warnings", "clearwarns", "id", "info", "admins", "report",
                          "pin", "unpin", "purge", "lock", "unlock", "slowmode", "antiflood", "protect",
                          "trust", "untrust", "trusted", "welcome", "verify", "newbie", "settings", "panel", "reports", "stats", "export"})  # closing parts 2, 3 + 4.2 + 4.6 + 4.7a + 6.4a + 6.5b + 6.7b


# ----------------------------------------------------------------------------- /id
class IdTests(InfoBase):
    async def test_member_gets_own_and_chat_id_only(self):
        r = await self.cmd("/id", reply_to=OTHER)
        self.assertIs(r.kind, R.INFO)
        self.assertIn(f"<code>{USER}</code>", r.text)
        self.assertIn(f"<code>{A}</code>", r.text)
        self.assertNotIn(str(OTHER), r.text)  # the replied-to id is moderator-only
        self.assertEqual(self.actions.calls, [])

    async def test_moderator_also_gets_the_replied_member_id(self):
        r = await self.run_cmd("/id", actor=TG_ADMIN, reply_to=OTHER)
        self.assertIn(f"<code>{OTHER}</code>", r.text)
        self.assertEqual(r.target_id, OTHER)

    async def test_limited_admin_without_restrict_right_is_not_a_moderator(self):
        r = await self.run_cmd("/id", actor=TG_LIMITED_ADMIN, reply_to=OTHER)
        self.assertNotIn(str(OTHER), r.text)

    async def test_no_denial_audit_noise_for_ordinary_members(self):
        await self.cmd("/id", reply_to=OTHER)
        self.assertNotIn("permission_denied", self.audit_types())

    async def test_cooldown_is_silent_and_per_user(self):
        self.assertIs((await self.cmd("/id")).kind, R.INFO)
        r = await self.cmd("/id")
        self.assertIs(r.kind, R.THROTTLED)
        self.assertEqual(r.text, "")
        self.assertIs((await self.cmd("/id", actor=OTHER)).kind, R.INFO)  # another user is not throttled
        self.advance(seconds=6)
        self.assertIs((await self.cmd("/id")).kind, R.INFO)

    async def test_english_text_and_arabic_alias_work_through_parser(self):
        r = await self.cmd("ايدي")
        self.assertIs(r.kind, R.INFO)


# ----------------------------------------------------------------------------- /admins
class AdminsTests(InfoBase):
    async def test_lists_names_without_bots_ids_or_pings(self):
        r = await self.cmd("/admins")
        self.assertIs(r.kind, R.INFO)
        self.assertIn("Boss", r.text)
        self.assertIn("Alice — mod", r.text)
        self.assertNotIn("GuardianBot", r.text)
        self.assertNotIn("@", r.text)
        self.assertNotIn("tg://", r.text)
        self.assertNotIn(str(TG_ADMIN), r.text)
        self.assertLess(r.text.index("Boss"), r.text.index("Alice"))  # creator first

    async def test_names_are_sanitised_and_escaped(self):
        self.s.chat.admins[A] = [adm(TG_ADMIN, "<b>Eve</b>\u202e\u200bX\n" + "y" * 80, title="<i>t</i>")]
        r = await self.cmd("/admins")
        self.assertNotIn("<b>Eve", r.text)
        self.assertIn("&lt;b&gt;Eve", r.text)
        self.assertNotIn("\u202e", r.text)
        self.assertNotIn("\u200b", r.text)
        self.assertNotIn("y" * 50, r.text)
        self.assertIn("&lt;i&gt;t", r.text)

    async def test_anonymous_and_more_than_the_limit(self):
        self.s.chat.admins[A] = [adm(1000 + i, f"Adm{i:02d}") for i in range(35)] + [adm(5, "Aaa Ghost", anonymous=True)]
        r = await self.cmd("/admins")
        self.assertIn("Aaa Ghost (", r.text)
        self.assertIn("… و6 آخرون", r.text.replace("\u200f", ""))
        self.assertEqual(r.text.count("\n•") + r.text.count("\n👑"), 30)

    async def test_lookup_failure_is_a_safe_error_and_still_throttles(self):
        self.s.chat.admins_fail = True
        r = await self.cmd("/admins")
        self.assertIs(r.kind, R.ERROR)
        self.assertNotIn("down", r.text)
        self.assertIs((await self.cmd("/admins", actor=OTHER)).kind, R.THROTTLED)  # per chat: protects the API

    async def test_per_chat_cooldown_and_isolation(self):
        await self.cmd("/admins")
        self.assertIs((await self.cmd("/admins", actor=OTHER)).kind, R.THROTTLED)
        self.s.chat.admins[B] = [adm(TG_CREATOR, "OtherBoss", creator=True)]
        r = await self.cmd("/admins", chat=B)
        self.assertIn("OtherBoss", r.text)
        self.assertNotIn("Boss</", r.text.replace("OtherBoss", ""))
        self.advance(seconds=31)
        self.assertIs((await self.cmd("/admins")).kind, R.INFO)

    async def test_empty_list(self):
        self.s.chat.admins[A] = [adm(BOT, "GuardianBot", bot=True)]
        self.assertIs((await self.cmd("/admins")).kind, R.INFO)

    async def test_arabic_alias(self):
        self.assertIn("Boss", (await self.cmd("المشرفين")).text)


# ----------------------------------------------------------------------------- /info
class InfoTests(InfoBase):
    async def test_requires_moderate_permission(self):
        for actor in (USER, TG_LIMITED_ADMIN, STRANGER):
            r = await self.run_cmd("/info", actor=actor, reply_to=OTHER)
            self.assertIs(r.kind, R.DENIED, actor)
        self.assertIn("permission_denied", self.audit_types())

    async def test_shows_status_exemption_warnings_and_restrictions(self):
        self.member(OTHER, "restricted")
        await self.run_cmd("/warn spam", reply_to=OTHER, msg=1)
        await self.s.sanctions.record(OWNER, A, OTHER, SanctionKind.MUTE, expires_at=self.s.clock() + timedelta(hours=2),
                                      context_chat_id=A)
        r = await self.run_cmd("/info", reply_to=OTHER, msg=2)
        self.assertIs(r.kind, R.INFO)
        self.assertIn(f"<code>{OTHER}</code>", r.text)
        self.assertIn("مقيّد", r.text)
        self.assertIn("غير معفى", r.text)
        self.assertIn("1/3", r.text)
        self.assertIn("2", r.text)  # remaining hours
        self.assertNotIn("spam", r.text)  # reasons are never echoed

    async def test_protected_member_can_be_inspected_and_is_marked_exempt(self):
        r = await self.run_cmd("/info", reply_to=TG_CREATOR)
        self.assertIs(r.kind, R.INFO)
        self.assertIn("معفى (", r.text)
        self.assertIn("منشئ", r.text)

    async def test_target_by_id_and_errors_are_localised(self):
        self.member(OTHER)
        self.assertIs((await self.run_cmd(f"/info {OTHER}")).kind, R.INFO)
        r = await self.run_cmd("/info")
        self.assertIs(r.kind, R.INVALID)
        self.assertTrue(r.text)
        r = await self.run_cmd(f"/info {BOT}")
        self.assertIs(r.kind, R.INVALID)

    async def test_license_off_is_explained_to_moderators(self):
        r = await self.run_cmd("/info", reply_to=OTHER, protection=gate(A, TG_ADMIN, allowed=False))
        self.assertIs(r.kind, R.LICENSE_OFF)
        self.assertTrue(r.text)

    async def test_other_group_context_never_leaks(self):
        # moderator of A cannot inspect inside group B
        r = await self.run_cmd("/info", chat=B, actor=TG_ADMIN, reply_to=OTHER, protection=gate(B, TG_ADMIN))
        self.assertIs(r.kind, R.DENIED)

    async def test_lookup_failure_for_counts_is_reported_as_unavailable_not_zero(self):
        self.member(OTHER)

        async def boom(*a, **k):
            raise RuntimeError("db down")
        self.s.warnings.count_active = boom
        r = await self.run_cmd("/info", reply_to=OTHER)
        self.assertIs(r.kind, R.INFO)
        self.assertIn("غير متاح", r.text)
        self.assertNotIn("0/3", r.text)

    async def test_expired_lifted_and_kick_records_are_never_listed_as_active(self):
        from datetime import datetime, timezone
        from guardian.moderation.models import Sanction
        now = self.s.clock()
        rows = [
            Sanction(1, A, OTHER, SanctionKind.MUTE, None, None, now - timedelta(days=2), expires_at=now - timedelta(hours=1)),
            Sanction(2, A, OTHER, SanctionKind.BAN, None, None, now - timedelta(days=2), lifted_at=now - timedelta(days=1)),
            Sanction(3, A, OTHER, SanctionKind.KICK, None, None, now - timedelta(days=2)),
        ]

        async def stale(*a, **k):
            return rows
        self.s.sanctions.active = stale
        self.member(OTHER)
        r = await self.run_cmd("/info", reply_to=OTHER)
        self.assertIn("لا يوجد", r.text)
        self.assertNotIn("متبق", r.text)

    async def test_exemption_lookup_failure_reads_as_exempt_never_as_punishable(self):
        self.member(OTHER)

        async def boom(*a, **k):
            raise RuntimeError("down")
        self.s.perm.is_exempt_from_automation = boom
        r = await self.run_cmd("/info", reply_to=OTHER)
        self.assertIn("معفى (", r.text)

    async def test_info_is_read_only(self):
        self.member(OTHER)
        await self.run_cmd("/info", reply_to=OTHER)
        self.assertEqual(self.actions.calls, [])
        self.assertEqual(await self.s.sanctions.active(OWNER, A, OTHER, context_chat_id=A), [])


# ----------------------------------------------------------------------------- /report
class ReportTests(InfoBase):
    async def report(self, text="/report", *, actor=USER, reply_to=OTHER, msg=10, chat=A, protection="default", reply_mid=77):
        parsed = parse_command(text, BOT_NAME, has_reply=reply_to is not None)
        prot = gate(chat, actor) if protection == "default" else protection
        reply = ReplyInfo(reply_to, message_id=reply_mid) if reply_to is not None else None
        return await self.svc.handle(parsed, chat_id=chat, actor_id=actor, message_id=msg, protection=prot, reply=reply)

    async def test_notifies_admins_who_can_act_with_hidden_mentions_and_link(self):
        self.member(OTHER)
        r = await self.report("/report spam <script>")
        self.assertIs(r.kind, R.DONE)
        self.assertIn(f'<a href="tg://user?id={TG_CREATOR}">', r.text)
        self.assertIn(f'<a href="tg://user?id={TG_ADMIN}">', r.text)
        self.assertNotIn(f"user?id={BOT}", r.text)  # bots are never pinged
        self.assertIn(f"<code>{USER}</code>", r.text)
        self.assertIn(f"<code>{OTHER}</code>", r.text)
        self.assertNotIn("<script>", r.text)
        self.assertIn("&lt;script&gt;", r.text)
        self.assertIn('<a href="https://t.me/c/1/77">', r.text)  # chat id -1001 => internal id 1, replied message 77
        self.assertEqual(self.actions.calls, [])  # notify-only: no moderation action at all
        self.assertIn("report_filed", self.audit_types())

    async def test_supergroup_link_is_built_for_100_prefixed_chats(self):
        self.assertEqual(message_link(-1001234567890, 55), "https://t.me/c/1234567890/55")
        for bad in (-123456, 5, -100, -1000123, -777, True):
            self.assertIsNone(message_link(bad, 5), bad)
        self.assertIsNone(message_link(-1001234567890, None))

    async def test_basic_group_has_no_message_link(self):
        self.s.chat.admins[-777] = [adm(TG_CREATOR, "Boss", creator=True)]
        r = await self.report(chat=-777, protection=gate(-777, USER))
        self.assertIs(r.kind, R.DONE)
        self.assertNotIn("t.me", r.text)
        self.assertIn("tg://user?id=", r.text)

    async def test_audit_stores_ids_only_never_the_reason(self):
        await self.report("/report my secret reason")
        details = " ".join(e.detail or "" for e in self.s.audit.events if e.event_type == "report_filed")
        self.assertIn(f"target={OTHER}", details)
        self.assertNotIn("secret", details)

    async def test_needs_a_reply(self):
        r = await self.report("/report spam", reply_to=None)
        self.assertIs(r.kind, R.INVALID)
        self.assertTrue(r.text)

    async def test_cannot_report_self_admin_owner_or_bot(self):
        self.s.chat.admins[A] = [adm(TG_CREATOR, "Boss", creator=True)]
        for target, who in ((USER, "self"), (TG_ADMIN, "admin"), (TG_CREATOR, "creator"), (OWNER, "owner"), (BOT, "bot")):
            r = await self.report(reply_to=target, msg=20 + target % 7)
            self.assertIs(r.kind, R.INVALID, who)
            self.assertNotIn("tg://user", r.text, who)
        self.assertNotIn("report_filed", self.audit_types())

    async def test_sender_chat_reply_cannot_be_reported(self):
        parsed = parse_command("/report", BOT_NAME, has_reply=True)
        r = await self.svc.handle(parsed, chat_id=A, actor_id=USER, message_id=3, protection=gate(A, USER),
                                  reply=ReplyInfo(None, sender_chat=True))
        self.assertIs(r.kind, R.INVALID)

    async def test_cooldown_counts_only_posted_reports(self):
        self.member(OTHER)
        await self.report(reply_to=USER)  # invalid (self) must not start the cooldown
        self.assertIs((await self.report(msg=11)).kind, R.DONE)
        r = await self.report(msg=12)
        self.assertIs(r.kind, R.THROTTLED)
        self.assertEqual(r.text, "")
        self.assertIs((await self.report(msg=13, actor=STRANGER)).kind, R.DONE)  # per reporter
        self.advance(seconds=61)
        self.assertIs((await self.report(msg=14)).kind, R.DONE)

    async def test_redelivered_update_never_pings_twice(self):
        self.member(OTHER)
        self.assertIs((await self.report(msg=30)).kind, R.DONE)
        self.advance(seconds=120)  # cooldown over: only the claim protects now
        r = await self.report(msg=30)
        self.assertIs(r.kind, R.DUPLICATE)
        self.assertEqual(r.text, "")

    async def test_broken_claim_store_sends_nothing(self):
        from executor_stack import BrokenClaims
        svc = self.make_service(BrokenClaims())
        parsed = parse_command("/report", BOT_NAME, has_reply=True)
        r = await svc.handle(parsed, chat_id=A, actor_id=USER, message_id=1, protection=gate(A, USER),
                             reply=ReplyInfo(OTHER, message_id=5))
        self.assertIs(r.kind, R.ERROR)
        self.assertNotIn("tg://user", r.text)

    async def test_admin_lookup_failure_tells_the_reporter_nobody_was_notified(self):
        self.s.chat.admins_fail = True
        r = await self.report()
        self.assertIs(r.kind, R.ERROR)
        self.assertNotIn("tg://user", r.text)
        self.assertNotIn("report_filed", self.audit_types())
        self.s.chat.admins_fail = False
        self.assertIs((await self.report(msg=99)).kind, R.DONE)  # a failure did not burn the cooldown/claim

    async def test_no_reachable_admin_is_an_error_not_a_silent_success(self):
        self.s.chat.admins[A] = [adm(BOT, "GuardianBot", bot=True), adm(5, "Ghost", anonymous=True),
                                 adm(6, "NoRights", delete=False, restrict=False)]
        r = await self.report()
        self.assertIs(r.kind, R.ERROR)

    async def test_at_most_ten_admins_are_pinged_and_the_reporter_is_not(self):
        # the reporter is an admin with rights and sorts FIRST (lowest id): only the explicit exclusion keeps them out
        self.s.chat.admins[A] = [adm(9000 + i, f"A{i}") for i in range(15)] + [adm(USER, "Me")]
        r = await self.report()
        self.assertEqual(r.text.count("tg://user?id="), 10)
        self.assertNotIn(f"tg://user?id={USER}", r.text)

    async def test_works_in_dry_run_because_it_changes_nothing(self):
        await self.settings(dry_run=True)
        self.assertIs((await self.report()).kind, R.DONE)
        self.assertEqual(self.actions.calls, [])

    async def test_arabic_alias_with_reply(self):
        self.assertIs((await self.report("بلاغ سبام")).kind, R.DONE)


# ----------------------------------------------------------------------------- license / identity gates (all 4 commands)
class GateTests(InfoBase):
    async def test_public_commands_are_silent_when_the_license_is_off(self):
        off = gate(A, USER, allowed=False)
        for text in ("/id", "/admins", "/report"):
            r = await self.run_cmd(text, actor=USER, reply_to=OTHER, protection=off)
            self.assertIs(r.kind, R.LICENSE_OFF, text)
            self.assertEqual(r.text, "", text)
        self.assertEqual(self.s.chat.admin_calls, 0)  # nothing was looked up
        self.assertEqual(self.actions.calls, [])

    async def test_missing_or_foreign_gate_context_fails_closed(self):
        for prot in (None, gate(B, USER)):
            for text in ("/id", "/admins", "/report", "/info"):
                r = await self.run_cmd(text, actor=TG_ADMIN, reply_to=OTHER, protection=prot)
                self.assertIs(r.kind, R.LICENSE_OFF, text)

    async def test_service_accounts_and_invalid_actors_are_ignored(self):
        for actor in (777000, 1087968824, 136817688):
            for text in ("/id", "/admins", "/report"):
                r = await self.run_cmd(text, actor=actor, reply_to=OTHER, protection=gate(A, actor))
                self.assertIs(r.kind, R.DENIED, (actor, text))
                self.assertEqual(r.text, "")

    async def test_expired_license_after_a_sleep_blocks_public_commands(self):
        # the real gate decides `allowed`; here a pending/expired context is what it hands over
        from guardian.protection_gate import ProtectionContext
        ctx = ProtectionContext(A, "supergroup", False, "expired", USER, False)
        self.assertEqual((await self.run_cmd("/id", protection=ctx)).text, "")


# ----------------------------------------------------------------------------- through the real message handler
class HandlerFlowTests(InfoBase):
    """text -> `match_command` -> `execute` -> service -> reply, with duck-typed message fakes."""

    def message(self, text, *, sender=USER, reply_to=None, reply_mid=77, mid=500):
        msg = NS(text=text, message_id=mid, entities=None, chat=NS(id=A, type="supergroup", title="T"),
                 from_user=NS(id=sender, is_bot=False, language_code="ar", username=None), sender_chat=None,
                 reply_to_message=None, replies=[])
        if reply_to is not None:
            msg.reply_to_message = NS(message_id=reply_mid, from_user=NS(id=reply_to, is_bot=False), sender_chat=None)

        async def reply(text):
            msg.replies.append(text)
        msg.reply = reply
        return msg

    async def run_message(self, msg, protection="default"):
        bot = NS(me=lambda: None)

        async def me():
            return NS(id=BOT, username=BOT_NAME)
        bot.me = me
        parsed = await h.match_command(msg, bot)
        self.assertIsNotNone(parsed, msg.text)
        services = NS(settings=NS(default_language="ar"), moderation_commands=self.svc)
        prot = gate(A, msg.from_user.id) if protection == "default" else protection
        return await h.execute(msg, parsed, protection=prot, services=services)

    async def test_report_end_to_end_replies_with_mentions_and_message_link(self):
        msg = self.message("/report سبام", reply_to=OTHER)
        result = await self.run_message(msg)
        self.assertIs(result.kind, R.DONE)
        self.assertEqual(len(msg.replies), 1)
        self.assertIn(f'tg://user?id={TG_ADMIN}', msg.replies[0])
        self.assertIn("https://t.me/c/1/77", msg.replies[0])
        self.assertIn("سبام", msg.replies[0])

    async def test_id_and_admins_end_to_end_and_silent_when_throttled(self):
        msg = self.message("/id")
        await self.run_message(msg)
        self.assertIn(f"<code>{USER}</code>", msg.replies[0])
        again = self.message("/id", mid=501)
        result = await self.run_message(again)
        self.assertIs(result.kind, R.THROTTLED)
        self.assertEqual(again.replies, [])  # silent: no Telegram message at all
        adm_msg = self.message("المشرفين", sender=OTHER)
        await self.run_message(adm_msg)
        self.assertIn("Boss", adm_msg.replies[0])

    async def test_license_off_public_commands_send_no_message_at_all(self):
        for text, extra in (("/id", {}), ("/admins", {}), ("/report", {"reply_to": OTHER})):
            msg = self.message(text, **extra)
            result = await self.run_message(msg, protection=gate(A, USER, allowed=False))
            self.assertIs(result.kind, R.LICENSE_OFF)
            self.assertEqual(msg.replies, [], text)

    async def test_info_by_reply_from_a_moderator(self):
        self.member(OTHER)
        msg = self.message("معلومات", sender=TG_ADMIN, reply_to=OTHER)
        await self.run_message(msg)
        self.assertIn(f"<code>{OTHER}</code>", msg.replies[0])


# ----------------------------------------------------------------------------- adapter + handler pieces
class AdapterTests(unittest.IsolatedAsyncioTestCase):
    def tg_admin(self, uid, status="administrator", **kw):
        user = NS(id=uid, full_name=kw.pop("name", f"U{uid}"), first_name="F", username=kw.pop("username", None), is_bot=kw.pop("is_bot", False))
        return NS(status=NS(value=status) if status == "creator" else status, user=user, **kw)

    def test_conversion(self):
        owner = admin_info_from_telegram(self.tg_admin(1, "creator", is_anonymous=False, custom_title="Chief"))
        self.assertTrue(owner.is_creator and owner.can_moderate and owner.title == "Chief")
        a = admin_info_from_telegram(self.tg_admin(2, can_delete_messages=True, can_restrict_members=None, is_anonymous=True))
        self.assertTrue(a.can_delete_messages and not a.can_restrict_members and a.is_anonymous and a.can_moderate)
        self.assertFalse(admin_info_from_telegram(self.tg_admin(3, can_delete_messages=None, can_restrict_members=None)).can_moderate)
        self.assertIsNone(admin_info_from_telegram(self.tg_admin(4, "member")))
        self.assertIsNone(admin_info_from_telegram(NS(status="administrator", user=NS(id=-5))))
        self.assertIsNone(admin_info_from_telegram(NS(status="administrator", user=None)))

    async def test_list_admins_caches_and_fails_closed(self):
        calls = []

        class Bot:
            fail = False

            async def get_chat_administrators(self, chat_id):
                calls.append(chat_id)
                if self.fail:
                    raise RuntimeError("secret detail")
                return [NS(status="administrator", user=NS(id=9, full_name="N", username="u", is_bot=False),
                           can_delete_messages=True, can_restrict_members=True, is_anonymous=False),
                        NS(status="member", user=NS(id=10))]

        now = [0.0]
        bot = Bot()
        info = AiogramChatInfo(bot, ttl=30, clock=lambda: now[0])
        self.assertEqual([a.user_id for a in await info.list_admins(-1001)], [9])
        await info.list_admins(-1001)
        self.assertEqual(calls, [-1001])  # cached
        now[0] = 31
        await info.list_admins(-1001)
        self.assertEqual(len(calls), 2)
        bot.fail = True
        now[0] = 100
        with self.assertRaises(TelegramLookupFailed) as cm:
            await info.list_admins(-1001)
        self.assertNotIn("secret", str(cm.exception))

    async def test_list_admins_one_bounded_retry_on_retry_after(self):
        class Boom(Exception):
            retry_after = 1

        seen = []

        class Bot:
            async def get_chat_administrators(self, chat_id):
                seen.append(1)
                if len(seen) == 1:
                    raise Boom()
                return []

        async def nosleep(_):
            return None

        info = AiogramChatInfo(Bot(), sleep=nosleep)
        self.assertEqual(await info.list_admins(-1001), [])
        self.assertEqual(len(seen), 2)

    def test_reply_info_carries_message_id(self):
        replied = NS(message_id=42, from_user=NS(id=5), sender_chat=None)
        self.assertEqual(h.reply_info(NS(reply_to_message=replied)), ReplyInfo(5, False, 42))
        chan = NS(message_id=43, from_user=None, sender_chat=NS(id=-1))
        self.assertEqual(h.reply_info(NS(reply_to_message=chan)), ReplyInfo(None, True, 43))
        self.assertIsNone(h.reply_info(NS(reply_to_message=NS(message_id=True, from_user=NS(id=5), sender_chat=None))).message_id)

    def test_clean_display(self):
        self.assertEqual(clean_display("a\u202eb\u200bc\x00d  e"), "abcd e")
        self.assertEqual(len(clean_display("x" * 100)), 40)
        self.assertEqual(clean_display(None), "")


if __name__ == "__main__":
    unittest.main()
