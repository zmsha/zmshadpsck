"""Part 6.8b: `/backup` (owner, private chat): parser, service (preview + single-use code), the verify-only delivery path.
PostgreSQL / aiogram / Telegram are NOT exercised (fakes only)."""
from __future__ import annotations

import asyncio
import dataclasses
import json
import re
import unittest
from datetime import timedelta
from pathlib import Path

from backup_helpers import FIXED_NOW, FakeReader
from stack import A, B, BACKUP, NOW, OWNER, OWNER_GROUP, STRANGER, Stack

from guardian import i18n
from guardian.audit import BACKUP_DELIVERED, BACKUP_FAILED, BACKUP_REQUESTED, InMemorySecurityAudit
from guardian.backup import service as svc
from guardian.backup.collector import BackupCollector
from guardian.backup.command import BackupCommandService, parse_backup_command
from guardian.backup.delivery import BackupDelivery
from guardian.backup.format import BackupError, MAX_BACKUP_BYTES
from guardian.export.models import PrivateChatUnavailable
from guardian.idempotency import InMemoryIdempotency
from guardian.owner_templates.pending import PendingActions
from guardian.permissions import OWNER_ONLY, Permission

SRC = Path(__file__).resolve().parent.parent / "src" / "guardian"
SECRET = "S3cr3t-Token-Value-12345"


class Transport:
    def __init__(self, exc=None, delay=0.0):
        self.sent, self.exc, self.delay = [], exc, delay

    async def send_document(self, chat_id, name, data, caption=None):
        if self.delay:
            await asyncio.sleep(self.delay)
        if self.exc:
            raise self.exc
        self.sent.append((chat_id, name, data, caption))


class BrokenClaims:
    async def claim(self, key, now=None):
        raise RuntimeError("down")


class Clock:
    def __init__(self):
        self.now = NOW

    def __call__(self):
        return self.now


class Base(unittest.IsolatedAsyncioTestCase):
    def build(self, *, reader=None, transport=None, secrets=(), delivery_claims=None, cooldown=300, collector=None):
        self.stack = Stack()
        self.clock = Clock()
        self.audit = self.stack.audit
        self.claims = InMemoryIdempotency()
        self.pending = PendingActions(clock=self.clock)
        self.transport = transport or Transport()
        self.collector = collector or BackupCollector(reader or FakeReader(), app_version="t", schema_version=10,
                                                      schema_name="0010_report_schedule", secrets=secrets, clock=lambda: FIXED_NOW)
        self.delivery = BackupDelivery(self.transport, claims=delivery_claims or self.claims, audit=self.audit, secrets=secrets,
                                       forbidden_chat_ids=(OWNER_GROUP,), clock=self.clock)
        self.service = svc.BackupService(collector=self.collector, delivery=self.delivery, pending=self.pending,
                                         permissions=self.stack.perm, claims=self.claims, audit=self.audit, clock=self.clock,
                                         cooldown=cooldown)
        self.cmd = BackupCommandService(self.service)
        return self

    async def go(self, text, user=OWNER, chat=None, chat_type="private", mid=1):
        parsed = parse_backup_command(text, "GuardBot")
        assert parsed is not None, text
        return await self.cmd.run(parsed, chat_id=user if chat is None else chat, chat_type=chat_type, user_id=user, message_id=mid)

    async def preview_code(self):
        out = await self.service.prepare(OWNER)
        return out.code

    def kinds(self):
        return [e.event_type for e in self.audit.events]


# ------------------------------------------------------------------------------------------------ parser
class ParserTests(unittest.TestCase):
    def test_forms(self):
        p = lambda s, b="GuardBot": parse_backup_command(s, b)  # noqa: E731
        self.assertEqual(p("/backup").action, "preview")
        self.assertEqual(p("/BACKUP@guardbot").action, "preview")
        self.assertEqual(p("نسخة احتياطية").action, "preview")
        self.assertEqual(p("نسخة احتياطي").action, "preview")
        c = p("/backup confirm ab12cd")
        self.assertEqual((c.action, c.code), ("confirm", "AB12CD"))
        c = p("تأكيد نسخة ab12cd")
        self.assertEqual((c.action, c.code), ("confirm", "AB12CD"))
        for bad in ("/backup now", "/backup confirm", "/backup confirm a", "/backup confirm abc def", "/backup confirm ab-12!"):
            self.assertEqual(p(bad).action, "usage", bad)

    def test_not_ours(self):
        p = lambda s, b="GuardBot": parse_backup_command(s, b)  # noqa: E731
        for text in ("/backup@OtherBot", "/backups", "/export", "hello", "", None, 5, "x" * 101, "/backup " + "a" * 200, "نسخة", "تأكيد نسخة", "نسخة احتياطية الآن"):
            self.assertIsNone(p(text), text)
        self.assertIsNone(p("/backup@GuardBot", None))


# ------------------------------------------------------------------------------------------------ service / command
class ServiceTests(Base):
    async def test_owner_flow_sends_a_verified_file_to_the_owner_only(self):
        self.build()
        r = await self.go("/backup")
        self.assertEqual(r.status, "preview")
        code = re.search(r"confirm ([A-Z0-9]+)", r.text).group(1)
        r = await self.go(f"/backup confirm {code}", mid=2)
        self.assertEqual(r.status, "sent")
        (chat, name, data, caption), = self.transport.sent
        self.assertEqual(chat, OWNER)
        self.assertNotIn(chat, (OWNER_GROUP, A, B))
        self.assertTrue(re.fullmatch(r"guardian-backup-\d{8}-\d{6}-utc\.json", name))
        self.assertIn("manifest", json.loads(data))
        self.assertEqual(self.kinds(), [BACKUP_REQUESTED, BACKUP_DELIVERED])

    async def test_everyone_else_gets_silence(self):
        self.build()
        code = await self.preview_code()
        for who in (BACKUP, STRANGER, 900_003):
            for text in ("/backup", f"/backup confirm {code}", "/backup bogus", "نسخة احتياطية"):
                self.assertIsNone(await self.go(text, user=who), (who, text))
        self.assertEqual(self.transport.sent, [])
        self.assertEqual(len(self.pending), 1, "a stranger cannot consume the owner's code")

    async def test_private_chat_only(self):
        self.build()
        code = await self.preview_code()
        for kw in (dict(chat=A, chat_type="supergroup"), dict(chat=OWNER_GROUP, chat_type="supergroup"), dict(chat=OWNER, chat_type="group"),
                   dict(chat=OWNER + 1, chat_type="private")):
            for text in ("/backup", f"/backup confirm {code}", "/backup x"):
                self.assertIsNone(await self.go(text, **kw), (kw, text))
        self.assertEqual(self.transport.sent, [])

    async def test_code_is_single_use_wrong_code_consumes_nothing(self):
        self.build()
        code = await self.preview_code()
        r = await self.go("/backup confirm ZZZZZZ", mid=2)
        self.assertEqual(r.status, "unknown_code")
        self.assertEqual(self.transport.sent, [])
        self.assertEqual((await self.go(f"/backup confirm {code}", mid=3)).status, "sent")
        self.clock.now += timedelta(minutes=10)
        r = await self.go(f"/backup confirm {code}", mid=4)
        self.assertEqual(r.status, "unknown_code")
        self.assertEqual(len(self.transport.sent), 1)

    async def test_code_expires_and_is_bound_to_kind_and_owner(self):
        self.build()
        code = await self.preview_code()
        self.clock.now += timedelta(hours=2)
        self.assertEqual((await self.go(f"/backup confirm {code}", mid=2)).status, "unknown_code")
        other = self.pending.create(OWNER, "template_apply", {"x": 1})
        self.assertEqual((await self.go(f"/backup confirm {other}", mid=3)).status, "unknown_code")
        foreign = self.pending.create(BACKUP, "backup", {})
        self.assertEqual((await self.go(f"/backup confirm {foreign}", mid=4)).status, "unknown_code")
        self.assertEqual(self.transport.sent, [])

    async def test_redelivered_update_is_silent_and_sends_once(self):
        self.build()
        code = await self.preview_code()
        self.assertEqual((await self.go(f"/backup confirm {code}", mid=7)).status, "sent")
        self.assertIsNone(await self.go(f"/backup confirm {code}", mid=7))
        self.assertEqual(len(self.transport.sent), 1)

    async def test_cooldown_does_not_consume_the_code(self):
        self.build()
        c1 = await self.preview_code()
        self.assertEqual((await self.go(f"/backup confirm {c1}", mid=1)).status, "sent")
        c2 = await self.preview_code()
        r = await self.go(f"/backup confirm {c2}", mid=2)
        self.assertEqual(r.status, "cooldown")
        self.assertEqual(len(self.pending), 1)
        self.clock.now += timedelta(seconds=301)
        self.assertEqual((await self.go(f"/backup confirm {c2}", mid=3)).status, "sent")
        self.assertEqual(len(self.transport.sent), 2)

    async def test_one_at_a_time(self):
        self.build(transport=Transport(delay=0.05))
        c1, c2 = await self.preview_code(), await self.preview_code()
        first = asyncio.ensure_future(self.go(f"/backup confirm {c1}", mid=1))
        await asyncio.sleep(0.01)
        r = await self.go(f"/backup confirm {c2}", mid=2)
        self.assertEqual(r.status, "busy")
        self.assertEqual((await first).status, "sent")
        self.assertEqual(len(self.pending), 1)

    async def test_collector_failures_are_reported_and_audited_without_content(self):
        class Boom:
            def __init__(self, exc):
                self.exc = exc

            async def collect(self):
                raise self.exc

        cases = ((BackupError("secret_found", "group_settings"), "secret_found"), (BackupError("too_large"), "too_large"),
                 (BackupError("read_failed"), "failed"), (RuntimeError(f"leak {SECRET}"), "failed"))
        for i, (exc, status) in enumerate(cases):
            self.build(collector=Boom(exc))
            code = await self.preview_code()
            r = await self.go(f"/backup confirm {code}", mid=10 + i)
            self.assertEqual(r.status, status, exc)
            self.assertEqual(self.transport.sent, [])
            failed = [e for e in self.audit.events if e.event_type == BACKUP_FAILED]
            self.assertEqual(len(failed), 1)
            self.assertNotIn(SECRET, repr(failed[0]))

    async def test_a_secret_in_the_data_refuses_the_whole_backup(self):
        data = {k: [dict(r) for r in v] for k, v in FakeReader().data.items()}
        data["group_settings"][0]["settings"] = {"note": f"token {SECRET}"}
        self.build(reader=FakeReader(data), secrets=(SECRET,))
        code = await self.preview_code()
        r = await self.go(f"/backup confirm {code}", mid=2)
        self.assertEqual(r.status, "secret_found")
        self.assertEqual(self.transport.sent, [])
        self.assertNotIn(SECRET, r.text + repr(self.audit.events))

    async def test_unavailable_when_not_wired(self):
        self.build()
        self.service._delivery = None
        self.assertEqual((await self.go("/backup")).status, "unavailable")
        self.assertIsNone(await self.go("/backup", user=STRANGER))

    async def test_claim_store_down_fails_closed(self):
        self.build()
        self.service._claims = BrokenClaims()
        code = await self.preview_code()
        self.assertEqual((await self.go(f"/backup confirm {code}", mid=2)).status, "unavailable")
        self.assertEqual(self.transport.sent, [])

    async def test_bad_message_id_fails_closed(self):
        self.build()
        code = await self.preview_code()
        for mid in (None, 0, -1, True, "5"):
            self.assertEqual((await self.service.confirm(OWNER, code, mid)).status, "unavailable")
        self.assertEqual(self.transport.sent, [])

    async def test_audit_events_carry_no_file_content(self):
        self.build()
        code = await self.preview_code()
        await self.go(f"/backup confirm {code}", mid=2)
        for e in self.audit.events:
            self.assertLess(len(e.detail or ""), 80)
            self.assertNotIn("مجموعة الاختبار", repr(e))
            self.assertNotIn(code, repr(e))

    async def test_service_exception_becomes_a_failed_reply(self):
        self.build()

        async def boom(*a, **k):
            raise RuntimeError("x")

        self.service.prepare = boom
        self.assertEqual((await self.go("/backup")).status, "failed")


# ------------------------------------------------------------------------------------------------ delivery
class DeliveryTests(Base):
    async def result(self, **kw):
        self.build(**kw)
        return await self.collector.collect()

    async def test_destination_is_the_requester_and_never_the_owner_group(self):
        b = await self.result()
        self.assertEqual((await self.delivery.deliver(OWNER_GROUP, b, key=1)).code, "invalid")
        for bad in (0, -5, None, True, "1", A):
            self.assertEqual((await self.delivery.deliver(bad, b, key=2)).code, "invalid", bad)
        self.assertEqual(self.transport.sent, [])
        self.assertEqual((await self.delivery.deliver(OWNER, b, key=3)).code, "sent")
        self.assertEqual(self.transport.sent[0][0], OWNER)

    async def test_forbidden_ids_are_enforced_even_for_a_positive_id(self):
        b = await self.result()
        strict = BackupDelivery(self.transport, claims=InMemoryIdempotency(), forbidden_chat_ids=(OWNER,))
        self.assertEqual((await strict.deliver(OWNER, b, key=1)).code, "invalid")
        self.assertEqual(self.transport.sent, [])

    async def test_bytes_arrive_exactly_and_hashes_survive(self):
        b = await self.result()
        await self.delivery.deliver(OWNER, b, key=1)
        sent = self.transport.sent[0][2]
        self.assertEqual(sent, b.data)
        self.assertGreaterEqual(len(re.findall(r"[0-9a-f]{64}", sent.decode())), 11)
        self.assertNotIn("REDACTED", sent.decode())

    async def test_name_pattern(self):
        b = await self.result()
        for name in ("backup.json", "../guardian-backup-20261101-093015-utc.json", "guardian-backup-20261101-093015-utc.json\n", "x.txt", ""):
            r = await self.delivery.deliver(OWNER, dataclasses.replace(b, name=name), key=name or "e")
            self.assertEqual(r.code, "rejected", name)
        self.assertEqual(self.transport.sent, [])

    async def test_size_cap_10mb(self):
        b = await self.result()
        big = dataclasses.replace(b, data=b.data + b" " * MAX_BACKUP_BYTES)
        self.assertEqual((await self.delivery.deliver(OWNER, big, key=1)).code, "too_large")
        self.assertEqual(self.transport.sent, [])

    async def test_secret_refuses_never_cleans(self):
        b = await self.result(secrets=(SECRET,))
        tainted = dataclasses.replace(b, data=b.data.replace(b'"manifest"', f'"x":"{SECRET}","manifest"'.encode(), 1))
        self.assertEqual((await self.delivery.deliver(OWNER, tainted, key=1)).code, "rejected")
        pem = dataclasses.replace(b, data=b.data.replace(b'"manifest"', b'"x":"-----BEGIN PRIVATE KEY-----","manifest"', 1))
        self.assertEqual((await self.delivery.deliver(OWNER, pem, key=2)).code, "rejected")
        self.assertEqual(self.transport.sent, [])

    async def test_corrupt_is_refused(self):
        b = await self.result()
        cases = (b.data.replace(b"Second group", b"Second grouq"), b"not json", b"\xff\xfe", b.data[:-5])
        for i, data in enumerate(cases):
            r = await self.delivery.deliver(OWNER, dataclasses.replace(b, data=data), key=i)
            self.assertEqual(r.code, "corrupt", i)
        self.assertEqual(self.transport.sent, [])

    async def test_duplicate_claim_sends_once(self):
        b = await self.result()
        self.assertEqual((await self.delivery.deliver(OWNER, b, key=1)).code, "sent")
        self.assertEqual((await self.delivery.deliver(OWNER, b, key=1)).code, "duplicate")
        self.assertEqual(len(self.transport.sent), 1)

    async def test_transport_failures_map_to_codes(self):
        for exc, code in ((PrivateChatUnavailable(), "private_not_started"), (RuntimeError(f"url with {SECRET}"), "failed")):
            b = await self.result(transport=Transport(exc))
            self.assertEqual((await self.delivery.deliver(OWNER, b, key=1)).code, code)
            self.assertNotIn(SECRET, repr(self.audit.events))
        b = await self.result(transport=Transport(delay=1))
        self.delivery._timeout = 0.01
        self.assertEqual((await self.delivery.deliver(OWNER, b, key=1)).code, "failed")

    async def test_claim_failure_fails_closed(self):
        b = await self.result(delivery_claims=BrokenClaims())
        self.assertEqual((await self.delivery.deliver(OWNER, b, key=1)).code, "failed")
        self.assertEqual(self.transport.sent, [])

    async def test_audit_is_content_free(self):
        b = await self.result()
        await self.delivery.deliver(OWNER, b, key=1)
        (e,) = self.audit.events
        self.assertEqual(e.event_type, BACKUP_DELIVERED)
        self.assertRegex(e.detail, r"^bytes=\d+ rows=\d+ code=sent$")

    async def test_not_a_backup_result(self):
        self.build()
        for junk in (None, b"x", "x", object()):
            self.assertEqual((await self.delivery.deliver(OWNER, junk, key=1)).code, "invalid")


# ------------------------------------------------------------------------------------------------ structure / i18n / wiring
class StructureTests(unittest.TestCase):
    def test_permission_is_owner_only(self):
        self.assertIn(Permission.BACKUP, OWNER_ONLY)

    def test_i18n_parity_and_placeholders(self):
        keys = {k for k in i18n.MESSAGES["ar"] if k.startswith("bk_")}
        self.assertEqual(len(keys), 15)
        self.assertEqual(keys, {k for k in i18n.MESSAGES["en"] if k.startswith("bk_")})
        for k in keys:
            fields = lambda lang: set(re.findall(r"{(\w+)}", i18n.MESSAGES[lang][k]))  # noqa: E731
            self.assertEqual(fields("ar"), fields("en"), k)

    def test_replies_render_in_both_languages(self):
        for lang in ("ar", "en"):
            for status in ("unknown_code", "busy", "unavailable", "secret_found", "too_large", "private_not_started", "rejected",
                           "corrupt", "duplicate", "failed"):
                self.assertTrue(BackupCommandService._reply(svc.BackupOutcome(status), lang).text)
            self.assertIn("ABC123", BackupCommandService._reply(svc.BackupOutcome("preview", code="ABC123", minutes=10), lang).text)
            self.assertTrue(BackupCommandService._reply(svc.BackupOutcome("sent", rows=5, size=4096, flags=("t",)), lang).text)
            self.assertIn("30", BackupCommandService._reply(svc.BackupOutcome("cooldown", wait_seconds=30), lang).text)

    def test_wiring(self):
        app = (SRC / "app.py").read_text(encoding="utf-8")
        self.assertIn("forbidden_chat_ids=(settings.owner_group_id,)", app)
        self.assertIn("owner_backup=BackupCommandService(", app)
        self.assertRegex((SRC / "services.py").read_text(encoding="utf-8"), r"owner_backup: Any = None")

    def test_no_chat_parameter_and_no_group_destination(self):
        text = (SRC / "backup" / "delivery.py").read_text(encoding="utf-8")
        self.assertNotRegex(text, r"def deliver\([^)]*chat_id")
        self.assertNotIn("owner_group", text)
        self.assertNotIn("ExportDelivery", text.split('"""', 2)[2])

    def test_not_in_the_telegram_menu_and_no_new_migration(self):
        menu = (SRC / "bot" / "commands_menu.py").read_text(encoding="utf-8")
        self.assertNotIn("backup", menu)
        from guardian.db.migrations import discover
        self.assertEqual([v for v, _ in discover()][-1], "0013_member_activity_stats")


if __name__ == "__main__":
    unittest.main()
