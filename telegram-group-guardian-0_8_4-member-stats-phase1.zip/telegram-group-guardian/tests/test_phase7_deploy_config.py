"""Part 7.1: deployment files must agree with config.py and carry no secret (text-only checks, no PyYAML)."""
import re
import unittest
from pathlib import Path

from guardian.config import WEBHOOK_PATH, load_settings

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src" / "guardian"

# Variables provided by Render itself (never set by the user): allowed to be read by config.py.
PLATFORM_VARS = {"RENDER_EXTERNAL_URL"}
# Variables that hold a secret: must never carry a value in render.yaml.
SECRET_VARS = {"BOT_TOKEN", "DATABASE_URL", "WEBHOOK_SECRET", "OWNER_TELEGRAM_ID", "GEMINI_API_KEY_1", "GEMINI_API_KEY_2",
               "GEMINI_API_KEY_3", "GEMINI_API_KEY_4", "GEMINI_API_KEY_5"}
REQUIRED_VARS = {"BOT_TOKEN", "DATABASE_URL", "OWNER_TELEGRAM_ID", "WEBHOOK_SECRET"}


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def config_vars() -> set[str]:
    text = _read(SRC / "config.py")
    return set(re.findall(r'(?:get|required)\("([A-Z][A-Z0-9_]+)"\)', text))


def example_vars() -> dict[str, str | None]:
    """name -> value for active lines, name -> None for commented-out optional lines."""
    found: dict[str, str | None] = {}
    for line in _read(ROOT / ".env.example").splitlines():
        match = re.match(r"^\s*(#\s*)?([A-Z][A-Z0-9_]+)=(.*)$", line)
        if match:
            commented, name, rest = match.groups()
            found[name] = None if commented else rest.split("  #")[0].strip()
    return found


def render_blocks() -> list[dict[str, str]]:
    """Each `- key: X` entry under envVars as {key, value?, sync?}."""
    text = _read(ROOT / "render.yaml")
    blocks, current = [], None
    in_env = False
    for line in text.splitlines():
        if line.strip().startswith("#") or not line.strip():
            continue
        if re.match(r"^\s*envVars:\s*$", line):
            in_env = True
            continue
        if not in_env:
            continue
        key = re.match(r"^\s*-\s*key:\s*(\S+)\s*$", line)
        if key:
            current = {"key": key.group(1)}
            blocks.append(current)
            continue
        other = re.match(r"^\s+(value|sync):\s*(.+?)\s*$", line)
        if other and current is not None:
            current[other.group(1)] = other.group(2).strip('"')
    return blocks


class EnvExampleMatchesConfig(unittest.TestCase):
    def test_every_variable_config_reads_is_in_env_example(self):
        missing = config_vars() - PLATFORM_VARS - set(example_vars())
        self.assertEqual(missing, set(), "config.py reads variables missing from .env.example")

    def test_env_example_has_no_unknown_variable(self):
        unknown = set(example_vars()) - config_vars()
        self.assertEqual(unknown, set(), ".env.example lists variables config.py never reads")

    def test_required_variables_are_active_lines_and_optional_ones_are_present(self):
        found = example_vars()
        for name in REQUIRED_VARS:
            with self.subTest(name=name):
                self.assertIsNotNone(found.get(name), f"{name} must be an active (uncommented) line")

    def test_render_provided_variable_is_only_mentioned_not_assigned(self):
        text = _read(ROOT / ".env.example")
        self.assertIn("RENDER_EXTERNAL_URL", text)
        self.assertNotIn("\nRENDER_EXTERNAL_URL=", text)

    def test_values_are_placeholders_and_the_file_loads_as_valid_settings(self):
        env = {k: v for k, v in example_vars().items() if v is not None}
        self.assertIn("REPLACE", env["BOT_TOKEN"])
        settings = load_settings(env)  # the shipped example must itself validate
        self.assertEqual(settings.webhook_register_on_startup, False)
        self.assertEqual(settings.port, 10000)

    def test_the_commented_optionals_also_validate_when_enabled(self):
        env = {}
        for line in _read(ROOT / ".env.example").splitlines():
            match = re.match(r"^\s*#?\s*([A-Z][A-Z0-9_]+)=([^\s#]*)", line)
            if match:
                env[match.group(1)] = match.group(2)
        settings = load_settings(env)
        self.assertEqual(settings.owner_group_id, -1001234567890)
        self.assertEqual(settings.webhook_base_url, "https://your-service.onrender.com")
        self.assertEqual(settings.webhook_url, "https://your-service.onrender.com" + WEBHOOK_PATH)
        self.assertEqual(settings.audit_retention_days, 180)

    def test_example_is_a_safe_default_for_a_first_deploy(self):
        found = example_vars()
        self.assertEqual(found["WEBHOOK_REGISTER_ON_STARTUP"], "false")
        self.assertEqual(found["RUN_MIGRATIONS_ON_STARTUP"], "true")


class RenderYamlChecks(unittest.TestCase):
    def setUp(self):
        self.text = _read(ROOT / "render.yaml")
        self.blocks = render_blocks()
        self.keys = {b["key"] for b in self.blocks}

    def test_every_declared_variable_is_one_config_reads(self):
        unknown = self.keys - config_vars() - {"PYTHON_VERSION"}
        self.assertEqual(unknown, set())

    def test_every_required_variable_is_declared(self):
        self.assertTrue(REQUIRED_VARS <= self.keys, REQUIRED_VARS - self.keys)

    def test_secrets_are_never_given_a_value_and_are_not_synced(self):
        by_key = {b["key"]: b for b in self.blocks}
        for name in SECRET_VARS:
            with self.subTest(name=name):
                self.assertEqual(by_key[name].get("sync"), "false")
                self.assertNotIn("value", by_key[name])

    def test_only_three_non_secret_values_are_pinned(self):
        pinned = {b["key"]: b["value"] for b in self.blocks if "value" in b}
        self.assertEqual(pinned, {"PYTHON_VERSION": "3.12.7", "WEBHOOK_REGISTER_ON_STARTUP": "false",
                                  "ENVIRONMENT": "production"})

    def test_no_secret_shaped_text_anywhere(self):
        self.assertIsNone(re.search(r"\d{5,}:[A-Za-z0-9_-]{20,}", self.text))
        self.assertIsNone(re.search(r"[a-z]+://[^\s:/@]+:[^\s@]+@", self.text))
        self.assertNotIn("-----BEGIN", self.text)

    def test_service_shape_for_render_free(self):
        self.assertRegex(self.text, r"(?m)^\s*plan:\s*free\s*$")
        self.assertRegex(self.text, r"(?m)^\s*healthCheckPath:\s*/health\s*$")
        self.assertRegex(self.text, r"(?m)^\s*runtime:\s*python\s*$")
        self.assertRegex(self.text, r"(?m)^\s*(?:-\s*)?type:\s*web\s*$")

    def test_start_command_binds_render_port_with_the_app_factory(self):
        match = re.search(r"(?m)^\s*startCommand:\s*(.+)$", self.text)
        self.assertIsNotNone(match)
        command = match.group(1)
        self.assertIn("guardian.app:create_app", command)
        self.assertIn("--factory", command)
        self.assertIn("--host 0.0.0.0", command)
        self.assertIn("--port $PORT", command)
        self.assertNotIn("--reload", command)
        self.assertNotIn("--workers", command)  # one process: in-memory state and one webhook consumer

    def test_build_command_installs_only_the_runtime_requirements(self):
        self.assertRegex(self.text, r"(?m)^\s*buildCommand:\s*pip install -r requirements\.txt\s*$")

    def test_the_header_states_the_free_plan_limits_and_no_keep_alive(self):
        header = "\n".join(line for line in self.text.splitlines() if line.startswith("#"))
        self.assertIn("spins down", header)
        self.assertIn("No keep-alive", header)

    def test_health_check_path_matches_the_route(self):
        app_text = _read(SRC / "app.py")
        self.assertIn('"/health"', app_text)
        self.assertEqual(WEBHOOK_PATH, "/telegram/webhook")


class NoSecretInStartupOrLogs(unittest.TestCase):
    SECRET_ATTRS = ("bot_token", "webhook_secret", "database_url", "secret_values", "password")

    def test_no_log_call_formats_a_secret_attribute(self):
        pattern = re.compile(r"\blog(?:ger)?\.(?:debug|info|warning|error|exception|critical)\(")
        offenders = []
        for path in SRC.rglob("*.py"):
            lines = _read(path).splitlines()
            for number, line in enumerate(lines, 1):
                if pattern.search(line):
                    window = " ".join(lines[number - 1:number + 2]).lower()
                    if any(attr in window for attr in self.SECRET_ATTRS):
                        offenders.append(f"{path.relative_to(ROOT)}:{number}")
        self.assertEqual(offenders, [])

    def test_settings_repr_hides_every_secret(self):
        env = {k: v for k, v in example_vars().items() if v is not None}
        settings = load_settings(env)
        for text in (repr(settings), str(settings)):
            for secret in settings.secret_values():
                self.assertNotIn(secret, text)

    def test_config_errors_name_the_variable_never_the_value(self):
        from guardian.errors import ConfigError

        env = {k: v for k, v in example_vars().items() if v is not None}
        env["BOT_TOKEN"] = "123456789:SECRET_VALUE_THAT_MUST_NOT_LEAK_abcdef"
        env["WEBHOOK_SECRET"] = "bad secret with spaces and SECRETVALUE"
        with self.assertRaises(ConfigError) as caught:
            load_settings(env)
        message = str(caught.exception)
        self.assertIn("WEBHOOK_SECRET", message)
        self.assertNotIn("SECRETVALUE", message)
        self.assertNotIn("SECRET_VALUE_THAT_MUST_NOT_LEAK", message)

    def test_logging_is_configured_before_anything_can_log_in_create_app(self):
        text = _read(SRC / "app.py")
        self.assertLess(text.index("configure_logging(settings.log_level, settings.secret_values())"),
                        text.index("owner_hub = ("))


class WebhookModeOnly(unittest.TestCase):
    def test_no_polling_anywhere_in_the_source(self):
        for path in SRC.rglob("*.py"):
            text = _read(path)
            for forbidden in ("start_polling", "run_polling", "getUpdates", "get_updates"):
                with self.subTest(path=path.name, forbidden=forbidden):
                    self.assertNotIn(forbidden, text)

    def test_the_webhook_is_registered_with_the_secret_token_and_without_dropping_updates(self):
        text = _read(SRC / "app.py")
        self.assertIn("secret_token=settings.webhook_secret", text)
        self.assertIn("drop_pending_updates=False", text)


if __name__ == "__main__":
    unittest.main()
