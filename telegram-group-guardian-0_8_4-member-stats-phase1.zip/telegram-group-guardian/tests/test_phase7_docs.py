"""Part 7.3: the deployment documents exist, match the code, and keep the honesty rules.

Text-only checks (no network, no PyYAML). They do NOT prove that Render/PostgreSQL/Telegram behave as described:
the facts about Render and the external databases were read from their pages on 2026-11-04 and may change.
"""
from __future__ import annotations

import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEPLOY = (ROOT / "docs" / "DEPLOY_RENDER.md").read_text(encoding="utf-8")
LOCAL = (ROOT / "docs" / "LOCAL_VERIFY.md").read_text(encoding="utf-8")
CONFIG = (ROOT / "src" / "guardian" / "config.py").read_text(encoding="utf-8")
ENV_EXAMPLE = (ROOT / ".env.example").read_text(encoding="utf-8")
RENDER_YAML = (ROOT / "render.yaml").read_text(encoding="utf-8")


def env_names_in_example() -> set[str]:
    return set(re.findall(r"(?m)^#?\s*([A-Z][A-Z0-9_]{2,})=", ENV_EXAMPLE))


class DeployGuideTests(unittest.TestCase):
    def test_every_variable_in_env_example_is_in_the_deploy_table(self):
        for name in sorted(env_names_in_example()):
            with self.subTest(name=name):
                self.assertIn(f"`{name}`", DEPLOY)

    def test_required_variables_are_marked_required_and_secrets_are_not_in_render_yaml(self):
        for name in ("BOT_TOKEN", "DATABASE_URL", "OWNER_TELEGRAM_ID", "WEBHOOK_SECRET"):
            row = next(line for line in DEPLOY.splitlines() if line.startswith(f"| `{name}`"))
            self.assertIn("| نعم |", row, name)
            self.assertRegex(RENDER_YAML, rf"key: {name}\s+sync: false")

    def test_the_build_and_start_commands_match_render_yaml(self):
        build = re.search(r"buildCommand:\s*(.+)", RENDER_YAML).group(1).strip()
        start = re.search(r"startCommand:\s*(.+)", RENDER_YAML).group(1).strip()
        self.assertIn(build, DEPLOY)
        self.assertIn(start, DEPLOY)
        self.assertIn("/health", DEPLOY)

    def test_the_webhook_path_and_header_are_the_real_ones(self):
        path = re.search(r'WEBHOOK_PATH = "([^"]+)"', CONFIG).group(1)
        self.assertIn(path, DEPLOY)
        self.assertIn("X-Telegram-Bot-Api-Secret-Token", DEPLOY)
        self.assertIn("X-Telegram-Bot-Api-Secret-Token", LOCAL)
        self.assertIn(path, LOCAL)

    def test_the_free_database_expiry_is_stated_and_not_recommended(self):
        self.assertIn("30 يومًا", DEPLOY)
        self.assertIn("نسخ احتياطية", DEPLOY)
        self.assertRegex(DEPLOY, r"لا تصلح للاستمرار")

    def test_the_free_plan_limits_section_is_explicit(self):
        section = DEPLOY.split("## 10. حدود Render Free", 1)[1].split("## 11.", 1)[0]
        for needle in ("15 دقيقة", "نحو دقيقة", "لا ضمان لحماية لحظية", "بلا قرص دائم", "الترقية لاحقًا دون تغيير التصميم"):
            with self.subTest(needle=needle):
                self.assertIn(needle, section)

    def test_the_guide_says_nothing_was_deployed_and_dates_its_facts(self):
        self.assertIn("لم يُنشَر المشروع فعليًا", DEPLOY)
        self.assertIn("4 نوفمبر 2026", DEPLOY)
        for url in ("https://render.com/docs/free", "https://neon.com/faqs/free-plan-limits-and-quotas", "https://supabase.com/pricing.md"):
            with self.subTest(url=url):
                self.assertIn(url, DEPLOY)

    def test_no_real_looking_secret_in_the_documents(self):
        token = re.compile(r"\b\d{8,10}:[A-Za-z0-9_-]{35}\b")
        url_pw = re.compile(r"postgres(?:ql)?://[^:\s/]+:(?!pass\b|password\b|كلمة_المرور)[^@\s]+@")
        for name, text in (("DEPLOY_RENDER.md", DEPLOY), ("LOCAL_VERIFY.md", LOCAL)):
            with self.subTest(doc=name):
                self.assertIsNone(token.search(text))
                self.assertIsNone(url_pw.search(text))

    def test_the_pooled_database_url_is_warned_against(self):
        self.assertIn("المجمّع", DEPLOY)
        self.assertIn("-pooler", DEPLOY)
        self.assertIn("advisory", DEPLOY)


class LocalVerifyTests(unittest.TestCase):
    def test_it_lists_the_commands_the_plan_requires(self):
        for needle in (
            "pip install -r requirements.txt -r requirements-dev.txt",
            "unittest discover -s tests",
            "uvicorn --app-dir src guardian.app:create_app --factory",
            "curl -i http://localhost:10000/health",
            "-m guardian migrate",
            "-m guardian check-config",
        ):
            with self.subTest(needle=needle):
                self.assertIn(needle, LOCAL)

    def test_it_expects_403_without_the_header_and_200_with_it(self):
        self.assertRegex(LOCAL, r"بلا الترويسة السرّية: يجب 403")
        self.assertRegex(LOCAL, r"الترويسة الصحيحة[^\n]*يجب 200")

    def test_the_five_skipped_tests_are_explained(self):
        self.assertIn("test_app_integration", LOCAL)
        self.assertIn("skipped=0", LOCAL)

    def test_the_migration_count_matches_the_sql_files(self):
        files = sorted((ROOT / "src" / "guardian" / "db" / "sql").glob("*.sql"))
        self.assertEqual(files[-1].name[:4], "0013")
        self.assertIn("`0001` إلى `0013`", LOCAL)


if __name__ == "__main__":
    unittest.main()
