import unittest

from guardian.config import WEBHOOK_PATH, load_settings
from guardian.errors import ConfigError
from helpers import VALID_ENV


def env(**over):
    e = dict(VALID_ENV)
    for k, v in over.items():
        if v is None:
            e.pop(k, None)
        else:
            e[k] = v
    return e


class ConfigTests(unittest.TestCase):
    def test_valid_minimal(self):
        s = load_settings(env())
        self.assertEqual(s.owner_telegram_id, 111111111)
        self.assertEqual(s.default_language, "ar")
        self.assertEqual(s.display_timezone, "Asia/Riyadh")
        self.assertIsNone(s.backup_owner_telegram_id)
        self.assertIsNone(s.owner_group_id)
        self.assertFalse(s.webhook_register_on_startup)
        self.assertTrue(s.run_migrations_on_startup)
        self.assertEqual(s.port, 10000)

    def test_empty_environment_lists_all_required_names(self):
        with self.assertRaises(ConfigError) as cm:
            load_settings({})
        names = {n for n, _ in cm.exception.problems}
        self.assertEqual(names, {"BOT_TOKEN", "DATABASE_URL", "OWNER_TELEGRAM_ID", "WEBHOOK_SECRET"})

    def test_error_message_never_contains_values(self):
        bad = env(BOT_TOKEN="not-a-token-SUPERSECRETVALUE", WEBHOOK_SECRET="short!SECRETVALUE", OWNER_TELEGRAM_ID="abc")
        with self.assertRaises(ConfigError) as cm:
            load_settings(bad)
        text = str(cm.exception)
        for leaked in ("SUPERSECRETVALUE", "SECRETVALUE", "abc"):
            self.assertNotIn(leaked, text)
        self.assertIn("BOT_TOKEN", text)

    def test_invalid_values(self):
        cases = {
            "BOT_TOKEN": "xyz",
            "DATABASE_URL": "mysql://u:p@h/db",
            "OWNER_TELEGRAM_ID": "-5",
            "WEBHOOK_SECRET": "has spaces and is long enough!!",
            "DEFAULT_LANGUAGE": "fr",
            "DISPLAY_TIMEZONE": "Mars/Base",
            "ENVIRONMENT": "staging",
            "LOG_LEVEL": "LOUD",
            "PORT": "70000",
            "OWNER_GROUP_ID": "0",
            "WEBHOOK_BASE_URL": "http://insecure.example.com",
            "RUN_MIGRATIONS_ON_STARTUP": "maybe",
        }
        for name, value in cases.items():
            with self.subTest(name=name):
                with self.assertRaises(ConfigError) as cm:
                    load_settings(env(**{name: value}))
                self.assertIn(name, {n for n, _ in cm.exception.problems})

    def test_backup_owner_must_differ(self):
        with self.assertRaises(ConfigError):
            load_settings(env(BACKUP_OWNER_TELEGRAM_ID="111111111"))
        s = load_settings(env(BACKUP_OWNER_TELEGRAM_ID="222222222"))
        self.assertEqual(s.backup_owner_telegram_id, 222222222)

    def test_owner_group_id_negative_allowed(self):
        self.assertEqual(load_settings(env(OWNER_GROUP_ID="-1001234567890")).owner_group_id, -1001234567890)

    def test_webhook_url_and_render_fallback(self):
        s = load_settings(env(RENDER_EXTERNAL_URL="https://svc.onrender.com/"))
        self.assertEqual(s.webhook_url, "https://svc.onrender.com" + WEBHOOK_PATH)
        s2 = load_settings(env(WEBHOOK_BASE_URL="https://custom.example.com", RENDER_EXTERNAL_URL="https://svc.onrender.com"))
        self.assertEqual(s2.webhook_base_url, "https://custom.example.com")
        self.assertIsNone(load_settings(env()).webhook_url)

    def test_register_requires_base_url(self):
        with self.assertRaises(ConfigError):
            load_settings(env(WEBHOOK_REGISTER_ON_STARTUP="true"))
        s = load_settings(env(WEBHOOK_REGISTER_ON_STARTUP="true", WEBHOOK_BASE_URL="https://x.example.com"))
        self.assertTrue(s.webhook_register_on_startup)

    def test_pool_bounds(self):
        with self.assertRaises(ConfigError):
            load_settings(env(DB_POOL_MIN="6", DB_POOL_MAX="5"))

    def test_repr_hides_secrets(self):
        s = load_settings(env())
        for text in (repr(s), str(s)):
            self.assertNotIn("AAAAAAAA", text)
            self.assertNotIn("s3cretPW", text)
            self.assertNotIn("unit-test-webhook-secret", text)

    def test_secret_values_include_db_password(self):
        values = load_settings(env()).secret_values()
        self.assertIn("s3cretPW", values)
        self.assertIn(VALID_ENV["BOT_TOKEN"], values)


if __name__ == "__main__":
    unittest.main()
