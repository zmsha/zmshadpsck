import unittest

from guardian.audit import FORGED_CALLBACK
from guardian.errors import InvalidInput, PermissionDenied
from guardian.licensing.callbacks import build_callback, handle_license_callback, parse_callback
from guardian.licensing.models import LicenseStatus as S
from stack import A, B, BACKUP, OWNER, STRANGER, TG_ADMIN, TG_CREATOR, Stack


class CodecTests(unittest.TestCase):
    def test_roundtrip(self):
        for action in ("activate_permanent", "stop", "reject", "ban", "unban", "allow"):
            cb = parse_callback(build_callback(action, -1001234567890))
            self.assertEqual((cb.action, cb.group_id), (action, -1001234567890))

    def test_malformed_data_is_rejected(self):
        bad = [None, 5, b"lic:ap:-1", "", "lic:ap:1001", "lic:ap:-0", "lic:ap:-01", "lic:xx:-1001", "LIC:ap:-1001",
               "lic:ap:-1001:extra", "lic:ap:-1001 ", " lic:ap:-1001", "lic:ap:-1e3", "lic:ap:-１００１", "lic:ap:-1００１",
               "lic:ap:" + "-" + "9" * 40, "lic:ap:-1001\n", "lic:__class__:-1001", "x" * 200]
        for data in bad:
            with self.assertRaises(InvalidInput, msg=repr(data)):
                parse_callback(data)

    def test_builder_refuses_bad_input(self):
        for action, gid in (("activate_temporary", -1), ("ban", 5), ("ban", True), ("nope", -1)):
            with self.assertRaises(InvalidInput):
                build_callback(action, gid)


class ForgedCallbackTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A, B)

    async def test_forged_callback_from_non_owner_is_refused_and_audited(self):
        data = build_callback("activate_permanent", A)  # hand-crafted exactly like a real button
        for actor in (STRANGER, TG_CREATOR, TG_ADMIN, BACKUP):
            with self.assertRaises(PermissionDenied):
                await handle_license_callback(self.s.admin, self.s.audit, actor, data)
        self.assertIs((await self.s.licenses.get(A)).status, S.PENDING)
        forged = [e for e in self.s.audit.events if e.event_type == FORGED_CALLBACK]
        self.assertEqual({e.actor_telegram_id for e in forged}, {STRANGER, TG_CREATOR, TG_ADMIN, BACKUP})
        self.assertTrue(all(e.group_id == A for e in forged))

    async def test_forged_unban_of_banned_group_by_group_owner_fails(self):
        await self.s.admin.ban(OWNER, A)
        with self.assertRaises(PermissionDenied):
            await handle_license_callback(self.s.admin, self.s.audit, TG_CREATOR, build_callback("unban", A))
        self.assertIs((await self.s.licenses.get(A)).status, S.BANNED)

    async def test_malformed_callback_is_audited_and_changes_nothing(self):
        with self.assertRaises(InvalidInput):
            await handle_license_callback(self.s.admin, self.s.audit, OWNER, "lic:ap:-1001;DROP")
        self.assertTrue(any(e.event_type == FORGED_CALLBACK for e in self.s.audit.events))
        self.assertIs((await self.s.licenses.get(A)).status, S.PENDING)

    async def test_actor_comes_from_the_update_not_from_the_data(self):
        # Even a callback string naming the owner's id cannot elevate: ids are not part of the codec.
        with self.assertRaises(InvalidInput):
            await handle_license_callback(self.s.admin, self.s.audit, STRANGER, f"lic:ap:-1001:{OWNER}")

    async def test_owner_callback_works_and_is_group_specific(self):
        result = await handle_license_callback(self.s.admin, self.s.audit, OWNER, build_callback("activate_permanent", A))
        self.assertEqual(result.license.group_id, A)
        self.assertIs((await self.s.licenses.get(A)).status, S.ACTIVE_PERMANENT)
        self.assertIs((await self.s.licenses.get(B)).status, S.PENDING)

    async def test_callback_from_a_different_chat_cannot_target_this_group(self):
        with self.assertRaises(PermissionDenied):
            await handle_license_callback(self.s.admin, self.s.audit, OWNER, build_callback("ban", A),
                                          context_chat_id=B)
        self.assertIs((await self.s.licenses.get(A)).status, S.PENDING)


if __name__ == "__main__":
    unittest.main()
