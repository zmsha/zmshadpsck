import unittest
from datetime import datetime, timedelta, timezone

from guardian.time_utils import ensure_utc, format_display, to_display_tz, utcnow


class TimeTests(unittest.TestCase):
    def test_naive_rejected(self):
        with self.assertRaises(ValueError):
            ensure_utc(datetime(2026, 1, 1))

    def test_normalises_to_utc(self):
        plus3 = timezone(timedelta(hours=3))
        self.assertEqual(ensure_utc(datetime(2026, 1, 1, 3, 0, tzinfo=plus3)), datetime(2026, 1, 1, 0, 0, tzinfo=timezone.utc))

    def test_display_riyadh_is_utc_plus_3(self):
        shown = to_display_tz(datetime(2026, 10, 29, 0, 25, tzinfo=timezone.utc), "Asia/Riyadh")
        self.assertEqual((shown.hour, shown.minute), (3, 25))
        self.assertEqual(format_display(datetime(2026, 10, 29, 0, 25, tzinfo=timezone.utc), "Asia/Riyadh"), "2026-10-29 03:25 (Asia/Riyadh)")

    def test_dst_zone_sanity(self):
        summer = to_display_tz(datetime(2026, 7, 1, 12, 0, tzinfo=timezone.utc), "Europe/London")
        winter = to_display_tz(datetime(2026, 1, 1, 12, 0, tzinfo=timezone.utc), "Europe/London")
        self.assertEqual((summer.hour, winter.hour), (13, 12))

    def test_utcnow_is_aware_utc(self):
        self.assertEqual(utcnow().utcoffset(), timedelta(0))


if __name__ == "__main__":
    unittest.main()
