"""Phase 3 / part 8: the PRIVATE-HANDOFF acceptance test, end to end with the REAL gate.

Every earlier test of "license off" used a hand-made `ProtectionContext(allowed=False)`. Here the chain is the real one:

    real license state (LicenseAdminService) -> ProtectionGate -> ProtectionGateMiddleware (+ real ProtectionEngine)
        -> handler -> moderation_handler.match_command/execute -> ModerationCommandService

Acceptance criteria (spec: "no protective path may bypass the permission/licence check"):
* pending / unregistered / rejected / banned / stopped / expired / DB failure  =>  NO protection and NO moderation
  command touches Telegram, the ledgers, or the claim store -- for ALL eight commands, for the group admin AND the owner;
* the middleware never drops the update (the owner's license paths keep working in every state);
* the owner can recover every state through the ordinary license transitions, after which commands and protection work;
* a licensed group never licenses another group.
"""
from __future__ import annotations

import unittest
from datetime import timedelta
from types import SimpleNamespace as NS

from executor_stack import BOT, FakeActions, USER
from guardian.bot import moderation_handler as h
from guardian.bot.middlewares import ProtectionGateMiddleware
from guardian.idempotency import InMemoryIdempotency
from guardian.moderation.executor import ModerationCommandService, ResultKind as R
from guardian.protection.engine import ActionResult, ProtectionEngine
from guardian.protection_gate import ProtectionContext, ProtectionGate
from guardian.telegram_rights import ChatMemberInfo
from helpers import FakeNotifier
from stack import OWNER, STRANGER, TG_ADMIN, Stack
from test_moderation_integration import FakeBot, Msg

ALL_COMMANDS = ("/ban", "/unban", "/mute", "/unmute", "/kick", "/warn spam", "/warnings", "/clearwarns")
BLOCKED_STATES = ("pending", "unregistered", "rejected", "banned", "stopped", "expired", "store_down")


class Acts(FakeActions):
    async def delete_message(self, chat_id, message_id):
        return await self._do("delete", chat_id, message_id)


class Pipeline(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        self.notifier = FakeNotifier()
        self.actions = Acts()
        self.claims = InMemoryIdempotency()
        self.bot = FakeBot()
        self.gate = ProtectionGate(self.s.license_service, self.s.perm, self.notifier, clock=self.s.clock)
        self.engine = ProtectionEngine(self.s.settings_store, self.actions, self.s.chat, self.claims, self.s.audit,
                                       self.notifier, clock=self.s.clock)
        self.mw = ProtectionGateMiddleware(self.gate, self.engine)
        self.svc = ModerationCommandService(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions,
            settings_store=self.s.settings_store, actions=self.actions, chat_info=self.s.chat, claims=self.claims,
            audit=self.s.audit, bot_id=BOT, clock=self.s.clock)
        self.services = NS(settings=NS(default_language="ar"), moderation_commands=self.svc)
        self.mid = 0
        self._groups = 0

    # ------------------------------------------------------------------ helpers
    def _prepare_chat(self, g):
        self.s.chat.set(g, BOT, ChatMemberInfo("administrator", True, True, True))
        self.s.chat.set(g, TG_ADMIN, ChatMemberInfo("administrator", True, True, True))
        self.s.chat.set(g, USER, ChatMemberInfo("member"))

    async def group_in(self, state: str) -> int:
        """A fresh group driven into `state` ONLY through the real owner license service."""
        self._groups += 1
        g = -2_000 - self._groups
        self._prepare_chat(g)
        if state != "unregistered":
            await self.s.register(g)
        if state in ("stopped", "expired", "store_down"):
            if state == "expired":
                await self.s.admin.activate_temporary(OWNER, g, self.s.clock() + timedelta(hours=1))
                self.s.clock.advance(hours=2)  # the host slept past expires_at; no scheduler ever ran
            else:
                await self.s.admin.activate_permanent(OWNER, g)
                if state == "stopped":
                    await self.s.admin.stop(OWNER, g)
        elif state == "rejected":
            await self.s.admin.reject(OWNER, g)
        elif state == "banned":
            await self.s.admin.ban(OWNER, g)
        return g

    async def deliver(self, msg):
        """One update through the real middleware. Returns (handler_ran, command_result|None)."""
        out = {"ran": False, "result": None}

        async def handler(event, data):
            out["ran"] = True
            parsed = await h.match_command(event, self.bot)
            if parsed is not None:
                out["result"] = await h.execute(event, parsed, protection=data["protection"], services=self.services)

        await self.mw(handler, msg, {})
        return out["ran"], out["result"]

    def cmd(self, text, g, sender=TG_ADMIN):
        self.mid += 1
        return Msg(text, chat=g, sender=sender, mid=self.mid, reply_to=USER)

    def link(self, g, sender=STRANGER):
        self.mid += 1
        return Msg("buy at https://evil.example.com now", chat=g, sender=sender, mid=self.mid)

    async def assert_fully_off(self, g, who):
        calls_before, claims_before = len(self.actions.calls), dict(self.claims._keys)
        for text in ALL_COMMANDS:
            ran, res = await self.deliver(self.cmd(text, g, sender=who))
            self.assertTrue(ran, f"middleware must never drop the update ({text})")
            self.assertIsNotNone(res, text)
            self.assertEqual(res.kind, R.LICENSE_OFF, text)
        ran, _ = await self.deliver(self.link(g))
        self.assertTrue(ran)
        self.assertEqual(self.actions.calls[calls_before:], [])        # nothing reached Telegram
        self.assertEqual(self.claims._keys, claims_before)             # no claim consumed
        self.assertEqual(await self.s.warning_store.count_active(g, USER, self.s.clock()), 0)
        self.assertEqual(await self.s.sanction_store.get_active(g, USER, self.s.clock()), [])

    def break_store(self):
        real_get = self.s.licenses.get

        async def boom(*a, **k):
            raise RuntimeError("db down")

        self.s.licenses.get = boom
        return real_get

    async def owner_recovers(self, g, state):
        if state == "rejected":
            await self.s.admin.allow(OWNER, g)
        elif state == "banned":
            await self.s.admin.unban(OWNER, g)
        if state != "store_down":
            await self.s.admin.activate_permanent(OWNER, g)


# --------------------------------------------------------------------------- the acceptance matrix
class LicenseMatrixTests(Pipeline):
    async def test_every_blocked_state_disables_all_commands_and_protection(self):
        for state in BLOCKED_STATES:
            with self.subTest(state=state):
                g = await self.group_in(state)
                real_get = self.s.licenses.get
                if state == "store_down":
                    real_get = self.break_store()
                try:
                    await self.assert_fully_off(g, TG_ADMIN)
                finally:
                    self.s.licenses.get = real_get

    async def test_the_owner_is_blocked_too_commands_are_not_a_license_path(self):
        for state in ("pending", "rejected", "banned", "stopped", "expired"):
            with self.subTest(state=state):
                g = await self.group_in(state)
                await self.assert_fully_off(g, OWNER)

    async def test_unregistered_group_is_registered_pending_never_activated(self):
        g = await self.group_in("unregistered")
        await self.deliver(self.cmd("/ban", g))
        rec = await self.s.licenses.get(g)
        self.assertEqual(rec.status.value, "pending")
        await self.assert_fully_off(g, TG_ADMIN)

    async def test_owner_recovers_every_state_through_the_license_service_then_everything_works(self):
        for state in BLOCKED_STATES:
            with self.subTest(state=state):
                g = await self.group_in(state)
                real_get = self.break_store() if state == "store_down" else self.s.licenses.get
                try:
                    await self.assert_fully_off(g, TG_ADMIN)
                finally:
                    self.s.licenses.get = real_get               # the database is back
                await self.owner_recovers(g, state)              # the owner's paths were never blocked
                _, res = await self.deliver(self.cmd("/ban", g))
                self.assertEqual(res.kind, R.DONE)
                self.assertEqual(self.actions.names()[-1], "ban")
                before = len(self.actions.calls)
                await self.deliver(self.link(g))                  # protection is back too (positive control)
                self.assertGreater(len(self.actions.calls), before)
                self.assertEqual(self.actions.calls[before][0], "delete")

    async def test_unexpected_bug_inside_the_gate_fails_closed_for_commands_and_protection(self):
        g = await self.group_in("stopped")
        await self.s.admin.activate_permanent(OWNER, g)           # fully licensed: only a bug can deny
        real = self.s.perm.is_exempt_from_automation

        async def bug(*a, **k):
            raise RuntimeError("bug")

        self.s.perm.is_exempt_from_automation = bug
        try:
            await self.assert_fully_off(g, TG_ADMIN)
        finally:
            self.s.perm.is_exempt_from_automation = real
        _, res = await self.deliver(self.cmd("/ban", g))          # and it heals once the bug is gone
        self.assertEqual(res.kind, R.DONE)

    async def test_license_lost_midway_stops_the_very_next_command(self):
        g = await self.group_in("stopped")
        await self.s.admin.activate_permanent(OWNER, g)
        _, ok = await self.deliver(self.cmd("/mute", g))
        self.assertEqual(ok.kind, R.DONE)
        await self.s.admin.stop(OWNER, g)
        n = len(self.actions.calls)
        _, res = await self.deliver(self.cmd("/unmute", g))
        self.assertEqual(res.kind, R.LICENSE_OFF)
        self.assertEqual(len(self.actions.calls), n)

    async def test_temporary_license_lapses_between_two_commands_without_any_scheduler(self):
        g = await self.group_in("pending")
        await self.s.admin.activate_temporary(OWNER, g, self.s.clock() + timedelta(minutes=10))
        _, a = await self.deliver(self.cmd("/mute", g))
        self.assertEqual(a.kind, R.DONE)
        self.s.clock.advance(minutes=10)                          # exactly at expires_at counts as expired
        _, b = await self.deliver(self.cmd("/unmute", g))
        self.assertEqual(b.kind, R.LICENSE_OFF)


# --------------------------------------------------------------------------- isolation between groups
class IsolationTests(Pipeline):
    async def test_a_licensed_group_does_not_license_another(self):
        live = await self.group_in("stopped")
        await self.s.admin.activate_permanent(OWNER, live)
        dead = await self.group_in("pending")
        _, res = await self.deliver(self.cmd("/ban", dead))
        self.assertEqual(res.kind, R.LICENSE_OFF)
        self.assertEqual(self.actions.calls, [])

    async def test_context_of_another_chat_never_licenses_this_one(self):
        live = await self.group_in("stopped")
        await self.s.admin.activate_permanent(OWNER, live)
        dead = await self.group_in("pending")
        parsed = await h.match_command(self.cmd("/ban", dead), self.bot)
        borrowed = ProtectionContext(live, "supergroup", True, "none", TG_ADMIN, False)  # wrong chat on purpose
        res = await h.execute(self.cmd("/ban", dead), parsed, protection=borrowed, services=self.services)
        self.assertEqual(res.kind, R.LICENSE_OFF)
        self.assertEqual(self.actions.calls, [])

    async def test_admin_of_one_group_cannot_moderate_a_licensed_group_they_do_not_administer(self):
        g = await self.group_in("stopped")
        await self.s.admin.activate_permanent(OWNER, g)
        self.s.chat.set(g, TG_ADMIN, ChatMemberInfo("member"))   # admin elsewhere, plain member here
        _, res = await self.deliver(self.cmd("/ban", g))
        self.assertEqual(res.kind, R.DENIED)
        self.assertEqual(self.actions.calls, [])

    async def test_missing_context_fails_closed(self):
        g = await self.group_in("stopped")
        await self.s.admin.activate_permanent(OWNER, g)
        msg = self.cmd("/ban", g)
        parsed = await h.match_command(msg, self.bot)
        res = await h.execute(msg, parsed, protection=None, services=self.services)
        self.assertEqual(res.kind, R.LICENSE_OFF)
        self.assertEqual(self.actions.calls, [])


# --------------------------------------------------------------------------- end-to-end happy path of all eight commands
class EightCommandsEndToEnd(Pipeline):
    async def test_all_eight_commands_run_through_the_real_chain(self):
        g = await self.group_in("pending")
        await self.s.admin.activate_permanent(OWNER, g)
        seen = {}
        for text in ALL_COMMANDS:
            _, res = await self.deliver(self.cmd(text, g))
            seen[text] = res.kind
        self.assertEqual(seen["/ban"], R.DONE)
        self.assertIn(seen["/unban"], (R.DONE, R.NOOP))
        self.assertEqual(seen["/mute"], R.DONE)
        self.assertIn(seen["/unmute"], (R.DONE, R.NOOP))
        self.assertIn(seen["/kick"], (R.DONE, R.INVALID, R.NOOP))
        self.assertEqual(seen["/warn spam"], R.DONE)
        self.assertEqual(seen["/warnings"], R.INFO)
        self.assertIn(seen["/clearwarns"], (R.DONE, R.NOOP))
        self.assertFalse(any(k in (R.ERROR, R.DENIED, R.LICENSE_OFF) for k in seen.values()), seen)

    async def test_telegram_failure_is_reported_and_nothing_is_recorded(self):
        g = await self.group_in("pending")
        await self.s.admin.activate_permanent(OWNER, g)
        self.actions.fail["ban"] = "forbidden"
        _, res = await self.deliver(self.cmd("/ban", g))
        self.assertEqual(res.kind, R.TELEGRAM_FAILED)
        self.assertEqual(await self.s.sanction_store.get_active(g, USER, self.s.clock()), [])


if __name__ == "__main__":
    unittest.main()
