import unittest
from types import SimpleNamespace as NS

from guardian.protection.links import find_links, normalize_domain, violating_links
from guardian.protection.settings import ProtectionSettings


def E(t, o, l, u=None):
    return NS(type=t, offset=o, length=l, url=u)


def bad(text, allow=(), entities=None, invites=False):
    return violating_links(find_links(text, entities), allow, allow_invites=invites)


class LinkTests(unittest.TestCase):
    def test_plain_text_has_no_links(self):
        for s in ("hello world", "file.py and e.g. this", "مرحبا بكم", "v1.2.3", "price 3.5 dollars", "a@b.com"):
            self.assertEqual(find_links(s), [], s)

    def test_scheme_www_and_bare_domains(self):
        for s in ("https://evil.com/x", "go www.evil.com now", "evil.com", "visit EVIL.COM/page", "evil.com:8080/a"):
            self.assertEqual([l.host.removeprefix("www.") for l in find_links(s)], ["evil.com"], s)

    def test_allowlist_exact_and_subdomain_only_on_dot_boundary(self):
        self.assertEqual(bad("https://good.com/a", ["good.com"]), [])
        self.assertEqual(bad("https://sub.good.com", ["good.com"]), [])
        self.assertEqual(len(bad("https://evil-good.com", ["good.com"])), 1)
        self.assertEqual(len(bad("https://good.com.evil.com", ["good.com"])), 1)
        self.assertEqual(len(bad("https://good.com", [])), 1)  # blocked by default

    def test_userinfo_trick_uses_real_host(self):
        self.assertEqual(bad("http://good.com@evil.com/x", ["good.com"])[0].host, "evil.com")

    def test_case_trailing_dot_punctuation_and_zero_width(self):
        self.assertEqual(bad("HTTPS://Good.COM./x).", ["good.com"]), [])
        self.assertEqual(len(bad("ev\u200bil.com")), 1)

    def test_hidden_text_link_entity(self):
        ents = [E("text_link", 0, 5, "https://evil.com/p")]
        self.assertEqual(bad("click", ["good.com"], ents)[0].host, "evil.com")
        self.assertEqual(bad("click", ["evil.com"], ents), [])

    def test_url_entity_uses_utf16_offsets(self):
        text = "😀😀 evil.org"  # each emoji = 2 UTF-16 units; entity starts at 5
        self.assertEqual(bad(text, [], [E("url", 5, 8)])[0].host, "evil.org")

    def test_malformed_entities_ignored_not_crash(self):
        self.assertEqual(bad("hi", [], [NS(type="url", offset="x", length=None), NS(type="text_link", url="")]), [])

    def test_invites_blocked_unless_allowed(self):
        for s in ("t.me/+AbC123", "https://t.me/joinchat/xyz", "tg://join?invite=abc", "telegram.me/+z"):
            links = find_links(s)
            self.assertEqual(links[0].kind, "invite", s)
            self.assertEqual(len(violating_links(links, ["t.me"])), 1, s)  # allowlisting t.me is not enough
            self.assertEqual(violating_links(links, [], allow_invites=True), [])

    def test_tme_channel_link_needs_t_me_in_allowlist(self):
        self.assertEqual(len(bad("https://t.me/somechannel", ["good.com"])), 1)
        self.assertEqual(bad("https://t.me/somechannel", ["t.me"]), [])

    def test_shortener_judged_by_own_domain(self):
        self.assertEqual(len(bad("bit.ly/abc", ["good.com"])), 1)
        self.assertEqual(bad("bit.ly/abc", ["bit.ly"]), [])

    def test_idn_punycode(self):
        self.assertEqual(normalize_domain("https://WWW.Bücher.de/x"), "xn--bcher-kva.de")
        self.assertEqual(bad("https://bücher.de", ["bücher.de".encode("idna").decode()]), [])

    def test_normalize_domain_rejects_garbage(self):
        for v in (None, 5, "", "a b.com", "x" * 300, "http://", "not a domain!", "-bad-.com"):
            self.assertIsNone(normalize_domain(v), v)
        self.assertEqual(normalize_domain("example.com"), "example.com")


class SettingsTests(unittest.TestCase):
    def test_defaults_are_safe(self):
        s = ProtectionSettings.from_raw(None)
        self.assertTrue(s.links_enabled and s.flood_enabled and s.duplicate_enabled)
        self.assertFalse(s.dry_run or s.links_allow_invites)
        self.assertEqual(s.links_allow_domains, ())

    def test_invalid_values_fall_back_never_trusted(self):
        s = ProtectionSettings.from_raw({
            "links_enabled": "no", "flood_max_messages": 0, "flood_window_seconds": True,
            "escalation_mutes_seconds": [5, 100], "duplicate_max_repeats": 10**9, "dry_run": 1,
            "links_allow_domains": ["good.com", "bad domain", 5, "GOOD.com", "https://x.org/p"],
        })
        self.assertTrue(s.links_enabled)
        self.assertEqual((s.flood_max_messages, s.flood_window_seconds, s.duplicate_max_repeats), (6, 10, 3))
        self.assertEqual(s.escalation_mutes_seconds, (600, 3600, 86400))
        self.assertFalse(s.dry_run)
        self.assertEqual(s.links_allow_domains, ("good.com", "x.org"))

    def test_escalation_steps_and_cap(self):
        s = ProtectionSettings.from_raw({"escalation_mutes_seconds": [60, 120]})
        self.assertEqual([s.mute_for(n) for n in (1, 2, 3, 99, 0)], [60, 120, 120, 120, 60])


if __name__ == "__main__":
    unittest.main()
