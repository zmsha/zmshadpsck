"""Part 6.9a: restore VALIDATION and PREVIEW (`/restore` in the owner's private chat). Nothing is ever written.
PostgreSQL / aiogram / Telegram are NOT exercised (fakes only)."""
from __future__ import annotations

import asyncio
import ast
import copy
import json
import re
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace as NS

import helpers  # noqa: F401
from backup_helpers import FIXED_NOW, FakeReader, sample_rows
from stack import NOW, OWNER, BACKUP, STRANGER, Stack

from guardian import i18n
from guardian.audit import RESTORE_PREVIEWED, RESTORE_REJECTED, InMemorySecurityAudit
from guardian.backup import format as F
from guardian.backup import preview as P
from guardian.backup import restore_service as svc
from guardian.backup import validate as V
from guardian.backup.collector import BackupCollector
from guardian.backup.restore_command import (RestoreCommandService, parse_restore_command, render_preview, _INVALID_KEYS)
from guardian.bot import owner_panel_handler as oh
from guardian.db.migrations import discover
from guardian.idempotency import InMemoryIdempotency
from guardian.permissions import OWNER_ONLY, Permission

SRC = Path(__file__).resolve().parent.parent / "src" / "guardian"
SQL = Path(__file__).resolve().parent.parent / "src" / "guardian" / "db" / "sql"
SECRET = "S3cr3t-Token-Value-12345"
G1, G2 = -1001, -1002


def run(coro):
    return asyncio.run(coro)


def collect(rows=None, *, secrets=(), schema=10, name="0010_report_schedule", now=FIXED_NOW):
    reader = FakeReader(rows if rows is not None else sample_rows())
    return run(BackupCollector(reader, app_version="0.6.8-test", schema_version=schema, schema_name=name, secrets=secrets,
                               clock=lambda: now).collect())


_GOOD = collect().data     # one real backup, built once at import (the collector is async: no loop is running here)


def good() -> bytes:
    return _GOOD


def resign(doc: dict) -> bytes:
    """Re-compute counts, checksums, digest and total of an EDITED document (an attacker can; the checksums are not signatures)."""
    entries = {}
    for name, rows in doc["tables"].items():
        entries[name] = {"rows": len(rows), "sha256": F.sha256_hex(F.canonical(rows))}
    doc["manifest"]["tables"] = entries
    doc["manifest"]["tables_digest"] = F.tables_digest(entries)
    doc["manifest"]["total_rows"] = sum(e["rows"] for e in entries.values())
    return F.canonical(doc).encode("utf-8")


def edited(mutate, *, base: bytes | None = None) -> bytes:
    doc = json.loads((base or good()).decode("utf-8"))
    mutate(doc)
    return resign(doc)


def validate(data, **kw):
    kw.setdefault("current_schema_version", 10)
    kw.setdefault("now", FIXED_NOW + timedelta(hours=1))
    return V.validate_backup(data, **kw)


def code_of(data, **kw) -> tuple[str, str]:
    try:
        validate(data, **kw)
    except V.RestoreValidationError as exc:
        return exc.code, exc.detail
    raise AssertionError("expected a validation error")


# ------------------------------------------------------------------------------------------------ validation
class ValidationAcceptsTests(unittest.TestCase):
    def test_a_real_backup_passes(self):
        v = validate(good())
        self.assertEqual(v.schema_version, 10)
        self.assertEqual(v.app_version, "0.6.8-test")
        self.assertEqual(v.group_ids, (G2, G1))
        self.assertEqual(v.created_at, FIXED_NOW)
        self.assertEqual(v.total_rows, sum(len(r) for r in sample_rows().values()))
        self.assertEqual(v.fingerprint, v.manifest["tables_digest"][:12])
        self.assertEqual(len(v.tables["group_reports"]), 1)

    def test_an_empty_database_backup_passes(self):
        v = validate(collect({}).data)
        self.assertEqual((v.total_rows, v.group_ids), (0, ()))

    def test_the_fingerprint_names_the_content_not_the_time(self):
        a = validate(collect().data)
        b = validate(collect(now=FIXED_NOW + timedelta(minutes=5)).data)
        self.assertEqual(a.fingerprint, b.fingerprint)
        rows = sample_rows()
        rows["group_settings"][0]["settings"] = {"x": 1}
        self.assertNotEqual(validate(collect(rows).data).fingerprint, a.fingerprint)

    def test_validation_does_not_modify_its_input(self):
        data = good()
        before = bytes(data)
        validate(data)
        self.assertEqual(data, before)


class ValidationStructureTests(unittest.TestCase):
    def test_not_bytes_and_garbage(self):
        for bad in (None, "text", 5, ["x"]):
            self.assertEqual(code_of(bad)[0], "bad_json")
        for bad in (b"", b"not json", b"\xff\xfe", b"[]", b"{}", b'{"manifest":{},"tables":{},"x":1}'):
            self.assertIn(code_of(bad)[0], ("bad_json", "bad_shape"), bad)

    def test_too_large(self):
        self.assertEqual(code_of(good() + b" " * F.MAX_BACKUP_BYTES)[0], "too_large")
        self.assertEqual(code_of(good(), max_bytes=100)[0], "too_large")

    def test_tampering_is_detected_by_the_checksums(self):
        data = good().replace(b"Second group", b"Second grouq")
        self.assertEqual(code_of(data)[0], "checksum_mismatch")

    def test_wrong_format_and_version(self):
        self.assertEqual(code_of(edited(lambda d: d["manifest"].update(format="other")))[0], "bad_format")
        self.assertEqual(code_of(edited(lambda d: d["manifest"].update(format_version=2)))[0], "bad_version")

    def test_unknown_table_and_its_hostile_name_is_not_echoed_as_detail(self):
        data = edited(lambda d: d["tables"].update({"evil<b>x": []}))
        code, detail = code_of(data)
        self.assertEqual(code, "unknown_table")
        self.assertEqual(svc.safe_detail(detail), "")          # a name taken from the file is never shown

    def test_incomplete_backup_is_refused(self):
        self.assertEqual(code_of(edited(lambda d: d["tables"].pop("moderation_warnings")))[0], "incomplete")
        self.assertEqual(code_of(edited(lambda d: d["tables"].pop("global_default_settings")))[1], "global_default_settings")

    def test_errors_never_contain_values(self):
        data = edited(lambda d: d["tables"]["group_reports"][0].update(reason=5))
        code, detail = code_of(data)
        self.assertEqual((code, detail), ("bad_value", "group_reports.reason"))
        self.assertNotIn("إعلان", detail)


class ValidationManifestTests(unittest.TestCase):
    def test_schema_version_window(self):
        self.assertEqual(code_of(good(), current_schema_version=9)[0], "schema_too_new")
        self.assertEqual(code_of(good(), current_schema_version=9)[1], "10>9")
        self.assertEqual(validate(good(), current_schema_version=11).schema_version, 10)   # an older backup into a newer app: accepted
        old = collect(schema=9, name="0009_daily_counters").data
        self.assertEqual(code_of(old)[0], "schema_too_old")
        for bad in ("10", True, 0, -1, None, 10.0):
            self.assertEqual(code_of(edited(lambda d: d["manifest"].update(schema_version=bad)))[0], "bad_manifest", bad)

    def test_manifest_fields(self):
        cases = {
            "schema_name": ("0009_x", "x", None, 5, "0010_" + "a" * 80),
            "app_version": ("", "x" * 41, None, 5, "bad\nline"),
            "created_at": ("2026-11-01", None, 5, "2026-11-01T12:00:00.000Z", "2026-13-45T00:00:00Z"),
            "excluded": ("x", None, [1], {"a": 1}),
        }
        for field, values in cases.items():
            for value in values:
                data = edited(lambda d: d["manifest"].update({field: value}))
                self.assertEqual(code_of(data), ("bad_manifest", field), (field, value))

    def test_a_backup_from_the_future_is_refused(self):
        far = collect(now=FIXED_NOW + timedelta(days=30)).data
        self.assertEqual(code_of(far), ("bad_manifest", "created_at_future"))
        self.assertEqual(validate(collect(now=FIXED_NOW + timedelta(hours=2)).data).schema_version, 10)   # small clock skew is fine

    def test_total_rows_must_match(self):
        doc = json.loads(good().decode())
        doc["manifest"]["total_rows"] += 1
        # tables digest does not cover total_rows, so only the validator can catch it
        self.assertEqual(code_of(F.canonical(doc).encode()), ("bad_manifest", "total_rows"))


class ValidationRowTests(unittest.TestCase):
    def row_edit(self, table, **changes):
        return edited(lambda d: d["tables"][table][0].update(changes))

    def test_columns_must_match_exactly(self):
        self.assertEqual(code_of(edited(lambda d: d["tables"]["group_settings"][0].update(extra=1)))[0], "bad_columns")
        self.assertEqual(code_of(edited(lambda d: d["tables"]["group_settings"][0].pop("language")))[0], "bad_columns")

    def test_types_are_strict(self):
        cases = [("telegram_groups", dict(group_id="-1001")), ("telegram_groups", dict(group_id=True)),
                 ("telegram_groups", dict(group_id=-1001.0)), ("telegram_groups", dict(title=5)),
                 ("telegram_groups", dict(created_at="2026-11-01")), ("telegram_groups", dict(created_at=5)),
                 ("telegram_groups", dict(created_at="2026-11-01T12:00:00Z")),
                 ("global_default_settings", dict(singleton=1)), ("global_default_settings", dict(version="2"))]
        for table, change in cases:
            self.assertEqual(code_of(self.row_edit(table, **change))[0], "bad_value", (table, change))

    def test_null_primary_key_and_duplicates(self):
        self.assertEqual(code_of(self.row_edit("telegram_groups", group_id=None)), ("bad_value", "telegram_groups.group_id"))
        dup = edited(lambda d: d["tables"]["group_trusted_users"].append(dict(d["tables"]["group_trusted_users"][0])))
        self.assertEqual(code_of(dup), ("duplicate_key", "group_trusted_users"))
        dup = edited(lambda d: d["tables"]["moderation_warnings"].append(dict(d["tables"]["moderation_warnings"][0])))
        self.assertEqual(code_of(dup), ("duplicate_key", "moderation_warnings"))

    def test_every_sql_rule_is_enforced(self):
        far = "2031-01-01T00:00:00.000000Z"
        cases = [
            (("telegram_groups", dict(group_id=1001)), "telegram_groups.group_id_negative"),
            (("telegram_groups", dict(license_status="gold")), "telegram_groups.license_status"),
            (("telegram_groups", dict(license_status="active_permanent", expires_at=far)), "telegram_groups.permanent_no_expiry"),
            (("telegram_groups", dict(license_status="active_temporary", expires_at=None)), "telegram_groups.temporary_has_expiry"),
            (("telegram_groups", dict(activated_by=None)), "telegram_groups.active_has_activation"),
            (("license_audit_log", dict(group_id=5)), "license_audit_log.group_id_negative"),
            (("license_audit_log", dict(new_status="x")), "license_audit_log.new_status"),
            (("license_audit_log", dict(previous_status="x")), "license_audit_log.previous_status"),
            (("license_audit_log", dict(action="  ")), "license_audit_log.action_not_blank"),
            (("license_audit_log", dict(reason="x" * 501)), "license_audit_log.reason_len"),
            (("group_settings", dict(language="fr")), "group_settings.language"),
            (("group_settings", dict(settings=[1])), "group_settings.settings_object"),
            (("group_delegations", dict(user_id=0)), "group_delegations.user_id_positive"),
            (("group_delegations", dict(role="root")), "group_delegations.role"),
            (("group_delegations", dict(revoked_by=None, revoked_at=far)), "group_delegations.revoked_pair"),
            (("group_trusted_users", dict(user_id=-4)), "group_trusted_users.user_id_positive"),
            (("group_trusted_users", dict(note="n" * 201)), "group_trusted_users.note_len"),
            (("group_trusted_bots", dict(bot_id=0)), "group_trusted_bots.bot_id_positive"),
            (("group_trusted_bots", dict(added_by=0)), "group_trusted_bots.added_by_positive"),
            (("moderation_warnings", dict(user_id=0)), "moderation_warnings.user_id_positive"),
            (("moderation_warnings", dict(reason="r" * 501)), "moderation_warnings.reason_len"),
            (("moderation_warnings", dict(idempotency_key="")), "moderation_warnings.idempotency_key_len"),
            (("moderation_warnings", dict(expires_at="2020-01-01T00:00:00.000000Z")), "moderation_warnings.expiry_after_create"),
            (("moderation_warnings", dict(revoked_at=far)), "moderation_warnings.revoked_pair"),
            (("moderation_sanctions", dict(kind="exile")), "moderation_sanctions.kind"),
            (("moderation_sanctions", dict(kind="kick")), "moderation_sanctions.kick_no_expiry"),
            (("moderation_sanctions", dict(violation="v" * 41)), "moderation_sanctions.violation_len"),
            (("moderation_sanctions", dict(lifted_by=5)), "moderation_sanctions.lifter_needs_lift"),
            (("moderation_sanctions", dict(expires_at="2020-01-01T00:00:00.000000Z")), "moderation_sanctions.expiry_after_create"),
            (("group_reports", dict(report_type="x")), "group_reports.report_type"),
            (("group_reports", dict(priority="urgent")), "group_reports.priority"),
            (("group_reports", dict(status="closed")), "group_reports.status"),
            (("group_reports", dict(outcome="x", status="open")), "group_reports.outcome"),
            (("group_reports", dict(status="taken")), "group_reports.state_consistent"),
            (("group_reports", dict(status="resolved", outcome="no_action")), "group_reports.state_consistent"),
            (("group_reports", dict(trace_id="XYZ")), "group_reports.trace_id"),
            (("group_reports", dict(reason="r" * 201)), "group_reports.reason_len"),
            (("group_reports", dict(message_id=0)), "group_reports.message_id_positive"),
            (("settings_templates", dict(name="")), "settings_templates.name_len"),
            (("settings_templates", dict(name_key="k" * 41)), "settings_templates.name_key_len"),
            (("settings_templates", dict(settings="x")), "settings_templates.settings_object"),
            (("settings_templates", dict(source_group_id=5)), "settings_templates.source_group_negative"),
            (("global_default_settings", dict(version=0)), "global_default_settings.version_positive"),
            (("global_default_settings", dict(singleton=False)), "global_default_settings.singleton_true"),
        ]
        for (table, change), expected in cases:
            self.assertEqual(code_of(self.row_edit(table, **change)), ("bad_rule", expected), (table, change))

    def test_a_valid_state_machine_row_passes(self):
        for change in (dict(status="resolved", outcome="action_taken", handled_by=5, handled_at="2026-11-01T12:00:00.000000Z"),
                       dict(status="taken", assigned_to=7), dict(status="dismissed", outcome="false_report", handled_by=5,
                                                               handled_at="2026-11-01T12:00:00.000000Z")):
            validate(self.row_edit("group_reports", **change))

    def test_foreign_keys_inside_the_file(self):
        for table in V.GROUP_TABLES:
            def orphan(d, table=table):
                d["tables"][table][0]["group_id"] = -999
                if table == "group_trusted_users" or table == "group_trusted_bots":
                    pass
            self.assertEqual(code_of(edited(orphan)), ("orphan_row", table), table)

    def test_unique_indexes_of_the_live_schema(self):
        def two_live(d):
            rows = d["tables"]["group_delegations"]
            rows.append(dict(rows[0], id=9))                 # same (group, user), both live
        self.assertEqual(code_of(edited(two_live)), ("duplicate_key", "group_delegations.delegation_live"))

        def revoked_duplicate_is_fine(d):
            rows = d["tables"]["group_delegations"]
            rows.append(dict(rows[1], id=9))                 # same (group, user) but revoked: allowed by the partial index
        validate(edited(revoked_duplicate_is_fine))

        def warn_key(d):
            rows = d["tables"]["moderation_warnings"]
            rows.append(dict(rows[0], id=9))
        self.assertEqual(code_of(edited(warn_key)), ("duplicate_key", "moderation_warnings.warning_idempotency"))

        def sanction_key(d):
            rows = d["tables"]["moderation_sanctions"]
            rows.append(dict(rows[0], id=9, group_id=G2))    # the sanction key is unique across ALL groups
        self.assertEqual(code_of(edited(sanction_key)), ("duplicate_key", "moderation_sanctions.sanction_idempotency"))

        def report_key(d):
            rows = d["tables"]["group_reports"]
            rows.append(dict(rows[0], id=9))
        self.assertEqual(code_of(edited(report_key)), ("duplicate_key", "group_reports.report_idempotency"))

        def template_name(d):
            rows = d["tables"]["settings_templates"]
            rows.append(dict(rows[0], id=9))
        self.assertEqual(code_of(edited(template_name)), ("duplicate_key", "settings_templates.template_name"))

        def null_keys_never_collide(d):
            for name in ("moderation_warnings", "group_reports"):
                rows = d["tables"][name]
                rows[0]["idempotency_key"] = None
                rows.append(dict(rows[0], id=9))
        validate(edited(null_keys_never_collide))


class ValidationSecretsTests(unittest.TestCase):
    def test_configured_secret_anywhere_refuses_and_names_only_the_table(self):
        data = edited(lambda d: d["tables"]["group_reports"][0].update(reason=f"see {SECRET}"))
        for secrets in ((SECRET,),):
            code, detail = code_of(data, secrets=secrets)
            self.assertEqual((code, detail), ("secret_found", "group_reports"))
            self.assertNotIn(SECRET, f"{code}{detail}")
        self.assertEqual(code_of(edited(lambda d: d["manifest"].update(app_version=SECRET)), secrets=(SECRET,)), ("secret_found", "manifest"))

    def test_url_quoted_and_json_escaped_forms(self):
        data = edited(lambda d: d["tables"]["group_reports"][0].update(reason="u p%40ss%3Aword%21%21"))
        self.assertEqual(code_of(data, secrets=("p@ss:word!!",)), ("secret_found", "group_reports"))
        data = edited(lambda d: d["tables"]["group_reports"][0].update(reason='quo"te'))
        self.assertEqual(code_of(data, secrets=('quo"te',)), ("secret_found", "group_reports"))

    def test_pem_and_token_shapes(self):
        pem = edited(lambda d: d["tables"]["group_reports"][0].update(reason="-----BEGIN PRIVATE KEY-----"))
        self.assertEqual(code_of(pem), ("secret_found", "group_reports"))
        token = edited(lambda d: d["tables"]["moderation_warnings"][0].update(reason="123456789:" + "A" * 35))
        self.assertEqual(code_of(token), ("secret_found", "moderation_warnings"))

    def test_a_rule_that_cannot_be_evaluated_fails_closed(self):
        original = V.RULES["group_settings"]
        V.RULES["group_settings"] = original + (("boom", lambda r: r["no_such_column"] > 1),)
        try:
            self.assertEqual(code_of(good()), ("bad_rule", "group_settings.boom"))
        finally:
            V.RULES["group_settings"] = original

    def test_short_secrets_are_ignored(self):
        validate(good(), secrets=("ab", ""))


class ValidationRegistryTests(unittest.TestCase):
    def test_every_table_has_rules_and_every_code_is_known(self):
        self.assertEqual(set(V.RULES), set(F.TABLE_NAMES))
        self.assertEqual(len(set(V.VALIDATION_CODES)), len(V.VALIDATION_CODES))
        with self.assertRaises(ValueError):
            V.RestoreValidationError("nope")
        self.assertEqual(set(V.VALIDATION_CODES) - set(_INVALID_KEYS), set())

    def test_vocabularies_match_the_migrations(self):
        text = "\n".join(p.read_text(encoding="utf-8") for p in sorted(SQL.glob("*.sql")))
        vocab = (V.LICENSE_STATUSES | V.ROLES | V.SANCTION_KINDS | V.REPORT_TYPES | V.REPORT_PRIORITIES | V.REPORT_STATUSES
                 | V.REPORT_OUTCOMES | V.LANGUAGES)
        for word in vocab:
            self.assertIn(f"'{word}'", text, word)
        for status in V.LICENSE_STATUSES:     # and the other way round for the licence statuses
            self.assertIn(status, text)
        m = re.search(r"license_status IN\s*\(([^)]*)\)", text)
        self.assertEqual({w.strip().strip("'") for w in m.group(1).split(",")}, set(V.LICENSE_STATUSES))
        m = re.search(r"role IN \(([^)]*)\)", text)
        self.assertEqual({w.strip().strip("'") for w in m.group(1).split(",")}, set(V.ROLES))
        m = re.search(r"kind IN \('mute', 'ban', 'kick'\)", text)
        self.assertIsNotNone(m)

    def test_schema_floor_is_the_migration_that_ends_the_registry(self):
        self.assertEqual(V.MIN_SCHEMA_VERSION, 10)
        self.assertGreaterEqual(int(discover()[-1][0][:4]), V.MIN_SCHEMA_VERSION)


# ------------------------------------------------------------------------------------------------ preview
def state(**over):
    groups = {G1: P.CurrentGroup("active_temporary", sample_rows()["telegram_groups"][0]["expires_at"].strftime("%Y-%m-%dT%H:%M:%S.%fZ")),
              -1003: P.CurrentGroup("pending", None)}
    base = dict(groups=groups, counts={"group_settings": {G1: 1, -1003: 1}, "moderation_warnings": {G1: 4, -1003: 2},
                                       "license_audit_log": {G1: 3, -1003: 1}},
                global_counts={"settings_templates": 3, "global_default_settings": 1}, defaults_version=2)
    base.update(over)
    return P.CurrentState(**base)


class PreviewTests(unittest.TestCase):
    def build(self, cur=None, now=None):
        return P.build_preview(validate(good()), cur or state(), now or FIXED_NOW + timedelta(hours=1))

    def line(self, p, table):
        return next(l for l in p.tables if l.table == table)

    def test_groups_replaced_new_and_kept(self):
        p = self.build()
        self.assertEqual((p.groups_replaced, p.groups_new, p.groups_kept), (1, 1, 1))
        self.assertEqual([g.group_id for g in p.groups], [G2, G1])
        self.assertEqual([(g.group_id, g.is_new) for g in p.groups], [(G2, True), (G1, False)])

    def test_groups_only_in_the_database_are_counted_as_kept_and_never_touched(self):
        cur = state(groups={G1: P.CurrentGroup("pending", None), -1003: P.CurrentGroup("pending", None),
                            -1004: P.CurrentGroup("pending", None), -1005: P.CurrentGroup("pending", None)})
        p = self.build(cur)
        self.assertEqual((p.groups_replaced, p.groups_new, p.groups_kept), (1, 1, 3))
        # their rows are not part of any count: -1003 holds rows now, none of them is "removed"
        self.assertEqual(self.line(p, "group_settings").current, 1)

    def test_per_group_tables_are_replaced_and_counted(self):
        p = self.build()
        warn = self.line(p, "moderation_warnings")
        self.assertEqual((warn.policy, warn.current, warn.backup, warn.removed, warn.added), ("replace_group", 4, 1, 4, 1))
        sett = self.line(p, "group_settings")
        self.assertEqual((sett.current, sett.backup), (1, 2))            # -1003 is not in the file: its row is not counted
        self.assertEqual(self.line(p, "group_reports").current, 0)

    def test_the_licence_log_is_never_removed_or_replaced(self):
        p = self.build()
        log = self.line(p, "license_audit_log")
        self.assertEqual((log.policy, log.removed, log.added), ("append_only", 0, 0))
        self.assertEqual((p.log_backup, p.log_current), (2, 3))

    def test_existing_groups_are_not_modified_and_missing_ones_are_created(self):
        p = self.build()
        g = self.line(p, "telegram_groups")
        self.assertEqual((g.policy, g.current, g.backup, g.removed, g.added), ("create_missing", 1, 2, 0, 1))

    def test_global_tables_are_replaced_as_a_whole(self):
        p = self.build()
        t = self.line(p, "settings_templates")
        self.assertEqual((t.policy, t.current, t.backup, t.removed), ("replace_all", 3, 1, 3))
        self.assertEqual((p.defaults_current, p.defaults_backup), (2, 2))

    def test_totals_and_the_age(self):
        p = self.build()
        self.assertEqual(p.removed_total, sum(l.removed for l in p.tables))
        self.assertEqual(p.added_total, sum(l.added for l in p.tables))
        self.assertEqual(p.age_days, 0)
        self.assertEqual(self.build(now=FIXED_NOW + timedelta(days=9)).age_days, 9)

    def test_licence_difference_is_reported_per_group(self):
        same = self.build()
        self.assertEqual(same.license_differs, 0)
        changed = state(groups={**state().groups, G1: P.CurrentGroup("expired", None)})
        p = self.build(changed)
        self.assertEqual(p.license_differs, 1)
        self.assertTrue(next(g for g in p.groups if g.group_id == G1).license_differs)
        longer = state(groups={**state().groups, G1: P.CurrentGroup("active_temporary", "2031-01-01T00:00:00.000000Z")})
        self.assertEqual(self.build(longer).license_differs, 1)

    def test_a_fresh_database_removes_nothing(self):
        p = self.build(P.CurrentState({}, {}, {}, None))
        self.assertEqual((p.removed_total, p.groups_new, p.groups_replaced, p.groups_kept), (0, 2, 0, 0))
        self.assertEqual(p.warnings and [w[0] for w in p.warnings], ["new_groups_pending"])

    def test_warnings(self):
        codes = lambda p: [c for c, _ in p.warnings]  # noqa: E731
        p = self.build(now=FIXED_NOW + timedelta(days=9))
        self.assertEqual(codes(p), ["old_backup", "removes_rows", "new_groups_pending", "groups_kept"])
        older = self.build(state(defaults_version=5))
        self.assertIn("older_defaults", codes(older))
        self.assertNotIn("older_defaults", codes(self.build(state(defaults_version=None))))

    def test_a_preview_is_pure_and_does_not_write(self):
        backup, cur = validate(good()), state()
        snapshot = copy.deepcopy(backup.tables)
        a = P.build_preview(backup, cur, FIXED_NOW)
        b = P.build_preview(backup, cur, FIXED_NOW)
        self.assertEqual(a, b)
        self.assertEqual(backup.tables, snapshot)
        self.assertFalse(a.writes_anything)

    def test_every_registered_table_has_a_policy(self):
        self.assertEqual(set(P.POLICY), set(F.TABLE_NAMES))

    def test_the_text_fits_a_message_even_with_hundreds_of_groups(self):
        rows = {"telegram_groups": [dict(group_id=-(1000 + i), title=f"g{i}", license_status="pending", activated_at=None, expires_at=None,
                                          activated_by=None, status_note=None, created_at=FIXED_NOW, updated_at=FIXED_NOW)
                                    for i in range(500)]}
        backup = validate(collect(rows).data)
        p = P.build_preview(backup, P.CurrentState({}, {}, {}, None), FIXED_NOW)
        for lang in ("ar", "en"):
            text = render_preview(p, lang)
            self.assertLess(len(text), 3500, lang)
            self.assertIn(p.fingerprint.upper(), text)
        self.assertEqual(len(p.groups), 500)

    def test_the_text_has_no_row_content_and_both_languages(self):
        text_ar, text_en = render_preview(self.build(), "ar"), render_preview(self.build(), "en")
        for text in (text_ar, text_en):
            for leaked in ("مجموعة الاختبار", "Second group", "إعلان مزعج", "spam", "444"):
                self.assertNotIn(leaked, text)
        self.assertIn("لم يُكتب", text_ar)
        self.assertIn("nothing was written", text_en)


# ------------------------------------------------------------------------------------------------ service
class Downloader:
    def __init__(self, data=None, exc=None, delay=0.0, none=False):
        self.data, self.exc, self.delay, self.none, self.calls = data, exc, delay, none, []

    async def download(self, file_id, max_bytes):
        self.calls.append((file_id, max_bytes))
        if self.delay:
            await asyncio.sleep(self.delay)
        if self.exc:
            raise self.exc
        return None if self.none else self.data


class StateReader:
    def __init__(self, current=None, exc=None):
        self.current, self.exc, self.calls = current or state(), exc, 0

    async def read(self):
        self.calls += 1
        if self.exc:
            raise self.exc
        return self.current


class BrokenClaims:
    async def claim(self, key, now=None):
        raise RuntimeError("down")


class Clock:
    def __init__(self):
        self.now = FIXED_NOW + timedelta(hours=1)

    def __call__(self):
        return self.now


class Base(unittest.IsolatedAsyncioTestCase):
    def build(self, *, data=None, downloader=None, reader=None, secrets=(), claims=None, cooldown=20, schema=10):
        self.stack = Stack()
        self.clock = Clock()
        self.audit = self.stack.audit
        self.downloader = downloader if downloader is not None else Downloader(good() if data is None else data)
        self.reader = reader or StateReader()
        self.service = svc.RestorePreviewService(
            downloader=self.downloader, state_reader=self.reader, permissions=self.stack.perm, claims=claims or InMemoryIdempotency(),
            audit=self.audit, secrets=secrets, schema_version=schema, clock=self.clock, cooldown=cooldown)
        self.cmd = RestoreCommandService(self.service)
        return self

    DOC = svc.DocumentRef("FILEID", 1000)

    async def go(self, text="/restore", user=OWNER, chat=None, chat_type="private", mid=1, doc="default", lang=None):
        parsed = parse_restore_command(text, "GuardBot")
        assert parsed is not None, text
        document = self.DOC if doc == "default" else doc
        return await self.cmd.run(parsed, chat_id=user if chat is None else chat, chat_type=chat_type, user_id=user, message_id=mid,
                                  document=document, lang=lang)

    def kinds(self):
        return [e.event_type for e in self.audit.events]


class ParserTests(unittest.TestCase):
    def test_forms(self):
        p = lambda s, b="GuardBot": parse_restore_command(s, b)  # noqa: E731
        for text in ("/restore", "/RESTORE@guardbot", "استعادة", "استعادة نسخة", "استعادة نسخة احتياطية", "استعادة نسخة احتياطي", "  /restore  "):
            self.assertEqual(p(text).action, "preview", text)
        for text in ("/restore now", "/restore confirm ABC123", "/restore  with_license"):
            self.assertEqual(p(text).action, "usage", text)

    def test_not_ours(self):
        p = lambda s, b="GuardBot": parse_restore_command(s, b)  # noqa: E731
        for text in ("/restore@OtherBot", "/restores", "/backup", "hello", "", None, 5, "x" * 101, "استعادة الان", "استعادة نسخة احتياطية الان",
                     "نسخة احتياطية", "/restore " + "a" * 200):
            self.assertIsNone(p(text), text)
        self.assertIsNone(p("/restore@GuardBot", None))


class ServiceTests(Base):
    async def test_happy_path_previews_and_writes_nothing(self):
        self.build()
        reply = await self.go()
        self.assertEqual(reply.status, "previewed")
        self.assertEqual(self.downloader.calls, [("FILEID", F.MAX_BACKUP_BYTES)])
        self.assertEqual(self.reader.calls, 1)
        self.assertEqual(self.kinds(), [RESTORE_PREVIEWED])
        self.assertIn("لم يُكتب", reply.text)
        fp = validate(good()).fingerprint.upper()
        self.assertIn(fp, reply.text)

    async def test_only_the_primary_owner_and_the_rest_get_silence(self):
        self.build()
        for who in (BACKUP, STRANGER, 5):
            self.assertIsNone(await self.go(user=who, mid=who))
            self.assertIsNone(await self.go("/restore now", user=who, mid=who + 1))
        self.assertEqual(self.downloader.calls, [])
        self.assertEqual(self.reader.calls, 0)
        self.assertNotIn(RESTORE_PREVIEWED, self.kinds())

    async def test_private_chat_only(self):
        self.build()
        self.assertIsNone(await self.go(chat=-100500, chat_type="supergroup"))
        self.assertIsNone(await self.go(chat=OWNER + 1))
        self.assertIsNone(await self.go(chat_type="group", chat=OWNER))
        self.assertEqual(self.downloader.calls, [])

    async def test_usage_and_no_file(self):
        self.build()
        self.assertEqual((await self.go("/restore now")).status, "usage")
        reply = await self.go(doc=None)
        self.assertEqual(reply.status, "no_file")
        self.assertEqual(reply.text, i18n.t("rs_usage", "ar"))
        self.assertEqual(self.downloader.calls, [])

    async def test_declared_size_is_checked_before_downloading(self):
        self.build()
        reply = await self.go(doc=svc.DocumentRef("F", F.MAX_BACKUP_BYTES + 1))
        self.assertEqual(reply.status, "too_large")
        self.assertEqual(self.downloader.calls, [])
        self.assertEqual(self.kinds(), [RESTORE_REJECTED])
        self.assertIn("code=too_large_file", self.audit.events[0].detail)

    async def test_downloader_returning_none_means_too_large(self):
        self.build(downloader=Downloader(none=True))
        self.assertEqual((await self.go()).status, "too_large")

    async def test_redelivered_update_is_silent(self):
        self.build()
        self.assertEqual((await self.go(mid=7)).status, "previewed")
        self.assertIsNone(await self.go(mid=7))
        self.assertEqual(len(self.downloader.calls), 1)

    async def test_bad_message_ids_and_file_ids(self):
        self.build()
        for mid in (None, 0, -1, True, "5"):
            self.assertEqual((await self.go(mid=mid)).status, "unavailable")
        for doc in (svc.DocumentRef("", 5), svc.DocumentRef(None, 5)):
            self.assertEqual((await self.go(doc=doc, mid=11)).status, "unavailable")
        self.assertEqual(self.downloader.calls, [])

    async def test_cooldown_then_ok(self):
        self.build()
        self.assertEqual((await self.go(mid=1)).status, "previewed")
        again = await self.go(mid=2)
        self.assertEqual(again.status, "cooldown")
        self.assertIn("21", again.text)
        self.clock.now += timedelta(seconds=21)
        self.assertEqual((await self.go(mid=3)).status, "previewed")
        self.assertEqual(len(self.downloader.calls), 2)

    async def test_one_preview_at_a_time(self):
        self.build(downloader=Downloader(good(), delay=0.05), cooldown=0)
        first = asyncio.create_task(self.go(mid=1))
        await asyncio.sleep(0.01)
        second = await self.go(mid=2)
        self.assertEqual(second.status, "busy")
        self.assertEqual((await first).status, "previewed")

    async def test_download_failure_is_reported_without_leaking_the_error(self):
        token = "123456789:" + "A" * 35
        self.build(downloader=Downloader(exc=RuntimeError(f"https://api.telegram.org/bot{token}/getFile failed")))
        reply = await self.go()
        self.assertEqual(reply.status, "download_failed")
        self.assertEqual(self.kinds(), [RESTORE_REJECTED])
        self.assertNotIn(token, repr(self.audit.events))
        self.assertNotIn(token, reply.text)

    async def test_a_hung_download_times_out(self):
        original = svc.DOWNLOAD_TIMEOUT
        svc.DOWNLOAD_TIMEOUT = 0.05
        try:
            self.build(downloader=Downloader(good(), delay=1.0))
            self.assertEqual((await self.go()).status, "download_failed")
        finally:
            svc.DOWNLOAD_TIMEOUT = original

    async def test_invalid_files_are_rejected_with_a_closed_code_and_audited(self):
        cases = {b"not json": ("bad_json", "rs_bad_file"), good().replace(b"Second group", b"Second grouq"): ("checksum_mismatch", "rs_corrupt"),
                 edited(lambda d: d["tables"].pop("group_reports")): ("incomplete", "rs_incomplete"),
                 edited(lambda d: d["tables"]["group_settings"][0].update(language="fr")): ("bad_rule", "rs_bad_content")}
        for i, (data, (code, key)) in enumerate(cases.items()):
            self.build(data=data)
            reply = await self.go(mid=i + 1)
            self.assertEqual(reply.status, "invalid", code)
            self.assertEqual(self.kinds(), [RESTORE_REJECTED])
            self.assertIn(f"code={code}", self.audit.events[0].detail)
            self.assertEqual(self.reader.calls, 0)                      # an invalid file never reaches the database
            self.assertIn(i18n.t(key, "ar", where="x").split("(")[0].strip()[:12], reply.text)

    async def test_schema_newer_than_the_app_is_refused(self):
        self.build(schema=9)
        self.assertEqual((await self.go()).status, "invalid")
        self.assertIn("code=schema_too_new", self.audit.events[0].detail)

    async def test_a_secret_in_the_file_is_refused_and_never_echoed(self):
        data = edited(lambda d: d["tables"]["group_reports"][0].update(reason=f"x {SECRET}"))
        self.build(data=data, secrets=(SECRET,))
        reply = await self.go()
        self.assertEqual(reply.status, "invalid")
        self.assertNotIn(SECRET, reply.text)
        self.assertNotIn(SECRET, repr(self.audit.events))
        self.assertIn("group_reports", reply.text)

    async def test_hostile_table_names_are_not_echoed(self):
        self.build(data=edited(lambda d: d["tables"].update({"evil<b>x": []})))
        reply = await self.go()
        self.assertEqual(reply.status, "invalid")
        self.assertNotIn("evil", reply.text)
        self.assertNotIn("evil", repr(self.audit.events))

    async def test_state_read_failure(self):
        self.build(reader=StateReader(exc=RuntimeError("db down")))
        reply = await self.go()
        self.assertEqual(reply.status, "failed")
        self.assertEqual(self.kinds(), [RESTORE_REJECTED])
        self.assertIn("code=state_failed", self.audit.events[0].detail)

    async def test_claim_failure_and_missing_collaborators(self):
        self.build(claims=BrokenClaims())
        self.assertEqual((await self.go()).status, "unavailable")
        self.build(downloader=None)
        self.service._downloader = None
        self.assertEqual((await self.go()).status, "unavailable")
        self.build()
        self.service._reader = None
        self.assertEqual((await self.go()).status, "unavailable")

    async def test_audit_carries_counts_and_the_fingerprint_only(self):
        self.build()
        await self.go()
        event = self.audit.events[0]
        self.assertLess(len(event.detail), 120)
        for leaked in ("مجموعة", "Second", "spam", "444", "settings"):
            self.assertNotIn(leaked, repr(event))
        self.assertIn(validate(good()).fingerprint, event.detail)
        self.assertEqual((event.actor_telegram_id, event.target_id, event.result), (OWNER, "restore", "applied"))

    async def test_the_service_holds_no_store_to_write_to(self):
        self.build()
        self.assertEqual(set(vars(self.service)), {"_downloader", "_reader", "_perm", "_claims", "_audit", "_secrets", "_schema",
                                                   "_clock", "_cooldown", "_max", "_lock", "_last", "_pending", "_executor",
                                                   "_confirm_cooldown", "_last_confirm"})
        self.assertIsNone(self.service._executor)                # the PREVIEW path of this fixture has no executor at all
        await self.go()
        self.assertEqual(self.kinds(), [RESTORE_PREVIEWED])      # the only side effects: a claim and ONE audit row

    async def test_command_failures_become_a_failed_reply(self):
        self.build()

        async def boom(*a, **k):
            raise RuntimeError("x")

        self.service.preview = boom
        self.assertEqual((await self.go()).status, "failed")

    async def test_english_reply(self):
        self.build()
        self.assertIn("nothing was written", (await self.go(lang="en")).text)

    async def test_the_validation_runs_off_the_event_loop(self):
        self.build()
        import threading
        seen = []
        original = V.validate_backup

        def spy(*a, **k):
            seen.append(threading.current_thread() is threading.main_thread())
            return original(*a, **k)

        svc.validate_backup = spy
        try:
            await self.go()
        finally:
            svc.validate_backup = original
        self.assertEqual(seen, [False])


class PermissionTests(Base):
    async def test_restore_is_owner_only(self):
        self.assertIn(Permission.RESTORE, OWNER_ONLY)
        self.build()
        self.assertTrue((await self.stack.perm.check_global(OWNER, Permission.RESTORE)).allowed)
        for who in (BACKUP, STRANGER):
            self.assertFalse((await self.stack.perm.check_global(who, Permission.RESTORE)).allowed)


# ------------------------------------------------------------------------------------------------ handler
class Chat:
    def __init__(self, type_="private", id_=OWNER):
        self.type, self.id = type_, id_


class Msg:
    def __init__(self, text=None, caption=None, document=None, reply=None, chat_type="private", user=OWNER, is_bot=False, mid=1):
        self.text, self.caption, self.document, self.reply_to_message = text, caption, document, reply
        self.chat = Chat(chat_type, user)
        self.from_user = NS(id=user, is_bot=is_bot, language_code="ar")
        self.message_id = mid
        self.sent = []

    async def answer(self, text):
        self.sent.append(text)


class FakeBot:
    async def me(self):
        return NS(username="GuardBot")


def Doc(file_id="F1", size=500):
    return NS(file_id=file_id, file_size=size)


class HandlerTests(unittest.IsolatedAsyncioTestCase):
    async def test_matching_forms(self):
        m = oh.match_restore_command
        self.assertEqual((await m(Msg(text="/restore"), FakeBot())).action, "preview")
        self.assertEqual((await m(Msg(caption="/restore", document=Doc()), FakeBot())).action, "preview")
        self.assertEqual((await m(Msg(caption="استعادة نسخة", document=Doc()), FakeBot())).action, "preview")
        self.assertEqual((await m(Msg(text="/restore@GuardBot"), FakeBot())).action, "preview")
        self.assertIsNone(await m(Msg(text="/restore@Other"), FakeBot()))
        self.assertIsNone(await m(Msg(text="/restore", chat_type="supergroup"), FakeBot()))
        self.assertIsNone(await m(Msg(text="/restore", is_bot=True), FakeBot()))
        self.assertIsNone(await m(Msg(text=None, caption=None, document=Doc()), FakeBot()))
        self.assertIsNone(await m(Msg(text="hello"), FakeBot()))
        self.assertIsNone(await m(Msg(caption="hello", document=Doc()), FakeBot()))

    async def test_document_resolution(self):
        d = oh._document_of
        self.assertEqual(d(Msg(caption="/restore", document=Doc("A", 10))), svc.DocumentRef("A", 10))
        self.assertEqual(d(Msg(text="/restore", reply=Msg(document=Doc("B", 20)))), svc.DocumentRef("B", 20))
        self.assertEqual(d(Msg(caption="/restore", document=Doc("A", 10), reply=Msg(document=Doc("B")))).file_id, "A")   # the attached file wins
        self.assertIsNone(d(Msg(text="/restore")))
        self.assertIsNone(d(Msg(text="/restore", reply=Msg(text="no file"))))
        self.assertEqual(d(Msg(caption="x", document=Doc("C", None))), svc.DocumentRef("C", None))
        self.assertEqual(d(Msg(caption="x", document=Doc("C", True))).size, None)
        self.assertIsNone(d(Msg(caption="x", document=NS(file_id=5, file_size=1))))

    async def test_execute_replies_and_passes_the_document(self):
        calls = []

        class Service:
            async def run(self, parsed, **kw):
                calls.append(kw)
                return NS(status="previewed", text="OK")

        services = NS(owner_restore=Service(), settings=NS(default_language="ar"))
        msg = Msg(caption="/restore", document=Doc("Z", 9), mid=42)
        parsed = await oh.match_restore_command(msg, FakeBot())
        self.assertEqual(await oh.execute_restore(msg, parsed, services=services), "previewed")
        self.assertEqual(msg.sent, ["OK"])
        self.assertEqual((calls[0]["document"], calls[0]["message_id"], calls[0]["user_id"]), (svc.DocumentRef("Z", 9), 42, OWNER))

    async def test_execute_is_silent_without_a_service_or_reply(self):
        msg = Msg(text="/restore")
        parsed = await oh.match_restore_command(msg, FakeBot())
        self.assertIsNone(await oh.execute_restore(msg, parsed, services=NS(owner_restore=None, settings=NS(default_language="ar"))))

        class Silent:
            async def run(self, parsed, **kw):
                return None

        self.assertIsNone(await oh.execute_restore(msg, parsed, services=NS(owner_restore=Silent(), settings=NS(default_language="ar"))))
        self.assertEqual(msg.sent, [])

        class Boom:
            async def run(self, parsed, **kw):
                raise RuntimeError("x")

        self.assertIsNone(await oh.execute_restore(msg, parsed, services=NS(owner_restore=Boom(), settings=NS(default_language="ar"))))


# ------------------------------------------------------------------------------------------------ messages
class MessageTests(unittest.TestCase):
    def test_keys_in_both_languages(self):
        ar = {k for k in i18n.MESSAGES["ar"] if k.startswith("rs_")}
        self.assertEqual(ar, {k for k in i18n.MESSAGES["en"] if k.startswith("rs_")})
        self.assertGreaterEqual(len(ar), 30)

    def test_every_template_formats_with_its_placeholders(self):
        for lang in ("ar", "en"):
            for key, text in i18n.MESSAGES[lang].items():
                if key.startswith("rs_"):
                    names = set(re.findall(r"{(\w+)}", text))
                    i18n.t(key, lang, **{n: "1" for n in names})

    def test_html_in_values_is_escaped(self):
        self.assertNotIn("<b>", i18n.t("rs_bad_content", "ar", where="<b>x"))

    def test_warning_keys_exist_for_every_warning_code(self):
        for code in (P.W_OLD_BACKUP, P.W_REMOVES_ROWS, P.W_NEW_GROUPS, P.W_KEPT_GROUPS, P.W_LICENSE_DIFFERS, P.W_OLDER_DEFAULTS):
            for lang in ("ar", "en"):
                self.assertIn(f"rs_w_{code}", i18n.MESSAGES[lang])
        for policy in (P.REPLACE_GROUP, P.REPLACE_ALL):
            self.assertIn(f"rs_line_{policy}", i18n.MESSAGES["ar"])


# ------------------------------------------------------------------------------------------------ guards
class ScopeGuards(unittest.TestCase):
    NEW = ("validate.py", "preview.py", "postgres_state.py", "restore_service.py", "restore_command.py")

    def text(self, name):
        return (SRC / "backup" / name).read_text(encoding="utf-8")

    def test_no_new_migration_and_no_write_sql(self):
        self.assertEqual([v for v, _ in discover()][-1], "0013_member_activity_stats")
        pattern = re.compile(r"\b(INSERT\s+INTO|UPDATE\s+\w+\s+SET|DELETE\s+FROM|TRUNCATE|DROP\s+TABLE|ALTER\s+TABLE|CREATE\s+TABLE)\b", re.I)
        for name in self.NEW:
            self.assertIsNone(pattern.search(self.text(name)), name)

    def test_the_state_reader_only_selects_and_only_fetches(self):
        from guardian.backup import postgres_state as ps
        banned = {"execute", "executemany", "fetchrow", "fetchval", "copy_records_to_table"}
        for node in ast.walk(ast.parse(self.text("postgres_state.py"))):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                self.assertNotIn(node.func.attr, banned)
        for table in P.COUNTED_PER_GROUP:
            self.assertTrue(ps.count_sql(table).startswith("SELECT "))
        for table in P.GLOBAL_REPLACED:
            self.assertTrue(ps.global_count_sql(table).startswith("SELECT "))
        self.assertTrue(ps.GROUPS_SQL.startswith("SELECT ") and ps.DEFAULTS_VERSION_SQL.startswith("SELECT "))
        for bad in ("security_audit_log", "x; DROP", "telegram_groups", "settings_templates"):
            with self.assertRaises(ValueError):
                ps.count_sql(bad)
        with self.assertRaises(ValueError):
            ps.global_count_sql("group_settings")
        self.assertIn("repeatable_read", self.text("postgres_state.py"))
        self.assertIn("readonly=True", self.text("postgres_state.py"))

    def test_no_aiogram_asyncpg_or_telegram_sending_in_the_new_modules(self):
        for name in self.NEW:
            text = self.text(name)
            imports = "\n".join(l for l in text.splitlines() if re.match(r"\s*(from|import)\s", l))
            for forbidden in ("aiogram", "asyncpg", "owner_hub", "bot.", "hub_transport"):
                self.assertNotIn(forbidden, imports, (name, forbidden))
            code = re.sub(r'""".*?"""', "", text, flags=re.DOTALL)
            for forbidden in ("send_document", "send_message", "list_all"):
                self.assertNotIn(forbidden, code, (name, forbidden))

    def test_the_pure_modules_touch_no_database_at_all(self):
        for name in ("validate.py", "preview.py", "restore_command.py"):
            imports = "\n".join(l for l in self.text(name).splitlines() if re.match(r"\s*(from|import)\s", l))
            self.assertIsNone(re.search(r"postgres|memory_store|\.store\b|\bpool\b|\bdb\b", imports), name)

    def test_the_download_transport_only_reads(self):
        text = (SRC / "bot" / "restore_transport.py").read_text(encoding="utf-8")
        self.assertIn("get_file", text)
        self.assertIn("download_file", text)
        for forbidden in ("send_", "guardian.backup", "from ..backup", "delete_", "edit_"):
            self.assertNotIn(forbidden, text)

    def test_the_command_is_wired_for_the_owner_private_chat_only(self):
        router = (SRC / "bot" / "routers" / "owner_panel.py").read_text(encoding="utf-8")
        self.assertIn("match_restore_command", router)
        self.assertIn("owner_restore", (SRC / "services.py").read_text(encoding="utf-8"))
        app = (SRC / "app.py").read_text(encoding="utf-8")
        self.assertIn("RestorePreviewService(", app)
        self.assertNotIn("restore", (SRC / "bot" / "commands_menu.py").read_text(encoding="utf-8").lower())   # no menu entry

    def test_the_execution_is_confined_to_restore_and_its_postgres_writer(self):
        """6.9b added `restore.py` (pure orchestration) and `postgres_restore.py` (the only writer); nothing else may mention the option."""
        self.assertTrue((SRC / "backup" / "restore.py").exists())
        for path in (SRC / "backup").glob("*.py"):
            code = re.sub(r'""".*?"""|#.*', "", path.read_text(encoding="utf-8"), flags=re.DOTALL)
            if "with_license" in code:
                self.assertIn(path.name, {"restore.py", "restore_service.py", "restore_command.py"}, path.name)

    def test_only_the_handler_and_the_app_import_the_backup_package(self):
        users = sorted(str(p.relative_to(SRC)) for p in SRC.rglob("*.py")
                       if "backup" not in p.relative_to(SRC).parts[:1] and re.search(r"\bguardian\.backup\b|from \.+backup\b|from \.backup", p.read_text(encoding="utf-8")))
        self.assertEqual(users, ["app.py", "bot/owner_panel_handler.py"])


if __name__ == "__main__":
    unittest.main()
