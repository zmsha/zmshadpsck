import types
import unittest

from guardian.bot.chat_info import AiogramChatInfo
from guardian.errors import TelegramLookupFailed
from guardian.telegram_rights import (BotCapability, ChatMemberInfo, check_bot_capabilities,
                                      member_info_from_telegram)


def tg(status, **flags):
    return types.SimpleNamespace(status=types.SimpleNamespace(value=status), **flags)


class ParseTests(unittest.TestCase):
    def test_creator_has_everything_even_without_flags(self):
        info = member_info_from_telegram(tg("creator"))
        self.assertTrue(info.is_creator and info.can_restrict() and info.can_delete_messages)

    def test_admin_flags_and_none_means_no(self):
        info = member_info_from_telegram(tg("administrator", can_delete_messages=True, can_restrict_members=None))
        self.assertTrue(info.can_delete_messages)
        self.assertFalse(info.can_restrict_members)
        self.assertFalse(info.can_pin_messages)  # attribute missing entirely
        self.assertTrue(info.is_admin)

    def test_plain_member_and_unknown(self):
        for status in ("member", "restricted", "left", "kicked"):
            info = member_info_from_telegram(tg(status, can_restrict_members=True))
            self.assertFalse(info.is_admin or info.can_restrict(), status)
        self.assertEqual(member_info_from_telegram(object()).status, "unknown")

    def test_plain_string_status(self):
        self.assertTrue(member_info_from_telegram(types.SimpleNamespace(status="creator")).is_creator)


class FakeProvider:
    def __init__(self, info=None, error=None):
        self.info, self.error = info, error

    async def get_bot_member(self, chat_id):
        if self.error:
            raise self.error
        return self.info


class CapabilityTests(unittest.IsolatedAsyncioTestCase):
    async def test_ok_when_all_rights_present(self):
        p = FakeProvider(ChatMemberInfo("administrator", True, True, True))
        r = await check_bot_capabilities(p, -1, BotCapability.DELETE_MESSAGES, BotCapability.RESTRICT_MEMBERS)
        self.assertTrue(r.ok)
        self.assertIsNone(r.user_message_key())

    async def test_missing_rights_listed_with_generic_message(self):
        p = FakeProvider(ChatMemberInfo("administrator", True, False, False))
        r = await check_bot_capabilities(p, -1, BotCapability.DELETE_MESSAGES, BotCapability.RESTRICT_MEMBERS,
                                         BotCapability.PIN_MESSAGES)
        self.assertFalse(r.ok)
        self.assertEqual(set(r.missing), {BotCapability.RESTRICT_MEMBERS, BotCapability.PIN_MESSAGES})
        self.assertEqual(r.user_message_key(), "bot_missing_rights")

    async def test_bot_as_plain_member_has_no_capabilities(self):
        r = await check_bot_capabilities(FakeProvider(ChatMemberInfo("member")), -1, BotCapability.DELETE_MESSAGES)
        self.assertFalse(r.ok)

    async def test_lookup_failure_fails_closed_with_safe_message(self):
        for err in (TelegramLookupFailed("x"), RuntimeError("secret detail")):
            r = await check_bot_capabilities(FakeProvider(error=err), -1, BotCapability.DELETE_MESSAGES)
            self.assertFalse(r.ok)
            self.assertTrue(r.lookup_failed)
            self.assertEqual(r.user_message_key(), "bot_check_failed")


class RetryAfter(Exception):
    def __init__(self, retry_after):
        super().__init__("flood")
        self.retry_after = retry_after


class FakeBot:
    def __init__(self, script):
        self.script = list(script)
        self.calls = 0

    async def me(self):
        return types.SimpleNamespace(id=777)

    async def get_chat_member(self, chat_id, user_id):
        self.calls += 1
        item = self.script.pop(0)
        if isinstance(item, Exception):
            raise item
        return item


class AdapterTests(unittest.IsolatedAsyncioTestCase):
    def make(self, script, ttl=30.0):
        self.t = 0.0
        self.slept = []

        async def sleep(sec):
            self.slept.append(sec)

        self.bot = FakeBot(script)
        return AiogramChatInfo(self.bot, ttl=ttl, clock=lambda: self.t, sleep=sleep)

    async def test_cache_and_fresh_bypass(self):
        a = self.make([tg("administrator", can_restrict_members=True)] * 3)
        await a.get_member(-1, 5)
        await a.get_member(-1, 5)
        self.assertEqual(self.bot.calls, 1)
        await a.get_member(-1, 5, fresh=True)  # authorization path never uses the cache
        self.assertEqual(self.bot.calls, 2)
        self.t += 31
        await a.get_member(-1, 5)
        self.assertEqual(self.bot.calls, 3)

    async def test_cache_is_per_chat_and_user(self):
        a = self.make([tg("creator"), tg("member")])
        self.assertTrue((await a.get_member(-1, 5)).is_creator)
        self.assertFalse((await a.get_member(-2, 5)).is_admin)

    async def test_one_bounded_retry_on_short_retry_after(self):
        a = self.make([RetryAfter(2), tg("member")])
        info = await a.get_member(-1, 5)
        self.assertEqual(info.status, "member")
        self.assertEqual(self.slept, [2.0])

    async def test_long_retry_after_or_other_errors_fail_closed_without_leaking(self):
        for script in ([RetryAfter(60)], [RuntimeError("token 123456789:AAAAAAAAAAAAAAAAAAAAAAAAAAAA leaked")],
                       [RetryAfter(1), RetryAfter(1)]):
            a = self.make(script)
            with self.assertRaises(TelegramLookupFailed) as cm:
                await a.get_member(-1, 5)
            self.assertNotIn("AAAA", str(cm.exception))

    async def test_bot_member_uses_bot_identity(self):
        a = self.make([tg("administrator", can_delete_messages=True)])
        self.assertTrue((await a.get_bot_member(-1)).can_delete_messages)


if __name__ == "__main__":
    unittest.main()
