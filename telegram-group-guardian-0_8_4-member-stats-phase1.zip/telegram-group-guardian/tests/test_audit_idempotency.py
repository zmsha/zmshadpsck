import unittest
from datetime import datetime, timedelta, timezone

from guardian.audit import InMemorySecurityAudit, SecurityEvent, make_event, record_safely, sanitize_text
from guardian.idempotency import InMemoryIdempotency, PurgingClaims, operation_key, update_key

NOW = datetime(2026, 10, 29, 12, tzinfo=timezone.utc)


class SanitizeTests(unittest.TestCase):
    def test_redacts_tokens_dsn_and_explicit_secrets(self):
        text = ("failed bot123456789:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA at postgresql://u:hunter2pw@h/db "
                "and secret-xyz")
        out = sanitize_text(text, secrets=("secret-xyz",))
        for leaked in ("AAAAAAAA", "hunter2pw", "secret-xyz"):
            self.assertNotIn(leaked, out)

    def test_control_chars_length_and_blank(self):
        self.assertEqual(sanitize_text("a\x00b\nc\td"), "a b c d")
        self.assertEqual(len(sanitize_text("x" * 1000)), 300)
        self.assertIsNone(sanitize_text("   \n "))
        self.assertIsNone(sanitize_text(None))

    def test_event_detail_is_sanitized_and_time_utc(self):
        e = SecurityEvent("t", NOW, detail="a\x07b " + "y" * 999)
        self.assertNotIn("\x07", e.detail)
        self.assertLessEqual(len(e.detail), 300)
        with self.assertRaises(ValueError):
            SecurityEvent("t", datetime(2026, 1, 1))  # naive time rejected


class AuditTests(unittest.IsolatedAsyncioTestCase):
    async def test_for_group_filters_and_limits(self):
        a = InMemorySecurityAudit()
        for i in range(5):
            await a.record(make_event("e", group_id=-1, detail=str(i), now=NOW))
        await a.record(make_event("e", group_id=-2, now=NOW))
        self.assertEqual([e.detail for e in await a.for_group(-1, limit=2)], ["3", "4"])
        self.assertEqual(len(await a.for_group(-2)), 1)

    async def test_record_safely_swallows_errors(self):
        class Broken:
            async def record(self, event):
                raise RuntimeError("db down")

        await record_safely(Broken(), make_event("e", now=NOW))
        await record_safely(None, make_event("e", now=NOW))


class IdempotencyTests(unittest.IsolatedAsyncioTestCase):
    async def test_claim_once(self):
        s = InMemoryIdempotency()
        self.assertTrue(await s.claim(update_key(5)))
        self.assertFalse(await s.claim(update_key(5)))
        self.assertTrue(await s.claim(update_key(6)))

    async def test_invalid_keys_rejected(self):
        s = InMemoryIdempotency()
        for bad in ("", "a b", "x" * 201, None, "a;b"):
            with self.assertRaises(ValueError):
                await s.claim(bad)
        with self.assertRaises(ValueError):
            operation_key("sanction", "a b")
        self.assertEqual(operation_key("sanction", -1001, 55, 9), "op:sanction:-1001:55:9")

    async def test_purge_and_wrapper(self):
        s = InMemoryIdempotency()
        await s.claim("old", NOW - timedelta(days=10))
        await s.claim("new", NOW)
        self.assertEqual(await s.purge_older_than(NOW - timedelta(days=7)), 1)
        self.assertFalse(await s.claim("new"))
        w = PurgingClaims(InMemoryIdempotency(), every=2)
        await w.claim("k1", NOW - timedelta(days=30))
        await w.claim("k2", NOW)  # triggers purge of k1
        self.assertTrue(await w.claim("k1", NOW))  # k1 was purged, so it can be claimed again


if __name__ == "__main__":
    unittest.main()
