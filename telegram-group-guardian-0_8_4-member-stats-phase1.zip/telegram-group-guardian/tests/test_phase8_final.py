"""Phase 8 / part 8.4 (the closing part): consistency tests for the FINAL delivery.

Documentation + packaging only. Nothing here exercises Telegram, aiogram, FastAPI, asyncpg, PostgreSQL or Render:
those were never tried (see FINAL_REPORT.md). What these tests pin is that the closing documents say what the code
and the test-suite actually are, and that the delivered tree is complete.
"""
from __future__ import annotations

import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src" / "guardian"

VERSION = "0.8.4-phase8-complete"
# The exact result of the last full run, as recorded in FINAL_REPORT.md. Update them (and the report) together
# whenever a test is added: this is what stops the report from quietly drifting away from the suite.
TOTAL, PASSED, SKIPPED = 2822, 2815, 7


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def section(text: str, number: int) -> str:
    """The body of '## <number>. ...' up to the next '## ' heading."""
    match = re.search(rf"(?m)^## {number}\. .*$", text)
    assert match, f"section {number} is missing"
    rest = text[match.end():]
    nxt = re.search(r"(?m)^## ", rest)
    return rest[: nxt.start()] if nxt else rest


class FinalReportTests(unittest.TestCase):
    def setUp(self):
        self.text = read("FINAL_REPORT.md")

    def test_the_header_names_the_final_version(self):
        self.assertIn(VERSION, self.text.splitlines()[0])

    def test_the_ten_sections_exist_in_order(self):
        positions = [self.text.index(f"\n## {n}. ") for n in range(1, 11)]
        self.assertEqual(positions, sorted(positions))

    def test_the_verdict_is_honest(self):
        self.assertIn("ليست مُثبَتة للإنتاج", self.text)
        # "ready for production" may only ever appear negated
        self.assertNotRegex(self.text, r"(?<!غير )(?<!ليس )(?<!ليست )جاهز(ة)? للإنتاج")

    def test_the_not_tried_section_names_every_real_service(self):
        body = section(self.text, 4)
        for name in ("aiogram", "FastAPI", "asyncpg", "PostgreSQL", "Telegram", "Render", "PyPI"):
            with self.subTest(name=name):
                self.assertIn(name, body)

    def test_the_numbers_match_the_last_recorded_run(self):
        body = section(self.text, 3)
        self.assertIn(f"{TOTAL} اختبارًا", body)
        self.assertIn(f"{PASSED} نجح", body)
        self.assertIn(f"{SKIPPED} متخطاة", body)

    def test_the_skipped_tests_are_exactly_the_http_ones(self):
        http_tests = len(re.findall(r"(?m)^    (?:async )?def test_", (ROOT / "tests" / "test_app_integration.py")
                                    .read_text(encoding="utf-8")))
        self.assertEqual(http_tests, SKIPPED)

    def test_the_structural_numbers_are_the_real_ones(self):
        migrations = sorted((SRC / "db" / "sql").glob("*.sql"))
        self.assertEqual(len(migrations), 13)
        self.assertIn("`0001–0013`", self.text)
        from guardian.moderation.commands import Command
        self.assertEqual(len(list(Command)), 31)
        self.assertIn("31 أمرًا", self.text)

    def test_every_file_the_report_names_exists(self):
        names = re.findall(r"`([\w./-]+\.(?:md|py|yaml|toml|txt|sql|example))`", self.text)
        self.assertGreater(len(names), 10)
        for name in sorted(set(names)):
            with self.subTest(name=name):
                candidates = (ROOT / name, ROOT / "tests" / name, SRC / name, ROOT / "docs" / name)
                self.assertTrue(any(c.exists() for c in candidates), name)

    def test_the_owner_steps_are_numbered_and_in_a_safe_order(self):
        body = section(self.text, 7)
        numbers = [int(n) for n in re.findall(r"(?m)^(\d+)\. ", body)]
        self.assertEqual(numbers, list(range(1, len(numbers) + 1)))
        self.assertGreaterEqual(len(numbers), 8)
        order = ["pip install", "unittest", "check-config", "migrate", "getWebhookInfo"]
        positions = [body.index(word) for word in order]
        self.assertEqual(positions, sorted(positions), "install -> tests -> config -> migrate -> real webhook")
        # nothing goes to production before the real checks
        self.assertLess(body.index("migrate"), body.index("Render"))

    def test_the_pre_production_checklist_has_the_required_items(self):
        body = section(self.text, 8)
        self.assertGreaterEqual(len(re.findall(r"(?m)^- \[ \] ", body)), 5)
        for word in ("الاعتماديات", "الاختبارات", "الهجرات", "توكن جديد", "الأوامر الأساسية"):
            with self.subTest(word=word):
                self.assertIn(word, body)

    def test_the_open_decisions_are_stated_not_hidden(self):
        body = section(self.text, 6)
        for word in ("license_audit_log", "trace_id", "dry_run", "30 يومًا"):
            with self.subTest(word=word):
                self.assertIn(word, body)


class HandoffTests(unittest.TestCase):
    def test_the_final_handoff_is_brief_and_points_to_the_report_and_the_history(self):
        lines = read("HANDOFF.md").splitlines()
        self.assertLessEqual(len(lines), 120)
        self.assertIn(VERSION, lines[0])
        text = "\n".join(lines)
        for ref in ("FINAL_REPORT.md", "docs/HANDOFF_HISTORY.md", "PHASE8_PLAN.md", "docs/LOCAL_VERIFY.md"):
            with self.subTest(ref=ref):
                self.assertTrue(ref in text, f"HANDOFF.md must mention {ref}")
        self.assertTrue("python3 -m unittest discover -s tests" in text, "HANDOFF.md must give the test command")

    def test_the_old_handoff_was_kept_not_thrown_away(self):
        history = read("docs/HANDOFF_HISTORY.md")
        self.assertGreater(len(history), 50_000)
        for marker in ("0.8.3-phase8-part3", "6.10ب", "0.5.9-phase5-complete", "0.4.8-phase4-complete"):
            with self.subTest(marker=marker):
                self.assertTrue(marker in history, f"the archive lost {marker}")


class PackageCompletenessTests(unittest.TestCase):
    REQUIRED = (
        "README.md", "FINAL_REPORT.md", "HANDOFF.md", "CHANGELOG.md", "TEST_REPORT.md", "PROJECT_SUMMARY.md",
        "PROGRESS.md", "PROJECT_STRUCTURE.md", "PHASE8_PLAN.md", "requirements.txt", "requirements-dev.txt",
        ".env.example", ".gitignore", "render.yaml", "pyproject.toml",
        "docs/BACKUP_RESTORE.md", "docs/DEPLOY_RENDER.md", "docs/LOCAL_VERIFY.md", "docs/TEST_MATRIX.md",
        "docs/TROUBLESHOOTING.md", "docs/HANDOFF_HISTORY.md",
    )

    def test_every_required_file_is_present(self):
        for rel in self.REQUIRED:
            with self.subTest(rel=rel):
                self.assertTrue((ROOT / rel).is_file(), rel)

    def test_the_migrations_are_consecutive_from_0001(self):
        numbers = [int(p.name[:4]) for p in sorted((SRC / "db" / "sql").glob("*.sql"))]
        self.assertEqual(numbers, list(range(1, 14)))

    def test_no_real_env_file_and_the_gitignore_covers_the_usual_leaks(self):
        self.assertFalse((ROOT / ".env").exists())
        ignore = read(".gitignore").splitlines()
        for pattern in (".env", "__pycache__/", "*.pyc", "*.zip"):
            with self.subTest(pattern=pattern):
                self.assertIn(pattern, ignore)

    def test_every_source_directory_with_python_files_is_a_package(self):
        for directory in sorted({p.parent for p in SRC.rglob("*.py")}):
            if "__pycache__" in directory.parts:
                continue
            with self.subTest(directory=str(directory.relative_to(ROOT))):
                self.assertTrue((directory / "__init__.py").is_file())

    def test_the_local_verify_guide_counts_the_seven_skipped_tests_not_five(self):
        # 8.1 added two HTTP tests to test_app_integration; the guide still said five until 8.4 fixed it.
        guide = read("docs/LOCAL_VERIFY.md")
        self.assertIn("السبعة", guide)
        self.assertNotIn("الخمسة", guide)
        self.assertNotRegex(guide, r"\b5 متخطاة")


if __name__ == "__main__":
    unittest.main()
