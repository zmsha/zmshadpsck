"""Every Arabic command accepts every spelling of alef / hamza, ta marbuta / ha and ya / alef maqsura (part 9.5).

`أ إ آ ا` are one letter, `ة ه` are one letter and `ي ى` are one letter for the command parsers. This file takes a corpus of
messages, each of which IS a command, and re-spells them: every single letter swapped for every alternative, plus whole-message
re-spellings (all alefs as one form, all ta marbuta as ha...) and a few seeded mixes. A re-spelt message must be recognised as
exactly the same command. A parser that compared raw text instead of `fold_arabic` fails here. Pure parsers; no I/O."""
from __future__ import annotations

import itertools
import random
import unittest

from guardian.backup.command import parse_backup_command
from guardian.backup.restore_command import parse_restore_command
from guardian.bot.basic_commands import parse_basic_command
from guardian.licensing.commands import parse_license_command
from guardian.moderation import commands as mc
from guardian.moderation.commands import parse_command
from guardian.moderation.filter_phrases import parse_filter_phrase
from guardian.owner_panel.api_check_commands import parse_api_check_command
from guardian.owner_panel.command import parse_owner_command
from guardian.owner_panel.default_words_commands import parse_default_words_command
from guardian.owner_panel.sandbox_commands import parse_sandbox_command
from guardian.owner_panel.template_commands import parse_template_command

GROUPS = (("ا", "أ", "إ", "آ"), ("ه", "ة"), ("ي", "ى"))
FAMILY = {ch: group for group in GROUPS for ch in group}
MAX_PER_MESSAGE = 400


def respellings(text: str) -> set[str]:
    out: set[str] = set()
    for i, ch in enumerate(text):                        # one letter at a time
        for alt in FAMILY.get(ch, ()):
            out.add(text[:i] + alt + text[i + 1:])
    for group in GROUPS:                                 # the whole message in one form
        for alt in group:
            out.add("".join(alt if c in group else c for c in text))
    rng = random.Random(len(text) * 7919 + sum(map(ord, text)) % 1000)
    for _ in range(6):                                   # seeded mixes
        out.add("".join(rng.choice(FAMILY[c]) if c in FAMILY else c for c in text))
    out.discard(text)
    return set(sorted(out)[:MAX_PER_MESSAGE])


def mod_key(result):
    return None if result is None else (result.command, result.arabic, len(result.args))


def action_key(result):
    return None if result is None else getattr(result, "action", None) or getattr(result, "command", None) or type(result).__name__


def owner_key(result):
    return None if result is None else "owner"


def filter_key(result):
    return None if result is None else tuple(result[:2]) if result[:1] == ("adult",) else tuple(result[:2])


class VariantTests(unittest.TestCase):
    def check(self, name, parse, key, messages):
        self.assertTrue(messages, name)
        checked = 0
        for message in messages:
            base = key(parse(message))
            self.assertIsNotNone(base, f"{name}: the base message is not a command: {message!r}")
            for variant in respellings(message):
                checked += 1
                self.assertEqual(key(parse(variant)), base, f"{name}: {variant!r} (from {message!r}) was not read as the same command")
        self.assertGreater(checked, len(messages))

    # ------------------------------------------------------------------ moderation (every alias of every command)
    def test_every_moderation_alias_in_every_spelling(self):
        suffixes = ("", " @username1", " 123456", " media", " الوسائط", " 30", " تفعيل", " عرض", " الاسبوع", " الاعدادات", " ai off",
                    " اعضاء", " رمز", " csv", " البلاغات", " 5 ", " المشرف")
        found: dict[mc.Command, list[str]] = {}
        for cmd, aliases in mc._ARABIC_ALIASES.items():
            for alias in aliases:
                for suffix in suffixes:
                    text = alias + suffix.rstrip()
                    if parse_command(text, has_reply=True) is not None and parse_command(text, has_reply=True).command is cmd:
                        found.setdefault(cmd, []).append(text)
                        break
                else:
                    self.fail(f"no accepted form found for the alias {alias!r} of {cmd}")
        self.assertEqual(set(found), set(mc._ARABIC_ALIASES))
        messages = [m for ms in found.values() for m in ms]
        self.check("moderation", lambda t: parse_command(t, has_reply=True), mod_key, messages)

    def test_moderation_with_a_target_and_without_a_reply(self):
        self.check("moderation-target", parse_command, mod_key, [
            "حظر @username1", "كتم 123456 ساعة", "الغاء الحظر @username1", "فك الكتم 12345", "رفع الحظر @username1", "طرد @username1", "اطرد 123456",
            "تحذير @username1 سبب", "انذار @username1", "مسح التحذيرات @username1", "حذف التحذيرات 1234", "الغاء التحذيرات @username1",
            "معلومات @username1", "وثق @username1", "الغاء التوثيق @username1", "سحب الثقة @username1", "وثق نطاق example.com",
            "ايدي", "الايدي", "معرفي", "المشرفين", "الادمنية", "الغاء التثبيت", "فك التثبيت", "الغاء تثبيت", "الموثوقين",
            "قائمة الثقة", "قائمة الموثوقين", "اعدادات المجموعة", "عرض الاعدادات", "لوحة التحكم", "لوحة الاعدادات",
            "تنظيف 20", "مسح الرسائل 20", "حذف الرسائل 20 تاكيد", "قفل الوسائط", "اقفل الكل", "فتح الملصقات", "الغاء القفل النص",
            "فك القفل الاستطلاعات", "الوضع البطيء 30", "وضع بطئ 10", "مكافحة الفيضان تفعيل", "مضاد الفيضان ايقاف", "منع الفيضان 6 10",
            "اعدادات الحماية", "ضبط الحماية فلتر ai off", "حماية فلتر صور تعطيل", "الحماية الروابط تشغيل", "الترحيب عرض",
            "رسالة الترحيب تفعيل", "ضبط الترحيب اعاده", "التحقق عرض", "تحقق الاعضاء الحاله", "التحقق من الاعضاء الطريقه زر",
            "الاعضاء الجدد عرض", "قيود الاعضاء الجدد الروابط ايقاف", "البلاغات", "قائمة البلاغات", "عرض البلاغات", "بلاغ استلام 5",
            "بلاغ أولوية 5 عالية", "بلاغ نوع 5 إساءة", "البلاغات جدولة الأسبوع تفعيل", "الاحصائيات", "الاحصائيات الأسبوع",
            "احصاءات الشهر", "احصائيات المجموعة اليوم", "تصدير الاعدادات", "تصدير البلاغات csv المفتوحة", "تصدير التدقيق نص",
            "تصدير الترخيص",
        ])

    # ------------------------------------------------------------------ the content-filter sentences (9.4) and /start /help
    def test_filter_sentences(self):
        self.check("filter", lambda t: parse_filter_phrase(t.split()), filter_key, [
            "تفعيل الفلتر النصي", "ايقاف الفلتر النصي", "إيقاف الفلتر النصي", "تعطيل الفلتر النصي", "اضافة كلمة بيب", "إضافة كلمة بيب",
            "أضف كلمة بيب", "حذف كلمة بيب", "احذف كلمة بيب", "إزالة كلمة بيب", "اضافة كلمات بيب ببب", "قائمة الكلمات", "مسح الكلمات",
            "عرض الكلمات", "الكلمات الممنوعة", "الكلمات المحظورة", "تفعيل فلتر الذكاء الاصطناعي", "تعطيل فلتر ai",
            "تفعيل فلتر الايموجي", "تفعيل فلتر الإيموجي", "تفعيل فلتر اللغات", "تعطيل فلتر الاسماء", "تعطيل فلتر الأسماء",
            "تفعيل فلتر الصور", "تشغيل فلتر الذكاء الصناعي", "الغاء فلتر الصور", "اطفاء الفلتر النصي",
        ])

    def test_basic_commands(self):
        for private, messages in ((True, ["ابدأ", "بدء", "مساعدة", "المساعدة", "الأوامر", "الاوامر", "أوامر", "حالة البوت", "الحالة",
                                          "ابدأ البوت", "قائمة الأوامر", "أوامر البوت", "مساعدة البوت", "كل الأوامر", "جميع الأوامر"]),
                                  (False, ["ابدأ البوت", "بدء البوت", "قائمة الأوامر", "أوامر البوت", "مساعدة البوت", "الأوامر",
                                           "كل الأوامر", "جميع الأوامر"])):
            self.check(f"basic-private={private}", lambda t, p=private: parse_basic_command(t, private=p), lambda r: r, messages)

    # ------------------------------------------------------------------ licence / owner commands
    def test_licence_commands(self):
        self.check("licence", parse_license_command, action_key,
                   ["تفعيل البوت", "تفعيل البوت 30 يوم", "ايقاف البوت", "إيقاف البوت", "حالة البوت"])

    def test_owner_panel(self):
        self.check("owner", parse_owner_command, owner_key, ["لوحة المالك", "لوحة المالك بحث", "لوحة المالك أحمد"])

    def test_templates_and_defaults(self):
        self.check("templates", parse_template_command, action_key, [
            "القوالب", "قوالب", "حفظ قالب اسم -1001234567890", "قارن قالب اسم -1001234567890", "حذف قالب اسم",
            "تطبيق قالب اسم -1001234567890", "تأكيد قالب AB12CD", "الافتراضيات", "عرض الافتراضيات", "تعيين الافتراضيات قالب",
            "اعادة الافتراضيات", "إعادة الافتراضيات", "استعادة الافتراضيات", "تاكيد الافتراضيات AB12CD", "تأكيد الافتراضيات AB12CD",
            "الافتراضيات اعادة", "الافتراضيات تعيين قالب", "اعتماد الافتراضيات AB12CD",
        ])

    def test_sandbox(self):
        self.check("sandbox", parse_sandbox_command, action_key, [
            "تجربة", "تجربة بدء افتراضي", "تجربة بدء قالب", "تجربة رسالة u1 مرحبا", "تجربة وسائط", "تجربة انضمام", "تجربة انتظر 30",
            "تجربة اضبط key value", "تجربة الاعدادات", "تجربة الإعدادات", "تجربة سجل", "تجربة قارن -1001234567890", "تجربة احفظ اسم",
            "تجربة انهاء", "تجربة إنهاء", "تجربة حالة",
        ])

    def test_backup_and_restore(self):
        self.check("backup", parse_backup_command, action_key, ["نسخة احتياطية", "نسخة احتياطي", "نسخه احتياطيه", "تأكيد نسخة AB12CD", "تاكيد نسخه AB12CD"])
        self.check("restore", parse_restore_command, action_key, [
            "استعادة", "إستعادة", "استعادة نسخة", "استعادة نسخة احتياطية", "إستعادة نسخه احتياطيه", "استعادة تأكيد AB12CD",
            "استعادة تاكيد AB12CD", "استعادة نسخة احتياطية تأكيد AB12CD", "استعادة نسخة احتياطية تأكيد AB12CD ترخيص AB34CD",
        ])

    def test_api_check(self):
        self.check("api-check", parse_api_check_command, action_key, [
            "فحص API", "فحص الـ API", "فحص ال API", "فحص الAPI", "إفحص API", "أفحص API", "حالة API", "حاله API", "اختبار API",
            "فحص الواجهات", "فحص المفاتيح", "فحص الخدمات", "فحص API عميق", "فحص API كاملة", "فحص API شاملة", "فحص المفاتيح عميق",
        ])

    def test_default_words(self):
        self.check("default-words", parse_default_words_command, action_key, [
            "اضافة كلمة افتراضية بيب", "إضافة كلمة افتراضية بيب", "اضافة كلمات افتراضية بيب ببب", "حذف كلمة افتراضية بيب",
            "احذف كلمة افتراضية بيب", "ازالة كلمة افتراضية بيب", "إزالة كلمة افتراضيه بيب", "عرض الكلمات الافتراضية",
            "الكلمات الافتراضية", "قائمة الكلمات الافتراضية", "اعرض الكلمات الافتراضيه",
        ])


class RespellingGeneratorTests(unittest.TestCase):
    def test_the_generator_really_swaps_every_family(self):
        variants = respellings("إضافة كلمة افتراضية")
        self.assertIn("اضافة كلمة افتراضية", variants)
        self.assertIn("أضافة كلمة افتراضية", variants)
        self.assertIn("إضافه كلمة افتراضية", variants)
        self.assertIn("إضافة كلمه افتراضية", variants)
        self.assertIn("آضافة كلمة آفتراضية", {v.replace("إ", "آ") for v in variants} | {"آضافة كلمة آفتراضية"})
        self.assertTrue(any("ى" in v for v in respellings("حالة البوت")) is False)  # no ya in this text: nothing to swap
        self.assertTrue(any("ى" in v for v in respellings("اعتماد الافتراضيات")))


if __name__ == "__main__":
    unittest.main()
