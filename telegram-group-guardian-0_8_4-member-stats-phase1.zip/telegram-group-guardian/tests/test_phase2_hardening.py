"""Phase 2 completion tests: defects found while re-reviewing the delivered Phase 2 code.

Each test names the failure it guards against. Stdlib only (no aiogram/FastAPI/asyncpg/PostgreSQL).
"""
import json
import unittest
from contextlib import asynccontextmanager
from datetime import datetime, timezone

import audit_helpers  # noqa: F401  (resets the audit secret registry after each test module import)
from guardian import audit as audit_mod
from guardian.audit import FORGED_CALLBACK, PERMISSION_DENIED, make_event, register_secrets
from guardian.auth import MAX_BIGINT, MIN_BIGINT, TELEGRAM_SERVICE_ACCOUNT_IDS
from guardian.config import load_settings
from guardian.errors import ConfigError, InvalidInput, PermissionDenied
from guardian.groups.models import GroupRole
from guardian.groups.postgres_store import PostgresDelegationStore
from guardian.groups.service import validate_settings_patch
from guardian.licensing.callbacks import handle_license_callback, parse_callback
from guardian.permissions import Permission
from guardian.telegram_rights import ChatMemberInfo
from helpers import VALID_ENV
from stack import A, B, BACKUP, DELEGATE, OWNER, STRANGER, TG_ADMIN, TG_CREATOR, Stack

ANON_ADMIN, CHANNEL_BOT, TELEGRAM = 1087968824, 136817688, 777000
NOW = datetime(2026, 10, 29, 12, tzinfo=timezone.utc)


class SettingsMustBeStorableInJsonbTests(unittest.TestCase):
    """PostgreSQL JSONB rejects NaN/Infinity and \\u0000; lone surrogates cannot be encoded.
    Before the fix these passed validation and then crashed at the database (or with
    UnicodeEncodeError inside the validator)."""

    def test_non_finite_numbers_rejected(self):
        for bad in (float("nan"), float("inf"), float("-inf")):
            with self.assertRaises(InvalidInput, msg=repr(bad)):
                validate_settings_patch({"x": bad})
            with self.assertRaises(InvalidInput, msg=repr(bad)):
                validate_settings_patch({"x": [1, {"y": bad}]})

    def test_nul_character_rejected(self):
        with self.assertRaises(InvalidInput):
            validate_settings_patch({"x": "a\x00b"})

    def test_lone_surrogate_rejected_with_invalid_input_not_a_crash(self):
        with self.assertRaises(InvalidInput):
            validate_settings_patch({"x": "\ud800"})

    def test_out_of_range_numbers_rejected(self):
        for bad in (10**400, -(10**30), 2**53 + 1, 1e300):
            with self.assertRaises(InvalidInput, msg=repr(bad)):
                validate_settings_patch({"x": bad})

    def test_normal_values_still_accepted_and_json_roundtrips(self):
        patch = {"links": "delete", "warn_limit": 3, "ratio": 0.5, "on": True, "none": None,
                 "ar": "مرحبًا بكم", "nested": {"a": [1, 2, "x"]}, "edge": 2**53, "neg": -5}
        out = validate_settings_patch(patch)
        self.assertEqual(json.loads(json.dumps(out, allow_nan=False)), patch)


class IdsMustFitBigintTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A)

    def test_callback_with_group_id_below_bigint_is_malformed(self):
        with self.assertRaises(InvalidInput):
            parse_callback("lic:bn:-9999999999999999999")
        with self.assertRaises(InvalidInput):
            parse_callback(f"lic:bn:{MIN_BIGINT - 1}")
        self.assertEqual(parse_callback(f"lic:bn:{MIN_BIGINT}").group_id, MIN_BIGINT)

    async def test_out_of_range_ids_are_denied_even_for_the_owner(self):
        for group in (MIN_BIGINT - 1, -(10**30)):
            d = await self.s.perm.check(OWNER, group, Permission.CHANGE_LICENSE)
            self.assertFalse(d.allowed, group)
        d = await self.s.perm.check(MAX_BIGINT + 1, A, Permission.MODERATE)
        self.assertEqual((d.allowed, d.reason), (False, "invalid_actor"))

    async def test_oversized_forged_callback_from_owner_never_reaches_the_store(self):
        with self.assertRaises(InvalidInput):
            await handle_license_callback(self.s.admin, self.s.audit, OWNER, "lic:bn:-9999999999999999999")
        self.assertEqual([e.event_type for e in self.s.audit.events], [FORGED_CALLBACK])

    def test_config_rejects_ids_outside_bigint_and_service_accounts(self):
        cases = [
            ({"OWNER_TELEGRAM_ID": str(MAX_BIGINT + 1)}, "OWNER_TELEGRAM_ID"),
            ({"OWNER_GROUP_ID": str(MIN_BIGINT - 1)}, "OWNER_GROUP_ID"),
            ({"BACKUP_OWNER_TELEGRAM_ID": str(MAX_BIGINT + 1)}, "BACKUP_OWNER_TELEGRAM_ID"),
            ({"OWNER_TELEGRAM_ID": str(ANON_ADMIN)}, "OWNER_TELEGRAM_ID"),
            ({"BACKUP_OWNER_TELEGRAM_ID": str(TELEGRAM)}, "BACKUP_OWNER_TELEGRAM_ID"),
        ]
        for extra, name in cases:
            with self.assertRaises(ConfigError, msg=name) as ctx:
                load_settings({**VALID_ENV, **extra})
            self.assertIn(name, [n for n, _ in ctx.exception.problems])
            self.assertNotIn(extra[name], str(ctx.exception))  # values never echoed


class TelegramServiceAccountTests(unittest.IsolatedAsyncioTestCase):
    """Anonymous admins post as GroupAnonymousBot (1087968824): the person is hidden. Before the
    fix such a sender was neither protected from automatic sanctions nor explicitly refused."""

    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A)

    def test_known_ids(self):
        self.assertEqual(TELEGRAM_SERVICE_ACCOUNT_IDS, {TELEGRAM, ANON_ADMIN, CHANNEL_BOT})

    async def test_service_accounts_are_never_authorized_even_if_telegram_says_admin(self):
        for acct in TELEGRAM_SERVICE_ACCOUNT_IDS:
            self.s.chat.set(A, acct, ChatMemberInfo("administrator", True, True, True))
            for perm in Permission:
                d = await self.s.perm.check(acct, A, perm)
                self.assertFalse(d.allowed, (acct, perm))
                self.assertEqual(d.reason, "service_account")

    async def test_service_account_cannot_gain_rights_through_a_delegation(self):
        await self.s.delegations.grant(OWNER, A, ANON_ADMIN, GroupRole.GROUP_MANAGER)  # owner mistake
        d = await self.s.perm.check(ANON_ADMIN, A, Permission.MODERATE)
        self.assertFalse(d.allowed)

    async def test_service_accounts_are_protected_and_exempt_from_automation(self):
        for acct in TELEGRAM_SERVICE_ACCOUNT_IDS:
            self.assertTrue(await self.s.perm.is_protected(acct, A))
            self.assertTrue(await self.s.perm.is_exempt_from_automation(acct, A))

    async def test_unidentifiable_actor_is_exempt_from_automation(self):
        for bad in (None, "x", 0, -5, True, [1]):
            self.assertTrue(await self.s.perm.is_exempt_from_automation(bad, A), repr(bad))
        self.assertFalse(await self.s.perm.is_exempt_from_automation(STRANGER, A))  # real strangers are not

    async def test_service_account_denial_is_audited(self):
        await self.s.perm.check(ANON_ADMIN, A, Permission.CHANGE_LICENSE)
        events = [e for e in self.s.audit.events if e.event_type == PERMISSION_DENIED]
        self.assertEqual([(e.actor_telegram_id, e.detail) for e in events], [(ANON_ADMIN, "service_account")])


class _UniqueViolation(Exception):
    sqlstate = "23505"


class _OtherDbError(Exception):
    sqlstate = "40001"


class _ScriptedConn:
    """fetchrow() answers come from a script; an Exception item is raised instead of returned."""

    def __init__(self, script):
        self.script, self.sql = list(script), []

    def transaction(self):
        class Tx:
            async def __aenter__(self_):
                return self_

            async def __aexit__(self_, *exc):
                return False

        return Tx()

    async def fetchrow(self, sql, *args):
        self.sql.append(" ".join(sql.split()))
        item = self.script.pop(0)
        if isinstance(item, Exception):
            raise item
        return item

    async def execute(self, sql, *args):
        self.sql.append(" ".join(sql.split()))


class _Db:
    def __init__(self, conn):
        self.conn = conn

    @asynccontextmanager
    async def acquire(self):
        yield self.conn


def _row(role="moderator"):
    return {"group_id": A, "user_id": DELEGATE, "role": role, "granted_by": OWNER,
            "granted_at": NOW, "revoked_at": None, "revoked_by": None}


class DelegationGrantRaceTests(unittest.IsolatedAsyncioTestCase):
    """Two concurrent FIRST grants: FOR UPDATE locks nothing (no row yet), so the partial unique
    index rejects the loser with SQLSTATE 23505. Before the fix that surfaced as a raw DB error."""

    async def test_unique_violation_on_first_grant_is_retried_and_answers_idempotently(self):
        conn = _ScriptedConn([None, _UniqueViolation(), _row("moderator")])
        store = PostgresDelegationStore(_Db(conn))
        delegation, changed = await store.grant(A, DELEGATE, GroupRole.MODERATOR, OWNER, NOW)
        self.assertFalse(changed)  # the winner's identical grant stands: no duplicate audit upstream
        self.assertEqual((delegation.group_id, delegation.role), (A, GroupRole.MODERATOR))

    async def test_loser_with_a_different_role_replaces_the_winners_grant(self):
        conn = _ScriptedConn([None, _UniqueViolation(), _row("moderator"), _row("group_manager")])
        store = PostgresDelegationStore(_Db(conn))
        delegation, changed = await store.grant(A, DELEGATE, GroupRole.GROUP_MANAGER, OWNER, NOW)
        self.assertTrue(changed)
        self.assertEqual(delegation.role, GroupRole.GROUP_MANAGER)
        self.assertTrue(any(s.startswith("UPDATE group_delegations SET revoked_at") for s in conn.sql))

    async def test_other_database_errors_are_not_swallowed_and_retry_is_bounded(self):
        with self.assertRaises(_OtherDbError):
            await PostgresDelegationStore(_Db(_ScriptedConn([None, _OtherDbError()]))).grant(
                A, DELEGATE, GroupRole.MODERATOR, OWNER, NOW)
        with self.assertRaises(_UniqueViolation):  # second consecutive violation: give up
            await PostgresDelegationStore(_Db(_ScriptedConn([None, _UniqueViolation(), None, _UniqueViolation()]))).grant(
                A, DELEGATE, GroupRole.MODERATOR, OWNER, NOW)


class AuditSecretsTests(unittest.TestCase):
    def tearDown(self):
        register_secrets(())

    def test_registered_secrets_are_redacted_from_audit_text(self):
        secret = "my-webhook-secret-0123456789"
        register_secrets((secret, "dbPassw0rd!"))
        event = make_event("x", detail=f"reason leaked {secret} and dbPassw0rd! here", now=NOW)
        self.assertNotIn(secret, event.detail)
        self.assertNotIn("dbPassw0rd!", event.detail)
        self.assertIn("***", event.detail)

    def test_without_registration_behaviour_is_unchanged(self):
        event = make_event("x", detail="plain text", now=NOW)
        self.assertEqual(event.detail, "plain text")
        self.assertEqual(audit_mod._known_secrets, ())


class AuditQueryServiceTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A, B)
        await self.s.admin.activate_permanent(OWNER, A, reason="paid")
        await self.s.admin.ban(OWNER, B, reason="spam")
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.GROUP_MANAGER)
        await self.s.perm.check(STRANGER, A, Permission.CHANGE_LICENSE)  # one audited denial in A

    async def test_owner_reads_license_history_of_the_requested_group_only(self):
        history = await self.s.audit_query.license_history(OWNER, A)
        self.assertEqual([e.action for e in history], ["register_pending", "activate_permanent"])
        self.assertTrue(all(e.group_id == A for e in history))
        banned = await self.s.audit_query.license_history(OWNER, B)
        self.assertEqual([e.action for e in banned], ["register_pending", "ban"])
        self.assertTrue(all(e.group_id == B for e in banned))

    async def test_owner_reads_security_events_of_the_requested_group_only(self):
        events = await self.s.audit_query.security_events(OWNER, A)
        self.assertTrue(events)
        self.assertTrue(all(e.group_id == A for e in events))
        self.assertIn(PERMISSION_DENIED, [e.event_type for e in events])
        self.assertEqual(await self.s.audit_query.security_events(OWNER, B), [])

    async def test_nobody_but_the_primary_owner_can_read_the_audit(self):
        for actor in (BACKUP, TG_CREATOR, TG_ADMIN, DELEGATE, STRANGER, ANON_ADMIN, None, "x", True):
            with self.assertRaises(PermissionDenied, msg=repr(actor)):
                await self.s.audit_query.license_history(actor, A)
            with self.assertRaises(PermissionDenied, msg=repr(actor)):
                await self.s.audit_query.security_events(actor, A)

    async def test_command_context_in_another_chat_is_refused_even_for_the_owner(self):
        with self.assertRaises(PermissionDenied):
            await self.s.audit_query.license_history(OWNER, A, context_chat_id=B)
        with self.assertRaises(PermissionDenied):
            await self.s.audit_query.security_events(OWNER, A, context_chat_id=B)

    async def test_limit_is_clamped_and_garbage_limit_gets_the_default(self):
        for i in range(5):
            await self.s.admin.ban(OWNER, A, reason=f"r{i}")  # first one changes, rest are no-ops
        for bad in (0, -3, 10**9, "7", None, True, 2.5):
            out = await self.s.audit_query.license_history(OWNER, A, bad)
            self.assertLessEqual(len(out), 200)
            self.assertGreaterEqual(len(out), 1)
        self.assertEqual(len(await self.s.audit_query.license_history(OWNER, A, 1)), 1)


if __name__ == "__main__":
    unittest.main()
