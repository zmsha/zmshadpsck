"""Phase 4 / part 2: /trust /untrust /trusted — parsing, permissions, per-group isolation, idempotency, caps, audit."""
import unittest
from types import SimpleNamespace as NS
from unittest import mock

from executor_stack import BOT, BOT_NAME, OTHER, USER, BrokenClaims, ExecBase, gate
from guardian.audit import TRUST_ADDED, TRUST_BOT_ADDED, TRUST_BOT_REMOVED, TRUST_REMOVED
from guardian.groups.models import GroupRole
from guardian.bot import moderation_handler as handler
from guardian.errors import GroupNotRegistered, InvalidInput, PermissionDenied
from guardian.members import trust as rules
from guardian.members.memory_store import InMemoryBotTrustStore
from guardian.members.service import BotTrustService
from guardian.moderation.commands import Command, CommandError, parse_command
from guardian.moderation.executor import ModerationCommandService, ResultKind as R
from guardian.moderation.targets import ReplyInfo
from guardian.moderation.trust_args import parse_trust_args
from guardian.moderation.usernames import VisibleUsers
from stack import A, B, DELEGATE, OWNER, STRANGER, TG_ADMIN, TG_CREATOR, TG_LIMITED_ADMIN

A_BOT = 880_001  # another bot account


class TrustBase(ExecBase):
    async def asyncSetUp(self):
        self.bots = InMemoryBotTrustStore()
        self.visible = VisibleUsers(clock=lambda: self.s.clock())
        await super().asyncSetUp()
        self.bot_trust = BotTrustService(self.bots, self.s.licenses, self.s.perm, self.s.audit, clock=self.s.clock)
        self.svc = self.make_service(self.claims)
        await self.s.admin.activate_permanent(OWNER, A)
        self.msg = 100

    def make_service(self, claims, **over):
        kw = dict(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions,
            settings_store=self.s.settings_store, actions=self.actions, chat_info=self.s.chat, claims=claims,
            audit=self.s.audit, bot_id=BOT, clock=self.s.clock, group_settings=self.s.settings, usernames=self.visible,
            trust=self.s.trust, bot_trust=getattr(self, "bot_trust", None), trust_store=self.s.trust_store,
            bot_trust_store=self.bots)
        kw.update(over)
        return ModerationCommandService(**kw)

    async def cmd(self, text, *, actor=TG_ADMIN, chat=A, reply=None, msg=None, svc=None, protection="default", mention=None):
        parsed = parse_command(text, BOT_NAME, has_reply=reply is not None)
        assert parsed is not None, text
        if msg is None:
            self.msg += 1
            msg = self.msg
        prot = gate(chat, actor) if protection == "default" else protection
        return await (svc or self.svc).handle(parsed, chat_id=chat, actor_id=actor, message_id=msg, protection=prot,
                                              reply=reply, mention_user_id=mention)

    async def trusted_ids(self, group=A):
        return sorted(r.user_id for r in await self.s.trust_store.list(group))

    async def domains(self, group=A):
        row = await self.s.settings_store.get(group)
        return list((row.settings if row else {}).get("links_allow_domains", []))


class ParserTests(unittest.TestCase):
    def p(self, text, reply=False):
        return parse_command(text, BOT_NAME, has_reply=reply)

    def test_english_forms(self):
        for text, cmd in (("/trust", Command.TRUST), ("/untrust 5", Command.UNTRUST), ("/trusted", Command.TRUSTED),
                          (f"/trust@{BOT_NAME} 5", Command.TRUST), ("/TRUSTED", Command.TRUSTED)):
            self.assertIs(self.p(text).command, cmd, text)
        self.assertIsNone(self.p("/trust@OtherBot 5"))

    def test_arabic_aliases_need_a_reply_target_or_scope_word(self):
        self.assertIs(self.p("وثق", reply=True).command, Command.TRUST)
        self.assertIs(self.p("وثق @abcde").command, Command.TRUST)
        self.assertIs(self.p("وثق نطاق example.com").command, Command.TRUST)
        self.assertIs(self.p("الغاء الثقة", reply=True).command, Command.UNTRUST)
        self.assertIs(self.p("سحب الثقة بوت 123").command, Command.UNTRUST)
        self.assertIsNone(self.p("وثق"))              # no reply, nothing to act on
        self.assertIsNone(self.p("وثق الله وتوكل"))   # ordinary chat
        self.assertIsNone(self.p("ثقة", reply=True))  # a compliment as a reply must NEVER trust someone
        self.assertIsNone(self.p("ثقة"))

    def test_trusted_alias_only_as_the_whole_message(self):
        self.assertIs(self.p("الموثوقين").command, Command.TRUSTED)
        self.assertIs(self.p("قائمة الثقة").command, Command.TRUSTED)
        self.assertIsNone(self.p("الموثوقين في الشركة كثر"))

    def test_args(self):
        a = parse_trust_args("trust", (), has_reply=True)
        self.assertEqual((a.scope, a.token), ("user", None))
        a = parse_trust_args("trust", ("@abcde",), has_reply=False)
        self.assertEqual((a.scope, a.token), ("user", "@abcde"))
        a = parse_trust_args("untrust", ("user", "5",), has_reply=False)
        self.assertEqual((a.scope, a.token), ("user", "5"))
        a = parse_trust_args("trust", ("domain", "Example.com", "https://www.Foo.org/x"), has_reply=False)
        self.assertEqual((a.scope, a.domains), ("domain", ("example.com", "foo.org")))
        a = parse_trust_args("trust", ("نطاق", "example.com"), has_reply=True)
        self.assertEqual(a.scope, "domain")  # a reply never matters for a domain
        a = parse_trust_args("trust", ("bot", "123"), has_reply=False)
        self.assertEqual((a.scope, a.token), ("bot", "123"))
        a = parse_trust_args("trust", ("بوت",), has_reply=True)
        self.assertEqual((a.scope, a.token), ("bot", None))
        for scope in ("users", "domains", "bots"):
            self.assertEqual(parse_trust_args("trusted", (scope,), has_reply=False).scope, scope)
        self.assertEqual(parse_trust_args("trusted", (), has_reply=False).scope, "all")

    def test_strict_errors(self):
        bad = [("trust", (), False, "trust_need_target"), ("trust", ("@abcde", "note"), False, "trust_args"),
               ("trust", ("@abcde",), True, "trust_args"), ("trust", ("5", "6"), False, "trust_args"),
               ("trust", ("domain",), False, "trust_domain"), ("trust", ("domain", "not a domain!"), False, "trust_domain"),
               ("trust", ("domain",) + tuple(f"d{i}.com" for i in range(11)), False, "trust_domain"),
               ("trusted", ("everything",), False, "trust_args"), ("trusted", ("users", "x"), False, "trust_args"),
               ("trust", tuple("x" * 21), False, "too_many_args")]
        for command, args, reply, code in bad:
            with self.assertRaises(CommandError, msg=(command, args)) as cm:
                parse_trust_args(command, args, has_reply=reply)
            self.assertEqual(cm.exception.code, code, (command, args))


class MemberTrustTests(TrustBase):
    async def test_trust_by_reply_adds_audits_and_explains_what_is_skipped(self):
        r = await self.cmd("/trust", reply=ReplyInfo(USER))
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(await self.trusted_ids(), [USER])
        self.assertIn(f"<code>{USER}</code>", r.text)
        self.assertIn("الفيضان", r.text)  # says what is NOT skipped
        self.assertIn(TRUST_ADDED, self.audit_types())
        self.assertEqual(self.actions.calls, [])  # trust never touches Telegram

    async def test_second_time_is_noop_without_second_audit(self):
        await self.cmd("/trust", reply=ReplyInfo(USER))
        r = await self.cmd("/trust", reply=ReplyInfo(USER))
        self.assertIs(r.kind, R.NOOP)
        self.assertEqual(self.audit_types().count(TRUST_ADDED), 1)

    async def test_redelivered_update_is_silent_and_writes_once(self):
        await self.cmd("/trust", reply=ReplyInfo(USER), msg=7)
        r = await self.cmd("/trust", reply=ReplyInfo(USER), msg=7)
        self.assertEqual((r.kind, r.text), (R.DUPLICATE, ""))
        self.assertEqual(self.audit_types().count(TRUST_ADDED), 1)

    async def test_untrust_removes_then_noop(self):
        await self.cmd("/trust 5001")
        r = await self.cmd("/untrust 5001")
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(await self.trusted_ids(), [])
        self.assertIn(TRUST_REMOVED, self.audit_types())
        self.assertIs((await self.cmd("/untrust 5001")).kind, R.NOOP)

    async def test_by_id_by_visible_username_and_unknown_username(self):
        self.visible.observe(A, OTHER, "alice_user")
        self.assertIs((await self.cmd("/trust @alice_user")).kind, R.DONE)
        self.assertEqual(await self.trusted_ids(), [OTHER])
        r = await self.cmd("/trust @nobody_here")
        self.assertIs(r.kind, R.INVALID)
        self.assertEqual(await self.trusted_ids(), [OTHER])

    async def test_arabic_alias(self):
        self.assertIs((await self.cmd("وثق", reply=ReplyInfo(USER))).kind, R.DONE)
        self.assertIs((await self.cmd("الغاء الثقة", reply=ReplyInfo(USER))).kind, R.DONE)
        self.assertEqual(await self.trusted_ids(), [])

    async def test_banned_member_cannot_be_newly_trusted_but_can_be_untrusted(self):
        self.member(OTHER, "kicked")
        self.assertIs((await self.cmd("/trust 5002")).kind, R.INVALID)
        self.assertEqual(await self.trusted_ids(), [])
        await self.s.trust_store.add(A, OTHER, OWNER, None, self.s.clock())
        self.assertIs((await self.cmd("/untrust 5002")).kind, R.DONE)

    async def test_rejects_the_bot_itself_bad_ids_and_bot_accounts(self):
        for text in (f"/trust {BOT}", "/trust 0", "/trust 99999999999999999999", "/trust @ab"):
            self.assertIs((await self.cmd(text)).kind, R.INVALID, text)
        r = await self.cmd("/trust", reply=ReplyInfo(A_BOT, is_bot=True))
        self.assertIs(r.kind, R.INVALID)  # a bot is trusted with `/trust bot`
        for reply in (ReplyInfo(None, sender_chat=True), ReplyInfo(None)):
            self.assertIs((await self.cmd("/trust", reply=reply)).kind, R.INVALID)
        self.assertEqual(await self.trusted_ids(), [])

    async def test_list_cap(self):
        with mock.patch.object(rules, "MAX_TRUSTED_USERS", 2):
            for uid in (5001, 5002):
                self.assertIs((await self.cmd(f"/trust {uid}")).kind, R.DONE)
            r = await self.cmd("/trust 5003")
            self.assertIs(r.kind, R.INVALID)
            self.assertIs((await self.cmd("/trust 5001")).kind, R.NOOP)  # an existing entry is not "full"
        self.assertEqual(await self.trusted_ids(), [5001, 5002])

    async def test_isolated_per_group(self):
        await self.s.admin.activate_permanent(OWNER, B)
        await self.cmd("/trust 5001")
        self.assertEqual(await self.trusted_ids(B), [])
        r = await self.cmd("/untrust 5001", chat=B, actor=TG_CREATOR)
        self.assertIs(r.kind, R.NOOP)
        self.assertEqual(await self.trusted_ids(), [5001])  # B's /untrust never touched A

    async def test_works_in_dry_run(self):
        await self.settings(dry_run=True)
        self.assertIs((await self.cmd("/trust 5001")).kind, R.DONE)
        self.assertEqual(await self.trusted_ids(), [5001])


class BotAndDomainTests(TrustBase):
    async def test_trust_bot_by_reply_and_by_id_and_remove(self):
        r = await self.cmd("/trust bot", reply=ReplyInfo(A_BOT, is_bot=True))
        self.assertIs(r.kind, R.DONE)
        self.assertTrue(await self.bots.is_trusted(A, A_BOT))
        self.assertIn(TRUST_BOT_ADDED, self.audit_types())
        self.assertIs((await self.cmd("/trust bot 880002")).kind, R.DONE)
        self.assertIs((await self.cmd("/trust bot 880002")).kind, R.NOOP)
        self.assertIs((await self.cmd("/untrust bot 880002")).kind, R.DONE)
        self.assertIs((await self.cmd("/untrust bot 880002")).kind, R.NOOP)
        self.assertIn(TRUST_BOT_REMOVED, self.audit_types())
        self.assertEqual([b.bot_id for b in await self.bots.list(A)], [A_BOT])
        self.assertEqual(await self.trusted_ids(), [])  # bots never land in the member list

    async def test_bot_rejections(self):
        for text, reply in (("/trust bot @some_bot", None), ("/trust bot abc", None), (f"/trust bot {BOT}", None),
                            ("/trust bot 0", None), ("/trust bot", ReplyInfo(USER, is_bot=False)),
                            ("/trust bot", ReplyInfo(None, sender_chat=True)), ("/trust bot 5 6", None)):
            self.assertIs((await self.cmd(text, reply=reply)).kind, R.INVALID, text)
        self.assertEqual(await self.bots.list(A), [])

    async def test_bot_cap_and_isolation(self):
        with mock.patch.object(rules, "MAX_TRUSTED_BOTS", 1):
            self.assertIs((await self.cmd("/trust bot 880001")).kind, R.DONE)
            self.assertIs((await self.cmd("/trust bot 880002")).kind, R.INVALID)
        await self.s.admin.activate_permanent(OWNER, B)
        self.assertEqual(await self.bots.list(B), [])

    async def test_domains_use_the_one_allow_list_shared_with_protect(self):
        r = await self.cmd("/trust domain Example.com https://www.Foo.org/x")
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(await self.domains(), ["example.com", "foo.org"])
        listing = await self.cmd("/protect allow list")
        self.assertIn("example.com", listing.text)
        await self.cmd("/protect allow add bar.net")
        self.assertEqual(await self.domains(), ["example.com", "foo.org", "bar.net"])
        r = await self.cmd("/untrust domain example.com")
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(await self.domains(), ["foo.org", "bar.net"])
        self.assertIs((await self.cmd("/untrust domain example.com")).kind, R.NOOP)
        self.assertIs((await self.cmd("/trust domain foo.org")).kind, R.NOOP)
        self.assertIn("settings_changed", self.audit_types())

    async def test_bad_domains_write_nothing(self):
        for text in ("/trust domain", "/trust domain not_a_domain!!", "/trust domain a.com https://"):
            self.assertIs((await self.cmd(text)).kind, R.INVALID, text)
        self.assertIsNone(await self.s.settings_store.get(A))

    async def test_domain_redelivery_writes_once(self):
        await self.cmd("/trust domain a.com", msg=9)
        r = await self.cmd("/trust domain a.com", msg=9)
        self.assertEqual((r.kind, r.text), (R.DUPLICATE, ""))
        self.assertEqual(self.audit_types().count("settings_changed"), 1)


class PermissionTests(TrustBase):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.MODERATOR, context_chat_id=A)
        await self.s.trust_store.add(A, USER, OWNER, None, self.s.clock())
        await self.s.settings.update(OWNER, A, {"links_allow_domains": ["keep.com"]}, context_chat_id=A)
        await self.bots.add(A, A_BOT, OWNER, None, self.s.clock())

    async def assert_untouched(self):
        self.assertEqual(await self.trusted_ids(), [USER])
        self.assertEqual(await self.domains(), ["keep.com"])
        self.assertEqual([b.bot_id for b in await self.bots.list(A)], [A_BOT])

    async def test_moderator_delegate_may_list_but_not_change(self):
        self.assertIs((await self.cmd("/trusted", actor=DELEGATE)).kind, R.INFO)
        for text in (f"/trust 5002", "/untrust 5001", "/trust domain x.com", "/untrust domain keep.com",
                     "/trust bot 5", f"/untrust bot {A_BOT}"):
            self.assertIs((await self.cmd(text, actor=DELEGATE)).kind, R.DENIED, text)
        await self.assert_untouched()

    async def test_plain_member_and_limited_admin_cannot_do_anything(self):
        for actor in (STRANGER, USER, TG_LIMITED_ADMIN):  # the limited admin lacks can_restrict_members => no MODERATE
            for text in ("/trusted", "/trust 5002", "/untrust 5001", "/trust domain x.com", "/trust bot 5"):
                self.assertIs((await self.cmd(text, actor=actor, protection=gate(A, actor))).kind, R.DENIED,
                              (actor, text))
        await self.assert_untouched()

    async def test_delegation_group_manager_can_change(self):
        await self.s.delegations.grant(OWNER, A, 900_077, GroupRole.GROUP_MANAGER, context_chat_id=A)
        self.assertIs((await self.cmd("/trust 5002", actor=900_077)).kind, R.DONE)

    async def test_license_off_blocks_everything_including_listing(self):
        for text in ("/trusted", "/trust 5002", "/untrust 5001", "/trust domain x.com", "/trust bot 5"):
            r = await self.cmd(text, protection=gate(A, TG_ADMIN, allowed=False))
            self.assertIs(r.kind, R.LICENSE_OFF, text)
        await self.assert_untouched()

    async def test_wrong_chat_context_is_denied(self):
        r = await self.cmd("/trust 5002", chat=A, protection=gate(B, TG_ADMIN))
        self.assertIs(r.kind, R.LICENSE_OFF)
        await self.assert_untouched()

    async def test_failures_fail_closed(self):
        r = await self.cmd("/trust 5002", svc=self.make_service(BrokenClaims()))
        self.assertIs(r.kind, R.ERROR)
        r = await self.cmd("/trust 5002", svc=self.make_service(self.claims, trust=None))
        self.assertIs(r.kind, R.ERROR)
        r = await self.cmd("/trust bot 5", svc=self.make_service(self.claims, bot_trust=None))
        self.assertIs(r.kind, R.ERROR)
        r = await self.cmd("/trust domain x.com", svc=self.make_service(self.claims, group_settings=None))
        self.assertIs(r.kind, R.ERROR)
        self.s.chat.fail = True
        self.assertIs((await self.cmd("/trust 5002")).kind, R.DENIED)  # no live admin check => deny
        await self.assert_untouched()


class ListTests(TrustBase):
    async def test_lists_everything_and_the_rules(self):
        await self.cmd("/trust 5001")
        await self.cmd("/trust domain example.com")
        await self.cmd("/trust bot 880001")
        r = await self.cmd("/trusted")
        self.assertIs(r.kind, R.INFO)
        for needle in ("<code>5001</code>", "example.com", "<code>880001</code>", "الفيضان", "(1)"):
            self.assertIn(needle, r.text)
        for scope, present, absent in (("users", "5001", "880001"), ("bots", "880001", "5001"),
                                       ("domains", "example.com", "5001")):
            r = await self.cmd(f"/trusted {scope}")
            self.assertIn(present, r.text)
            self.assertNotIn(absent, r.text)
            self.assertNotIn("الفيضان", r.text)  # the rules note belongs to the full listing

    async def test_empty_and_truncated(self):
        self.assertIn("لا يوجد", (await self.cmd("/trusted")).text)
        for uid in range(6001, 6001 + 30):
            await self.s.trust_store.add(A, uid, OWNER, None, self.s.clock())
        r = await self.cmd("/trusted users")
        self.assertEqual(r.text.count("• "), 25)
        self.assertIn("… و5 آخرين", r.text)

    async def test_listing_is_per_group(self):
        await self.s.admin.activate_permanent(OWNER, B)
        await self.cmd("/trust 5001")
        self.assertNotIn("5001", (await self.cmd("/trusted", chat=B, actor=TG_CREATOR)).text)

    async def test_info_marks_a_trusted_member(self):
        await self.cmd("/trust 5001")
        r = await self.cmd("/info 5001")
        self.assertIn("/trusted", r.text)
        self.assertNotIn("/trusted", (await self.cmd("/info 5002")).text)


class ManualModerationStillAppliesTests(TrustBase):
    async def test_a_trusted_member_can_still_be_muted_and_warned(self):
        await self.cmd("/trust 5001")
        self.assertIs((await self.cmd("/mute 5001 1h")).kind, R.DONE)
        self.assertIn(("mute", A), [c[:2] for c in self.actions.calls])
        self.assertIs((await self.cmd("/warn 5001 spam")).kind, R.DONE)


class ServiceAndHandlerTests(TrustBase):
    async def test_bot_trust_service_authorizes_validates_and_audits_on_its_own(self):
        for actor in (STRANGER, DELEGATE):  # (a Telegram admin without can_restrict_members has MANAGE_TRUST by design)
            with self.assertRaises(PermissionDenied, msg=actor):
                await self.bot_trust.add(actor, A, A_BOT, context_chat_id=A)
        with self.assertRaises(PermissionDenied):
            await self.bot_trust.add(TG_ADMIN, A, A_BOT, context_chat_id=B)  # wrong chat context
        self.assertEqual(await self.bots.list(A), [])
        for bad in (0, -1, True, "5", None, 2**63):
            with self.assertRaises(InvalidInput, msg=bad):
                await self.bot_trust.add(TG_ADMIN, A, bad, context_chat_id=A)
        with self.assertRaises(GroupNotRegistered):
            await self.bot_trust.add(OWNER, -777, A_BOT)  # never registered
        self.assertTrue(await self.bot_trust.add(TG_ADMIN, A, A_BOT, "x" * 500, context_chat_id=A))
        self.assertFalse(await self.bot_trust.add(TG_ADMIN, A, A_BOT, context_chat_id=A))
        self.assertEqual(len(await self.bot_trust.list(TG_ADMIN, A, context_chat_id=A)), 1)
        with self.assertRaises(PermissionDenied):
            await self.bot_trust.list(DELEGATE, A, context_chat_id=A)
        self.assertTrue(await self.bot_trust.remove(TG_ADMIN, A, A_BOT, context_chat_id=A))
        self.assertFalse(await self.bot_trust.remove(TG_ADMIN, A, A_BOT, context_chat_id=A))
        self.assertEqual(self.audit_types().count(TRUST_BOT_ADDED), 1)
        self.assertEqual(self.audit_types().count(TRUST_BOT_REMOVED), 1)

    async def test_change_allow_accepts_only_add_and_remove(self):
        with self.assertRaises(ValueError):
            await self.svc._config.change_allow("allow_clear", (), cmd=Command.TRUST, decision=None, chat_id=A,
                                                actor_id=TG_ADMIN, message_id=1, lang="ar")

    def message(self, text, *, replied_user=None, replied_bot=False, actor=TG_ADMIN):
        sent: list[str] = []

        async def reply(text, **kw):
            sent.append(text)

        replied = None
        if replied_user is not None:
            replied = NS(message_id=5, from_user=NS(id=replied_user, is_bot=replied_bot), sender_chat=None,
                         forum_topic_created=None)
        msg = NS(text=text, entities=None, message_id=50, chat=NS(id=A, type="supergroup"), reply=reply,
                 from_user=NS(id=actor, is_bot=False, language_code="ar", username=None), reply_to_message=replied)
        return msg, sent

    def test_reply_info_marks_bot_accounts(self):
        msg, _ = self.message("/trust", replied_user=A_BOT, replied_bot=True)
        self.assertTrue(handler.reply_info(msg).is_bot)
        msg, _ = self.message("/trust", replied_user=USER, replied_bot=False)
        self.assertFalse(handler.reply_info(msg).is_bot)
        msg.reply_to_message.from_user.is_bot = "yes"  # only a real True counts
        self.assertFalse(handler.reply_info(msg).is_bot)

    async def test_telegram_message_to_trusted_bot_end_to_end(self):
        services = NS(moderation_commands=self.svc, settings=NS(default_language="ar"))
        bot = NS(me=lambda: None)

        async def me():
            return NS(username=BOT_NAME)

        bot.me = me
        msg, sent = self.message("/trust bot", replied_user=A_BOT, replied_bot=True)
        parsed = await handler.match_command(msg, bot)
        result = await handler.execute(msg, parsed, protection=gate(A, TG_ADMIN), services=services)
        self.assertIs(result.kind, R.DONE)
        self.assertTrue(await self.bots.is_trusted(A, A_BOT))
        self.assertEqual(len(sent), 1)
        msg, sent = self.message("/trust", replied_user=A_BOT, replied_bot=True)  # as a member: refused, with advice
        result = await handler.execute(msg, await handler.match_command(msg, bot), protection=gate(A, TG_ADMIN),
                                       services=services)
        self.assertIs(result.kind, R.INVALID)
        self.assertEqual(await self.trusted_ids(), [])


if __name__ == "__main__":
    unittest.main()
