"""Statistics phase 1: permanent per-member statistics (migration 0013, `guardian.member_stats`).

PostgreSQL itself is NOT exercised: the Postgres store is checked against a recording fake connection and the migration is
checked statically. No Telegram, no aiogram, no network."""
from __future__ import annotations

import re
import unittest
from contextlib import asynccontextmanager
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace as NS

import test_content_filter as tcf
import test_protection_engine as tpe
from guardian.bot import commands_menu
from guardian.bot import owner_panel_handler as handler
from guardian.bot.middlewares import ProtectionGateMiddleware
from guardian.content_filter.store import InMemoryContentLedger
from guardian.db.migrations import discover
from guardian.i18n import MESSAGES
from guardian.idempotency import InMemoryIdempotency
from guardian.member_stats import GroupTotals, MemberEvent, MemberStats, MemberStatsRecorder
from guardian.member_stats.commands import GROUP, TOP, USER, parse_member_stats_command
from guardian.member_stats.memory_store import InMemoryMemberStatsStore
from guardian.member_stats.models import EVENT_COLUMN
from guardian.member_stats.postgres_store import COUNTER_SQL, PostgresMemberStatsStore
from guardian.member_stats.service import MemberStatsCommandService
from guardian.member_stats.tracking import TrackingContentLedger, TrackingSanctionStore, TrackingWarningStore
from guardian.moderation.memory_store import InMemorySanctionStore, InMemoryWarningStore
from guardian.moderation.models import SanctionKind
from guardian.moderation.targets import ReplyInfo
from guardian.protection.engine import MessageView, OutcomeKind
from guardian.protection_gate import ProtectionGate
from helpers import FakeNotifier
from stack import A, B, BACKUP, DELEGATE, OWNER, STRANGER, TG_ADMIN, Stack

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src" / "guardian"
SQL = SRC / "db" / "sql" / "0013_member_activity_stats.sql"
TZ = "Asia/Riyadh"
U1, U2 = 5001, 5002
D1 = date(2026, 11, 6)
T0 = datetime(2026, 11, 6, 12, 0, tzinfo=timezone.utc)  # 15:00 in Riyadh


class Clock:
    def __init__(self, now: datetime = T0):
        self.now = now

    def __call__(self) -> datetime:
        return self.now


# ------------------------------------------------------------------------------------------------ store
class StoreTests(unittest.IsolatedAsyncioTestCase):
    async def test_messages_count_total_today_and_last_activity(self):
        s = InMemoryMemberStatsStore()
        await s.record(A, U1, MemberEvent.MESSAGE, D1, T0)
        await s.record(A, U1, MemberEvent.MESSAGE, D1, T0 + timedelta(minutes=5))
        m = await s.get(A, U1, D1)
        self.assertEqual((m.total_messages, m.today_messages), (2, 2))
        self.assertEqual(m.last_activity_at, T0 + timedelta(minutes=5))
        self.assertEqual(m.first_seen_at, T0)

    async def test_a_new_day_restarts_today_but_keeps_the_total(self):
        s = InMemoryMemberStatsStore()
        await s.record(A, U1, MemberEvent.MESSAGE, D1, T0)
        await s.record(A, U1, MemberEvent.MESSAGE, D1, T0)
        tomorrow = D1 + timedelta(days=1)
        self.assertEqual((await s.get(A, U1, tomorrow)).today_messages, 0)  # read on a later day: nothing yet today
        await s.record(A, U1, MemberEvent.MESSAGE, tomorrow, T0 + timedelta(days=1))
        m = await s.get(A, U1, tomorrow)
        self.assertEqual((m.total_messages, m.today_messages), (3, 1))

    async def test_the_same_member_in_two_groups_is_two_independent_records(self):
        s = InMemoryMemberStatsStore()
        for _ in range(3):
            await s.record(A, U1, MemberEvent.MESSAGE, D1, T0)
        await s.record(B, U1, MemberEvent.MESSAGE, D1, T0)
        await s.record(B, U1, MemberEvent.WARNING, D1, T0)
        await s.record(A, U1, MemberEvent.BAN, D1, T0)
        a, b = await s.get(A, U1, D1), await s.get(B, U1, D1)
        self.assertEqual((a.total_messages, a.warnings, a.bans), (3, 0, 1))
        self.assertEqual((b.total_messages, b.warnings, b.bans), (1, 1, 0))

    async def test_every_event_has_its_own_counter_and_sanctions_do_not_set_the_last_activity(self):
        s = InMemoryMemberStatsStore()
        for event in (MemberEvent.DELETED, MemberEvent.VIOLATION, MemberEvent.WARNING, MemberEvent.MUTE, MemberEvent.BAN):
            await s.record(A, U1, event, D1, T0)
        m = await s.get(A, U1, D1)
        self.assertEqual((m.total_messages, m.deleted_messages, m.violations, m.warnings, m.mutes, m.bans), (0, 1, 1, 1, 1, 1))
        self.assertIsNone(m.last_activity_at)

    async def test_top_is_per_group_ordered_by_total_then_id_and_limited(self):
        s = InMemoryMemberStatsStore()
        for user, n in ((U2, 3), (U1, 3), (7001, 5), (7002, 1)):
            for _ in range(n):
                await s.record(A, user, MemberEvent.MESSAGE, D1, T0)
        await s.record(B, 9999, MemberEvent.MESSAGE, D1, T0)
        top = await s.top(A, 3, D1)
        self.assertEqual([m.user_id for m in top], [7001, U1, U2])
        self.assertNotIn(9999, [m.user_id for m in await s.top(A, 20, D1)])

    async def test_totals_sum_one_group_only(self):
        s = InMemoryMemberStatsStore()
        for user in (U1, U2):
            await s.record(A, user, MemberEvent.MESSAGE, D1, T0)
            await s.record(A, user, MemberEvent.WARNING, D1, T0)
        await s.record(B, U1, MemberEvent.MESSAGE, D1, T0)
        t = await s.totals(A, D1)
        self.assertEqual((t.members, t.total_messages, t.today_messages, t.warnings), (2, 2, 2, 2))
        self.assertEqual(await s.totals(-999, D1), GroupTotals(-999))

    async def test_unknown_member_and_bad_amount(self):
        s = InMemoryMemberStatsStore()
        self.assertIsNone(await s.get(A, U1, D1))
        with self.assertRaises(ValueError):
            await s.record(A, U1, MemberEvent.MESSAGE, D1, T0, 0)


# ------------------------------------------------------------------------------------------------ recorder
class FailingStore(InMemoryMemberStatsStore):
    async def record(self, *a, **k):
        raise RuntimeError("db down")


class DownClaims:
    async def claim(self, key, now=None):
        raise RuntimeError("claims down")


class RecorderTests(unittest.IsolatedAsyncioTestCase):
    def make(self, store=None, claims=None, clock=None):
        self.store = store or InMemoryMemberStatsStore()
        self.clock = clock or Clock()
        return MemberStatsRecorder(self.store, claims if claims is not None else InMemoryIdempotency(), TZ, self.clock)

    async def test_a_message_delivered_twice_counts_once(self):
        r = self.make()
        self.assertTrue(await r.message(A, U1, 10))
        self.assertFalse(await r.message(A, U1, 10))
        self.assertTrue(await r.message(A, U1, 11))
        self.assertEqual((await self.store.get(A, U1, D1)).total_messages, 2)

    async def test_the_same_message_id_in_two_groups_is_two_messages(self):
        r = self.make()
        self.assertTrue(await r.message(A, U1, 10))
        self.assertTrue(await r.message(B, U1, 10))
        self.assertEqual((await self.store.get(B, U1, D1)).total_messages, 1)

    async def test_invalid_input_never_raises_and_never_counts(self):
        r = self.make()
        for g, u, m in ((None, U1, 1), (A, None, 1), (A, True, 1), (A, 0, 1), (A, U1, 0), (A, U1, True), ("x", U1, 1), (5, U1, 1)):
            self.assertFalse(await r.message(g, u, m), (g, u, m))
        self.assertIsNone(await self.store.get(A, U1, D1))

    async def test_a_failing_store_is_swallowed(self):
        r = self.make(store=FailingStore())
        self.assertFalse(await r.message(A, U1, 1))
        self.assertFalse(await r.event(A, U1, MemberEvent.WARNING))
        await r.message_acted_on(A, U1, 1, True)  # must not raise

    async def test_when_the_claim_store_is_down_the_tick_is_skipped_not_doubled(self):
        r = self.make(claims=DownClaims())
        self.assertFalse(await r.message(A, U1, 1))
        self.assertIsNone(await self.store.get(A, U1, D1))

    async def test_violation_and_deletion_count_once_per_message_even_when_two_components_report_it(self):
        r = self.make()
        await r.message_acted_on(A, U1, 5, False)   # e.g. the content filter acted without the delete right
        await r.message_acted_on(A, U1, 5, True)    # then the engine deleted it
        await r.message_acted_on(A, U1, 5, True)    # and a redelivery
        m = await self.store.get(A, U1, D1)
        self.assertEqual((m.violations, m.deleted_messages), (1, 1))

    async def test_today_follows_the_display_timezone(self):
        late = datetime(2026, 11, 6, 20, 59, tzinfo=timezone.utc)   # 23:59 in Riyadh
        r = self.make(clock=Clock(late))
        await r.message(A, U1, 1)
        r2 = MemberStatsRecorder(self.store, InMemoryIdempotency(), TZ, Clock(late + timedelta(minutes=1)))  # 00:00 next day
        await r2.message(A, U1, 2)
        m = await self.store.get(A, U1, date(2026, 11, 7))
        self.assertEqual((m.total_messages, m.today_messages), (2, 1))


# ------------------------------------------------------------------------------------------------ tracking decorators
class TrackingTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.store = InMemoryMemberStatsStore()
        self.rec = MemberStatsRecorder(self.store, InMemoryIdempotency(), TZ, Clock())

    async def stats(self, g=A, u=U1) -> MemberStats:
        return await self.store.get(g, u, D1)

    async def test_warnings_are_counted_when_created_and_a_repeated_key_is_not(self):
        w = TrackingWarningStore(InMemoryWarningStore(), self.rec)
        await w.add(A, U1, OWNER, "x", T0, None, "k1")
        await w.add(A, U1, OWNER, "x", T0, None, "k1")       # redelivered command: same key
        await w.add(A, U1, None, "auto", T0, None, "k2")
        self.assertEqual((await self.stats()).warnings, 2)
        await w.revoke_all(A, U1, OWNER, T0)                  # clearing warnings does not lower the history
        self.assertEqual((await self.stats()).warnings, 2)
        self.assertEqual(await w.count_active(A, U1, T0), 0)  # every other method is delegated

    async def test_mutes_and_bans_are_counted_but_a_kick_is_not(self):
        s = TrackingSanctionStore(InMemorySanctionStore(), self.rec)
        until = T0 + timedelta(hours=1)
        await s.record(A, U1, SanctionKind.MUTE, OWNER, None, T0, until, None, "m1")
        await s.record(A, U1, SanctionKind.MUTE, OWNER, None, T0, until, None, "m1")   # same key
        await s.record(A, U1, SanctionKind.BAN, OWNER, None, T0, None, None, "b1")
        await s.record(A, U1, SanctionKind.KICK, OWNER, None, T0, None, None, "k1")
        m = await self.stats()
        self.assertEqual((m.mutes, m.bans, m.warnings), (1, 1, 0))
        await s.lift(A, U1, SanctionKind.BAN, OWNER, T0)      # lifting does not lower it
        self.assertEqual((await self.stats()).bans, 1)

    async def test_the_automatic_mute_of_the_engine_ledger_path_is_counted(self):
        from guardian.protection.offenses import SanctionOffenseLedger
        ledger = SanctionOffenseLedger(TrackingSanctionStore(InMemorySanctionStore(), self.rec))
        await ledger.record_mute(A, U1, "links", 60, T0, "key-1")
        await ledger.record_mute(A, U1, "links", 60, T0, "key-1")
        self.assertEqual((await self.stats()).mutes, 1)

    async def test_the_content_ledger_ban_mute_and_warn_rows(self):
        led = TrackingContentLedger(InMemoryContentLedger(), self.rec)
        for action, key in (("ban", "a"), ("mute", "b"), ("warn", "c"), ("review", "d"), ("ban", "a")):
            await led.record(A, U1, "message", "explicit", action, T0, key)
        m = await self.stats()
        self.assertEqual((m.bans, m.mutes, m.warnings), (1, 1, 1))
        self.assertEqual(await led.count_since(A, U1, T0 - timedelta(hours=1)), 4)  # delegated

    async def test_a_broken_recorder_never_changes_the_result(self):
        class Boom:
            async def event(self, *a, **k):
                raise RuntimeError("boom")
        w = TrackingWarningStore(InMemoryWarningStore(), Boom())
        warning, created = await w.add(A, U1, OWNER, "x", T0)
        self.assertTrue(created)
        self.assertEqual(warning.user_id, U1)


# ------------------------------------------------------------------------------------------------ middleware
class MiddlewareTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A, B)
        await self.s.admin.activate_permanent(OWNER, A)          # B stays pending (no licence)
        self.store = InMemoryMemberStatsStore()
        self.rec = MemberStatsRecorder(self.store, InMemoryIdempotency(), TZ, self.s.clock)
        self.gate = ProtectionGate(self.s.license_service, self.s.perm, FakeNotifier(), clock=self.s.clock)
        self.today = self.s.clock().astimezone(timezone.utc).date()

    def event(self, mid=1, group=A, user=STRANGER, ctype="supergroup", content="text", bot=False, sender_chat=None):
        return NS(chat=NS(id=group, type=ctype, title="T"), from_user=NS(id=user, is_bot=bot) if user else None,
                  sender_chat=sender_chat, message_id=mid, content_type=content, text="hello")

    async def feed(self, event, edit=False, record=True):
        async def handler_(e, data):
            return "handled"
        mw = ProtectionGateMiddleware(self.gate, is_edit=edit, member_stats=self.rec if record else None)
        return await mw(handler_, event, {})

    async def total(self, group=A, user=STRANGER):
        m = await self.store.get(group, user, self.s.clock().date())
        return 0 if m is None else m.total_messages

    async def test_a_group_message_counts_and_the_handler_still_runs(self):
        self.assertEqual(await self.feed(self.event()), "handled")
        self.assertEqual(await self.total(), 1)

    async def test_the_same_update_processed_twice_counts_once(self):
        await self.feed(self.event(mid=7))
        await self.feed(self.event(mid=7))
        self.assertEqual(await self.total(), 1)

    async def test_an_edit_is_never_a_new_message(self):
        await self.feed(self.event(mid=7))
        await self.feed(self.event(mid=7), edit=True)
        await self.feed(self.event(mid=99), edit=True)    # even an edit whose original was never seen
        self.assertEqual(await self.total(), 1)

    async def test_what_is_not_a_member_message_is_not_counted(self):
        cases = {
            "service": self.event(mid=1, content="new_chat_members"),
            "bot": self.event(mid=2, bot=True),
            "anonymous admin / channel": self.event(mid=3, sender_chat=NS(id=A)),
            "no sender": self.event(mid=4, user=None),
            "private chat": self.event(mid=5, group=STRANGER, ctype="private"),
            "unlicensed group": self.event(mid=6, group=B),
        }
        for name, ev in cases.items():
            await self.feed(ev)
            self.assertEqual(await self.total(A), 0, name)
            self.assertEqual(await self.total(B), 0, name)
            self.assertEqual(await self.total(STRANGER, STRANGER), 0, name)

    async def test_administrators_and_the_owner_are_counted_too(self):
        await self.feed(self.event(mid=1, user=TG_ADMIN))
        await self.feed(self.event(mid=2, user=OWNER))
        self.assertEqual(await self.total(A, TG_ADMIN), 1)
        self.assertEqual(await self.total(A, OWNER), 1)

    async def test_without_a_recorder_nothing_changes(self):
        self.assertEqual(await self.feed(self.event(), record=False), "handled")
        self.assertEqual(await self.total(), 0)

    async def test_a_recorder_that_raises_never_blocks_the_update(self):
        class Boom:
            async def message(self, *a, **k):
                raise RuntimeError("boom")
        async def handler_(e, data):
            return "handled"
        mw = ProtectionGateMiddleware(self.gate, member_stats=Boom())
        self.assertEqual(await mw(handler_, self.event(), {}), "handled")


# ------------------------------------------------------------------------------------------------ engine and content filter
class EngineStatsTests(tpe.Base):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.store = InMemoryMemberStatsStore()
        self.rec = MemberStatsRecorder(self.store, InMemoryIdempotency(), TZ, self.s.clock)
        from guardian.protection.engine import ProtectionEngine
        self.engine = ProtectionEngine(self.s.settings_store, self.actions, self.s.chat, self.claims, self.s.audit, self.notifier,
                                       clock=self.s.clock, member_stats=self.rec)

    async def member(self, user=tpe.STRANGER):
        return await self.store.get(A, user, self.s.clock().date())

    async def test_a_violation_is_counted_once_with_its_deletion_even_on_redelivery(self):
        first = await self.send("buy at https://evil.com", mid=50)
        self.assertEqual(first.kind, OutcomeKind.ACTED)
        again = await self.send("buy at https://evil.com", mid=50)
        self.assertEqual(again.kind, OutcomeKind.DUPLICATE_DELIVERY)
        m = await self.member()
        self.assertEqual((m.violations, m.deleted_messages), (1, 1))

    async def test_no_delete_right_means_a_violation_without_a_deletion(self):
        self.actions.delete_result = tpe.ActionResult(False)
        await self.send("buy at https://evil.com", mid=51)
        m = await self.member()
        self.assertEqual((m.violations, m.deleted_messages), (1, 0))

    async def test_a_clean_message_and_a_dry_run_are_not_violations(self):
        await self.send("hello there", mid=52)
        self.assertIsNone(await self.member())
        await self.cfg(dry_run=True)
        await self.send("buy at https://evil.com", mid=53)
        self.assertIsNone(await self.member())

    async def test_another_group_and_another_member_are_untouched(self):
        await self.send("buy at https://evil.com", mid=54)
        self.assertIsNone(await self.store.get(B, tpe.STRANGER, self.s.clock().date()))
        self.assertIsNone(await self.member(user=tpe.STRANGER + 5))


class GuardStatsTests(tcf.GuardBase):
    def build(self, ai, notifier=None):
        self.store = InMemoryMemberStatsStore()
        self.rec = MemberStatsRecorder(self.store, InMemoryIdempotency(), TZ, self.s.clock)
        from guardian.content_filter.service import ContentGuard
        return ContentGuard(self.s.settings_store, self.actions, self.s.chat, InMemoryIdempotency(), self.s.audit,
                            TrackingContentLedger(self.ledger, self.rec), self.reviews, ai=ai, photos=self.actions,
                            permissions=self.s.perm, notifier=notifier, owner_ids=(OWNER,), clock=self.s.clock,
                            member_stats=self.rec)

    async def test_a_banned_emoji_counts_a_violation_a_deletion_and_a_ban_once(self):
        self.assertTrue(await self.say("شوف 🍆 هنا", mid=77))
        self.assertTrue(await self.say("شوف 🍆 هنا", mid=77))   # redelivery
        m = await self.store.get(A, STRANGER, self.s.clock().date())
        self.assertEqual((m.violations, m.deleted_messages, m.bans), (1, 1, 1))

    async def test_a_clean_message_counts_nothing(self):
        self.assertFalse(await self.say("مرحبا بالجميع"))
        self.assertIsNone(await self.store.get(A, STRANGER, self.s.clock().date()))


# ------------------------------------------------------------------------------------------------ parser
class ParserTests(unittest.TestCase):
    def kind(self, text, bot="gbot"):
        p = parse_member_stats_command(text, bot)
        return None if p is None else p.kind

    def test_the_required_commands_in_both_languages(self):
        for text, kind in (("/userstats", USER), ("/احصائيات_عضو", USER), ("/topmembers", TOP), ("/اكثر_الاعضاء", TOP),
                           ("/groupstats", GROUP), ("/احصائيات_القروب", GROUP)):
            self.assertEqual(self.kind(text), kind, text)

    def test_arabic_spelling_variants_and_forms(self):
        for text, kind in (("/إحصائيات_عضو", USER), ("/احصاءات_عضو", USER), ("/أكثر_الأعضاء", TOP), ("/اكثر_الاعضاء_نشاطا", TOP),
                           ("/إحصائيات_القروب", GROUP), ("/احصائيات_المجموعة", GROUP), ("/احصائيات_المجموعه", GROUP),
                           ("/احصائيات_الجروب", GROUP), ("احصائيات عضو", USER), ("إحصائيات العضو", USER),
                           ("أكثر الأعضاء", TOP), ("اكثر الاعضاء نشاطا", TOP), ("احصائيات القروب", GROUP),
                           ("إحصائيات المجموعة", GROUP), ("/احصائيات القروب", GROUP), ("/اكثر الاعضاء 5", TOP)):
            self.assertEqual(self.kind(text), kind, text)

    def test_arguments_are_kept(self):
        self.assertEqual(parse_member_stats_command("/userstats 123").args, ("123",))
        self.assertEqual(parse_member_stats_command("/topmembers 5").args, ("5",))
        self.assertEqual(parse_member_stats_command("/groupstats -1001234567890").args, ("-1001234567890",))
        self.assertEqual(parse_member_stats_command("احصائيات عضو @abcde").args, ("@abcde",))

    def test_addressing_another_bot_is_not_ours(self):
        self.assertEqual(self.kind("/userstats@gbot"), USER)
        self.assertEqual(self.kind("/userstats@GBOT 1"), USER)
        self.assertIsNone(self.kind("/userstats@otherbot"))
        self.assertIsNone(self.kind("/userstats@gbot", bot=None))

    def test_ordinary_talk_is_not_swallowed(self):
        for text in ("احصائيات القروب كيف الحال", "احصائيات عضو ممتاز جدا", "اكثر الاعضاء نشاطا في الدنيا مين", "احصائيات",
                     "هل احصائيات القروب جيدة", "مرحبا", "", "   ", "/stats", "/userstat", "/احصائيات", None, 5, "احصائيات عضو 1 2"):
            self.assertIsNone(parse_member_stats_command(text, "gbot"), repr(text))

    def test_a_very_long_text_is_not_a_command(self):
        self.assertIsNone(parse_member_stats_command("/userstats " + "1 " * 100))


# ------------------------------------------------------------------------------------------------ service
class Usernames:
    def __init__(self, known=None):
        self.known = known or {}

    async def resolve(self, group_id, username):
        return self.known.get((group_id, username))


class ServiceTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        self.store = InMemoryMemberStatsStore()
        self.clock = Clock()
        self.svc = MemberStatsCommandService(store=self.store, permissions=self.s.perm, usernames=Usernames({(A, "abcde"): U1}),
                                             clock=self.clock)
        for _ in range(7):
            await self.store.record(A, U1, MemberEvent.MESSAGE, D1, T0)
        for _ in range(3):
            await self.store.record(B, U1, MemberEvent.MESSAGE, D1, T0)
        for event in (MemberEvent.WARNING, MemberEvent.WARNING, MemberEvent.MUTE, MemberEvent.BAN, MemberEvent.VIOLATION,
                      MemberEvent.DELETED):
            await self.store.record(A, U1, event, D1, T0)
        await self.store.record(B, U1, MemberEvent.BAN, D1, T0)
        await self.store.record(B, U1, MemberEvent.BAN, D1, T0)
        await self.store.record(A, U2, MemberEvent.MESSAGE, D1, T0)

    async def run_cmd(self, text, *, chat=A, chat_type="supergroup", user=OWNER, reply=None, lang="ar"):
        parsed = parse_member_stats_command(text, "gbot")
        return await self.svc.run(parsed, chat_id=chat, chat_type=chat_type, user_id=user, reply=reply, lang=lang)

    async def test_userstats_shows_this_groups_numbers_only(self):
        r = await self.run_cmd("/userstats", reply=ReplyInfo(U1))
        self.assertEqual(r.status, "ok")
        self.assertIn("إجمالي الرسائل: <b>7</b>", r.text)
        self.assertIn("رسائل اليوم: <b>7</b>", r.text)
        self.assertIn("التحذيرات: <b>2</b>", r.text)
        self.assertIn("مرات الكتم: <b>1</b>", r.text)
        self.assertIn("مرات الحظر: <b>1</b>", r.text)       # group B has 2 bans: never merged
        self.assertIn("المخالفات: <b>1</b>", r.text)
        self.assertIn("2026-11-06 15:00 (Asia/Riyadh)", r.text)
        self.assertIn(f"tg://user?id={U1}", r.text)

    async def test_the_same_member_in_the_other_group(self):
        r = await self.run_cmd(f"/userstats {U1}", chat=B)
        self.assertIn("إجمالي الرسائل: <b>3</b>", r.text)
        self.assertIn("مرات الحظر: <b>2</b>", r.text)

    async def test_target_by_id_username_and_english(self):
        by_id = await self.run_cmd(f"/احصائيات_عضو {U1}")
        by_name = await self.run_cmd("/userstats @abcde", lang="en")
        self.assertIn("إجمالي الرسائل: <b>7</b>", by_id.text)
        self.assertIn("Total messages: <b>7</b>", by_name.text)

    async def test_target_errors_are_usage_messages_not_guesses(self):
        for text, reply in (("/userstats", None), ("/userstats abc", None), (f"/userstats {U1} {U2}", None),
                            (f"/userstats {U1}", ReplyInfo(U2)), ("/userstats", ReplyInfo(None, sender_chat=True)),
                            ("/userstats @zzzzzz", None), ("/userstats 0", None)):
            r = await self.run_cmd(text, reply=reply)
            self.assertEqual(r.status, "usage", text)

    async def test_a_member_with_no_record(self):
        r = await self.run_cmd("/userstats 424242")
        self.assertEqual(r.status, "empty")
        self.assertIn("424242", r.text)

    async def test_a_member_who_left_still_has_the_record(self):
        # nothing in the bot deletes a member's record on leave/kick/ban: the stored numbers are simply still there
        await self.store.record(A, U1, MemberEvent.MESSAGE, D1, T0 + timedelta(hours=1))
        r = await self.run_cmd(f"/userstats {U1}")
        self.assertIn("إجمالي الرسائل: <b>8</b>", r.text)

    async def test_topmembers_default_limit_and_range(self):
        r = await self.run_cmd("/topmembers")
        self.assertEqual(r.status, "ok")
        self.assertLess(r.text.index(f"id={U1}"), r.text.index(f"id={U2}"))
        self.assertEqual((await self.run_cmd("/اكثر_الاعضاء 1")).text.count("tg://user"), 1)
        for bad in ("/topmembers 0", "/topmembers 21", "/topmembers x", "/topmembers 1 2"):
            self.assertEqual((await self.run_cmd(bad)).status, "usage", bad)

    async def test_groupstats_sums_this_group_only(self):
        r = await self.run_cmd("/groupstats")
        self.assertEqual(r.status, "ok")
        self.assertIn("أعضاء لهم سجل: <b>2</b>", r.text)
        self.assertIn("إجمالي الرسائل: <b>8</b>", r.text)
        self.assertIn("مرات الحظر: <b>1</b>", r.text)
        self.assertEqual((await self.run_cmd("/groupstats now")).status, "usage")

    async def test_an_empty_group(self):
        for text in ("/groupstats", "/topmembers"):
            r = await self.run_cmd(text, chat=-1009)
            self.assertEqual(r.status, "empty")

    async def test_only_the_primary_owner_gets_an_answer_everybody_else_gets_silence(self):
        for who in (TG_ADMIN, DELEGATE, STRANGER, BACKUP, 12345):
            for text in ("/userstats 5001", "/topmembers", "/groupstats"):
                self.assertIsNone(await self.run_cmd(text, user=who), (who, text))
        self.assertIsNotNone(await self.run_cmd("/groupstats"))

    async def test_silence_also_for_wrong_chats_and_bad_ids(self):
        p = parse_member_stats_command("/groupstats")
        for chat, kind, user in ((A, "channel", OWNER), (OWNER, "private", STRANGER), (None, "supergroup", OWNER),
                                 (True, "supergroup", True), (A, "supergroup", None), (A, None, OWNER)):
            self.assertIsNone(await self.svc.run(p, chat_id=chat, chat_type=kind, user_id=user), (chat, kind, user))

    async def test_a_refused_owner_check_or_a_broken_one_is_silence(self):
        class Raises:
            async def check_global(self, *a):
                raise RuntimeError("db")
        svc = MemberStatsCommandService(store=self.store, permissions=Raises())
        self.assertIsNone(await svc.run(parse_member_stats_command("/groupstats"), chat_id=A, chat_type="supergroup", user_id=OWNER))

    async def test_in_private_the_group_id_comes_first(self):
        r = await self.run_cmd("/groupstats", chat=OWNER, chat_type="private")
        self.assertEqual((r.status, "-100" in r.text or "معرّف" in r.text), ("usage", True))
        ok = await self.run_cmd(f"/groupstats {A}", chat=OWNER, chat_type="private")
        self.assertIn("إجمالي الرسائل: <b>8</b>", ok.text)
        top = await self.run_cmd(f"/topmembers {B} 5", chat=OWNER, chat_type="private")
        self.assertNotIn(f"id={U2}", top.text)                # U2 never wrote in B
        user = await self.run_cmd(f"/userstats {A} {U1}", chat=OWNER, chat_type="private")
        self.assertIn("إجمالي الرسائل: <b>7</b>", user.text)

    async def test_in_a_group_the_chat_is_always_the_group_and_a_foreign_id_is_refused(self):
        r = await self.run_cmd(f"/groupstats {B}", chat=A)
        self.assertEqual(r.status, "usage")

    async def test_nothing_is_ever_written(self):
        writes = []
        original = self.store.record

        async def spy(*a, **k):
            writes.append(a)
            return await original(*a, **k)
        self.store.record = spy
        for text in ("/userstats 5001", "/topmembers", "/groupstats"):
            await self.run_cmd(text)
        self.assertEqual(writes, [])

    async def test_english_output_and_a_missing_store(self):
        r = await self.run_cmd("/groupstats", lang="en")
        self.assertIn("Members on record", r.text)
        svc = MemberStatsCommandService(store=None, permissions=self.s.perm)
        out = await svc.run(parse_member_stats_command("/groupstats"), chat_id=A, chat_type="supergroup", user_id=OWNER)
        self.assertEqual(out.status, "unavailable")

    async def test_today_is_zero_when_the_member_did_not_write_today(self):
        self.svc._clock = Clock(T0 + timedelta(days=1))
        r = await self.run_cmd("/userstats 5001")
        self.assertIn("رسائل اليوم: <b>0</b>", r.text)
        self.assertIn("إجمالي الرسائل: <b>7</b>", r.text)


# ------------------------------------------------------------------------------------------------ handler adapter
class FakeBot:
    async def me(self):
        return NS(username="gbot")


class FakeMessage:
    def __init__(self, text, chat_id=A, chat_type="supergroup", user=OWNER, bot=False, reply_uid=None):
        self.text = text
        self.chat = NS(id=chat_id, type=chat_type)
        self.from_user = NS(id=user, is_bot=bot, language_code="ar")
        self.reply_to_message = (NS(message_id=5, from_user=NS(id=reply_uid, is_bot=False), sender_chat=None)
                                 if reply_uid else None)
        self.sent: list[str] = []

    async def answer(self, text, **kw):
        self.sent.append(text)


class HandlerTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        self.store = InMemoryMemberStatsStore()
        await self.store.record(A, U1, MemberEvent.MESSAGE, D1, T0)
        self.services = NS(settings=NS(default_language="ar"),
                           owner_member_stats=MemberStatsCommandService(store=self.store, permissions=self.s.perm,
                                                                        clock=Clock()))

    async def test_matching(self):
        bot = FakeBot()
        self.assertEqual((await handler.match_member_stats_command(FakeMessage("/userstats@gbot 5"), bot)).kind, USER)
        self.assertEqual((await handler.match_member_stats_command(FakeMessage("/topmembers", chat_type="group"), bot)).kind, TOP)
        self.assertEqual((await handler.match_member_stats_command(FakeMessage("احصائيات القروب", chat_type="private"), bot)).kind, GROUP)
        for msg in (FakeMessage("/groupstats", chat_type="channel"), FakeMessage("/groupstats", bot=True),
                    FakeMessage("hello"), FakeMessage("/userstats@other 1")):
            self.assertIsNone(await handler.match_member_stats_command(msg, bot))

    async def test_the_owner_gets_the_answer_in_the_chat_and_admins_get_nothing(self):
        parsed = parse_member_stats_command("/userstats")
        owner_msg = FakeMessage("/userstats", reply_uid=U1)
        self.assertEqual(await handler.execute_member_stats(owner_msg, parsed, services=self.services), "ok")
        self.assertEqual(len(owner_msg.sent), 1)
        self.assertIn("إجمالي الرسائل: <b>1</b>", owner_msg.sent[0])
        for who in (TG_ADMIN, STRANGER, DELEGATE):
            msg = FakeMessage("/userstats", user=who, reply_uid=U1)
            self.assertIsNone(await handler.execute_member_stats(msg, parsed, services=self.services))
            self.assertEqual(msg.sent, [])

    async def test_no_service_means_no_answer(self):
        msg = FakeMessage("/groupstats")
        self.assertIsNone(await handler.execute_member_stats(msg, parse_member_stats_command("/groupstats"),
                                                              services=NS(settings=NS(default_language="ar"))))
        self.assertEqual(msg.sent, [])


# ------------------------------------------------------------------------------------------------ PostgreSQL layer and structure
class RecordingConn:
    def __init__(self, row=None, rows=()):
        self.calls, self.row, self.rows = [], row, list(rows)

    async def execute(self, sql, *args):
        self.calls.append((sql, args))

    async def fetchrow(self, sql, *args):
        self.calls.append((sql, args))
        return self.row

    async def fetch(self, sql, *args):
        self.calls.append((sql, args))
        return self.rows


class RecordingDb:
    def __init__(self, conn):
        self.conn = conn

    @asynccontextmanager
    async def acquire(self):
        yield self.conn


MEMBER_ROW = {"user_id": U1, "total_messages": 4, "today_messages": 2, "deleted_messages": 1, "violations": 1, "warnings": 2,
              "mutes": 0, "bans": 0, "last_activity_at": T0, "first_seen_at": T0}


class PostgresStoreTests(unittest.IsolatedAsyncioTestCase):
    async def test_message_upsert_is_keyed_by_group_and_member_and_resets_today_atomically(self):
        conn = RecordingConn()
        await PostgresMemberStatsStore(RecordingDb(conn)).record(A, U1, MemberEvent.MESSAGE, D1, T0)
        sql, args = conn.calls[0]
        self.assertTrue(sql.startswith("INSERT INTO member_activity_stats"))
        self.assertIn("ON CONFLICT (group_id, user_id) DO UPDATE", sql)
        self.assertIn("total_messages = member_activity_stats.total_messages + EXCLUDED.total_messages", sql)
        self.assertIn("CASE WHEN member_activity_stats.today_date = EXCLUDED.today_date", sql)
        self.assertEqual(args, (A, U1, 1, D1, T0))

    async def test_each_counter_upsert_touches_exactly_its_own_column(self):
        self.assertEqual(set(COUNTER_SQL), set(EVENT_COLUMN) - {MemberEvent.MESSAGE})
        for event, sql in COUNTER_SQL.items():
            column = EVENT_COLUMN[event]
            conn = RecordingConn()
            await PostgresMemberStatsStore(RecordingDb(conn)).record(B, U2, event, D1, T0, 1)
            used, args = conn.calls[0]
            self.assertIs(used, sql)
            self.assertIn(f"{column} = member_activity_stats.{column} + EXCLUDED.{column}", sql)
            self.assertEqual(args, (B, U2, 1, T0))
            others = [c for e, c in EVENT_COLUMN.items() if c != column]
            self.assertFalse(any(re.search(rf"\b{o}\b", sql) for o in others), (event, sql))

    async def test_reads_filter_by_group_and_map_the_rows(self):
        conn = RecordingConn(row=MEMBER_ROW, rows=[MEMBER_ROW])
        store = PostgresMemberStatsStore(RecordingDb(conn))
        m = await store.get(A, U1, D1)
        self.assertEqual((m.group_id, m.user_id, m.total_messages, m.today_messages, m.warnings), (A, U1, 4, 2, 2))
        self.assertEqual(conn.calls[0][1], (A, D1, U1))
        top = await store.top(A, 5, D1)
        self.assertEqual([x.user_id for x in top], [U1])
        self.assertEqual(conn.calls[1][1], (A, D1, 5))
        self.assertIn("ORDER BY total_messages DESC, user_id ASC LIMIT $3", conn.calls[1][0])
        for sql, _ in conn.calls:
            self.assertIn("group_id = $1", sql)

    async def test_totals_and_missing_rows(self):
        conn = RecordingConn(row={"members": 2, "total_messages": 9, "today_messages": 3, "deleted_messages": 1, "violations": 1,
                                  "warnings": 2, "mutes": 1, "bans": 1, "last_activity_at": T0})
        t = await PostgresMemberStatsStore(RecordingDb(conn)).totals(A, D1)
        self.assertEqual((t.group_id, t.members, t.total_messages, t.bans), (A, 2, 9, 1))
        self.assertIn("WHERE group_id = $1", conn.calls[0][0])
        self.assertIsNone(await PostgresMemberStatsStore(RecordingDb(RecordingConn())).get(A, U1, D1))
        with self.assertRaises(ValueError):
            await PostgresMemberStatsStore(RecordingDb(RecordingConn())).record(A, U1, MemberEvent.MESSAGE, D1, T0, 0)


class StructureTests(unittest.TestCase):
    def read(self, *parts):
        return Path(SRC, *parts).read_text(encoding="utf-8")

    def test_the_migration_is_the_newest_and_does_not_touch_older_tables(self):
        self.assertEqual([v for v, _ in discover()][-1], "0013_member_activity_stats")
        sql = SQL.read_text(encoding="utf-8")
        code = "\n".join(line for line in sql.splitlines() if not line.lstrip().startswith("--"))
        self.assertEqual(re.findall(r"(?i)CREATE TABLE IF NOT EXISTS (\w+)", code), ["member_activity_stats"])
        self.assertNotRegex(code.replace("ON DELETE RESTRICT", ""), r"(?i)\b(DROP|DELETE|TRUNCATE|ALTER)\b")
        self.assertIn("PRIMARY KEY (group_id, user_id)", code)
        self.assertIn("REFERENCES telegram_groups (group_id) ON DELETE RESTRICT", code)

    def test_the_columns_match_the_code(self):
        code = "\n".join(line for line in SQL.read_text(encoding="utf-8").splitlines() if not line.lstrip().startswith("--"))
        columns = set(re.findall(r"^\s{4}(\w+)\s+(?:BIGINT|DATE|TIMESTAMPTZ)\b", code, re.M))
        self.assertTrue(set(EVENT_COLUMN.values()) <= columns)
        fields = set(MemberStats.__dataclass_fields__) - {"group_id"}
        self.assertEqual(fields, columns - {"group_id", "today_date", "updated_at"} | set())  # today_messages / last_activity_at / first_seen_at

    def test_no_code_deletes_member_statistics(self):
        for path in SRC.rglob("*.py"):
            text = path.read_text(encoding="utf-8")
            if "member_activity_stats" in text:
                self.assertNotRegex(text, r"(?i)(DELETE\s+FROM|TRUNCATE|DROP\s+TABLE)\s+member_activity_stats", path.name)
        self.assertNotIn("member_activity_stats", self.read("members", "postgres_store.py"))
        self.assertNotIn("member_activity_stats", self.read("backup", "postgres_restore.py"))

    def test_the_backup_leaves_the_table_alone_on_purpose(self):
        from guardian.backup.format import EXCLUDED_TABLES, TABLE_NAMES
        self.assertIn("member_activity_stats", EXCLUDED_TABLES)
        self.assertNotIn("member_activity_stats", TABLE_NAMES)

    def test_edits_never_reach_the_recorder(self):
        factory = self.read("bot", "factory.py")
        message_mw = re.search(r"dp\.message\.outer_middleware\((.*?)\)\)\n", factory, re.S).group(1)
        edited_mw = re.search(r"dp\.edited_message\.outer_middleware\((.*?)\)\)\n", factory, re.S).group(1)
        self.assertIn("member_stats=", message_mw)
        self.assertNotIn("member_stats", edited_mw)
        mw = self.read("bot", "middlewares.py")
        self.assertIn("self._is_edit", mw[mw.index("async def _count_message"):])

    def test_the_wiring_in_the_app(self):
        app = self.read("app.py")
        for needle in ("MemberStatsRecorder(member_stats_store, claims", "TrackingWarningStore(warning_store, member_stats)",
                       "TrackingSanctionStore(sanction_store, member_stats)", "WarningService(tracked_warning_store",
                       "SanctionService(tracked_sanction_store", "SanctionOffenseLedger(tracked_sanction_store)",
                       "TrackingContentLedger(PostgresContentLedger(database), member_stats)", "owner_member_stats=MemberStatsCommandService(",
                       "member_stats=member_stats"):
            self.assertIn(needle, app, needle)
        from guardian.services import Services
        self.assertIn("owner_member_stats", Services.__dataclass_fields__)
        self.assertIn("member_stats", Services.__dataclass_fields__)
        self.assertIn("_is_member_stats_command", self.read("bot", "routers", "owner_panel.py"))

    def test_the_commands_are_not_shown_to_administrators(self):
        listed = set(commands_menu.BASIC + commands_menu.PUBLIC + commands_menu.MODERATION)
        for name in ("userstats", "topmembers", "groupstats", "user_stats", "top_members", "group_stats"):
            self.assertNotIn(name, listed)
        for spec in commands_menu.build_menus():
            self.assertFalse({c for c, _ in spec.commands} & {"userstats", "topmembers", "groupstats"})
        mentions = {key for lang in MESSAGES.values() for key, text in lang.items()
                    if re.search(r"userstats|topmembers|groupstats", text)}
        self.assertTrue(mentions <= {"commands_owner", "ms_usage_user", "ms_usage_top", "ms_usage_group"}, mentions)
        arabic = {key for lang in MESSAGES.values() for key, text in lang.items() if "احصائيات_عضو" in text}
        self.assertTrue(arabic <= {"commands_owner", "ms_usage_user"}, arabic)

    def test_arabic_and_english_texts_have_the_same_keys(self):
        ms = {lang: {k for k in MESSAGES[lang] if k.startswith("ms_")} for lang in MESSAGES}
        self.assertEqual(ms["ar"], ms["en"])
        self.assertGreaterEqual(len(ms["ar"]), 15)


if __name__ == "__main__":
    unittest.main()
