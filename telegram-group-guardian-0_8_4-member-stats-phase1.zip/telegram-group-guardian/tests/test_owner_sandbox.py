"""Phase 5 / part 5.8: the owner's sandbox. Every verdict comes from the REAL protection engine wired to fakes only; the tests
prove that nothing reaches Telegram or any production store, and that the only way out is a template + the confirmed apply flow."""
from __future__ import annotations

import re
import string
import unittest
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace as NS

import helpers  # noqa: F401
from guardian.audit import SANDBOX_ENDED, SANDBOX_STARTED, TEMPLATE_SAVED
from guardian.bot import owner_panel_handler as h
from guardian.errors import GroupNotRegistered, InvalidInput, PermissionDenied
from guardian.i18n import MESSAGES
from guardian.idempotency import InMemoryIdempotency
from guardian.owner_panel.sandbox_commands import (
    ParsedSandboxCommand as P, SandboxCommandService, fmt_span, parse_sandbox_command)
from guardian.owner_sandbox.sandbox import (
    MAX_LOG, MAX_TEXT, SANDBOX_GROUP_ID, USER_BASE, FakeActions, FakeChatInfo, SandboxSession, user_id)
from guardian.owner_sandbox.service import NoSession, SandboxService
from guardian.protection.engine import AUTO_SANCTION
from guardian.owner_templates.apply import TemplateApplyService
from guardian.owner_templates.templates import InMemoryTemplateStore, TemplateService, effective_settings
from stack import A, B, BACKUP, DELEGATE, NOW, OWNER, STRANGER, TG_CREATOR, Stack

SRC = Path(__file__).resolve().parents[1] / "src" / "guardian"
LINK = "see https://spam.example.com/x now"


async def session(**settings) -> SandboxSession:
    return await SandboxSession(OWNER, "default", {**effective_settings({}), **settings}, clock_start=NOW).prepare()


# ----------------------------------------------------------------------------- the simulated protection
class SessionRuleTests(unittest.IsolatedAsyncioTestCase):
    async def test_only_the_first_thousand_characters_are_inspected(self):
        s = await session()
        self.assertEqual((await s.say(1, "x" * MAX_TEXT + " https://late.example/")).verdict, "ok")
        self.assertEqual((await s.say(2, "x" * (MAX_TEXT - 30) + " https://in.example/")).violation, "links")

    async def test_a_link_is_deleted_and_the_member_muted_virtually(self):
        s = await session()
        ok = await s.say(1, "hello everyone")
        bad = await s.say(1, LINK)
        self.assertEqual((ok.verdict, ok.violation), ("ok", None))
        self.assertEqual((bad.verdict, bad.violation, bad.deleted, bad.muted_seconds), ("acted", "links", True, 600))
        self.assertEqual([c[0] for c in s.actions.calls], ["delete", "mute"])
        self.assertEqual(s.violations, 1)

    async def test_the_allow_list_and_the_switch(self):
        s = await session(links_allow_domains=["ok.example"])
        self.assertEqual((await s.say(1, "https://ok.example/page")).verdict, "ok")
        self.assertEqual((await s.say(2, "https://bad.example/page")).violation, "links")
        await s.set("links_enabled", False)
        self.assertEqual((await s.say(3, "https://bad.example/page")).verdict, "ok")

    async def test_flood(self):
        s = await session(flood_max_messages=3, flood_window_seconds=10)
        verdicts = [(await s.say(1, f"m{i}")).violation for i in range(4)]
        self.assertEqual(verdicts, [None, None, None, "flood"])
        muted = await s.say(1, "after the mute")                                       # a muted member cannot post
        self.assertEqual((muted.verdict, muted.violation), ("muted", None))
        self.assertGreater(muted.muted_seconds, 0)
        s.wait(601)
        self.assertEqual((await s.say(1, "back")).verdict, "ok")
        self.assertEqual(s.violations, 1)

    async def test_duplicates(self):
        s = await session(duplicate_max_repeats=3, duplicate_min_length=5)
        out = [(await s.say(1, "the very same text")).violation for _ in range(3)]
        self.assertEqual(out, [None, None, "duplicate"])
        self.assertEqual((await s.say(1, "the very same text")).verdict, "muted")
        self.assertIsNone((await s.say(2, "the very same text")).violation)          # per member

    async def test_slow_mode_and_the_virtual_wait(self):
        s = await session(slowmode_seconds=30)
        self.assertEqual((await s.say(1, "one")).verdict, "ok")
        slow = await s.say(1, "two")
        self.assertEqual((slow.violation, slow.deleted, slow.muted_seconds), ("slowmode", True, None))   # delete only
        s.wait(60)
        self.assertEqual((await s.say(1, "three")).verdict, "ok")

    async def test_newcomer_window(self):
        s = await session(newbie_seconds=3600, newbie_block_links=True, links_enabled=False)
        s.join(2)
        self.assertEqual((await s.say(2, "https://x.example")).violation, "newbie")
        self.assertEqual((await s.say(1, "https://x.example")).verdict, "ok")             # u1 is not a newcomer (links rule is off)
        both = await session(newbie_seconds=3600, newbie_block_links=True)
        both.join(2)
        self.assertEqual((await both.say(2, "https://x.example")).violation, "links")     # the ordinary link rule ranks first
        s2 = await session(newbie_seconds=3600, newbie_block_messages=True, links_enabled=False)
        s2.join(3)
        self.assertEqual((await s2.say(3, "hi")).violation, "newbie")
        s2.wait(3601)
        self.assertEqual((await s2.say(3, "hi again")).verdict, "ok")

    async def test_escalation_follows_the_offense_count(self):
        s = await session()
        first = await s.say(1, LINK)
        s.wait(first.muted_seconds + 5)                                                   # the first mute is over
        second = await s.say(1, LINK)
        self.assertGreater(second.muted_seconds, first.muted_seconds)

    async def test_media_and_edits(self):
        s = await session(newbie_seconds=3600, newbie_block_media=True)
        s.join(1)
        self.assertEqual((await s.say(1, "pic", media=True)).violation, "newbie")
        self.assertEqual((await session()).violations, 0)
        e = await (await session()).say(1, "plain edit", edit=True)
        self.assertEqual(e.verdict, "ok")

    async def test_virtual_time_and_the_log(self):
        s = await session()
        first = await s.say(1, "a")
        s.wait(100)
        last = await s.say(1, "b")
        self.assertEqual((last.at - first.at).total_seconds(), 101)
        self.assertEqual([e.n for e in s.log], [1, 2, 3])
        self.assertEqual([e.kind for e in s.log], ["message", "wait", "message"])

    async def test_the_log_is_bounded_and_text_clipped(self):
        s = await session(flood_enabled=False)
        for i in range(MAX_LOG + 10):
            await s.say(1, "x" * 5000)
        self.assertEqual(len(s.log), MAX_LOG)
        self.assertLessEqual(len(s.log[-1].text), 60)
        self.assertEqual(s.log[-1].n, MAX_LOG + 10)

    async def test_input_validation(self):
        s = await session()
        for bad in (0, 10, True, None, "1", -1):
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError):
                    await s.say(bad, "x")
                with self.assertRaises(ValueError):
                    s.join(bad)
        for bad in (0, -5, 7 * 24 * 3600 + 1, True, "5"):
            with self.subTest(wait=bad), self.assertRaises(ValueError):
                s.wait(bad)

    async def test_set_uses_the_template_whitelist_and_changes_nothing_on_error(self):
        s = await session()
        before = dict(s.settings)
        for key, value in (("dry_run", True), ("nope", 1), ("flood_max_messages", 100000), ("links_enabled", "yes"),
                           ("welcome_text", "{name.__class__}")):
            with self.subTest(key=key), self.assertRaises(InvalidInput):
                await s.set(key, value)
        self.assertEqual(s.settings, before)
        await s.set("flood_max_messages", 2)
        self.assertEqual((s.settings["flood_max_messages"], s.origin["flood_max_messages"]), (2, 6))

    async def test_diff_against_a_group(self):
        s = await session(warn_limit=9)
        entries, same = s.diff_against(effective_settings({}))
        self.assertEqual([(e.key, e.group, e.template) for e in entries], [("warn_limit", 3, 9)])
        self.assertEqual(same, 40)


class FakeTests(unittest.IsolatedAsyncioTestCase):
    async def test_fakes_only_record(self):
        a = FakeActions()
        self.assertTrue((await a.delete_message(1, 2)).ok)
        self.assertTrue((await a.mute_member(1, 2, NOW)).ok)
        self.assertEqual(a.calls, [("delete", 2), ("mute", 2, NOW)])
        info = await FakeChatInfo().get_bot_member(1)
        self.assertTrue(info.can_delete_messages and info.can_restrict_members)

    async def test_simulated_ids_cannot_be_real_chats_or_known_users(self):
        self.assertEqual(user_id(1), USER_BASE + 1)
        self.assertTrue(-1_000_000_000_000 < SANDBOX_GROUP_ID < -10_000_000_000)             # neither a -100… supergroup nor a small basic group id
        self.assertGreater(USER_BASE, 6_000_000_000)

    async def test_the_engine_events_stay_inside_the_session(self):
        s = await session()
        await s.say(1, LINK)
        self.assertEqual([e.event_type for e in s._audit.events], [AUTO_SANCTION])


# ----------------------------------------------------------------------------- the service
class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        self.store = InMemoryTemplateStore()
        self.tpl = TemplateService(self.store, self.s.licenses, self.s.settings_store, self.s.perm, self.s.audit, clock=self.s.clock)
        self.sb = SandboxService(self.tpl, self.s.audit, clock=self.s.clock)
        await self.s.register(A, B)
        for g in (A, B):
            await self.s.admin.activate_permanent(OWNER, g, context_chat_id=g)
        await self.s.settings_store.merge(A, {"warn_limit": 7, "flood_max_messages": 9}, OWNER, NOW)
        self.t, _ = await self.tpl.save_from_group(OWNER, "Strict", A)

    def prod(self):
        return ({g: (dict(r.settings) if (r := self.s.settings_store._rows.get(g)) else None) for g in (A, B)},
                dict(self.s.licenses._rows), list(self.s.licenses.audit_log), dict(self.store._rows))

    def kinds(self):
        return [e.event_type for e in self.s.audit.events]


class ServiceTests(Base):
    async def test_owner_only(self):
        await self.sb.start(OWNER, None)
        ops = lambda who: (self.sb.start(who, None), self.sb.status(who), self.sb.say(who, 1, "x"), self.sb.join(who, 1),
                           self.sb.wait(who, 5), self.sb.set(who, "warn_limit", 5), self.sb.log(who), self.sb.diff(who, A),
                           self.sb.save(who, "n"), self.sb.end(who))
        for who in (BACKUP, STRANGER, TG_CREATOR, DELEGATE, None):
            for op in ops(who):
                with self.subTest(who=who), self.assertRaises(PermissionDenied):
                    await op
        self.assertEqual((await self.sb.status(OWNER))._n, 0)                              # the owner's session survived

    async def test_sources(self):
        d = await self.sb.start(OWNER, None)
        self.assertEqual((d.source, d.settings), ("default", effective_settings({})))
        g = await self.sb.start(OWNER, A)
        self.assertEqual((g.source, g.settings["warn_limit"], g.source_name), (f"group:{A}", 7, str(A)))
        t = await self.sb.start(OWNER, " strict ")
        self.assertEqual((t.source, t.settings["flood_max_messages"], t.source_name), (f"template:{self.t.id}", 9, "Strict"))
        for bad in ("nope", ""):
            with self.assertRaises(InvalidInput):
                await self.sb.start(OWNER, bad)
        with self.assertRaises(GroupNotRegistered):
            await self.sb.start(OWNER, -4242)
        with self.assertRaises(InvalidInput):
            await self.sb.start(OWNER, 55)

    async def test_a_partial_template_still_gives_a_full_sandbox(self):
        await self.store.upsert("Mini", "mini", {"warn_limit": 5}, OWNER, None, NOW)
        sess = await self.sb.start(OWNER, "mini")
        self.assertEqual(sess.settings, {**effective_settings({}), "warn_limit": 5})
        self.assertEqual(set((await self.sb.save(OWNER, "FullCopy"))[0].settings), set(effective_settings({})))

    async def test_save_from_settings_validates_like_every_template(self):
        for bad in ({"dry_run": True}, {"nope": 1}, {}, {"flood_max_messages": 10**6}):
            with self.subTest(bad=bad), self.assertRaises(InvalidInput):
                await self.tpl.save_from_settings(OWNER, "Bad", bad)
        with self.assertRaises(PermissionDenied):
            await self.tpl.save_from_settings(STRANGER, "X", {"warn_limit": 4})

    async def test_no_session_and_idle_expiry(self):
        with self.assertRaises(NoSession):
            await self.sb.say(OWNER, 1, "x")
        await self.sb.start(OWNER, None)
        self.s.clock.advance(hours=2, seconds=1)
        with self.assertRaises(NoSession):
            await self.sb.status(OWNER)
        await self.sb.start(OWNER, None)
        self.s.clock.advance(hours=1)
        await self.sb.say(OWNER, 1, "alive")                                                 # activity keeps it alive
        self.s.clock.advance(hours=1, minutes=30)
        self.assertEqual((await self.sb.status(OWNER))._n, 1)

    async def test_a_failed_start_keeps_the_running_session(self):
        await self.sb.start(OWNER, None)
        await self.sb.say(OWNER, 1, "kept")
        for bad in ("nope", -4242, 55):
            with self.assertRaises((InvalidInput, GroupNotRegistered)):
                await self.sb.start(OWNER, bad)
        self.assertEqual((await self.sb.status(OWNER))._n, 1)
        self.assertEqual(self.kinds().count(SANDBOX_ENDED), 0)

    async def test_start_replaces_and_end_reports_counts(self):
        await self.sb.start(OWNER, None)
        await self.sb.say(OWNER, 1, LINK)
        await self.sb.start(OWNER, None)
        self.assertEqual((await self.sb.status(OWNER))._n, 0)
        await self.sb.say(OWNER, 1, LINK)
        await self.sb.say(OWNER, 1, "fine")
        self.assertEqual(await self.sb.end(OWNER), (2, 1))
        with self.assertRaises(NoSession):
            await self.sb.end(OWNER)
        self.assertEqual(self.kinds().count(SANDBOX_STARTED), 2)
        ended = [e for e in self.s.audit.events if e.event_type == SANDBOX_ENDED]
        self.assertEqual([e.detail for e in ended], ["events=1 violations=1", "events=2 violations=1"])

    async def test_production_is_untouched_by_a_long_experiment(self):
        before = self.prod()
        audit_before = len(self.s.audit.events)
        await self.sb.start(OWNER, A)
        await self.sb.set(OWNER, "flood_max_messages", 2)
        for i in range(30):
            await self.sb.say(OWNER, 1 + i % 3, LINK if i % 2 else f"m{i}")
        await self.sb.join(OWNER, 4)
        await self.sb.wait(OWNER, 99)
        await self.sb.diff(OWNER, B)
        await self.sb.end(OWNER)
        self.assertEqual(self.prod(), before)
        self.assertEqual(sorted({e.event_type for e in self.s.audit.events[audit_before:]}), [SANDBOX_ENDED, SANDBOX_STARTED])

    async def test_audit_never_contains_experiment_contents(self):
        await self.sb.start(OWNER, A)
        await self.sb.say(OWNER, 1, "https://secret-domain.example/x")
        await self.sb.end(OWNER)
        for e in self.s.audit.events:
            self.assertNotIn("secret-domain", e.detail or "")

    async def test_the_source_is_a_copy(self):
        await self.sb.start(OWNER, " Strict")
        await self.sb.set(OWNER, "flood_max_messages", 2)
        self.assertEqual((await self.store.get(self.t.id)).settings["flood_max_messages"], 9)
        self.assertEqual(self.s.settings_store._rows[A].settings["flood_max_messages"], 9)

    async def test_diff_is_read_only_and_needs_a_registered_group(self):
        await self.sb.start(OWNER, None)
        await self.sb.set(OWNER, "warn_limit", 9)
        before = self.prod()
        entries, same = await self.sb.diff(OWNER, A)
        self.assertEqual({(e.key, e.group, e.template) for e in entries}, {("warn_limit", 7, 9), ("flood_max_messages", 9, 6)})
        self.assertEqual(self.prod(), before)
        with self.assertRaises(GroupNotRegistered):
            await self.sb.diff(OWNER, -4242)

    async def test_save_makes_a_template_and_never_touches_a_group(self):
        await self.sb.start(OWNER, None)
        await self.sb.set(OWNER, "flood_max_messages", 3)
        groups_before = self.prod()[:3]
        tpl, created = await self.sb.save(OWNER, "Sandbox One")
        self.assertTrue(created)
        self.assertEqual(self.prod()[:3], groups_before)
        self.assertEqual(tpl.settings["flood_max_messages"], 3)
        self.assertNotIn("dry_run", tpl.settings)
        self.assertEqual((await self.sb.save(OWNER, "sandbox one"))[1], False)
        saved = [e for e in self.s.audit.events if e.event_type == TEMPLATE_SAVED][-1]
        self.assertIn("source=sandbox", saved.detail)
        for bad in ("", "---", "x" * 41):
            with self.assertRaises(InvalidInput):
                await self.sb.save(OWNER, bad)

    async def test_the_way_out_is_template_then_the_confirmed_apply(self):
        await self.sb.start(OWNER, A)
        await self.sb.set(OWNER, "warn_limit", 4)
        tpl, _ = await self.sb.save(OWNER, "FromSandbox")
        applier = TemplateApplyService(self.tpl, self.s.licenses, self.s.settings, InMemoryIdempotency(), self.s.audit)
        pv = await applier.preview(OWNER, tpl.id, [B])
        self.assertIn("warn_limit", {e.key for e in pv.items[0].entries})
        self.assertEqual(self.s.settings_store._rows.get(B), None)                          # still nothing written
        out = await applier.execute(OWNER, tpl.id, [(B, pv.items[0].digest)], "c1")
        self.assertEqual(out[0].status, "applied")
        self.assertEqual(self.s.settings_store._rows[B].settings["warn_limit"], 4)


# ----------------------------------------------------------------------------- commands
class ParserTests(unittest.TestCase):
    def test_english(self):
        cases = {
            "/sandbox": P("status"), "/sandbox status": P("status"), "/sandbox start default": P("start"),
            "/sandbox start Strict Mode": P("start", source="Strict Mode"), "/sandbox start -1001": P("start", source=-1001),
            "/sandbox say hello  world": P("say", user=1, text="hello  world"), "/sandbox say u3 hi": P("say", user=3, text="hi"),
            "/sandbox say U2 https://a.example/x?y=1": P("say", user=2, text="https://a.example/x?y=1"),
            "/sandbox say u3": P("usage"), "/sandbox say": P("usage"),
            "/sandbox media": P("media", user=1, text=""), "/sandbox media u4 pic": P("media", user=4, text="pic"),
            "/sandbox join": P("join"), "/sandbox join u5": P("join", user=5), "/sandbox join u5 x": P("usage"),
            "/sandbox wait 90": P("wait", seconds=90), "/sandbox wait 0": P("usage"), "/sandbox wait x": P("usage"),
            "/sandbox wait 99999999999": P("usage"), "/sandbox set warn_limit 5": P("set", key="warn_limit", value=5),
            "/sandbox set links_allow_domains [\"a.com\"]": P("set", key="links_allow_domains", value=["a.com"]),
            "/sandbox set welcome_text hello there": P("set", key="welcome_text", value="hello there"),
            "/sandbox set warn_limit": P("usage"), "/sandbox settings": P("settings"), "/sandbox log": P("log"),
            "/sandbox diff -5": P("diff", group_id=-5), "/sandbox diff 5": P("usage"), "/sandbox save My T": P("save", name="My T"),
            "/sandbox save": P("usage"), "/sandbox end": P("end"), "/sandbox end now": P("usage"), "/sandbox nope": P("usage"),
        }
        for text, want in cases.items():
            with self.subTest(text=text):
                self.assertEqual(parse_sandbox_command(text), want)

    def test_arabic(self):
        cases = {
            "تجربة": P("status"), "تجربة بدء افتراضي": P("start"), "تجربة بدء default": P("start"),
            "تجربة بدء صارم": P("start", source="صارم"), "تجربة رسالة u2 مرحبا بكم": P("say", user=2, text="مرحبا بكم"),
            "تجربة انضمام u2": P("join", user=2), "تجربة انتظر ٩٠": P("wait", seconds=90), "تجربة اضبط warn_limit 4": P("set", key="warn_limit", value=4),
            "تجربة الاعدادات": P("settings"), "تجربة الإعدادات": P("settings"), "تجربة سجل": P("log"), "تجربة قارن -١٠٠": P("diff", group_id=-100),
            "تجربة احفظ اسم": P("save", name="اسم"), "تجربة إنهاء": P("end"), "تجربة شيء": None, "تجريبي": None, "تجربة رسالة": P("usage"),
        }
        for text, want in cases.items():
            with self.subTest(text=text):
                self.assertEqual(parse_sandbox_command(text), want)

    def test_not_ours_and_bounds(self):
        for text in ("/owner", "/sandboxes", "hello", "", None, 5, "/sandbox@OtherBot say x", "/sandbox say " + "x" * (MAX_TEXT + 100)):
            self.assertIsNone(parse_sandbox_command(text, "GBot"))
        self.assertEqual(parse_sandbox_command("/sandbox@GBot log", "gbot"), P("log"))
        self.assertIsNone(parse_sandbox_command("/sandbox@GBot log"))
        self.assertEqual(parse_sandbox_command("/sandbox say " + "x" * MAX_TEXT).action, "say")

    def test_spans(self):
        self.assertEqual(fmt_span(30, "ar"), "30 ثانية")
        self.assertEqual(fmt_span(600, "ar"), "10 دقيقة")
        self.assertEqual(fmt_span(7200, "en"), "2 h")
        self.assertEqual(fmt_span(172800, "en"), "2 d")


class CommandTests(Base):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.cmd = SandboxCommandService(self.sb, self.tpl, self.s.licenses)

    async def run_(self, text, user=OWNER, chat=None, ctype="private"):
        return await self.cmd.run(parse_sandbox_command(text), chat_id=user if chat is None else chat, chat_type=ctype, user_id=user)

    async def test_every_reply_is_labelled_simulated(self):
        for text in ("/sandbox", "/sandbox start default", "/sandbox say hi", "/sandbox say " + LINK, "/sandbox join u2", "/sandbox wait 5",
                     "/sandbox set warn_limit 4", "/sandbox settings", "/sandbox log", f"/sandbox diff {A}", "/sandbox save Mine",
                     "/sandbox", "/sandbox end", "/sandbox say after end", "/sandbox nope", "/sandbox start nope"):
            reply = await self.run_(text)
            self.assertTrue(reply.text.startswith(MESSAGES["ar"]["sbx_banner"]), text)

    async def test_a_full_experiment_reads_well(self):
        self.assertEqual((await self.run_("/sandbox")).status, "no_session")
        self.assertEqual((await self.run_("/sandbox start Strict")).status, "started")
        ok = await self.run_("/sandbox say hello")
        self.assertIn("مقبولة", ok.text)
        bad = await self.run_("/sandbox say u2 " + LINK)
        self.assertEqual(bad.status, "message")
        for needle in ("u2", "روابط", "كان سيحذف الرسالة", "ويكتم العضو 10 دقيقة"):
            self.assertIn(needle, bad.text)
        self.assertIn("1", (await self.run_("/sandbox status")).text)
        self.assertEqual((await self.run_("/sandbox set flood_max_messages 2")).status, "set")
        self.assertIn("flood_max_messages", (await self.run_("/sandbox settings")).text)
        log = await self.run_("/sandbox log")
        self.assertIn("1.", log.text)
        self.assertIn("«hello»", log.text)
        diff = await self.run_(f"/sandbox diff {B}")
        self.assertEqual(diff.status, "diff")
        self.assertIn("/template apply", diff.text)
        saved = await self.run_("/sandbox save Result")
        self.assertIn("/template apply Result", saved.text)
        self.assertIn("3 حدثًا", (await self.run_("/sandbox end")).text)         # hello, the link, the setting

    async def test_set_errors_and_unknown_sources_are_plain_replies(self):
        await self.run_("/sandbox start default")
        self.assertEqual((await self.run_("/sandbox set dry_run true")).status, "set_invalid")
        self.assertEqual((await self.run_("/sandbox set nope 1")).status, "set_invalid")
        self.assertEqual((await self.run_("/sandbox start nope")).status, "bad_input")
        self.assertEqual((await self.run_("/sandbox diff -4242")).status, "bad_input")
        self.assertEqual((await self.run_("/sandbox save ---")).status, "bad_input")

    async def test_only_the_owner_in_a_private_chat_is_answered(self):
        for who in (BACKUP, STRANGER, TG_CREATOR, DELEGATE):
            for text in ("/sandbox", "/sandbox start default", "/sandbox say hi", "/sandbox save x"):
                self.assertIsNone(await self.run_(text, user=who))
        for text in ("/sandbox nope", "/sandbox end", "/sandbox start", "/sandbox log"):               # even the usage text stays private
            for who in (BACKUP, STRANGER, TG_CREATOR, DELEGATE):
                self.assertIsNone(await self.run_(text, user=who), text)
        for ctype in ("group", "supergroup", "channel"):                                            # same id as the user, wrong chat type
            self.assertIsNone(await self.run_("/sandbox", ctype=ctype))
        self.assertIsNone(await self.run_("/sandbox", ctype="supergroup", chat=A))
        self.assertIsNone(await self.run_("/sandbox", chat=OWNER + 1))
        self.assertEqual(self.kinds().count(SANDBOX_STARTED), 0)

    async def test_failures_are_safe_replies(self):
        class Boom:
            async def status(self, *a): raise RuntimeError("boom")

        cmd = SandboxCommandService(Boom(), self.tpl, self.s.licenses)
        reply = await cmd.run(P("status"), chat_id=OWNER, chat_type="private", user_id=OWNER)
        self.assertEqual(reply.status, "failed")


class GlueTests(Base):
    def msg(self, text, *, chat="private", user=OWNER, bot=False):
        sent = []

        async def answer(text, **kw):
            sent.append(text)

        return NS(text=text, chat=NS(id=user, type=chat), from_user=NS(id=user, is_bot=bot, language_code="ar"), answer=answer), sent

    async def test_matching_and_execution(self):
        bot = NS()
        self.assertEqual(await h.match_sandbox_command(self.msg("/sandbox log")[0], bot), P("log"))
        self.assertEqual(await h.match_sandbox_command(self.msg("تجربة سجل")[0], bot), P("log"))
        for kw in (dict(chat="supergroup"), dict(bot=True)):
            self.assertIsNone(await h.match_sandbox_command(self.msg("/sandbox log", **kw)[0], bot))
        services = NS(owner_sandbox=SandboxCommandService(self.sb, self.tpl, self.s.licenses), settings=NS(default_language="ar"))
        message, sent = self.msg("/sandbox start default")
        self.assertEqual(await h.execute_sandbox(message, P("start"), services=services), "started")
        self.assertEqual(len(sent), 1)
        stranger, sent2 = self.msg("/sandbox", user=STRANGER)
        self.assertIsNone(await h.execute_sandbox(stranger, P("status"), services=services))
        self.assertEqual(sent2, [])
        self.assertIsNone(await h.execute_sandbox(message, P("status"), services=NS(owner_sandbox=None, settings=NS(default_language="ar"))))

    async def test_a_failing_send_is_swallowed(self):
        services = NS(owner_sandbox=SandboxCommandService(self.sb, self.tpl, self.s.licenses), settings=NS(default_language="ar"))
        message, _ = self.msg("/sandbox")

        async def broken(*a, **kw):
            raise RuntimeError("telegram down")

        message.answer = broken
        self.assertEqual(await h.execute_sandbox(message, P("status"), services=services), "no_session")


# ----------------------------------------------------------------------------- static guards
class StaticGuardTests(unittest.TestCase):
    def read(self, rel):
        return (SRC / rel).read_text(encoding="utf-8")

    def test_the_sandbox_package_has_no_telegram_and_no_production_stores(self):
        for path in (SRC / "owner_sandbox").glob("*.py"):
            src = path.read_text(encoding="utf-8")
            for forbidden in ("aiogram", "Postgres", "postgres_store", "licensing.store", "from ..app", "from ..bot", "Bot(", "services"):
                self.assertNotIn(forbidden, src, f"{path.name}: {forbidden}")
        src = self.read("owner_sandbox/sandbox.py")
        imports = set(re.findall(r"^from \.\.([\w.]+) import", src, re.M))
        self.assertTrue(imports <= {"audit", "groups.memory_store", "idempotency", "members.newcomers", "moderation.memory_store",
                                    "owner_templates.templates", "protection.engine", "protection.offenses", "protection_gate",
                                    "telegram_rights", "time_utils"}, imports)
        self.assertEqual(sorted(set(re.findall(r"\b(InMemory\w+)", src))), ["InMemoryIdempotency", "InMemorySanctionStore",
                                                                              "InMemorySecurityAudit", "InMemorySettingsStore"])

    def test_the_service_touches_production_only_through_the_template_service_and_the_audit(self):
        src = self.read("owner_sandbox/service.py")
        self.assertEqual(sorted(set(re.findall(r"self\._templates\.(\w+)\(", src))),
                         ["find", "group_effective", "require_owner", "save_from_settings"])
        self.assertEqual(sorted(set(re.findall(r"self\._audit", src))), ["self._audit"])
        self.assertNotIn(".merge(", src)
        self.assertNotIn(".update(", src)

    def test_commands_never_write_a_group(self):
        src = self.read("owner_panel/sandbox_commands.py")
        self.assertNotRegex(src, r"\.(merge|update|set_language|transition|claim)\(")
        self.assertEqual(sorted(set(re.findall(r"sb\.(\w+)\(", src))),
                         ["diff", "end", "join", "log", "save", "say", "set", "start", "status", "wait"])

    def test_wiring(self):
        self.assertIn("owner_sandbox", self.read("services.py"))
        app = self.read("app.py")
        for needle in ("SandboxService(template_service, security_audit)", "owner_sandbox=SandboxCommandService("):
            self.assertIn(needle, app)
        router = self.read("bot/routers/owner_panel.py")
        self.assertIn("match_sandbox_command", router)
        self.assertIn("execute_sandbox", router)

    def test_i18n_keys_exist_in_both_languages_with_equal_placeholders(self):
        keys = set(re.findall(r'"(sbx_[a-z_]+)"', self.read("owner_panel/sandbox_commands.py")))
        keys |= {f"sbx_v_{v}" for v in ("links", "flood", "duplicate", "slowmode", "newbie")}
        keys |= {f"sbx_span_{u}" for u in "smhd"}
        self.assertGreaterEqual(len(keys), 30)
        for key in sorted(keys):
            fields = []
            for lang in ("ar", "en"):
                self.assertIn(key, MESSAGES[lang], key)
                fields.append({n for _, n, _, _ in string.Formatter().parse(MESSAGES[lang][key]) if n})
            self.assertEqual(fields[0], fields[1], key)
        for lang in ("ar", "en"):
            self.assertIn("🧪", MESSAGES[lang]["sbx_banner"])


if __name__ == "__main__":
    unittest.main()
