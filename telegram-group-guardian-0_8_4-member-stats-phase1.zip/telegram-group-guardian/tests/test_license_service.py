import asyncio
import unittest
from datetime import datetime, timedelta, timezone

from guardian.licensing.memory_store import InMemoryLicenseStore
from guardian.licensing.models import DenyReason, GroupLicense, LicenseStatus
from guardian.licensing.service import LicenseService

NOW = datetime(2026, 10, 29, 12, 0, tzinfo=timezone.utc)
A, B = -1001, -1002


def seed(store, group_id, status, expires_at=None):
    store._rows[group_id] = GroupLicense(group_id=group_id, title="t", status=status, updated_at=NOW, expires_at=expires_at)


class ServiceTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.store = InMemoryLicenseStore()
        self.service = LicenseService(self.store)

    async def test_new_group_is_pending_and_protection_denied(self):
        license_, created = await self.service.on_bot_added(A, "Group A", NOW)
        self.assertTrue(created)
        self.assertIs(license_.status, LicenseStatus.PENDING)
        decision = await self.service.check(A, NOW)
        self.assertFalse(decision.allowed)
        self.assertIs(decision.reason, DenyReason.PENDING)
        self.assertEqual([e.action for e in self.store.audit_log], ["register_pending"])

    async def test_readding_bot_never_changes_status(self):
        for status in (LicenseStatus.ACTIVE_PERMANENT, LicenseStatus.EXPIRED, LicenseStatus.STOPPED, LicenseStatus.REJECTED, LicenseStatus.BANNED):
            with self.subTest(status=status):
                seed(self.store, A, status)
                license_, created = await self.service.on_bot_added(A, "renamed", NOW)
                self.assertFalse(created)
                self.assertIs(license_.status, status)
                self.assertEqual(license_.title, "renamed")  # metadata may refresh
        self.assertEqual(len(self.store.audit_log), 0)  # nothing registered

    async def test_unknown_group_denied_not_registered(self):
        self.assertIs((await self.service.check(A, NOW)).reason, DenyReason.NOT_REGISTERED)

    async def test_permanent_allowed(self):
        seed(self.store, A, LicenseStatus.ACTIVE_PERMANENT)
        self.assertTrue((await self.service.check(A, NOW)).allowed)

    async def test_expired_after_service_slept_first_update_denied(self):
        # Row still says ACTIVE_TEMPORARY (no scheduler ran while the host was asleep).
        seed(self.store, A, LicenseStatus.ACTIVE_TEMPORARY, expires_at=NOW + timedelta(hours=1))
        later = NOW + timedelta(days=3)
        decision = await self.service.check(A, later)
        self.assertFalse(decision.allowed)
        self.assertIs(decision.reason, DenyReason.EXPIRED)
        self.assertIs((await self.store.get(A)).status, LicenseStatus.EXPIRED)  # persisted lazily

    async def test_expiry_transition_recorded_exactly_once_under_concurrency(self):
        seed(self.store, A, LicenseStatus.ACTIVE_TEMPORARY, expires_at=NOW)
        results = await asyncio.gather(*[self.service.check(A, NOW + timedelta(minutes=1)) for _ in range(10)])
        self.assertTrue(all(not r.allowed for r in results))
        self.assertEqual([e.action for e in self.store.audit_log], ["auto_expire"])
        await self.service.check(A, NOW + timedelta(hours=1))  # later checks add nothing
        self.assertEqual(len(self.store.audit_log), 1)

    async def test_failure_persisting_expiry_never_allows(self):
        seed(self.store, A, LicenseStatus.ACTIVE_TEMPORARY, expires_at=NOW)

        async def boom(*a, **k):
            raise RuntimeError("db write failed")

        self.store.transition = boom
        decision = await self.service.check(A, NOW + timedelta(seconds=5))
        self.assertFalse(decision.allowed)
        self.assertIs(decision.reason, DenyReason.EXPIRED)

    async def test_store_failure_fails_closed(self):
        async def boom(*a, **k):
            raise RuntimeError("db down")

        self.store.get = boom
        decision = await self.service.check(A, NOW)
        self.assertFalse(decision.allowed)
        self.assertIs(decision.reason, DenyReason.STORE_UNAVAILABLE)

    async def test_groups_are_isolated(self):
        seed(self.store, A, LicenseStatus.ACTIVE_PERMANENT)
        self.assertTrue((await self.service.check(A, NOW)).allowed)
        self.assertFalse((await self.service.check(B, NOW)).allowed)
        await self.service.on_bot_added(B, "B", NOW)
        self.assertIs((await self.store.get(A)).status, LicenseStatus.ACTIVE_PERMANENT)
        self.assertIs((await self.store.get(B)).status, LicenseStatus.PENDING)

    async def test_cas_transition_rejects_stale_expected_status(self):
        seed(self.store, A, LicenseStatus.STOPPED)
        stale = GroupLicense(group_id=A, title="t", status=LicenseStatus.EXPIRED, updated_at=NOW)
        from guardian.licensing.models import AuditEvent

        ok = await self.store.transition(
            A,
            expected_status=LicenseStatus.ACTIVE_TEMPORARY,
            new_license=stale,
            audit=AuditEvent(A, "auto_expire", LicenseStatus.ACTIVE_TEMPORARY, LicenseStatus.EXPIRED, NOW),
        )
        self.assertFalse(ok)
        self.assertIs((await self.store.get(A)).status, LicenseStatus.STOPPED)
        self.assertEqual(self.store.audit_log, [])


if __name__ == "__main__":
    unittest.main()
