"""Closing part 3: /lock /unlock (lock_commands.py + the aiogram adapter `set_default_permissions`)."""
from __future__ import annotations

import dataclasses
import unittest
from types import SimpleNamespace as NS

from executor_stack import A, B, BOT, BrokenClaims, ExecBase, gate
from guardian.bot.actions import AiogramModerationActions
from guardian.moderation import config_args as ca
from guardian.moderation.executor import ResultKind as R
from guardian.moderation.lock_commands import PermissionChange
from guardian.permissions import GroupRole
from guardian.telegram_rights import ChatMemberInfo
from stack import BACKUP, DELEGATE, OWNER, STRANGER, TG_ADMIN, TG_LIMITED_ADMIN

ANON = 1_087_968_824


class LockExecTests(ExecBase):
    def tg_calls(self):
        return [c for c in self.actions.calls if c[0] == "set_perms"]

    async def test_lock_and_unlock_media(self):
        r = await self.run_cmd("/lock media")
        self.assertEqual(r.kind, R.DONE)
        self.assertEqual([(c[1], set(c[2]), c[3]) for c in self.tg_calls()], [(A, set(ca.FLAG_MEDIA), False)])
        self.assertIn("الوسائط", r.text)
        r = await self.run_cmd("/unlock media", msg=2)
        self.assertEqual(r.kind, R.DONE)
        self.assertTrue(self.tg_calls()[-1][3])
        self.assertEqual([t for t in self.audit_types() if t.startswith("chat_")], ["chat_locked", "chat_unlocked"])

    async def test_lock_all_uses_every_sending_flag_and_no_dangerous_one(self):
        await self.run_cmd("/lock all")
        flags = set(self.tg_calls()[0][2])
        self.assertEqual(flags, set(ca.LOCKABLE_FLAGS))
        self.assertTrue(flags.isdisjoint({"can_change_info", "can_invite_users", "can_pin_messages", "can_manage_topics"}))

    async def test_arabic_alias_and_english_text(self):
        r = await self.run_cmd("قفل الوسائط")
        self.assertEqual(r.kind, R.DONE)
        r = await self.run_cmd("فتح الوسائط", msg=2)
        self.assertEqual(r.kind, R.DONE)
        self.assertEqual([c[3] for c in self.tg_calls()], [False, True])

    async def test_already_in_state_is_a_noop_without_audit(self):
        self.actions.perm_change = PermissionChange(True, None, False)
        r = await self.run_cmd("/lock polls")
        self.assertEqual(r.kind, R.NOOP)
        self.assertEqual([t for t in self.audit_types() if t.startswith("chat_")], [])

    async def test_invalid_arguments_touch_nothing_and_consume_no_claim(self):
        for text in ("/lock", "/lock bogus", "/lock links", "/unlock media oops"):
            r = await self.run_cmd(text)
            self.assertEqual(r.kind, R.INVALID, text)
        self.assertEqual(self.actions.calls, [])
        self.assertEqual(self.claims._keys, {})
        self.assertIn("/protect links on", (await self.run_cmd("/lock links")).text)

    async def test_only_moderators_may_lock(self):
        for actor in (STRANGER, TG_LIMITED_ADMIN, BACKUP, ANON):
            r = await self.run_cmd("/lock all", actor=actor)
            self.assertEqual(r.kind, R.DENIED, actor)
        self.assertEqual(self.actions.calls, [])
        await self.s.delegations.grant(OWNER, A, DELEGATE, GroupRole.MODERATOR)
        self.assertEqual((await self.run_cmd("/lock text", actor=DELEGATE)).kind, R.DONE)
        self.assertEqual((await self.run_cmd("/unlock text", actor=OWNER, msg=3)).kind, R.DONE)

    async def test_admin_of_another_group_cannot_lock_this_one(self):
        r = await self.run_cmd("/lock all", chat=B, actor=TG_ADMIN)  # TG_ADMIN is an admin of A only
        self.assertEqual(r.kind, R.DENIED)
        self.assertEqual(self.actions.calls, [])
        await self.run_cmd("/lock all", chat=A)
        self.assertEqual({c[1] for c in self.tg_calls()}, {A})

    async def test_license_must_be_active_for_this_chat(self):
        for ctx in (None, gate(A, allowed=False), gate(B, allowed=True)):
            r = await self.run_cmd("/lock all", protection=ctx)
            self.assertEqual(r.kind, R.LICENSE_OFF)
        self.assertEqual(self.actions.calls, [])
        self.assertEqual(self.claims._keys, {})

    async def test_dry_run_changes_nothing(self):
        await self.settings(dry_run=True)
        r = await self.run_cmd("/lock all")
        self.assertEqual(r.kind, R.DRY_RUN)
        self.assertEqual(self.actions.calls, [])
        self.assertEqual(self.claims._keys, {})
        self.assertIn("moderation_dry_run", self.audit_types())

    async def test_bot_without_restrict_right_or_unknown_rights(self):
        self.s.chat.set(A, BOT, ChatMemberInfo("administrator", True, False, True))
        r = await self.run_cmd("/lock all")
        self.assertEqual(r.kind, R.BOT_RIGHTS)
        self.assertEqual(self.actions.calls, [])
        self.s.chat.set(A, BOT, ChatMemberInfo("administrator", True, True, True))
        self.s.chat.fail = True  # the owner needs no Telegram lookup; the bot's own rights cannot be read
        r = await self.run_cmd("/lock all", actor=OWNER, msg=5)
        self.assertEqual(r.kind, R.BOT_RIGHTS)
        self.assertEqual(self.actions.calls, [])

    async def test_redelivered_command_acts_once(self):
        first = await self.run_cmd("/lock all", msg=9)
        again = await self.run_cmd("/lock all", msg=9)
        self.assertEqual((first.kind, again.kind, again.text), (R.DONE, R.DUPLICATE, ""))
        self.assertEqual(len(self.tg_calls()), 1)

    async def test_claim_store_down_fails_closed(self):
        self.svc = self.make_service(BrokenClaims())
        r = await self.run_cmd("/lock all")
        self.assertEqual(r.kind, R.ERROR)
        self.assertEqual(self.actions.calls, [])

    async def test_telegram_failures_are_reported_not_audited_as_success(self):
        for err, key in (("rate_limited", "الانتظار"), ("forbidden", "صلاحيات المجموعة"), ("other", "تعذر")):
            self.actions.fail["set_perms"] = err
            r = await self.run_cmd("/lock media", msg=hash(err) % 10_000 + 1)
            self.assertEqual(r.kind, R.TELEGRAM_FAILED, err)
            self.assertIn(key, r.text, err)
        self.assertNotIn("chat_locked", self.audit_types())
        self.assertEqual(self.audit_types().count("moderation_action_failed"), 3)


class StrictBot:
    def __init__(self, perms, **flags):
        self.chat = NS(permissions=perms)
        self.calls, self.script = [], {}

    async def get_chat(self, chat_id):
        self.calls.append(("get_chat", chat_id, {}))
        step = self.script.get("get_chat")
        if step:
            raise step.pop(0)
        return self.chat

    async def set_chat_permissions(self, chat_id, permissions, use_independent_chat_permissions=None):
        self.calls.append(("set", chat_id, {"permissions": permissions, "ind": use_independent_chat_permissions}))
        queue = self.script.get("set")
        if queue:
            step = queue.pop(0)
            if step is not None:
                raise step


@dataclasses.dataclass(frozen=True)
class Perms:
    can_send_messages: bool | None = True
    can_send_photos: bool | None = True
    can_send_videos: bool | None = True
    can_send_audios: bool | None = True
    can_send_documents: bool | None = True
    can_send_video_notes: bool | None = True
    can_send_voice_notes: bool | None = True
    can_send_polls: bool | None = True
    can_send_other_messages: bool | None = True
    can_add_web_page_previews: bool | None = True
    can_change_info: bool | None = False
    can_invite_users: bool | None = True
    can_pin_messages: bool | None = False


class RetryAfter(Exception):
    def __init__(self, s):
        self.retry_after = s


class Forbidden(Exception):
    pass


def adapter(bot):
    slept = []

    async def sleep(s):
        slept.append(s)

    return AiogramModerationActions(bot, sleep=sleep), slept


class SetDefaultPermissionsTests(unittest.IsolatedAsyncioTestCase):
    async def test_get_modify_set_changes_only_the_requested_flags(self):
        bot = StrictBot(Perms())
        act, _ = adapter(bot)
        res = await act.set_default_permissions(-100, ca.FLAG_MEDIA, False)
        self.assertEqual(res, PermissionChange(True, None, True))
        self.assertEqual([c[0] for c in bot.calls], ["get_chat", "set"])
        sent = bot.calls[1][2]
        self.assertTrue(sent["ind"])  # independent permissions: every flag means exactly itself
        before = dataclasses.asdict(Perms())
        after = dataclasses.asdict(sent["permissions"])
        changed = {k for k in before if before[k] != after[k]}
        self.assertEqual(changed, set(ca.FLAG_MEDIA))
        self.assertEqual(after["can_invite_users"], True)   # untouched flags are sent back exactly as read
        self.assertEqual(after["can_pin_messages"], False)

    async def test_unlock_sets_true_and_nothing_is_sent_when_already_in_state(self):
        bot = StrictBot(Perms(can_send_polls=False))
        act, _ = adapter(bot)
        self.assertEqual(await act.set_default_permissions(-100, ("can_send_polls",), True), PermissionChange(True, None, True))
        self.assertTrue(bot.calls[1][2]["permissions"].can_send_polls)
        bot = StrictBot(Perms(can_send_polls=False))
        act, _ = adapter(bot)
        self.assertEqual(await act.set_default_permissions(-100, ("can_send_polls",), False), PermissionChange(True, None, False))
        self.assertEqual([c[0] for c in bot.calls], ["get_chat"])  # no write when nothing changes

    async def test_an_omitted_flag_is_not_assumed_locked(self):
        bot = StrictBot(Perms(can_send_polls=None))
        act, _ = adapter(bot)
        res = await act.set_default_permissions(-100, ("can_send_polls",), False)
        self.assertTrue(res.changed)  # None is "unknown": write the explicit False
        self.assertIs(bot.calls[1][2]["permissions"].can_send_polls, False)

    async def test_unreadable_or_uncopyable_permissions_are_refused(self):
        bot = StrictBot(None)
        act, _ = adapter(bot)
        self.assertEqual(await act.set_default_permissions(-100, ("can_send_polls",), False), PermissionChange(False, "other"))
        bot = StrictBot(NS(can_send_polls=True))  # not copyable (neither pydantic nor dataclass)
        act, _ = adapter(bot)
        self.assertEqual(await act.set_default_permissions(-100, ("can_send_polls",), False), PermissionChange(False, "other"))
        self.assertEqual([c[0] for c in bot.calls], ["get_chat"])

    async def test_pydantic_style_copy_is_used_when_available(self):
        class Model:
            can_send_polls = True

            def model_copy(self, update):
                m = Model()
                m.__dict__.update(update)
                return m

        bot = StrictBot(Model())
        act, _ = adapter(bot)
        res = await act.set_default_permissions(-100, ("can_send_polls",), False)
        self.assertTrue(res.changed)
        self.assertIs(bot.calls[1][2]["permissions"].can_send_polls, False)

    async def test_invalid_arguments_never_reach_telegram(self):
        bot = StrictBot(Perms())
        act, _ = adapter(bot)
        bad = ((100, ("can_send_polls",), False), (0, ("can_send_polls",), False), (True, ("can_send_polls",), False),
               (-100, (), False), (-100, ("can_change_info",), False), (-100, ("can_pin_messages",), True),
               (-100, ("can_send_polls", "can_send_polls"), False), (-100, ("can_send_polls",), 1), (-100, "can_send_polls", False),
               (-100, ("nope",), False))
        for chat, flags, allowed in bad:
            self.assertEqual(await act.set_default_permissions(chat, flags, allowed), PermissionChange(False, "other"), (chat, flags))
        self.assertEqual(bot.calls, [])

    async def test_errors_are_classified_and_never_raised(self):
        bot = StrictBot(Perms())
        bot.script["get_chat"] = [Forbidden("Forbidden: not enough rights")]
        act, _ = adapter(bot)
        self.assertEqual(await act.set_default_permissions(-100, ("can_send_polls",), False), PermissionChange(False, "forbidden"))
        bot = StrictBot(Perms())
        bot.script["set"] = [RuntimeError("boom")]
        act, _ = adapter(bot)
        self.assertEqual(await act.set_default_permissions(-100, ("can_send_polls",), False), PermissionChange(False, "other"))

    async def test_one_bounded_retry_for_a_small_retry_after(self):
        bot = StrictBot(Perms())
        bot.script["set"] = [RetryAfter(1), None]
        act, slept = adapter(bot)
        self.assertEqual((await act.set_default_permissions(-100, ("can_send_polls",), False)).changed, True)
        self.assertEqual(slept, [1.0])
        bot = StrictBot(Perms())
        bot.script["set"] = [RetryAfter(60)]
        act, slept = adapter(bot)
        res = await act.set_default_permissions(-100, ("can_send_polls",), False)
        self.assertEqual((res.ok, res.error, slept), (False, "rate_limited", []))


if __name__ == "__main__":
    unittest.main()
