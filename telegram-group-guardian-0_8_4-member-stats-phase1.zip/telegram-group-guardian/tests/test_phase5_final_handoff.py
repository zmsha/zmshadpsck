"""Phase 5 / part 5.9: the PRIVATE-HANDOFF acceptance test of everything phase 5 added (owner panel, owner hub, templates,
defaults, sandbox, license commands), end to end with the REAL services. No new feature: tests + a few static guards only.

Acceptance criteria:
* an ordinary member (and a Telegram admin / creator / delegate / the backup owner) has NO owner power: every panel screen,
  every template / defaults / sandbox / license command is refused and changes nothing (licenses, settings, templates,
  defaults, sandbox session);
* a callback is attacker-controlled: any mutation of a valid owner callback (tag, group, status, action, digest, chat,
  structure) is refused and writes nothing;
* group `dry_run` and the sandbox send NOTHING real (no Telegram call, no claim, no sanction record, no hub message);
* a failing / hanging / mis-addressed owner group (`OWNER_GROUP_ID`) never stops protection, never blocks nor repeats a
  sensitive operation;
* the phase documents agree with each other and with the code (version, status, part table).
"""
from __future__ import annotations

import ast
import asyncio
import re
import unittest
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace as NS

import helpers  # noqa: F401
from executor_stack import USER
from guardian.audit import FORGED_CALLBACK, SANDBOX_STARTED, TEMPLATE_SAVED
from guardian.bot import owner_panel_handler as h
from guardian.bot.middlewares import ProtectionGateMiddleware
from guardian.idempotency import InMemoryIdempotency
from guardian.licensing.commands import LicenseCommandService, parse_license_command
from guardian.licensing.models import LicenseStatus as S
from guardian.moderation.executor import ResultKind as R
from guardian.owner_hub.mirror import HubMirroringNotifier
from guardian.owner_hub.reports import HubReporter
from guardian.owner_hub.sender import OwnerHubSender
from guardian.owner_panel import codec
from guardian.owner_panel.actions import OwnerActions
from guardian.owner_panel.sandbox_commands import SandboxCommandService, parse_sandbox_command
from guardian.owner_panel.service import OwnerPanelService
from guardian.owner_panel.template_commands import TemplateCommandService, parse_template_command
from guardian.owner_sandbox.service import SandboxService
from guardian.owner_templates.apply import TemplateApplyService
from guardian.owner_templates.defaults import GlobalDefaultsService, InMemoryDefaultsStore
from guardian.owner_templates.overview import GroupOverviewService
from guardian.owner_templates.pending import PendingActions
from guardian.owner_templates.templates import InMemoryTemplateStore, TemplateService
from guardian.protection.engine import ProtectionEngine
from guardian.protection_gate import ProtectionGate
from helpers import FakeNotifier
from stack import A, B, BACKUP, DELEGATE, NOW, OWNER, OWNER_GROUP, STRANGER, TG_ADMIN, TG_CREATOR, Clock, Stack
from test_phase3_final_handoff import Acts, Pipeline
from test_owner_hub import FakeTransport

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src" / "guardian"
SECRET = "phase5-final-handoff-secret-0123456789"
KEY = codec.derive_key(SECRET)
C = -1003
NON_OWNERS = (STRANGER, TG_ADMIN, TG_CREATOR, DELEGATE, BACKUP)
ALL_SCREENS = (codec.LIST, codec.FILTERS, codec.DETAIL, codec.SEARCH_HELP, codec.CLEAR_SEARCH, codec.CLOSE, codec.MENU,
               codec.ASK, codec.DO, codec.OVERVIEW, codec.PICK, codec.DIFF, codec.TEMPLATES, codec.APPLY_ASK, codec.APPLY_DO)


def sign(screen, chat=OWNER, **kw):
    """A callback with a VALID signature for `chat`, as if the server had drawn that button for that chat."""
    if screen in (codec.ASK, codec.DO):
        kw.setdefault("action", "st")
        kw.setdefault("status", "d")
    if screen in (codec.DIFF, codec.APPLY_ASK, codec.APPLY_DO):
        kw.setdefault("template_id", 1)
    if screen == codec.APPLY_DO:
        kw.setdefault("digest", "abcdef")
    if screen in (codec.DETAIL, codec.MENU, codec.ASK, codec.DO, codec.OVERVIEW, codec.PICK, codec.DIFF, codec.APPLY_ASK, codec.APPLY_DO):
        kw.setdefault("group_id", A)
    return codec.build(KEY, chat, screen, **kw)


class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        self.claims = InMemoryIdempotency()
        self.pending = PendingActions(clock=self.s.clock)
        self.store = InMemoryTemplateStore()
        self.tpl = TemplateService(self.store, self.s.licenses, self.s.settings_store, self.s.perm, self.s.audit, clock=self.s.clock)
        self.apply = TemplateApplyService(self.tpl, self.s.licenses, self.s.settings, self.claims, self.s.audit)
        self.dstore = InMemoryDefaultsStore()
        self.defaults = GlobalDefaultsService(self.dstore, self.tpl, self.s.perm, self.pending, self.s.audit, clock=self.s.clock)
        self.sandbox = SandboxService(self.tpl, self.s.audit, clock=self.s.clock)
        self.actions = OwnerActions(license_admin=self.s.admin, licenses=self.s.licenses, claims=self.claims, clock=self.s.clock)
        self.overview = GroupOverviewService(self.s.licenses, self.s.settings_store, self.s.audit_query, self.s.perm)
        self.transport = FakeTransport()
        self.hub = OwnerHubSender(self.transport, OWNER_GROUP, clock=self.s.clock)
        self.reporter = HubReporter(self.hub, self.s.licenses, clock=self.s.clock)
        self.panel = OwnerPanelService(permissions=self.s.perm, licenses=self.s.licenses, audit=self.s.audit, secret=SECRET,
                                       clock=self.s.clock, actions=self.actions, templates=self.tpl, overview=self.overview,
                                       applier=self.apply, hub=self.reporter)
        self.tcmd = TemplateCommandService(self.tpl, self.s.licenses, applier=self.apply, defaults=self.defaults, pending=self.pending)
        self.scmd = SandboxCommandService(self.sandbox, self.tpl, self.s.licenses)
        self.lcmd = LicenseCommandService(license_admin=self.s.admin, license_service=self.s.license_service,
                                          permissions=self.s.perm, claims=self.claims, clock=self.s.clock, hub=self.reporter)
        await self.s.register(A, B, C)
        for g in (A, B):
            await self.s.admin.activate_permanent(OWNER, g, context_chat_id=g)
        await self.s.settings_store.merge(A, {"warn_limit": 7, "flood_max_messages": 9}, OWNER, NOW)
        self.t, _ = await self.tpl.save_from_group(OWNER, "Strict", A)      # template id 1
        self.n = 0

    # ------------------------------------------------------------------ state snapshots
    def settings_rows(self):
        return {g: dict(r.settings) for g, r in self.s.settings_store._rows.items()}

    def snapshot(self):
        return (dict(self.s.licenses._rows), len(self.s.licenses.audit_log), self.settings_rows(),
                {k: v for k, v in vars(self.store).items() if k != "_clock"}.__repr__(), repr(vars(self.dstore)),
                self.sandbox._session, len(self.hub._tasks))

    def events(self, kind):
        return [e for e in self.s.audit.events if e.event_type == kind]

    async def press(self, data, *, presser=OWNER, chat=None, ctype="private", svc=None):
        self.n += 1
        return await (svc or self.panel).press(presser if chat is None else chat, ctype, presser, data, "ar", f"cb{self.n}")

    async def settle(self):
        await self.hub.drain()


# ============================================================================================= 1. no owner power
class OrdinaryMemberHasNoOwnerPowerTests(Base):
    async def test_the_panel_opens_for_nobody_but_the_owner(self):
        before = self.snapshot()
        for who in NON_OWNERS:
            with self.subTest(who=who):
                self.assertIsNone(await self.panel.open(who, "private", who))
                self.assertIsNone(await self.panel.open(who, "private", who, "search"))
                self.assertIsNone(await self.panel.open(A, "supergroup", who))       # not even in a group
        self.assertIsNone(await self.panel.open(OWNER, "supergroup", OWNER))          # the owner either: private chat only
        self.assertEqual(self.snapshot(), before)

    async def test_every_screen_signed_for_the_strangers_own_chat_is_refused_and_audited(self):
        """The strongest forgery possible: a perfect signature (e.g. a forwarded button re-signed by a bug) for the presser's own
        private chat. The owner check on EVERY press must still refuse."""
        before = self.snapshot()
        for who in NON_OWNERS:
            for screen in ALL_SCREENS:
                with self.subTest(who=who, screen=screen):
                    data = sign(screen, chat=who)
                    forged_before = len(self.events(FORGED_CALLBACK))
                    out = await self.press(data, presser=who, chat=who)
                    self.assertEqual(out.status, "not_owner")
                    self.assertTrue(out.toast)
                    self.assertIsNone(out.text)                                    # no data leaks to a non-owner
                    self.assertIsNone(out.buttons if hasattr(out, "buttons") else None)
                    self.assertEqual(len(self.events(FORGED_CALLBACK)), forged_before + 1)
        self.assertEqual(self.snapshot(), before)

    async def test_the_owners_buttons_do_nothing_in_anybody_elses_hands(self):
        """A button drawn for the owner's chat, pressed by someone else (a forward, a group, a bot echo)."""
        before = self.snapshot()
        for screen in ALL_SCREENS:
            data = sign(screen, chat=OWNER)
            for who in NON_OWNERS:
                with self.subTest(screen=screen, who=who):
                    self.assertIsNone(await self.press(data, presser=who, chat=OWNER))              # chat != presser
                    out = await self.press(data, presser=who, chat=who)                              # signature of another chat
                    self.assertEqual(out.status, "forged")                                         # a visible "invalid" toast, no data
                    self.assertIsNone(out.text)
                    self.assertIsNone(await self.press(data, presser=OWNER, chat=OWNER, ctype="supergroup"))
        self.assertEqual(self.snapshot(), before)

    async def test_license_actions_cannot_be_run_by_a_member_even_with_a_valid_looking_press(self):
        before = self.snapshot()
        for who in NON_OWNERS:
            for act in codec.ACTION_CODES:
                for screen in (codec.ASK, codec.DO):
                    out = await self.press(sign(screen, chat=who, action=act, status="d"), presser=who, chat=who)
                    self.assertEqual(out.status, "not_owner")
        self.assertEqual(self.snapshot(), before)
        self.assertEqual((await self.s.licenses.get(A)).status, S.ACTIVE_PERMANENT)

    async def test_template_defaults_and_apply_commands_are_silent_for_everyone_else(self):
        texts = ("/templates", "القوالب", "/template save X -1001", "/template diff Strict -1001", "/template delete Strict",
                 "/template apply Strict -1002", "/template confirm ABC123", "/defaults", "/defaults set Strict", "/defaults reset",
                 "/defaults confirm ABC123", "تطبيق قالب Strict -1002", "تأكيد قالب ABC123", "الافتراضيات")
        before = self.snapshot()
        for who in NON_OWNERS:
            for text in texts:
                with self.subTest(who=who, text=text):
                    self.assertIsNone(await self.tcmd.run(parse_template_command(text), chat_id=who, chat_type="private", user_id=who))
                    self.assertIsNone(await self.tcmd.run(parse_template_command(text), chat_id=A, chat_type="supergroup", user_id=who))
        self.assertEqual(self.snapshot(), before)

    async def test_the_owners_confirmation_code_is_useless_to_anyone_else(self):
        reply = await self.tcmd.run(parse_template_command("/template apply Strict -1002"), chat_id=OWNER, chat_type="private", user_id=OWNER)
        code = re.search(r"confirm ([A-Z0-9]{6})", reply.text).group(1)
        before = self.snapshot()
        for who in NON_OWNERS:
            self.assertIsNone(await self.tcmd.run(parse_template_command(f"/template confirm {code}"), chat_id=who, chat_type="private", user_id=who))
        self.assertEqual(self.snapshot(), before)
        done = await self.tcmd.run(parse_template_command(f"/template confirm {code}"), chat_id=OWNER, chat_type="private", user_id=OWNER)
        self.assertEqual(done.status, "applied")                                  # the code survived the failed attempts
        self.assertEqual(self.settings_rows()[B]["warn_limit"], 7)

    async def test_sandbox_commands_are_silent_for_everyone_else_and_start_nothing(self):
        for who in NON_OWNERS:
            for text in ("/sandbox", "/sandbox start default", "/sandbox say hi", "/sandbox save X", "تجربة بدء", "تجربة احفظ X"):
                with self.subTest(who=who, text=text):
                    self.assertIsNone(await self.scmd.run(parse_sandbox_command(text), chat_id=who, chat_type="private", user_id=who))
        self.assertIsNone(self.sandbox._session)
        self.assertEqual(self.events(SANDBOX_STARTED), [])
        self.assertEqual(self.events(TEMPLATE_SAVED), [self.events(TEMPLATE_SAVED)[0]])        # only the setUp save of the owner

    async def test_handlers_ignore_group_chats_bots_and_foreign_senders(self):
        sent = []

        async def answer(text, **kw):
            sent.append(text)

        def msg(text, chat="private", user=OWNER, bot=False):
            return NS(text=text, chat=NS(id=user if chat == "private" else A, type=chat),
                      from_user=NS(id=user, is_bot=bot, language_code="ar"), answer=answer)

        services = NS(owner_templates=self.tcmd, owner_sandbox=self.scmd, settings=NS(default_language="ar"))
        for text, matcher in (("/templates", h.match_template_command), ("/sandbox", h.match_sandbox_command), ("/owner", h.match_command)):
            self.assertIsNone(await matcher(msg(text, chat="supergroup"), NS()))
            self.assertIsNone(await matcher(msg(text, bot=True), NS()))
        for who in NON_OWNERS:
            parsed = await h.match_template_command(msg("/templates", user=who), NS())
            self.assertIsNone(await h.execute_template(msg("/templates", user=who), parsed, services=services))
            parsed = await h.match_sandbox_command(msg("/sandbox", user=who), NS())
            self.assertIsNone(await h.execute_sandbox(msg("/sandbox", user=who), parsed, services=services))
        self.assertEqual(sent, [])

    async def test_group_license_commands_belong_to_the_real_owner_only(self):
        """`تفعيل البوت` / `إيقاف البوت` in the group: a member, a Telegram admin and the group creator cannot change anything."""
        before = (dict(self.s.licenses._rows), len(self.s.licenses.audit_log))
        mid = 500
        for who in (STRANGER, TG_ADMIN, TG_CREATOR, DELEGATE):
            for text in ("تفعيل البوت", "تفعيل البوت 30 يوم", "إيقاف البوت"):
                mid += 1
                with self.subTest(who=who, text=text):
                    await self.lcmd.handle(parse_license_command(text), chat_id=C, actor_id=who, message_id=mid)
                    await self.lcmd.handle(parse_license_command(text), chat_id=A, actor_id=who, message_id=mid + 1000)
        self.assertEqual((dict(self.s.licenses._rows), len(self.s.licenses.audit_log)), before)
        self.assertEqual((await self.s.licenses.get(C)).status, S.PENDING)

    async def test_the_owner_alone_still_works_after_all_those_refusals(self):
        """Refusals must not poison anything: the real owner gets the list, a template diff and an activation."""
        out = await self.panel.open(OWNER, "private", OWNER)
        self.assertIsNotNone(out.text)
        out = await self.press(sign(codec.ASK, action="st", status="p", group_id=C))
        self.assertNotEqual(out.status, "not_owner")
        self.assertEqual((await self.tcmd.run(parse_template_command("/templates"), chat_id=OWNER, chat_type="private", user_id=OWNER)).status, "list")


# ============================================================================================= 2. callback mutation sweep
class CallbackMutationTests(Base):
    """Every valid owner callback, every kind of mutation: the answer is always a refusal and nothing is written."""

    def valid_callbacks(self):
        out = []
        for filt in codec.FILTER_CODES:
            out += [sign(codec.LIST, filter=filt, page=2), sign(codec.FILTERS, filter=filt, page=1), sign(codec.TEMPLATES, filter=filt)]
        for g in (A, B, C):
            out += [sign(codec.DETAIL, group_id=g), sign(codec.MENU, group_id=g), sign(codec.OVERVIEW, group_id=g), sign(codec.PICK, group_id=g),
                    sign(codec.DIFF, group_id=g), sign(codec.APPLY_ASK, group_id=g), sign(codec.APPLY_DO, group_id=g)]
            for act in codec.ACTION_CODES:
                for st in codec.STATUS_CODES:
                    out += [sign(codec.ASK, action=act, status=st, group_id=g), sign(codec.DO, action=act, status=st, group_id=g)]
        out += [sign(codec.SEARCH_HELP), sign(codec.CLEAR_SEARCH), sign(codec.CLOSE)]
        return out

    @staticmethod
    def mutations(data):
        parts = data.split(":")
        body, tag = parts[1:-1], parts[-1]
        flip = lambda c: "0" if c != "0" else "1"                          # noqa: E731
        yield "tag-flip-first", ":".join([*parts[:-1], flip(tag[0]) + tag[1:]])
        yield "tag-flip-last", ":".join([*parts[:-1], tag[:-1] + flip(tag[-1])])
        yield "tag-upper", ":".join([*parts[:-1], tag.upper()]) if tag.upper() != tag else None
        yield "tag-short", ":".join([*parts[:-1], tag[:-1]])
        yield "tag-long", ":".join([*parts[:-1], tag + "0"])
        yield "tag-empty", ":".join([*parts[:-1], ""])
        yield "no-tag", ":".join(parts[:-1])
        yield "extra-field", ":".join([*parts[:-1], "0", tag])
        yield "dropped-field", ":".join([parts[0], *body[:-1], tag]) if len(body) > 1 else None
        yield "prefix", "x" + data
        yield "other-prefix", "ox" + data[2:]
        yield "unicode", data + "\u200b"
        yield "arabic-digit", data.replace("0", "\u0660", 1) if "0" in body[-1] else None
        yield "swapped-screen", ":".join([parts[0], "x" if body[0] != "x" else "l", *body[1:], tag]) if body[0] not in "x" else None
        for i, field in enumerate(body[1:], start=1):
            if field.lstrip("-").isdigit():                                 # numeric field: group / page / template id
                bumped = str(int(field) - 1 if int(field) < 0 else int(field) + 1)
                yield f"field{i}-bumped", ":".join([parts[0], *body[:i], bumped, *body[i + 1:], tag])
            elif len(field) <= 3:                                           # filter / status / action code
                other = "q" if field != "q" else "w"
                yield f"field{i}-swapped", ":".join([parts[0], *body[:i], other, *body[i + 1:], tag])

    async def test_no_mutation_of_any_valid_callback_is_ever_applied(self):
        before = self.snapshot()
        checked = refused = 0
        for data in self.valid_callbacks():
            for name, mutated in self.mutations(data):
                if mutated is None or mutated == data:
                    continue
                checked += 1
                out = await self.press(mutated)
                # a malformed one is dropped (None); a well-formed one with a bad tag is a visible "invalid"
                if out is None:
                    refused += 1
                    continue
                self.assertEqual(out.status, "forged", f"{name}: {mutated!r} -> {out.status}")
                refused += 1
        self.assertGreater(checked, 3000)
        self.assertEqual(refused, checked)
        self.assertEqual(self.snapshot(), before)
        self.assertGreater(len(self.events(FORGED_CALLBACK)), 100)             # and they were audited

    async def test_a_signature_never_transfers_to_another_chat_or_screen(self):
        data = sign(codec.DO, action="st", status="d", group_id=A)
        before = self.snapshot()
        for chat in (STRANGER, TG_ADMIN, BACKUP, DELEGATE):
            self.assertEqual((await self.press(data, presser=chat, chat=chat)).status, "forged")
        # the same payload re-signed for the wrong chat, or the same tag glued to another screen
        other = data.replace("ow:y:", "ow:a:", 1)
        self.assertEqual((await self.press(other)).status, "forged")
        self.assertEqual(self.snapshot(), before)

    async def test_stale_screen_and_replay_never_double_apply(self):
        """A valid DO press for a status the group no longer has is refused; the same callback id twice applies once."""
        data = sign(codec.DO, action="st", status="p", group_id=C)          # C is pending: it cannot be "stopped"
        before = self.snapshot()
        out = await self.press(data)
        self.assertNotEqual(out.status, "done")
        self.assertEqual((await self.s.licenses.get(C)).status, S.PENDING)
        self.assertEqual(self.snapshot()[0], before[0])
        # a legitimate press with the real status, delivered twice with the SAME Telegram callback id
        live = sign(codec.DO, action="st", status="p", group_id=A)           # A is permanent: "p" is the code of PENDING -> stale
        await self.panel.press(OWNER, "private", OWNER, live, "ar", "same-id")
        await self.panel.press(OWNER, "private", OWNER, live, "ar", "same-id")
        self.assertEqual((await self.s.licenses.get(A)).status, S.ACTIVE_PERMANENT)
        good = sign(codec.DO, action="st", status="d", group_id=A)            # "d" = permanent in this codec
        first = await self.panel.press(OWNER, "private", OWNER, good, "ar", "once")
        again = await self.panel.press(OWNER, "private", OWNER, good, "ar", "once")
        self.assertEqual(first.status, "done")
        self.assertNotEqual(again.status, "done")
        self.assertEqual(len([e for e in self.s.licenses.audit_log if e.group_id == A and e.action == "stop"]), 1)


# ============================================================================================= 3. dry-run / sandbox send nothing
class NothingRealIsSentTests(Pipeline):
    async def test_group_dry_run_touches_no_telegram_no_claim_no_record(self):
        g = await self.group_in("rejected")
        await self.owner_recovers(g, "rejected")
        await self.s.settings_store.merge(g, {"dry_run": True}, OWNER, NOW)
        calls, claims = len(self.actions.calls), dict(self.claims._keys)
        for text in ("/ban", "/mute", "/kick", "/warn spam", "/unban", "/unmute"):
            ran, res = await self.deliver(self.cmd(text, g))
            self.assertTrue(ran)
            # /unban and /unmute of a member who is not punished are a harmless NOOP before the dry-run check
            self.assertIn(res.kind, (R.DRY_RUN, R.NOOP) if text in ("/unban", "/unmute") else (R.DRY_RUN,), text)
        self.assertEqual(self.actions.calls[calls:], [])
        self.assertEqual(self.claims._keys, claims)
        self.assertEqual(await self.s.warning_store.count_active(g, USER, self.s.clock()), 0)
        self.assertEqual(await self.s.sanction_store.get_active(g, USER, self.s.clock()), [])

    async def test_dry_run_is_switched_off_only_by_the_owner_and_then_acts_for_real(self):
        g = await self.group_in("rejected")
        await self.owner_recovers(g, "rejected")
        await self.s.settings_store.merge(g, {"dry_run": True}, OWNER, NOW)
        await self.s.settings_store.merge(g, {"dry_run": False}, OWNER, NOW)
        before = len(self.actions.calls)
        ran, res = await self.deliver(self.cmd("/mute", g))
        self.assertTrue(ran)
        self.assertEqual(res.kind, R.DONE)
        self.assertGreater(len(self.actions.calls), before)


class SandboxSendsNothingTests(Base):
    async def test_a_long_session_leaves_no_trace_outside_its_own_stores(self):
        """30 messages, settings changes, join/wait, diff against a real group, save, end. The hub transport (the only thing that
        could reach Telegram here) records zero calls, no group / license / template / defaults changed, and the production audit
        gets only the sandbox events + the one template the owner asked to save."""
        before_settings, before_lic = self.settings_rows(), dict(self.s.licenses._rows)
        before_audit = len(self.s.audit.events)

        async def run(text):
            return await self.scmd.run(parse_sandbox_command(text), chat_id=OWNER, chat_type="private", user_id=OWNER)

        replies = [await run("/sandbox start Strict")]
        for i in range(30):
            replies.append(await run(f"/sandbox say https://spam{i}.example.com" if i % 2 else f"/sandbox say hello {i}"))
        for text in ("/sandbox join u2", "/sandbox media", "/sandbox wait 700", "/sandbox set warn_limit 2", "/sandbox settings",
                     "/sandbox log", f"/sandbox diff {A}", f"/sandbox diff {B}", "/sandbox save Experiment", "/sandbox end"):
            replies.append(await run(text))
        for reply in replies:
            self.assertIsNotNone(reply)
            self.assertIn("🧪", reply.text, reply.status)
        self.assertEqual(self.transport.calls, 0)
        self.assertEqual(self.transport.messages, [])
        self.assertEqual(self.settings_rows(), before_settings)
        self.assertEqual(dict(self.s.licenses._rows), before_lic)
        self.assertEqual((await self.tpl.find(OWNER, "Strict")).settings["warn_limit"], 7)
        new_kinds = sorted(e.event_type for e in self.s.audit.events[before_audit:])
        self.assertEqual(new_kinds, sorted(["sandbox_started", "sandbox_ended", "template_saved"]))

    async def test_the_only_way_out_is_a_template_and_applying_it_still_needs_the_code(self):
        run = lambda text: self.scmd.run(parse_sandbox_command(text), chat_id=OWNER, chat_type="private", user_id=OWNER)  # noqa: E731
        await run("/sandbox start default")
        await run("/sandbox set warn_limit 2")
        await run("/sandbox save Exp")
        self.assertNotEqual(self.settings_rows().get(B, {}).get("warn_limit"), 2)               # saved, not applied
        reply = await self.tcmd.run(parse_template_command("/template apply Exp -1002"), chat_id=OWNER, chat_type="private", user_id=OWNER)
        self.assertEqual(reply.status, "apply_preview")
        self.assertNotEqual(self.settings_rows().get(B, {}).get("warn_limit"), 2)               # still not applied: needs the code


# ============================================================================================= 4. the owner hub never hurts protection
class HangingTransport:
    """Never answers: the worst case for anything that (wrongly) waits for the owner group."""

    def __init__(self):
        self.calls = 0

    async def send_message(self, chat_id, text):
        self.calls += 1
        await asyncio.sleep(3600)

    send_document = None


class OwnerGroupFailureTests(Pipeline):
    def failing_stack(self, transport=None, **kw):
        hub = OwnerHubSender(transport or FakeTransport(fail=RuntimeError("chat not found")), OWNER_GROUP, clock=self.s.clock, **kw)
        self.hub = hub
        self.notifier = HubMirroringNotifier(self.notifier, hub)
        self.gate = ProtectionGate(self.s.license_service, self.s.perm, self.notifier, clock=self.s.clock)
        self.engine = ProtectionEngine(self.s.settings_store, self.actions, self.s.chat, self.claims, self.s.audit, self.notifier,
                                       clock=self.s.clock)
        self.mw = ProtectionGateMiddleware(self.gate, self.engine)
        return hub

    async def licensed_group(self):
        g = await self.group_in("rejected")
        await self.owner_recovers(g, "rejected")
        return g

    async def test_protection_keeps_working_while_the_owner_group_rejects_everything(self):
        hub = self.failing_stack()
        g = await self.licensed_group()
        await self.notifier.notify_owner("a mirrored owner notice")        # reaches the (rejecting) hub
        await hub.drain()
        for _ in range(3):
            before = len(self.actions.calls)
            await self.deliver(self.link(g))
            self.assertEqual([c[0] for c in self.actions.calls[before:]][:1], ["delete"])          # the link is still deleted
        await hub.drain()
        self.assertGreaterEqual(hub.health().consecutive_failures, 1)

    async def test_a_hanging_owner_group_never_delays_protection_nor_a_notification(self):
        transport = HangingTransport()
        hub = self.failing_stack(transport, timeout=0.6)             # the hub itself would wait 0.6s; protection must not
        g = await self.licensed_group()
        await asyncio.wait_for(self.notifier.notify_owner("a new group asked for activation"), timeout=0.25)
        await asyncio.wait_for(self.deliver(self.link(g)), timeout=0.25)
        self.assertIn("delete", [c[0] for c in self.actions.calls])
        self.assertEqual(self.notifier._inner.owner_messages, ["a new group asked for activation"])
        await asyncio.wait_for(hub.drain(), timeout=3)                # the hub's own timeout ends the background send
        self.assertGreaterEqual(hub.health().consecutive_failures, 1)

    async def test_the_private_owner_message_still_goes_out_when_the_hub_fails(self):
        hub = self.failing_stack()
        await self.notifier.notify_owner("hello owner")
        await hub.drain()
        self.assertEqual(self.notifier._inner.owner_messages, ["hello owner"])

    async def test_after_failures_the_hub_backs_off_instead_of_hammering_telegram(self):
        transport = FakeTransport(fail=RuntimeError("down"))
        hub = self.failing_stack(transport)
        for _ in range(10):
            hub.post_text("x")
            await hub.drain()
        self.assertEqual(transport.calls, 1)                              # one attempt, then the cooldown swallows the rest
        self.s.clock.advance(minutes=2)
        hub.post_text("again")
        await hub.drain()
        self.assertEqual(transport.calls, 2)


class OwnerGroupFailureNeverRepeatsASensitiveOperationTests(Base):
    async def break_hub(self):
        self.transport.fail = RuntimeError("chat not found")

    async def test_a_license_change_is_applied_exactly_once_when_the_notice_fails(self):
        await self.break_hub()
        out = await self.press(sign(codec.DO, action="ap", status="p", group_id=C), presser=OWNER)
        await self.settle()
        self.assertEqual(out.status, "done")
        self.assertEqual((await self.s.licenses.get(C)).status, S.ACTIVE_PERMANENT)
        self.assertEqual(len([e for e in self.s.licenses.audit_log if e.group_id == C and e.action == "activate_permanent"]), 1)
        self.assertEqual(self.transport.calls, 1)                         # the failed notice was NOT retried

    async def test_the_group_command_path_survives_a_failing_hub_too(self):
        await self.break_hub()
        res = await self.lcmd.handle(parse_license_command("تفعيل البوت 7 ايام"), chat_id=C, actor_id=OWNER, message_id=700)
        await self.settle()
        self.assertNotEqual(res.kind.name, "ERROR")
        self.assertEqual((await self.s.licenses.get(C)).status, S.ACTIVE_TEMPORARY)
        self.assertEqual(self.transport.calls, 1)

    async def test_a_hub_that_raises_from_any_method_never_escapes(self):
        class Exploding:
            def post_text(self, *a, **k):
                raise RuntimeError("boom")

            def license_changed(self, *a, **k):
                raise RuntimeError("boom")

        panel = OwnerPanelService(permissions=self.s.perm, licenses=self.s.licenses, audit=self.s.audit, secret=SECRET,
                                  clock=self.s.clock, actions=self.actions, hub=Exploding())
        try:
            out = await self.press(sign(codec.DO, action="ap", status="p", group_id=C), svc=panel)
        except Exception as exc:                                          # a hook failure must never surface as a panel failure
            self.fail(f"hub failure escaped: {exc!r}")
        self.assertIn(out.status, {"done", "failed", "error"})
        self.assertEqual((await self.s.licenses.get(C)).status, S.ACTIVE_PERMANENT)

    async def test_a_secret_never_reaches_the_owner_group_even_in_a_license_notice(self):
        await self.s.licenses.get(A)
        self.reporter.license_changed(await self.s.licenses.get(A), "renew", "panel")
        await self.settle()
        text = " ".join(m[1] for m in self.transport.messages)
        for secret in ("123456789:AAA", "postgresql://"):
            self.assertNotIn(secret, text)


# ============================================================================================= 5. static guards + documents
class StaticGuardTests(unittest.TestCase):
    @staticmethod
    def imports(path):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        names = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                names |= {a.name for a in node.names}
            elif isinstance(node, ast.ImportFrom):
                names.add(("." * node.level) + (node.module or ""))
        return names

    def test_sandbox_and_panel_code_never_import_the_telegram_layer_or_the_database(self):
        banned = ("aiogram", "asyncpg", "fastapi", "httpx", "requests", "aiohttp", "urllib")
        for pkg in ("owner_sandbox", "owner_panel", "owner_templates"):
            for path in (SRC / pkg).glob("*.py"):
                for name in self.imports(path):
                    with self.subTest(file=f"{pkg}/{path.name}", name=name):
                        self.assertFalse(any(name == b or name.startswith(b + ".") for b in banned))
                        self.assertNotIn(name.lstrip("."), ("bot", "app") if "store_pg" not in path.name else ())

    def test_only_config_and_app_read_the_owner_group_setting(self):
        """`settings.owner_group_id` is read in config.py and wired once in app.py; no other module may reach the destination."""
        for path in SRC.rglob("*.py"):
            if path.name in ("config.py", "app.py"):
                continue
            tree = ast.parse(path.read_text(encoding="utf-8"))
            hits = [n for n in ast.walk(tree) if (isinstance(n, ast.Attribute) and n.attr == "owner_group_id")
                    or (isinstance(n, ast.Name) and n.id == "owner_group_id")]
            with self.subTest(file=str(path.relative_to(SRC))):
                self.assertEqual(hits, [])

    def test_every_owner_callback_screen_is_owner_checked_in_the_service(self):
        """The service checks the owner BEFORE dispatching any screen: the first dispatch line comes after `_is_owner`."""
        src = (SRC / "owner_panel" / "service.py").read_text(encoding="utf-8")
        press = src[src.index("async def press"):src.index("async def _filters")]
        self.assertLess(press.index("_is_owner"), press.index("codec.CLOSE"))
        for screen in ("LIST", "FILTERS", "DETAIL", "OVERVIEW", "PICK", "DIFF", "TEMPLATES", "APPLY_ASK", "APPLY_DO", "MENU", "ASK", "DO"):
            self.assertLess(press.index("_is_owner"), press.index(f"codec.{screen}"), screen)

    def test_the_sandbox_is_wired_to_fakes_only(self):
        src = (SRC / "owner_sandbox" / "sandbox.py").read_text(encoding="utf-8")
        for needle in ("FakeActions()", "FakeNotifier()"):
            self.assertIn(needle, src)
        for forbidden in ("send_message(", "TelegramActions", "aiogram", "Bot("):
            self.assertNotIn(forbidden, src.replace("async def send_message(", ""))


class DocumentConsistencyTests(unittest.TestCase):
    VERSION = "0.8.4-phase8-complete"        # the CURRENT version (phase 8 complete, part 8.4)
    P7_VERSION = "0.7.3-phase7-complete"    # phase 7's own closing version: it stays in the phase-7 documents
    P6_VERSION = "0.6.10-phase6-complete"   # phase 6's own closing version: it stays in the phase-6 documents
    P5_VERSION = "0.5.9-phase5-complete"    # phase 5's own closing version: it stays in the phase-5 documents

    def read(self, name):
        return (ROOT / name).read_text(encoding="utf-8")

    def test_the_version_is_the_same_everywhere(self):
        self.assertIn(f'"{self.VERSION}"', (SRC / "__init__.py").read_text(encoding="utf-8"))
        self.assertRegex(self.read("pyproject.toml"), r'(?m)^version = "0\.8\.4"$')
        for doc in ("HANDOFF.md", "CHANGELOG.md", "TEST_REPORT.md", "PROJECT_SUMMARY.md", "README.md", "PROGRESS.md",
                    "PHASE8_PLAN.md"):
            with self.subTest(doc=doc):
                self.assertIn(self.VERSION, self.read(doc))
        for version in (self.P7_VERSION, self.P6_VERSION, self.P5_VERSION):
            with self.subTest(version=version):
                self.assertIn(version, self.read("CHANGELOG.md"))

    def test_the_current_handoff_and_changelog_start_with_phase_5_complete(self):
        self.assertIn(self.VERSION, self.read("HANDOFF.md").splitlines()[0])
        self.assertIn(self.VERSION, self.read("CHANGELOG.md").splitlines()[1])
        self.assertIn(self.VERSION, self.read("TEST_REPORT.md").splitlines()[0])

    def test_no_document_still_calls_phase_5_unfinished(self):
        stale = ("الإغلاق لم يُنفَّذ", "لا يبدأ الجزء التالي", "المرحلة 5 جارية", "5.8 من 9", "المرحلة 4 من 8 **مكتملة**",
                 "الأوامر العربية واللوحة تأتي في المرحلة 5", "لا توجد بعد قوالب")
        for doc in ("HANDOFF.md", "PROJECT_SUMMARY.md", "README.md", "PROGRESS.md"):
            text = self.read(doc)
            for phrase in stale:
                with self.subTest(doc=doc, phrase=phrase):
                    self.assertNotIn(phrase, text)

    def test_the_changelog_keeps_the_phase_5_record(self):
        # the phase-5 plan/progress files were removed from the repository; the changelog is the surviving record
        changelog = self.read("CHANGELOG.md")
        self.assertIn(self.P5_VERSION, changelog)

    def test_the_test_report_names_this_part(self):
        self.assertIn("test_phase5_final_handoff.py", self.read("TEST_REPORT.md"))
        self.assertIn("test_phase5_final_handoff.py", self.read("PROJECT_STRUCTURE.md"))
