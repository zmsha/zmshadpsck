from datetime import timedelta

from executor_stack import A, B, BOT, OTHER, USER, ExecBase
from guardian.moderation.executor import ResultKind as R
from guardian.moderation.models import SanctionKind as K
from guardian.telegram_rights import ChatMemberInfo
from stack import NOW, OWNER, TG_ADMIN, TG_CREATOR


class Warn(ExecBase):
    async def active(self, uid=USER, group=A):
        return await self.s.warning_store.list_active(group, uid, NOW)

    async def test_below_limit_only_records_a_warning(self):
        self.member(USER)
        r1 = await self.run_cmd("/warn spam", reply_to=USER, msg=1)
        r2 = await self.run_cmd("/warn again", reply_to=USER, msg=2)
        self.assertEqual((r1.kind, r2.kind), (R.DONE, R.DONE))
        self.assertIn("1/3", r1.text)
        self.assertIn("2/3", r2.text)
        self.assertEqual(self.actions.calls, [])
        self.assertEqual(len(await self.active()), 2)

    async def test_default_limit_action_is_one_day_mute_then_new_cycle(self):
        self.member(USER)
        for i in range(3):
            r = await self.run_cmd("/warn", reply_to=USER, msg=10 + i)
        self.assertEqual(self.actions.calls, [("mute", A, USER, NOW + timedelta(days=1))])
        self.assertIn("3/3", r.text)
        self.assertEqual(await self.active(), [])  # cleared: new cycle
        (m,) = await self.s.sanction_store.get_active(A, USER, NOW)
        self.assertEqual((m.kind, m.reason), (K.MUTE, "warn limit"))
        self.assertIn("warnings_cleared", self.audit_types())

    async def test_configured_ban_permanent(self):
        await self.settings(warn_limit=2, warn_action="ban", warn_action_seconds=0)
        self.member(USER)
        await self.run_cmd("/warn", reply_to=USER, msg=1)
        await self.run_cmd("/warn", reply_to=USER, msg=2)
        self.assertEqual(self.actions.calls, [("ban", A, USER, None)])

    async def test_configured_kick_and_timed_ban(self):
        await self.settings(warn_limit=1, warn_action="kick")
        self.member(USER)
        await self.run_cmd("/warn", reply_to=USER, msg=1)
        self.assertEqual(self.actions.calls, [("kick", A, USER)])
        await self.settings(warn_action="ban", warn_action_seconds=3600)
        self.member(OTHER)
        await self.run_cmd("/warn", reply_to=OTHER, msg=2)
        self.assertEqual(self.actions.calls[-1], ("ban", A, OTHER, NOW + timedelta(hours=1)))

    async def test_invalid_settings_fall_back_to_defaults(self):
        await self.settings(warn_limit=0, warn_action="nuke", warn_action_seconds=5)
        self.member(USER)
        for i in range(3):
            await self.run_cmd("/warn", reply_to=USER, msg=i + 1)
        self.assertEqual(self.actions.calls, [("mute", A, USER, NOW + timedelta(days=1))])

    async def test_failed_limit_action_keeps_warnings_and_retries_next_time(self):
        await self.settings(warn_limit=2)
        self.member(USER)
        await self.run_cmd("/warn", reply_to=USER, msg=1)
        self.actions.fail["mute"] = "forbidden"
        r = await self.run_cmd("/warn", reply_to=USER, msg=2)
        self.assertEqual(r.kind, R.DONE)  # the warning itself succeeded
        self.assertIn("2/2", r.text)
        self.assertEqual(len(await self.active()), 2)
        self.assertEqual(await self.s.sanction_store.get_active(A, USER, NOW), [])
        self.actions.fail.clear()
        await self.run_cmd("/warn", reply_to=USER, msg=3)  # count 3 >= limit: retried
        self.assertEqual(self.actions.names(), ["mute", "mute"])
        self.assertEqual(await self.active(), [])

    async def test_rights_not_needed_below_limit_but_required_at_limit_without_recording(self):
        self.member(USER)
        self.s.chat.set(A, BOT, ChatMemberInfo("member"))  # bot lost its admin rights
        self.assertEqual((await self.run_cmd("/warn", reply_to=USER, msg=1)).kind, R.DONE)
        self.assertEqual((await self.run_cmd("/warn", reply_to=USER, msg=2)).kind, R.DONE)
        r = await self.run_cmd("/warn", reply_to=USER, msg=3)  # would hit the limit
        self.assertEqual(r.kind, R.BOT_RIGHTS)
        self.assertEqual(len(await self.active()), 2)  # third warning NOT recorded
        self.assertEqual(self.actions.calls, [])

    async def test_warn_requires_present_member(self):
        self.member(USER, "left")
        self.assertEqual((await self.run_cmd("/warn", reply_to=USER)).kind, R.INVALID)
        self.assertEqual(await self.active(), [])

    async def test_redelivery_does_not_double_warn(self):
        self.member(USER)
        await self.run_cmd("/warn", reply_to=USER, msg=5)
        again = await self.run_cmd("/warn", reply_to=USER, msg=5)
        self.assertEqual(again.kind, R.DUPLICATE)
        self.assertEqual(len(await self.active()), 1)

    async def test_warnings_are_per_group(self):
        self.member(USER)
        self.member(USER, group=B)
        await self.run_cmd("/warn", reply_to=USER, msg=1)
        self.assertEqual(await self.active(USER, B), [])


class WarningsAndClear(ExecBase):
    async def test_list_shows_count_limit_and_escaped_reasons(self):
        self.member(USER)
        await self.run_cmd("/warn <b>x</b> & y", reply_to=USER, msg=1)
        r = await self.run_cmd("/warnings", reply_to=USER, msg=2)
        self.assertEqual(r.kind, R.INFO)
        self.assertIn("1/3", r.text)
        self.assertIn("&lt;b&gt;x&lt;/b&gt;", r.text)
        self.assertNotIn("<b>x</b>", r.text)

    async def test_list_caps_items_and_works_without_bot_rights_or_claim(self):
        self.member(USER)
        for i in range(2):
            await self.run_cmd(f"/warn r{i}", reply_to=USER, msg=i + 1)
        self.s.chat.set(A, BOT, ChatMemberInfo("member"))
        r1 = await self.run_cmd("/warnings", reply_to=USER, msg=3)
        r2 = await self.run_cmd("/warnings", reply_to=USER, msg=3)  # same message id: read-only, no claim
        self.assertEqual((r1.kind, r2.kind), (R.INFO, R.INFO))
        self.assertEqual(r1.text.count("•"), 2)

    async def test_none_message(self):
        self.member(USER)
        r = await self.run_cmd("/warnings", reply_to=USER)
        self.assertEqual(r.kind, R.INFO)
        self.assertIn(str(USER), r.text)
        self.assertNotIn("•", r.text)

    async def test_warnings_allowed_on_protected_target_and_needs_moderator(self):
        self.assertEqual((await self.run_cmd(f"/warnings {TG_CREATOR}")).kind, R.INFO)
        from stack import STRANGER
        self.assertEqual((await self.run_cmd("/warnings", actor=STRANGER, reply_to=USER, msg=9)).kind, R.DENIED)

    async def test_clearwarns(self):
        self.member(USER)
        for i in range(2):
            await self.run_cmd("/warn", reply_to=USER, msg=i + 1)
        self.s.chat.set(A, BOT, ChatMemberInfo("member"))  # no Telegram call: rights irrelevant
        r = await self.run_cmd("/clearwarns", reply_to=USER, msg=3)
        self.assertEqual(r.kind, R.DONE)
        self.assertIn("2", r.text)
        self.assertEqual(await self.s.warning_store.list_active(A, USER, NOW), [])
        self.assertEqual((await self.run_cmd("/clearwarns", reply_to=USER, msg=4)).kind, R.NOOP)
        self.assertEqual(self.actions.calls, [])

    async def test_clearwarns_keeps_history_rows(self):
        self.member(USER)
        await self.run_cmd("/warn", reply_to=USER, msg=1)
        await self.run_cmd("/clearwarns", reply_to=USER, msg=2)
        rows = self.s.warning_store._rows
        self.assertEqual(len(rows), 1)  # history kept...
        self.assertIsNotNone(rows[0].revoked_at)  # ...but revoked, not deleted


class DryRun(ExecBase):
    async def test_every_mutating_command_is_preview_only(self):
        await self.settings(dry_run=True)
        self.member(USER)
        self.member(OTHER, "kicked")
        cmds = [("/ban", USER), ("/mute 10m", USER), ("/kick", USER), ("/warn", USER), ("/clearwarns", USER),
                ("/unban", OTHER)]
        self.member(5003, "restricted")
        cmds.append(("/unmute", 5003))
        for i, (text, uid) in enumerate(cmds):
            r = await self.run_cmd(text, reply_to=uid, msg=i + 1)
            self.assertEqual(r.kind, R.DRY_RUN, text)
            self.assertIn(str(uid), r.text)
        self.assertEqual(self.actions.calls, [])
        self.assertEqual(await self.s.sanction_store.get_active(A, USER, NOW), [])
        self.assertEqual(await self.s.warning_store.list_active(A, USER, NOW), [])
        self.assertEqual(self.audit_types().count("moderation_dry_run"), len(cmds))

    async def test_dry_run_consumes_no_claim_and_does_not_touch_stale_ledger(self):
        await self.settings(dry_run=True)
        self.member(USER)
        await self.run_cmd("/kick", reply_to=USER, msg=7)
        await self.settings(dry_run=False)
        r = await self.run_cmd("/kick", reply_to=USER, msg=7)  # same message id now acts
        self.assertEqual(r.kind, R.DONE)
        self.assertEqual(self.actions.names(), ["kick"])

    async def test_dry_run_does_not_clean_ledger_on_noop_unban(self):
        self.member(USER)
        await self.run_cmd("/ban", reply_to=USER, msg=1)
        self.member(USER, "member")
        await self.settings(dry_run=True)
        await self.run_cmd("/unban", reply_to=USER, msg=2)
        self.assertEqual(len(await self.s.sanction_store.get_active(A, USER, NOW)), 1)

    async def test_dry_run_still_validates_and_authorizes(self):
        await self.settings(dry_run=True)
        from stack import STRANGER
        self.assertEqual((await self.run_cmd("/ban", actor=STRANGER, reply_to=USER)).kind, R.DENIED)
        self.assertEqual((await self.run_cmd("/ban", reply_to=TG_CREATOR, msg=2)).kind, R.INVALID)
        self.assertEqual((await self.run_cmd("/mute 30x", reply_to=USER, msg=3)).kind, R.INVALID)

    async def test_dry_run_is_per_group(self):
        await self.settings(group=B, dry_run=True)
        self.member(USER)
        self.assertEqual((await self.run_cmd("/kick", reply_to=USER)).kind, R.DONE)  # A is not in dry-run


if __name__ == "__main__":
    import unittest
    unittest.main()
