"""Phase 4 / part 4: member verification core (challenge, answer, expiry, failure actions, license, isolation).

Fakes mirror the narrow interfaces the service needs; nothing here proves behaviour against the real aiogram / Telegram
(see HANDOFF.md). The adapter tests use a signature-strict fake Bot."""
import random
import unittest
from datetime import timedelta
from types import SimpleNamespace as NS

from guardian.bot import members_handler as h
from guardian.bot.actions import AiogramModerationActions
from guardian.idempotency import InMemoryIdempotency
from guardian.members import verification as v
from guardian.members.memory_store import InMemoryChallengeStore
from guardian.members.models import ChallengeKind, ChallengeStatus
from guardian.members.verification import VerificationService, buttons_for, make_puzzle, parse_callback
from guardian.members.welcome import Joined
from guardian.protection.engine import ActionResult, SendResult
from guardian.protection_gate import ProtectionGate
from stack import A, B, OWNER, STRANGER, TG_ADMIN, Stack

U1, U2, BOTID = 5001, 5002, 6001


class FakeActions:
    def __init__(self):
        self.calls, self.next_id = [], 100
        self.fail = set()  # method names that fail
        self.photos = {}   # user_id -> True/False/None (default True)
        self.photo_calls = []

    def _res(self, name, *args):
        self.calls.append((name, *args))
        return ActionResult(name not in self.fail, "forbidden" if name in self.fail else None)

    async def mute_member(self, chat, user, until): return self._res("mute", chat, user, until)
    async def unmute_member(self, chat, user): return self._res("unmute", chat, user)
    async def kick_member(self, chat, user): return self._res("kick", chat, user)
    async def ban_member(self, chat, user, until): return self._res("ban", chat, user, until)
    async def delete_message(self, chat, mid): return self._res("delete", chat, mid)

    async def send_message(self, chat, text, buttons=None):
        self.calls.append(("send", chat, text, buttons))
        if "send" in self.fail:
            return SendResult(False, "forbidden")
        self.next_id += 1
        return SendResult(True, None, self.next_id)

    async def has_profile_photo(self, user_id):
        self.photo_calls.append(user_id)
        return self.photos.get(user_id, True)

    def names(self, name): return [c for c in self.calls if c[0] == name]


class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        await self.s.register(A, B)
        await self.s.admin.activate_permanent(OWNER, A)
        await self.s.admin.activate_permanent(OWNER, B)
        self.act = FakeActions()
        self.store = InMemoryChallengeStore()
        self.timers = []
        self.mono = [1000.0]
        self.svc = self.make()
        self.gate = ProtectionGate(self.s.license_service, self.s.perm, NS(notify_group=self._noop, notify_owner=self._noop),
                                   clock=self.s.clock)
        self.mid = 0

    async def _noop(self, *a, **k): return None

    def make(self, **kw):
        def schedule(delay, job):
            self.timers.append((delay, job))
            return True
        return VerificationService(self.s.settings_store, self.act, self.store, self.s.license_service, self.s.perm,
                                   claims=InMemoryIdempotency(), clock=self.s.clock, monotonic=lambda: self.mono[0],
                                   schedule=schedule, rng=random.Random(7), **kw)

    async def cfg(self, group=A, **patch):
        await self.s.settings_store.merge(group, patch, OWNER, self.s.clock())

    async def enable(self, group=A, **patch):
        await self.cfg(group, verify_enabled=True, **patch)

    async def ctx(self, group=A):
        return await self.gate.evaluate(group, "supergroup", STRANGER)

    async def join(self, members=(Joined(U1, "Sara"),), group=A, mid=None):
        self.mid += 1
        return await self.svc.on_join(await self.ctx(group), mid or self.mid, list(members), "G")

    async def pending(self, group=A, user=U1):
        return await self.store.get_pending(group, user)


class JoinTests(Base):
    async def test_off_by_default(self):
        out = await self.join()
        self.assertEqual(out.reason, "disabled")
        self.assertEqual(self.act.calls, [])

    async def test_enabled_group_mutes_and_prompts_with_one_button(self):
        await self.enable()
        out = await self.join()
        self.assertEqual(out.challenged, (U1,))
        self.assertEqual(self.act.calls[0], ("mute", A, U1, None))
        chat, text, buttons = self.act.names("send")[0][1:]
        self.assertIn(f'tg://user?id={U1}', text)
        row = await self.pending()
        self.assertEqual(buttons, ((("✅ أنا لست بوتًا", f"vf:{row.id}:ok"),),))
        self.assertEqual(row.prompt_message_id, 101)
        self.assertEqual(self.timers[0][0], 300.0)

    async def test_unlicensed_group_does_nothing(self):
        await self.enable()
        await self.s.admin.stop(OWNER, A)
        out = await self.join()
        self.assertEqual(out.reason, "not_allowed")
        self.assertEqual(self.act.calls, [])
        self.assertIsNone(await self.pending())

    async def test_pending_group_does_nothing(self):
        await self.s.register(-1003)
        await self.enable(-1003)
        out = await self.join(group=-1003)
        self.assertEqual((out.reason, self.act.calls), ("not_allowed", []))

    async def test_settings_failure_fails_closed(self):
        async def boom(*a, **k): raise RuntimeError("db")
        self.s.settings_store.get = boom
        out = await self.svc.on_join(await self.ctx(), 1, [Joined(U1, "x")], "G")
        self.assertEqual(out.reason, "settings_unavailable")
        self.assertEqual(self.act.calls, [])

    async def test_dry_run_never_restricts(self):
        await self.enable(dry_run=True)
        self.assertEqual((await self.join()).reason, "dry_run")
        self.assertEqual(self.act.calls, [])

    async def test_bots_and_invalid_ids_are_never_challenged(self):
        await self.enable()
        out = await self.join((Joined(BOTID, "bot", True), Joined(-5, "neg")))
        self.assertEqual((out.reason, self.act.calls), ("no_humans", []))

    async def test_exempt_members_are_not_challenged(self):
        await self.enable()
        out = await self.join((Joined(OWNER, "o"), Joined(TG_ADMIN, "a")))
        self.assertEqual(out.challenged, ())
        self.assertEqual(self.act.calls, [])

    async def test_trusted_member_is_not_challenged_but_other_group_member_is(self):
        await self.enable()
        await self.s.trust.add(OWNER, A, U1, context_chat_id=A)
        out = await self.join((Joined(U1, "t"), Joined(U2, "n")))
        self.assertEqual(out.challenged, (U2,))

    async def test_trust_in_another_group_does_not_exempt(self):
        await self.enable()
        await self.s.trust.add(OWNER, B, U1, context_chat_id=B)
        self.assertEqual((await self.join()).challenged, (U1,))

    async def test_exemption_lookup_failure_means_no_challenge(self):
        await self.enable()
        async def boom(*a, **k): raise RuntimeError("x")
        self.s.trust_store.is_trusted = boom
        out = await self.join()
        self.assertEqual((out.challenged, self.act.calls), ((), []))

    async def test_redelivered_join_creates_nothing(self):
        await self.enable()
        await self.join(mid=77)
        n = len(self.act.calls)
        out = await self.join(mid=77)
        self.assertEqual(out.challenged, ())
        self.assertEqual(len(self.act.calls), n)

    async def test_rejoin_while_pending_reuses_the_challenge(self):
        await self.enable()
        await self.join(mid=1)
        out = await self.join(mid=2)
        self.assertEqual(out.challenged, ())
        self.assertEqual(len(self.act.names("send")), 1)

    async def test_missing_message_id_cannot_be_idempotent(self):
        await self.enable()
        out = await self.svc.on_join(await self.ctx(), None, [Joined(U1, "x")], "G")
        self.assertEqual((out.reason, self.act.calls), ("no_key", []))

    async def test_cannot_restrict_means_cancelled_and_no_prompt(self):
        await self.enable()
        self.act.fail.add("mute")
        out = await self.join()
        self.assertEqual(out.challenged, ())
        self.assertEqual(self.act.names("send"), [])
        self.assertIsNone(await self.pending())

    async def test_prompt_send_failure_unmutes_and_cancels(self):
        await self.enable()
        self.act.fail.add("send")
        out = await self.join()
        self.assertEqual(out.challenged, ())
        self.assertEqual(len(self.act.names("unmute")), 1)
        self.assertIsNone(await self.pending())

    async def test_only_the_configured_number_per_join_message(self):
        await self.enable()
        out = await self.join(tuple(Joined(7000 + i, f"m{i}") for i in range(25)))
        self.assertEqual(len(out.challenged), v.MAX_PER_JOIN)

    async def test_english_group_gets_english_prompt(self):
        await self.enable()
        await self.s.settings_store.set_language(A, "en", OWNER, self.s.clock())
        await self.join()
        self.assertIn("Member verification", self.act.names("send")[0][2])

    async def test_names_are_html_escaped(self):
        await self.enable()
        await self.join((Joined(U1, "<b>x</b>"),))
        self.assertIn("&lt;b&gt;x&lt;/b&gt;", self.act.names("send")[0][2])


class AnswerTests(Base):
    async def start(self, **patch):
        await self.enable(**patch)
        await self.join()
        return await self.pending()

    async def test_button_pass_unmutes_deletes_prompt_and_resolves(self):
        row = await self.start()
        out = await self.svc.answer(A, row.id, U1, "ok")
        self.assertEqual(out.kind, "passed")
        self.assertEqual(self.act.names("unmute"), [("unmute", A, U1)])
        self.assertEqual(self.act.names("delete"), [("delete", A, 101)])
        self.assertEqual((await self.store.get(A, row.id)).status, ChallengeStatus.PASSED)
        self.assertEqual((await self.svc.answer(A, row.id, U1, "ok")).kind, "gone")  # second click does nothing
        self.assertEqual(len(self.act.names("unmute")), 1)

    async def test_pass_with_failed_unmute_is_reported(self):
        row = await self.start()
        self.act.fail.add("unmute")
        self.assertEqual((await self.svc.answer(A, row.id, U1, "ok")).kind, "passed_unmute_failed")

    async def test_someone_else_cannot_answer_for_the_member(self):
        row = await self.start()
        out = await self.svc.answer(A, row.id, U2, "ok")
        self.assertEqual((out.kind, out.alert), ("not_yours", True))
        self.assertTrue((await self.store.get(A, row.id)).is_pending)
        self.assertEqual(self.act.names("unmute"), [])

    async def test_challenge_of_another_group_is_unreachable(self):
        row = await self.start()
        self.assertEqual((await self.svc.answer(B, row.id, U1, "ok")).kind, "gone")
        self.assertTrue((await self.store.get(A, row.id)).is_pending)

    async def test_math_wrong_answers_count_then_fail_with_kick(self):
        row = await self.start(verify_method="math", verify_failure="kick", verify_max_attempts=3)
        # a fresh challenge per method: the first join used button, so start another member
        await self.join((Joined(U2, "m"),))
        row = await self.pending(user=U2)
        self.assertEqual(row.kind, ChallengeKind.MATH)
        wrong = next(str(n) for n in range(30) if str(n) != row.answer)
        o1 = await self.svc.answer(A, row.id, U2, wrong)
        o2 = await self.svc.answer(A, row.id, U2, wrong)
        self.assertEqual((o1.kind, o2.kind), ("wrong", "wrong"))
        self.assertIn("1", o2.text)
        o3 = await self.svc.answer(A, row.id, U2, wrong)
        self.assertEqual(o3.kind, "failed")
        self.assertEqual(self.act.names("kick"), [("kick", A, U2)])
        self.assertEqual((await self.store.get(A, row.id)).status, ChallengeStatus.FAILED)

    async def test_correct_math_answer_after_a_wrong_one_passes(self):
        await self.enable(verify_method="math")
        await self.join()
        row = await self.pending()
        wrong = next(str(n) for n in range(30) if str(n) != row.answer)
        await self.svc.answer(A, row.id, U1, wrong)
        self.assertEqual((await self.svc.answer(A, row.id, U1, row.answer)).kind, "passed")

    async def test_attempt_limit_is_capped_for_guessable_challenges(self):
        await self.enable(verify_method="choice", verify_max_attempts=10)
        await self.join()
        row = await self.pending()
        wrong = next(k for k in v.SYMBOLS if k != row.answer)
        kinds = [(await self.svc.answer(A, row.id, U1, wrong)).kind for _ in range(v.MAX_GUESS_ATTEMPTS)]
        self.assertEqual(kinds[-1], "failed")

    async def test_ban_failure_action_is_temporary(self):
        await self.enable(verify_method="math", verify_failure="ban", verify_ban_seconds=600, verify_max_attempts=1)
        await self.join()
        row = await self.pending()
        wrong = next(str(n) for n in range(30) if str(n) != row.answer)
        await self.svc.answer(A, row.id, U1, wrong)
        name, chat, user, until = self.act.names("ban")[0]
        self.assertEqual((chat, user, until), (A, U1, self.s.clock() + timedelta(seconds=600)))

    async def test_restrict_failure_action_leaves_member_muted(self):
        await self.enable(verify_method="math", verify_failure="restrict", verify_max_attempts=1)
        await self.join()
        row = await self.pending()
        wrong = next(str(n) for n in range(30) if str(n) != row.answer)
        self.assertEqual((await self.svc.answer(A, row.id, U1, wrong)).kind, "failed")
        self.assertEqual((self.act.names("kick"), self.act.names("ban"), self.act.names("unmute")), ([], [], []))

    async def test_answer_after_license_stopped_does_nothing(self):
        row = await self.start()
        await self.s.admin.stop(OWNER, A)
        n = len(self.act.calls)
        self.assertEqual((await self.svc.answer(A, row.id, U1, "ok")).kind, "unavailable")
        self.assertEqual(len(self.act.calls), n)
        self.assertTrue((await self.store.get(A, row.id)).is_pending)

    async def test_late_answer_expires_instead_of_passing(self):
        row = await self.start(verify_failure="kick")
        self.s.clock.advance(seconds=301)
        self.assertEqual((await self.svc.answer(A, row.id, U1, "ok")).kind, "expired")
        self.assertEqual(self.act.names("kick"), [("kick", A, U1)])
        self.assertEqual((await self.store.get(A, row.id)).status, ChallengeStatus.EXPIRED)

    async def test_two_racing_resolutions_apply_the_failure_once(self):
        row = await self.start(verify_failure="kick")
        self.s.clock.advance(seconds=400)
        a = await self.svc.sweep()
        b = await self.svc.sweep()
        self.assertEqual((a, b), (1, 0))
        self.assertEqual(len(self.act.names("kick")), 1)


class ExpiryTests(Base):
    async def test_timer_resolves_after_deadline(self):
        await self.enable(verify_failure="kick")
        await self.join()
        delay, job = self.timers[0]
        await job()  # fires early: nothing
        self.assertEqual(self.act.names("kick"), [])
        self.s.clock.advance(seconds=int(delay))
        await job()
        self.assertEqual(self.act.names("kick"), [("kick", A, U1)])

    async def test_sweep_after_sleep_resolves_what_expired_meanwhile(self):
        await self.enable(verify_failure="ban", verify_ban_seconds=120)
        await self.join()
        self.timers.clear()                      # the process slept: in-memory timers are gone
        fresh = self.make()                      # new process, same database
        self.s.clock.advance(hours=3)
        self.mono[0] += 100
        self.assertEqual(await fresh.tick(), 1)
        self.assertEqual(len(self.act.names("ban")), 1)

    async def test_tick_is_throttled(self):
        await self.enable()
        await self.join()
        self.s.clock.advance(hours=1)
        self.assertEqual(await self.svc.tick(), 1)
        await self.join((Joined(U2, "b"),))
        self.s.clock.advance(hours=1)
        self.assertEqual(await self.svc.tick(), 0)   # inside the interval
        self.mono[0] += v.SWEEP_INTERVAL + 1
        self.assertEqual(await self.svc.tick(), 1)

    async def test_expired_license_leaves_pending_rows_untouched(self):
        await self.enable(verify_failure="kick")
        await self.join()
        await self.s.admin.stop(OWNER, A)
        self.s.clock.advance(hours=2)
        n = len(self.act.calls)
        self.assertEqual(await self.svc.sweep(), 0)
        self.assertEqual(len(self.act.calls), n)
        self.assertIsNotNone(await self.pending())
        await self.s.admin.activate_permanent(OWNER, A)   # license returns: the sweeper resolves it
        self.assertEqual(await self.svc.sweep(), 1)
        self.assertEqual(len(self.act.names("kick")), 1)

    async def test_sweep_only_acts_in_licensed_groups(self):
        await self.enable(A, verify_failure="kick")
        await self.enable(B, verify_failure="kick")
        await self.join(group=A)
        await self.join(group=B)
        await self.s.admin.stop(OWNER, B)
        self.s.clock.advance(hours=2)
        self.assertEqual(await self.svc.sweep(), 1)
        self.assertEqual(self.act.names("kick"), [("kick", A, U1)])

    async def test_member_who_became_admin_is_cancelled_and_unmuted_not_punished(self):
        await self.enable(verify_failure="kick")
        await self.join()
        from guardian.telegram_rights import ChatMemberInfo
        self.s.chat.set(A, U1, ChatMemberInfo("administrator", True, True, True))
        self.s.clock.advance(hours=1)
        await self.svc.sweep()
        self.assertEqual(self.act.names("kick"), [])
        self.assertEqual(self.act.names("unmute"), [("unmute", A, U1)])
        self.assertIsNone(await self.pending())

    async def test_dry_run_turned_on_cancels_and_unmutes(self):
        await self.enable(verify_failure="ban")
        await self.join()
        await self.cfg(dry_run=True)
        self.s.clock.advance(hours=1)
        await self.svc.sweep()
        self.assertEqual((self.act.names("ban"), len(self.act.names("unmute"))), ([], 1))

    async def test_lookup_failure_at_expiry_leaves_row_for_next_sweep(self):
        await self.enable(verify_failure="kick")
        await self.join()
        self.s.clock.advance(hours=1)
        real = self.s.trust_store.is_trusted
        async def boom(*a, **k): raise RuntimeError("x")
        self.s.trust_store.is_trusted = boom
        self.assertEqual(await self.svc.sweep(), 0)
        self.assertIsNotNone(await self.pending())
        self.s.trust_store.is_trusted = real
        self.assertEqual(await self.svc.sweep(), 1)

    async def test_losing_the_resolution_race_does_nothing(self):
        await self.enable(verify_failure="kick")
        await self.join()
        self.s.clock.advance(hours=1)
        async def lost(*a, **k): return None  # another worker resolved it first
        self.store.resolve = lost
        self.assertEqual(await self.svc.sweep(), 0)
        self.assertEqual([c for c in self.act.calls if c[0] in ("kick", "ban", "unmute")], [])

    async def test_settings_failure_at_expiry_leaves_row_pending_and_does_nothing(self):
        await self.enable(verify_failure="kick")
        await self.join()
        self.s.clock.advance(hours=1)
        real = self.s.settings_store.get
        async def boom(*a, **k): raise RuntimeError("db")
        self.s.settings_store.get = boom
        n = len(self.act.calls)
        self.assertEqual(await self.svc.sweep(), 0)
        self.assertEqual(len(self.act.calls), n)
        self.assertIsNotNone(await self.pending())
        self.s.settings_store.get = real
        self.assertEqual(await self.svc.sweep(), 1)

    async def test_member_leaving_cancels_the_challenge(self):
        await self.enable(verify_failure="kick")
        await self.join()
        self.assertTrue(await self.svc.on_leave(await self.ctx(), U1))
        self.assertIsNone(await self.pending())
        self.assertEqual(self.act.names("delete"), [("delete", A, 101)])
        self.s.clock.advance(hours=1)
        self.assertEqual(await self.svc.sweep(), 0)
        self.assertEqual(self.act.names("kick"), [])

    async def test_leave_without_license_does_nothing(self):
        await self.enable()
        await self.join()
        await self.s.admin.stop(OWNER, A)
        self.assertFalse(await self.svc.on_leave(await self.ctx(), U1))
        self.assertIsNotNone(await self.pending())

    async def test_aclose_cancels_timers(self):
        svc = VerificationService(self.s.settings_store, self.act, self.store, self.s.license_service, self.s.perm,
                                  claims=InMemoryIdempotency(), clock=self.s.clock, rng=random.Random(1))
        await self.enable()
        await svc.on_join(await self.ctx(), 1, [Joined(U1, "x")], "G")
        self.assertEqual(len(svc._tasks), 1)
        await svc.aclose()
        self.assertEqual(len(svc._tasks), 0)


class PuzzleTests(unittest.TestCase):
    def test_math_is_correct_never_negative_and_answer_is_an_option(self):
        for seed in range(300):
            p = make_puzzle(ChallengeKind.MATH, "ar", random.Random(seed))
            nums = [int(x) for x in p.question.replace("−", " ").replace("+", " ").replace("؟", " ").split() if x.isdigit()]
            expected = nums[0] + nums[1] if "+" in p.question else nums[0] - nums[1]
            self.assertEqual(str(expected), p.answer)
            self.assertGreaterEqual(expected, 0)
            values = [val for _, val in p.options]
            self.assertEqual((len(values), len(set(values)), p.answer in values), (v.OPTIONS, v.OPTIONS, True))

    def test_choice_names_the_target_and_has_it_among_distinct_options(self):
        for seed in range(100):
            for lang, idx in (("ar", 1), ("en", 2)):
                p = make_puzzle(ChallengeKind.CHOICE, lang, random.Random(seed))
                self.assertIn(v.SYMBOLS[p.answer][idx], p.question)
                self.assertEqual(len({val for _, val in p.options}), v.OPTIONS)
                self.assertIn(p.answer, [val for _, val in p.options])

    def test_button_and_unsupported_kind(self):
        self.assertEqual(make_puzzle(ChallengeKind.BUTTON, "en", random.Random(1)).answer, "ok")
        admin = make_puzzle(ChallengeKind.ADMIN, "en", random.Random(1))
        self.assertEqual([val for _, val in admin.options], ["ap", "rj"])
        with self.assertRaises(ValueError):
            make_puzzle("nope", "ar", random.Random(1))

    def test_callback_data_roundtrip_and_limits(self):
        rows = buttons_for(12, tuple((str(i), str(i)) for i in range(6)))
        self.assertEqual([len(r) for r in rows], [3, 3])
        self.assertEqual(rows[0][0][1], "vf:12:0")
        self.assertTrue(all(len(c[1].encode()) <= 64 for r in rows for c in r))
        self.assertEqual(parse_callback("vf:12:ok"), (12, "ok"))
        for bad in (None, 5, "vf:12", "vf:x:ok", "vf:12:OK", "vf:12:a b", "xx:12:ok", "vf:12:ok:extra", "vf:-1:ok", "vf:12:" + "a" * 13):
            self.assertIsNone(parse_callback(bad), bad)


def query(data, chat_id=A, chat_type="supergroup", user=U1, with_message=True):
    msg = NS(chat=NS(id=chat_id, type=chat_type)) if with_message else None
    return NS(data=data, from_user=NS(id=user), message=msg)


class HandlerTests(Base):
    async def services(self):
        return NS(verification=self.svc, welcome=None)

    async def test_forged_callback_cannot_act_for_another_member(self):
        await self.enable()
        await self.join()
        row = await self.pending()
        res = await h.on_verify_callback(query(f"vf:{row.id}:ok", user=U2), await self.services())
        self.assertEqual(res[1], True)
        self.assertTrue((await self.store.get(A, row.id)).is_pending)

    async def test_forged_callback_from_another_group_message_is_gone(self):
        await self.enable()
        await self.join()
        row = await self.pending()
        res = await h.on_verify_callback(query(f"vf:{row.id}:ok", chat_id=B), await self.services())
        self.assertIn("انتهى", res[0])
        self.assertTrue((await self.store.get(A, row.id)).is_pending)

    async def test_private_chat_inline_and_malformed_callbacks_are_ignored(self):
        await self.enable()
        await self.join()
        row = await self.pending()
        svcs = await self.services()
        for q in (query(f"vf:{row.id}:ok", chat_id=U1, chat_type="private"), query(f"vf:{row.id}:ok", with_message=False),
                  query("vf:garbage"), query(None), query(f"vf:{row.id}:ok", user=True)):
            self.assertIsNone(await h.on_verify_callback(q, svcs))
        self.assertTrue((await self.store.get(A, row.id)).is_pending)

    async def test_valid_press_passes(self):
        await self.enable()
        await self.join()
        row = await self.pending()
        res = await h.on_verify_callback(query(f"vf:{row.id}:ok"), await self.services())
        self.assertEqual(res, ("✅ تم التحقق، أهلًا بك", False))

    async def test_service_crash_is_swallowed(self):
        class Boom:
            async def answer(self, *a): raise RuntimeError("x")
        self.assertIsNone(await h.on_verify_callback(query("vf:1:ok"), NS(verification=Boom())))

    async def test_join_handler_verifies_before_welcoming_and_survives_failures(self):
        order = []
        class V:
            async def on_join(self, *a): order.append("verify"); raise RuntimeError("x")
        class W:
            async def on_join(self, *a): order.append("welcome")
        msg = NS(message_id=9, chat=NS(title="G"), new_chat_members=[NS(id=U1, full_name="S", is_bot=False)])
        await h.on_new_members(msg, await self.ctx(), NS(verification=V(), welcome=W()))
        self.assertEqual(order, ["verify", "welcome"])

    async def test_join_handler_does_nothing_without_license(self):
        await self.enable()
        await self.s.admin.stop(OWNER, A)
        msg = NS(message_id=9, chat=NS(title="G"), new_chat_members=[NS(id=U1, full_name="S", is_bot=False)])
        await h.on_new_members(msg, await self.ctx(), NS(verification=self.svc, welcome=None))
        self.assertEqual(self.act.calls, [])

    async def test_leave_handler_cancels(self):
        await self.enable()
        await self.join()
        msg = NS(message_id=10, chat=NS(title="G"), left_chat_member=NS(id=U1))
        await h.on_left_member(msg, await self.ctx(), NS(verification=self.svc, welcome=None))
        self.assertIsNone(await self.pending())


class StrictBot:
    def __init__(self):
        self.calls = []
        self.returned = NS(message_id=55)

    async def send_message(self, chat_id, text, *, parse_mode=None, disable_notification=None, reply_markup=None):
        self.calls.append((chat_id, text, parse_mode, disable_notification, reply_markup))
        return self.returned


class AdapterButtonTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.bot = StrictBot()
        self.act = AiogramModerationActions(self.bot, markup_factory=lambda rows: ("MARKUP", rows))

    async def test_buttons_become_reply_markup(self):
        rows = ((("OK", "vf:1:ok"),),)
        res = await self.act.send_message(-100, "hi", rows)
        self.assertEqual((res.ok, res.message_id), (True, 55))
        self.assertEqual(self.bot.calls[0][4], ("MARKUP", rows))

    async def test_no_buttons_means_no_markup_argument_change(self):
        await self.act.send_message(-100, "hi")
        self.assertIsNone(self.bot.calls[0][4])

    async def test_invalid_buttons_are_refused_before_telegram(self):
        for bad in ((), (()), ((("", "x"),),), ((("a", ""),),), ((("a", "x" * 65),),), ((("a", "é" * 33),),),
                    ("nope",), ((("a",),),), (tuple((("a", "b"),) for _ in range(9)),), ((tuple(("a", "b") for _ in range(9)),),)):
            res = await self.act.send_message(-100, "hi", bad)
            self.assertFalse(res.ok, bad)
        self.assertEqual(self.bot.calls, [])

    async def test_keyboard_build_failure_refuses_to_send(self):
        def boom(rows): raise ImportError("no aiogram")
        act = AiogramModerationActions(self.bot, markup_factory=boom)
        self.assertFalse((await act.send_message(-100, "hi", ((("a", "b"),),))).ok)
        self.assertEqual(self.bot.calls, [])


class MiddlewareTickTests(unittest.IsolatedAsyncioTestCase):
    async def test_tick_runs_on_every_update_and_failures_never_block(self):
        from guardian.bot.middlewares import ProtectionGateMiddleware
        from guardian.protection_gate import denied
        class Gate:
            async def evaluate(self, *a, **k): return denied(-1, "supergroup", "pending", None)
        ticks, handled = [], []
        async def tick():
            ticks.append(1)
            raise RuntimeError("boom")
        async def handler(event, data): handled.append(1)
        mw = ProtectionGateMiddleware(Gate(), None, tick=tick)
        await mw(handler, NS(chat=NS(id=-1, type="supergroup"), from_user=NS(id=1), sender_chat=None, message_id=1), {})
        self.assertEqual((ticks, handled), ([1], [1]))


if __name__ == "__main__":
    unittest.main()
