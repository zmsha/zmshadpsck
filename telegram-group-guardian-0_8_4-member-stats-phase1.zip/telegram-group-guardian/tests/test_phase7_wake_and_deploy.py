"""Part 7.2: what a Render Free sleep/wake does (and does not) change, and the no-workaround guards.

Render Free sleeps the process; on the next request everything in memory is new and only PostgreSQL survives. Here a
"restart" rebuilds EVERY in-memory object (license service, permissions, gate, engine, middleware, command service,
dedup) over the SAME stores and the SAME durable claims, then drives the real chain again.

Acceptance (PHASE7_PLAN.md, 7.2):
* (a) first sensitive update after a sleep that outlived a temporary license => no protection, no moderation;
* (b) licenses and groups live in the durable store, not in the process;
* (c) a duplicate update after a restart is not executed twice (durable claim);
* (d) a database that is down at startup => the service stays up, protection is closed, the owner can renew when it returns;
* (e) static guard: no ping / keep-alive / external scheduler / worker to stay awake, and no polling beside the webhook;
* (f) `/health` exposes no secret and no database detail.
"""
from __future__ import annotations

import ast
import re
import unittest
from datetime import timedelta
from pathlib import Path

from executor_stack import USER
from guardian.bot.middlewares import ProtectionGateMiddleware
from guardian.health import DB_OK, DB_UNAVAILABLE, DB_UNKNOWN, build_health
from guardian.idempotency import update_key
from guardian.licensing.service import LicenseService
from guardian.moderation.executor import ModerationCommandService, ResultKind as R
from guardian.moderation.service import SanctionService, WarningService
from guardian.permissions import PermissionService
from guardian.protection.engine import ProtectionEngine
from guardian.protection_gate import ProtectionGate
from guardian.webhook import UpdateDeduplicator
from helpers import FakeNotifier
from stack import OWNER, STRANGER, TG_ADMIN
from executor_stack import BOT
from test_phase3_final_handoff import Acts, Pipeline

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src" / "guardian"


class Wake(Pipeline):
    """`Pipeline` (real gate -> real middleware -> real engine/command service) plus a simulated process restart."""

    def restart(self) -> None:
        """A sleeping host loses every in-memory object; the stores and the durable claims are what PostgreSQL keeps."""
        s = self.s
        s.perm = PermissionService(s.authority, s.deleg_store, s.chat, s.audit, s.trust_store, clock=s.clock)
        s.warnings = WarningService(s.warning_store, s.licenses, s.perm, s.audit, clock=s.clock)
        s.sanctions = SanctionService(s.sanction_store, s.licenses, s.perm, s.audit, clock=s.clock)
        s.license_service = LicenseService(s.licenses)
        self.notifier = FakeNotifier()
        self.actions = Acts()
        self.gate = ProtectionGate(s.license_service, s.perm, self.notifier, clock=s.clock)
        self.engine = ProtectionEngine(s.settings_store, self.actions, s.chat, self.claims, s.audit, self.notifier, clock=s.clock)
        self.mw = ProtectionGateMiddleware(self.gate, self.engine)
        self.svc = ModerationCommandService(
            permissions=s.perm, warnings=s.warnings, sanctions=s.sanctions, settings_store=s.settings_store,
            actions=self.actions, chat_info=s.chat, claims=self.claims, audit=s.audit, bot_id=BOT, clock=s.clock)
        self.services.moderation_commands = self.svc
        self.dedup = UpdateDeduplicator()

    # ------------------------------------------------------------------ (a) license is re-checked after the wake
    async def test_first_sensitive_update_after_a_sleep_past_expiry_does_not_protect(self):
        g = await self.group_in("pending")
        await self.s.admin.activate_temporary(OWNER, g, self.s.clock() + timedelta(hours=1))
        n = len(self.actions.calls)
        await self.deliver(self.link(g))
        self.assertEqual(self.actions.calls[n][0], "delete")         # licensed while awake
        self.s.clock.advance(hours=5)                                # the host slept; no scheduler flipped anything
        self.restart()
        await self.assert_fully_off(g, TG_ADMIN)                     # first update after waking: every command + protection off
        await self.assert_fully_off(g, OWNER)                        # the license is not bypassed by the owner's commands either

    async def test_sleep_inside_the_license_window_keeps_protecting_and_expiry_still_bites_later(self):
        g = await self.group_in("pending")
        await self.s.admin.activate_temporary(OWNER, g, self.s.clock() + timedelta(hours=3))
        self.s.clock.advance(hours=1)
        self.restart()
        n = len(self.actions.calls)
        await self.deliver(self.link(g))
        self.assertEqual(self.actions.calls[n][0], "delete")         # still licensed after the wake
        self.s.clock.advance(hours=2)                                # exactly at expires_at => expired, evaluated from the clock
        self.restart()
        await self.assert_fully_off(g, TG_ADMIN)

    # ------------------------------------------------------------------ (b) state is in the store, not in the process
    async def test_licenses_and_groups_survive_a_restart_unchanged(self):
        active = await self.group_in("pending")
        await self.s.admin.activate_permanent(OWNER, active)
        stopped = await self.group_in("stopped")
        pending = await self.group_in("pending")
        banned = await self.group_in("banned")
        snapshot = {g: (r.status, r.expires_at) for g, r in self.s.licenses._rows.items()}
        self.restart()
        self.assertEqual({g: (r.status, r.expires_at) for g, r in self.s.licenses._rows.items()}, snapshot)
        n = len(self.actions.calls)
        await self.deliver(self.link(active))
        self.assertEqual(self.actions.calls[n][0], "delete")         # the permanent license still protects
        for g in (stopped, pending, banned):
            await self.assert_fully_off(g, TG_ADMIN)
        self.assertEqual({g: (r.status, r.expires_at) for g, r in self.s.licenses._rows.items()}, snapshot)  # nothing was activated by waking

    async def test_a_group_first_seen_after_a_restart_is_registered_pending_never_active(self):
        self.restart()
        g = await self.group_in("unregistered")
        await self.deliver(self.cmd("/ban", g))
        self.assertEqual((await self.s.licenses.get(g)).status.value, "pending")
        await self.assert_fully_off(g, TG_ADMIN)

    # ------------------------------------------------------------------ (c) durable de-duplication
    async def test_duplicate_update_after_a_restart_is_not_run_twice(self):
        self.restart()
        self.assertFalse(self.dedup.seen_before(41))
        self.assertTrue(await self.claims.claim(update_key(41)))     # first delivery: processed
        self.restart()                                               # sleep: the in-memory dedup is empty again ...
        self.assertFalse(self.dedup.seen_before(41))
        self.assertFalse(await self.claims.claim(update_key(41)))    # ... but the durable claim refuses the redelivery
        self.assertTrue(await self.claims.claim(update_key(42)))     # a genuinely new update is unaffected

    async def test_a_sanction_command_redelivered_after_a_restart_acts_once(self):
        g = await self.group_in("pending")
        await self.s.admin.activate_permanent(OWNER, g)
        msg = self.cmd("/ban", g)
        _, first = await self.deliver(msg)
        self.assertEqual(first.kind, R.DONE)
        self.restart()
        await self.deliver(msg)                                      # same message id again, new process
        self.assertEqual(self.actions.names().count("ban"), 0)       # the new process did not ban again
        self.assertEqual(len(await self.s.sanction_store.get_active(g, USER, self.s.clock())), 1)

    # ------------------------------------------------------------------ (d) database down at startup
    async def test_database_down_after_a_restart_closes_protection_and_the_owner_renews_when_it_returns(self):
        g = await self.group_in("pending")
        await self.s.admin.activate_permanent(OWNER, g)
        self.restart()
        real_get = self.s.licenses.get

        async def down(*a, **k):
            raise RuntimeError("db down")

        self.s.licenses.get = down
        try:
            await self.assert_fully_off(g, TG_ADMIN)                 # degraded: up, but closed
            await self.assert_fully_off(g, OWNER)
        finally:
            self.s.licenses.get = real_get                           # the database is back
        n = len(self.actions.calls)
        await self.deliver(self.link(g))                             # the stored license is intact: protection resumes
        self.assertEqual(self.actions.calls[n][0], "delete")
        await self.s.admin.stop(OWNER, g)                            # the owner's license path worked all along
        await self.assert_fully_off(g, TG_ADMIN)
        await self.s.admin.activate_permanent(OWNER, g)
        n = len(self.actions.calls)
        await self.deliver(self.link(g))
        self.assertEqual(self.actions.calls[n][0], "delete")         # renewed by the owner: protection is back

    def test_startup_never_raises_on_a_migration_or_pool_failure(self):
        tree = ast.parse((SRC / "app.py").read_text(encoding="utf-8"))
        startup = next(n for n in ast.walk(tree) if isinstance(n, ast.AsyncFunctionDef) and n.name == "_startup")
        guarded = {"run_migrations": False, "ensure_pool": False, "set_webhook": False}
        for node in ast.walk(startup):
            if not isinstance(node, ast.Try):
                continue
            body_text = "".join(ast.unparse(b) for b in node.body)
            for name in guarded:
                if name + "(" in body_text:
                    self.assertTrue(node.handlers, name)
                    self.assertFalse(any(isinstance(x, ast.Raise) for h in node.handlers for x in ast.walk(h)), name)
                    guarded[name] = True
        self.assertEqual([k for k, v in guarded.items() if not v], [])

    def test_webhook_handler_checks_the_secret_then_dedups_then_feeds_the_dispatcher_in_that_order(self):
        text = (SRC / "app.py").read_text(encoding="utf-8")
        body = text[text.index("async def telegram_webhook"):text.index("@app.exception_handler")]
        order = [body.index(x) for x in ("verify_secret_token", "dedup.seen_before", "claims.claim(update_key(", "feed_update")]
        self.assertEqual(order, sorted(order))
        self.assertIn("drop_pending_updates=False", text)            # updates queued during the sleep are processed (and license-checked)


# --------------------------------------------------------------------------- (e) no workaround to stay awake, no polling
FORBIDDEN_SCHEDULERS = ("apscheduler", "celery", "aiocron", "crontab", "dramatiq", "arq", "huey", "schedule")
FORBIDDEN_POLLING = re.compile(r"start_polling|run_polling|\bgetUpdates\b|get_updates", re.IGNORECASE)
KEEPALIVE_SERVICES = re.compile(r"uptime\s*robot|cron-job\.org|cronitor|pingdom|freshping|healthchecks\.io|better\s*uptime|statuscake", re.IGNORECASE)
KEEPALIVE_WORDS = re.compile(r"keep[- ]?alive|keep[- ]?awake|\bpings?\b|\bcron\b|مجدول|بنغ", re.IGNORECASE)
NEGATION = re.compile(r"\bno\b|\bnot\b|\bnever\b|\bnor\b|without|don't|do not|doesn't|لا\b|لا |بلا|بدون|ممنوع|يمنع|لن |ليس|خارج|never", re.IGNORECASE)
LIVE_DOCS = ("README.md", "render.yaml", ".env.example", "docs/BACKUP_RESTORE.md", "docs/DEPLOY_RENDER.md", "docs/LOCAL_VERIFY.md")


class NoWorkaroundGuards(unittest.TestCase):
    def test_no_polling_beside_the_webhook(self):
        for path in SRC.rglob("*.py"):
            self.assertIsNone(FORBIDDEN_POLLING.search(path.read_text(encoding="utf-8")), str(path.relative_to(ROOT)))

    def test_no_scheduler_or_background_loop_library_in_source_or_requirements(self):
        names = re.compile(r"^\s*(?:from|import)\s+(%s)\b" % "|".join(FORBIDDEN_SCHEDULERS), re.MULTILINE)
        for path in SRC.rglob("*.py"):
            self.assertIsNone(names.search(path.read_text(encoding="utf-8")), str(path.relative_to(ROOT)))
        for req in ("requirements.txt", "requirements-dev.txt", "pyproject.toml"):
            text = (ROOT / req).read_text(encoding="utf-8").lower()
            for lib in FORBIDDEN_SCHEDULERS:
                self.assertNotRegex(text, r"(?m)^\s*[\"']?%s\b" % lib, f"{req}: {lib}")

    def test_no_self_driven_background_loop(self):
        """Background work rides on incoming updates (`tick`); no coroutine spins on its own (`while True` + sleep)."""
        for path in SRC.rglob("*.py"):
            for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"))):
                if isinstance(node, ast.While) and isinstance(node.test, ast.Constant) and node.test.value is True:
                    sleeps = [c for c in ast.walk(node) if isinstance(c, ast.Call) and getattr(c.func, "attr", getattr(c.func, "id", "")) == "sleep"]
                    self.assertEqual(sleeps, [], f"`while True` + sleep in {path.relative_to(ROOT)}:{node.lineno}")

    def test_render_yaml_declares_one_free_web_service_and_no_worker_or_cron(self):
        text = (ROOT / "render.yaml").read_text(encoding="utf-8")
        types = re.findall(r"(?m)^\s*-?\s*type:\s*(\S+)", text)
        self.assertEqual(types, ["web"])
        self.assertNotRegex(text, r"(?mi)^\s*-?\s*(?:type:\s*(?:worker|cron|pserv|keyvalue|redis)|cronJobs|schedule:)")
        self.assertRegex(text, r"(?m)^\s*plan:\s*free\s*$")

    def test_live_documents_never_recommend_pinging_or_an_external_scheduler(self):
        for rel in LIVE_DOCS:
            path = ROOT / rel
            if not path.exists():
                continue                                             # DEPLOY_RENDER.md / LOCAL_VERIFY.md arrive in 7.3
            for n, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
                self.assertIsNone(KEEPALIVE_SERVICES.search(line), f"{rel}:{n} names a keep-alive service")
                if KEEPALIVE_WORDS.search(line):
                    self.assertIsNotNone(NEGATION.search(line), f"{rel}:{n} mentions ping/keep-alive/scheduler without refusing it: {line.strip()}")

    def test_the_documents_state_the_free_plan_sleeps_and_gives_no_instant_protection_guarantee(self):
        text = (ROOT / "README.md").read_text(encoding="utf-8") + (ROOT / "render.yaml").read_text(encoding="utf-8")
        self.assertIn("تنام", text)
        self.assertIn("لا يضمن", text)
        self.assertRegex(text, r"(?i)no keep-alive pings")


# --------------------------------------------------------------------------- (f) /health leaks nothing
class HealthLeaksNothing(unittest.TestCase):
    def test_payload_has_two_fixed_keys_and_closed_values(self):
        for status in (DB_OK, DB_UNAVAILABLE, DB_UNKNOWN):
            self.assertEqual(build_health(status), {"status": "ok", "database": status})

    def test_anything_else_is_reported_as_unknown_never_echoed(self):
        for raw in ("postgresql://user:pw@db.example.com:5432/app", "password authentication failed for user bot", "", None, 7):
            self.assertEqual(build_health(raw), {"status": "ok", "database": DB_UNKNOWN})  # type: ignore[arg-type]

    def test_health_module_and_route_touch_neither_settings_nor_the_database(self):
        health = (SRC / "health.py").read_text(encoding="utf-8")
        self.assertNotRegex(health, r"(?m)^\s*(?:from|import)\s+.*(?:config|os|db|asyncpg|logging)\b")
        text = (SRC / "app.py").read_text(encoding="utf-8")
        route = text[text.index("async def health"):text.index("@app.post(WEBHOOK_PATH)")]
        self.assertIn("build_health(database.last_known_status)", route)
        for forbidden in ("settings", "acquire", "fetch", "execute", "ensure_pool", "__version__"):
            self.assertNotIn(forbidden, route)


if __name__ == "__main__":
    unittest.main()
