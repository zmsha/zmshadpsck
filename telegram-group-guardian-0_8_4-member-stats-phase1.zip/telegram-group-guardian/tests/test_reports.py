"""Part 6.3: report store (models, memory + PostgreSQL stores, service, migration 0008) and the `/report` hook.
PostgreSQL itself is NOT exercised: the stores are checked against a recording fake connection."""
from __future__ import annotations

import asyncio
import re
import unittest
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path

from executor_stack import A, B, BOT, BOT_NAME, OTHER, USER, ExecBase, gate
from guardian.audit import InMemorySecurityAudit
from guardian.db.migrations import discover
from guardian.errors import InvalidInput
from guardian.moderation.commands import parse_command
from guardian.moderation.executor import ModerationCommandService, ResultKind as R
from guardian.moderation.targets import ReplyInfo
from guardian.reports import (OPEN_STATUSES, ReportOutcome, ReportPriority, ReportService, ReportStatus, ReportType,
                              TransitionCode, clean_reason)
from guardian.reports.memory_store import InMemoryReportStore
from guardian.reports.postgres_store import PostgresReportStore
from guardian.trace import reset_trace_id, set_trace_id
from stack import NOW, OWNER, TG_ADMIN, TG_CREATOR
from test_info_commands import adm

ROOT = Path(__file__).resolve().parent.parent
SQL = ROOT / "src" / "guardian" / "db" / "sql" / "0008_group_reports.sql"
ADMIN1, ADMIN2 = 7001, 7002


def svc(audit=None, clock=None):
    return ReportService(InMemoryReportStore(), audit, clock or (lambda: NOW))


class ModelTests(unittest.TestCase):
    def test_clean_reason(self):
        self.assertIsNone(clean_reason(None))
        self.assertIsNone(clean_reason("  \u202e \x00 "))
        self.assertEqual(clean_reason("a\u202eb\x07  c\n d"), "ab c d")
        self.assertEqual(len(clean_reason("x" * 500)), 200)
        self.assertNotIn("123456789:ABCdefGhIJKlmNoPQRsTuVwxyz012345678", clean_reason("t 123456789:ABCdefGhIJKlmNoPQRsTuVwxyz012345678"))

    def test_open_statuses(self):
        self.assertEqual(set(OPEN_STATUSES), {ReportStatus.OPEN, ReportStatus.TAKEN})


class CreateTests(unittest.IsolatedAsyncioTestCase):
    async def test_defaults_and_fields(self):
        s = svc()
        r, created = await s.create(A, USER, OTHER, 77, "  spam   here ")
        self.assertTrue(created)
        self.assertEqual((r.group_id, r.reporter_id, r.target_user_id, r.message_id, r.reason), (A, USER, OTHER, 77, "spam here"))
        self.assertEqual((r.report_type, r.priority, r.status), (ReportType.OTHER, ReportPriority.NORMAL, ReportStatus.OPEN))
        self.assertEqual((r.assigned_to, r.outcome, r.handled_by, r.handled_at), (None, None, None, None))
        self.assertEqual((r.created_at, r.updated_at), (NOW, NOW))
        self.assertTrue(r.is_open)

    async def test_invalid_input_is_rejected(self):
        s = svc()
        bad = [dict(group_id=5), dict(group_id=True), dict(group_id=0), dict(group_id="-1"), dict(reporter_id=0),
               dict(reporter_id=True), dict(target_user_id=-1), dict(message_id=0), dict(message_id=True),
               dict(report_type="nonsense"), dict(priority="urgent"), dict(idempotency_key=""), dict(idempotency_key="a b"),
               dict(idempotency_key="x" * 201), dict(reporter_id=2 ** 63)]
        for over in bad:
            kw = dict(group_id=A, reporter_id=USER, target_user_id=OTHER)
            kw.update(over)
            with self.subTest(over=over), self.assertRaises(InvalidInput):
                await s.create(**kw)
        self.assertEqual(await s.count(A), 0)

    async def test_the_current_trace_id_is_kept_and_none_outside_an_update(self):
        s = svc()
        none, _ = await s.create(A, USER, OTHER)
        self.assertIsNone(none.trace_id)
        token = set_trace_id("0123456789abcdef")
        try:
            r, _ = await s.create(A, USER, OTHER, 5)
        finally:
            reset_trace_id(token)
        self.assertEqual(r.trace_id, "0123456789abcdef")

    async def test_the_same_key_stores_once_per_group_only(self):
        s = svc()
        one, c1 = await s.create(A, USER, OTHER, 1, "x", idempotency_key="op:k:1")
        two, c2 = await s.create(A, USER, OTHER, 1, "other text", idempotency_key="op:k:1")
        other_group, c3 = await s.create(B, USER, OTHER, 1, "x", idempotency_key="op:k:1")
        self.assertEqual((c1, c2, c3), (True, False, True))
        self.assertEqual(one.id, two.id)
        self.assertEqual(two.reason, "x")  # the original is returned untouched
        self.assertNotEqual(one.id, other_group.id)
        self.assertEqual(await s.count(A), 1)
        # no key = no dedup
        await s.create(A, USER, OTHER, 1)
        await s.create(A, USER, OTHER, 1)
        self.assertEqual(await s.count(A), 3)


class ListTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = svc()
        self.ids = [(await self.s.create(A, USER, OTHER, i + 1))[0].id for i in range(5)]
        self.other = (await self.s.create(B, USER, OTHER, 1))[0]

    async def test_newest_first_and_isolated_by_group(self):
        rows = await self.s.list_reports(A)
        self.assertEqual([r.id for r in rows], sorted(self.ids, reverse=True))
        self.assertTrue(all(r.group_id == A for r in rows))
        self.assertEqual([r.id for r in await self.s.list_reports(B)], [self.other.id])
        self.assertEqual(await self.s.count(A), 5)
        self.assertEqual(await self.s.count(B), 1)

    async def test_status_filter_paging_and_limit_clamp(self):
        await self.s.take(A, self.ids[0], ADMIN1)
        await self.s.resolve(A, self.ids[1], ADMIN1)
        self.assertEqual({r.id for r in await self.s.list_open(A)}, {self.ids[0], *self.ids[2:]})
        self.assertEqual([r.id for r in await self.s.list_reports(A, [ReportStatus.RESOLVED])], [self.ids[1]])
        self.assertEqual(await self.s.count(A, [ReportStatus.OPEN]), 3)
        self.assertEqual(await self.s.count(A, OPEN_STATUSES), 4)
        page1 = await self.s.list_reports(A, None, 2)
        page2 = await self.s.list_reports(A, None, 2, before_id=page1[-1].id)
        self.assertEqual([r.id for r in page1 + page2], sorted(self.ids, reverse=True)[:4])
        self.assertEqual(len(await self.s.list_reports(A, None, 0)), 1)       # clamped up to 1
        self.assertEqual(len(await self.s.list_reports(A, None, 10_000)), 5)  # clamped down to 50
        for bad in (dict(limit=True), dict(limit="5"), dict(statuses=["x"]), dict(before_id=0)):
            with self.subTest(bad=bad), self.assertRaises(InvalidInput):
                await self.s.list_reports(A, **bad)


class TransitionTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.audit = InMemorySecurityAudit()
        self.t = NOW
        self.s = ReportService(InMemoryReportStore(), self.audit, lambda: self.t)
        self.r = (await self.s.create(A, USER, OTHER, 9, "secret reason text"))[0]

    async def test_take_resolve_flow(self):
        self.t = NOW + timedelta(minutes=5)
        res = await self.s.take(A, self.r.id, ADMIN1)
        self.assertIs(res.code, TransitionCode.OK)
        self.assertEqual((res.report.status, res.report.assigned_to, res.report.updated_at), (ReportStatus.TAKEN, ADMIN1, self.t))
        self.t = NOW + timedelta(minutes=9)
        done = await self.s.resolve(A, self.r.id, ADMIN1)
        self.assertIs(done.code, TransitionCode.OK)
        r = done.report
        self.assertEqual((r.status, r.outcome, r.handled_by, r.handled_at, r.assigned_to),
                         (ReportStatus.RESOLVED, ReportOutcome.ACTION_TAKEN, ADMIN1, self.t, ADMIN1))
        self.assertFalse(r.is_open)

    async def test_resolve_and_dismiss_straight_from_open(self):
        a = await self.s.resolve(A, self.r.id, ADMIN1, ReportOutcome.NO_ACTION)
        self.assertEqual((a.code, a.report.outcome, a.report.assigned_to), (TransitionCode.OK, ReportOutcome.NO_ACTION, None))
        r2 = (await self.s.create(A, USER, OTHER, 10))[0]
        d = await self.s.dismiss(A, r2.id, ADMIN2, ReportOutcome.FALSE_REPORT)
        self.assertEqual((d.code, d.report.status, d.report.outcome), (TransitionCode.OK, ReportStatus.DISMISSED, ReportOutcome.FALSE_REPORT))
        self.assertEqual((await self.s.dismiss(A, (await self.s.create(A, USER, OTHER, 11))[0].id, ADMIN1)).report.outcome,
                         ReportOutcome.NO_ACTION)

    async def test_take_conflicts(self):
        await self.s.take(A, self.r.id, ADMIN1)
        self.assertIs((await self.s.take(A, self.r.id, ADMIN1)).code, TransitionCode.UNCHANGED)
        other = await self.s.take(A, self.r.id, ADMIN2)
        self.assertIs(other.code, TransitionCode.ALREADY_TAKEN)
        self.assertEqual(other.report.assigned_to, ADMIN1)  # the holder is not replaced
        self.assertFalse(other.ok)
        await self.s.resolve(A, self.r.id, ADMIN1)
        self.assertIs((await self.s.take(A, self.r.id, ADMIN1)).code, TransitionCode.CLOSED)

    async def test_closed_reports_never_reopen_or_change(self):
        await self.s.dismiss(A, self.r.id, ADMIN1, ReportOutcome.FALSE_REPORT)
        self.assertIs((await self.s.dismiss(A, self.r.id, ADMIN1, ReportOutcome.FALSE_REPORT)).code, TransitionCode.UNCHANGED)
        self.assertIs((await self.s.dismiss(A, self.r.id, ADMIN1, ReportOutcome.NO_ACTION)).code, TransitionCode.CLOSED)
        self.assertIs((await self.s.dismiss(A, self.r.id, ADMIN2, ReportOutcome.FALSE_REPORT)).code, TransitionCode.CLOSED)
        self.assertIs((await self.s.resolve(A, self.r.id, ADMIN1)).code, TransitionCode.CLOSED)
        row = await self.s.get(A, self.r.id)
        self.assertEqual((row.status, row.outcome, row.handled_by), (ReportStatus.DISMISSED, ReportOutcome.FALSE_REPORT, ADMIN1))

    async def test_outcome_must_fit_the_action(self):
        for call, outcome in ((self.s.resolve, ReportOutcome.FALSE_REPORT), (self.s.dismiss, ReportOutcome.ACTION_TAKEN),
                              (self.s.resolve, "bogus")):
            with self.subTest(outcome=outcome), self.assertRaises(InvalidInput):
                await call(A, self.r.id, ADMIN1, outcome)
        self.assertEqual((await self.s.get(A, self.r.id)).status, ReportStatus.OPEN)

    async def test_another_groups_report_is_not_found_and_untouched(self):
        for call in (self.s.take, self.s.resolve, self.s.dismiss):
            self.assertIs((await call(B, self.r.id, ADMIN1)).code, TransitionCode.NOT_FOUND)
        self.assertIsNone(await self.s.get(B, self.r.id))
        self.assertIs((await self.s.take(A, 9999, ADMIN1)).code, TransitionCode.NOT_FOUND)
        self.assertEqual((await self.s.get(A, self.r.id)).status, ReportStatus.OPEN)

    async def test_two_admins_racing_exactly_one_wins(self):
        results = await asyncio.gather(*(self.s.take(A, self.r.id, a) for a in (ADMIN1, ADMIN2)))
        self.assertEqual(sorted(x.code.value for x in results), ["already_taken", "ok"])
        results = await asyncio.gather(self.s.resolve(A, self.r.id, ADMIN1), self.s.dismiss(A, self.r.id, ADMIN2))
        self.assertEqual(sorted(x.code.value for x in results), ["closed", "ok"])

    async def test_invalid_ids_are_rejected(self):
        for args in ((5, 1, 1), (A, 0, 1), (A, 1, 0), (A, True, 1), (A, 1, True)):
            with self.subTest(args=args), self.assertRaises(InvalidInput):
                await self.s.take(*args)

    async def test_audit_has_ids_and_vocabulary_only(self):
        await self.s.take(A, self.r.id, ADMIN1)
        await self.s.take(A, self.r.id, ADMIN1)      # unchanged: no row
        await self.s.take(A, self.r.id, ADMIN2)      # refused: no row
        await self.s.resolve(A, self.r.id, ADMIN1)
        await self.s.resolve(A, self.r.id, ADMIN1)   # unchanged: no row
        kinds = [(e.event_type, e.actor_telegram_id, e.group_id, e.target_id, e.result, e.detail) for e in self.audit.events]
        self.assertEqual(kinds, [
            ("report_taken", ADMIN1, A, str(self.r.id), "applied", "status=taken"),
            ("report_resolved", ADMIN1, A, str(self.r.id), "applied", "status=resolved outcome=action_taken")])
        self.assertNotIn("secret", " ".join(str(e) for e in self.audit.events))

    async def test_a_failing_audit_never_undoes_or_breaks_the_move(self):
        class Broken:
            async def record(self, event):
                raise RuntimeError("audit down")
        s = ReportService(InMemoryReportStore(), Broken(), lambda: NOW)
        r = (await s.create(A, USER, OTHER))[0]
        self.assertIs((await s.take(A, r.id, ADMIN1)).code, TransitionCode.OK)
        self.assertEqual((await s.get(A, r.id)).status, ReportStatus.TAKEN)


# ------------------------------------------------------------------------------------- PostgreSQL store (fake conn)
class RecConn:
    def __init__(self, fetchrow=None, fetch=None, fetchval=None, rows=None):
        self.log: list[tuple[str, str, tuple]] = []
        self._rows = list(rows) if rows is not None else None
        self._fetchrow, self._fetch, self._fetchval = fetchrow, fetch or [], fetchval

    async def fetchrow(self, sql, *args):
        self.log.append(("fetchrow", " ".join(sql.split()), args))
        if self._rows is not None:
            return self._rows.pop(0) if self._rows else None
        return self._fetchrow

    async def fetch(self, sql, *args):
        self.log.append(("fetch", " ".join(sql.split()), args))
        return self._fetch

    async def fetchval(self, sql, *args):
        self.log.append(("fetchval", " ".join(sql.split()), args))
        return self._fetchval


class RecDb:
    def __init__(self, conn):
        self.conn = conn

    @asynccontextmanager
    async def acquire(self):
        yield self.conn


def row(**over):
    base = dict(id=1, group_id=A, reporter_id=USER, target_user_id=OTHER, message_id=9, reason="r", report_type="other",
                priority="normal", status="open", created_at=NOW, updated_at=NOW, assigned_to=None, outcome=None,
                handled_by=None, handled_at=None, trace_id=None, idempotency_key="op:k")
    base.update(over)
    return base


class PostgresStoreTests(unittest.IsolatedAsyncioTestCase):
    async def test_add_inserts_with_group_first_and_conflict_returns_the_existing_row(self):
        conn = RecConn(rows=[row()])
        r, created = await PostgresReportStore(RecDb(conn)).add(A, USER, OTHER, 9, "r", ReportType.SPAM, ReportPriority.HIGH, NOW,
                                                                 "0123456789abcdef", "op:k")
        self.assertTrue(created)
        kind, sql, args = conn.log[0]
        self.assertTrue(sql.startswith("INSERT INTO group_reports"))
        self.assertIn("ON CONFLICT (group_id, idempotency_key) WHERE idempotency_key IS NOT NULL DO NOTHING", sql)
        self.assertEqual(args, (A, USER, OTHER, 9, "r", "spam", "high", NOW, "0123456789abcdef", "op:k"))
        self.assertEqual(r.report_type, ReportType.OTHER)  # as returned by the row
        conn = RecConn(rows=[None, row(id=4)])
        r, created = await PostgresReportStore(RecDb(conn)).add(A, USER, OTHER, 9, "r", ReportType.OTHER, ReportPriority.NORMAL, NOW,
                                                                 None, "op:k")
        self.assertEqual((created, r.id), (False, 4))
        self.assertIn("WHERE group_id = $1 AND idempotency_key = $2", conn.log[1][1])
        self.assertEqual(conn.log[1][2], (A, "op:k"))

    async def test_reads_are_scoped_by_group(self):
        conn = RecConn(fetchrow=row(), fetch=[row(id=2), row(id=1)], fetchval=3)
        store = PostgresReportStore(RecDb(conn))
        self.assertEqual((await store.get(A, 1)).id, 1)
        self.assertEqual([r.id for r in await store.list_reports(A, [ReportStatus.OPEN, ReportStatus.TAKEN], 20, 10)], [2, 1])
        self.assertEqual(await store.count(A, None), 3)
        for _, sql, args in conn.log:
            self.assertIn("WHERE group_id = $1", sql)
            self.assertEqual(args[0], A)
        self.assertEqual(conn.log[1][2], (A, ["open", "taken"], 10, 20))
        self.assertIn("ORDER BY id DESC LIMIT $4", conn.log[1][1])
        self.assertEqual(conn.log[2][2], (A, None))

    async def test_transition_is_one_guarded_update(self):
        conn = RecConn(fetchrow=row(status="taken", assigned_to=ADMIN1))
        r = await PostgresReportStore(RecDb(conn)).transition(A, 1, (ReportStatus.OPEN,), ReportStatus.TAKEN, ADMIN1, NOW)
        self.assertEqual((r.status, r.assigned_to), (ReportStatus.TAKEN, ADMIN1))
        self.assertEqual(len(conn.log), 1)
        _, sql, args = conn.log[0]
        self.assertTrue(sql.startswith("UPDATE group_reports SET"))
        self.assertIn("WHERE group_id = $1 AND id = $2 AND status = ANY($6::text[])", sql)
        self.assertEqual((args[0], args[1], args[-1]), (A, 1, ["open"]))
        conn = RecConn(fetchrow=row(status="resolved", outcome="action_taken", handled_by=ADMIN1, handled_at=NOW))
        r = await PostgresReportStore(RecDb(conn)).transition(A, 1, OPEN_STATUSES, ReportStatus.RESOLVED, ADMIN1, NOW,
                                                              ReportOutcome.ACTION_TAKEN)
        self.assertEqual(r.outcome, ReportOutcome.ACTION_TAKEN)
        self.assertEqual(conn.log[0][2], (A, 1, "resolved", ADMIN1, NOW, ["open", "taken"], "action_taken"))
        self.assertIsNone(await PostgresReportStore(RecDb(RecConn(fetchrow=None))).transition(
            A, 1, (ReportStatus.OPEN,), ReportStatus.TAKEN, ADMIN1, NOW))

    async def test_closing_without_outcome_or_reopening_is_refused_before_any_sql(self):
        conn = RecConn(fetchrow=row())
        store = PostgresReportStore(RecDb(conn))
        with self.assertRaises(InvalidInput):
            await store.transition(A, 1, OPEN_STATUSES, ReportStatus.RESOLVED, ADMIN1, NOW)
        with self.assertRaises(InvalidInput):
            await store.transition(A, 1, (ReportStatus.TAKEN,), ReportStatus.OPEN, ADMIN1, NOW)
        self.assertEqual(conn.log, [])

    async def test_service_over_the_pg_store_maps_a_lost_race_by_reading_the_row(self):
        conn = RecConn(rows=[None, row(status="taken", assigned_to=ADMIN2)])
        res = await ReportService(PostgresReportStore(RecDb(conn)), None, lambda: NOW).take(A, 1, ADMIN1)
        self.assertIs(res.code, TransitionCode.ALREADY_TAKEN)


# ------------------------------------------------------------------------------------- migration + static guards
class MigrationTests(unittest.TestCase):
    sql = SQL.read_text(encoding="utf-8")

    def test_it_is_the_eighth_migration_and_older_ones_are_untouched(self):
        versions = [v for v, _ in discover()]
        self.assertEqual(versions[7], "0008_group_reports")

    def check_list(self, column, enum_cls):
        found = re.search(rf"{column}\s+TEXT[^,]*?IN \(([^)]*)\)", self.sql, re.S)
        self.assertIsNotNone(found, column)
        self.assertEqual(set(re.findall(r"'([a-z_]+)'", found.group(1))), {m.value for m in enum_cls}, column)

    def test_sql_vocabularies_match_python(self):
        self.check_list("report_type", ReportType)
        self.check_list("priority", ReportPriority)
        self.check_list("status", ReportStatus)
        self.check_list("outcome", ReportOutcome)

    def test_required_objects_and_constraints(self):
        for needle in ("CREATE TABLE IF NOT EXISTS group_reports", "REFERENCES telegram_groups (group_id) ON DELETE RESTRICT",
                       "group_reports_state_consistent", "CREATE UNIQUE INDEX IF NOT EXISTS uq_group_reports_idem",
                       "(group_id, idempotency_key) WHERE idempotency_key IS NOT NULL", "reporter_id     BIGINT      NOT NULL",
                       "length(reason) <= 200", "trace_id ~ '^[0-9a-f]{16}$'"):
            self.assertIn(needle, self.sql)

    def test_it_never_touches_audit_tables_triggers_or_drops_anything(self):
        body = self.sql.replace("ON DELETE RESTRICT", "")  # the foreign key's own clause is the only DELETE allowed
        for forbidden in ("DROP ", "TRIGGER", "DELETE ", "TRUNCATE", "security_audit_log", "license_audit_log", "UPDATE "):
            self.assertNotIn(forbidden, body)
        self.assertEqual(len(re.findall(r"CREATE TABLE", self.sql)), 1)

    def test_older_migrations_are_not_edited(self):
        import hashlib
        digest = hashlib.sha256((SQL.parent / "0001_initial.sql").read_bytes()).hexdigest()
        self.assertEqual(digest, "72b784563aecb473e545c6dbef156574981583396a2c0b9f271569710d266d81")

    def test_the_reports_package_imports_no_framework(self):
        for path in (ROOT / "src" / "guardian" / "reports").glob("*.py"):
            text = path.read_text(encoding="utf-8")
            for forbidden in ("aiogram", "asyncpg", "fastapi"):
                self.assertNotIn(f"import {forbidden}", text, path.name)
                self.assertNotIn(f"from {forbidden}", text, path.name)


# ------------------------------------------------------------------------------------- `/report` hook
class ReportCommandStoresTests(ExecBase):
    async def asyncSetUp(self):
        self.reports_store = InMemoryReportStore()
        await super().asyncSetUp()
        self.s.chat.admins[A] = [adm(TG_CREATOR, "Boss", creator=True), adm(TG_ADMIN, "Alice", title="mod"),
                                 adm(BOT, "GuardianBot", bot=True)]

    def make_service(self, claims):
        self.reports = ReportService(self.reports_store, self.s.audit, self.s.clock)
        return ModerationCommandService(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions,
            settings_store=self.s.settings_store, actions=self.actions, chat_info=self.s.chat, claims=claims,
            audit=self.s.audit, bot_id=BOT, clock=self.s.clock, group_settings=self.s.settings, reports=self.reports)

    async def report(self, text="/report", *, actor=USER, reply_to=OTHER, msg=10, chat=A, reply_mid=77, svc=None):
        parsed = parse_command(text, BOT_NAME, has_reply=reply_to is not None)
        reply = ReplyInfo(reply_to, message_id=reply_mid) if reply_to is not None else None
        return await (svc or self.svc).handle(parsed, chat_id=chat, actor_id=actor, message_id=msg,
                                              protection=gate(chat, actor), reply=reply)

    async def test_a_report_is_stored_and_the_notice_is_unchanged(self):
        r = await self.report("/report spam <b>links</b>")
        self.assertIs(r.kind, R.DONE)
        self.assertIn(f'<a href="tg://user?id={TG_ADMIN}">', r.text)
        self.assertIn("https://t.me/c/1/77", r.text)
        stored = await self.reports.list_reports(A)
        self.assertEqual(len(stored), 1)
        rep = stored[0]
        self.assertEqual((rep.group_id, rep.reporter_id, rep.target_user_id, rep.message_id, rep.status),
                         (A, USER, OTHER, 77, ReportStatus.OPEN))
        self.assertEqual(rep.reason, "spam <b>links</b>")  # stored raw; the NOTICE escapes it
        self.assertEqual((rep.report_type, rep.priority), (ReportType.OTHER, ReportPriority.NORMAL))
        self.assertEqual(rep.created_at, self.s.clock())
        self.assertEqual(self.actions.calls, [])

    async def test_no_reason_means_none(self):
        await self.report("/report")
        self.assertIsNone((await self.reports.list_reports(A))[0].reason)

    async def test_the_audit_row_carries_the_report_id_but_never_the_reason(self):
        await self.report("/report my secret reason")
        ev = [e for e in self.s.audit.events if e.event_type == "report_filed"]
        self.assertEqual(len(ev), 1)
        rid = (await self.reports.list_reports(A))[0].id
        self.assertEqual(ev[0].target_id, str(rid))
        self.assertIn(f"report={rid}", ev[0].detail)
        self.assertIn(f"target={OTHER}", ev[0].detail)
        self.assertNotIn("secret", ev[0].detail)

    async def test_a_redelivered_command_stores_one_report(self):
        await self.report(msg=10)
        self.s.clock.advance(minutes=5)  # past the per-reporter cooldown, so the claim is what stops the repeat
        again = await self.report(msg=10)
        self.assertIs(again.kind, R.DUPLICATE)
        self.assertEqual(await self.reports.count(A), 1)

    async def test_the_store_key_is_idempotent_even_when_the_claim_is_lost(self):
        """Defence in depth: a fresh claim store (e.g. after the 7-day purge) still cannot duplicate the row."""
        await self.report(msg=10)
        from guardian.idempotency import InMemoryIdempotency
        fresh = self.make_service(InMemoryIdempotency())
        self.s.clock.advance(minutes=5)  # past the per-reporter cooldown
        await self.report(msg=10, svc=fresh)
        self.assertEqual(await self.reports.count(A), 1)

    async def test_invalid_or_refused_reports_store_nothing(self):
        await self.report(reply_to=None)                    # no reply
        await self.report(reply_to=USER)                    # self
        await self.report(reply_to=TG_ADMIN)                # admin
        await self.report(reply_to=BOT)                     # bot
        r = await self.report(chat=-777)                    # unlicensed chat: parser/gate answer nothing
        self.assertEqual(await self.reports.count(A), 0)
        self.assertEqual(await self.reports.count(-777), 0)
        self.assertIsNot(r.kind, R.DONE)

    async def test_no_admins_to_notify_stores_nothing(self):
        self.s.chat.admins[A] = [adm(BOT, "GuardianBot", bot=True)]
        r = await self.report()
        self.assertIs(r.kind, R.ERROR)
        self.assertEqual(await self.reports.count(A), 0)

    async def test_a_store_failure_never_changes_what_the_group_sees(self):
        class Down:
            async def add(self, *a, **k):
                raise RuntimeError("db down")
        self.reports._store = Down()
        r = await self.report()
        self.assertIs(r.kind, R.DONE)
        self.assertIn(f'<a href="tg://user?id={TG_ADMIN}">', r.text)
        ev = [e for e in self.s.audit.events if e.event_type == "report_filed"]
        self.assertEqual(len(ev), 1)
        self.assertIsNone(ev[0].target_id)
        self.assertNotIn("report=", ev[0].detail)

    async def test_without_a_report_service_the_command_behaves_as_before(self):
        plain = ModerationCommandService(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions,
            settings_store=self.s.settings_store, actions=self.actions, chat_info=self.s.chat, claims=self.claims,
            audit=self.s.audit, bot_id=BOT, clock=self.s.clock, group_settings=self.s.settings)
        r = await self.report(svc=plain)
        self.assertIs(r.kind, R.DONE)
        self.assertEqual(await self.reports.count(A), 0)

    async def test_reports_of_two_groups_never_mix(self):
        self.s.chat.admins[B] = [adm(TG_CREATOR, "Boss", creator=True), adm(TG_ADMIN, "Alice")]
        await self.report(chat=A)
        await self.report(chat=B, msg=11)
        self.assertEqual([r.group_id for r in await self.reports.list_reports(A)], [A])
        self.assertEqual([r.group_id for r in await self.reports.list_reports(B)], [B])


if __name__ == "__main__":
    unittest.main()
