"""Phase 4.1: typed welcome / verification / new-member settings (defaults, clamping, templates, key hygiene)."""
import unittest
from dataclasses import fields

from guardian.groups.service import MAX_STRING_VALUE, validate_settings_patch
from guardian.members.settings import (
    NEWBIE_WINDOW, TEMPLATE_MAX_CHARS, VERIFY_ATTEMPTS, VERIFY_BAN, VERIFY_TIMEOUT, WELCOME_DELETE_AFTER,
    WELCOME_VARIABLES, NewMemberPolicy, VerificationSettings, WelcomeSettings, render_template, template_ok,
)
from guardian.protection.settings import ProtectionSettings


class DefaultsTests(unittest.TestCase):
    def test_everything_is_off_by_default(self):
        for raw in (None, {}, [], "x", 5):
            w, v, n = WelcomeSettings.from_raw(raw), VerificationSettings.from_raw(raw), NewMemberPolicy.from_raw(raw)
            self.assertFalse(w.welcome_enabled)
            self.assertFalse(v.verify_enabled)
            self.assertFalse(n.active)
            self.assertEqual((w.join_service, w.leave_service), ("keep", "keep"))
            self.assertEqual((v.verify_failure, v.verify_scope, v.verify_method), ("restrict", "all", "button"))

    def test_valid_values_are_kept(self):
        v = VerificationSettings.from_raw({
            "verify_enabled": True, "verify_scope": "suspicious", "verify_method": "math", "verify_timeout_seconds": 120,
            "verify_failure": "ban", "verify_ban_seconds": 7200, "verify_max_attempts": 5})
        self.assertEqual((v.verify_enabled, v.verify_scope, v.verify_method, v.verify_timeout_seconds,
                          v.verify_failure, v.verify_ban_seconds, v.verify_max_attempts),
                         (True, "suspicious", "math", 120, "ban", 7200, 5))
        w = WelcomeSettings.from_raw({"welcome_enabled": True, "welcome_text": "hi {name}", "join_service": "delete",
                                      "leave_service": "delete", "welcome_delete_after_seconds": 60,
                                      "welcome_delete_previous": False})
        self.assertEqual((w.welcome_enabled, w.welcome_text, w.join_service, w.leave_service,
                          w.welcome_delete_after_seconds, w.welcome_delete_previous),
                         (True, "hi {name}", "delete", "delete", 60, False))


class ClampingTests(unittest.TestCase):
    def test_bounds_are_inclusive_and_out_of_range_falls_back(self):
        for key, (lo, hi), default in (("verify_timeout_seconds", VERIFY_TIMEOUT, 300), ("verify_max_attempts", VERIFY_ATTEMPTS, 3),
                                       ("verify_ban_seconds", VERIFY_BAN, 3600)):
            for ok in (lo, hi):
                self.assertEqual(getattr(VerificationSettings.from_raw({key: ok}), key), ok)
            for bad in (lo - 1, hi + 1, 0, -5):
                self.assertEqual(getattr(VerificationSettings.from_raw({key: bad}), key), default)
        for key, bounds, cls in (("welcome_delete_after_seconds", WELCOME_DELETE_AFTER, WelcomeSettings),
                                 ("newbie_seconds", NEWBIE_WINDOW, NewMemberPolicy)):
            self.assertEqual(getattr(cls.from_raw({key: 0}), key), 0)
            for ok in bounds:
                self.assertEqual(getattr(cls.from_raw({key: ok}), key), ok)
            for bad in (bounds[0] - 1, bounds[1] + 1, -1):
                self.assertEqual(getattr(cls.from_raw({key: bad}), key), 0)  # unknown => off, never "on with a guess"

    def test_wrong_types_never_leak(self):
        v = VerificationSettings.from_raw({
            "verify_enabled": "yes", "verify_timeout_seconds": True, "verify_max_attempts": "3", "verify_scope": ["all"],
            "verify_method": "captcha_image", "verify_failure": "delete_account", "verify_ban_seconds": 3600.0})
        self.assertEqual(v, VerificationSettings())
        n = NewMemberPolicy.from_raw({"newbie_seconds": True, "newbie_block_links": 1})
        self.assertEqual(n, NewMemberPolicy())
        self.assertEqual(WelcomeSettings.from_raw({"join_service": "remove", "welcome_enabled": 1}), WelcomeSettings())

    def test_policy_active_needs_window_and_a_rule(self):
        self.assertTrue(NewMemberPolicy.from_raw({"newbie_seconds": 600}).active)  # defaults block links+media
        self.assertFalse(NewMemberPolicy.from_raw({"newbie_seconds": 600, "newbie_block_links": False,
                                                   "newbie_block_media": False}).active)
        self.assertFalse(NewMemberPolicy.from_raw({"newbie_block_messages": True}).active)  # no window
        self.assertTrue(NewMemberPolicy.from_raw({"newbie_seconds": 600, "newbie_block_messages": True}).active)


class TemplateTests(unittest.TestCase):
    def test_valid_templates(self):
        for t in ("أهلاً {name}", "{name} في {group} ({id})", "no variables", "literal {{braces}} and {name}"):
            self.assertTrue(template_ok(t), t)

    def test_rejected_templates(self):
        for t in ("{name.__class__}", "{name[0]}", "{id:>10}", "{name!r}", "{unknown}", "{}", "{0}", "{", "}", "{name",
                  "", "   ", "a\x00b", "x" * (TEMPLATE_MAX_CHARS + 1), None, 5, ["{name}"]):
            self.assertFalse(template_ok(t), repr(t))

    def test_limit_is_inclusive(self):
        self.assertTrue(template_ok("x" * TEMPLATE_MAX_CHARS))

    def test_invalid_stored_template_falls_back_to_default(self):
        self.assertIsNone(WelcomeSettings.from_raw({"welcome_text": "{name.__class__}"}).welcome_text)
        self.assertIsNone(WelcomeSettings.from_raw({"welcome_text": 5}).welcome_text)

    def test_render_substitutes_only_documented_variables(self):
        self.assertEqual(render_template("hi {name} @ {group} #{id} {{ok}}", name="Ali", group="G", user_id=7),
                         "hi Ali @ G #7 {ok}")
        self.assertEqual(WELCOME_VARIABLES, ("name", "group", "id"))

    def test_hostile_values_are_inserted_verbatim_not_reinterpreted(self):
        out = render_template("{name}|{group}", name="{id}", group="{name}", user_id=1)
        self.assertEqual(out, "{id}|{name}")


class KeyHygieneTests(unittest.TestCase):
    def test_no_key_collides_with_protection_settings_or_between_groups(self):
        prot = {f.name for f in fields(ProtectionSettings)}
        mine = [{f.name for f in fields(c)} for c in (WelcomeSettings, VerificationSettings, NewMemberPolicy)]
        for i, a in enumerate(mine):
            self.assertFalse(a & prot)
            for b in mine[i + 1:]:
                self.assertFalse(a & b)

    def test_a_full_patch_fits_the_settings_validator(self):
        patch = {"welcome_enabled": True, "welcome_text": "x" * TEMPLATE_MAX_CHARS, "welcome_delete_previous": True,
                 "welcome_delete_after_seconds": 60, "join_service": "delete", "leave_service": "delete",
                 "verify_enabled": True, "verify_scope": "suspicious", "verify_method": "choice",
                 "verify_timeout_seconds": 300, "verify_failure": "ban", "verify_ban_seconds": 3600,
                 "verify_max_attempts": 3, "newbie_seconds": 3600, "newbie_block_links": True,
                 "newbie_block_media": True, "newbie_block_messages": False}
        self.assertEqual(validate_settings_patch(patch), patch)
        self.assertLess(TEMPLATE_MAX_CHARS, MAX_STRING_VALUE)

    def test_parsers_ignore_each_others_and_protection_keys(self):
        raw = {"links_enabled": False, "flood_enabled": False, "welcome_enabled": True}
        self.assertFalse(VerificationSettings.from_raw(raw).verify_enabled)
        self.assertTrue(WelcomeSettings.from_raw(raw).welcome_enabled)
        self.assertTrue(ProtectionSettings.from_raw({"welcome_enabled": True, "verify_enabled": True}).links_enabled)


if __name__ == "__main__":
    unittest.main()
