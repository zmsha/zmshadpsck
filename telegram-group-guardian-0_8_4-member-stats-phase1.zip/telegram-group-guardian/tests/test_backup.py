"""Phase 6.8a: the backup FORMAT and COLLECTOR (no command, no sending, no restore)."""
from __future__ import annotations

import asyncio
import hashlib
import json
import re
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from backup_helpers import FIXED_NOW, FakeReader, sample_rows

from guardian import __version__
from guardian.backup import format as F
from guardian.backup.collector import BackupCollector, schema_state
from guardian.backup.postgres_reader import PostgresBackupReader, page_sql
from guardian.db.migrations import SQL_DIR, discover
from guardian.errors import StoreUnavailable
from guardian.owner_hub.redactor import screen_file

SRC = Path(__file__).resolve().parents[1] / "src" / "guardian"
SECRETS = ("123456789:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "unit-test-webhook-secret-123456", "s3cretPW",
           "postgresql://dbuser:s3cretPW@db.example.com:5432/guardian?sslmode=require")


def collector(reader=None, **kw):
    kw.setdefault("app_version", __version__)
    kw.setdefault("clock", lambda: FIXED_NOW)
    kw.setdefault("secrets", SECRETS)
    return BackupCollector(reader or FakeReader(), **kw)


def run(coro):
    return asyncio.run(coro)


# ------------------------------------------------------------------------------------------------ SQL parsing for the guards
def _strip_comments(sql: str) -> str:
    return "\n".join(line.split("--", 1)[0] for line in sql.splitlines())


def _split_top(body: str) -> list[str]:
    parts, depth, cur = [], 0, []
    for ch in body:
        depth += ch == "("
        depth -= ch == ")"
        if ch == "," and depth == 0:
            parts.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    parts.append("".join(cur))
    return [p.strip() for p in parts if p.strip()]


def schema_from_migrations() -> dict[str, dict[str, str]]:
    """{table: {column: SQL type word}} from every CREATE TABLE and ALTER TABLE ... ADD COLUMN in the migration files."""
    tables: dict[str, dict[str, str]] = {}
    for _, path in discover(SQL_DIR):
        sql = _strip_comments(path.read_text(encoding="utf-8"))
        for m in re.finditer(r"CREATE TABLE IF NOT EXISTS (\w+)\s*\(", sql):
            depth, i = 1, m.end()
            while depth:
                depth += {"(": 1, ")": -1}.get(sql[i], 0)
                i += 1
            cols: dict[str, str] = {}
            for part in _split_top(sql[m.end():i - 1]):
                words = part.split()
                if words[0].upper() in {"CONSTRAINT", "PRIMARY", "UNIQUE", "CHECK", "FOREIGN"}:
                    continue
                cols[words[0]] = words[1].upper()
            tables[m.group(1)] = cols
        for m in re.finditer(r"ALTER TABLE (\w+)(.*?);", sql, re.DOTALL):
            for c in re.finditer(r"ADD COLUMN (?:IF NOT EXISTS )?(\w+) (\w+)", m.group(2)):
                tables[m.group(1)][c.group(1)] = c.group(2).upper()
    return tables


KIND_OF = {"BIGINT": F.INT, "BIGSERIAL": F.INT, "INTEGER": F.INT, "TEXT": F.TEXT, "BOOLEAN": F.BOOL,
           "TIMESTAMPTZ": F.TS, "JSONB": F.JSON}


class RegistryTests(unittest.TestCase):
    def test_every_migration_table_is_backed_up_or_excluded_on_purpose(self):
        created = set(schema_from_migrations())
        listed = set(F.TABLE_NAMES) | set(F.EXCLUDED_TABLES) | set(F.NOT_DATA_TABLES) - {"schema_migrations"}
        self.assertEqual(created, listed - set(F.NOT_DATA_TABLES))
        self.assertFalse(set(F.TABLE_NAMES) & set(F.EXCLUDED_TABLES))
        for name, why in F.EXCLUDED_TABLES.items():
            self.assertTrue(why.strip(), name)

    def test_columns_and_kinds_match_the_migrations_exactly(self):
        schema = schema_from_migrations()
        for spec in F.TABLES:
            with self.subTest(table=spec.name):
                actual = {c: KIND_OF[t] for c, t in schema[spec.name].items()}
                self.assertEqual({c.name: c.kind for c in spec.columns}, actual)

    def test_the_key_is_the_primary_key_in_the_sql(self):
        for spec in F.TABLES:
            sql = "".join(_strip_comments(p.read_text(encoding="utf-8")) for _, p in discover(SQL_DIR))
            block = sql[sql.index(f"CREATE TABLE IF NOT EXISTS {spec.name} "):]
            block = block[block.index("("):block.index(");")]
            single = re.search(r"(\w+)\s+\w+[^,]*PRIMARY KEY", block)
            composite = re.search(r"PRIMARY KEY \(([^)]*)\)", block)
            keys = tuple(k.strip() for k in composite.group(1).split(",")) if composite else (single.group(1),)
            self.assertEqual(spec.key, keys, spec.name)

    def test_no_column_looks_like_a_secret(self):
        words = ("token", "secret", "password", "passwd", "passphrase", "api_key", "private_key", "dsn", "credential")
        for spec in F.TABLES:
            for name in spec.column_names:
                self.assertFalse(any(w in name for w in words), (spec.name, name))

    def test_the_tables_the_plan_promises_are_there(self):
        for needed in ("telegram_groups", "license_audit_log", "group_settings", "group_delegations", "group_trusted_users",
                       "group_trusted_bots", "moderation_warnings", "moderation_sanctions", "group_reports",
                       "settings_templates", "global_default_settings"):
            self.assertIn(needed, F.TABLE_NAMES)
        for left_out in ("idempotency_keys", "member_verifications", "security_audit_log"):
            self.assertNotIn(left_out, F.TABLE_NAMES)
            self.assertIn(left_out, F.EXCLUDED_TABLES)

    def test_parents_come_before_children(self):
        self.assertEqual(F.TABLE_NAMES[0], "telegram_groups")

    def test_bad_specs_are_refused(self):
        for bad in (lambda: F.Column("Bad Name", F.INT), lambda: F.Column("x", "float"),
                    lambda: F.TableSpec("t", (F.Column("a", F.INT),), ("b",)),
                    lambda: F.TableSpec("t", (F.Column("a", F.INT), F.Column("a", F.INT)), ("a",)),
                    lambda: F.TableSpec("t; DROP", (F.Column("a", F.INT),), ("a",))):
            with self.assertRaises(ValueError):
                bad()

    def test_schema_state_is_the_newest_migration(self):
        self.assertEqual(schema_state(), (13, "0013_member_activity_stats"))


class ValueTests(unittest.TestCase):
    def test_strict_encoding(self):
        self.assertEqual(F.encode_value(F.INT, 5), 5)
        self.assertEqual(F.encode_value(F.INT, None), None)
        for kind, bad in ((F.INT, True), (F.INT, "5"), (F.INT, 1.5), (F.BOOL, 1), (F.TEXT, 5), (F.TS, "2026-01-01"),
                          (F.TS, datetime(2026, 1, 1)), (F.JSON, {"a": float("nan")}), (F.JSON, {"a": object()})):
            with self.assertRaises(ValueError, msg=(kind, bad)):
                F.encode_value(kind, bad)

    def test_timestamps_are_utc_with_microseconds_and_round_trip(self):
        riyadh = timezone(timedelta(hours=3))
        t = datetime(2026, 11, 1, 15, 0, 0, 123456, tzinfo=riyadh)
        text = F.encode_timestamp(t)
        self.assertEqual(text, "2026-11-01T12:00:00.123456Z")
        self.assertEqual(F.decode_timestamp(text), t)
        self.assertEqual(F.decode_value(F.TS, text), t)
        for bad in ("2026-11-01", "2026-11-01T12:00:00Z", "2026-11-01 12:00:00.000000Z", 5, None):
            with self.assertRaises(ValueError):
                F.decode_timestamp(bad)

    def test_encode_row_keeps_exactly_the_spec_columns(self):
        spec = F.BY_NAME["group_trusted_users"]
        row = {"group_id": -1, "user_id": 2, "added_by": 3, "added_at": FIXED_NOW, "note": None, "extra_secret": "x"}
        out = F.encode_row(spec, row)
        self.assertEqual(list(out), list(spec.column_names))
        del row["note"]
        with self.assertRaises(F.BackupError) as cm:
            F.encode_row(spec, row)
        self.assertEqual(cm.exception.code, "bad_value")
        self.assertIn("group_trusted_users.note", str(cm.exception))

    def test_bad_value_error_never_carries_the_value(self):
        spec = F.BY_NAME["group_trusted_users"]
        with self.assertRaises(F.BackupError) as cm:
            F.encode_row(spec, {"group_id": "TOP-SECRET-VALUE", "user_id": 1, "added_by": 1, "added_at": FIXED_NOW, "note": None})
        self.assertNotIn("TOP-SECRET", str(cm.exception))

    def test_error_codes_are_a_closed_set(self):
        with self.assertRaises(ValueError):
            F.BackupError("whatever")
        with self.assertRaises(ValueError):
            F.BackupFormatError("whatever")


class CollectorTests(unittest.TestCase):
    def test_a_full_backup_round_trips_and_verifies(self):
        result = run(collector().collect())
        doc = F.parse_document(result.data)
        manifest = F.verify_integrity(doc)
        self.assertEqual(manifest, result.manifest)
        self.assertEqual(set(doc["tables"]), set(F.TABLE_NAMES))
        expected = sample_rows()
        for spec in F.TABLES:
            rows = doc["tables"][spec.name]
            self.assertEqual(len(rows), len(expected[spec.name]), spec.name)
            self.assertEqual(manifest["tables"][spec.name]["rows"], len(rows))
            text = json.dumps(rows, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            self.assertEqual(manifest["tables"][spec.name]["sha256"], hashlib.sha256(text.encode()).hexdigest())
        self.assertEqual(manifest["total_rows"], sum(len(v) for v in expected.values()))
        self.assertEqual(result.total_rows, manifest["total_rows"])
        self.assertEqual(result.size, len(result.data))

    def test_the_manifest_carries_versions_time_and_the_exclusions(self):
        m = run(collector().collect()).manifest
        self.assertEqual((m["format"], m["format_version"]), ("guardian-backup", 1))
        self.assertEqual((m["schema_version"], m["schema_name"]), (13, "0013_member_activity_stats"))
        self.assertEqual(m["app_version"], __version__)
        self.assertEqual(m["created_at"], "2026-11-01T12:00:00Z")
        self.assertEqual(m["excluded"], sorted(F.EXCLUDED_TABLES))

    def test_the_name_is_ascii_json_and_dated(self):
        self.assertEqual(run(collector().collect()).name, "guardian-backup-20261101-120000-utc.json")

    def test_the_same_data_gives_the_same_bytes(self):
        self.assertEqual(run(collector().collect()).data, run(collector().collect()).data)

    def test_the_file_is_canonical_text(self):
        data = run(collector().collect()).data
        self.assertEqual(data.decode("utf-8"), F.canonical(json.loads(data)))

    def test_an_empty_database_still_lists_every_table(self):
        result = run(collector(FakeReader({})).collect())
        manifest = F.verify_integrity(F.parse_document(result.data))
        self.assertEqual(manifest["total_rows"], 0)
        self.assertEqual(set(manifest["tables"]), set(F.TABLE_NAMES))

    def test_arabic_text_is_kept_as_utf8_not_escaped(self):
        data = run(collector().collect()).data
        self.assertIn("مجموعة الاختبار".encode("utf-8"), data)
        self.assertNotIn(b"\\u", data)

    def test_timestamps_and_json_come_out_in_their_canonical_forms(self):
        doc = F.parse_document(run(collector().collect()).data)
        first = next(r for r in doc["tables"]["telegram_groups"] if r["group_id"] == -1001)
        self.assertEqual(first["activated_at"], "2026-11-01T09:30:15.000000Z")
        self.assertIsNone(first["status_note"])
        settings = next(r for r in doc["tables"]["group_settings"] if r["group_id"] == -1001)["settings"]
        self.assertEqual(settings["links"], {"mode": "delete"})
        self.assertEqual(settings["نص"], "قيمة")
        self.assertIs(doc["tables"]["global_default_settings"][0]["singleton"], True)

    def test_columns_outside_the_registry_never_reach_the_file(self):
        data = sample_rows()
        data["group_trusted_users"][0]["answer"] = "SECRET-ANSWER"
        data["member_verifications"] = [{"group_id": -1, "answer": "42"}]
        raw = run(collector(FakeReader(data)).collect()).data
        self.assertNotIn(b"SECRET-ANSWER", raw)
        self.assertNotIn(b"member_verifications", F.canonical(json.loads(raw)["tables"]).encode())

    def test_reading_is_paged_by_the_key_and_every_row_is_read_once(self):
        data = sample_rows()
        data["group_trusted_users"] += [dict(group_id=-1001, user_id=u, added_by=1, added_at=FIXED_NOW, note=None) for u in (1, 2, 3)]
        reader = FakeReader(data)
        result = run(collector(reader, page_size=2).collect())
        rows = F.parse_document(result.data)["tables"]["group_trusted_users"]
        self.assertEqual(len(rows), 6)
        calls = [c for c in reader.log if c[0] == "group_trusted_users"]
        self.assertEqual(calls[0][1], None)
        self.assertTrue(all(c[2] == 2 for c in calls))
        afters = [c[1] for c in calls[1:]]
        self.assertEqual(afters, sorted(afters))
        self.assertEqual(len(set(afters)), len(afters))
        self.assertEqual(reader.opened, 1)  # ONE snapshot for the whole backup

    def test_an_exact_page_multiple_terminates(self):
        data = {"group_trusted_bots": [dict(group_id=-1, bot_id=b, added_by=1, added_at=FIXED_NOW, note=None) for b in (1, 2, 3, 4)]}
        result = run(collector(FakeReader(data), page_size=2).collect())
        self.assertEqual(result.manifest["tables"]["group_trusted_bots"]["rows"], 4)

    def test_a_reader_that_does_not_advance_is_stopped(self):
        data = {"group_trusted_bots": [dict(group_id=-1, bot_id=b, added_by=1, added_at=FIXED_NOW, note=None) for b in (1, 2, 3)]}
        with self.assertRaises(F.BackupError) as cm:
            run(collector(FakeReader(data, stuck=True), page_size=2).collect())
        self.assertEqual(cm.exception.code, "read_failed")

    def test_a_reader_returning_more_rows_than_asked_is_refused(self):
        from contextlib import asynccontextmanager

        class Ignoring:
            async def read_page(self, spec, after, limit):
                return [dict(group_id=-1, bot_id=b, added_by=1, added_at=FIXED_NOW, note=None) for b in range(limit + 1)]

        class R:
            @asynccontextmanager
            async def snapshot(self):
                yield Ignoring()

        with self.assertRaises(F.BackupError) as cm:
            run(collector(R()).collect())
        self.assertEqual(cm.exception.code, "read_failed")


class SizeCapTests(unittest.TestCase):
    def test_the_cap_is_ten_megabytes(self):
        self.assertEqual(F.MAX_BACKUP_BYTES, 10 * 1024 * 1024)

    def test_exactly_at_the_cap_passes_one_byte_less_is_refused_never_truncated(self):
        size = run(collector().collect()).size
        self.assertEqual(run(collector(max_bytes=size).collect()).size, size)
        with self.assertRaises(F.BackupError) as cm:
            run(collector(max_bytes=size - 1).collect())
        self.assertEqual(cm.exception.code, "too_large")

    def test_reading_stops_as_soon_as_the_data_cannot_fit(self):
        reader = FakeReader()
        with self.assertRaises(F.BackupError) as cm:
            run(collector(reader, max_bytes=200).collect())
        self.assertEqual(cm.exception.code, "too_large")
        self.assertLess(len({c[0] for c in reader.log}), len(F.TABLES))  # later tables were never read

    def test_a_large_database_is_refused_not_cut(self):
        data = sample_rows()
        data["group_reports"] = [dict(data["group_reports"][0], id=i, idempotency_key=f"k{i}", reason="x" * 190) for i in range(1, 400)]
        with self.assertRaises(F.BackupError) as cm:
            run(collector(FakeReader(data), max_bytes=50_000).collect())
        self.assertEqual(cm.exception.code, "too_large")


class SecretTests(unittest.TestCase):
    def leak(self, text, table="moderation_warnings", column="reason", secrets=SECRETS):
        data = sample_rows()
        data[table][0][column] = text
        return run(collector(FakeReader(data), secrets=secrets).collect())

    def assertRefused(self, text, **kw):
        with self.assertRaises(F.BackupError) as cm:
            self.leak(text, **kw)
        self.assertEqual(cm.exception.code, "secret_found")
        self.assertIn("moderation_warnings", str(cm.exception))
        self.assertNotIn(text, str(cm.exception))
        for secret in SECRETS:
            self.assertNotIn(secret, str(cm.exception))

    def test_each_configured_secret_is_refused(self):
        for secret in SECRETS:
            with self.subTest(secret=secret[:6]):
                self.assertRefused(f"see {secret} here")

    def test_url_quoted_and_json_escaped_forms_are_refused_too(self):
        from urllib.parse import quote
        self.assertRefused(quote("p@ss/word\"x", safe=""), secrets=("p@ss/word\"x",))
        self.assertRefused("a p@ss\"word\\x b", secrets=("p@ss\"word\\x",))

    def test_a_private_key_a_bot_token_and_a_url_password_are_refused_even_if_unconfigured(self):
        self.assertRefused("-----BEGIN PRIVATE KEY-----\nabc")
        self.assertRefused("987654321:BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB", secrets=())
        self.assertRefused("postgres://user:hunter2@host/db", secrets=())

    def test_the_secret_check_covers_every_table_not_just_one(self):
        for table, column in (("telegram_groups", "title"), ("group_reports", "reason"), ("license_audit_log", "reason"),
                              ("group_trusted_users", "note"), ("settings_templates", "name")):
            with self.subTest(table=table):
                with self.assertRaises(F.BackupError) as cm:
                    self.leak(f"x {SECRETS[0]} y", table=table, column=column)
                self.assertEqual(cm.exception.code, "secret_found")
                self.assertIn(table, str(cm.exception))

    def test_a_secret_inside_json_settings_is_refused(self):
        data = sample_rows()
        data["group_settings"][0]["settings"] = {"deep": {"list": ["a", SECRETS[1]]}}
        with self.assertRaises(F.BackupError) as cm:
            run(collector(FakeReader(data)).collect())
        self.assertEqual(cm.exception.code, "secret_found")

    def test_short_secrets_are_ignored_not_matched_everywhere(self):
        self.leak("abc is fine", secrets=("abc", "", "xyz"))  # < 4 characters: not treated as a secret

    def test_ordinary_data_is_not_flagged(self):
        result = run(collector().collect())
        self.assertEqual(result.screen_flags, ())

    def test_heuristic_hits_are_reported_but_do_not_block(self):
        random_looking = "A1b2C3d4E5f6G7h8I9j0K1l2M3n4O5p6Q7r8S9t0U1v2"  # 40+ letters and digits: the long-key heuristic
        result = self.leak(f"ref {random_looking} end", column="reason")
        self.assertEqual(result.screen_flags, ("moderation_warnings",))
        self.assertIn(random_looking.encode(), result.data)  # the owner's own data is not rewritten

    def test_the_generic_file_screen_would_break_the_checksums(self):
        """FINDING for 6.8b: `screen_file` masks 64-hex strings, i.e. the manifest's SHA-256 values, and caps files at 1MB.
        A backup must therefore NOT be sent through its redaction (the file would no longer verify); 6.8b needs a
        verify-only check (exact secrets / PEM / dotenv shape -> refuse) with the 10MB cap."""
        result = run(collector().collect())
        verdict = screen_file(result.name, result.data, SECRETS)
        self.assertGreater(verdict.redactions, 0)
        self.assertNotEqual(verdict.data, result.data)
        with self.assertRaises(F.BackupFormatError) as cm:
            F.verify_integrity(F.parse_document(verdict.data))
        self.assertEqual(cm.exception.code, "checksum_mismatch")
        # the ROWS themselves are not touched by it (only the checksums are): that is what `screen_flags` reports on
        self.assertEqual(result.screen_flags, ())


class FailureTests(unittest.TestCase):
    def test_a_driver_error_becomes_read_failed_with_only_the_type_name(self):
        with self.assertRaises(F.BackupError) as cm:
            run(collector(FakeReader(boom=RuntimeError("could not connect to postgres://u:pw@h/db"))).collect())
        self.assertEqual(cm.exception.code, "read_failed")
        self.assertIn("RuntimeError", str(cm.exception))
        self.assertNotIn("postgres://", str(cm.exception))
        self.assertIsNone(cm.exception.__cause__)

    def test_an_unavailable_store_is_its_own_code(self):
        with self.assertRaises(F.BackupError) as cm:
            run(collector(FakeReader(boom=StoreUnavailable("down"))).collect())
        self.assertEqual(cm.exception.code, "unavailable")

    def test_cancellation_is_not_swallowed(self):
        with self.assertRaises(asyncio.CancelledError):
            run(collector(FakeReader(boom=asyncio.CancelledError())).collect())

    def test_a_wrongly_typed_value_names_the_column_only(self):
        data = sample_rows()
        data["group_settings"][0]["updated_by"] = "TOP-SECRET"
        with self.assertRaises(F.BackupError) as cm:
            run(collector(FakeReader(data)).collect())
        self.assertEqual(cm.exception.code, "bad_value")
        self.assertIn("group_settings.updated_by", str(cm.exception))
        self.assertNotIn("TOP-SECRET", str(cm.exception))

    def test_a_naive_clock_is_a_programming_error(self):
        with self.assertRaises(ValueError):
            run(collector(clock=lambda: datetime(2026, 1, 1)).collect())

    def test_a_non_utc_clock_is_written_as_utc(self):
        tz = timezone(timedelta(hours=3))
        result = run(collector(clock=lambda: datetime(2026, 11, 1, 15, 0, 0, tzinfo=tz)).collect())
        self.assertEqual(result.manifest["created_at"], "2026-11-01T12:00:00Z")


class IntegrityTests(unittest.TestCase):
    def setUp(self):
        self.data = run(collector().collect()).data

    def doc(self):
        return json.loads(self.data)

    def check(self, doc):
        return F.verify_integrity(F.parse_document(F.canonical(doc).encode()))

    def refused(self, doc, code):
        with self.assertRaises(F.BackupFormatError) as cm:
            self.check(doc)
        self.assertEqual(cm.exception.code, code)
        return cm.exception

    def test_the_untouched_file_verifies(self):
        self.check(self.doc())

    def test_a_changed_value_breaks_the_table_checksum(self):
        d = self.doc()
        d["tables"]["group_reports"][0]["reason"] = "edited"
        self.assertEqual(self.refused(d, "checksum_mismatch").detail, "group_reports")

    def test_an_added_or_removed_row_breaks_the_row_count(self):
        d = self.doc()
        d["tables"]["group_reports"].append(dict(d["tables"]["group_reports"][0]))
        self.refused(d, "row_count_mismatch")
        d = self.doc()
        d["tables"]["group_trusted_users"].pop()
        self.refused(d, "row_count_mismatch")

    def test_a_table_removed_from_the_body_only_is_missing(self):
        d = self.doc()
        del d["tables"]["group_settings"]
        self.assertEqual(self.refused(d, "missing_table").detail, "group_settings")

    def test_a_table_removed_from_body_and_manifest_breaks_the_digest(self):
        d = self.doc()
        del d["tables"]["group_settings"]
        del d["manifest"]["tables"]["group_settings"]
        self.refused(d, "digest_mismatch")

    def test_a_row_edit_with_a_recomputed_table_checksum_is_still_caught_by_the_digest(self):
        d = self.doc()
        d["tables"]["group_reports"][0]["reason"] = "edited"
        d["manifest"]["tables"]["group_reports"]["sha256"] = F.sha256_hex(F.canonical(d["tables"]["group_reports"]))
        self.refused(d, "digest_mismatch")

    def test_an_unknown_table_is_refused(self):
        d = self.doc()
        d["tables"]["evil_table"] = []
        d["manifest"]["tables"]["evil_table"] = {"rows": 0, "sha256": F.sha256_hex("[]")}
        d["manifest"]["tables_digest"] = F.tables_digest(d["manifest"]["tables"])
        self.assertEqual(self.refused(d, "unknown_table").detail, "evil_table")

    def test_a_forged_manifest_is_still_caught_by_the_digest(self):
        d = self.doc()
        d["manifest"]["tables"]["group_reports"]["sha256"] = "0" * 64
        self.refused(d, "checksum_mismatch")
        d = self.doc()
        d["manifest"]["total_rows"] = 1
        self.check(d)  # total_rows is informational; the per-table counts are what is verified

    def test_format_name_and_version(self):
        d = self.doc()
        d["manifest"]["format"] = "other"
        self.refused(d, "bad_format")
        d = self.doc()
        d["manifest"]["format_version"] = 2
        self.refused(d, "bad_version")
        d = self.doc()
        d["manifest"]["format_version"] = True
        self.refused(d, "bad_version")

    def test_structural_garbage(self):
        for raw in (b"", b"not json", b"[]", b'{"manifest":{}}', b'{"manifest":[],"tables":{}}', b"\xff\xfe",
                    b'{"manifest":{},"tables":{},"x":1}', b'{"manifest":{"a":NaN},"tables":{}}'):
            with self.subTest(raw=raw), self.assertRaises(F.BackupFormatError) as cm:
                F.parse_document(raw)
            self.assertIn(cm.exception.code, {"bad_json", "bad_shape"})
        with self.assertRaises(F.BackupFormatError):
            F.parse_document("a string, not bytes")

    def test_rows_that_are_not_objects_are_refused(self):
        d = self.doc()
        d["tables"]["group_reports"] = [1]
        self.refused(d, "bad_shape")

    def test_the_size_cap_applies_when_reading_a_file_too(self):
        with self.assertRaises(F.BackupFormatError) as cm:
            F.parse_document(self.data, max_bytes=len(self.data) - 1)
        self.assertEqual(cm.exception.code, "too_large")
        F.parse_document(self.data, max_bytes=len(self.data))

    def test_decoding_gives_back_the_original_values(self):
        doc = F.parse_document(self.data)
        for spec in F.TABLES:
            for row, original in zip(doc["tables"][spec.name], sorted(sample_rows()[spec.name], key=lambda r: tuple(r[k] for k in spec.key))):
                for column in spec.columns:
                    self.assertEqual(F.decode_value(column.kind, row[column.name]), original[column.name], (spec.name, column.name))


class PostgresReaderTests(unittest.TestCase):
    class Conn:
        def __init__(self, records=None):
            self.records, self.log, self.tx = records or [], [], []

        def transaction(self, **kw):
            conn = self

            class Tx:
                async def __aenter__(self_):
                    conn.tx.append(("enter", kw))

                async def __aexit__(self_, *a):
                    conn.tx.append(("exit",))
                    return False
            return Tx()

        async def fetch(self, sql, *args):
            self.log.append((sql, args))
            return self.records

    class Db:
        def __init__(self, conn):
            self.conn = conn

        def acquire(self):
            conn = self.conn

            class A:
                async def __aenter__(self_):
                    return conn

                async def __aexit__(self_, *a):
                    return False
            return A()

    def test_one_repeatable_read_read_only_transaction_for_the_whole_snapshot(self):
        conn = self.Conn()

        async def go():
            async with PostgresBackupReader(self.Db(conn)).snapshot() as snap:
                await snap.read_page(F.TABLES[0], None, 10)
                await snap.read_page(F.TABLES[1], None, 10)
        run(go())
        self.assertEqual(conn.tx, [("enter", {"isolation": "repeatable_read", "readonly": True}), ("exit",)])
        self.assertEqual(len(conn.log), 2)

    def test_sql_is_a_select_with_explicit_columns_and_bound_parameters(self):
        for spec in F.TABLES:
            for has_after in (False, True):
                sql = page_sql(spec, has_after)
                self.assertTrue(sql.startswith("SELECT " + ", ".join(spec.column_names) + f" FROM {spec.name}"), sql)
                self.assertNotIn("*", sql)
                self.assertIn("ORDER BY " + ", ".join(spec.key), sql)
                self.assertTrue(sql.endswith(f"LIMIT ${len(spec.key) + 1 if has_after else 1}"), sql)
                self.assertEqual(len(re.findall(r"\$\d+", sql)), len(spec.key) + 1 if has_after else 1)
        self.assertIn("WHERE (group_id, user_id) > ($1, $2)", page_sql(F.BY_NAME["group_trusted_users"], True))
        self.assertIn("WHERE id > $1", page_sql(F.BY_NAME["group_reports"], True))

    def test_the_after_key_and_limit_are_passed_as_parameters(self):
        conn = self.Conn()

        async def go():
            async with PostgresBackupReader(self.Db(conn)).snapshot() as snap:
                await snap.read_page(F.BY_NAME["group_trusted_users"], (-1001, 5), 500)
        run(go())
        self.assertEqual(conn.log[0][1], (-1001, 5, 500))

    def test_jsonb_text_from_asyncpg_is_parsed_and_dicts_pass_through(self):
        row = dict(group_id=-1, language="ar", settings='{"a": [1, 2]}', updated_at=FIXED_NOW, updated_by=None)
        row2 = dict(row, group_id=-2, settings={"b": 1})
        conn = self.Conn([row, row2])

        async def go():
            async with PostgresBackupReader(self.Db(conn)).snapshot() as snap:
                return await snap.read_page(F.BY_NAME["group_settings"], None, 10)
        rows = run(go())
        self.assertEqual([r["settings"] for r in rows], [{"a": [1, 2]}, {"b": 1}])

    def test_the_end_to_end_collection_through_the_postgres_reader(self):
        data = sample_rows()
        conn_rows = {}

        class Conn(self.Conn):
            async def fetch(self_, sql, *args):
                table = re.search(r"FROM (\w+)", sql).group(1)
                spec = F.BY_NAME[table]
                rows = sorted(data.get(table, []), key=lambda r: tuple(r[k] for k in spec.key))
                if args[:-1]:
                    rows = [r for r in rows if tuple(r[k] for k in spec.key) > tuple(args[:-1])]
                return [dict(r, settings=json.dumps(r["settings"])) if "settings" in r else dict(r) for r in rows[:args[-1]]]
        result = run(collector(PostgresBackupReader(self.Db(Conn())), page_size=2).collect())
        reference = run(collector(FakeReader(), page_size=2).collect())
        self.assertEqual(result.data, reference.data)


class ScopeGuards(unittest.TestCase):
    def files(self):
        return sorted((SRC / "backup").glob("*.py"))

    def test_the_backup_package_never_writes_sql(self):
        pattern = re.compile(r"\b(INSERT\s+INTO|UPDATE\s+\w+\s+SET|DELETE\s+FROM|TRUNCATE|DROP\s+TABLE|ALTER\s+TABLE|CREATE\s+TABLE)\b", re.I)
        for path in self.files():
            if path.name == "postgres_restore.py":      # part 6.9b: the ONE writer of the package (guarded by tests/test_restore_apply.py)
                continue
            self.assertIsNone(pattern.search(path.read_text(encoding="utf-8")), path.name)

    def test_only_select_statements_go_to_the_driver(self):
        import ast
        tree = ast.parse((SRC / "backup" / "postgres_reader.py").read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr in {"execute", "executemany", "fetchrow", "fetchval", "copy_records_to_table"}:
                self.fail(f"unexpected driver call {node.func.attr}")

    def test_no_telegram_and_sending_only_in_the_delivery_module(self):
        """6.8a banned sending outright; 6.8b adds ONE sender (`delivery.py`, through an injected transport) and nothing else."""
        for path in self.files():
            text = path.read_text(encoding="utf-8")
            imports = "\n".join(l for l in text.splitlines() if re.match(r"\s*(from|import)\s", l))
            for forbidden in ("aiogram", "asyncpg", "owner_hub.sender", "owner_hub import sender", "bot.", "hub_transport"):
                self.assertNotIn(forbidden, imports, (path.name, forbidden))
            code = re.sub(r'""".*?"""', "", text, flags=re.DOTALL)
            banned = ("send_message", "list_all") if path.name == "delivery.py" else ("send_document", "send_message", "list_all")
            for forbidden in banned:
                self.assertNotIn(forbidden, code, (path.name, forbidden))
        users = sorted(str(p.relative_to(SRC)) for p in SRC.rglob("*.py")
                       if "backup" not in p.relative_to(SRC).parts[:1] and re.search(r"\bguardian\.backup\b|from \.+backup\b|from \.backup", p.read_text(encoding="utf-8")))
        self.assertEqual(users, ["app.py", "bot/owner_panel_handler.py"], "6.8b wires the command (handler) and the app; nothing else imports backup")

    def test_no_new_migration_in_this_part(self):
        self.assertEqual([v for v, _ in discover()][-1], "0013_member_activity_stats")

    def test_every_table_name_in_the_registry_is_a_plain_identifier(self):
        for spec in F.TABLES:
            self.assertRegex(spec.name, r"^[a-z][a-z0-9_]*$")
            for column in spec.column_names + spec.key:
                self.assertRegex(column, r"^[a-z][a-z0-9_]*$")


if __name__ == "__main__":
    unittest.main()
