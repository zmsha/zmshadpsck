"""Phase 5 / part 5.6: settings templates + the owner's read-only look at a group + the diff preview + migration 0005.
Everything is PREVIEW ONLY: tests assert that nothing is written to any group, license or sanction. aiogram/FastAPI/PostgreSQL
are NOT exercised (not installable in the build sandbox): the router is checked statically and the Postgres store against a
recording fake connection."""
from __future__ import annotations

import hashlib
import json
import re
import unittest
from contextlib import asynccontextmanager
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace as NS

import helpers  # noqa: F401
from guardian.audit import PERMISSION_DENIED, FORGED_CALLBACK, TEMPLATE_DELETED, TEMPLATE_SAVED
from guardian.bot import owner_panel_handler as h
from guardian.db.migrations import SQL_DIR, discover
from guardian.errors import GroupNotRegistered, InvalidInput, PermissionDenied
from guardian.i18n import MESSAGES, t
from guardian.owner_panel import codec, insight_views as iv
from guardian.owner_panel.service import OwnerPanelService
from guardian.owner_panel.template_commands import ParsedTemplateCommand as P, TemplateCommandService, parse_template_command
from guardian.owner_templates.overview import GroupOverviewService
from guardian.owner_templates.store_pg import PostgresTemplateStore
from guardian.owner_templates.templates import (
    EXCLUDED_KEYS, MAX_TEMPLATES, NAME_MAX, TEMPLATE_KEYS, InMemoryTemplateStore, TemplateLimitReached, TemplateService,
    diff_settings, effective_settings, normalize_name, validate_template_settings,
)
from guardian.permissions import OWNER_ONLY, Permission
from stack import A, B, BACKUP, DELEGATE, NOW, OWNER, STRANGER, TG_ADMIN, TG_CREATOR, Stack

SRC = Path(__file__).resolve().parents[1] / "src" / "guardian"
SECRET = "owner-panel-test-secret-0123456789"
KEY = codec.derive_key(SECRET)


def cb(screen, chat=OWNER, **kw):
    return codec.build(KEY, chat, screen, **kw)


def flat(outcome):
    return [b for row in (outcome.buttons or ()) for b in row]


def find(outcome, needle):
    for label, data in flat(outcome):
        if needle in label:
            return data
    raise AssertionError(f"no button containing {needle!r} in {[l for l, _ in flat(outcome)]}")


# ----------------------------------------------------------------------------- migration 0005
class MigrationTests(unittest.TestCase):
    sql = (SQL_DIR / "0005_settings_templates.sql").read_text(encoding="utf-8")

    def test_discovered_after_0004(self):
        self.assertEqual([v for v, _ in discover()][4:5], ["0005_settings_templates"])

    def test_0004_is_untouched(self):
        self.assertEqual(hashlib.sha256((SQL_DIR / "0004_members_welcome_verification.sql").read_bytes()).hexdigest(),
                         "f37ef765d21f00a374d859e80413fa665af44d8b40e695f31cac768aa6b88771")

    def test_tables_and_constraints(self):
        for needle in ("CREATE TABLE IF NOT EXISTS settings_templates", "CREATE TABLE IF NOT EXISTS global_default_settings",
                       "CREATE UNIQUE INDEX IF NOT EXISTS uq_settings_templates_name", "ON settings_templates (name_key)",
                       "jsonb_typeof(settings) = 'object'", "length(name) BETWEEN 1 AND 40", "CHECK (singleton)"):
            self.assertIn(needle, self.sql)

    def test_templates_are_owner_level_not_per_group_data(self):
        self.assertNotIn("REFERENCES telegram_groups", self.sql)      # a template outlives the group it was copied from

    def test_no_destructive_statements(self):
        for bad in ("DROP ", "TRUNCATE", "ALTER TABLE", "DELETE FROM"):
            self.assertNotIn(bad, self.sql.upper())


# ----------------------------------------------------------------------------- pure settings logic
class EffectiveAndValidationTests(unittest.TestCase):
    def test_keys_exclude_dry_run_and_are_the_four_classes(self):
        self.assertNotIn("dry_run", TEMPLATE_KEYS)
        self.assertEqual(EXCLUDED_KEYS, frozenset({"dry_run"}))
        self.assertEqual(len(TEMPLATE_KEYS), 41)
        self.assertEqual(set(effective_settings({})), set(TEMPLATE_KEYS))
        for key in ("links_enabled", "flood_max_messages", "welcome_text", "verify_method", "newbie_seconds"):
            self.assertIn(key, TEMPLATE_KEYS)

    def test_defaults_are_json_safe(self):
        eff = effective_settings(None)
        self.assertEqual(json.loads(json.dumps(eff)), eff)
        self.assertIsInstance(eff["escalation_mutes_seconds"], list)
        self.assertIsNone(eff["welcome_text"])

    def test_stored_values_are_reflected_and_invalid_ones_fall_back(self):
        eff = effective_settings({"flood_max_messages": 9, "links_enabled": False, "flood_window_seconds": 99999,
                                  "verify_method": "nope", "dry_run": True, "unknown": 1, "newbie_seconds": 3600})
        self.assertEqual((eff["flood_max_messages"], eff["links_enabled"], eff["newbie_seconds"]), (9, False, 3600))
        self.assertEqual(eff["flood_window_seconds"], 10)          # out of range => the default the bot would really use
        self.assertEqual(eff["verify_method"], "button")
        self.assertNotIn("dry_run", eff)
        self.assertNotIn("unknown", eff)

    def test_full_effective_settings_validate_unchanged(self):
        eff = effective_settings({"flood_max_messages": 9, "links_allow_domains": ["Example.com"], "welcome_text": "hi {name}"})
        self.assertEqual(validate_template_settings(eff), eff)

    def test_a_subset_is_allowed_and_ordered(self):
        out = validate_template_settings({"warn_limit": 5, "links_enabled": False})
        self.assertEqual(list(out), ["links_enabled", "warn_limit"])

    def test_rejections(self):
        bad = [{}, [], "x", None, {"dry_run": True}, {"nope": 1}, {"flood_max_messages": 100000}, {"flood_max_messages": True},
               {"links_enabled": 1}, {"links_enabled": "yes"}, {"verify_method": "x"}, {"warn_limit": 2.0},
               {"welcome_text": "{name.__class__}"}, {"welcome_text": "x\x00y"}, {"links_allow_domains": ["HTTP://A.com/x"]},
               {"escalation_mutes_seconds": [1]}, {"warn_limit": float("nan")}]
        for settings in bad:
            with self.subTest(settings=settings), self.assertRaises(InvalidInput):
                validate_template_settings(settings)

    def test_the_forbidden_key_is_named_in_the_error(self):
        with self.assertRaises(InvalidInput) as cm:
            validate_template_settings({"dry_run": True})
        self.assertIn("dry_run", str(cm.exception))


class NameTests(unittest.TestCase):
    def test_normalised_name_and_key(self):
        self.assertEqual(normalize_name("  Strict   Mode ")[0], "Strict Mode")
        self.assertEqual(normalize_name("STRICT mode")[1], normalize_name("strict MODE")[1])
        self.assertEqual(normalize_name("إعدادات")[1], normalize_name("اعدادات")[1])   # alef folded
        self.assertEqual(normalize_name("a\u202eb\x00c")[0], "a b c")                    # bidi/control removed

    def test_invalid_names(self):
        for bad in ("", "   ", "---", "😀😀", "x" * (NAME_MAX + 1), None, 5, b"x"):
            with self.subTest(bad=bad), self.assertRaises(InvalidInput):
                normalize_name(bad)

    def test_the_longest_name_is_accepted(self):
        self.assertEqual(len(normalize_name("x" * NAME_MAX)[0]), NAME_MAX)


class DiffTests(unittest.TestCase):
    def test_only_differences_in_stable_order_and_the_count_of_equal(self):
        group = effective_settings({"flood_max_messages": 9})
        tpl = validate_template_settings({"warn_limit": 5, "flood_max_messages": 9, "links_enabled": False, "slowmode_seconds": 0})
        entries, same = diff_settings(tpl, group)
        self.assertEqual([(e.key, e.template, e.group) for e in entries], [("links_enabled", False, True), ("warn_limit", 5, 3)])
        self.assertEqual(same, 2)

    def test_identical_and_partial(self):
        group = effective_settings({})
        self.assertEqual(diff_settings(group, group), ((), len(TEMPLATE_KEYS)))
        self.assertEqual(diff_settings({"warn_limit": 3}, group), ((), 1))

    def test_lists_compare_by_value(self):
        group = effective_settings({"links_allow_domains": ["a.com"]})
        entries, _ = diff_settings({"links_allow_domains": ["a.com", "b.com"]}, group)
        self.assertEqual(entries[0].group, ["a.com"])


# ----------------------------------------------------------------------------- in-memory store
class StoreTests(unittest.IsolatedAsyncioTestCase):
    async def test_upsert_create_then_update_keeps_the_id(self):
        st = InMemoryTemplateStore()
        row, created = await st.upsert("Strict", "strict", {"warn_limit": 2}, OWNER, A, NOW)
        again, created2 = await st.upsert("STRICT", "strict", {"warn_limit": 4}, OWNER, B, NOW + timedelta(hours=1))
        self.assertEqual((created, created2, row.id, again.id), (True, False, 1, 1))
        self.assertEqual((again.name, again.settings, again.source_group_id, again.created_at), ("STRICT", {"warn_limit": 4}, B, NOW))
        self.assertEqual(await st.count(), 1)

    async def test_list_order_get_delete_and_copies(self):
        st = InMemoryTemplateStore()
        for name in ("b", "a", "c"):
            await st.upsert(name, name, {"warn_limit": 2}, OWNER, None, NOW)
        self.assertEqual([r.name for r in await st.list()], ["a", "b", "c"])
        self.assertEqual(len(await st.list(2)), 2)
        row = await st.get(1)
        row.settings["warn_limit"] = 99                      # mutating a returned copy never changes the store
        self.assertEqual((await st.get(1)).settings["warn_limit"], 2)
        self.assertTrue(await st.delete(1))
        self.assertFalse(await st.delete(1))
        self.assertIsNone(await st.get(1))
        self.assertIsNone(await st.get_by_key("b"))
        self.assertIsNotNone(await st.get_by_key("a"))


# ----------------------------------------------------------------------------- service
class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.s = Stack()
        self.store = InMemoryTemplateStore()
        self.svc = TemplateService(self.store, self.s.licenses, self.s.settings_store, self.s.perm, self.s.audit, clock=self.s.clock)
        self.ov = GroupOverviewService(self.s.licenses, self.s.settings_store, self.s.audit_query, self.s.perm)
        await self.s.register(A, B)
        await self.s.admin.activate_permanent(OWNER, A, context_chat_id=A)

    def state(self):
        return (dict(self.s.settings_store._rows), dict(self.store._rows), dict(self.s.licenses._rows),
                list(self.s.licenses.audit_log), list(self.s.sanction_store.__dict__.items()).__repr__())

    def denied(self):
        return [e for e in self.s.audit.events if e.event_type == PERMISSION_DENIED]


class ServiceTests(Base):
    async def test_only_the_primary_owner_may_do_anything(self):
        await self.svc.save_from_group(OWNER, "x", A)
        for actor in (BACKUP, STRANGER, TG_CREATOR, TG_ADMIN, DELEGATE, None, True, 0, -5):
            ops = (self.svc.save_from_group(actor, "y", A), self.svc.list(actor), self.svc.get(actor, 1), self.svc.find(actor, "x"),
                   self.svc.delete(actor, 1), self.svc.diff(actor, 1, A))
            for op in ops:
                with self.subTest(actor=actor), self.assertRaises(PermissionDenied):
                    await op
        self.assertEqual(await self.store.count(), 1)
        self.assertIsNotNone(await self.store.get(1))
        self.assertTrue(self.denied())                         # denials are audited by the permission service

    async def test_a_group_admin_with_every_group_right_still_cannot(self):
        await self.s.delegations.grant(OWNER, A, DELEGATE, __import__("guardian.groups.models", fromlist=["GroupRole"]).GroupRole.GROUP_MANAGER,
                                       context_chat_id=A)
        with self.assertRaises(PermissionDenied):
            await self.svc.save_from_group(DELEGATE, "x", A)
        self.assertIn(Permission.OWNER_TEMPLATES, OWNER_ONLY)

    async def test_save_captures_the_effective_settings_not_the_raw_ones(self):
        await self.s.settings_store.merge(A, {"flood_max_messages": 9, "flood_window_seconds": 99999, "dry_run": True,
                                              "junk": [1]}, OWNER, NOW)
        tpl, created = await self.svc.save_from_group(OWNER, "Strict", A)
        self.assertTrue(created)
        self.assertEqual(tpl.settings["flood_max_messages"], 9)
        self.assertEqual(tpl.settings["flood_window_seconds"], 10)    # what the bot really uses
        self.assertNotIn("dry_run", tpl.settings)
        self.assertNotIn("junk", tpl.settings)
        self.assertEqual(set(tpl.settings), set(TEMPLATE_KEYS))
        self.assertEqual((tpl.created_by, tpl.source_group_id), (OWNER, A))

    async def test_saving_never_changes_the_group(self):
        before = self.state()
        await self.svc.save_from_group(OWNER, "x", A)
        after = self.state()
        self.assertEqual(before[0], after[0])
        self.assertEqual(before[2:], after[2:])

    async def test_same_name_updates_and_is_case_insensitive(self):
        first, c1 = await self.svc.save_from_group(OWNER, "Strict", A)
        await self.s.settings_store.merge(A, {"warn_limit": 7}, OWNER, NOW)
        second, c2 = await self.svc.save_from_group(OWNER, " strict ", A)
        self.assertEqual((c1, c2, second.id == first.id, second.settings["warn_limit"]), (True, False, True, 7))
        self.assertEqual(len(await self.svc.list(OWNER)), 1)

    async def test_registered_group_and_valid_id_required(self):
        for gid in (-9999, 5, 0, None, True, "x"):
            with self.subTest(gid=gid), self.assertRaises((GroupNotRegistered, InvalidInput)):
                await self.svc.save_from_group(OWNER, "x", gid)
        self.assertEqual(await self.store.count(), 0)

    async def test_the_template_limit(self):
        for i in range(MAX_TEMPLATES):
            await self.svc.save_from_group(OWNER, f"t{i}", A)
        with self.assertRaises(TemplateLimitReached):
            await self.svc.save_from_group(OWNER, "one-too-many", A)
        await self.svc.save_from_group(OWNER, "T0", A)                 # updating an existing name is still fine
        self.assertEqual(await self.store.count(), MAX_TEMPLATES)

    async def test_audit_records_ids_and_names_but_never_values(self):
        await self.s.settings_store.merge(A, {"welcome_text": "secret-ish welcome", "welcome_enabled": True}, OWNER, NOW)
        tpl, _ = await self.svc.save_from_group(OWNER, "Strict", A)
        await self.svc.delete(OWNER, tpl.id)
        events = [e for e in self.s.audit.events if e.event_type in (TEMPLATE_SAVED, TEMPLATE_DELETED)]
        self.assertEqual([e.event_type for e in events], [TEMPLATE_SAVED, TEMPLATE_DELETED])
        self.assertEqual(events[0].group_id, A)
        for e in events:
            self.assertIn("Strict", e.detail)
            self.assertNotIn("secret-ish", e.detail)

    async def test_delete_and_missing(self):
        tpl, _ = await self.svc.save_from_group(OWNER, "x", A)
        self.assertTrue(await self.svc.delete(OWNER, tpl.id))
        self.assertFalse(await self.svc.delete(OWNER, tpl.id))
        self.assertIsNone(await self.svc.get(OWNER, tpl.id))
        for bad in (0, -1, True, "1", None, 10**10):
            with self.subTest(bad=bad), self.assertRaises(InvalidInput):
                await self.svc.get(OWNER, bad)

    async def test_find_by_name(self):
        tpl, _ = await self.svc.save_from_group(OWNER, "Strict", A)
        self.assertEqual((await self.svc.find(OWNER, " STRICT")).id, tpl.id)
        self.assertIsNone(await self.svc.find(OWNER, "other"))

    async def test_diff_is_a_pure_preview(self):
        await self.s.settings_store.merge(A, {"warn_limit": 7}, OWNER, NOW)
        tpl, _ = await self.svc.save_from_group(OWNER, "Strict", A)
        await self.s.settings_store.merge(B, {"flood_max_messages": 20}, OWNER, NOW)
        before = self.state()
        diff = await self.svc.diff(OWNER, tpl.id, B)
        self.assertEqual(self.state(), before)                         # nothing written anywhere
        self.assertEqual({e.key for e in diff.entries}, {"warn_limit", "flood_max_messages"})
        self.assertEqual(diff.same, len(TEMPLATE_KEYS) - 2)
        self.assertEqual(diff.group_id, B)

    async def test_diff_of_a_group_with_itself_is_empty_and_follows_changes(self):
        tpl, _ = await self.svc.save_from_group(OWNER, "x", A)
        self.assertEqual((await self.svc.diff(OWNER, tpl.id, A)).entries, ())
        await self.s.settings_store.merge(A, {"links_enabled": False}, OWNER, NOW)
        self.assertEqual([e.key for e in (await self.svc.diff(OWNER, tpl.id, A)).entries], ["links_enabled"])

    async def test_diff_edge_cases(self):
        self.assertIsNone(await self.svc.diff(OWNER, 123, A))
        tpl, _ = await self.svc.save_from_group(OWNER, "x", A)
        with self.assertRaises(GroupNotRegistered):
            await self.svc.diff(OWNER, tpl.id, -777)
        with self.assertRaises(InvalidInput):
            await self.svc.diff(OWNER, tpl.id, 12)


# ----------------------------------------------------------------------------- overview
class OverviewTests(Base):
    async def test_owner_only(self):
        for actor in (BACKUP, STRANGER, TG_CREATOR, DELEGATE, None):
            with self.subTest(actor=actor), self.assertRaises(PermissionDenied):
                await self.ov.overview(actor, A)

    async def test_license_effective_settings_and_events(self):
        await self.s.settings_store.merge(A, {"flood_max_messages": 9}, OWNER, NOW)
        out = await self.ov.overview(OWNER, A)
        self.assertEqual(out.license.group_id, A)
        self.assertEqual(out.settings["flood_max_messages"], 9)
        self.assertEqual({e.kind for e in out.events}, {"license"})
        self.assertIn("activate_permanent", {e.what for e in out.events})

    async def test_events_merge_license_and_security_newest_first_and_capped(self):
        for i in range(12):
            self.s.clock.advance(minutes=1)
            await self.s.settings.update(OWNER, A, {"warn_limit": 2 + i % 5}, context_chat_id=A)
        out = await self.ov.overview(OWNER, A)
        self.assertEqual(len(out.events), 8)
        times = [e.when for e in out.events]
        self.assertEqual(times, sorted(times, reverse=True))
        self.assertEqual(out.events[0].kind, "security")

    async def test_other_groups_events_never_appear(self):
        await self.s.admin.activate_permanent(OWNER, B, context_chat_id=B)
        await self.s.settings.update(OWNER, B, {"warn_limit": 9}, context_chat_id=B)
        out = await self.ov.overview(OWNER, A)
        self.assertEqual(len(out.events), 2)                            # register_pending + activate_permanent of A only
        self.assertNotIn("settings_changed", {e.what for e in out.events})

    async def test_unregistered_and_invalid(self):
        with self.assertRaises(GroupNotRegistered):
            await self.ov.overview(OWNER, -555)
        with self.assertRaises(InvalidInput):
            await self.ov.overview(OWNER, 7)

    async def test_a_group_without_stored_settings_shows_the_defaults(self):
        self.assertEqual((await self.ov.overview(OWNER, B)).settings, effective_settings({}))


# ----------------------------------------------------------------------------- codec
class CodecTests(unittest.TestCase):
    def test_new_screens_round_trip_and_verify(self):
        cases = [(codec.OVERVIEW, dict(group_id=-1001, filter="b", page=3)), (codec.PICK, dict(group_id=-5)),
                 (codec.TEMPLATES, dict(filter="p", page=2)),
                 (codec.DIFF, dict(template_id=42, group_id=-1001234567890, filter="d", page=7))]
        for screen, kw in cases:
            with self.subTest(screen):
                data = cb(screen, **kw)
                parsed = codec.parse(data)
                self.assertEqual(parsed.screen, screen)
                self.assertTrue(codec.verify(KEY, OWNER, parsed))
                self.assertFalse(codec.verify(KEY, OWNER + 1, parsed))      # the chat is part of the tag
                for field, value in kw.items():
                    self.assertEqual(getattr(parsed, "filter" if field == "filter" else field), value)

    def test_worst_case_fits_in_64_bytes(self):
        data = cb(codec.DIFF, template_id=codec.MAX_TEMPLATE_ID, group_id=-(10**18), filter="b", page=codec.MAX_PAGE)
        self.assertLessEqual(len(data.encode()), 64)

    def test_tampering_is_detected(self):
        data = cb(codec.DIFF, template_id=1, group_id=-5, filter="a", page=0)
        forged = data.replace(":1:-5:", ":2:-5:")
        self.assertFalse(codec.verify(KEY, OWNER, codec.parse(forged)))
        other = data.replace(":-5:", ":-6:")
        self.assertFalse(codec.verify(KEY, OWNER, codec.parse(other)))

    def test_build_and_parse_reject_bad_values(self):
        for bad in (0, -1, codec.MAX_TEMPLATE_ID + 1, True, None):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                cb(codec.DIFF, template_id=bad, group_id=-5)
        with self.assertRaises(ValueError):
            cb(codec.OVERVIEW)                                                 # a group screen needs a group
        tag = "0" * 12
        for data in (f"ow:v:0:-5:a:0:{tag}", f"ow:v:01:-5:a:0:{tag}", f"ow:v:1:5:a:0:{tag}", f"ow:v:1:-5:a:{tag}",
                     f"ow:t:a:0:extra:{tag}", f"ow:o:-5:a:{tag}", f"ow:v:x:-5:a:0:{tag}"):
            with self.subTest(data=data):
                self.assertIsNone(codec.parse(data))


# ----------------------------------------------------------------------------- panel integration
class PanelBase(Base):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.panel = self.make()

    def make(self, **kw):
        kw.setdefault("templates", self.svc)
        kw.setdefault("overview", self.ov)
        return OwnerPanelService(permissions=self.s.perm, audit=self.s.audit, licenses=self.s.licenses, secret=SECRET,
                                 clock=self.s.clock, **kw)

    async def press(self, data, *, chat=OWNER, presser=OWNER, svc=None):
        return await (svc or self.panel).press(chat, "private", presser, data, "ar")


class PanelTests(PanelBase):
    async def test_entry_buttons_exist_only_when_the_services_are_wired(self):
        plain = self.make(templates=None, overview=None)
        for svc, expected in ((self.panel, True), (plain, False)):
            listing = await svc.open(OWNER, "private", OWNER)
            detail = await self.press(cb(codec.DETAIL, group_id=A), svc=svc)
            self.assertEqual("القوالب" in "".join(l for l, _ in flat(listing)), expected)
            self.assertEqual("الإعدادات والأحداث" in "".join(l for l, _ in flat(detail)), expected)

    async def test_the_insight_screens_are_unavailable_without_their_service(self):
        plain = self.make(templates=None, overview=None)
        for screen, kw in ((codec.OVERVIEW, dict(group_id=A)), (codec.PICK, dict(group_id=A)), (codec.TEMPLATES, {}),
                           (codec.DIFF, dict(template_id=1, group_id=A))):
            out = await self.press(cb(screen, **kw), svc=plain)
            self.assertEqual((out.status, out.alert, out.text), ("insight_unavailable", True, None))

    async def test_overview_screen(self):
        await self.s.settings_store.merge(A, {"flood_max_messages": 9, "links_enabled": False}, OWNER, NOW)
        out = await self.press(cb(codec.OVERVIEW, group_id=A))
        self.assertEqual(out.status, "overview")
        self.assertIn("flood_max_messages", out.text)
        self.assertIn("9", out.text)
        self.assertIn("✖ متوقف", out.text)
        self.assertIn("activate_permanent", out.text)
        self.assertIn("قارن", "".join(l for l, _ in flat(out)))
        self.assertEqual(codec.parse(find(out, "رجوع")).screen, codec.DETAIL)

    async def test_overview_without_templates_has_no_compare_button(self):
        out = await self.press(cb(codec.OVERVIEW, group_id=A), svc=self.make(templates=None))
        self.assertEqual(out.status, "overview")
        self.assertNotIn("قارن", "".join(l for l, _ in flat(out)))

    async def test_templates_list_and_picker(self):
        empty = await self.press(cb(codec.TEMPLATES))
        self.assertEqual(empty.status, "templates")
        self.assertIn("لا توجد قوالب", empty.text)
        pick = await self.press(cb(codec.PICK, group_id=A))
        self.assertIn(f"/template save اسم_القالب {A}", pick.text)
        await self.svc.save_from_group(OWNER, "Strict", A)
        full = await self.press(cb(codec.TEMPLATES))
        self.assertIn("Strict", full.text)
        pick = await self.press(cb(codec.PICK, group_id=A))
        parsed = codec.parse(find(pick, "Strict"))
        self.assertEqual((parsed.screen, parsed.template_id, parsed.group_id), (codec.DIFF, 1, A))

    async def test_diff_screen_shows_the_differences_and_changes_nothing(self):
        tpl, _ = await self.svc.save_from_group(OWNER, "Strict", A)
        await self.s.settings_store.merge(B, {"warn_limit": 9}, OWNER, NOW)
        before = self.state()
        out = await self.press(cb(codec.DIFF, template_id=tpl.id, group_id=B))
        self.assertEqual(out.status, "diff")
        self.assertIn("warn_limit", out.text)
        self.assertIn("9 ➜ 3", out.text)                        # the group's value ➜ the template's value
        self.assertIn("معاينة فقط", out.text)
        self.assertEqual(self.state(), before)
        same = await self.press(cb(codec.DIFF, template_id=tpl.id, group_id=A))
        self.assertIn("لا فروق", same.text)

    async def test_the_diff_uses_the_template_that_was_pressed(self):
        await self.svc.save_from_group(OWNER, "First", A)                          # id 1: identical to group B's defaults
        await self.s.settings_store.merge(A, {"warn_limit": 9}, OWNER, NOW)
        second, _ = await self.svc.save_from_group(OWNER, "Second", A)             # id 2: warn_limit 9
        out = await self.press(cb(codec.DIFF, template_id=second.id, group_id=B))
        self.assertIn("Second", out.text)
        self.assertIn("warn_limit", out.text)
        first = await self.press(cb(codec.DIFF, template_id=1, group_id=B))
        self.assertIn("First", first.text)
        self.assertIn("لا فروق", first.text)

    async def test_diff_for_a_deleted_template_or_group(self):
        out = await self.press(cb(codec.DIFF, template_id=99, group_id=A))
        self.assertEqual(out.status, "template_missing")
        tpl, _ = await self.svc.save_from_group(OWNER, "x", A)
        gone = await self.press(cb(codec.DIFF, template_id=tpl.id, group_id=-4242))
        self.assertEqual(gone.status, "missing")
        self.assertEqual((await self.press(cb(codec.OVERVIEW, group_id=-4242))).status, "missing")

    async def test_a_non_owner_gets_nothing_and_is_audited(self):
        tpl, _ = await self.svc.save_from_group(OWNER, "secret-template", A)
        for who in (STRANGER, BACKUP, TG_CREATOR, DELEGATE):
            for screen, kw in ((codec.OVERVIEW, dict(group_id=A)), (codec.PICK, dict(group_id=A)), (codec.TEMPLATES, {}),
                               (codec.DIFF, dict(template_id=tpl.id, group_id=A))):
                with self.subTest(who=who, screen=screen):
                    out = await self.press(cb(screen, chat=who, **kw), chat=who, presser=who)
                    self.assertEqual((out.status, out.text, out.buttons), ("not_owner", None, None))
        self.assertGreaterEqual(len([e for e in self.s.audit.events if e.event_type == FORGED_CALLBACK]), 16)

    async def test_a_forged_tag_is_refused(self):
        data = cb(codec.OVERVIEW, group_id=A)
        out = await self.press(data[:-1] + ("0" if data[-1] != "0" else "1"))
        self.assertEqual(out.status, "forged")

    async def test_service_failures_fail_closed(self):
        class Down:
            async def list(self, *a): raise RuntimeError("db down")
            async def diff(self, *a): raise RuntimeError("db down")
            async def overview(self, *a): raise RuntimeError("db down")

        svc = self.make(templates=Down(), overview=Down())
        for screen, kw in ((codec.OVERVIEW, dict(group_id=A)), (codec.TEMPLATES, {})):
            out = await self.press(cb(screen, **kw), svc=svc)
            self.assertEqual((out.status, out.alert, out.text), ("unavailable", True, None))

    async def test_user_controlled_text_is_escaped(self):
        await self.s.license_service.on_bot_added(-1500, "<b>x</b>&y", NOW)
        titled = await self.press(cb(codec.OVERVIEW, group_id=-1500))
        self.assertNotIn("<b>x</b>", titled.text)
        self.assertIn("&lt;b&gt;x&lt;/b&gt;&amp;y", titled.text)
        await self.s.settings_store.merge(A, {"welcome_text": "<script>{name}</script>", "links_allow_domains": ["a.com"]}, OWNER, NOW)
        out = await self.press(cb(codec.OVERVIEW, group_id=A))
        self.assertNotIn("<script>", out.text)
        self.assertIn("&lt;script&gt;", out.text)
        tpl, _ = await self.svc.save_from_group(OWNER, "a<i>b", A)
        self.assertNotIn("<i>", (await self.press(cb(codec.TEMPLATES))).text)

    async def test_long_views_stay_inside_telegrams_limit(self):
        await self.s.settings_store.merge(A, {"welcome_text": "x" * 400, "links_allow_domains": [f"d{i}.com" for i in range(60)]}, OWNER, NOW)
        for i in range(10):
            await self.s.settings.update(OWNER, A, {"warn_limit": 2 + i % 3}, context_chat_id=A)
        for i in range(MAX_TEMPLATES):
            await self.svc.save_from_group(OWNER, f"template-number-{i:03d}-with-a-long-name", A)
        for screen, kw in ((codec.OVERVIEW, dict(group_id=A)), (codec.TEMPLATES, {}), (codec.PICK, dict(group_id=A))):
            out = await self.press(cb(screen, **kw))
            self.assertLessEqual(len(out.text), 4096, screen)
            for label, data in flat(out):
                self.assertLessEqual(len(data.encode()), 64)
        self.assertLessEqual(len([b for b in flat(await self.press(cb(codec.PICK, group_id=A))) if "⚖" in b[0]]), iv.MAX_PICK)


# ----------------------------------------------------------------------------- commands
class ParserTests(unittest.TestCase):
    def test_english(self):
        cases = {"/templates": P("list"), "/templates@GBot": P("list"), "/template list": P("list"), "/template": P("usage"),
                 "/template save Strict Mode -1001": P("save", "Strict Mode", -1001), "/TEMPLATE diff x -5": P("diff", "x", -5),
                 "/template delete My Tpl": P("delete", "My Tpl"), "/template foo": P("usage"), "/template save x": P("usage"),
                 "/template save x 55": P("usage"), "/template delete": P("usage"), "/templates extra": P("usage")}
        for text, want in cases.items():
            with self.subTest(text=text):
                self.assertEqual(parse_template_command(text, "GBot"), want)

    def test_arabic(self):
        cases = {"القوالب": P("list"), "قوالب": P("list"), "حفظ قالب استريكت -1001": P("save", "استريكت", -1001),
                 "حفظ قالب اسم طويل -١٠٠١": P("save", "اسم طويل", -1001), "حذف قالب اسم": P("delete", "اسم"),
                 "قارن قالب اسم -5": P("diff", "اسم", -5), "حفظ قالب": None, "حذف قالب": None, "قالب": None,
                 "القوالب كلها": None, "حذف الرسائل": None}
        for text, want in cases.items():
            with self.subTest(text=text):
                self.assertEqual(parse_template_command(text), want)

    def test_not_ours(self):
        for text in ("/owner", "/templatex", "hello", "/template@OtherBot save x -5", "/template@GBot save x -5", "", None, 5,
                     "/template save " + "x" * 300):
            with self.subTest(text=text):
                self.assertIsNone(parse_template_command(text, None if text != "/template@GBot save x -5" else None))
        self.assertEqual(parse_template_command("/template@GBot save x -5", "gbot"), P("save", "x", -5))


class CommandServiceTests(Base):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.cmd = TemplateCommandService(self.svc, self.s.licenses)

    async def run_(self, parsed, *, chat=OWNER, ctype="private", user=OWNER):
        return await self.cmd.run(parsed, chat_id=chat, chat_type=ctype, user_id=user)

    async def test_full_flow(self):
        saved = await self.run_(P("save", "Strict", A))
        self.assertEqual(saved.status, "saved")
        self.assertIn("Strict", saved.text)
        self.assertIn("لم يُغيَّر شيء", saved.text)
        self.assertEqual((await self.run_(P("save", "strict", A))).status, "updated")
        listing = await self.run_(P("list"))
        self.assertIn("strict", listing.text)                    # the same name saved again renames to the latest spelling
        await self.s.settings_store.merge(B, {"warn_limit": 9}, OWNER, NOW)
        before = self.state()
        diff = await self.run_(P("diff", "STRICT", B))
        self.assertEqual((diff.status, self.state()), ("diff", before))
        self.assertIn("warn_limit", diff.text)
        self.assertEqual((await self.run_(P("delete", "strict"))).status, "deleted")
        self.assertEqual((await self.run_(P("delete", "strict"))).status, "not_found")
        self.assertEqual((await self.run_(P("diff", "strict", B))).status, "not_found")

    async def test_only_the_owner_in_a_private_chat_is_answered(self):
        for user in (BACKUP, STRANGER, TG_CREATOR, DELEGATE):
            self.assertIsNone(await self.run_(P("list"), chat=user, user=user))
            self.assertIsNone(await self.run_(P("usage"), chat=user, user=user))      # even the usage text stays private
            self.assertIsNone(await self.run_(P("save", "x", A), chat=user, user=user))
        self.assertIsNone(await self.run_(P("list"), chat=A, ctype="supergroup"))
        self.assertIsNone(await self.run_(P("list"), chat=OWNER + 1))                 # chat must be the owner's own private chat
        self.assertIsNone(await self.run_(P("list"), ctype="group"))
        self.assertEqual(await self.store.count(), 0)

    async def test_errors_become_plain_replies(self):
        self.assertEqual((await self.run_(P("usage"))).status, "usage")
        self.assertEqual((await self.run_(P("save", "---", A))).status, "name_invalid")
        self.assertEqual((await self.run_(P("save", "x", -4242))).status, "group_unknown")
        self.assertEqual((await self.run_(P("save", "x", 5))).status, "invalid")
        for i in range(MAX_TEMPLATES):
            await self.svc.save_from_group(OWNER, f"t{i}", A)
        self.assertEqual((await self.run_(P("save", "new", A))).status, "limit")

    async def test_a_store_failure_is_a_safe_reply(self):
        class Boom(InMemoryTemplateStore):
            async def list(self, limit=50): raise RuntimeError("db down")

        svc = TemplateService(Boom(), self.s.licenses, self.s.settings_store, self.s.perm, self.s.audit)
        out = await TemplateCommandService(svc, self.s.licenses).run(P("list"), chat_id=OWNER, chat_type="private", user_id=OWNER)
        self.assertEqual(out.status, "failed")


class GlueTests(Base):
    def msg(self, text, *, chat="private", user=OWNER, bot=False):
        sent = []

        async def answer(text, **kw):
            sent.append(text)

        return NS(text=text, chat=NS(id=user, type=chat), from_user=NS(id=user, is_bot=bot, language_code="ar"), answer=answer), sent

    async def test_matching_is_private_and_human_only(self):
        bot = NS()
        self.assertEqual(await h.match_template_command(self.msg("/templates")[0], bot), P("list"))
        self.assertEqual(await h.match_template_command(self.msg("القوالب")[0], bot), P("list"))
        self.assertIsNone(await h.match_template_command(self.msg("/templates", chat="supergroup")[0], bot))
        self.assertIsNone(await h.match_template_command(self.msg("/templates", bot=True)[0], bot))
        self.assertIsNone(await h.match_template_command(self.msg("hello")[0], bot))

    async def test_execute_replies_to_the_owner_only(self):
        services = NS(owner_templates=TemplateCommandService(self.svc, self.s.licenses), settings=NS(default_language="ar"))
        message, sent = self.msg("/template save Strict %d" % A)
        self.assertEqual(await h.execute_template(message, P("save", "Strict", A), services=services), "saved")
        self.assertEqual(len(sent), 1)
        stranger, sent2 = self.msg("/templates", user=STRANGER)
        self.assertIsNone(await h.execute_template(stranger, P("list"), services=services))
        self.assertEqual(sent2, [])
        self.assertIsNone(await h.execute_template(message, P("list"), services=NS(owner_templates=None, settings=NS(default_language="ar"))))

    async def test_a_failing_send_is_swallowed(self):
        services = NS(owner_templates=TemplateCommandService(self.svc, self.s.licenses), settings=NS(default_language="ar"))
        message, _ = self.msg("/templates")

        async def broken(*a, **kw):
            raise RuntimeError("telegram down")

        message.answer = broken
        self.assertEqual(await h.execute_template(message, P("list"), services=services), "list")


# ----------------------------------------------------------------------------- PostgreSQL store (recording fake)
class PgTests(unittest.IsolatedAsyncioTestCase):
    def db(self, row=None, rows=None, val=None):
        calls = []

        class Conn:
            async def fetchrow(self, sql, *a):
                calls.append(("fetchrow", " ".join(sql.split()), a))
                return row

            async def fetch(self, sql, *a):
                calls.append(("fetch", " ".join(sql.split()), a))
                return rows or []

            async def fetchval(self, sql, *a):
                calls.append(("fetchval", " ".join(sql.split()), a))
                return val

        class Db:
            @asynccontextmanager
            async def acquire(self):
                yield Conn()

        return Db(), calls

    def row(self, **kw):
        base = dict(id=3, name="Strict", name_key="strict", settings='{"warn_limit": 5}', created_by=OWNER, created_at=NOW,
                    updated_at=NOW, source_group_id=A, created=True)
        return {**base, **kw}

    async def test_upsert_is_one_parameterised_statement(self):
        db, calls = self.db(row=self.row())
        tpl, created = await PostgresTemplateStore(db).upsert("Strict", "strict", {"warn_limit": 5}, OWNER, A, NOW)
        kind, sql, args = calls[0]
        self.assertTrue(created)
        self.assertEqual((tpl.id, tpl.settings), (3, {"warn_limit": 5}))
        self.assertIn("INSERT INTO settings_templates", sql)
        self.assertIn("ON CONFLICT (name_key) DO UPDATE", sql)
        self.assertEqual(args[:2], ("Strict", "strict"))
        self.assertEqual(json.loads(args[2]), {"warn_limit": 5})
        self.assertNotIn("Strict", sql)                                             # values only as parameters
        self.assertEqual(len(calls), 1)

    async def test_an_updated_row_reports_created_false(self):
        db, _ = self.db(row=self.row(created=False, settings={"warn_limit": 2}))    # a dict (codec registered) is fine too
        tpl, created = await PostgresTemplateStore(db).upsert("Strict", "strict", {"warn_limit": 2}, OWNER, None, NOW)
        self.assertEqual((created, tpl.settings), (False, {"warn_limit": 2}))

    async def test_reads_deletes_and_count(self):
        db, calls = self.db(row=self.row(), rows=[self.row(), self.row(id=4)], val=3)
        st = PostgresTemplateStore(db)
        self.assertEqual((await st.get(3)).name, "Strict")
        self.assertEqual((await st.get_by_key("strict")).id, 3)
        self.assertEqual(len(await st.list(10**9)), 2)
        self.assertTrue(await st.delete(3))
        self.assertEqual(await st.count(), 3)
        sqls = [c[1] for c in calls]
        self.assertTrue(all("settings_templates" in s for s in sqls))
        self.assertIn("id = $1", sqls[0])
        self.assertEqual(calls[2][2], (200,))                                        # list limit clamped
        self.assertIn("DELETE FROM settings_templates WHERE id = $1", sqls[3])

    async def test_missing_rows(self):
        db, _ = self.db(row=None, val=None)
        st = PostgresTemplateStore(db)
        self.assertIsNone(await st.get(1))
        self.assertIsNone(await st.get_by_key("x"))
        self.assertFalse(await st.delete(1))
        self.assertEqual(await st.count(), 0)


# ----------------------------------------------------------------------------- static guards
class StaticGuardTests(unittest.TestCase):
    def read(self, rel):
        return (SRC / rel).read_text(encoding="utf-8")

    def test_the_preview_code_never_writes_a_group_license_or_sanction(self):
        forbidden = re.compile(r"\.(merge|set_language|transition|register_pending_if_absent|grant|revoke|add|remove|record)\(|"
                               r"group_settings|settings\.update\(|LicenseAdminService|SanctionService|WarningService")
        for rel in ("owner_templates/overview.py", "owner_panel/insight_views.py", "owner_panel/template_commands.py"):
            self.assertIsNone(forbidden.search(self.read(rel)), rel)
        # the template service writes only its own store (+ the audit), never the settings store of a group
        src = self.read("owner_templates/templates.py")
        self.assertNotIn("self._settings.merge", src)
        self.assertEqual(sorted(set(re.findall(r"self\._settings\.(\w+)\(", src))), ["get"])
        self.assertEqual(sorted(set(re.findall(r"self\._licenses\.(\w+)\(", src))), ["get"])

    def test_the_owner_panel_service_calls_only_read_methods_of_the_new_services(self):
        src = self.read("owner_panel/service.py")
        self.assertEqual(sorted(set(re.findall(r"self\._templates\.(\w+)\(", src))), ["diff", "list"])
        self.assertEqual(sorted(set(re.findall(r"self\._overview\.(\w+)\(", src))), ["overview"])

    def test_packages_are_framework_free_and_the_hub_stays_observation_only(self):
        for path in (SRC / "owner_templates").glob("*.py"):
            self.assertNotIn("aiogram", path.read_text(encoding="utf-8"), path.name)
        self.assertFalse((SRC / "owner_hub" / "templates.py").exists())             # not in the observation-only package

    def test_the_store_touches_only_its_own_table(self):
        src = self.read("owner_templates/store_pg.py")
        tables = set(re.findall(r"(?:FROM|INTO|UPDATE)\s+(\w+)", src)) - {"SET"}   # `DO UPDATE SET` is not a table
        self.assertEqual(tables, {"settings_templates"})

    def test_the_router_registers_the_template_commands_in_the_owner_router(self):
        src = self.read("bot/routers/owner_panel.py")
        self.assertIn("match_template_command", src)
        self.assertIn("execute_template", src)

    def test_services_and_app_are_wired(self):
        self.assertIn("owner_templates", self.read("services.py"))
        app = self.read("app.py")
        for needle in ("TemplateService(", "GroupOverviewService(", "TemplateCommandService(", "templates=template_service",
                       "overview=group_overview", "owner_templates=TemplateCommandService("):
            self.assertIn(needle, app)

    def test_the_new_permission_is_owner_only(self):
        self.assertIn(Permission.OWNER_TEMPLATES, OWNER_ONLY)

    def test_every_new_i18n_key_exists_in_both_languages_and_formats(self):
        keys = set()
        for rel in ("owner_panel/insight_views.py", "owner_panel/template_commands.py", "owner_panel/views.py",
                    "owner_panel/service.py"):
            keys |= set(re.findall(r'"((?:tpl_|ow_)[a-z_]+)"', self.read(rel)))
        for key in sorted(keys):
            for lang in ("ar", "en"):
                self.assertIn(key, MESSAGES[lang], key)
        new = [k for k in MESSAGES["ar"] if k.startswith("tpl_")]
        self.assertGreaterEqual(len(new), 18)
        for lang in ("ar", "en"):
            for key in new:
                fields = {n for _, n, _, _ in __import__("string").Formatter().parse(MESSAGES[lang][key]) if n}
                t(key, lang, **{f: "x" for f in fields})
            for key in ("ow_btn_overview", "ow_btn_templates", "ow_btn_compare"):
                self.assertLessEqual(len(MESSAGES[lang][key]), 24, key)


if __name__ == "__main__":
    unittest.main()
