"""Phase 4 / part 4.7c: the panel's protection screen (buttons write), the read-only trust screen, and panel expiry.

What must hold: (1) protection buttons carry only a signed NAME, the value lives in `panel.actions.ACTIONS`, and only the
keys in `PROTECT_KEYS` are reachable (never `dry_run`, domains, escalation); (2) a protection write re-checks
MANAGE_SETTINGS, claims by callback id, compares with the STORED values (an unreadable store never shows or writes
defaults), and audits key names only; (3) the trust screen is read-only and has no write button; (4) a panel older than
the TTL (or with an unknown / future / naive date) is dead: it changes nothing and strips its own buttons; (5) every
earlier panel guarantee still holds for the new screens."""
from __future__ import annotations

import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace as NS

from executor_stack import BOT
from guardian.bot import panel_handler as ph
from guardian.groups.models import GroupRole
from guardian.groups.service import validate_settings_patch
from guardian.members.memory_store import InMemoryBotTrustStore
from guardian.members.service import BotTrustService
from guardian.moderation import settings_commands as sc
from guardian.moderation.executor import ModerationCommandService
from guardian.panel import actions as pa
from guardian.panel import codec
from guardian.panel import service as ps
from guardian.panel.service import PanelService
from guardian.protection.settings import ProtectionSettings
from stack import DELEGATE, OWNER, TG_ADMIN
import test_panel as tp
import test_panel_screens as tps
from test_panel import KEY, SECRET, fake_markup
from test_phase3_final_handoff import BLOCKED_STATES

PROTECT_ACTIONS = {n: s for n, s in pa.ACTIONS.items() if s.topic == pa.TOPIC_PROTECT}
UTC = timezone.utc


# ----------------------------------------------------------------------------- the server-side table
class ProtectActionTableTests(unittest.TestCase):
    def test_protect_actions_exist_and_every_name_is_valid_and_fits_the_limit(self):
        self.assertTrue(PROTECT_ACTIONS)
        for name in PROTECT_ACTIONS:
            self.assertRegex(name, r"^[a-z]{1,8}$")
            data = codec.build(KEY, -(2**63), 10**18 - 1, name)
            self.assertLessEqual(len(data.encode()), 64, name)

    def test_one_button_changes_exactly_one_protection_key(self):
        for name, spec in PROTECT_ACTIONS.items():
            self.assertEqual(len(spec.patch), 1, name)

    def test_every_value_is_accepted_by_the_validator_and_kept_by_from_raw(self):
        for name, spec in PROTECT_ACTIONS.items():
            patch = dict(spec.patch)
            validate_settings_patch(patch)
            cfg = ProtectionSettings.from_raw(patch)
            for key, value in patch.items():
                self.assertEqual(getattr(cfg, key), value, f"{name}:{key}")

    def test_the_reachable_keys_are_exactly_the_whitelist_and_both_whitelists_agree(self):
        reachable = {k for spec in PROTECT_ACTIONS.values() for k in spec.patch}
        self.assertEqual(reachable, set(pa.PROTECT_KEYS))
        self.assertEqual(set(pa.PROTECT_KEYS), set(sc.PANEL_KEYS))

    def test_dry_run_domains_and_windows_are_never_reachable_from_a_button(self):
        banned = {"dry_run", "links_allow_domains", "escalation_mutes_seconds", "escalation_window_seconds",
                  "flood_window_seconds", "duplicate_window_seconds", "duplicate_max_repeats", "duplicate_min_length"}
        self.assertFalse(banned & {k for spec in pa.ACTIONS.values() for k in spec.patch})
        self.assertFalse(banned & set(pa.PROTECT_KEYS))

    def test_the_table_pins_the_documented_values(self):
        expected = {
            "lkon": ("links_enabled", True), "lkoff": ("links_enabled", False),
            "invon": ("links_allow_invites", True), "invoff": ("links_allow_invites", False),
            "floon": ("flood_enabled", True), "flooff": ("flood_enabled", False),
            "fmfour": ("flood_max_messages", 4), "fmsix": ("flood_max_messages", 6), "fmten": ("flood_max_messages", 10),
            "dupon": ("duplicate_enabled", True), "dupoff": ("duplicate_enabled", False),
            "slwoff": ("slowmode_seconds", 0), "slwten": ("slowmode_seconds", 10),
            "slwhalf": ("slowmode_seconds", 30), "slwmin": ("slowmode_seconds", 60),
            "wltwo": ("warn_limit", 2), "wlthree": ("warn_limit", 3), "wlfive": ("warn_limit", 5),
            "wamute": ("warn_action", "mute"), "wakick": ("warn_action", "kick"), "waban": ("warn_action", "ban"),
            "wsforev": ("warn_action_seconds", 0), "wshour": ("warn_action_seconds", 3600),
            "wsday": ("warn_action_seconds", 86400), "wsweek": ("warn_action_seconds", 604800)}
        self.assertEqual({n: next(iter(s.patch.items())) for n, s in PROTECT_ACTIONS.items()}, expected)
        for value in (s.patch for s in PROTECT_ACTIONS.values()):
            for v in value.values():
                self.assertIs(type(v) is bool or isinstance(v, (int, str)), True)

    def test_trust_has_no_write_action_and_is_not_a_writable_topic(self):
        self.assertIn(pa.TOPIC_TRUST, pa.TOPICS)
        self.assertNotIn(pa.TOPIC_TRUST, pa.WRITABLE_TOPICS)
        self.assertFalse([n for n, s in pa.ACTIONS.items() if s.topic == pa.TOPIC_TRUST])

    def test_names_never_collide_with_screens(self):
        names = list(pa.ACTIONS)
        self.assertEqual(len(names), len(set(names)))
        self.assertFalse({codec.SCREEN_HOME, codec.SCREEN_CLOSE, *pa.TOPICS} & set(names))
        self.assertEqual(sorted(codec.SCREENS), sorted([codec.SCREEN_HOME, codec.SCREEN_CLOSE, *pa.TOPICS, *names]))


# ----------------------------------------------------------------------------- full stack with trust stores
class Base(tps.WriteBase):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.bots = InMemoryBotTrustStore()
        self.bot_trust = BotTrustService(self.bots, self.s.licenses, self.s.perm, self.s.audit, clock=self.s.clock)
        self.svc = ModerationCommandService(
            permissions=self.s.perm, warnings=self.s.warnings, sanctions=self.s.sanctions,
            settings_store=self.s.settings_store, actions=self.actions, chat_info=self.s.chat, claims=self.claims,
            audit=self.s.audit, bot_id=BOT, clock=self.s.clock, group_settings=self.s.settings,
            trust=self.s.trust, bot_trust=self.bot_trust, trust_store=self.s.trust_store, bot_trust_store=self.bots)
        self.panel = self.make_panel(None)

    def make_panel(self, ttl):
        kw = {} if ttl == "default" else {"ttl_seconds": ttl}
        return PanelService(permissions=self.s.perm, licenses=self.s.license_service, commands=self.svc,
                            audit=self.s.audit, secret=SECRET, clock=self.s.clock, **kw)

    async def settings(self):
        return ProtectionSettings.from_raw(await self.raw())


# ----------------------------------------------------------------------------- protection screen
class ProtectScreenTests(Base):
    async def test_the_screen_shows_the_effective_values_a_hint_and_signed_owner_bound_buttons(self):
        out = await self.do(pa.TOPIC_PROTECT)
        self.assertEqual((out.status, out.alert, out.delete), ("topic", False, False))
        text, _ = await self.svc.panel_topic(pa.TOPIC_PROTECT, self.g, "ar")
        self.assertIn(text, out.text)
        self.assertIn("/protect", out.text)
        for row in out.buttons:
            for _, data in row:
                cb = codec.parse(data)
                self.assertEqual(cb.owner_id, TG_ADMIN)
                self.assertTrue(codec.verify(KEY, self.g, cb))
        shown = tps.screens_of(out.buttons)
        self.assertEqual(shown[-2:], ["home", "close"])
        self.assertTrue(all(pa.ACTIONS[s].topic == pa.TOPIC_PROTECT for s in shown if s in pa.ACTIONS))

    async def test_the_text_is_the_same_text_the_protect_command_shows(self):
        out = await self.do(pa.TOPIC_PROTECT)
        raw = await self.raw()
        self.assertIn(sc.render_lines(ProtectionSettings.from_raw(raw), sc.TOPIC_ORDER, "ar"), out.text)

    async def test_toggles_offer_the_opposite_and_mark_the_current_choice(self):
        shown = lambda out: tps.screens_of(out.buttons)  # noqa: E731
        out = await self.do(pa.TOPIC_PROTECT)
        for on, off, default_on in (("lkon", "lkoff", True), ("invon", "invoff", False),
                                    ("floon", "flooff", True), ("dupon", "dupoff", True)):
            self.assertEqual([s for s in shown(out) if s in (on, off)], [off if default_on else on], on)
        marked = [label for label in tps.labels(out.buttons) if label.startswith("✅")]
        self.assertTrue(any("6" in m for m in marked))          # default flood threshold
        self.assertTrue(any("3" in m for m in marked))          # default warn limit
        await self.do("flooff")
        self.assertIn("floon", shown(await self.do(pa.TOPIC_PROTECT)))

    async def test_the_warn_length_row_exists_only_for_mute_and_ban(self):
        shown = lambda out: tps.screens_of(out.buttons)  # noqa: E731
        self.assertIn("wsday", shown(await self.do(pa.TOPIC_PROTECT)))           # default: mute for a day
        await self.do("wakick")
        out = await self.do(pa.TOPIC_PROTECT)
        self.assertFalse({"wsforev", "wshour", "wsday", "wsweek"} & set(shown(out)))
        await self.do("waban")
        self.assertIn("wsforev", shown(await self.do(pa.TOPIC_PROTECT)))

    async def test_a_moderator_delegate_reads_but_gets_no_write_buttons(self):
        await self.s.delegations.grant(OWNER, self.g, DELEGATE, GroupRole.MODERATOR)
        out = await self.do(pa.TOPIC_PROTECT, owner=DELEGATE)
        self.assertEqual((out.status, tps.screens_of(out.buttons)), ("topic", ["home", "close"]))
        self.assertIn("🔒", out.text)

    async def test_a_group_manager_delegate_gets_the_write_buttons(self):
        await self.s.delegations.grant(OWNER, self.g, DELEGATE, GroupRole.GROUP_MANAGER)
        out = await self.do(pa.TOPIC_PROTECT, owner=DELEGATE)
        self.assertIn("lkoff", tps.screens_of(out.buttons))
        self.assertNotIn("🔒", out.text)

    async def test_reading_writes_claims_and_audits_nothing(self):
        before = await self.snapshot()
        await self.do(pa.TOPIC_PROTECT)
        await self.do(pa.TOPIC_TRUST)
        await self.untouched(*before)

    async def test_english_screen(self):
        out = await self.panel.press(self.g, "supergroup", TG_ADMIN, codec.build(KEY, self.g, TG_ADMIN, "protect"), "en", "q1")
        self.assertIn("Protection", out.text)
        self.assertTrue(any("Links" in label for label in tps.labels(out.buttons)))

    async def test_an_unreadable_store_never_shows_default_values(self):
        async def boom(*a, **k):
            raise RuntimeError("store down")
        real, self.s.settings_store.get = self.s.settings_store.get, boom
        try:
            out = await self.do(pa.TOPIC_PROTECT)
        finally:
            self.s.settings_store.get = real
        self.assertEqual((out.status, out.alert, out.text, out.buttons), ("unavailable", True, None, None))


# ----------------------------------------------------------------------------- protection writes
class ProtectWriteTests(Base):
    async def test_every_protect_action_ends_with_its_value_and_changes_nothing_else(self):
        for name, spec in PROTECT_ACTIONS.items():
            with self.subTest(action=name):
                before = await self.raw()
                out = await self.do(name)
                self.assertIn(out.status, ("saved", "noop"), name)
                after = await self.raw()
                cfg = ProtectionSettings.from_raw(after)
                for key, value in spec.patch.items():
                    self.assertEqual(getattr(cfg, key), value, f"{name}:{key}")
                self.assertEqual({k: v for k, v in after.items() if k not in spec.patch},
                                 {k: v for k, v in before.items() if k not in spec.patch}, name)

    async def test_a_change_saves_audits_key_names_only_and_redraws_the_protect_screen(self):
        out = await self.do("lkoff")
        self.assertEqual((out.status, out.toast, out.alert), ("saved", "تم الحفظ ✅", False))
        self.assertFalse((await self.settings()).links_enabled)
        self.assertIn("lkon", tps.screens_of(out.buttons))
        (event,) = self.changed()
        self.assertEqual((event.actor_telegram_id, event.detail), (TG_ADMIN, "keys=links_enabled"))

    async def test_the_claim_key_is_the_group_and_the_callback_id(self):
        await self.do("floon", query_id="55555")
        self.assertEqual(list(self.claims._keys), [f"op:panel:{self.g}:55555"])

    async def test_the_value_already_set_changes_nothing_but_refreshes(self):
        await self.do("wlfive")
        events, raw = len(self.s.audit.events), await self.raw()
        out = await self.do("wlfive")
        self.assertEqual((out.status, out.alert, out.toast), ("noop", False, "لا تغيير: الإعداد بهذه القيمة بالفعل."))
        self.assertEqual((await self.raw(), len(self.s.audit.events)), (raw, events))
        self.assertTrue(out.text)

    async def test_the_default_value_is_compared_with_the_stored_one_not_assumed(self):
        out = await self.do("lkon")                      # links are ON by default and nothing is stored yet
        self.assertEqual(out.status, "noop")
        self.assertEqual(await self.raw(), {})

    async def test_a_redelivered_press_writes_and_audits_once_and_shows_nothing(self):
        await self.do("lkoff", query_id="same")
        raw, events = await self.raw(), len(self.s.audit.events)
        out = await self.do("lkon", query_id="same")
        self.assertEqual((out.status, out.text, out.buttons, out.toast), ("duplicate", None, None, ""))
        self.assertEqual((await self.raw(), len(self.s.audit.events)), (raw, events))

    async def test_a_press_without_a_valid_callback_id_never_writes(self):
        before = await self.snapshot()
        for bad in (None, "", 5, True, "a b", "a/b", "x" * 65):
            out = await self.do("lkoff", query_id=bad)
            self.assertEqual((out.status, out.alert, out.text), ("unavailable", True, None), repr(bad))
        await self.untouched(*before)

    async def test_a_hand_built_write_by_a_read_only_delegate_is_refused_for_every_protect_action(self):
        await self.s.delegations.grant(OWNER, self.g, DELEGATE, GroupRole.MODERATOR)
        before = await self.snapshot()
        for name in PROTECT_ACTIONS:
            out = await self.do(name, owner=DELEGATE)
            self.assertEqual((out.status, out.alert, out.text), ("not_manager", True, None), name)
        await self.untouched(*before)

    async def test_every_blocked_license_state_refuses_the_protect_screen_and_every_write(self):
        for state in BLOCKED_STATES:
            with self.subTest(state=state):
                g = await self.group_in(state)
                real = self.break_store() if state == "store_down" else self.s.licenses.get
                before = (dict(self.claims._keys), len(self.s.audit.events))
                try:
                    for screen in (pa.TOPIC_PROTECT, pa.TOPIC_TRUST, *PROTECT_ACTIONS):
                        out = await self.do(screen, group=g)
                        self.assertIn(out.status, ("license_off", "unavailable"), (state, screen))
                        self.assertEqual((out.alert, out.text, out.delete), (True, None, False), (state, screen))
                finally:
                    self.s.licenses.get = real
                self.assertIsNone(await self.s.settings_store.get(g))
                self.assertEqual((dict(self.claims._keys), len(self.s.audit.events)), before)

    async def test_protect_writes_work_in_dry_run_and_never_touch_dry_run_itself(self):
        await self.s.settings_store.merge(self.g, {"dry_run": True}, OWNER, self.s.clock())
        self.assertEqual((await self.do("lkoff")).status, "saved")
        raw = await self.raw()
        self.assertIs(raw["dry_run"], True)
        for name in PROTECT_ACTIONS:
            await self.do(name)
        self.assertIs((await self.raw())["dry_run"], True)

    async def test_the_domain_list_and_escalation_survive_every_button(self):
        await self.s.settings_store.merge(self.g, {"links_allow_domains": ["example.com"],
                                                   "escalation_mutes_seconds": [120, 240]}, OWNER, self.s.clock())
        for name in PROTECT_ACTIONS:
            await self.do(name)
        raw = await self.raw()
        self.assertEqual((raw["links_allow_domains"], raw["escalation_mutes_seconds"]), (["example.com"], [120, 240]))

    async def test_the_panel_write_equals_the_command_write(self):
        other = await self.active_group()
        await self.do("flooff")
        from guardian.moderation.commands import parse_command
        from executor_stack import gate
        parsed = parse_command("/protect flood off", "GuardianBot")
        res = await self.svc.handle(parsed, chat_id=other, actor_id=TG_ADMIN, message_id=7, protection=gate(other, TG_ADMIN))
        self.assertEqual(res.kind.value, "done")
        a, b = await self.raw(), await self.raw(other)
        self.assertEqual({k: a.get(k) for k in ("flood_enabled",)}, {k: b.get(k) for k in ("flood_enabled",)})

    async def test_settings_of_another_group_are_untouched(self):
        other = await self.active_group()
        await self.do("lkoff")
        self.assertEqual(await self.raw(other), {})

    async def test_a_store_failure_during_a_write_never_writes_defaults(self):
        async def boom(*a, **k):
            raise RuntimeError("store down")
        await self.do("lkoff")
        raw = await self.raw()
        real, self.s.settings_store.get = self.s.settings_store.get, boom
        try:
            out = await self.do("lkon")
        finally:
            self.s.settings_store.get = real
        self.assertEqual((out.status, out.alert, out.text), ("unavailable", True, None))
        self.assertEqual(await self.raw(), raw)


class ServiceLevelGuardTests(Base):
    async def test_panel_write_refuses_keys_outside_the_whitelist_before_any_claim(self):
        for patch in ({"dry_run": True}, {"links_allow_domains": []}, {"links_enabled": False, "dry_run": True}, {}, None, ["x"]):
            with self.assertRaises(ValueError):
                await self.svc.panel_write(pa.TOPIC_PROTECT, patch, self.g, TG_ADMIN, "op:g:1", "ar")
        self.assertEqual(self.claims._keys, {})
        self.assertEqual(await self.raw(), {})

    async def test_the_trust_screen_has_no_write_path(self):
        with self.assertRaises(ValueError):
            await self.svc.panel_write(pa.TOPIC_TRUST, {"links_allow_domains": ["x.com"]}, self.g, TG_ADMIN, "op:g:2", "ar")
        self.assertEqual(self.claims._keys, {})

    async def test_a_denied_manager_check_raises_before_the_claim(self):
        from guardian.errors import PermissionDenied
        with self.assertRaises(PermissionDenied):
            await self.svc.panel_write(pa.TOPIC_PROTECT, {"links_enabled": False}, self.g, 424242, "op:g:3", "ar")
        self.assertEqual(self.claims._keys, {})

    async def test_without_the_strict_reader_the_panel_fails_closed(self):
        self.svc._config._load_raw = None
        with self.assertRaises(RuntimeError):
            await self.svc.panel_topic(pa.TOPIC_PROTECT, self.g, "ar")
        out = await self.do("lkoff")
        self.assertEqual((out.status, out.alert), ("unavailable", True))
        self.assertEqual(await self.raw(), {})


# ----------------------------------------------------------------------------- trust screen
class TrustScreenTests(Base):
    async def fill(self):
        await self.s.trust_store.add(self.g, 5551, OWNER, self.s.clock()) if hasattr(self.s.trust_store, "add") else None

    async def test_the_screen_lists_users_domains_and_bots_from_the_real_stores(self):
        await self.s.trust.add(TG_ADMIN, self.g, 7771, None, context_chat_id=self.g)
        await self.bot_trust.add(TG_ADMIN, self.g, 8881, None, context_chat_id=self.g)
        await self.s.settings_store.merge(self.g, {"links_allow_domains": ["example.com"]}, OWNER, self.s.clock())
        out = await self.do(pa.TOPIC_TRUST)
        self.assertEqual((out.status, out.alert, out.delete), ("topic", False, False))
        for needle in ("7771", "8881", "example.com", "/trust"):
            self.assertIn(needle, out.text)
        self.assertEqual(tps.screens_of(out.buttons), ["home", "close"])
        self.assertNotIn("🔒", out.text)

    async def test_it_shows_the_same_lists_the_trusted_command_shows(self):
        await self.s.trust.add(TG_ADMIN, self.g, 7771, None, context_chat_id=self.g)
        from guardian.moderation.commands import parse_command
        from executor_stack import gate
        cmd = await self.svc.handle(parse_command("/trusted", "GuardianBot"), chat_id=self.g, actor_id=TG_ADMIN,
                                    message_id=3, protection=gate(self.g, TG_ADMIN))
        out = await self.do(pa.TOPIC_TRUST)
        self.assertIn("7771", cmd.text)
        self.assertIn("7771", out.text)
        self.assertIn("<code>7771</code>", out.text)

    async def test_a_moderator_delegate_can_read_it(self):
        await self.s.delegations.grant(OWNER, self.g, DELEGATE, GroupRole.MODERATOR)
        self.assertEqual((await self.do(pa.TOPIC_TRUST, owner=DELEGATE)).status, "topic")

    async def test_it_is_per_group(self):
        other = await self.active_group()
        await self.s.trust.add(TG_ADMIN, other, 7772, None, context_chat_id=other)
        self.assertNotIn("7772", (await self.do(pa.TOPIC_TRUST)).text)

    async def test_the_worst_case_text_fits_one_telegram_message(self):
        worst = [f"{'a' * 61}.{'b' * 61}.{'c' * 61}.{'d' * 56}{i:02d}.com" for i in range(100)]
        self.assertTrue(all(len(d) <= 253 for d in worst))
        await self.s.settings_store.merge(self.g, {"links_allow_domains": worst}, OWNER, self.s.clock())
        for uid in range(1, 201):
            await self.s.trust_store.add(self.g, 10**15 + uid, OWNER, None, self.s.clock()) if False else None
        out = await self.do(pa.TOPIC_TRUST)
        self.assertEqual(out.status, "topic")
        self.assertLess(len(out.text), 4096)
        self.assertEqual(out.text.count(".com"), 10)                  # 10 of the 100 domains, the rest summarised

    async def test_an_unreadable_list_never_shows_an_empty_one(self):
        async def boom(*a, **k):
            raise RuntimeError("store down")
        for target in ("trust", "settings", "bots"):
            real = {"trust": (self.s.trust_store, "list"), "settings": (self.s.settings_store, "get"),
                    "bots": (self.bots, "list")}[target]
            original = getattr(real[0], real[1])
            setattr(real[0], real[1], boom)
            try:
                out = await self.do(pa.TOPIC_TRUST)
            finally:
                setattr(real[0], real[1], original)
            self.assertEqual((out.status, out.alert, out.text, out.buttons), ("unavailable", True, None, None), target)

    async def test_without_trust_stores_it_fails_closed(self):
        self.svc._trust._trust_store = None
        out = await self.do(pa.TOPIC_TRUST)
        self.assertEqual((out.status, out.alert), ("unavailable", True))

    async def test_an_admin_without_the_moderation_right_gets_nothing(self):
        out = await self.do(pa.TOPIC_TRUST, owner=424242)
        self.assertEqual((out.status, out.text), ("not_admin", None))

    async def test_english(self):
        out = await self.panel.press(self.g, "supergroup", TG_ADMIN, codec.build(KEY, self.g, TG_ADMIN, "trust"), "en", "q1")
        self.assertIn("Trust lists", out.text)
        self.assertIn("/untrust", out.text)


# ----------------------------------------------------------------------------- expiry
class ExpiryTests(Base):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.panel = self.make_panel("default")
        self.now = self.s.clock()

    async def at(self, screen, age, *, owner=TG_ADMIN, group=None, qid="auto", date="age"):
        group = self.g if group is None else group
        sent = self.now - timedelta(seconds=age) if date == "age" else date
        return await self.panel.press(group, "supergroup", owner, codec.build(KEY, group, owner, screen), "ar",
                                      self.qid() if qid == "auto" else qid, sent)

    def test_the_default_lifetime_is_thirty_minutes_and_bad_values_are_refused(self):
        self.assertEqual(ps.PANEL_TTL_SECONDS, 1800)
        self.assertEqual(self.panel._ttl, timedelta(seconds=1800))
        for bad in (0, -5, True, "60", 1.5):
            with self.assertRaises(ValueError):
                self.make_panel(bad)
        self.assertIsNone(self.make_panel(None)._ttl)

    async def test_the_boundaries(self):
        self.assertEqual((await self.at("home", 0)).status, "home")
        self.assertEqual((await self.at("home", 1799)).status, "home")
        self.assertEqual((await self.at("home", 1800)).status, "home")
        self.assertEqual((await self.at("home", 1801)).status, "expired")
        self.assertEqual((await self.at("home", 10**7)).status, "expired")

    async def test_a_date_slightly_in_the_future_is_clock_skew_but_far_in_the_future_is_not_trusted(self):
        self.assertEqual((await self.at("home", -299)).status, "home")
        self.assertEqual((await self.at("home", -300)).status, "home")
        self.assertEqual((await self.at("home", -301)).status, "expired")
        self.assertEqual((await self.at("home", -(10**6))).status, "expired")

    async def test_an_unknown_or_unusable_date_is_expired_never_fresh(self):
        naive = (self.now - timedelta(seconds=5)).replace(tzinfo=None)
        for bad in (None, 0, 1_700_000_000, "2026-10-31", b"x", naive, [self.now], object(),
                    datetime(1970, 1, 1, tzinfo=UTC)):
            out = await self.at("home", 0, date=bad)
            self.assertEqual(out.status, "expired", repr(bad))

    async def test_a_timezone_that_fails_while_converting_is_expired_never_fresh(self):
        from datetime import tzinfo

        class Flaky(tzinfo):
            calls = 0

            def utcoffset(self, dt):
                Flaky.calls += 1
                if Flaky.calls > 1:
                    raise RuntimeError("tz database broke")
                return timedelta(0)

            def dst(self, dt):
                return None

            def tzname(self, dt):
                return "X"
        out = await self.at("home", 0, date=self.now.replace(tzinfo=Flaky()))
        self.assertEqual(out.status, "expired")

    async def test_other_timezones_are_compared_in_utc(self):
        plus3 = timezone(timedelta(hours=3))
        self.assertEqual((await self.at("home", 0, date=(self.now - timedelta(seconds=10)).astimezone(plus3))).status, "home")
        self.assertEqual((await self.at("home", 0, date=(self.now - timedelta(seconds=2000)).astimezone(plus3))).status, "expired")

    async def test_an_expired_press_replaces_the_panel_with_a_notice_without_buttons(self):
        out = await self.at("home", 2000)
        self.assertEqual((out.status, out.alert, out.delete, out.buttons), ("expired", True, False, None))
        self.assertIn("/panel", out.text)
        self.assertEqual(out.toast, out.text)

    async def test_an_expired_panel_changes_nothing_for_every_screen_and_action(self):
        before = await self.snapshot()
        for screen in (*pa.TOPICS, *pa.ACTIONS, codec.SCREEN_HOME):
            out = await self.at(screen, 5000)
            self.assertEqual((out.status, out.delete, out.buttons), ("expired", False, None), screen)
        await self.untouched(*before)

    async def test_the_same_write_works_fresh_and_dies_stale(self):
        stale = await self.at("lkoff", 4000)
        self.assertEqual(stale.status, "expired")
        self.assertTrue((await self.settings()).links_enabled)
        fresh = await self.at("lkoff", 4)
        self.assertEqual(fresh.status, "saved")
        self.assertFalse((await self.settings()).links_enabled)

    async def test_closing_still_works_on_an_expired_panel(self):
        out = await self.at(codec.SCREEN_CLOSE, 5000)
        self.assertEqual((out.status, out.delete), ("closed", True))

    async def test_expiry_never_hides_an_earlier_refusal(self):
        stranger = 424242
        self.assertEqual((await self.at("home", 5000, owner=stranger)).status, "not_admin")
        other = await self.panel.press(self.g, "supergroup", 900_099, codec.build(KEY, self.g, TG_ADMIN, "home"), "ar", "q", None)
        self.assertEqual(other.status, "not_owner")
        forged = await self.panel.press(self.g, "supergroup", TG_ADMIN, "pn:%d:home:%s" % (TG_ADMIN, "0" * 12), "ar", "q", None)
        self.assertEqual(forged.status, "forged")
        g = await self.group_in("stopped")
        self.assertEqual((await self.at("home", 5000, group=g)).status, "license_off")

    async def test_an_expired_press_is_not_audited(self):
        n = len(self.s.audit.events)
        await self.at("lkoff", 5000)
        self.assertEqual(len(self.s.audit.events), n)

    async def test_the_clock_is_the_services_clock(self):
        clock = {"now": self.now}
        panel = PanelService(permissions=self.s.perm, licenses=self.s.license_service, commands=self.svc,
                             audit=self.s.audit, secret=SECRET, clock=lambda: clock["now"])
        data = codec.build(KEY, self.g, TG_ADMIN, "home")
        self.assertEqual((await panel.press(self.g, "supergroup", TG_ADMIN, data, "ar", "q", self.now)).status, "home")
        clock["now"] = self.now + timedelta(seconds=1801)
        self.assertEqual((await panel.press(self.g, "supergroup", TG_ADMIN, data, "ar", "q", self.now)).status, "expired")

    async def test_a_broken_clock_fails_closed(self):
        def bad():
            raise RuntimeError("clock")
        panel = PanelService(permissions=self.s.perm, licenses=self.s.license_service, commands=self.svc,
                             audit=self.s.audit, secret=SECRET, clock=bad)
        before = await self.snapshot()
        out = await panel.press(self.g, "supergroup", TG_ADMIN, codec.build(KEY, self.g, TG_ADMIN, "lkoff"), "ar", "q", self.now)
        self.assertIn(out.status, ("expired", "unavailable"))   # the license check reads the same clock: never "saved"
        self.assertTrue(out.alert)
        await self.untouched(*before)


class ExpiryHandlerTests(Base):
    class Msg:
        def __init__(self, chat, date):
            self.chat = NS(id=chat, type=NS(value="supergroup"))
            self.date = date
            self.edits, self.deleted = [], 0

        async def edit_text(self, text, reply_markup=None):
            self.edits.append((text, reply_markup))

        async def delete(self):
            self.deleted += 1

    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.panel = self.make_panel("default")

    def query(self, msg, screen="home", qid="cb1"):
        return NS(id=qid, data=codec.build(KEY, self.g, TG_ADMIN, screen), message=msg,
                  from_user=NS(id=TG_ADMIN, language_code="ar"))

    def svcs(self):
        return NS(settings=NS(default_language="ar"), panel=self.panel)

    async def test_a_fresh_panel_is_edited_in_place(self):
        m = self.Msg(self.g, self.s.clock() - timedelta(seconds=30))
        toast = await ph.on_panel_callback(self.query(m), self.svcs(), fake_markup)
        self.assertEqual(toast[1], False)
        (text, markup), = m.edits
        self.assertEqual(markup[0], "MARKUP")

    async def test_a_stale_panel_is_replaced_by_the_notice_and_loses_its_keyboard(self):
        m = self.Msg(self.g, self.s.clock() - timedelta(hours=3))
        toast = await ph.on_panel_callback(self.query(m), self.svcs(), fake_markup)
        self.assertEqual(toast[1], True)
        (text, markup), = m.edits
        self.assertIn("/panel", text)
        self.assertIsNone(markup)

    async def test_a_message_without_a_usable_date_is_stale(self):
        for date in (None, datetime(1970, 1, 1, tzinfo=UTC), 0):
            m = self.Msg(self.g, date)
            toast = await ph.on_panel_callback(self.query(m), self.svcs(), fake_markup)
            self.assertTrue(toast[1], repr(date))
            self.assertIsNone(m.edits[0][1])

    async def test_a_stale_write_through_the_handler_writes_nothing(self):
        before = await self.snapshot()
        m = self.Msg(self.g, self.s.clock() - timedelta(hours=3))
        await ph.on_panel_callback(self.query(m, "lkoff"), self.svcs(), fake_markup)
        await self.untouched(*before)

    async def test_a_message_object_with_no_date_attribute_is_stale(self):
        m = self.Msg(self.g, None)
        del m.date
        toast = await ph.on_panel_callback(self.query(m), self.svcs(), fake_markup)
        self.assertTrue(toast[1])


# ----------------------------------------------------------------------------- home
class HomeTests(Base):
    async def test_home_offers_every_screen_once(self):
        out = await self.do(codec.SCREEN_HOME)
        shown = tps.screens_of(out.buttons)
        self.assertEqual(shown, ["welcome", "verify", "newbie", "protect", "trust", "home", "close"])
        self.assertEqual(sorted(set(pa.TOPICS)), sorted(s for s in shown if s in pa.TOPICS))

    async def test_every_home_button_is_signed_for_the_owner_and_the_group(self):
        out = await self.do(codec.SCREEN_HOME)
        for row in out.buttons:
            for _, data in row:
                cb = codec.parse(data)
                self.assertEqual(cb.owner_id, TG_ADMIN)
                self.assertTrue(codec.verify(KEY, self.g, cb))
                self.assertFalse(codec.verify(KEY, self.g - 1, cb))


if __name__ == "__main__":
    unittest.main()
