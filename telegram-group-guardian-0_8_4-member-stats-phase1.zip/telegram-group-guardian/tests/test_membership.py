import unittest
from datetime import datetime, timezone

from guardian.licensing.memory_store import InMemoryLicenseStore
from guardian.licensing.models import GroupLicense, LicenseStatus
from guardian.licensing.service import LicenseService
from guardian.membership import handle_bot_added, was_bot_added
from helpers import FakeNotifier

NOW = datetime(2026, 10, 29, 12, 0, tzinfo=timezone.utc)
G = -100123


class WasBotAddedTests(unittest.TestCase):
    def test_table(self):
        cases = [
            ("left", "member", True),
            ("kicked", "administrator", True),
            (None, "member", True),
            ("member", "administrator", False),  # promotion, not an addition
            ("administrator", "member", False),
            ("member", "left", False),
            ("member", "kicked", False),
            ("left", "kicked", False),
        ]
        for old, new, expected in cases:
            with self.subTest(old=old, new=new):
                self.assertEqual(was_bot_added(old, new), expected)


class HandleBotAddedTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.store = InMemoryLicenseStore()
        self.service = LicenseService(self.store)
        self.notifier = FakeNotifier()

    async def test_first_add_registers_pending_and_notifies_once(self):
        out = await handle_bot_added(self.service, self.notifier, group_id=G, title="Team <b>X</b>")
        self.assertTrue(out.created)
        self.assertIs(out.status, LicenseStatus.PENDING)
        self.assertEqual(len(self.notifier.group_messages), 1)
        self.assertEqual(len(self.notifier.owner_messages), 1)
        self.assertIn("&lt;b&gt;X&lt;/b&gt;", self.notifier.owner_messages[0])
        self.assertFalse((await self.service.check(G, NOW)).allowed)

    async def test_second_add_is_silent_and_changes_nothing(self):
        await handle_bot_added(self.service, self.notifier, group_id=G, title="T")
        out = await handle_bot_added(self.service, self.notifier, group_id=G, title="T")
        self.assertFalse(out.created)
        self.assertEqual(len(self.notifier.group_messages), 1)
        self.assertEqual(len(self.notifier.owner_messages), 1)

    async def test_banned_group_stays_banned_after_readd(self):
        self.store._rows[G] = GroupLicense(group_id=G, title="T", status=LicenseStatus.BANNED, updated_at=NOW)
        out = await handle_bot_added(self.service, self.notifier, group_id=G, title="T")
        self.assertFalse(out.created)
        self.assertIs(out.status, LicenseStatus.BANNED)
        self.assertEqual(self.notifier.group_messages, [])
        self.assertFalse((await self.service.check(G, NOW)).allowed)

    async def test_notification_failure_does_not_break_registration(self):
        out = await handle_bot_added(self.service, FakeNotifier(fail=True), group_id=G, title="T")
        self.assertTrue(out.created)
        self.assertIs((await self.store.get(G)).status, LicenseStatus.PENDING)

    async def test_store_failure_reports_error_and_does_not_raise(self):
        async def boom(*a, **k):
            raise RuntimeError("db down")

        self.store.register_pending_if_absent = boom
        out = await handle_bot_added(self.service, self.notifier, group_id=G, title="T")
        self.assertTrue(out.store_error)
        self.assertFalse(out.created)
        self.assertEqual(len(self.notifier.owner_messages), 1)
        self.assertEqual(self.notifier.group_messages, [])


if __name__ == "__main__":
    unittest.main()
