"""Phase 6 / part 6.2: audit retention (config, service, lazy tick, SQL path) + the audit gaps closed in this part."""
from __future__ import annotations

import re
import unittest
from datetime import timedelta
from pathlib import Path

import helpers  # noqa: F401
from executor_stack import A, USER, ExecBase
from guardian.audit import (AUDIT_PURGED, COMMAND_REJECTED, REGISTRATION_FAILED, SANCTION_LIFTED, InMemorySecurityAudit,
                            PostgresSecurityAudit, make_event)
from guardian.audit_retention import BATCH_SIZE, MAX_BATCHES, PURGE_INTERVAL, AuditRetentionService
from guardian.config import load_settings
from guardian.db.migrations import SQL_DIR, discover
from guardian.errors import ConfigError
from guardian.membership import handle_bot_added
from guardian.moderation.executor import ResultKind as R
from stack import NOW, STRANGER, TG_ADMIN, Clock

ROOT = Path(__file__).resolve().parents[1]
BASE_ENV = {"BOT_TOKEN": "123456:ABCdefGHIjklMNOpqrsTUVwxyz0123456789", "DATABASE_URL": "postgresql://u:p@h/d",
            "OWNER_TELEGRAM_ID": "1", "WEBHOOK_SECRET": "s" * 32}


class Mono:
    def __init__(self):
        self.t = 1000.0

    def __call__(self):
        return self.t


async def fill(audit, n, age_days, clock_now=NOW, group=-1):
    for i in range(n):
        await audit.record(make_event("x", group_id=group, detail=str(i), now=clock_now - timedelta(days=age_days)))


class ConfigTests(unittest.TestCase):
    def test_default_is_180(self):
        self.assertEqual(load_settings(dict(BASE_ENV)).audit_retention_days, 180)

    def test_valid_values_and_bounds(self):
        for v, ok in (("30", True), ("730", True), ("365", True), ("29", False), ("731", False), ("0", False),
                      ("-5", False), ("abc", False), ("1.5", False)):
            env = dict(BASE_ENV, AUDIT_RETENTION_DAYS=v)
            if ok:
                self.assertEqual(load_settings(env).audit_retention_days, int(v), v)
            else:
                with self.assertRaises(ConfigError, msg=v):
                    load_settings(env)


class ServiceTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.audit, self.clock, self.mono = InMemorySecurityAudit(), Clock(), Mono()
        self.svc = AuditRetentionService(self.audit, 90, clock=self.clock, mono=self.mono)

    async def test_days_are_validated(self):
        for bad in (29, 731, 0, -1, True, "90", 90.0, None):
            with self.assertRaises(ValueError, msg=repr(bad)):
                AuditRetentionService(self.audit, bad)

    async def test_only_rows_older_than_the_window_go(self):
        await fill(self.audit, 3, 100)
        await fill(self.audit, 2, 89)
        await fill(self.audit, 1, 91)
        self.assertEqual(await self.svc.purge(), 4)
        self.assertEqual(len([e for e in self.audit.events if e.event_type == "x"]), 2)

    async def test_a_purge_leaves_one_audit_row_with_counts_only(self):
        await fill(self.audit, 3, 100)
        await self.svc.purge()
        (ev,) = [e for e in self.audit.events if e.event_type == AUDIT_PURGED]
        self.assertEqual(ev.result, "applied")
        self.assertIn("count=3", ev.detail)
        self.assertIn("days=90", ev.detail)
        self.assertNotIn("0", ev.detail.split("before=")[0].replace("count=3", ""))  # no row contents

    async def test_nothing_to_purge_writes_nothing(self):
        await fill(self.audit, 2, 10)
        self.assertEqual(await self.svc.purge(), 0)
        self.assertEqual([e.event_type for e in self.audit.events], ["x", "x"])

    async def test_backlog_is_bounded_per_run_then_continues_next_run(self):
        await fill(self.audit, BATCH_SIZE * MAX_BATCHES + 10, 200)
        self.assertEqual(await self.svc.purge(), BATCH_SIZE * MAX_BATCHES)
        self.assertEqual(await self.svc.purge(), 10)

    async def test_tick_is_throttled_runs_first_then_after_the_interval(self):
        await fill(self.audit, 2, 200)
        self.assertEqual(await self.svc.tick(), 2)
        await fill(self.audit, 2, 200)
        self.assertEqual(await self.svc.tick(), 0)        # throttled
        self.mono.t += PURGE_INTERVAL - 1
        self.assertEqual(await self.svc.tick(), 0)
        self.mono.t += 2
        self.assertEqual(await self.svc.tick(), 2)

    async def test_tick_never_raises_and_a_failure_still_throttles(self):
        class Boom(InMemorySecurityAudit):
            async def purge_before(self, cutoff, limit):
                raise RuntimeError("db down")
        svc = AuditRetentionService(Boom(), 90, clock=self.clock, mono=self.mono)
        self.assertEqual(await svc.tick(), 0)
        self.assertEqual(await svc.tick(), 0)

    async def test_tick_does_not_run_two_purges_at_once(self):
        import asyncio
        gate, calls = asyncio.Event(), []

        class Slow(InMemorySecurityAudit):
            async def purge_before(self, cutoff, limit):
                calls.append(1)
                await gate.wait()
                return 0
        svc = AuditRetentionService(Slow(), 90, clock=self.clock, mono=self.mono)
        first = asyncio.create_task(svc.tick())
        await asyncio.sleep(0)
        self.mono.t += PURGE_INTERVAL * 2
        self.assertEqual(await svc.tick(), 0)
        gate.set()
        await first
        self.assertEqual(len(calls), 1)


class FakeConn:
    def __init__(self, value=7):
        self.calls, self.value = [], value

    async def fetchval(self, sql, *args):
        self.calls.append((sql, args))
        return self.value


class FakeDb:
    def __init__(self, conn):
        self.conn = conn

    def acquire(self):
        conn = self.conn

        class Ctx:
            async def __aenter__(self_):
                return conn

            async def __aexit__(self_, *a):
                return False
        return Ctx()


class PostgresPathTests(unittest.IsolatedAsyncioTestCase):
    async def test_purge_calls_only_the_sql_function(self):
        conn = FakeConn(7)
        n = await PostgresSecurityAudit(FakeDb(conn)).purge_before(NOW, 500)
        self.assertEqual(n, 7)
        sql, args = conn.calls[0]
        self.assertEqual(sql, "SELECT guardian_purge_security_audit($1, $2)")
        self.assertEqual(args, (NOW, 500))

    async def test_no_python_code_deletes_from_the_audit_tables_directly(self):
        for p in (ROOT / "src").rglob("*.py"):
            text = p.read_text(encoding="utf-8")
            self.assertNotRegex(text, r"(?i)DELETE\s+FROM\s+(security|license)_audit_log", p.name)
            self.assertNotRegex(text, r"(?i)TRUNCATE\s+(security|license)_audit_log", p.name)

    async def test_the_license_log_is_never_referenced_by_retention(self):
        for path in (ROOT / "src/guardian/audit_retention.py", SQL_DIR / "0007_audit_retention.sql"):
            code = "\n".join(l for l in path.read_text(encoding="utf-8").splitlines()
                             if not l.strip().startswith(("--", "#")))
            code = re.sub(r'""".*?"""', "", code, flags=re.S)
            self.assertNotIn("license_audit_log", code, path.name)


class MigrationTests(unittest.TestCase):
    sql = (SQL_DIR / "0007_audit_retention.sql").read_text(encoding="utf-8")

    def test_it_follows_0006(self):
        self.assertEqual([v for v, _ in discover()][6:7], ["0007_audit_retention"])

    def test_0006_is_not_edited(self):
        import hashlib
        self.assertEqual(hashlib.sha256((SQL_DIR / "0006_audit_trace.sql").read_bytes()).hexdigest(),
                         "27e6ebd3783a7acff433076e4c07195bd8da2a17db58f9c214575d5324e8bbc7")

    def test_the_guard_forbids_update_and_only_allows_the_flagged_old_delete(self):
        self.assertIn("TG_OP = 'DELETE'", self.sql)
        self.assertIn("current_setting('guardian.audit_purge', true) = 'on'", self.sql)
        self.assertIn("interval '30 days'", self.sql)
        guard = self.sql[self.sql.index("guardian_security_audit_guard() RETURNS"):self.sql.index("DROP TRIGGER")]
        self.assertNotIn("UPDATE", guard.replace("-- ", "").split("RAISE")[0].replace("TG_OP", ""))
        self.assertIn("RAISE EXCEPTION", guard)

    def test_the_purge_function_checks_its_arguments_and_the_flag_is_transaction_local(self):
        self.assertIn("IF p_cutoff IS NULL OR p_cutoff > now() - interval '30 days' THEN", self.sql)
        self.assertIn("cutoff must be at least 30 days old", self.sql)
        self.assertIn("p_max_rows > 10000", self.sql)
        self.assertIn("set_config('guardian.audit_purge', 'on', true)", self.sql)
        self.assertIn("set_config('guardian.audit_purge', 'off', true)", self.sql)

    def test_truncate_trigger_and_license_triggers_are_untouched(self):
        code = "\n".join(l for l in self.sql.splitlines() if not l.strip().startswith("--"))
        self.assertNotIn("TRUNCATE", code.upper().replace("-- ", ""))
        self.assertNotIn("license_audit", code)
        self.assertNotIn("guardian_forbid_modification", code)


class GapTests(ExecBase):
    async def test_license_off_command_is_audited_with_name_only(self):
        self.member(USER)
        r = await self.run_cmd("/ban بسبب سري جدا", reply_to=USER, protection=None)
        self.assertEqual(r.kind, R.LICENSE_OFF)
        (ev,) = [e for e in self.s.audit.events if e.event_type == COMMAND_REJECTED]
        self.assertEqual((ev.detail, ev.target_id, ev.result, ev.actor_telegram_id, ev.group_id),
                         ("license_off", "ban", "denied", TG_ADMIN, A))
        self.assertNotIn("سري", repr(ev))

    async def test_permission_denied_command_is_audited(self):
        self.member(USER)
        r = await self.run_cmd("/ban", actor=STRANGER, reply_to=USER)
        self.assertEqual(r.kind, R.DENIED)
        (ev,) = [e for e in self.s.audit.events if e.event_type == COMMAND_REJECTED]
        self.assertEqual((ev.detail, ev.target_id, ev.actor_telegram_id), ("permission_denied", "ban", STRANGER))
        self.assertEqual(self.actions.calls, [])

    async def test_repeated_rejections_are_throttled_then_audited_again(self):
        self.member(USER)
        for i in range(5):
            await self.run_cmd("/ban", actor=STRANGER, reply_to=USER, msg=10 + i)
        self.assertEqual(len([e for e in self.s.audit.events if e.event_type == COMMAND_REJECTED]), 1)
        self.s.clock.advance(seconds=61)
        await self.run_cmd("/ban", actor=STRANGER, reply_to=USER, msg=30)
        self.assertEqual(len([e for e in self.s.audit.events if e.event_type == COMMAND_REJECTED]), 2)

    async def test_a_different_command_or_actor_is_not_throttled_by_another(self):
        self.member(USER)
        await self.run_cmd("/ban", actor=STRANGER, reply_to=USER, msg=1)
        await self.run_cmd("/kick", actor=STRANGER, reply_to=USER, msg=2)
        self.assertEqual(len([e for e in self.s.audit.events if e.event_type == COMMAND_REJECTED]), 2)

    async def test_successful_commands_write_no_rejection(self):
        self.member(USER)
        self.assertEqual((await self.run_cmd("/ban", reply_to=USER)).kind, R.DONE)
        self.assertNotIn(COMMAND_REJECTED, self.audit_types())

    async def test_unban_without_a_ledger_row_is_audited_as_telegram_only(self):
        self.member(USER, "kicked")  # banned in Telegram, never recorded by the bot
        r = await self.run_cmd("/unban", reply_to=USER)
        self.assertEqual(r.kind, R.DONE)
        (ev,) = [e for e in self.s.audit.events if e.event_type == SANCTION_LIFTED]
        self.assertIn("count=0", ev.detail)
        self.assertIn("telegram_only", ev.detail)
        self.assertEqual((ev.target_id, ev.result), (str(USER), "applied"))

    async def test_unban_with_a_ledger_row_is_audited_once_by_the_service(self):
        self.member(USER)
        await self.run_cmd("/ban", reply_to=USER, msg=1)
        self.member(USER, "kicked")
        await self.run_cmd("/unban", reply_to=USER, msg=2)
        lifted = [e for e in self.s.audit.events if e.event_type == SANCTION_LIFTED]
        self.assertEqual(len(lifted), 1)
        self.assertNotIn("telegram_only", lifted[0].detail)


class RegistrationFailureTests(unittest.IsolatedAsyncioTestCase):
    async def test_a_store_error_is_audited_without_blocking_and_a_success_is_not(self):
        class Boom:
            async def on_bot_added(self, group_id, title):
                raise RuntimeError("db down")

        class Ok:
            async def on_bot_added(self, group_id, title):
                from types import SimpleNamespace as NS
                return NS(status=None), False

        class Notifier:
            async def notify_group(self, *a): pass
            async def notify_owner(self, *a): pass
        audit = InMemorySecurityAudit()
        out = await handle_bot_added(Boom(), Notifier(), group_id=-5, title="T", audit=audit)
        self.assertTrue(out.store_error)
        (ev,) = audit.events
        self.assertEqual((ev.event_type, ev.group_id, ev.target_id, ev.result, ev.detail),
                         (REGISTRATION_FAILED, -5, "-5", "failed", "store_error"))
        await handle_bot_added(Ok(), Notifier(), group_id=-6, title="T", audit=audit)
        self.assertEqual(len(audit.events), 1)

    async def test_without_an_audit_store_nothing_changes(self):
        class Boom:
            async def on_bot_added(self, group_id, title):
                raise RuntimeError("x")

        class Notifier:
            async def notify_group(self, *a): pass
            async def notify_owner(self, *a): pass
        self.assertTrue((await handle_bot_added(Boom(), Notifier(), group_id=-5, title="T")).store_error)


class WiringTests(unittest.TestCase):
    def test_the_tick_runs_retention_and_verification_and_the_app_builds_the_service(self):
        factory = (ROOT / "src/guardian/bot/factory.py").read_text(encoding="utf-8")
        self.assertIn('getattr(services, "audit_retention", None)', factory)
        self.assertIn("for one in ticks:", factory)
        self.assertIn("[x.tick for x in (verification, retention) if x is not None]", factory)
        app = (ROOT / "src/guardian/app.py").read_text(encoding="utf-8")
        self.assertIn("AuditRetentionService(security_audit, settings.audit_retention_days)", app)

    def test_env_example_documents_the_setting(self):
        self.assertIn("AUDIT_RETENTION_DAYS", (ROOT / ".env.example").read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
