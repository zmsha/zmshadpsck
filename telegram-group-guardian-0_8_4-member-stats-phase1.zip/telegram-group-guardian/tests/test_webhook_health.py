import unittest

from guardian.health import build_health
from guardian.webhook import UpdateDeduplicator, verify_secret_token


class SecretTests(unittest.TestCase):
    def test_verify(self):
        self.assertTrue(verify_secret_token("abc", "abc"))
        self.assertFalse(verify_secret_token("abd", "abc"))
        self.assertFalse(verify_secret_token(None, "abc"))
        self.assertFalse(verify_secret_token("", "abc"))
        self.assertFalse(verify_secret_token("abc", ""))
        self.assertFalse(verify_secret_token("ab", "abc"))


class DedupTests(unittest.TestCase):
    def test_duplicate_detection(self):
        d = UpdateDeduplicator(capacity=3)
        self.assertFalse(d.seen_before(1))
        self.assertTrue(d.seen_before(1))
        self.assertFalse(d.seen_before(2))

    def test_bounded_memory_evicts_oldest(self):
        d = UpdateDeduplicator(capacity=2)
        for i in (1, 2, 3):
            d.seen_before(i)
        self.assertFalse(d.seen_before(1))  # evicted earlier, so treated as new

    def test_invalid_capacity(self):
        with self.assertRaises(ValueError):
            UpdateDeduplicator(0)


class HealthTests(unittest.TestCase):
    def test_payload_is_minimal(self):
        self.assertEqual(build_health("ok"), {"status": "ok", "database": "ok"})
        self.assertEqual(build_health("unavailable")["database"], "unavailable")
        self.assertEqual(build_health("weird")["database"], "unknown")
        self.assertEqual(set(build_health("ok")), {"status", "database"})


if __name__ == "__main__":
    unittest.main()
