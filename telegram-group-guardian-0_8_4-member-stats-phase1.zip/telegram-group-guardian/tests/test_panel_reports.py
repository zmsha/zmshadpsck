"""Part 6.4b: the reports screen of the admin panel (read the list, open one report, take / resolve / dismiss).

What must hold: (1) a report button carries a SIGNED numeric argument (report id / page cursor) and nothing else; the
outcome of every move is fixed server-side; (2) every press re-runs the whole panel pipeline first (owner binding, `MODERATE`
for THAT group now, live license, expiry), so a demoted admin / stopped license / old panel changes nothing; (3) reports are
looked up by (pressed group, id) only; (4) when the PRIMARY OWNER approved another destination, no report content is shown in
the group and no report button works; (5) one press = one claim, the move is the service's compare-and-set and it is audited
with ids and vocabulary only. PostgreSQL / aiogram / Telegram are not exercised (in-memory stores and fakes)."""
from __future__ import annotations

import ast
import hashlib
import hmac
import re
import unittest
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace as NS

from executor_stack import OTHER, USER, BrokenClaims
from guardian.audit import REPORT_DISMISSED, REPORT_RESOLVED, REPORT_TAKEN
from guardian.auth import MAX_BIGINT
from guardian.bot import panel_handler as ph
from guardian.i18n import MESSAGES
from guardian.panel import codec
from guardian.panel import report_actions as ra
from guardian.panel.reports_screen import FILTERS, PAGE_SIZE
from guardian.panel.service import PanelService
from guardian.reports import ReportOutcome, ReportService, ReportStatus
from guardian.reports.destination import DESTINATION_KEY
from guardian.reports.memory_store import InMemoryReportStore
from guardian.telegram_rights import ChatMemberInfo
from stack import OWNER, STRANGER, TG_ADMIN
from test_panel import KEY, SECRET, PanelBase, fake_markup
from test_phase3_final_handoff import BLOCKED_STATES

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src" / "guardian"
ADMIN2 = 7002
DEST = -100777
BIG_GROUP, BIG_OWNER = -(2 ** 63), 10 ** 18 - 1


def datas(rows):
    return [data for row in rows for _, data in row]


def screens(rows):
    return [codec.parse(d).screen for d in datas(rows)]


def find(rows, screen, arg=None):
    """The callback data of the first button on `screen` (with `arg` when given)."""
    for d in datas(rows):
        cb = codec.parse(d)
        if cb.screen == screen and (arg is None or cb.arg == arg):
            return d
    raise AssertionError(f"no {screen} button")


# ----------------------------------------------------------------------------- codec
class ArgCodecTests(unittest.TestCase):
    def test_round_trip_and_the_argument_is_signed(self):
        data = codec.build(KEY, BIG_GROUP + 5, 42, ra.RP_SHOW, 5)
        cb = codec.parse(data)
        self.assertEqual((cb.owner_id, cb.screen, cb.arg), (42, "rpshow", 5))
        self.assertTrue(codec.verify(KEY, BIG_GROUP + 5, cb))
        forged = codec.parse(data.replace(":5:", ":6:"))             # report 5's button turned into report 6's
        self.assertEqual(forged.arg, 6)
        self.assertFalse(codec.verify(KEY, BIG_GROUP + 5, forged))
        self.assertFalse(codec.verify(KEY, -77, cb))                  # and it is group-bound like every panel button

    def test_a_button_without_an_argument_keeps_the_pre_6_4b_signature(self):
        msg = f"pn|{-55}|{9}|home".encode("ascii")
        old = hmac.new(KEY, msg, hashlib.sha256).hexdigest()[:codec.TAG_LEN]
        self.assertEqual(codec.build(KEY, -55, 9, "home"), f"pn:9:home:{old}")
        self.assertEqual(codec.parse(f"pn:9:home:{old}").arg, None)

    def test_only_report_screens_take_an_argument(self):
        for screen in codec.SCREENS:
            with self.assertRaises(ValueError, msg=screen):
                codec.build(KEY, -55, 9, screen, 5)
            tag = codec.build(KEY, -55, 9, screen).rsplit(":", 1)[1]
            self.assertIsNone(codec.parse(f"pn:9:{screen}:5:{tag}"), screen)

    def test_screens_that_need_an_id_refuse_to_exist_without_one(self):
        for screen in ra.ARG_REQUIRED:
            with self.assertRaises(ValueError, msg=screen):
                codec.build(KEY, -55, 9, screen)
            tag = codec.build(KEY, -55, 9, screen, 3).rsplit(":", 1)[1]
            self.assertIsNone(codec.parse(f"pn:9:{screen}:{tag}"), screen)
        for screen in ra.LIST_SCREENS:                                # the list works with and without a cursor
            self.assertIsNone(codec.parse(codec.build(KEY, -55, 9, screen)).arg)
            self.assertEqual(codec.parse(codec.build(KEY, -55, 9, screen, 12)).arg, 12)

    def test_invalid_arguments_are_refused_on_build_and_on_parse(self):
        for bad in (0, -1, True, "5", 1.5, MAX_BIGINT + 1):
            with self.assertRaises(ValueError, msg=repr(bad)):
                codec.build(KEY, -55, 9, ra.RP_SHOW, bad)
        tag = "0" * 12
        for arg in ("0", "05", "-5", "١٢", "9" * 19, "9" * 20, "5:5", "5a", ""):
            self.assertIsNone(codec.parse(f"pn:9:rpshow:{arg}:{tag}"), arg)
        self.assertEqual(codec.parse(f"pn:9:rpshow:{MAX_BIGINT}:{tag}").arg, MAX_BIGINT)

    def test_every_report_screen_fits_telegrams_limit_with_the_longest_ids(self):
        for screen in ra.REPORT_SCREENS:
            data = codec.build(KEY, BIG_GROUP, BIG_OWNER, screen, MAX_BIGINT)
            self.assertLessEqual(len(data.encode()), 64, screen)
            self.assertEqual(codec.parse(data).arg, MAX_BIGINT)

    def test_names_are_valid_unique_and_apart_from_the_older_screens(self):
        names = list(ra.REPORT_SCREENS)
        self.assertEqual(len(names), len(set(names)))
        for name in names:
            self.assertRegex(name, r"^[a-z]{1,8}$")
        self.assertFalse(set(names) & set(codec.SCREENS))

    def test_the_move_table_is_fixed_and_legal_for_the_service(self):
        self.assertEqual(set(ra.MOVES), {"rptake", "rpresact", "rpresnon", "rpdisnon", "rpdisfal"})
        self.assertEqual(ra.MOVES[ra.RP_TAKE], ("take", None))
        self.assertEqual(ra.MOVES[ra.RP_RES_ACT], ("resolve", ReportOutcome.ACTION_TAKEN))
        self.assertEqual(ra.MOVES[ra.RP_DIS_FALSE], ("dismiss", ReportOutcome.FALSE_REPORT))
        with self.assertRaises(TypeError):
            ra.MOVES["x"] = None


# ----------------------------------------------------------------------------- the screen through PanelService
class ReportsPanelBase(PanelBase):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.reports = ReportService(InMemoryReportStore(), self.s.audit, self.s.clock)
        self.panel = self.make_panel()
        self.qid = 0
        self.s.chat.set(self.g, ADMIN2, ChatMemberInfo("administrator", True, True, True))

    async def load_raw(self, chat_id):
        row = await self.s.settings_store.get(chat_id)
        return dict(row.settings) if row is not None else {}

    def make_panel(self, **kw):
        args = dict(permissions=self.s.perm, licenses=self.s.license_service, commands=self.svc, audit=self.s.audit,
                    secret=SECRET, clock=self.s.clock, ttl_seconds=None, reports=self.reports, claims=self.claims,
                    load_raw=self.load_raw)
        args.update(kw)
        return PanelService(**args)

    async def file(self, n=1, group=None, reason="spam links"):
        out = []
        for i in range(n):
            r, _ = await self.reports.create(self.g if group is None else group, USER, OTHER + i, 70 + i, reason)
            out.append(r)
            self.s.clock.advance(seconds=1)
        return out

    async def tap(self, screen, arg=None, *, owner=TG_ADMIN, group=None, query_id=None, panel=None, date=None):
        group = self.g if group is None else group
        if query_id is None:
            self.qid += 1
            query_id = f"q{self.qid}"
        data = codec.build(KEY, group, owner, screen, arg)
        return await (panel or self.panel).press(group, "supergroup", owner, data, "ar", query_id, date)

    def moves(self):
        return [e for e in self.s.audit.events if e.event_type in (REPORT_TAKEN, REPORT_RESOLVED, REPORT_DISMISSED)]


class HomeButtonTests(ReportsPanelBase):
    async def test_the_home_screen_offers_reports_only_when_the_screen_is_configured(self):
        rows = (await self.tap(codec.SCREEN_HOME)).buttons
        self.assertEqual([len(r) for r in rows], [2, 2, 2, 2])
        self.assertEqual(screens(rows[2:3]), ["trust", "rpopen"])
        plain = PanelService(permissions=self.s.perm, licenses=self.s.license_service, commands=self.svc,
                             audit=self.s.audit, secret=SECRET, clock=self.s.clock, ttl_seconds=None)
        self.assertEqual([len(r) for r in (await self.tap(codec.SCREEN_HOME, panel=plain)).buttons], [2, 2, 1, 2])

    async def test_a_partly_configured_screen_does_not_exist(self):
        for missing in ("reports", "claims", "load_raw"):
            panel = self.make_panel(**{missing: None})
            self.assertEqual([len(r) for r in (await self.tap(codec.SCREEN_HOME, panel=panel)).buttons], [2, 2, 1, 2])
            out = await self.tap(ra.RP_OPEN, panel=panel)
            self.assertEqual((out.status, out.alert, out.text), ("unavailable", True, None))


class ListTests(ReportsPanelBase):
    async def test_the_open_list_shows_this_groups_reports_without_the_reporters_words(self):
        await self.file(2, reason="PRIVATE-WORDS")
        other = await self.active_group()
        await self.file(1, group=other, reason="other group")
        out = await self.tap(ra.RP_OPEN)
        self.assertEqual((out.status, out.alert), ("rp_list", False))
        self.assertIn("(2)", out.text)
        self.assertNotIn("PRIVATE-WORDS", out.text)
        self.assertNotIn("other group", out.text)
        self.assertEqual(screens(out.buttons)[:2], ["rpshow", "rpshow"])
        for row in out.buttons:
            for _, data in row:
                cb = codec.parse(data)
                self.assertEqual(cb.owner_id, TG_ADMIN)
                self.assertTrue(codec.verify(KEY, self.g, cb))
        self.assertEqual(screens(out.buttons)[-2:], ["home", "close"])

    async def test_it_pages_with_a_signed_cursor_five_at_a_time_newest_first(self):
        made = await self.file(7)
        first = await self.tap(ra.RP_OPEN)
        shown = [codec.parse(d).arg for d in datas(first.buttons) if codec.parse(d).screen == "rpshow"]
        self.assertEqual(shown, [r.id for r in reversed(made)][:PAGE_SIZE])
        nxt = find(first.buttons, "rpopen", shown[-1])
        cb = codec.parse(nxt)
        second = await self.panel.press(self.g, "supergroup", TG_ADMIN, nxt, "ar", "pg1", None)
        rest = [codec.parse(d).arg for d in datas(second.buttons) if codec.parse(d).screen == "rpshow"]
        self.assertEqual((cb.arg, rest), (shown[-1], [r.id for r in reversed(made)][PAGE_SIZE:]))
        self.assertEqual([codec.parse(d).arg for d in datas(second.buttons) if codec.parse(d).screen == "rpopen"], [None])

    async def test_filters_and_the_empty_list(self):
        a, b, c = await self.file(3)
        await self.reports.take(self.g, b.id, TG_ADMIN)
        await self.reports.resolve(self.g, c.id, TG_ADMIN)
        ids = lambda out: sorted(codec.parse(d).arg for d in datas(out.buttons) if codec.parse(d).screen == "rpshow")  # noqa: E731
        self.assertEqual(ids(await self.tap(ra.RP_OPEN)), sorted([a.id, b.id]))
        self.assertEqual(ids(await self.tap(ra.RP_TAKEN)), [b.id])
        self.assertEqual(ids(await self.tap(ra.RP_CLOSED)), [c.id])
        self.assertEqual(ids(await self.tap(ra.RP_ALL)), sorted([a.id, b.id, c.id]))
        empty = await self.tap(ra.RP_OPEN, panel=self.make_panel(reports=ReportService(InMemoryReportStore())))
        self.assertEqual(empty.status, "rp_list")
        self.assertEqual(ids(empty), [])
        self.assertEqual(set(FILTERS), set(ra.LIST_SCREENS))

    async def test_listing_changes_nothing_claims_nothing_audits_nothing(self):
        await self.file(2)
        claims, events, rows = dict(self.claims._keys), len(self.s.audit.events), await self.reports.count(self.g)
        for screen in ra.LIST_SCREENS:
            await self.tap(screen)
        self.assertEqual((self.claims._keys, len(self.s.audit.events), await self.reports.count(self.g)),
                         (claims, events, rows))


class DetailAndMoveTests(ReportsPanelBase):
    async def test_the_details_carry_the_reason_and_offer_the_moves_by_state(self):
        r, = await self.file(1, reason="the reporter's words")
        out = await self.tap(ra.RP_SHOW, r.id)
        self.assertEqual(out.status, "rp_detail")
        self.assertIn("the reporter&#x27;s words" if "&#x27;" in out.text else "the reporter", out.text)
        self.assertEqual(screens(out.buttons), ["rptake", "rpresact", "rpresnon", "rpdisnon", "rpdisfal", "rpopen", "rpshow", "close"])
        await self.reports.take(self.g, r.id, TG_ADMIN)
        self.assertEqual(screens((await self.tap(ra.RP_SHOW, r.id)).buttons),
                         ["rpresact", "rpresnon", "rpdisnon", "rpdisfal", "rpopen", "rpshow", "close"])
        await self.reports.resolve(self.g, r.id, TG_ADMIN)
        self.assertEqual(screens((await self.tap(ra.RP_SHOW, r.id)).buttons), ["rpclosed", "rpshow", "close"])

    async def test_a_report_of_another_group_or_a_missing_one_is_simply_not_found(self):
        other = await self.active_group()
        foreign, = await self.file(1, group=other, reason="FOREIGN")
        for rid in (foreign.id, 9999):
            for screen in (ra.RP_SHOW, *ra.MOVES):
                out = await self.tap(screen, rid)
                self.assertEqual((out.status, out.alert, out.text), ("rp_gone", True, None), (screen, rid))
        self.assertEqual((await self.reports.get(other, foreign.id)).status, ReportStatus.OPEN)
        self.assertEqual(self.moves(), [])

    async def test_take_resolve_dismiss_apply_the_fixed_outcome_and_audit_ids_only(self):
        a, b, c, d = await self.file(4, reason="SECRET-REASON")
        out = await self.tap(ra.RP_TAKE, a.id)
        self.assertEqual((out.status, out.alert, out.toast), ("rp_moved", False, f"✅ استلمتَ البلاغ #{a.id}."))
        self.assertEqual((await self.reports.get(self.g, a.id)).assigned_to, TG_ADMIN)
        await self.tap(ra.RP_RES_ACT, a.id)
        await self.tap(ra.RP_RES_NONE, b.id)
        await self.tap(ra.RP_DIS_NONE, c.id)
        await self.tap(ra.RP_DIS_FALSE, d.id)
        got = [(await self.reports.get(self.g, x.id)) for x in (a, b, c, d)]
        self.assertEqual([(r.status, r.outcome, r.handled_by) for r in got], [
            (ReportStatus.RESOLVED, ReportOutcome.ACTION_TAKEN, TG_ADMIN), (ReportStatus.RESOLVED, ReportOutcome.NO_ACTION, TG_ADMIN),
            (ReportStatus.DISMISSED, ReportOutcome.NO_ACTION, TG_ADMIN), (ReportStatus.DISMISSED, ReportOutcome.FALSE_REPORT, TG_ADMIN)])
        self.assertEqual([e.event_type for e in self.moves()],
                         [REPORT_TAKEN, REPORT_RESOLVED, REPORT_RESOLVED, REPORT_DISMISSED, REPORT_DISMISSED])
        self.assertTrue(all(e.actor_telegram_id == TG_ADMIN and e.group_id == self.g for e in self.moves()))
        self.assertNotIn("SECRET-REASON", repr(self.s.audit.events))

    async def test_a_move_shows_the_fresh_report_with_new_buttons(self):
        r, = await self.file(1)
        out = await self.tap(ra.RP_TAKE, r.id)
        self.assertIn("المسؤول", out.text)
        self.assertNotIn("rptake", screens(out.buttons))
        out = await self.tap(ra.RP_DIS_FALSE, r.id)
        self.assertEqual(screens(out.buttons), ["rpclosed", "rpshow", "close"])
        self.assertIn("بلاغ كاذب", out.text)

    async def test_two_admins_racing_exactly_one_wins(self):
        r, = await self.file(1)
        await self.tap(ra.RP_TAKE, r.id)
        out = await self.tap(ra.RP_TAKE, r.id, owner=ADMIN2)
        self.assertEqual((out.status, out.alert), ("rp_conflict", True))
        self.assertEqual((await self.reports.get(self.g, r.id)).assigned_to, TG_ADMIN)
        self.assertEqual(len(self.moves()), 1)
        out = await self.tap(ra.RP_RES_NONE, r.id, owner=ADMIN2)      # any moderator may close a taken report (as /report resolve)
        self.assertEqual((out.status, (await self.reports.get(self.g, r.id)).handled_by), ("rp_moved", ADMIN2))

    async def test_a_stale_button_on_a_closed_report_changes_nothing(self):
        r, = await self.file(1)
        await self.tap(ra.RP_RES_NONE, r.id)
        n = len(self.moves())
        for screen in (ra.RP_TAKE, ra.RP_RES_ACT, ra.RP_DIS_FALSE):
            out = await self.tap(screen, r.id)
            self.assertEqual((out.status, out.alert), ("rp_conflict", True), screen)
        got = await self.reports.get(self.g, r.id)
        self.assertEqual((got.status, got.outcome, len(self.moves())), (ReportStatus.RESOLVED, ReportOutcome.NO_ACTION, n))

    async def test_repeating_the_same_move_is_unchanged_and_silent(self):
        r, = await self.file(1)
        await self.tap(ra.RP_TAKE, r.id)
        out = await self.tap(ra.RP_TAKE, r.id)
        self.assertEqual((out.status, out.alert), ("rp_noop", False))
        self.assertEqual(len(self.moves()), 1)

    async def test_a_redelivered_press_never_moves_twice(self):
        r, = await self.file(1)
        first = await self.tap(ra.RP_TAKE, r.id, query_id="same-1")
        again = await self.tap(ra.RP_TAKE, r.id, query_id="same-1")
        self.assertEqual((first.status, again.status, again.text, len(self.moves())), ("rp_moved", "duplicate", None, 1))

    async def test_a_move_needs_a_valid_callback_query_id(self):
        r, = await self.file(1)
        for bad in (None, "", "x" * 65, "a b", "ب", 5):
            data = codec.build(KEY, self.g, TG_ADMIN, ra.RP_TAKE, r.id)
            out = await self.panel.press(self.g, "supergroup", TG_ADMIN, data, "ar", bad)
            self.assertEqual((out.status, out.alert), ("unavailable", True), repr(bad))
        self.assertEqual((await self.reports.get(self.g, r.id)).status, ReportStatus.OPEN)

    async def test_a_failing_claim_store_or_report_store_fails_closed(self):
        r, = await self.file(1)
        out = await self.tap(ra.RP_TAKE, r.id, panel=self.make_panel(claims=BrokenClaims()))
        self.assertEqual((out.status, out.alert), ("unavailable", True))

        async def boom(*a, **k):
            raise RuntimeError("db down")
        real, self.reports._store.transition = self.reports._store.transition, boom
        out = await self.tap(ra.RP_TAKE, r.id)
        self.reports._store.transition = real
        self.assertEqual((out.status, out.alert, out.text), ("unavailable", True, None))
        real_list, self.reports._store.list_reports = self.reports._store.list_reports, boom
        self.assertEqual((await self.tap(ra.RP_OPEN)).status, "unavailable")
        self.reports._store.list_reports = real_list
        self.assertEqual((await self.reports.get(self.g, r.id)).status, ReportStatus.OPEN)

    async def test_dry_run_does_not_stop_report_handling(self):
        r, = await self.file(1)
        await self.s.settings_store.merge(self.g, {"dry_run": True}, OWNER, self.s.clock())
        self.assertEqual((await self.tap(ra.RP_TAKE, r.id)).status, "rp_moved")


class PipelineStillAppliesTests(ReportsPanelBase):
    """Every report screen sits behind the same gates as the older screens, evaluated on THIS press."""

    async def test_a_demoted_admin_can_neither_read_nor_move(self):
        r, = await self.file(1)
        self.assertEqual((await self.tap(ra.RP_SHOW, r.id)).status, "rp_detail")
        self.s.chat.set(self.g, TG_ADMIN, ChatMemberInfo("member"))
        for screen in (ra.RP_OPEN, ra.RP_SHOW, *ra.MOVES):
            out = await self.tap(screen, r.id if screen in ra.ARG_REQUIRED else None)
            self.assertEqual((out.status, out.text, out.alert), ("not_admin", None, True), screen)
        self.assertEqual(((await self.reports.get(self.g, r.id)).status, self.moves()), (ReportStatus.OPEN, []))

    async def test_a_plain_member_and_a_borrowed_button_are_refused(self):
        r, = await self.file(1)
        self.assertEqual((await self.tap(ra.RP_TAKE, r.id, owner=STRANGER)).status, "not_admin")
        data = codec.build(KEY, self.g, TG_ADMIN, ra.RP_TAKE, r.id)         # someone else pressing the admin's button
        for presser in (STRANGER, ADMIN2):
            out = await self.panel.press(self.g, "supergroup", presser, data, "ar", "qq")
            self.assertEqual(out.status, "not_owner")
        self.assertEqual(((await self.reports.get(self.g, r.id)).status, self.moves()), (ReportStatus.OPEN, []))

    async def test_a_forged_argument_or_a_button_from_another_group_is_audited_and_refused(self):
        r, = await self.file(1)
        data = codec.build(KEY, self.g, TG_ADMIN, ra.RP_SHOW, r.id).replace(f":{r.id}:", ":99:")
        out = await self.panel.press(self.g, "supergroup", TG_ADMIN, data, "ar", "q")
        self.assertEqual((out.status, out.text), ("forged", None))
        other = await self.active_group()
        out = await self.panel.press(other, "supergroup", TG_ADMIN, codec.build(KEY, self.g, TG_ADMIN, ra.RP_TAKE, r.id), "ar", "q2")
        self.assertEqual(out.status, "forged")
        self.assertEqual(len(self.forged()) + len(self.forged(other)), 2)
        self.assertEqual(self.moves(), [])

    async def test_every_blocked_license_state_refuses_every_report_screen(self):
        for state in BLOCKED_STATES:
            with self.subTest(state=state):
                g = await self.group_in(state)
                r, _ = await self.reports.create(g, USER, OTHER, 70, "x")
                real = self.break_store() if state == "store_down" else self.s.licenses.get
                try:
                    for screen in ra.REPORT_SCREENS:
                        out = await self.tap(screen, r.id if screen in ra.ARG_REQUIRED else None, group=g)
                        self.assertIn(out.status, ("license_off", "unavailable"), (state, screen))
                        self.assertEqual((out.alert, out.text), (True, None))
                finally:
                    self.s.licenses.get = real
                self.assertEqual((await self.reports.get(g, r.id)).status, ReportStatus.OPEN)
        self.assertEqual(self.moves(), [])

    async def test_a_stopped_license_stops_a_panel_that_was_open(self):
        r, = await self.file(1)
        self.assertEqual((await self.tap(ra.RP_TAKE, r.id)).status, "rp_moved")
        await self.s.admin.stop(OWNER, self.g)
        out = await self.tap(ra.RP_RES_NONE, r.id)
        self.assertEqual(out.status, "license_off")
        self.assertEqual((await self.reports.get(self.g, r.id)).status, ReportStatus.TAKEN)

    async def test_an_old_panel_is_expired_and_moves_nothing(self):
        r, = await self.file(1)
        panel = self.make_panel(ttl_seconds=60)
        now = self.s.clock()
        for date in (now - timedelta(hours=1), now + timedelta(hours=1), None, now.replace(tzinfo=None)):
            out = await self.tap(ra.RP_TAKE, r.id, panel=panel, date=date)
            self.assertEqual((out.status, out.alert), ("expired", True), date)
        out = await self.tap(ra.RP_TAKE, r.id, panel=panel, date=now)
        self.assertEqual(out.status, "rp_moved")

    async def test_close_still_works_on_the_reports_screen(self):
        self.assertTrue((await self.tap(codec.SCREEN_CLOSE)).delete)


class DestinationTests(ReportsPanelBase):
    """6.4a: with another approved destination the group must never show reporter ids or words."""

    async def route(self, value=DEST):
        await self.s.settings_store.merge(self.g, {DESTINATION_KEY: value}, OWNER, self.s.clock())

    async def test_a_custom_destination_hides_every_report_and_disables_every_button(self):
        a, b = await self.file(2, reason="REPORTER-WORDS")
        await self.route()
        for screen in (*ra.LIST_SCREENS, ra.RP_SHOW, *ra.MOVES):
            out = await self.tap(screen, a.id if screen in ra.ARG_REQUIRED else None)
            self.assertEqual((out.status, out.alert), ("rp_routed", False), screen)
            self.assertIn("2", out.text)                                   # only how many are open
            for secret in ("REPORTER-WORDS", str(USER), str(OTHER), "#%d" % a.id):
                self.assertNotIn(secret, out.text)
            self.assertEqual(screens(out.buttons), ["home", "close"])
        self.assertEqual(self.moves(), [])
        self.assertEqual((await self.reports.get(self.g, a.id)).status, ReportStatus.OPEN)

    async def test_an_unreadable_destination_fails_closed(self):
        r, = await self.file(1, reason="WORDS")

        async def boom(chat_id):
            raise RuntimeError("settings down")
        panel = self.make_panel(load_raw=boom)
        for screen in (ra.RP_OPEN, ra.RP_SHOW, ra.RP_TAKE):
            out = await self.tap(screen, r.id if screen in ra.ARG_REQUIRED else None, panel=panel)
            self.assertEqual((out.status, out.alert, out.text), ("unavailable", True, None), screen)
        self.assertEqual(self.moves(), [])

    async def test_a_garbage_or_group_destination_means_the_group_itself(self):
        r, = await self.file(1)
        for value in ("x", 5, None, True, [DEST], self.g):
            await self.route(value)
            self.assertEqual((await self.tap(ra.RP_SHOW, r.id)).status, "rp_detail", value)

    async def test_the_destination_is_read_on_every_press(self):
        r, = await self.file(1)
        self.assertEqual((await self.tap(ra.RP_SHOW, r.id)).status, "rp_detail")
        await self.route()
        self.assertEqual((await self.tap(ra.RP_SHOW, r.id)).status, "rp_routed")      # a panel opened before the change
        await self.route(None)
        self.assertEqual((await self.tap(ra.RP_SHOW, r.id)).status, "rp_detail")


# ----------------------------------------------------------------------------- aiogram-free glue
class HandlerTests(ReportsPanelBase):
    class Panelled:
        def __init__(self, chat, date):
            self.chat, self.date = NS(id=chat, type=NS(value="supergroup")), date
            self.edits, self.deleted = [], 0

        async def edit_text(self, text, reply_markup=None):
            self.edits.append((text, reply_markup))

        async def delete(self):
            self.deleted += 1

    async def test_a_press_edits_the_panel_in_place_and_answers_a_plain_toast(self):
        r, = await self.file(1)
        m = self.Panelled(self.g, self.s.clock())
        panel = self.make_panel(ttl_seconds=1800)
        services = NS(settings=NS(default_language="ar"), panel=panel)
        query = NS(data=codec.build(KEY, self.g, TG_ADMIN, ra.RP_TAKE, r.id), message=m, id="cb-1",
                   from_user=NS(id=TG_ADMIN, language_code="ar"))
        toast = await ph.on_panel_callback(query, services, fake_markup)
        self.assertEqual(toast, (f"✅ استلمتَ البلاغ #{r.id}.", False))
        (text, markup), = m.edits
        self.assertIn(f"#{r.id}", text)
        self.assertEqual(markup[0], "MARKUP")
        self.assertNotIn("<", toast[0])                       # a toast is plain text: no HTML tags in it
        self.assertEqual((await self.reports.get(self.g, r.id)).status, ReportStatus.TAKEN)

    async def test_a_refusal_edits_nothing(self):
        r, = await self.file(1)
        m = self.Panelled(self.g, self.s.clock())
        services = NS(settings=NS(default_language="ar"), panel=self.make_panel(ttl_seconds=1800))
        query = NS(data=codec.build(KEY, self.g, STRANGER, ra.RP_TAKE, r.id), message=m, id="cb-2",
                   from_user=NS(id=STRANGER, language_code="ar"))
        toast = await ph.on_panel_callback(query, services, fake_markup)
        self.assertTrue(toast[1])
        self.assertEqual((m.edits, m.deleted), ([], 0))


# ----------------------------------------------------------------------------- static guards
class StaticTests(unittest.TestCase):
    def test_i18n_keys_exist_in_both_languages_with_the_same_placeholders(self):
        keys = [k for k in MESSAGES["ar"] if k.startswith("pn_rp_") or k == "pn_btn_reports"]
        self.assertEqual(len(keys), 16)
        for k in keys:
            self.assertIn(k, MESSAGES["en"], k)
            self.assertEqual(sorted(re.findall(r"{(\w+)}", MESSAGES["ar"][k])),
                             sorted(re.findall(r"{(\w+)}", MESSAGES["en"][k])), k)

    def test_the_screen_only_reads_and_closes_and_never_touches_type_priority_or_destination(self):
        src = (SRC / "panel" / "reports_screen.py").read_text(encoding="utf-8")
        tree = ast.parse(src)
        imported = {a.name for n in ast.walk(tree) if isinstance(n, ast.Import) for a in n.names}
        imported |= {(n.module or "") for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)}
        for banned in ("aiogram", "asyncpg", "fastapi"):
            self.assertFalse(any(m.split(".")[0] == banned for m in imported), banned)
        attrs = {n.attr for n in ast.walk(tree) if isinstance(n, ast.Attribute)}
        for forbidden in ("set_type", "set_priority", "set_meta", "update", "send_message", "list_all"):
            self.assertNotIn(forbidden, attrs, forbidden)
        used = set(re.findall(r"self\._reports\.(\w+)\(", src))
        self.assertEqual(used, {"get", "list_reports", "count", "take", "resolve", "dismiss"})

    def test_toast_texts_carry_no_html(self):
        for lang in ("ar", "en"):
            for key in ("pn_rp_gone", "pn_rp_ok_taken", "pn_rp_ok_resolved", "pn_rp_ok_dismissed", "pn_rp_unchanged",
                        "pn_rp_already_taken", "pn_rp_closed"):
                self.assertNotIn("<", MESSAGES[lang][key], key)


if __name__ == "__main__":
    unittest.main()
