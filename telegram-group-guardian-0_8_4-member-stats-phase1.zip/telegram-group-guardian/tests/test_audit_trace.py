"""Phase 6 / part 6.1: audit foundation — trace id per update, target_id/result columns, migration 0006."""
from __future__ import annotations

import asyncio
import hashlib
import unittest
from datetime import datetime, timezone

import helpers  # noqa: F401
from guardian import trace
from guardian.audit import (FORGED_CALLBACK, PERMISSION_DENIED, RESULT_DENIED, SETTINGS_CHANGED, InMemorySecurityAudit,
                            PostgresSecurityAudit, SecurityEvent, make_event, record_safely, sanitize_target)
from guardian.db.migrations import SQL_DIR, discover

NOW = datetime(2026, 11, 1, 12, 0, tzinfo=timezone.utc)


class Conn:
    def __init__(self, rows=()):
        self.calls, self.rows = [], list(rows)

    async def execute(self, sql, *args):
        self.calls.append((sql, args))

    async def fetch(self, sql, *args):
        self.calls.append((sql, args))
        return self.rows


class Db:
    def __init__(self, conn):
        self.conn = conn

    def acquire(self):
        conn = self.conn

        class Ctx:
            async def __aenter__(self_):
                return conn

            async def __aexit__(self_, *a):
                return False
        return Ctx()


class TraceTests(unittest.IsolatedAsyncioTestCase):
    async def test_no_trace_outside_an_update(self):
        self.assertIsNone(trace.current_trace_id())
        self.assertIsNone(make_event("x").trace_id)

    async def test_middleware_sets_one_trace_for_the_whole_update_and_resets(self):
        seen = []

        async def handler(event, data):
            seen.append(trace.current_trace_id())
            seen.append(make_event(SETTINGS_CHANGED, group_id=-1).trace_id)
            return "ok"
        out = await trace.TraceMiddleware()(handler, object(), {})
        self.assertEqual(out, "ok")
        self.assertTrue(trace.is_valid_trace_id(seen[0]))
        self.assertEqual(seen[0], seen[1])
        self.assertIsNone(trace.current_trace_id())

    async def test_trace_is_reset_even_when_the_handler_raises(self):
        async def boom(event, data):
            raise RuntimeError("x")
        with self.assertRaises(RuntimeError):
            await trace.TraceMiddleware()(boom, object(), {})
        self.assertIsNone(trace.current_trace_id())

    async def test_concurrent_updates_never_share_a_trace(self):
        async def handler(event, data):
            await asyncio.sleep(0)
            first = trace.current_trace_id()
            await asyncio.sleep(0)
            return first, trace.current_trace_id()
        mw = trace.TraceMiddleware()
        results = await asyncio.gather(*(mw(handler, None, {}) for _ in range(20)))
        self.assertTrue(all(a == b for a, b in results))
        self.assertEqual(len({a for a, _ in results}), 20)

    def test_trace_ids_are_opaque_hex_and_validated(self):
        t = trace.new_trace_id()
        self.assertTrue(trace.is_valid_trace_id(t))
        for bad in (None, "", "xyz", "A" * 16, "0" * 15, 123, "0" * 16 + "0"):
            self.assertFalse(trace.is_valid_trace_id(bad), bad)
        with self.assertRaises(ValueError):
            trace.set_trace_id("not-valid")

    def test_explicit_trace_wins_and_a_forged_one_is_dropped(self):
        self.assertEqual(make_event("x", trace_id="a" * 16).trace_id, "a" * 16)
        self.assertIsNone(SecurityEvent("x", NOW, trace_id="'; DROP TABLE x;--").trace_id)


class EventFieldTests(unittest.TestCase):
    def test_target_is_an_opaque_id_never_free_text_of_any_length(self):
        self.assertEqual(sanitize_target(42), "42")
        self.assertEqual(sanitize_target(-100123), "-100123")
        self.assertIsNone(sanitize_target(None))
        self.assertIsNone(sanitize_target(True))
        self.assertLessEqual(len(sanitize_target("y" * 500)), 64)
        self.assertNotIn("\x07", sanitize_target("a\x07b"))

    def test_target_redacts_registered_secrets(self):
        from guardian import audit
        audit.register_secrets(["TOP-SECRET-VALUE-123"])
        try:
            self.assertNotIn("TOP-SECRET-VALUE-123", make_event("x", target="id TOP-SECRET-VALUE-123").target_id)
        finally:
            audit.register_secrets([])

    def test_result_is_a_closed_vocabulary(self):
        self.assertEqual(make_event("x", result="denied").result, "denied")
        self.assertIsNone(make_event("x", result="because the user was rude").result)

    def test_denials_default_to_denied_and_other_events_stay_unknown(self):
        self.assertEqual(make_event(PERMISSION_DENIED).result, RESULT_DENIED)
        self.assertEqual(make_event(FORGED_CALLBACK).result, RESULT_DENIED)
        self.assertIsNone(make_event(SETTINGS_CHANGED).result)
        self.assertEqual(make_event(PERMISSION_DENIED, result="failed").result, "failed")

    def test_old_call_style_still_works(self):
        e = SecurityEvent("t", NOW, 1, -2, "p", "d")
        self.assertEqual((e.target_id, e.result, e.trace_id), (None, None, None))


class StoreTests(unittest.IsolatedAsyncioTestCase):
    async def test_memory_store_keeps_the_new_fields(self):
        a = InMemorySecurityAudit()
        await a.record(make_event("x", group_id=-1, target=7, result="applied", trace_id="b" * 16, now=NOW))
        (e,) = await a.for_group(-1)
        self.assertEqual((e.target_id, e.result, e.trace_id), ("7", "applied", "b" * 16))

    async def test_postgres_insert_writes_all_nine_columns_in_order(self):
        conn = Conn()
        ev = make_event("x", actor=5, group_id=-1, permission="p", detail="d", now=NOW, target=9, result="denied",
                        trace_id="c" * 16)
        await PostgresSecurityAudit(Db(conn)).record(ev)
        sql, args = conn.calls[0]
        self.assertIn("target_id, result, trace_id", " ".join(sql.split()))
        self.assertIn("$9", sql)
        self.assertNotIn("$10", sql)
        self.assertEqual(args, ("x", 5, -1, "p", "d", NOW, "9", "denied", "c" * 16))

    async def test_postgres_read_maps_the_new_columns(self):
        row = dict(event_type="x", actor_telegram_id=1, group_id=-1, permission=None, detail=None, occurred_at=NOW,
                   target_id="9", result="denied", trace_id="d" * 16)
        (e,) = await PostgresSecurityAudit(Db(Conn([row]))).for_group(-1)
        self.assertEqual((e.target_id, e.result, e.trace_id), ("9", "denied", "d" * 16))

    async def test_a_failing_store_still_cannot_break_the_caller(self):
        class Bad:
            async def record(self, event):
                raise RuntimeError("db down")
        await record_safely(Bad(), make_event("x"))


class MigrationTests(unittest.TestCase):
    sql = (SQL_DIR / "0006_audit_trace.sql").read_text(encoding="utf-8")

    def test_it_follows_0005(self):
        self.assertEqual([v for v, _ in discover()][5:6], ["0006_audit_trace"])

    def test_it_only_adds_nullable_columns_and_indexes(self):
        code = "\n".join(l for l in self.sql.splitlines() if not l.strip().startswith("--")).upper()
        for col in ("TARGET_ID", "RESULT", "TRACE_ID"):
            self.assertIn(f"ADD COLUMN IF NOT EXISTS {col}", code)
        self.assertNotIn("NOT NULL", code.replace("IS NOT NULL", ""))  # a NOT NULL column would break old rows
        for forbidden in ("DROP ", "DELETE ", "UPDATE ", "TRUNCATE", "DISABLE TRIGGER", "DROP TRIGGER"):
            self.assertNotIn(forbidden, code, forbidden)

    def test_result_values_match_python(self):
        from guardian.audit import RESULTS
        for r in RESULTS:
            self.assertIn(f"'{r}'", self.sql)

    def test_earlier_migrations_are_untouched(self):
        self.assertEqual(hashlib.sha256((SQL_DIR / "0001_initial.sql").read_bytes()).hexdigest(),
                         "72b784563aecb473e545c6dbef156574981583396a2c0b9f271569710d266d81")
        self.assertEqual(hashlib.sha256((SQL_DIR / "0003_moderation_records.sql").read_bytes()).hexdigest(),
                         "b54d055f951da3b6fa72c418662aa3b3f9dc096bd4702f91da316a91f36ece8b")

    def test_the_append_only_triggers_are_still_defined_in_0002_and_not_touched_here(self):
        s2 = (SQL_DIR / "0002_security_and_access.sql").read_text(encoding="utf-8")
        self.assertIn("CREATE TRIGGER security_audit_no_update_delete", s2)
        self.assertNotIn("security_audit_no_update_delete", self.sql)


class WiringTests(unittest.TestCase):
    def test_the_trace_middleware_is_registered_on_every_update_type_before_the_gate(self):
        from pathlib import Path
        src = (Path(__file__).resolve().parents[1] / "src/guardian/bot/factory.py").read_text(encoding="utf-8")
        self.assertIn("dp.update.outer_middleware(TraceMiddleware())", src)
        self.assertLess(src.index("TraceMiddleware()"), src.index("ProtectionGateMiddleware(gate"))

    def test_trace_module_does_not_import_aiogram_or_asyncpg(self):
        from pathlib import Path
        src = (Path(__file__).resolve().parents[1] / "src/guardian/trace.py").read_text(encoding="utf-8")
        import re
        imports = "\n".join(re.findall(r"(?m)^\s*(?:from|import)\s+\S+", src))
        self.assertNotIn("aiogram", imports)
        self.assertNotIn("asyncpg", imports)


if __name__ == "__main__":
    unittest.main()
