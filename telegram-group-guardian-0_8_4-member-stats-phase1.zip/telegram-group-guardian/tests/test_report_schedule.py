"""Part 6.6a: calendar periods, the per-group schedule (switches, owed periods, idempotent marks) and migration 0010.
Nothing is sent in this part. PostgreSQL itself is NOT exercised: the store is checked against a recording fake connection."""
from __future__ import annotations

import re
import unittest
from contextlib import asynccontextmanager
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from unittest import mock

from guardian.audit import REPORT_SCHEDULE_SET, InMemorySecurityAudit
from guardian.db.migrations import discover
from guardian.errors import InvalidInput
from guardian.idempotency import InMemoryIdempotency
from guardian.stats import (CATCH_UP_LIMIT, CalendarPeriod, Owed, ReportScheduleService, StatsPeriod, SwitchCode,
                            claim_key, last_completed, owed_periods, parse_period_key, period_containing)
from guardian.stats.schedule_memory_store import InMemoryScheduleStore
from guardian.stats.schedule_postgres_store import PostgresScheduleStore
from guardian.stats.schedule_store import ScheduleEntry

ROOT = Path(__file__).resolve().parent.parent
SQL = ROOT / "src" / "guardian" / "db" / "sql" / "0010_report_schedule.sql"
TZ = "Asia/Riyadh"
GA, GB = -1001, -1002
ADMIN = 7001
DAY, WEEK, MONTH = StatsPeriod.DAY, StatsPeriod.WEEK, StatsPeriod.MONTH


def utc(y, m, d, h=12, mi=0) -> datetime:
    return datetime(y, m, d, h, mi, tzinfo=timezone.utc)


# ---------------------------------------------------------------- calendar periods
class CalendarTests(unittest.TestCase):
    def test_a_day_is_the_local_calendar_day(self):
        p = period_containing(DAY, utc(2026, 10, 29, 12), TZ)   # 15:00 in Riyadh
        self.assertEqual((p.key, p.first_day, p.last_day), ("2026-10-29", date(2026, 10, 29), date(2026, 10, 29)))
        self.assertEqual((p.start, p.end), (utc(2026, 10, 28, 21), utc(2026, 10, 29, 21)))  # local midnights (UTC+3)

    def test_the_local_date_not_the_utc_date_decides(self):
        self.assertEqual(period_containing(DAY, utc(2026, 10, 29, 20, 59), TZ).key, "2026-10-29")
        self.assertEqual(period_containing(DAY, utc(2026, 10, 29, 21, 0), TZ).key, "2026-10-30")

    def test_a_week_runs_sunday_to_saturday_and_is_keyed_by_its_sunday(self):
        for day in range(25, 32):   # Sun 2026-10-25 .. Sat 2026-10-31
            p = period_containing(WEEK, utc(2026, 10, day, 9), TZ)
            self.assertEqual((p.key, p.last_day), ("2026-10-25", date(2026, 10, 31)), day)
        self.assertEqual(period_containing(WEEK, utc(2026, 11, 1, 9), TZ).key, "2026-11-01")   # Sunday starts a new week
        w = period_containing(WEEK, utc(2026, 10, 28), TZ)
        self.assertEqual(w.end - w.start, timedelta(days=7))
        self.assertEqual(w.first_day.weekday(), 6)

    def test_a_week_may_span_two_months_and_two_years(self):
        self.assertEqual(period_containing(WEEK, utc(2026, 12, 31, 9), TZ).key, "2026-12-27")
        p = period_containing(WEEK, utc(2027, 1, 1, 9), TZ)
        self.assertEqual((p.key, p.last_day), ("2026-12-27", date(2027, 1, 2)))

    def test_a_month_is_the_calendar_month_not_thirty_days(self):
        for (y, m, days) in ((2026, 10, 31), (2026, 9, 30), (2026, 2, 28), (2028, 2, 29)):
            p = period_containing(MONTH, utc(y, m, 15), TZ)
            self.assertEqual(p.key, f"{y:04d}-{m:02d}")
            self.assertEqual((p.end - p.start).days, days, (y, m))
            self.assertEqual(p.first_day, date(y, m, 1))
            self.assertEqual(p.last_day.day, days)

    def test_month_boundaries_follow_local_midnight(self):
        # 2026-10-31 21:00 UTC is already 2026-11-01 00:00 in Riyadh
        self.assertEqual(period_containing(MONTH, utc(2026, 10, 31, 20, 59), TZ).key, "2026-10")
        self.assertEqual(period_containing(MONTH, utc(2026, 10, 31, 21, 0), TZ).key, "2026-11")

    def test_december_rolls_into_january(self):
        p = period_containing(MONTH, utc(2026, 12, 20), TZ)
        self.assertEqual((p.key, p.after_day), ("2026-12", date(2027, 1, 1)))
        self.assertEqual(last_completed(MONTH, utc(2027, 1, 3), TZ).key, "2026-12")

    def test_last_completed_is_never_the_period_containing_now(self):
        now = utc(2026, 11, 1, 12)   # a Sunday, the 1st
        self.assertEqual(last_completed(DAY, now, TZ).key, "2026-10-31")
        self.assertEqual(last_completed(WEEK, now, TZ).key, "2026-10-25")
        self.assertEqual(last_completed(MONTH, now, TZ).key, "2026-10")
        for period in StatsPeriod:
            done = last_completed(period, now, TZ)
            self.assertLessEqual(done.end, now)
            self.assertEqual(period_containing(period, now, TZ).start, done.end)   # adjacent, no gap, no overlap

    def test_exactly_at_the_boundary_the_new_period_has_started(self):
        boundary = utc(2026, 10, 30, 21, 0)   # local midnight of 2026-10-31
        self.assertEqual(last_completed(DAY, boundary, TZ).key, "2026-10-30")
        self.assertEqual(last_completed(DAY, boundary - timedelta(microseconds=1), TZ).key, "2026-10-29")

    def test_dst_zones_use_local_midnights(self):
        spring = period_containing(DAY, utc(2026, 3, 8, 12), "America/New_York")   # 23-hour day
        self.assertEqual((spring.end - spring.start), timedelta(hours=23))
        fall = period_containing(DAY, utc(2026, 11, 1, 12), "America/New_York")     # 25-hour day
        self.assertEqual((fall.end - fall.start), timedelta(hours=25))

    def test_to_range_matches_the_shape_stats_reads_with(self):
        r = period_containing(WEEK, utc(2026, 10, 28), TZ).to_range()
        self.assertEqual((r.period, r.start, r.end, r.timezone), (WEEK, utc(2026, 10, 24, 21), utc(2026, 10, 31, 21), TZ))
        self.assertEqual((r.start_day, r.end_day), (date(2026, 10, 25), date(2026, 10, 31)))   # inclusive local dates
        self.assertIsNotNone(r)

    def test_consecutive_periods_tile_the_time_line(self):
        for period in StatsPeriod:
            cur = period_containing(period, utc(2026, 10, 1), TZ)
            for _ in range(40):
                nxt = period_containing(period, cur.end, TZ)
                self.assertEqual(nxt.start, cur.end)
                self.assertGreater(nxt.ordinal, cur.ordinal)
                self.assertEqual(nxt.ordinal, cur.ordinal + 1)
                cur = nxt

    def test_unknown_period_word_is_rejected(self):
        with self.assertRaises(InvalidInput):
            period_containing("year", utc(2026, 10, 1), TZ)


class KeyTests(unittest.TestCase):
    def test_a_key_round_trips(self):
        for period, key in ((DAY, "2026-10-29"), (WEEK, "2026-10-25"), (MONTH, "2026-10")):
            self.assertEqual(parse_period_key(period, key, TZ).key, key)

    def test_malformed_keys_are_rejected(self):
        bad = {
            DAY: ["", "2026-1-29", "2026-13-01", "2026-02-30", "20261029", "2026-10-29\n", "٢٠٢٦-١٠-٢٩", "2026-10", None, 20261029],
            WEEK: ["2026-10-26", "2026-10-24", "2026-10", "x"],     # Monday / Saturday are not week starts
            MONTH: ["2026-13", "2026-00", "2026-10-01", "2026-1", "2026-10\n", "", None],
        }
        for period, keys in bad.items():
            for key in keys:
                with self.subTest(period=period.value, key=key), self.assertRaises(InvalidInput):
                    parse_period_key(period, key, TZ)

    def test_claim_key_is_stable_valid_and_distinct(self):
        a = claim_key(GA, MONTH, "2026-10")
        self.assertEqual(a, claim_key(GA, MONTH, "2026-10"))
        self.assertEqual(a, "op:periodic:-1001:month:2026-10")
        self.assertNotEqual(a, claim_key(GB, MONTH, "2026-10"))
        self.assertNotEqual(a, claim_key(GA, DAY, "2026-10-01"))
        with self.assertRaises(InvalidInput):
            claim_key(5, MONTH, "2026-10")   # not a group id

    def test_the_claim_key_is_accepted_by_the_idempotency_store_exactly_once(self):
        import asyncio
        store = InMemoryIdempotency()
        key = claim_key(GA, DAY, "2026-10-29")
        self.assertTrue(asyncio.run(store.claim(key)))
        self.assertFalse(asyncio.run(store.claim(key)))


# ---------------------------------------------------------------- what is owed
class OwedTests(unittest.TestCase):
    def owed(self, period, now, enabled_from, last=None, limit=None):
        return owed_periods(period, now, TZ, enabled_from=enabled_from, last_key=last, limit=limit)

    def keys(self, owed):
        return [p.key for p in owed.periods]

    def test_not_enabled_owes_nothing(self):
        self.assertEqual(self.owed(DAY, utc(2026, 11, 1), None), Owed())
        self.assertFalse(self.owed(DAY, utc(2026, 11, 1), None))

    def test_the_period_containing_the_switch_on_is_owed_only_once_it_has_ended(self):
        on = utc(2026, 10, 29, 12)
        self.assertFalse(self.owed(DAY, utc(2026, 10, 29, 20), on))                    # same local day: not finished
        self.assertEqual(self.keys(self.owed(DAY, utc(2026, 10, 30, 1), on)), ["2026-10-29"])

    def test_earlier_periods_are_never_replayed(self):
        on = utc(2026, 10, 29, 12)
        self.assertEqual(self.keys(self.owed(DAY, utc(2026, 11, 1, 12), on, limit=10)),
                         ["2026-10-29", "2026-10-30", "2026-10-31"])   # nothing before the 29th

    def test_missed_periods_are_listed_oldest_first_after_the_last_handled_one(self):
        on = utc(2026, 9, 1)
        got = self.owed(DAY, utc(2026, 11, 1, 12), on, last="2026-10-29", limit=5)
        self.assertEqual(self.keys(got), ["2026-10-30", "2026-10-31"])
        self.assertEqual(got.skipped, 0)

    def test_the_limit_keeps_the_newest_and_counts_the_rest_as_skipped(self):
        on = utc(2026, 9, 1)
        got = self.owed(DAY, utc(2026, 11, 1, 12), on)   # ~60 days owed, default limit 3
        self.assertEqual(self.keys(got), ["2026-10-29", "2026-10-30", "2026-10-31"])
        self.assertEqual(len(got.periods), CATCH_UP_LIMIT[DAY])
        self.assertEqual(got.skipped, (date(2026, 10, 31) - date(2026, 9, 1)).days + 1 - 3)

    def test_marking_the_newest_forgets_the_skipped_ones(self):
        on = utc(2026, 9, 1)
        got = self.owed(DAY, utc(2026, 11, 1, 12), on)
        again = self.owed(DAY, utc(2026, 11, 1, 12), on, last=got.periods[-1].key)
        self.assertEqual(again, Owed())

    def test_a_year_of_sleep_is_cheap_and_bounded(self):
        got = self.owed(DAY, utc(2030, 1, 1), utc(2026, 1, 1), limit=60)
        self.assertEqual(len(got.periods), 60)
        self.assertGreater(got.skipped, 1000)

    def test_weekly_and_monthly(self):
        on = utc(2026, 8, 5)
        w = self.owed(WEEK, utc(2026, 11, 1, 12), on)
        self.assertEqual(self.keys(w), ["2026-10-18", "2026-10-25"])
        m = self.owed(MONTH, utc(2026, 11, 1, 12), on)
        self.assertEqual(self.keys(m), ["2026-09", "2026-10"])
        self.assertEqual(m.skipped, 1)   # 2026-08 was owed too (it contains the switch-on)

    def test_a_week_is_owed_after_saturday_ends_not_before(self):
        on = utc(2026, 10, 20)
        self.assertEqual(self.keys(self.owed(WEEK, utc(2026, 10, 31, 20), on, last="2026-10-18")), [])      # Sat evening
        self.assertEqual(self.keys(self.owed(WEEK, utc(2026, 11, 1, 1), on, last="2026-10-18")), ["2026-10-25"])  # Sunday 04:00 local

    def test_the_last_key_never_resurrects_older_periods_than_the_switch_on(self):
        on = utc(2026, 10, 29, 12)
        got = self.owed(DAY, utc(2026, 11, 1, 12), on, last="2026-01-01", limit=10)
        self.assertEqual(self.keys(got), ["2026-10-29", "2026-10-30", "2026-10-31"])

    def test_a_switch_on_in_the_future_owes_nothing(self):
        self.assertFalse(self.owed(DAY, utc(2026, 10, 29), utc(2026, 11, 5)))

    def test_a_bad_last_key_or_limit_is_rejected_not_ignored(self):
        with self.assertRaises(InvalidInput):
            self.owed(DAY, utc(2026, 11, 1), utc(2026, 10, 1), last="garbage")
        for limit in (0, -1, 61, True, 1.5):
            with self.subTest(limit=limit), self.assertRaises(InvalidInput):
                self.owed(DAY, utc(2026, 11, 1), utc(2026, 10, 1), limit=limit)


# ---------------------------------------------------------------- service over the in-memory store
class ServiceBase(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.now = utc(2026, 11, 1, 12)
        self.store = InMemoryScheduleStore()
        self.audit = InMemorySecurityAudit()
        self.svc = ReportScheduleService(self.store, self.audit, display_timezone=TZ, clock=lambda: self.now)


class SwitchTests(ServiceBase):
    async def test_everything_is_off_by_default_and_reading_writes_nothing(self):
        entries = await self.svc.entries(GA)
        self.assertEqual(set(entries), set(StatsPeriod))
        self.assertTrue(all(not e.enabled and e.enabled_from is None and e.last_period_key is None for e in entries.values()))
        for period in StatsPeriod:
            self.assertFalse(await self.svc.is_enabled(GA, period))
            self.assertFalse(await self.svc.owed(GA, period))
        self.assertEqual(await self.svc.owed_all(GA), {})
        self.assertEqual(await self.store.get_all(GA), [])
        self.assertEqual(self.audit.events, [])

    async def test_switching_on_stamps_the_moment_and_audits_period_word_only(self):
        r = await self.svc.set_enabled(GA, WEEK, True, ADMIN)
        self.assertEqual((r.code, r.enabled), (SwitchCode.CHANGED, True))
        e = (await self.svc.entries(GA))[WEEK]
        self.assertEqual((e.enabled, e.enabled_from, e.changed_by, e.updated_at), (True, self.now, ADMIN, self.now))
        self.assertTrue(await self.svc.is_enabled(GA, WEEK))
        self.assertFalse(await self.svc.is_enabled(GA, DAY))   # periods are independent
        (ev,) = self.audit.events
        self.assertEqual((ev.event_type, ev.actor_telegram_id, ev.group_id, ev.target_id, ev.result), (REPORT_SCHEDULE_SET, ADMIN, GA, "week", "applied"))
        self.assertEqual(ev.detail, "period=week enabled=on")

    async def test_repeating_a_switch_changes_nothing_and_is_not_audited_again(self):
        await self.svc.set_enabled(GA, DAY, True, ADMIN)
        self.now += timedelta(hours=5)
        r = await self.svc.set_enabled(GA, DAY, True, ADMIN + 1)
        self.assertEqual(r.code, SwitchCode.UNCHANGED)
        e = (await self.svc.entries(GA))[DAY]
        self.assertEqual((e.enabled_from, e.changed_by), (utc(2026, 11, 1, 12), ADMIN))   # the first switch-on stands
        self.assertEqual(len(self.audit.events), 1)

    async def test_switching_off_a_period_that_was_never_on_creates_no_row(self):
        r = await self.svc.set_enabled(GA, MONTH, False, ADMIN)
        self.assertEqual(r.code, SwitchCode.UNCHANGED)
        self.assertEqual(await self.store.get_all(GA), [])
        self.assertEqual(self.audit.events, [])

    async def test_off_then_on_again_restarts_the_clock_but_keeps_the_handled_marker(self):
        await self.svc.set_enabled(GA, DAY, True, ADMIN)
        self.now = utc(2026, 11, 3, 12)
        await self.svc.mark_done(GA, DAY, "2026-11-02")
        await self.svc.set_enabled(GA, DAY, False, ADMIN)
        self.assertFalse(await self.svc.owed(GA, DAY, utc(2026, 12, 1)))   # off owes nothing, however long
        self.now = utc(2026, 11, 20, 12)
        await self.svc.set_enabled(GA, DAY, True, ADMIN + 1)
        e = (await self.svc.entries(GA))[DAY]
        self.assertEqual((e.enabled_from, e.last_period_key, e.changed_by), (self.now, "2026-11-02", ADMIN + 1))
        self.assertEqual([p.key for p in (await self.svc.owed(GA, DAY, utc(2026, 11, 22, 12), limit=9)).periods],
                         ["2026-11-20", "2026-11-21"])   # the gap while it was off is not replayed
        self.assertEqual([e.event_type for e in self.audit.events], [REPORT_SCHEDULE_SET] * 3)
        self.assertEqual([e.detail for e in self.audit.events], ["period=day enabled=on", "period=day enabled=off", "period=day enabled=on"])

    async def test_groups_are_isolated(self):
        await self.svc.set_enabled(GA, DAY, True, ADMIN)
        await self.svc.mark_done(GA, DAY, "2026-10-31")
        self.assertFalse(await self.svc.is_enabled(GB, DAY))
        self.assertIsNone((await self.svc.entries(GB))[DAY].last_period_key)
        self.assertFalse(await self.svc.mark_done(GB, DAY, "2026-10-31"))   # GB has no row
        await self.svc.set_enabled(GB, DAY, True, ADMIN)
        self.assertIsNone((await self.svc.entries(GB))[DAY].last_period_key)

    async def test_arguments_are_validated(self):
        for args in ((5, DAY, True, ADMIN), (GA, "year", True, ADMIN), (GA, DAY, "yes", ADMIN), (GA, DAY, True, -4),
                     (GA, DAY, True, True), (True, DAY, True, ADMIN)):
            with self.subTest(args=args), self.assertRaises(InvalidInput):
                await self.svc.set_enabled(*args)
        self.assertEqual(await self.store.get_all(GA), [])

    async def test_a_failing_audit_store_does_not_undo_the_switch(self):
        class Broken:
            async def record(self, event):
                raise RuntimeError("down")
        svc = ReportScheduleService(self.store, Broken(), display_timezone=TZ, clock=lambda: self.now)
        with mock.patch("guardian.audit.log") as audit_log:   # the warning is expected; keep the test output clean
            self.assertEqual((await svc.set_enabled(GA, DAY, True, ADMIN)).code, SwitchCode.CHANGED)
        audit_log.warning.assert_called_once()
        self.assertTrue(await svc.is_enabled(GA, DAY))

    async def test_naive_time_is_rejected(self):
        with self.assertRaises(ValueError):
            await self.svc.set_enabled(GA, DAY, True, ADMIN, now=datetime(2026, 11, 1, 12))

    async def test_a_bad_timezone_fails_at_construction(self):
        with self.assertRaises(Exception):
            ReportScheduleService(self.store, None, display_timezone="Mars/Olympus")


class OwedServiceTests(ServiceBase):
    async def test_owed_follows_the_switch_and_the_marker(self):
        await self.svc.set_enabled(GA, DAY, True, ADMIN)            # 2026-11-01 12:00 UTC
        self.assertFalse(await self.svc.owed(GA, DAY))                 # same local day
        self.now = utc(2026, 11, 3, 12)
        owed = await self.svc.owed(GA, DAY)
        self.assertEqual([p.key for p in owed.periods], ["2026-11-01", "2026-11-02"])
        self.assertTrue(await self.svc.mark_done(GA, DAY, "2026-11-01"))
        self.assertEqual([p.key for p in (await self.svc.owed(GA, DAY)).periods], ["2026-11-02"])
        self.assertTrue(await self.svc.mark_done(GA, DAY, "2026-11-02"))
        self.assertFalse(await self.svc.owed(GA, DAY))

    async def test_owed_all_lists_only_enabled_periods_with_something_owed(self):
        await self.svc.set_enabled(GA, DAY, True, ADMIN)
        await self.svc.set_enabled(GA, MONTH, True, ADMIN)
        self.now = utc(2026, 11, 3, 12)
        got = await self.svc.owed_all(GA)
        self.assertEqual(set(got), {DAY})      # the month containing the switch-on has not ended
        self.now = utc(2026, 12, 2, 12)
        got = await self.svc.owed_all(GA)
        self.assertEqual({k: [p.key for p in v.periods] for k, v in got.items()},
                         {DAY: ["2026-11-29", "2026-11-30", "2026-12-01"], MONTH: ["2026-11"]})

    async def test_the_periods_handed_over_carry_a_range_stats_can_read(self):
        await self.svc.set_enabled(GA, WEEK, True, ADMIN)
        self.now = utc(2026, 11, 9, 12)
        (p,) = (await self.svc.owed(GA, WEEK)).periods
        self.assertIsInstance(p, CalendarPeriod)
        self.assertEqual(p.key, "2026-11-01")
        self.assertEqual((p.to_range().start_day, p.to_range().end_day), (date(2026, 11, 1), date(2026, 11, 7)))

    async def test_two_ticks_asking_at_once_see_the_same_periods(self):
        await self.svc.set_enabled(GA, DAY, True, ADMIN)
        self.now = utc(2026, 11, 3, 12)
        a, b = await self.svc.owed(GA, DAY), await self.svc.owed(GA, DAY)
        self.assertEqual(a, b)   # asking never consumes: only mark_done does


class MarkDoneTests(ServiceBase):
    async def asyncSetUp(self):
        await self.svc.set_enabled(GA, DAY, True, ADMIN)
        self.now = utc(2026, 11, 10, 12)

    async def test_it_only_moves_forward(self):
        self.assertTrue(await self.svc.mark_done(GA, DAY, "2026-11-05"))
        self.assertFalse(await self.svc.mark_done(GA, DAY, "2026-11-05"))   # repeat
        self.assertFalse(await self.svc.mark_done(GA, DAY, "2026-11-04"))   # older
        self.assertEqual((await self.svc.entries(GA))[DAY].last_period_key, "2026-11-05")
        self.assertTrue(await self.svc.mark_done(GA, DAY, "2026-11-09"))
        self.assertEqual((await self.svc.entries(GA))[DAY].last_period_key, "2026-11-09")

    async def test_a_period_that_has_not_ended_cannot_be_marked(self):
        for key in ("2026-11-10", "2026-11-11", "2027-01-01"):
            with self.subTest(key=key), self.assertRaises(InvalidInput):
                await self.svc.mark_done(GA, DAY, key)
        self.assertIsNone((await self.svc.entries(GA))[DAY].last_period_key)

    async def test_a_bad_key_is_rejected(self):
        for key in ("", "2026-11", "nope", None):
            with self.subTest(key=key), self.assertRaises(InvalidInput):
                await self.svc.mark_done(GA, DAY, key)

    async def test_it_does_not_need_the_switch_to_still_be_on(self):
        await self.svc.set_enabled(GA, DAY, False, ADMIN)   # switched off while a send was in flight
        self.assertTrue(await self.svc.mark_done(GA, DAY, "2026-11-05"))

    async def test_a_group_with_no_row_is_a_harmless_false(self):
        self.assertFalse(await self.svc.mark_done(GB, DAY, "2026-11-05"))

    async def test_month_keys_order_across_a_year_boundary(self):
        await self.svc.set_enabled(GA, MONTH, True, ADMIN)
        self.now = utc(2027, 3, 5)
        self.assertTrue(await self.svc.mark_done(GA, MONTH, "2026-12"))
        self.assertTrue(await self.svc.mark_done(GA, MONTH, "2027-01"))
        self.assertFalse(await self.svc.mark_done(GA, MONTH, "2026-12"))


# ---------------------------------------------------------------- PostgreSQL layer (recording fake connection)
class RecConn:
    def __init__(self, fetchrow=None, fetch=None):
        self.log: list[tuple[str, str, tuple]] = []
        self._fetchrow, self._fetch = fetchrow, fetch or []

    async def fetchrow(self, sql, *args):
        self.log.append(("fetchrow", " ".join(sql.split()), args))
        return self._fetchrow

    async def fetch(self, sql, *args):
        self.log.append(("fetch", " ".join(sql.split()), args))
        return self._fetch


class RecDb:
    def __init__(self, conn):
        self.conn = conn

    @asynccontextmanager
    async def acquire(self):
        yield self.conn


NOW = utc(2026, 11, 1)


class PostgresTests(unittest.IsolatedAsyncioTestCase):
    async def test_switching_on_is_one_upsert_that_changes_nothing_when_already_on(self):
        conn = RecConn(fetchrow={"group_id": GA})
        self.assertTrue(await PostgresScheduleStore(RecDb(conn)).set_enabled(GA, WEEK, True, ADMIN, NOW))
        kind, sql, args = conn.log[0]
        self.assertTrue(sql.startswith("INSERT INTO report_schedule"))
        self.assertIn("ON CONFLICT (group_id, period) DO UPDATE", sql)
        self.assertIn("WHERE report_schedule.enabled = FALSE", sql)
        self.assertEqual(args, (GA, "week", NOW, ADMIN))
        self.assertEqual(len(conn.log), 1)
        self.assertFalse(await PostgresScheduleStore(RecDb(RecConn(fetchrow=None))).set_enabled(GA, WEEK, True, ADMIN, NOW))

    async def test_switching_off_only_touches_a_row_that_is_on(self):
        conn = RecConn(fetchrow={"group_id": GA})
        self.assertTrue(await PostgresScheduleStore(RecDb(conn)).set_enabled(GA, DAY, False, ADMIN, NOW))
        sql = conn.log[0][1]
        self.assertTrue(sql.startswith("UPDATE report_schedule SET enabled = FALSE"))
        self.assertIn("WHERE group_id = $1 AND period = $2 AND enabled = TRUE", sql)
        self.assertEqual(conn.log[0][2], (GA, "day", ADMIN, NOW))
        self.assertFalse(await PostgresScheduleStore(RecDb(RecConn(fetchrow=None))).set_enabled(GA, DAY, False, ADMIN, NOW))

    async def test_mark_done_is_a_forward_only_compare_and_set_in_one_statement(self):
        conn = RecConn(fetchrow={"group_id": GA})
        self.assertTrue(await PostgresScheduleStore(RecDb(conn)).mark_done(GA, MONTH, "2026-10", NOW))
        _, sql, args = conn.log[0]
        self.assertTrue(sql.startswith("UPDATE report_schedule SET last_period_key = $3"))
        self.assertIn("WHERE group_id = $1 AND period = $2", sql)
        self.assertIn('last_period_key IS NULL OR last_period_key COLLATE "C" < $3', sql)   # byte order, not locale order
        self.assertEqual(args, (GA, "month", "2026-10", NOW))
        self.assertFalse(await PostgresScheduleStore(RecDb(RecConn(fetchrow=None))).mark_done(GA, MONTH, "2026-10", NOW))

    async def test_get_all_is_scoped_by_group_and_maps_rows(self):
        row = {"period": "day", "enabled": True, "enabled_from": NOW, "last_period_key": "2026-10-31", "changed_by": ADMIN, "updated_at": NOW}
        conn = RecConn(fetch=[row])
        got = await PostgresScheduleStore(RecDb(conn)).get_all(GA)
        self.assertIn("WHERE group_id = $1", conn.log[0][1])
        self.assertEqual(conn.log[0][2], (GA,))
        self.assertEqual(got, [ScheduleEntry(GA, DAY, True, NOW, "2026-10-31", ADMIN, NOW)])

    async def test_an_unknown_period_never_reaches_sql(self):
        conn = RecConn()
        with self.assertRaises(ValueError):
            await PostgresScheduleStore(RecDb(conn)).set_enabled(GA, "year", True, ADMIN, NOW)
        self.assertEqual(conn.log, [])

    async def test_the_service_works_over_the_postgres_store_too(self):
        conn = RecConn(fetch=[])
        svc = ReportScheduleService(PostgresScheduleStore(RecDb(conn)), None, display_timezone=TZ, clock=lambda: NOW)
        self.assertFalse(await svc.is_enabled(GA, DAY))
        self.assertEqual(await svc.owed_all(GA), {})
        self.assertEqual(len(conn.log), 2)   # one read each, nothing written


# ---------------------------------------------------------------- migration 0010
class MigrationTests(unittest.TestCase):
    def code(self):
        return "\n".join(l for l in SQL.read_text(encoding="utf-8").splitlines() if not l.lstrip().startswith("--"))

    def test_0010_is_discovered_after_0009(self):
        self.assertEqual([v for v, _ in discover()][8:11], ["0009_daily_counters", "0010_report_schedule", "0011_content_filter"])

    def test_the_table_is_per_group_and_off_by_default(self):
        sql = SQL.read_text(encoding="utf-8")
        self.assertIn("REFERENCES telegram_groups (group_id) ON DELETE RESTRICT", sql)
        self.assertIn("PRIMARY KEY (group_id, period)", sql)
        self.assertIn("enabled         BOOLEAN     NOT NULL DEFAULT FALSE", sql)

    def test_the_period_vocabulary_matches_python(self):
        found = re.search(r"period\s+TEXT\s+NOT NULL CHECK \(period IN \(([^)]*)\)\)", self.code())
        self.assertIsNotNone(found)
        self.assertEqual(tuple(re.findall(r"'([a-z]+)'", found.group(1))), tuple(p.value for p in StatsPeriod))

    def test_an_enabled_row_must_carry_its_start_and_keys_must_match_the_period(self):
        code = self.code()
        self.assertIn("CHECK (NOT enabled OR enabled_from IS NOT NULL)", code)
        self.assertIn("period = 'month' AND last_period_key ~ '^[0-9]{4}-[0-9]{2}$'", code)
        self.assertIn("period IN ('day', 'week') AND last_period_key ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$'", code)

    def test_it_touches_no_other_table_and_no_audit_trigger(self):
        code = self.code()
        self.assertNotRegex(code, r"(?i)\b(ALTER|DROP|TRIGGER|UPDATE|DELETE\s+FROM|INSERT)\b")
        self.assertEqual(re.findall(r"(?i)CREATE TABLE IF NOT EXISTS (\w+)", code), ["report_schedule"])


# ---------------------------------------------------------------- scope guards
class ScopeTests(unittest.TestCase):
    SRC = ROOT / "src" / "guardian"

    def test_nothing_in_this_part_can_send_or_reach_telegram(self):
        for name in ("periodic.py", "schedule_store.py", "schedule_memory_store.py", "schedule_postgres_store.py"):
            text = (self.SRC / "stats" / name).read_text(encoding="utf-8")
            with self.subTest(file=name):
                self.assertNotRegex(text, r"(?m)^\s*(from|import)\s+(aiogram|asyncpg|fastapi)\b")
                self.assertNotRegex(text, r"send_message|send_document|\.bot\b|Bot\(")

    def test_only_the_reports_command_exposes_the_switch(self):
        for path in self.SRC.rglob("*.py"):
            # 6.7: the ONE chat surface is `/reports schedule` (reports/commands.py, wired through the executor)
            if path.name in {"periodic.py", "app.py", "services.py", "audit.py", "__init__.py", "commands.py", "executor.py", "i18n.py", "args.py", "format.py"} or "schedule" in path.name:
                continue
            self.assertNotIn("report_schedule", path.read_text(encoding="utf-8"), str(path))

    def test_the_audit_event_carries_no_free_text(self):
        text = (self.SRC / "stats" / "periodic.py").read_text(encoding="utf-8")
        self.assertIn('detail=f"period={period.value} enabled=', text)


if __name__ == "__main__":
    unittest.main()
