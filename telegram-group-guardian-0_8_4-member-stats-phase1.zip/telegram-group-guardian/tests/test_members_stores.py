"""Phase 4.1: challenge + trusted-bot stores. The contract suite runs on the in-memory store (behaviour); the
PostgreSQL store is checked for query SHAPE only (group scoping, compare-and-set), as elsewhere in this project:
a real PostgreSQL has not been exercised (see TEST_REPORT.md)."""
import asyncio
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from guardian.db.migrations import SQL_DIR, discover
from guardian.members.memory_store import InMemoryBotTrustStore, InMemoryChallengeStore
from guardian.members.models import ChallengeKind as K, ChallengeStatus as S, FailureAction as F
from guardian.members.postgres_store import PostgresBotTrustStore, PostgresChallengeStore
from test_postgres_layer import RecConn, RecDb

T0 = datetime(2026, 10, 30, 12, tzinfo=timezone.utc)
G1, G2, U = -1001, -1002, 555


def mk(store, group=G1, user=U, key="join:1", kind=K.BUTTON, fa=F.RESTRICT, ban=None, answer=None, now=T0, secs=300):
    return store.create(group, user, kind, answer, fa, ban, now, now + timedelta(seconds=secs), key)


class ChallengeContract(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.s = InMemoryChallengeStore()

    async def test_create_and_get_are_group_scoped(self):
        c, created = await mk(self.s, kind=K.MATH, answer="7")
        self.assertTrue(created)
        self.assertEqual((c.status, c.kind, c.answer, c.attempts), (S.PENDING, K.MATH, "7", 0))
        self.assertEqual(await self.s.get(G1, c.id), c)
        self.assertIsNone(await self.s.get(G2, c.id))  # another group never sees it
        self.assertIsNone(await self.s.get_pending(G2, U))
        self.assertEqual(await self.s.list_pending(G2), [])

    async def test_redelivery_same_key_does_not_create_a_second_challenge(self):
        a, ca = await mk(self.s)
        b, cb = await mk(self.s)
        self.assertEqual((ca, cb), (True, False))
        self.assertEqual(a.id, b.id)
        self.assertEqual(len(await self.s.list_pending(G1)), 1)

    async def test_rejoin_while_pending_reuses_the_pending_challenge(self):
        a, _ = await mk(self.s, key="join:1")
        b, created = await mk(self.s, key="join:2")
        self.assertFalse(created)
        self.assertEqual(b.id, a.id)

    async def test_same_key_in_two_groups_are_independent(self):
        a, ca = await mk(self.s, group=G1)
        b, cb = await mk(self.s, group=G2)
        self.assertTrue(ca and cb)
        self.assertNotEqual(a.id, b.id)
        self.assertEqual((a.group_id, b.group_id), (G1, G2))

    async def test_new_challenge_allowed_after_resolution(self):
        a, _ = await mk(self.s, key="join:1")
        await self.s.resolve(G1, a.id, S.PASSED, T0)
        b, created = await mk(self.s, key="join:2")
        self.assertTrue(created)
        self.assertNotEqual(a.id, b.id)

    async def test_resolve_is_compare_and_set_and_group_scoped(self):
        c, _ = await mk(self.s)
        self.assertIsNone(await self.s.resolve(G2, c.id, S.PASSED, T0))  # wrong group
        done = await self.s.resolve(G1, c.id, S.PASSED, T0 + timedelta(seconds=5))
        self.assertEqual((done.status, done.resolved_by), (S.PASSED, None))
        self.assertIsNone(await self.s.resolve(G1, c.id, S.EXPIRED, T0))  # already resolved: do nothing
        self.assertEqual((await self.s.get(G1, c.id)).status, S.PASSED)
        self.assertIsNone(await self.s.get_pending(G1, U))

    async def test_resolve_records_the_admin(self):
        c, _ = await mk(self.s, kind=K.ADMIN)
        done = await self.s.resolve(G1, c.id, S.APPROVED, T0, resolved_by=42)
        self.assertEqual((done.status, done.resolved_by), (S.APPROVED, 42))

    async def test_cannot_resolve_to_pending_or_create_with_past_expiry(self):
        c, _ = await mk(self.s)
        with self.assertRaises(ValueError):
            await self.s.resolve(G1, c.id, S.PENDING, T0)
        with self.assertRaises(ValueError):
            await self.s.create(G1, 9, K.BUTTON, None, F.KICK, None, T0, T0, "k")

    async def test_attempts_count_only_while_pending(self):
        c, _ = await mk(self.s)
        self.assertEqual(await self.s.record_attempt(G1, c.id), 1)
        self.assertEqual(await self.s.record_attempt(G1, c.id), 2)
        self.assertIsNone(await self.s.record_attempt(G2, c.id))
        await self.s.resolve(G1, c.id, S.FAILED, T0)
        self.assertIsNone(await self.s.record_attempt(G1, c.id))
        self.assertEqual((await self.s.get(G1, c.id)).attempts, 2)

    async def test_prompt_message_only_while_pending(self):
        c, _ = await mk(self.s)
        self.assertFalse(await self.s.set_prompt_message(G1, c.id, 0))
        self.assertFalse(await self.s.set_prompt_message(G2, c.id, 10))
        self.assertTrue(await self.s.set_prompt_message(G1, c.id, 10))
        self.assertEqual((await self.s.get(G1, c.id)).prompt_message_id, 10)
        await self.s.resolve(G1, c.id, S.PASSED, T0)
        self.assertFalse(await self.s.set_prompt_message(G1, c.id, 11))

    async def test_ban_seconds_kept_only_for_ban(self):
        a, _ = await mk(self.s, user=1, key="a", fa=F.BAN, ban=600)
        b, _ = await mk(self.s, user=2, key="b", fa=F.KICK, ban=600)
        self.assertEqual((a.ban_seconds, b.ban_seconds), (600, None))

    async def test_list_due_is_ordered_bounded_and_skips_resolved_and_future(self):
        a, _ = await mk(self.s, user=1, key="a", secs=100)
        b, _ = await mk(self.s, user=2, key="b", secs=50)
        c, _ = await mk(self.s, group=G2, user=3, key="c", secs=70)
        d, _ = await mk(self.s, user=4, key="d", secs=9999)
        e, _ = await mk(self.s, user=5, key="e", secs=60)
        await self.s.resolve(G1, e.id, S.PASSED, T0)
        now = T0 + timedelta(seconds=100)  # a is due exactly at its deadline
        self.assertEqual([r.id for r in await self.s.list_due(now, 10)], [b.id, c.id, a.id])
        self.assertEqual([r.id for r in await self.s.list_due(now, 2)], [b.id, c.id])
        self.assertEqual(await self.s.list_due(now, 0), [])
        self.assertEqual(await self.s.list_due(T0 + timedelta(seconds=49), 10), [])
        self.assertNotIn(d.id, [r.id for r in await self.s.list_due(now, 10)])

    async def test_purge_resolved_keeps_pending_and_recent(self):
        old, _ = await mk(self.s, user=1, key="o")
        new, _ = await mk(self.s, user=2, key="n")
        pend, _ = await mk(self.s, user=3, key="p")
        await self.s.resolve(G1, old.id, S.PASSED, T0 - timedelta(days=40))
        await self.s.resolve(G1, new.id, S.PASSED, T0)
        self.assertEqual(await self.s.purge_resolved(T0 - timedelta(days=30)), 1)
        self.assertIsNone(await self.s.get(G1, old.id))
        self.assertIsNotNone(await self.s.get(G1, new.id))
        self.assertIsNotNone(await self.s.get(G1, pend.id))

    async def test_concurrent_resolution_has_exactly_one_winner(self):
        c, _ = await mk(self.s)
        results = await asyncio.gather(*(self.s.resolve(G1, c.id, S.PASSED, T0) for _ in range(5)))
        self.assertEqual(sum(r is not None for r in results), 1)


class BotTrustContract(unittest.IsolatedAsyncioTestCase):
    async def test_lists_are_independent_per_group_and_idempotent(self):
        s = InMemoryBotTrustStore()
        self.assertTrue(await s.add(G1, 99, 1, "rose", T0))
        self.assertFalse(await s.add(G1, 99, 2, None, T0))
        self.assertTrue(await s.is_trusted(G1, 99))
        self.assertFalse(await s.is_trusted(G2, 99))
        self.assertEqual([b.bot_id for b in await s.list(G1)], [99])
        self.assertEqual(await s.list(G2), [])
        self.assertFalse(await s.remove(G2, 99))
        self.assertTrue(await s.remove(G1, 99))
        self.assertFalse(await s.remove(G1, 99))
        self.assertFalse(await s.is_trusted(G1, 99))


class PostgresShapeTests(unittest.IsolatedAsyncioTestCase):
    async def test_group_scoped_statements_filter_by_group_first(self):
        conn = RecConn(fetchrow=None, fetch=[])
        s = PostgresChallengeStore(RecDb(conn))
        await s.get(G1, 1)
        await s.get_pending(G1, U)
        await s.set_prompt_message(G1, 1, 5)
        await s.record_attempt(G1, 1)
        await s.resolve(G1, 1, S.PASSED, T0)
        await s.list_pending(G1)
        self.assertEqual(len(conn.log), 6)
        for _, sql, args, _ in conn.log:
            self.assertIn("group_id = $1", sql)
            self.assertEqual(args[0], G1)

    async def test_mutations_are_compare_and_set_on_pending(self):
        conn = RecConn(fetchrow=None)
        s = PostgresChallengeStore(RecDb(conn))
        self.assertIsNone(await s.resolve(G1, 1, S.EXPIRED, T0))
        self.assertIsNone(await s.record_attempt(G1, 1))
        self.assertFalse(await s.set_prompt_message(G1, 1, 5))
        for _, sql, _, _ in conn.log:
            self.assertTrue(sql.startswith("UPDATE member_verifications"))
            self.assertIn("status = 'pending'", sql)
            self.assertNotIn("SELECT", sql.split("WHERE")[0])

    async def test_resolve_refuses_pending_target_before_sql(self):
        conn = RecConn()
        with self.assertRaises(ValueError):
            await PostgresChallengeStore(RecDb(conn)).resolve(G1, 1, S.PENDING, T0)
        self.assertEqual(conn.log, [])

    async def test_create_is_one_insert_and_falls_back_to_reads_only_on_conflict(self):
        row = {"id": 1, "group_id": G1, "user_id": U, "kind": "button", "status": "pending", "answer": None, "attempts": 0,
               "failure_action": "ban", "ban_seconds": 60, "prompt_message_id": None, "created_at": T0,
               "expires_at": T0 + timedelta(seconds=60), "resolved_at": None, "resolved_by": None, "idempotency_key": "k"}
        conn = RecConn(fetchrow=row)
        c, created = await mk(PostgresChallengeStore(RecDb(conn)), fa=F.BAN, ban=60, key="k", secs=60)
        self.assertTrue(created)
        self.assertEqual(len(conn.log), 1)
        self.assertIn("ON CONFLICT DO NOTHING", conn.log[0][1])
        self.assertEqual((conn.log[0][2][4], conn.log[0][2][5]), (F.BAN.value, 60))

    async def test_create_drops_ban_seconds_unless_ban(self):
        conn = RecConn(fetchrow=None)
        try:
            await mk(PostgresChallengeStore(RecDb(conn)), fa=F.KICK, ban=600)
        except RuntimeError:  # nothing came back from the fake; only the bound arguments matter here
            pass
        self.assertIsNone(conn.log[0][2][5])

    async def test_create_on_conflict_reads_existing_by_key_then_by_pending_member(self):
        row = {"id": 3, "group_id": G1, "user_id": U, "kind": "button", "status": "pending", "answer": None, "attempts": 0,
               "failure_action": "restrict", "ban_seconds": None, "prompt_message_id": None, "created_at": T0,
               "expires_at": T0 + timedelta(seconds=60), "resolved_at": None, "resolved_by": None, "idempotency_key": "old"}

        class Seq(RecConn):  # insert -> conflict (None); by-key -> None; by-pending-member -> row
            def __init__(self):
                super().__init__()
                self.queue = [None, None, row]

            async def fetchrow(self, sql, *args):
                await self._rec("fetchrow", sql, args)
                return self.queue.pop(0)

        conn = Seq()
        c, created = await mk(PostgresChallengeStore(RecDb(conn)), key="new")
        self.assertEqual((created, c.id), (False, 3))
        self.assertEqual(len(conn.log), 3)
        self.assertIn("idempotency_key = $2", conn.log[1][1])
        self.assertIn("status = 'pending'", conn.log[2][1])
        for _, sql, args, _ in conn.log:
            self.assertEqual(args[0], G1)

    async def test_create_conflict_with_nothing_to_return_asks_for_retry(self):
        with self.assertRaises(RuntimeError):
            await mk(PostgresChallengeStore(RecDb(RecConn(fetchrow=None))))

    async def test_create_rejects_non_future_expiry_before_sql(self):
        conn = RecConn()
        with self.assertRaises(ValueError):
            await PostgresChallengeStore(RecDb(conn)).create(G1, U, K.BUTTON, None, F.KICK, None, T0, T0, "k")
        self.assertEqual(conn.log, [])

    async def test_sweeper_and_purge_are_the_only_cross_group_statements(self):
        conn = RecConn(fetch=[])
        s = PostgresChallengeStore(RecDb(conn))
        await s.list_due(T0, 5)
        await s.purge_resolved(T0)
        self.assertEqual(conn.log[0][2], (T0, 5))
        self.assertIn("status = 'pending' AND expires_at <= $1", conn.log[0][1])
        self.assertIn("status <> 'pending'", conn.log[1][1])

    async def test_bot_trust_queries_are_scoped(self):
        conn = RecConn(fetchrow=None, fetch=[])
        s = PostgresBotTrustStore(RecDb(conn))
        await s.add(G1, 9, 1, None, T0)
        await s.remove(G1, 9)
        await s.is_trusted(G1, 9)
        await s.list(G1)
        for _, sql, args, _ in conn.log:
            self.assertIn("group_id", sql)
            self.assertEqual(args[0], G1)
        self.assertIn("ON CONFLICT (group_id, bot_id) DO NOTHING", conn.log[0][1])


class MigrationFileTests(unittest.TestCase):
    sql = (SQL_DIR / "0004_members_welcome_verification.sql").read_text(encoding="utf-8")

    def test_discovered_in_order_after_0003(self):
        names = [v for v, _ in discover()]
        self.assertEqual(names[:4], ["0001_initial", "0002_security_and_access", "0003_moderation_records",
                                     "0004_members_welcome_verification"])

    def test_earlier_migrations_are_untouched(self):
        import hashlib
        self.assertEqual(hashlib.sha256((SQL_DIR / "0003_moderation_records.sql").read_bytes()).hexdigest(),
                         "b54d055f951da3b6fa72c418662aa3b3f9dc096bd4702f91da316a91f36ece8b")

    def test_tables_are_group_scoped_with_cascade(self):
        for table in ("group_trusted_bots", "member_verifications"):
            self.assertIn(f"CREATE TABLE IF NOT EXISTS {table}", self.sql)
        self.assertEqual(self.sql.count("REFERENCES telegram_groups (group_id) ON DELETE CASCADE"), 2)

    def test_integrity_constraints_present(self):
        for needle in ("uq_member_verifications_pending", "WHERE status = 'pending'", "uq_member_verifications_idem",
                       "member_verifications_expiry_after_create", "member_verifications_resolved_consistent",
                       "PRIMARY KEY (group_id, bot_id)", "idx_member_verifications_due"):
            self.assertIn(needle, self.sql)

    def test_no_destructive_or_earlier_table_changes(self):
        upper = self.sql.upper()
        for bad in ("DROP ", "TRUNCATE", "ALTER TABLE", "DELETE FROM"):
            self.assertNotIn(bad, upper)

    def test_status_and_kind_vocabularies_match_the_enums(self):
        for e in list(K) + list(S) + list(F):
            self.assertIn(f"'{e.value}'", self.sql)


if __name__ == "__main__":
    unittest.main()
