"""Part 9.5: the owner's default words (add / remove / list), the `الاوامر` full list, and the alef/hamza/ta-marbuta
equivalence of every Arabic command. Pure parsers + in-memory stores; nothing touches Telegram or PostgreSQL."""
from __future__ import annotations

import asyncio
import itertools
import unittest

from guardian.content_filter.classifier import BLOCK, CLEAN, ContentClassifier
from guardian.content_filter.default_words import InMemoryDefaultWordStore, DefaultWordsService, MAX_OWNER_WORDS
from guardian.content_filter.lexicon import Lexicon
from guardian.moderation.commands import Command, parse_command
from guardian.moderation.filter_phrases import parse_filter_phrase
from guardian.owner_panel.default_words_commands import (DefaultWordsCommandService, ParsedDefaultWords,
                                                         parse_default_words_command)


def run(coro):
    return asyncio.run(coro)


def base_classifier() -> ContentClassifier:
    return ContentClassifier(Lexicon(explicit=frozenset({"سكس"}), insults=frozenset({"حقير"}), hints=frozenset({"موعد"})))


class FakePermissions:
    def __init__(self, owner: int = 7):
        self.owner = owner

    async def check_global(self, user_id, permission, *, audit_denial=True):
        from guardian.permissions import PermissionDecision
        return PermissionDecision(user_id == self.owner, permission, "ok" if user_id == self.owner else "not_owner")


class FakeAudit:
    def __init__(self):
        self.events = []

    async def record(self, event):
        self.events.append(event)


def make():
    classifier = base_classifier()
    store = InMemoryDefaultWordStore()
    words = DefaultWordsService(store, classifier)
    audit = FakeAudit()
    return classifier, store, words, audit, DefaultWordsCommandService(words, FakePermissions(), audit)


class ParserTests(unittest.TestCase):
    def test_arabic_forms(self):
        cases = {
            "اضافة كلمة افتراضية بيب": ("add", ("بيب",)),
            "إضافة كلمة افتراضيه بيب": ("add", ("بيب",)),
            "أضف كلمة افتراضية بيب": ("add", ("بيب",)),
            "اضافه كلمه افتراضيه بيب": ("add", ("بيب",)),
            "اضافة كلمات افتراضية بيب ببب": ("add", ("بيب", "ببب")),
            "حذف كلمة افتراضية بيب": ("remove", ("بيب",)),
            "حذف كلمة افتراضيه بيب": ("remove", ("بيب",)),
            "احذف كلمة افتراضية بيب": ("remove", ("بيب",)),
            "إزالة كلمة افتراضية بيب": ("remove", ("بيب",)),
            "عرض الكلمات الافتراضية": ("list", ()),
            "عرض الكلمات الافتراضيه": ("list", ()),
            "الكلمات الافتراضية": ("list", ()),
            "قائمة الكلمات الافتراضية": ("list", ()),
            "قائمه الكلمات الافتراضيه": ("list", ()),
            "اضافة كلمة افتراضية": ("usage", ()),
            "اضافة كلمة افتراضية بيب ببب": ("usage", ()),
        }
        for text, (action, words) in cases.items():
            with self.subTest(text=text):
                self.assertEqual(parse_default_words_command(text), ParsedDefaultWords(action, words))

    def test_english_forms(self):
        self.assertEqual(parse_default_words_command("/defaultword add bad"), ParsedDefaultWords("add", ("bad",)))
        self.assertEqual(parse_default_words_command("/defaultword remove bad x"), ParsedDefaultWords("remove", ("bad", "x")))
        self.assertEqual(parse_default_words_command("/defaultwords"), ParsedDefaultWords("list"))
        self.assertEqual(parse_default_words_command("/defaultword"), ParsedDefaultWords("list"))
        self.assertEqual(parse_default_words_command("/defaultword add"), ParsedDefaultWords("usage"))
        self.assertIsNone(parse_default_words_command("/defaultword@OtherBot add x", "MyBot"))
        self.assertEqual(parse_default_words_command("/defaultword@MyBot add x", "MyBot"), ParsedDefaultWords("add", ("x",)))

    def test_ordinary_chat_is_not_a_command(self):
        for text in ("اضافة كلمة بيب", "حذف كلمة بيب", "عرض الكلمات", "الكلمات", "هذه كلمة افتراضية", "اضافة افتراضية",
                     "كلمة افتراضية", "/start", "", "   ", None, 5):
            with self.subTest(text=text):
                self.assertIsNone(parse_default_words_command(text))

    def test_the_group_parser_leaves_the_owner_vocabulary_alone(self):
        for text in ("اضافة كلمة افتراضية بيب", "اضافة كلمات افتراضية بيب ببب", "حذف كلمة افتراضية بيب",
                     "اضافة كلمة افتراضية", "إضافة كلمات افتراضيه", "حذف كلمات الافتراضية بيب"):
            with self.subTest(text=text):
                self.assertIsNone(parse_filter_phrase(text.split()))
                self.assertIsNone(parse_command(text))
        # the group commands of part 9.4 are unchanged
        self.assertEqual(parse_filter_phrase("اضافة كلمة بيب".split()), ("adult", "add", "بيب"))
        self.assertEqual(parse_command("قائمة الكلمات").command, Command.PROTECT)


class ServiceTests(unittest.TestCase):
    def test_add_makes_the_word_block_and_normalises(self):
        classifier, store, words, *_ = make()
        self.assertEqual(classifier.classify("هذا بيب").level, CLEAN)
        result = run(words.add(7, ["بِيـــب"]))
        self.assertEqual(result.added, ("بيب",))
        self.assertEqual(classifier.classify("هذا بيب").level, BLOCK)
        self.assertEqual(classifier.classify("هذا ببييب").level, BLOCK)      # repeated letters fold to the same entry
        self.assertEqual(store.rows, {"بيب": "add"})

    def test_hamza_and_ta_marbuta_variants_are_one_word(self):
        classifier, _, words, *_ = make()
        run(words.add(7, ["أباحة"]))
        for variant in ("اباحة", "إباحه", "آباحة", "اباحه"):
            self.assertEqual(classifier.classify(variant).level, BLOCK, variant)
        again = run(words.add(7, ["إباحه"]))
        self.assertEqual((again.added, again.unchanged), ((), ("اباحه",)))

    def test_remove_an_owner_word_deletes_the_row(self):
        classifier, store, words, *_ = make()
        run(words.add(7, ["بيب"]))
        result = run(words.remove(7, ["بيب"]))
        self.assertEqual(result.removed, ("بيب",))
        self.assertEqual(store.rows, {})
        self.assertEqual(classifier.classify("بيب").level, CLEAN)

    def test_remove_a_bundled_word_switches_it_off_and_add_brings_it_back(self):
        classifier, store, words, *_ = make()
        self.assertEqual(classifier.classify("سكس").level, BLOCK)
        self.assertEqual(run(words.remove(7, ["سكس", "حقير", "موعد"])).removed, ("سكس", "حقير", "موعد"))
        for w in ("سكس", "حقير", "موعد"):
            self.assertEqual(classifier.classify(w).level, CLEAN, w)
        self.assertEqual(store.rows, {"سكس": "remove", "حقير": "remove", "موعد": "remove"})
        self.assertEqual(run(words.add(7, ["سكس"])).added, ("سكس",))
        self.assertEqual(classifier.classify("سكس").level, BLOCK)
        self.assertNotIn("سكس", store.rows)
        # the bundled lexicon itself is never modified
        self.assertIn("سكس", classifier.base_lexicon.explicit)

    def test_unchanged_and_invalid_are_reported(self):
        _, _, words, *_ = make()
        self.assertEqual(run(words.add(7, ["سكس"])).unchanged, ("سكس",))            # already a bundled word
        self.assertEqual(run(words.remove(7, ["غيرموجودة"])).unchanged, ("غيرموجوده",))   # stored folded: ة -> ه
        bad = run(words.add(7, ["ا", "كلمتان معا", "x" * 40, "ab-cd"]))
        self.assertEqual(bad.added, ())
        self.assertEqual(len(bad.invalid), 4)

    def test_refresh_restores_the_state_after_a_restart_and_survives_a_store_failure(self):
        classifier, store, words, *_ = make()
        run(words.add(7, ["بيب"]))
        run(words.remove(7, ["سكس"]))
        fresh = base_classifier()
        run(DefaultWordsService(store, fresh).refresh())
        self.assertEqual(fresh.classify("بيب").level, BLOCK)
        self.assertEqual(fresh.classify("سكس").level, CLEAN)

        class Broken(InMemoryDefaultWordStore):
            async def load(self):
                raise RuntimeError("db down")
        keep = base_classifier()
        import logging
        logger = logging.getLogger("guardian.content_filter.default_words")
        logger.disabled = True                                                    # the failure is logged on purpose; keep the run quiet
        try:
            self.assertFalse(run(DefaultWordsService(Broken(), keep).refresh()))
        finally:
            logger.disabled = False
        self.assertEqual(keep.classify("سكس").level, BLOCK)                       # bundled list untouched

    def test_the_owner_word_limit(self):
        _, store, words, *_ = make()
        store.rows.update({f"كلمه{i}": "add" for i in range(MAX_OWNER_WORDS)})
        run(words.refresh())
        result = run(words.add(7, ["جديده"]))
        self.assertTrue(result.limit_reached)
        self.assertEqual(result.added, ())

    def test_view(self):
        _, _, words, *_ = make()
        run(words.add(7, ["بيب"]))
        run(words.remove(7, ["سكس"]))
        view = words.view()
        self.assertEqual((view.bundled_explicit, view.bundled_insults, view.bundled_hints), (1, 1, 1))
        self.assertEqual((view.added, view.removed, view.bundled_sample), (("بيب",), ("سكس",), ()))


class CommandServiceTests(unittest.TestCase):
    def call(self, svc, text, *, user=7, chat=7, chat_type="private"):
        parsed = parse_default_words_command(text)
        return run(svc.run(parsed, chat_id=chat, chat_type=chat_type, user_id=user, lang="ar"))

    def test_full_flow_in_arabic(self):
        classifier, _, _, audit, svc = make()
        reply = self.call(svc, "اضافة كلمة افتراضية بيب")
        self.assertEqual(reply.status, "changed")
        self.assertIn("بيب", reply.text)
        self.assertEqual(classifier.classify("بيب").level, BLOCK)
        shown = self.call(svc, "عرض الكلمات الافتراضية")
        self.assertEqual(shown.status, "list")
        self.assertIn("بيب", shown.text)
        self.assertIn("سكس", shown.text)
        self.assertEqual(self.call(svc, "اضافة كلمة افتراضية بيب").status, "unchanged")
        self.assertEqual(self.call(svc, "حذف كلمة افتراضية بيب").status, "changed")
        self.assertEqual(classifier.classify("بيب").level, CLEAN)
        self.assertEqual(self.call(svc, "حذف كلمة افتراضية بيب").status, "unchanged")
        self.assertEqual(self.call(svc, "اضافة كلمة افتراضية").status, "usage")

    def test_only_the_owner_in_a_private_chat(self):
        classifier, _, _, audit, svc = make()
        self.assertIsNone(self.call(svc, "اضافة كلمة افتراضية بيب", user=8, chat=8))             # not the owner
        self.assertIsNone(self.call(svc, "اضافة كلمة افتراضية بيب", user=7, chat=-100, chat_type="supergroup"))
        self.assertIsNone(self.call(svc, "اضافة كلمة افتراضية بيب", user=7, chat=9))             # chat is not the user's own
        self.assertEqual(classifier.classify("بيب").level, CLEAN)
        self.assertEqual(audit.events, [])

    def test_the_audit_never_carries_the_word(self):
        _, _, _, audit, svc = make()
        self.call(svc, "اضافة كلمة افتراضية بيبكلمة")
        self.assertEqual(len(audit.events), 1)
        self.assertEqual(audit.events[0].event_type, "default_words_changed")
        self.assertNotIn("بيبكلمة", audit.events[0].detail or "")
        self.call(svc, "اضافة كلمة افتراضية بيبكلمة")      # unchanged -> no event
        self.assertEqual(len(audit.events), 1)

    def test_the_list_fits_a_telegram_message_even_with_many_words(self):
        _, store, words, _, svc = make()
        store.rows.update({f"كلمه{chr(0x0621 + i % 26)}{i}": "add" for i in range(400)})
        run(words.refresh())
        self.assertLessEqual(len(self.call(svc, "عرض الكلمات الافتراضية").text), 4096)

    def test_html_is_escaped(self):
        _, _, _, _, svc = make()
        reply = self.call(svc, "اضافة كلمة افتراضية <b>")
        self.assertNotIn("<b>", reply.text)


class WiringTests(unittest.TestCase):
    def test_app_and_router_are_wired(self):
        import pathlib
        src = pathlib.Path(__file__).resolve().parents[1] / "src" / "guardian"
        app = (src / "app.py").read_text(encoding="utf-8")
        for needle in ("DefaultWordsService(", "owner_default_words=DefaultWordsCommandService(", "classifier=content_classifier",
                       "await default_words.refresh()"):
            self.assertIn(needle, app)
        self.assertIn("match_default_words_command", (src / "bot" / "routers" / "owner_panel.py").read_text(encoding="utf-8"))
        self.assertIn("owner_default_words", (src / "services.py").read_text(encoding="utf-8"))

    def test_migration_0012(self):
        import pathlib
        sql = (pathlib.Path(__file__).resolve().parents[1] / "src" / "guardian" / "db" / "sql"
               / "0012_content_default_words.sql").read_text(encoding="utf-8")
        for needle in ("CREATE TABLE IF NOT EXISTS content_default_words", "PRIMARY KEY", "('add', 'remove')"):
            self.assertIn(needle, sql)


class CommandsListTests(unittest.TestCase):
    def test_the_list_names_every_command_family_and_the_new_commands(self):
        from guardian.i18n import t
        for lang in ("ar", "en"):
            text = t("commands_all", lang)
            for needle in ("حظر", "كتم", "تثبيت", "قفل", "وثق", "الاحصائيات", "تصدير", "تفعيل الفلتر النصي", "قائمة الكلمات",
                           "الاوامر", "تفعيل البوت"):
                self.assertIn(needle, text, (lang, needle))
            self.assertLessEqual(len(text), 4096)
            owner = t("commands_owner", lang)
            for needle in ("اضافة كلمة افتراضية", "حذف كلمة افتراضية", "عرض الكلمات الافتراضية", "لوحة المالك", "القوالب",
                           "الافتراضيات", "تجربة", "نسخة احتياطية", "استعادة"):
                self.assertIn(needle, owner, (lang, needle))


if __name__ == "__main__":
    unittest.main()
