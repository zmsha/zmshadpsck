import unittest

from guardian.i18n import MESSAGES
from guardian.moderation.commands import CommandError
from guardian.moderation.duration import DurationError
from guardian.moderation.messages import error_message
from guardian.moderation.targets import TargetError
from guardian.protection.settings import ProtectionSettings as PS

DURATION_CODES = ("empty", "negative", "zero", "format", "unit", "too_short", "too_long")
TARGET_CODES = ("missing", "ambiguous", "format", "invalid", "unresolvable", "username_unresolved", "self", "bot",
                "lookup_failed", "protected")


class WarnSettings(unittest.TestCase):
    def test_defaults(self):
        s = PS.from_raw({})
        self.assertEqual((s.warn_limit, s.warn_action, s.warn_action_seconds), (3, "mute", 86400))
        self.assertEqual(PS().warn_limit, 3)
        self.assertEqual(PS.from_raw("junk").warn_action, "mute")

    def test_valid_values(self):
        s = PS.from_raw({"warn_limit": 5, "warn_action": "ban", "warn_action_seconds": 0})
        self.assertEqual((s.warn_limit, s.warn_action, s.warn_action_seconds), (5, "ban", 0))
        self.assertEqual(PS.from_raw({"warn_action": "kick"}).warn_action, "kick")
        self.assertEqual(PS.from_raw({"warn_action_seconds": 3600}).warn_action_seconds, 3600)

    def test_invalid_values_fall_back_to_safe_defaults(self):
        for raw in ({"warn_limit": 0}, {"warn_limit": 21}, {"warn_limit": True}, {"warn_limit": "3"}, {"warn_limit": -1}):
            self.assertEqual(PS.from_raw(raw).warn_limit, 3, raw)
        for v in ("delete", "BAN", None, 1, ["ban"]):
            self.assertEqual(PS.from_raw({"warn_action": v}).warn_action, "mute", v)
        for v in (-1, 59, 366 * 86400 + 1, True, "1h", 1.5):
            self.assertEqual(PS.from_raw({"warn_action_seconds": v}).warn_action_seconds, 86400, v)

    def test_existing_protection_settings_unchanged(self):
        s = PS.from_raw({"flood_max_messages": 9, "dry_run": True})
        self.assertEqual((s.flood_max_messages, s.dry_run, s.links_enabled), (9, True, True))


class Messages(unittest.TestCase):
    def test_every_code_has_both_languages(self):
        keys = [f"mod_err_duration_{c}" for c in DURATION_CODES] + [f"mod_err_target_{c}" for c in TARGET_CODES] + ["mod_err_too_many_args"]
        for k in keys:
            for lang in ("ar", "en"):
                self.assertIn(k, MESSAGES[lang], k)

    def test_error_message_mapping(self):
        for c in DURATION_CODES:
            self.assertTrue(error_message(DurationError(c), "en"))
            self.assertEqual(error_message(CommandError("duration", c), "ar"), error_message(DurationError(c), "ar"))
        for c in TARGET_CODES:
            self.assertTrue(error_message(TargetError(c), "ar"))
        self.assertTrue(error_message(CommandError("too_many_args"), "en"))

    def test_unknown_errors_return_none(self):
        self.assertIsNone(error_message(ValueError("x")))
        self.assertIsNone(error_message(DurationError("nonexistent")))


if __name__ == "__main__":
    unittest.main()
