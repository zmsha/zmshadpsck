"""In-memory wiring of the Phase 2 services for tests (no aiogram/FastAPI/asyncpg needed)."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import helpers  # noqa: F401  (disables logging for expected-failure tests)
from guardian.audit import InMemorySecurityAudit
from guardian.audit_service import AuditQueryService
from guardian.auth import Authority
from guardian.errors import TelegramLookupFailed
from guardian.groups.memory_store import InMemoryDelegationStore, InMemorySettingsStore, InMemoryTrustStore
from guardian.groups.service import DelegationService, GroupSettingsService, TrustService
from guardian.licensing.admin import LicenseAdminService
from guardian.licensing.memory_store import InMemoryLicenseStore
from guardian.licensing.service import LicenseService
from guardian.moderation.memory_store import InMemorySanctionStore, InMemoryWarningStore
from guardian.moderation.service import SanctionService, WarningService
from guardian.permissions import PermissionService
from guardian.telegram_rights import AdminInfo, ChatMemberInfo

OWNER, BACKUP = 111_111_111, 222_222_222
STRANGER, TG_CREATOR, TG_ADMIN, TG_LIMITED_ADMIN, DELEGATE = 900_001, 900_002, 900_003, 900_004, 900_005
A, B, OWNER_GROUP = -1001, -1002, -1009
NOW = datetime(2026, 10, 29, 12, 0, tzinfo=timezone.utc)


class Clock:
    def __init__(self, now: datetime = NOW):
        self.now = now

    def __call__(self) -> datetime:
        return self.now

    def advance(self, **kw) -> None:
        self.now += timedelta(**kw)


class FakeChatInfo:
    """members[(chat_id, user_id)] -> ChatMemberInfo; unknown pairs are plain members."""

    def __init__(self):
        self.members: dict[tuple[int, int], ChatMemberInfo] = {}
        self.fail = False
        self.calls = 0
        self.admins: dict[int, list[AdminInfo]] = {}
        self.admin_calls = 0
        self.admins_fail = False

    def set(self, chat_id: int, user_id: int, info: ChatMemberInfo) -> None:
        self.members[(chat_id, user_id)] = info

    async def get_member(self, chat_id, user_id, *, fresh=False):
        self.calls += 1
        if self.fail:
            raise TelegramLookupFailed("down")
        return self.members.get((chat_id, user_id), ChatMemberInfo("member"))

    async def get_bot_member(self, chat_id):
        return await self.get_member(chat_id, 777)

    async def list_admins(self, chat_id):
        self.admin_calls += 1
        if self.admins_fail or self.fail:
            raise TelegramLookupFailed("down")
        return list(self.admins.get(chat_id, []))


class Stack:
    def __init__(self):
        self.clock = Clock()
        self.authority = Authority(OWNER, BACKUP)
        self.licenses = InMemoryLicenseStore()
        self.license_service = LicenseService(self.licenses)
        self.deleg_store = InMemoryDelegationStore()
        self.trust_store = InMemoryTrustStore()
        self.settings_store = InMemorySettingsStore()
        self.audit = InMemorySecurityAudit()
        self.chat = FakeChatInfo()
        self.chat.set(A, TG_CREATOR, ChatMemberInfo("creator", True, True, True))
        self.chat.set(B, TG_CREATOR, ChatMemberInfo("creator", True, True, True))
        self.chat.set(A, TG_ADMIN, ChatMemberInfo("administrator", True, True, True))
        self.chat.set(A, TG_LIMITED_ADMIN, ChatMemberInfo("administrator", True, False, True))
        self.chat.set(OWNER_GROUP, TG_CREATOR, ChatMemberInfo("creator", True, True, True))
        self.perm = PermissionService(
            self.authority, self.deleg_store, self.chat, self.audit, self.trust_store, clock=self.clock
        )
        self.admin = LicenseAdminService(self.licenses, self.perm, self.audit, clock=self.clock)
        self.delegations = DelegationService(self.deleg_store, self.licenses, self.perm, self.audit, clock=self.clock)
        self.trust = TrustService(self.trust_store, self.licenses, self.perm, self.audit, clock=self.clock)
        self.settings = GroupSettingsService(self.settings_store, self.licenses, self.perm, self.audit, clock=self.clock)
        self.audit_query = AuditQueryService(self.licenses, self.audit, self.perm)
        self.warning_store = InMemoryWarningStore()
        self.sanction_store = InMemorySanctionStore()
        self.warnings = WarningService(self.warning_store, self.licenses, self.perm, self.audit, clock=self.clock)
        self.sanctions = SanctionService(self.sanction_store, self.licenses, self.perm, self.audit, clock=self.clock)

    async def register(self, *group_ids: int):
        for gid in group_ids:
            await self.license_service.on_bot_added(gid, f"Group {gid}", self.clock())
