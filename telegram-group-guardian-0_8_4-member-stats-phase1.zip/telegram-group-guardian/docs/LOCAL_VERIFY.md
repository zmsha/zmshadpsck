# التحقق المحلي — أوامر تشغّلها أنت على جهازك

> **لماذا هذا الملف؟** بيئة بناء المشروع لم يكن فيها وصول إلى PyPI ولا إلى PostgreSQL ولا Telegram. لذلك **لم تُثبَّت قط** الاعتماديات الحقيقية (`aiogram` و`fastapi` و`uvicorn` و`asyncpg` و`httpx`) **ولم تعمل قط** اختبارات `tests/test_app_integration.py` السبعة (تظهر «متخطاة»). `requirements.txt` مثبَّتة بأرقام اختيرت دون اتصال. **هذه الأوامر هي الدليل الحقيقي الأول**؛ لا تعتبر المشروع جاهزًا قبل أن تنجح.
> كل القيم أدناه **وهمية**. لا تضع توكنك الحقيقي في أوامر تشاركها مع أحد.

المتطلبات: Python 3.11+ (يوصى 3.12)، وللخطوة 6 قاعدة PostgreSQL **اختبارية** (ليست قاعدة الإنتاج).

## 1. تثبيت الاعتماديات
```bash
cd telegram-group-guardian
python3 -m venv .venv && source .venv/bin/activate      # على ويندوز: .venv\Scripts\activate
pip install -r requirements.txt -r requirements-dev.txt
```
**إن فشل التثبيت** (رقم إصدار غير موجود مثلًا): انسخ نص الخطأ كاملًا (بلا أسرار) وأرسله لتصحيح `requirements.txt`. هذا بالذات هو الخطر المعروف.

## 2. الاختبارات (يجب أن تعمل السبعة المتخطاة)
```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src:tests python3 -m unittest discover -s tests
python3 -m compileall -q src
```
المتوقع بعد تثبيت الاعتماديات: **كل الاختبارات تنجح و`skipped=0`** (قبل التثبيت كانت: 2822 اختبارًا، 2815 نجح، 7 متخطاة). أي فشل في `test_app_integration` يعني عدم توافق حقيقي مع aiogram/FastAPI: أرسل اسم الاختبار والخطأ. أو بـ pytest: `pytest -q`.

## 3. فحص الإعدادات
```bash
export BOT_TOKEN="123456789:REPLACE_WITH_TOKEN_FROM_BOTFATHER"      # وهمي (نفس قيمة .env.example)
export DATABASE_URL="postgresql://user:pass@localhost:5432/guardian_test"
export OWNER_TELEGRAM_ID="111111111"
export WEBHOOK_SECRET="local_test_secret_0123456789"
PYTHONPATH=src python -m guardian check-config
```
المتوقع: يمرّ بلا خطأ. جرّب تغيير `WEBHOOK_SECRET` إلى `abc` فيجب أن يرفض بذكر **اسم** المتغير فقط دون قيمته.

## 4. تشغيل الخدمة بقيم وهمية
```bash
export RUN_MIGRATIONS_ON_STARTUP=false      # لا قاعدة بعد: تبقى الخدمة «متدهورة» وهذا سليم
uvicorn --app-dir src guardian.app:create_app --factory --port 10000
```
اتركها تعمل وافتح نافذة طرفية ثانية (مع تفعيل البيئة نفسها).

## 5. اختبار `/health` والـwebhook بـcurl
```bash
# (أ) الصحة: يجب 200 وجسم {"status":"ok","database":"unavailable"|"ok"|"unknown"}
curl -i http://localhost:10000/health

# (ب) webhook بلا الترويسة السرّية: يجب 403
curl -i -X POST http://localhost:10000/telegram/webhook \
  -H "Content-Type: application/json" -d '{"update_id":1}'

# (ج) ترويسة خاطئة: يجب 403
curl -i -X POST http://localhost:10000/telegram/webhook \
  -H "Content-Type: application/json" \
  -H "X-Telegram-Bot-Api-Secret-Token: wrong_secret_value_000" -d '{"update_id":1}'

# (د) الترويسة الصحيحة وتحديث لا يطابق أي معالج: يجب 200 {"ok":true}
curl -i -X POST http://localhost:10000/telegram/webhook \
  -H "Content-Type: application/json" \
  -H "X-Telegram-Bot-Api-Secret-Token: local_test_secret_0123456789" -d '{"update_id":2}'

# (هـ) JSON فاسد أو update_id غير صحيح مع الترويسة الصحيحة: يجب 400
curl -i -X POST http://localhost:10000/telegram/webhook \
  -H "Content-Type: application/json" \
  -H "X-Telegram-Bot-Api-Secret-Token: local_test_secret_0123456789" -d '{"update_id":"x"}'
```
**ملاحظة:** مع قاعدة غير متصلة يُسجَّل تحذير `durable update dedup unavailable` وهذا متوقَّع؛ لا حماية تعمل لأن الترخيص يفشل مغلقًا. تحقق أيضًا أن السجل **لا يحتوي** التوكن ولا رابط القاعدة.

## 6. تطبيق الهجرات على PostgreSQL اختباري
أنشئ قاعدة فارغة (محليًا أو في خدمة اختبارية) وضع رابطها **المباشر** (لا المجمّع):
```bash
export DATABASE_URL="postgresql://user:pass@localhost:5432/guardian_test"   # أضف ?sslmode=require للخدمات السحابية
PYTHONPATH=src python -m guardian migrate
PYTHONPATH=src python -m guardian migrate      # الثانية يجب ألا تطبّق شيئًا
```
المتوقع: تُطبَّق الهجرات `0001` إلى `0013` ثم الثانية «محدّثة». **هذه أول مرة يُنفَّذ فيها SQL المشروع على PostgreSQL حقيقية** — خصوصًا: مشغّلات السجل الأمني (`0006`/`0007`)، دالة الاحتفاظ، قيود CHECK، `ON CONFLICT`، والقفل الاستشاري. أي خطأ SQL أرسله كما هو.

ثم أعد تشغيل `uvicorn` (الخطوة 4) مع `RUN_MIGRATIONS_ON_STARTUP=true` وتأكد أن `/health` يعيد `"database":"ok"`.

## 7. تجربة مع Telegram الحقيقي (اختياري لكنه ضروري قبل الإنتاج)
1. بوت جديد بتوكن جديد (BotFather) ومجموعة اختبار.
2. شغّل خدمة عامة (نشر Render، أو نفق HTTPS مؤقت إلى المنفذ المحلي) واضبط `WEBHOOK_REGISTER_ON_STARTUP=true` و`WEBHOOK_BASE_URL`.
3. تحقق من الـwebhook:
```bash
curl -sS "https://api.telegram.org/bot<BOT_TOKEN>/getWebhookInfo"
```
المتوقع: `url` صحيح، و`pending_update_count` صغير، **وبلا** `last_error_message`.
4. في المجموعة: `/id` ثم `تفعيل البوت 7 ايام` (من المالك) ثم `/status` و`/panel` و`/stats`، وجرّب إرسال رابط مع تفعيل `/protect links on`.
5. من الخاص: `/owner` و`/backup` ثم `/backup confirm <الرمز>` (يصلك ملف) ثم جرّب `/restore` على قاعدة اختبارية فقط.

## 8. ما الذي يجب أن تبلّغ عنه
لخّص النتائج هكذا حتى أكمل منها:
- الخطوة 1: نجح/فشل (مع الخطأ).
- الخطوة 2: العدد الإجمالي وعدد المتخطاة وأي فشل.
- الخطوة 5: رمز HTTP لكل حالة (أ–هـ).
- الخطوة 6: هل طُبّقت الهجرات العشر؟ أي خطأ SQL؟
- الخطوة 7: ما الذي عمل وما الذي لم يعمل على الجوال.

لا ترسل التوكن ولا رابط القاعدة ولا `WEBHOOK_SECRET` الحقيقي.
